(() => {
'use strict';
const STR = {
  pin: ['开会时置顶', 'Keep window on top'],
  stealth: ['共享屏幕时隐身', 'Hidden during screen share'],
  handover: ['交给我的 AI', 'Handover to my AI'],
  mini_capsule: ['收成迷你胶囊', 'Collapse to mini capsule'],
  home: ['首页', 'Home'],
  full: ['切换到完整界面', 'Switch to full app'],
  settings: ['设置、账号与记忆', 'Settings, account and memory'],
  tabs_label: ['工作区', 'Workspace'],
  tab_proactive: ['主动智能', 'Proactive'],
  tab_transcript: ['实时转写', 'Transcript'],
  tab_outputs: ['产出', 'Outputs'],
  conversation: ['对话', 'Conversation'],
  toggle_conversation: ['收起或展开对话', 'Toggle conversation'],
  status_planned: ['待研究', 'Planned'],
  status_failed: ['未完成', 'Failed'],
  status_queued: ['等待研究', 'Queued'],
  live_badge: ['直播', 'Live'],
  choose_session: ['新旁听', 'New session'],
  st_idle: ['待机', 'Idle'],
  st_connecting: ['正在连接', 'Connecting'],
  st_listening: ['正在听', 'Listening'],
  st_paused: ['已暂停', 'Paused'],
  st_ended: ['已结束', 'Ended'],
  sound_source: ['声音来源', 'Sound source'],
  pause: ['暂停', 'Pause'],
  resume: ['继续', 'Resume'],
  stop: ['停止', 'Stop'],
  start: ['旁听', 'Listen'],
  continue_meeting: ['继续录制', 'Resume'],
  new_meeting: ['新会议', 'New meeting'],
  happening: ['正在发生', 'Happening now'],
  final_recap: ['讨论收尾', 'Final recap'],
  stream_empty: ['主动研究与引用会显示在这里。', 'Questions and citations will show up here.'],
  effort_quick: ['⚡ 速查', '⚡ Quick'],
  effort_deep: ['✦ 深研', '✦ Deep'],
  ask_label: ['向 Citeside 提问或发起深度研究', 'Ask or start deep research'],
  ask_ph: ['追问当前讨论，或输入课题立即深度研究...', 'Ask about this call, or start deep research...'],
  ask_send: ['发送', 'Send'],
  tr_label: ['搜索转写内容', 'Search transcript'],
  tr_ph: ['搜索转写关键词...', 'Filter transcript...'],
  copy_tr: ['复制原文', 'Copy transcript'],
  jump_latest: ['↓ 最新', '↓ Latest'],
  new_session: ['+ 新旁听', '+ New session'],
  search_label: ['搜索历史场次', 'Search sessions'],
  search_sessions: ['搜索标题...', 'Search by title...'],
  ho1t: ['复制整场 Markdown 给 AI', 'Copy full Markdown for AI'],
  ho1s: ['标题 + 深度研究 + 核心引用 + 完整转写', 'Title, deep research, insights, and full transcript'],
  ho2t: ['导出 .md 文件', 'Export .md file'],
  ho2s: ['下载结构化 Markdown', 'Download structured Markdown'],
  ho3t: ['仅复制深度研究报告', 'Copy deep research report'],
  ho3s: ['结论、子问题与来源', 'Conclusion, sub-questions, and sources'],
  ho4t: ['仅复制完整转写', 'Copy full transcript'],
  ho4s: ['说话人逐字稿，不含总结', 'Speaker transcript without a summary'],
  back: ['返回', 'Back'],
  back_settings: ['返回', 'Back'],
  copy_research_md: ['复制整份研究 Markdown', 'Copy research Markdown'],
  follow_label: ['针对这份研究追问', 'Ask a follow-up'],
  follow_ph: ['输入追问...', 'Ask a follow-up...'],
  send: ['发送', 'Send'],
  sources_h: ['来源', 'Sources'],
  settings_title: ['设置与记忆', 'Settings and memory'],
  grp_account: ['账号与会员', 'Account and membership'],
  plan_label: ['方案', 'Plan'],
  hours_used: ['已用时长', 'Hours used'],
  grp_mcp: ['连接你的 AI (MCP) 与静默记忆生长', 'Connect your AI (MCP) and silent memory'],
  mcp_copy: ['生成/复制 MCP 配置', 'Copy MCP config'],
  silent: ['会后静默记忆生长', 'Silent post-meeting memory'],
  silent_desc: ['停录后自动提炼高置信事实', 'Extract high-confidence facts after recording stops'],
  tier1: ['角色画像', 'Role profile'],
  profile_name: ['姓名', 'Name'],
  profile_role: ['角色', 'Role'],
  profile_domain: ['领域', 'Domain'],
  profile_prefs: ['偏好', 'Preferences'],
  profile_notes: ['备注', 'Notes'],
  save: ['保存', 'Save'],
  forget: ['遗忘', 'Forget'],
  confirm_forget: ['确认遗忘', 'Confirm forget'],
  tier2: ['项目记忆', 'Project memory'],
  mem_add_ph: ['补充一条项目事实...', 'Add a project fact...'],
  mem_add: ['添加', 'Add'],
  grp_listen: ['收音与小窗', 'Listening and window'],
  ui_lang: ['界面语言', 'Interface language'],
  lang_zh: ['中文', 'Chinese'],
  lang_en: ['EN', 'EN'],
  theme_label: ['主题', 'Theme'],
  theme_auto: ['跟随系统', 'Auto'],
  theme_light: ['浅色', 'Light'],
  theme_dark: ['深色', 'Dark'],
  tongue_label: ['识别语言', 'Recognition language'],
  tongue_auto: ['自动', 'Auto'],
  tongue_zh: ['中文', 'Chinese'],
  tongue_en: ['English', 'English'],
  pin_row: ['置顶窗口', 'Pin window'],
  stealth_row: ['共享隐身', 'Hide on share'],
  full_short: ['完整版', 'Full'],
  win_toolbar_label: ['窗口控制', 'Window controls'],
  win_group_label: ['悬浮与隐身', 'Float and stealth'],
  grp_updates: ['软件更新与高级', 'Updates and advanced'],
  channel_label: ['更新通道', 'Update channel'],
  channel_stable: ['稳定版', 'Stable'],
  channel_candidate: ['Beta 候选版', 'Candidate'],
  check_update: ['检查更新', 'Check updates'],
  install_update: ['下载并安装', 'Download and install'],
  byok: ['高级模型与接口 (BYOK)', 'Advanced model and endpoint (BYOK)'],
  byok_base: ['接口地址', 'Base URL'],
  byok_model: ['模型', 'Model'],
  byok_key: ['接口密钥', 'API key'],
  test_conn: ['测试', 'Test'],
  sign_in: ['登录', 'Sign in'],
  mcp_not_connected: ['未连接', 'Not connected'],
  mcp_connected: ['已连接', 'Connected'],
  mcp_profile_received: ['已收到配置', 'Profile received'],
  mcp_disconnected: ['已断开', 'Disconnected'],
  up_to_date: ['已是最新', 'Up to date'],
  act_deep: ['深入研究', 'Deep research'],
  act_stop: ['停止', 'Stop'],
  act_open: ['打开报告 ›', 'Open report ›'],
  act_save: ['记入背景', 'Save context'],
  act_research: ['深入研究', 'Research'],
  status_quick: ['速查中', 'Quick lookup'],
  status_deep: ['深入研究中', 'Deep research'],
  status_done: ['已完成', 'Done'],
  status_stopped: ['已停止', 'Stopped'],
  kind_suggestion: ['建议', 'Suggestion'],
  kind_insights: ['洞察', 'Insight'],
  kind_history: ['历史', 'History'],
  kind_factcheck: ['事实核对', 'Fact-check'],
  kind_highlight: ['要点', 'Highlight'],
  toast_desktop: ['桌面客户端生效', 'Takes effect in desktop app'],
  toast_copied: ['已复制', 'Copied'],
  toast_copy_fail: ['复制失败', 'Copy failed'],
  toast_saved: ['已记入背景', 'Saved to context'],
  toast_export: ['已导出 Markdown', 'Exported Markdown'],
  toast_export_fail: ['导出失败', 'Export failed'],
  toast_profile: ['已保存画像', 'Profile saved'],
  toast_listening: ['正在旁听，请先结束后再开新场', 'A session is already listening'],
  toast_install_blocked: ['录音中无法安装', 'Cannot install while recording'],
  toast_check_first: ['请先检查更新', 'Check for updates first'],
  toast_saved_byok: ['已保存', 'Saved'],
  toast_test_ok: ['测试通过', 'Test passed'],
  toast_test_idle: ['空闲时才能测试', 'Test is available when idle'],
  toast_test_fail: ['测试失败', 'Test failed'],
  toast_updated: ['已开始安装', 'Install started'],
  toast_forgotten: ['已遗忘', 'Forgotten'],
  mic_source: ['切换声音与麦克风', 'Switch audio & microphone'],
  mic_source_title: ['声音与麦克风输入', 'Audio & microphone input'],
  mic_auto: ['自动（系统声音 + 默认麦克风）', 'Auto (System audio + default mic)'],
  mic_switched: ['已切换麦克风', 'Microphone switched'],
  mic_switch_fail: ['未能切换麦克风，请重试', 'Could not switch microphone']
};
const state = {
  uiLang: 'zh', theme: 'auto', tongue: 'auto', channel: 'stable',
  pinned: false, stealth: false, silentMemory: true, effort: 'quick', tab: 'proactive',
  viewId: '', session: null, research: [], cards: null, interim: '', jobs: [], jobsSequence: 0, chatFolded: false, expandedIds: [],
  native: { active: false, phase: 'idle' }, meetings: [], memory: null, account: null, mcp: null,
  startPending: false, commandPending: false, micSwitching: false, followupPending: false, askDraftSequence: 0, followupDraftSequence: 0, nativeSequence: 0, sessionSequence: 0, researchSequence: 0, sessionRead: null,
  wsRetryTimer: null, wsRetryAttempt: 0, pageHidden: false, updateSequence: 0, updateChecking: false, installPending: false,
  updateOffer: null, ended: false, endedLatch: false, wasActive: false, asking: false,
  sessionOpen: false, handoverOpen: false, micOpen: false, openDrawerName: '', focusReturn: null,
  reportItem: null, contextTexts: [], pollTimer: null, clockTimer: null, clockBase: 0, clockAt: 0, clockSessionId: '', ws: null,
  expertStatus: { state: 'idle', count: 0 }, seenProactiveCount: 0, unreadProactiveCount: 0
};
function tKey(key) {
  const pair = STR[key] || ['', ''];
  return state.uiLang === 'en' ? pair[1] : pair[0];
}
function later(fn, ms) {
  const t = setTimeout(fn, ms);
  if (t && typeof t.unref === 'function') t.unref();
  return t;
}
function el(tag, text) {
  const n = document.createElement(tag);
  if (text != null) n.textContent = text;
  return n;
}
function val(id) {
  const n = document.getElementById(id);
  return n ? String(n.value || '').trim() : '';
}
function uuid() {
  try { if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}
function safeUrl(x) {
  try {
    const u = new URL(x);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return '';
    if (u.username || u.password) return '';
    return u.href;
  } catch (e) { return ''; }
}
function fmtClock(sec) {
  if (typeof sec === 'string' && /^\d+:\d{2}(?::\d{2})?$/.test(sec.trim())) {
    const parts = sec.trim().split(':').map(Number);
    sec = parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : parts[0] * 60 + parts[1];
  }
  sec = Math.max(0, Math.floor(Number(sec) || 0));
  return String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0');
}
function token() {
  try {
    const q = new URLSearchParams(location.search).get('token');
    if (q) return q;
  } catch (e) {}
  try {
    const parsed = JSON.parse(localStorage.getItem('tht-settings') || '{}');
    if (parsed && parsed.relayToken) return parsed.relayToken;
  } catch (e) {}
  return (window.THT_BOOT && window.THT_BOOT.relayToken) || '';
}
async function request(url, opt) {
  try {
    const res = await fetch(url, opt);
    if (res && typeof res.json === 'function') {
      const data = await res.json();
      if (!res.ok) return { ok: false, error: (data && data.error) || ('HTTP ' + res.status) };
      return data && typeof data === 'object' ? data : { ok: false, error: 'Invalid response' };
    }
  } catch (e) {
    return { ok: false, error: (e && e.message) || 'network' };
  }
  return { ok: false, error: 'Invalid response' };
}
function get(url) {
  return request(url, { headers: { 'x-tht-token': token() } });
}
function post(url, body) {
  return request(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-tht-token': token() },
    body: JSON.stringify(body || {})
  });
}
function currentId() {
  if (state.viewId) return state.viewId;
  try { const viewed = new URLSearchParams(location.search).get('id'); if (viewed) return viewed; } catch (e) {}
  return state.native && state.native.sessionId || '';
}
function launchLang() {
  if (state.tongue === 'zh' || state.tongue === 'en') return state.tongue;
  return state.uiLang === 'en' ? 'en' : 'zh';
}
function uiLang() { return state.uiLang === 'en' ? 'en' : 'zh'; }
function phase() {
  const n = state.native || {};
  if (n.starting || n.phase === 'connecting') return 'connecting';
  if (n.active && (n.phase === 'paused' || n.paused)) return 'paused';
  if (n.active || n.phase === 'listening') return 'listening';
  if (state.ended || n.phase === 'ended') return 'ended';
  return 'idle';
}
function viewingLive() {
  const live = state.native.sessionId || '';
  if (!state.viewId) return true;
  if (!live) return false;
  return state.viewId === live;
}
function eventForView(msg) {
  const id = (msg && (msg.sessionId || msg.id)) || '';
  if (!id) {
    if (state.viewId && state.native.sessionId && state.viewId !== state.native.sessionId) return false;
    return true;
  }
  return (state.viewId || state.native.sessionId || id) === id;
}
// Keep the saved-span calculation identical to meeting-workspace recordingSeconds.
function recordingSeconds(snapshot, at) {
  if (!snapshot) return null;
  const stamp = value => typeof value === 'number' ? value : Date.parse(value || ''), start = stamp(snapshot.start), end = snapshot.end ? stamp(snapshot.end) : Number(at);
  if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
  const gap = (snapshot.recordingSpans || []).reduce((sum, span) => {
    const previous = stamp(span.previousEnd), continued = stamp(span.continuedAt);
    return sum + (Number.isFinite(previous) && Number.isFinite(continued) ? Math.max(0, Math.min(end, continued) - Math.max(start, previous)) : 0);
  }, 0);
  return Math.max(0, Math.floor((end - start - gap) / 1000));
}
function noteClock(sec) {
  sec = Number(sec);
  if (!Number.isFinite(sec) || sec < 0 || !state.native.sessionId || state.native.sessionId !== currentId()) return;
  // Native seconds restart on each continued segment, even for the same ID.
  state.clockBase = sec;
  state.clockAt = Date.now();
  state.clockSessionId = state.native.sessionId || '';
}
function shownClock() {
  const id = currentId(), n = state.native || {}, snapshot = state.session?.id === id ? state.session : null;
  const ownsClock = !!id && state.clockSessionId === id;
  const active = ownsClock && n.sessionId === id && n.active;
  if (!active && snapshot?.end) return recordingSeconds(snapshot, Date.now()) ?? 0;
  let segment = ownsClock ? Math.max(0, Number(state.clockBase) || 0) : 0;
  const frozen = !active || n.phase === 'paused' || n.paused || n.captureEnding || state.pageHidden || !state.clockAt || Date.now() - state.clockAt > 6000;
  if (!frozen) segment += Math.min(6000, Math.max(0, Date.now() - state.clockAt)) / 1000;
  // Native audioSeconds is per segment; saved spans hold the earlier captures.
  const last = snapshot?.recordingSpans?.at(-1);
  const prior = last ? recordingSeconds({ ...snapshot, end: last.previousEnd }, Date.now()) : 0;
  return (prior ?? 0) + segment;
}
function levelPct(level) {
  let n = Number(level);
  if (!Number.isFinite(n) || n < 0) n = 0;
  if (n > 1) n = n / 100;
  if (n > 1) n = 1;
  return Math.round(n * 100);
}
function speakerName(spk, session) {
  const names = (session || state.session || {}).names || {};
  if (spk == null || spk === '') return names['0'] || 'S0';
  const key = String(spk);
  if (names[key] != null && names[key] !== '') return String(names[key]);
  if (key === 'them') return state.uiLang === 'en' ? 'Online' : '线上';
  if (key === 'me') return state.uiLang === 'en' ? 'Me' : '我';
  if (/^S\d+$/.test(key)) return key;
  return /^\d+$/.test(key) ? ('S' + key) : key;
}
function spkClass(name) {
  let h = 0;
  const s = String(name || '');
  for (let i = 0; i < s.length; i++) h = (h + s.charCodeAt(i)) % 6;
  return 'spk-' + h;
}
function parseClockValue(raw) {
  if (raw == null || raw === '') return null;
  if (typeof raw === 'string' && /^\d+:\d{2}(?::\d{2})?$/.test(raw.trim())) {
    const parts = raw.trim().split(':').map(Number);
    return parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : parts[0] * 60 + parts[1];
  }
  const n = Number(raw);
  if (!Number.isFinite(n)) return null;
  if (n > 1e11) {
    const startMs = Number(state.session?.start || state.native?.startedAt || 0);
    return startMs > 1e11 ? Math.max(0, Math.round((n - startMs) / 1000)) : 0;
  }
  return Math.max(0, n);
}
function rowSeconds(row) {
  if (!row || typeof row !== 'object') return 0;
  for (const key of ['atSec', 'offset', 't', 'at']) {
    const sec = parseClockValue(row[key]);
    if (sec != null) return sec;
  }
  return 0;
}
function transcriptRows() {
  const s = state.session || {};
  if (Array.isArray(s.transcript) && s.transcript.length) return s.transcript.slice();
  if (viewingLive() && Array.isArray(state.native.recentTranscript)) return state.native.recentTranscript.slice();
  return Array.isArray(s.transcript) ? s.transcript.slice() : [];
}
function asList(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value.filter(Boolean);
  if (typeof value === 'object') return [value];
  return [];
}
function cardText(c) {
  for (const k of ['text', 'body', 'md', 'point', 'claim']) {
    if (c && typeof c[k] === 'string' && c[k]) return c[k];
  }
  return '';
}
function toast(message) {
  const box = document.getElementById('sc-toast');
  const msg = document.getElementById('sc-toast-msg');
  if (!box || !msg) return;
  msg.textContent = message || '';
  box.hidden = false;
  later(() => { box.hidden = true; }, 2800);
}
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(String(text || ''));
    toast(tKey('toast_copied'));
  } catch (e) {
    toast(tKey('toast_copy_fail'));
  }
}
function paintChrome() {
  for (const node of document.querySelectorAll('[data-k]')) {
    const key = node.getAttribute('data-k');
    if (!STR[key]) continue;
    const value = tKey(key);
    const attr = node.getAttribute('data-k-attr') || 'text';
    if (attr === 'placeholder') {
      node.setAttribute('placeholder', value);
      node.placeholder = value;
    } else if (attr === 'title') node.setAttribute('title', value);
    else if (attr === 'aria') {
      node.setAttribute('aria-label', value);
      node.setAttribute('title', value);
    } else node.textContent = value;
  }
}
function press(id, on) {
  const n = document.getElementById(id);
  if (n) n.setAttribute('aria-pressed', on ? 'true' : 'false');
}
function syncToggles() {
  press('btn-pin', state.pinned);
  press('btn-stealth', state.stealth);
  const silentBtn = document.getElementById('btn-silent');
  if (silentBtn) {
    silentBtn.setAttribute('aria-checked', state.silentMemory ? 'true' : 'false');
  }
  const effortBtn = document.getElementById('btn-effort');
  if (effortBtn) {
    const deep = state.effort === 'deep';
    effortBtn.setAttribute('aria-pressed', deep ? 'true' : 'false');
    effortBtn.setAttribute('data-chrome', '');
    effortBtn.setAttribute('data-k', deep ? 'effort_deep' : 'effort_quick');
    effortBtn.textContent = tKey(deep ? 'effort_deep' : 'effort_quick');
  }
  press('ui-zh', state.uiLang !== 'en');
  press('ui-en', state.uiLang === 'en');
  press('theme-auto', state.theme === 'auto');
  press('theme-light', state.theme === 'light');
  press('theme-dark', state.theme === 'dark');
  press('tongue-auto', state.tongue === 'auto');
  press('tongue-zh', state.tongue === 'zh');
  press('tongue-en', state.tongue === 'en');
  press('channel-stable', state.channel !== 'candidate');
  press('channel-candidate', state.channel === 'candidate');
  const app = document.getElementById('lite-app');
  if (app) {
    app.classList.toggle('is-pinned', !!state.pinned);
    app.classList.toggle('is-native', window.liveMateNativeWindow === true);
  }
  const badge = document.getElementById('settings-badge');
  if (badge) {
    badge.hidden = !(state.pinned || state.stealth);
    badge.setAttribute('aria-hidden', 'true');
  }
}
function renderTitle() {
  const node = document.getElementById('session-title');
  const s = state.session || {};
  const title = s.topicTitle || s.title || '';
  if (title) {
    node.textContent = title;
    node.removeAttribute('data-chrome');
    node.removeAttribute('data-k');
  } else {
    node.setAttribute('data-chrome', '');
    node.setAttribute('data-k', 'choose_session');
    node.textContent = tKey('choose_session');
  }
}
function renderRec() {
  const p = phase();
  const status = document.getElementById('rec-status');
  const key = 'st_' + p;
  status.textContent = tKey(key);
  status.setAttribute('data-chrome', '');
  status.setAttribute('data-k', key);
  document.getElementById('rec-timer').textContent = fmtClock(shownClock());
  document.getElementById('rec-meter').style.width = levelPct(state.native.audioLevel) + '%';
  const level = p === 'listening' ? Math.min(1, 2 * Math.sqrt(levelPct(state.native.audioLevel) / 100)) : 0;
  document.querySelectorAll('#rec-wave i').forEach((bar, i) => { bar.style.transform = 'scaleY(' + ((3 + level * 15 * [.3,.55,.8,.6,1,.7,.9,.5,.75,.45,.3][i]) / 18) + ')'; });
  const sourceName = state.native.inputName || state.native.deviceName || '';
  document.getElementById('rec-source-name').textContent = sourceName;
  const sourceRow = document.getElementById('rec-source-row');
  if (sourceRow) sourceRow.hidden = !(state.native.inputName || state.native.deviceName);
  const pill = document.getElementById('rec-pill');
  pill.className = 'rec-capsule rec-pill is-' + p;
  const active = p === 'listening' || p === 'paused' || p === 'connecting';
  pill.hidden = !active;
  const endedMeeting = !active && !!currentId() && (p === 'ended' || !!state.session?.end);
  const endedBadge = document.getElementById('rec-ended-badge');
  if (endedBadge) endedBadge.hidden = !endedMeeting;
  document.getElementById('btn-start').hidden = active || endedMeeting;
  document.getElementById('btn-continue-meeting').hidden = !endedMeeting;
  document.getElementById('btn-new-meeting').hidden = !endedMeeting;
  document.getElementById('btn-pause').hidden = !(p === 'listening' || p === 'connecting');
  document.getElementById('btn-resume').hidden = p !== 'paused';
  const stopBtn = document.getElementById('btn-stop');
  stopBtn.hidden = !active;
  // #84 P0：接入中（connecting）也要能点「取消」，只在命令 / 安装进行中才禁用。
  stopBtn.disabled = state.commandPending || state.installPending;
  const stopLabel = p === 'connecting' ? (uiLang() === 'en' ? 'Cancel connecting' : '取消接入') : (uiLang() === 'en' ? 'Stop' : '停止');
  stopBtn.title = stopLabel;
  stopBtn.setAttribute('aria-label', stopLabel);
  const miniBtn = document.getElementById('btn-mini');
  if (miniBtn) miniBtn.hidden = !active;
  for (const id of ['btn-start', 'btn-continue-meeting', 'btn-new-meeting', 'btn-pause', 'btn-resume']) document.getElementById(id).disabled = state.startPending || state.commandPending || state.installPending;
  const micSource = document.getElementById('btn-mic-source');
  if (micSource) {
    micSource.hidden = !active;
    micSource.disabled = state.startPending || state.commandPending || state.installPending || state.micSwitching;
  }
  const micIdle = document.getElementById('btn-mic-idle');
  if (micIdle) {
    micIdle.hidden = active || endedMeeting;
    micIdle.disabled = state.startPending || state.commandPending || state.installPending || state.micSwitching;
  }
  if (state.micOpen) renderMicMenu();
  const live = document.getElementById('session-live');
  live.hidden = !(active && viewingLive());
  live.setAttribute('aria-hidden', 'true');
}
function discussionView() {
  const d = (state.session && state.session.nativeInsights && state.session.nativeInsights.discussion) || (state.cards && state.cards.discussion) || (state.native.cards && state.native.cards.discussion) || null;
  if (d && typeof d === 'object') {
    const title = d.title || '';
    const text = typeof d.text === 'string' ? d.text : '';
    let bullets = [];
    if (Array.isArray(d.bullets)) bullets = d.bullets.map(x => typeof x === 'string' ? x : ((x && (x.text || x.title)) || '')).filter(Boolean);
    else if (Array.isArray(d.chapters)) bullets = d.chapters.map(c => (c && (c.text || c.title)) || '').filter(Boolean);
    const status = typeof d.status === 'string' ? d.status : '';
    if (title || text || bullets.length || status) return { title, text, bullets, status };
  }
  const highs = (state.session && state.session.highlights) || [];
  if (state.viewId && !viewingLive() && highs.length) {
    const last = highs[highs.length - 1];
    const text = last.text || last.body || '';
    const title = last.title || '';
    if (title || text) return { title, text, bullets: [], status: '' };
  }
  return null;
}
function happeningPlain() {
  const view = discussionView();
  if (!view) return '';
  return [view.title, view.text].concat(view.bullets || []).filter(Boolean).join('\n');
}
function renderAnchor() {
  const view = discussionView();
  const box = document.getElementById('context-anchor');
  box.hidden = !view;
  const titleEl = document.getElementById('anchor-title');
  const textEl = document.getElementById('anchor-text');
  const statusEl = document.getElementById('anchor-status');
  const ul = document.getElementById('anchor-bullets');
  let feed = document.getElementById('anchor-timeline');
  if (!feed && box) {
    feed = el('div');
    feed.id = 'anchor-timeline';
    box.append(feed);
  }
  if (feed) feed.replaceChildren();
  if (!view) return;
  titleEl.textContent = view.title || '';
  textEl.textContent = view.text || '';
  statusEl.textContent = view.status || '';
  ul.replaceChildren();
  const entries = [];
  for (const item of view.bullets || []) {
    if (item && !entries.includes(item)) entries.push(item);
  }
  if (view.text && !entries.includes(view.text)) entries.push(view.text);
  for (const item of entries) {
    const row = el('article');
    row.className = 'feed-entry is-happening';
    const icon = el('span');
    icon.className = 'ic';
    icon.setAttribute('aria-hidden', 'true');
    icon.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="8" cy="8" r="3.2"/></svg>';
    const lab = el('div');
    lab.className = 'lab';
    const curPhase = phase();
    const isEndedRecap = curPhase === 'ended' || (!(['listening', 'paused', 'connecting'].includes(curPhase)) && !!state.session?.end);
    const labelText = window.ThtProactiveContract
      ? window.ThtProactiveContract.meetingTimelineLabel({ ended: isEndedRecap, paused: curPhase === 'paused', isLatest: true, en: state.uiLang === 'en' })
      : (isEndedRecap ? t('final_recap') : curPhase === 'paused' ? t('st_paused') : t('happening'));
    lab.append(el('span', labelText));
    const body = el('div');
    body.className = 'fdx';
    body.append(el('p', item));
    row.append(icon, lab, body);
    if (feed) feed.append(row);
  }
}
function researchRunning(item) {
  return ['running', 'queued', 'refining'].includes(presentation(item)?.status || (item && item.state));
}
function presentation(item) {
  const helper = window.ThtLiveResearch && window.ThtLiveResearch.researchPresentation;
  return typeof helper === 'function' ? helper(item) : null;
}
function researchStatus(item) {
  const p = presentation(item);
  const status = p ? p.status : item && item.state;
  if (status === 'queued') return tKey('status_queued');
  if (status === 'running' || status === 'refining') return tKey(item.deepStarted ? 'status_deep' : 'status_quick');
  return tKey({ completed: 'status_done', stopped: 'status_stopped', failed: 'status_failed', planned: 'status_planned' }[status] || 'status_planned');
}
function chromeSpan(key) {
  const s = el('span', tKey(key));
  s.setAttribute('data-chrome', '');
  return s;
}
function renderMarkdown(host, text) {
  if (window.ThtSafeMarkdown && typeof window.ThtSafeMarkdown.markdown === 'function') host.innerHTML = window.ThtSafeMarkdown.markdown(String(text || ''));
  else host.textContent = String(text || '');
}
function renderOutputs() {
  const host = document.getElementById('output-list'); host.replaceChildren();
  for (const item of state.research || []) {
    if (!presentation(item)?.hasReport) continue;
    const article = el('article'); article.className = 'card lite-out-card';
    const head = el('div'); head.className = 'lite-out-head';
    const verdict = item.fastCard && item.fastCard.verdict ? item.fastCard.verdict : researchStatus(item);
    const badge = el('span', verdict); badge.className = 'lite-out-badge';
    const openBtn = actionButton('act_open', { 'data-open-report': item.id || '', class: 'lite-out-open' });
    head.append(badge, openBtn);
    const title = el('h3', item.title || ''); title.className = 'lite-out-title';
    const body = el('div'); body.className = 'lite-out-body';
    const summaryText = (item.fastCard && (item.fastCard.delta || item.fastCard.conclusion)) || item.conclusion || (item.subs || []).map(s => s.section?.answer || '').filter(Boolean).join('\n\n');
    renderMarkdown(body, summaryText);
    article.append(head, title, body); host.append(article);
  }
}
function renderChat() {
  const host = document.getElementById('ordinary-chat'); host.replaceChildren();
  const strip = document.getElementById('conversation-strip');
  const head = document.getElementById('conversation-head');
  const toggleBtn = document.getElementById('toggle-conversation');
  const jobs = state.jobs.filter(j => !j.candidateId && (j.contextId || j.meetingId) === currentId());
  const last = jobs[jobs.length - 1];
  const running = !!(last && !last.reply && !last.answer && !last.output && !last.message && !last.error && last.state !== 'completed' && last.state !== 'failed');
  if (head) head.hidden = !jobs.length || state.chatFolded;
  if (toggleBtn) {
    toggleBtn.setAttribute('aria-expanded', String(!state.chatFolded));
    toggleBtn.innerHTML = state.chatFolded
      ? '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="m4 10 4-4 4 4"/></svg>'
      : '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg>';
  }
  host.hidden = !jobs.length || state.chatFolded;
  if (strip) {
    strip.hidden = !jobs.length || !state.chatFolded;
    strip.replaceChildren();
    if (!strip.hidden) {
      strip.setAttribute('data-state', running ? 'running' : 'done');
      const dot = el('span', running ? '' : '✓');
      dot.className = running ? 'conv-orbit' : 'conv-done-mark';
      const label = el('span', running
        ? (state.uiLang === 'en' ? 'AI thinking… · Click to expand' : 'AI 正在处理… · 点击展开')
        : (state.uiLang === 'en' ? ('Conversation (' + jobs.length + ') · Click to expand') : ('对话 · ' + jobs.length + ' 条 · 点击展开')));
      label.className = 'conv-strip-label';
      const chev = el('span');
      chev.className = 'conv-strip-chev';
      chev.innerHTML = '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="m4 10 4-4 4 4"/></svg>';
      strip.append(dot, label, chev);
    }
  }
  for (const job of jobs) {
    const row = el('article'); row.className = 'ordinary-message'; row.append(el('p', job.comment || ''));
    const body = el('div');
    const result = job.reply || (typeof job.result === 'string' ? job.result : job.result?.answer || job.result?.text || job.answer || job.output || job.message || '');
    renderMarkdown(body, typeof result === 'string' ? result : ''); row.append(body);
    if (job.error) row.append(el('p', job.error));
    host.append(row);
  }
}
async function refreshJobs(id) {
  if (!id) return;
  const sequence = ++state.jobsSequence, sessionSequence = state.sessionSequence;
  const data = await get('/workspace-assistant?contextId=' + encodeURIComponent(id));
  if (sequence !== state.jobsSequence || sessionSequence !== state.sessionSequence || currentId() !== id || state.pageHidden || data.ok === false || !Array.isArray(data.jobs)) return;
  state.jobs = data.jobs.filter(j => (j.contextId || j.meetingId) === id); renderChat();
}
const MEETING_VIEW_KEY = 'citeside-meeting-view-v1';
function captureMeetingViewState() {
  const id = currentId(); if (!id) return null;
  try {
    const prior = JSON.parse(sessionStorage.getItem(MEETING_VIEW_KEY) || 'null');
    const record = Object.assign({}, prior?.version === 1 && prior.sessionId === id ? prior : {}, { version: 1, sessionId: id, draft: document.getElementById('lite-ask-input').value, chatFolded: state.chatFolded, expandedIds: state.expandedIds });
    sessionStorage.setItem(MEETING_VIEW_KEY, JSON.stringify(record));
    const saved = JSON.parse(sessionStorage.getItem('tht-agent-composer') || '{}');
    const contexts = Object.assign({}, saved.version === 2 ? saved.contexts : {});
    contexts[id] = Object.assign({}, contexts[id] || {}, { text: record.draft });
    sessionStorage.setItem('tht-agent-composer', JSON.stringify(Object.assign({}, saved, { version: 2, contexts })));
    return record;
  } catch (e) { return null; }
}
function restoreMeetingViewState(id) {
  state.tab = 'proactive'; state.chatFolded = false; state.expandedIds = [];
  try {
    const saved = JSON.parse(sessionStorage.getItem(MEETING_VIEW_KEY) || 'null');
    const composer = JSON.parse(sessionStorage.getItem('tht-agent-composer') || '{}');
    const matched = saved?.version === 1 && saved.sessionId === id;
    const draft = matched && typeof saved.draft === 'string' ? saved.draft : composer.version === 2 ? composer.contexts?.[id]?.text : '';
    document.getElementById('lite-ask-input').value = draft || '';
    if (matched) { state.chatFolded = !!saved.chatFolded; state.expandedIds = Array.isArray(saved.expandedIds) ? saved.expandedIds : []; }
  } catch (e) {}
  selectTab('proactive');
}

const SEMANTIC_BADGE_MAP = {
  fact_check: ['事实核查', 'Fact Check', '事実確認'],
  blind_spot: ['关键盲区', 'Blind Spot', '重要な盲点'],
  external_case: ['外部案例', 'External Case', '外部事例'],
  memory_conflict: ['历史踩坑', 'Past Pitfall', '過去の教訓'],
  external: ['事实核查', 'Fact Check', '事実確認'],
  best_practice: ['方案对比', 'Trade-off', '案の比較'],
  gap: ['逻辑缺口', 'Logic Gap', '論理の抜け']
};
function semanticBadgeInfo(item) {
  const lang = state.uiLang || document.documentElement?.lang || 'zh';
  if (window.ThtProactiveContract && typeof window.ThtProactiveContract.semanticBadgeOf === 'function') {
    return window.ThtProactiveContract.semanticBadgeOf(item, lang);
  }
  const b = item && item.semanticBadge;
  const isObj = !!(b && typeof b === 'object');
  const kind = (isObj && b.kind) || (item && item.cardKind) || '';
  if (!kind || !SEMANTIC_BADGE_MAP[kind]) return null;
  const pair = SEMANTIC_BADGE_MAP[kind];
  const l = String(lang).toLowerCase();
  const label = l.startsWith('en') ? ((isObj && b.labelEn) || pair[1]) : l.startsWith('ja') ? ((isObj && b.labelJa) || pair[2]) : ((isObj && b.labelZh) || pair[0]);
  return { kind, label };
}
function renderCheckingStatus() {
  const pill = document.getElementById('proactive-checking');
  const txt = document.getElementById('proactive-checking-text');
  if (!pill || !txt) return;
  const st = state.expertStatus;
  if (st && st.state === 'checking') {
    const isTradeoff = st.kind === 'best_practice';
    const rawTopic = String(st.topic || st.query || st.claim || st.label || '').replace(/\s+/g, ' ').trim();
    const shortTopic = rawTopic.length > 16 ? rawTopic.slice(0, 16) + '…' : rawTopic;
    txt.textContent = state.uiLang === 'en'
      ? (shortTopic ? (isTradeoff ? 'Comparing: ' + shortTopic : 'Verifying: ' + shortTopic) : (isTradeoff ? 'Comparing industry approaches…' : 'Verifying external source…'))
      : (shortTopic ? (isTradeoff ? '正在对比「' + shortTopic + '」…' : '正在核实「' + shortTopic + '」…') : (isTradeoff ? '正在对比行业方案…' : '正在核实外部资料…'));
    pill.hidden = false;
  } else {
    pill.hidden = true;
    txt.textContent = '';
  }
}
function renderProactiveBadge(totalCount) {
  const badge = document.getElementById('tab-proactive-badge');
  if (state.tab === 'proactive') {
    state.seenProactiveCount = totalCount;
    state.unreadProactiveCount = 0;
  } else if (totalCount > state.seenProactiveCount) {
    state.unreadProactiveCount += (totalCount - state.seenProactiveCount);
    state.seenProactiveCount = totalCount;
  } else if (totalCount < state.seenProactiveCount) {
    state.seenProactiveCount = totalCount;
    state.unreadProactiveCount = 0;
  }
  if (!badge) return;
  if (state.unreadProactiveCount > 0) {
    badge.textContent = state.unreadProactiveCount > 9 ? '9+' : String(state.unreadProactiveCount);
    badge.hidden = false;
  } else {
    badge.textContent = '';
    badge.hidden = true;
  }
}

let litePostTimer = 0, litePostSid = '', litePostStatus = '', litePostMd = '', litePostSnapshots = [];
function shareMeetingCloud24h(sid, statusEl, btn) {
  const en = state.uiLang === 'en';
  if (!sid || !statusEl) return Promise.resolve();
  if (btn) btn.disabled = true;
  statusEl.hidden = false;
  statusEl.textContent = en ? 'Creating 24h cloud link…' : '正在生成 24h 云链接…';
  return post('/asr-relay/live-research', { id: sid, action: 'share', cloud: true, keys: ['minutes'], hours: 24, parts: { minutes: true, todos: true } }).then(res => {
    if (btn) btn.disabled = false;
    if (!res || res.ok === false || !res.url) { statusEl.textContent = (res && res.error) || (en ? 'Share failed. Try again.' : '分享失败，请重试。'); return; }
    let link;
    try { link = new URL(res.url, location.origin).href; } catch (e) { link = String(res.url); }
    try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(link); } catch (e) {}
    const tokenPath = '/s/' + String(res.token || '');
    const expires = Number(res.expiresAt) ? new Date(Number(res.expiresAt)).toLocaleString() : '';
    statusEl.textContent = '';
    statusEl.append(
      document.createTextNode(en ? '✓ Link copied · ' : '✓ 已复制 24h 云链接 · '),
      Object.assign(el('a', tokenPath), { href: link, target: '_blank', rel: 'noopener noreferrer' }),
      document.createTextNode(expires ? (en ? ' · Expires ' : ' · 有效期至 ') + expires : '')
    );
  }).catch(err => {
    if (btn) btn.disabled = false;
    statusEl.textContent = (err && err.message) || (en ? 'Share failed. Try again.' : '分享失败，请重试。');
  });
}
function pollLitePostSummary(sid) {
  if (!sid || sid !== currentId() || !state.session || !state.session.end || viewingLive()) { clearTimeout(litePostTimer); litePostTimer = 0; return; }
  get('/asr-relay/post-meeting-state?id=' + encodeURIComponent(sid)).then(data => {
    if (sid !== currentId() || !state.session || !state.session.end) return;
    const st = (data && data.progress && data.progress.summary && data.progress.summary.status) || (data && data.state && data.state.progress && data.state.progress.summary && data.state.progress.summary.status) || '';
    const md = String(data?.summary?.markdown || data?.state?.summary?.markdown || '');
    const snaps = Array.isArray(data?.metadata?.snapshots) ? data.metadata.snapshots : (Array.isArray(data?.state?.metadata?.snapshots) ? data.state.metadata.snapshots : []);
    const next = (st === 'pending' || st === 'running') ? 'running' : (st === 'done' || st === 'skipped' || st === 'failed') ? st : '';
    const mdChanged = md !== litePostMd;
    const snapKey = JSON.stringify(snaps.map(s => s && s.name));
    const snapChanged = snapKey !== JSON.stringify(litePostSnapshots.map(s => s && s.name));
    if (mdChanged) litePostMd = md;
    if (snapChanged) litePostSnapshots = snaps;
    if (next && (next !== litePostStatus || mdChanged || snapChanged)) { litePostStatus = next; renderProactive(); }
    if (next === 'running') { clearTimeout(litePostTimer); litePostTimer = setTimeout(() => pollLitePostSummary(sid), 3000); }
  }).catch(() => {
    const endTs = typeof state.session?.end === 'number' ? state.session.end : Date.parse(state.session?.end || '');
    if (Number.isFinite(endTs) && Date.now() - endTs < 20000 && sid === currentId()) {
      if (litePostStatus !== 'running') { litePostStatus = 'running'; renderProactive(); }
      clearTimeout(litePostTimer); litePostTimer = setTimeout(() => pollLitePostSummary(sid), 3000);
    }
  });
}
function postMeetingEndCard() {
  if (!state.session || !state.session.end || viewingLive()) {
    if (litePostSid) { clearTimeout(litePostTimer); litePostTimer = 0; litePostSid = ''; litePostStatus = ''; litePostSnapshots = []; }
    return null;
  }
  const sid = currentId();
  if (sid && litePostSid !== sid) {
    litePostSid = sid;
    litePostMd = '';
    litePostSnapshots = [];
    const endTs = typeof state.session.end === 'number' ? state.session.end : Date.parse(state.session.end || '');
    litePostStatus = (Number.isFinite(endTs) && Date.now() - endTs < 20000) ? 'running' : '';
    pollLitePostSummary(sid);
  }
  if (!litePostStatus) return null;
  const en = state.uiLang === 'en';
  const card = discoveryRow();
  card.classList.add('post-summary-end');
  const top = el('div');
  top.className = 'lab';
  const tag = el('span', en ? 'Meeting ended' : '会议已结束');
  tag.className = 'tag';
  top.append(tag);
  const body = el('div');
  body.className = 'fdx';
  const actions = el('div');
  actions.className = 'card-actions';
  const extras = [];
  if (litePostStatus === 'running') {
    body.textContent = en ? '✦ Auto-generating meeting summary…' : '✦ 正在自动整理会议纪要…';
  } else if (litePostStatus === 'done') {
    body.textContent = en ? '✓ Meeting summary ready' : '✓ 会议纪要已整理完成';
    const fullMd = String(litePostMd || (state.session && state.session.summary && state.session.summary.markdown) || '');
    const inlineBody = el('div');
    inlineBody.className = 'mw-main-post-body';
    if (fullMd) {
      if (window.ThtSafeMarkdown && typeof window.ThtSafeMarkdown.markdown === 'function') inlineBody.innerHTML = window.ThtSafeMarkdown.markdown(fullMd);
      else { inlineBody.textContent = fullMd; inlineBody.style.whiteSpace = 'pre-wrap'; }
    } else {
      inlineBody.textContent = en ? 'The full minutes appear here once ready.' : '完整纪要整理完成后会直接呈现在这里。';
    }
    const inlineActs = el('div');
    inlineActs.className = 'mw-main-post-acts';
    const copyBtn = el('button', en ? 'Copy' : '复制');
    copyBtn.type = 'button';
    copyBtn.onclick = () => {
      try {
        (navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(fullMd) : Promise.reject()).then(() => {
          copyBtn.textContent = en ? '✓ Copied' : '✓ 已复制';
          setTimeout(() => { copyBtn.textContent = en ? 'Copy' : '复制'; }, 1600);
        }).catch(() => {});
      } catch (e) {}
    };
    const shareBtn = el('button', en ? 'Share 24h link' : '分享 24h 云链接');
    shareBtn.type = 'button';
    shareBtn.className = 'mw-main-post-share-btn';
    const shareResult = el('div');
    shareResult.className = 'mw-main-post-share-result';
    shareResult.hidden = true;
    shareBtn.onclick = () => { void shareMeetingCloud24h(sid, shareResult, shareBtn); };
    const collapseBtn = el('button', en ? 'Collapse' : '收起');
    collapseBtn.type = 'button';
    collapseBtn.onclick = () => {
      const collapsed = inlineBody.hidden = !inlineBody.hidden;
      collapseBtn.textContent = collapsed ? (en ? 'Expand' : '展开') : (en ? 'Collapse' : '收起');
    };
    const openBtn = el('button', en ? 'View in full window ›' : '查看完整纪要 ›');
    openBtn.type = 'button';
    openBtn.className = 'act';
    openBtn.onclick = () => { const f = document.getElementById('btn-full'); if (f) f.click(); };
    inlineActs.append(copyBtn, shareBtn, collapseBtn, openBtn);
    const validSnaps = (litePostSnapshots || []).filter(s => s && s.name);
    if (validSnaps.length) {
      const strip = el('div');
      strip.className = 'lite-snap-strip';
      const head = el('div', en ? `Shared Screen Snapshots · ${validSnaps.length}` : `共享屏幕截图 · ${validSnaps.length} 张`);
      head.className = 'lite-snap-head';
      const row = el('div');
      row.className = 'lite-snap-row';
      const tokVal = (typeof token === 'function' && token()) || (typeof window !== 'undefined' && window.THT_BOOT && window.THT_BOOT.relayToken) || '';
      const tokParam = tokVal ? '&token=' + encodeURIComponent(tokVal) : '';
      const snapSrc = s => '/assets?id=' + encodeURIComponent(sid) + '&name=' + encodeURIComponent(s.name) + tokParam;
      const snapClock = s => {
        if (!s.capturedAt) return '';
        const d = new Date(s.capturedAt);
        return Number.isNaN(d.getTime()) ? '' : String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      };
      const openLiteLightbox = startIdx => {
        let idx = Math.max(0, Math.min(validSnaps.length - 1, startIdx));
        const prevLb = document.querySelector('.lite-snap-lightbox');
        if (prevLb) { if (typeof prevLb._liteCleanup === 'function') prevLb._liteCleanup(); else prevLb.remove(); }
        const lb = el('div'); lb.className = 'lite-snap-lightbox'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true');
        const box = el('div'); box.className = 'lite-snap-lb-box';
        const img = document.createElement('img'); img.className = 'lite-snap-lb-img';
        const bar = el('div'); bar.className = 'lite-snap-lb-bar';
        const meta = el('span');
        const closeBtn = el('button', '×'); closeBtn.type = 'button'; closeBtn.setAttribute('aria-label', en ? 'Close' : '关闭');
        const renderLb = () => {
          const cur = validSnaps[idx];
          img.src = snapSrc(cur);
          const t = snapClock(cur);
          meta.textContent = validSnaps.length > 1 ? `${idx + 1} / ${validSnaps.length}${t ? ' · ' + t : ''}` : t;
        };
        const cleanup = () => { document.removeEventListener('keydown', onKey); lb.remove(); };
        lb._liteCleanup = cleanup;
        const onKey = ev => { if (ev.key === 'Escape') cleanup(); else if (ev.key === 'ArrowLeft' && idx > 0) { idx--; renderLb(); } else if (ev.key === 'ArrowRight' && idx < validSnaps.length - 1) { idx++; renderLb(); } };
        closeBtn.onclick = cleanup;
        lb.onclick = ev => { if (ev.target === lb) cleanup(); };
        bar.append(meta, closeBtn); box.append(img, bar); lb.append(box);
        document.body.append(lb); document.addEventListener('keydown', onKey); renderLb();
      };
      validSnaps.forEach((s, idx) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'lite-snap-thumb';
        const img = document.createElement('img');
        img.src = snapSrc(s);
        img.loading = 'lazy';
        const t = snapClock(s);
        img.alt = t || s.name;
        b.append(img);
        if (t) { const ts = el('span', t); ts.className = 'lite-snap-time'; b.append(ts); }
        b.onclick = () => openLiteLightbox(idx);
        row.append(b);
      });
      strip.append(head, row);
      extras.push(inlineBody, strip, inlineActs, shareResult);
    } else {
      extras.push(inlineBody, inlineActs, shareResult);
    }
  } else {
    body.textContent = litePostStatus === 'skipped'
      ? (en ? 'Short recording — auto-summary skipped.' : '转写较短，未自动整理会议纪要。')
      : (en ? 'Meeting summary did not finish.' : '会议纪要整理未完成。');
    const retryBtn = el('button', litePostStatus === 'skipped' ? (en ? 'Generate summary' : '立即整理纪要') : (en ? 'Retry summary' : '重试整理'));
    retryBtn.type = 'button';
    retryBtn.className = 'act';
    retryBtn.onclick = () => {
      const wasSkipped = litePostStatus === 'skipped';
      litePostStatus = 'running'; renderProactive();
      const bodyPayload = wasSkipped ? { op: 'start', force: true } : { op: 'retry', block: 'summary' };
      post('/asr-relay/native/postmeeting?id=' + encodeURIComponent(sid), bodyPayload).catch(() => {});
      post('/meeting-retry', { id: sid }).catch(() => {});
      clearTimeout(litePostTimer); litePostTimer = setTimeout(() => pollLitePostSummary(sid), 2500);
    };
    actions.append(retryBtn);
  }
  card.append(top, body);
  for (const node of extras) card.append(node);
  if (actions.childNodes.length) card.append(actions);
  return card;
}
function renderProactive() {
  renderAnchor();
  renderCheckingStatus();
  const host = document.getElementById('proactive-stream');
  const empty = document.getElementById('stream-empty');
  host.replaceChildren();
  state.contextTexts = [];
  const research = (state.research || []).filter(item => presentation(item)?.visible);
  const cites = citationCards();
  const endCard = postMeetingEndCard();
  const total = research.length + cites.length;
  renderProactiveBadge(total);
  empty.hidden = total > 0 || !!endCard || !!discussionView() || (state.expertStatus && state.expertStatus.state === 'checking');
  for (const item of research) host.append(researchCard(item));
  for (const card of cites) host.append(citeCard(card));
  if (endCard) host.append(endCard);
  renderOutputs();
}
// Same transparent discovery row and spark marker as the approved meeting feed.
function discoveryRow() {
  const card = el('article');
  card.className = 'feed-entry it fd k-fd';
  const icon = el('span');
  icon.className = 'ic';
  icon.setAttribute('aria-hidden', 'true');
  icon.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5Z"/></svg>';
  card.append(icon);
  return card;
}
const openSourceDrawers = new Set();
function sourceDrawerKey(item) {
  return String((item && (item.id || item.title || item.text || item.body)) || '').replace(/\s+/g, ' ').trim().slice(0, 80);
}
function buildSourcesDrawer(item, sourceList, actions) {
  const drawerKey = sourceDrawerKey(item);
  const isOpen = !!drawerKey && openSourceDrawers.has(drawerKey);
  const links = el('div');
  links.className = 'src-list sources-drawer';
  links.hidden = !isOpen;
  const cred = item && item.credibility;
  if (cred && cred.level) {
    const cr = el('div');
    cr.className = 'cred-row';
    const badge = el('span', cred.level === 'verified' || cred.level === '证实' ? (state.uiLang === 'en' ? 'Verified' : '可信度：证实') : String(cred.level));
    badge.className = 'cred-pill';
    cr.append(badge);
    if (cred.note) cr.append(el('span', String(cred.note)));
    links.append(cr);
  }
  const seen = new Set();
  let count = 0;
  for (const src of sourceList || []) {
    const href = safeUrl(src && src.url);
    if (!href || seen.has(href)) continue;
    seen.add(href);
    let host = '';
    try { host = new URL(href).hostname.replace(/^www\./, ''); } catch (e) {}
    const row = el('div');
    row.className = 'src-item';
    const a = el('a', ((src && (src.title || src.name)) || host || href) + ' ↗');
    a.setAttribute('href', href);
    a.setAttribute('rel', 'noopener noreferrer');
    a.setAttribute('target', '_blank');
    row.append(a);
    if (host) {
      const dom = el('span', host);
      dom.className = 'src-host';
      row.append(dom);
    }
    if (src && src.quote) {
      const q = el('p', '「' + String(src.quote).slice(0, 200) + '」');
      q.className = 'src-quote';
      row.append(q);
    }
    links.append(row);
    count++;
  }
  if (count > 0 && actions) {
    const toggle = el('button', '');
    toggle.setAttribute('type', 'button');
    toggle.setAttribute('data-toggle-sources', '1');
    if (drawerKey) toggle.setAttribute('data-source-key', drawerKey);
    toggle.setAttribute('aria-expanded', String(isOpen));
    toggle.className = 'src-chip';
    const dot = el('span', '');
    dot.className = 'src-dot';
    const lbl = el('span', state.uiLang === 'en' ? (count + ' sources ▾') : (count + ' 个来源 ▾'));
    toggle.append(dot, lbl);
    actions.append(toggle);
  }
  return { links, count };
}
function researchCard(item) {
  const view = presentation(item);
  if (!view?.visible) return null;
  const card = discoveryRow();
  const top = el('div');
  top.className = 'lab';
  const badge = el('span', researchStatus(item));
  badge.className = 'tag';
  top.append(badge);
  const body = el('div');
  body.className = 'fdx';
  // Pending work still needs its topic; an answer replaces that title.
  renderMarkdown(body, view.answer || item.title || '');
  const actions = el('div');
  actions.className = 'card-actions';
  const srcBuilt = buildSourcesDrawer(item, view && view.sources, actions);
  if (researchRunning(item)) actions.append(actionButton('act_stop', { 'data-stop': item.id || '' }));
  if (!item.deepStarted) actions.append(actionButton('act_deep', { 'data-deep': item.id || '' }));
  if (view && view.hasReport) actions.append(actionButton('act_open', { 'data-open-report': item.id || '' }));
  card.append(top, body, srcBuilt.links, actions);
  return card;
}
function actionButton(key, attrs) {
  const b = el('button', tKey(key));
  b.setAttribute('type', 'button');
  b.setAttribute('data-chrome', '');
  for (const name of Object.keys(attrs)) b.setAttribute(name, attrs[name]);
  return b;
}
function citationCards() {
  const out = [];
  const seen = new Map();
  const cards = (state.session && state.session.nativeInsights) || state.cards || {};
  const stripAiPrefix = s => String(s || '').replace(/^(?:AI\s*解读|AI\s*interpretation)[：:]\s*/i, '').trim();
  const pushUnique = item => {
    const rawBody = String(cardText(item) || '').replace(/\s+/g, ' ').trim();
    const body = stripAiPrefix(rawBody);
    const title = stripAiPrefix(String(item.title || '').replace(/\s+/g, ' ').trim());
    if (!body && !title) return;
    const norm = body || title;
    const dedupKey = (item.id && String(item.id).trim()) ? ('id:' + String(item.id).trim()) : ('txt:' + norm);
    const txtKey = 'txt:' + norm;
    const existing = seen.get(dedupKey) || seen.get(txtKey);
    if (existing) {
      if (/^(?:AI\s*解读|AI\s*interpretation)[：:]/i.test(String(existing.text || existing.body || '').trim()) && !/^(?:AI\s*解读|AI\s*interpretation)[：:]/i.test(rawBody)) {
        existing.text = body; existing.body = body;
      }
      if ((!existing.sources || !existing.sources.length) && item.sources && item.sources.length) existing.sources = item.sources;
      if (!existing.semanticBadge && item.semanticBadge) existing.semanticBadge = item.semanticBadge;
      if (!existing.sourceLabel && item.sourceLabel) existing.sourceLabel = item.sourceLabel;
      return;
    }
    const copy = Object.assign({}, item);
    if (copy.text && /^(?:AI\s*解读|AI\s*interpretation)[：:]/i.test(String(copy.text).trim())) copy.text = stripAiPrefix(copy.text);
    if (copy.body && /^(?:AI\s*解读|AI\s*interpretation)[：:]/i.test(String(copy.body).trim())) copy.body = stripAiPrefix(copy.body);
    out.push(copy);
    seen.set(dedupKey, copy);
    seen.set(txtKey, copy);
  };
  for (const key of ['insights', 'history']) {
    for (const item of asList(cards[key])) {
      if (window.ThtProactiveContract ? !window.ThtProactiveContract.shouldShowProactiveCard(item) : (item && item.kind === 'judgment' && !item.cardKind && !item.semanticBadge && !(item.sources && item.sources.length))) continue;
      pushUnique(Object.assign({ kind: key === 'insights' ? 'insights' : key }, item));
    }
  }
  for (const item of (state.session && state.session.factchecks) || []) {
    if (window.ThtProactiveContract && typeof window.ThtProactiveContract.shouldShowFactcheck === 'function') {
      if (!window.ThtProactiveContract.shouldShowFactcheck(item, true)) continue;
    } else {
      if (item && item.lookupState && item.lookupState !== 'ready') continue;
      if (item && item.channel === 'judgment' && !(item.verify && item.verify.sources && item.verify.sources.length)) continue;
    }
    pushUnique({ kind: 'factcheck', text: item.point || item.md || item.text || item.claim || '', verdict: item.verdict, speaker: item.speaker || item.spk, t: item.t, sources: item.verify && item.verify.sources });
  }
  return out;
}
function citeCard(item) {
  const card = discoveryRow();
  const top = el('div');
  top.className = 'lab';
  const sem = semanticBadgeInfo(item);
  const rawToneText = String(item.foot ? cardText(item).replace('\n' + item.foot, '') : cardText(item)).trim();
  const semTone = window.ThtProactiveContract && typeof window.ThtProactiveContract.semanticToneOf === 'function'
    ? window.ThtProactiveContract.semanticToneOf(sem, rawToneText)
    : (/^(?:核实一致|已核实)[：:]/.test(rawToneText) ? 'ok'
      : ((sem && (sem.kind === 'gap' || sem.kind === 'fact_check' || sem.kind === 'blind_spot')) || /^(?:纠偏[：:]|实际是)|而非会上说的/.test(rawToneText)) ? 'fix'
      : (sem && (sem.kind === 'best_practice' || sem.kind === 'external_case' || sem.kind === 'memory_conflict')) ? 'cmp' : 'add');
  card.setAttribute('data-sem-tone', semTone);
  if (sem) {
    const tag = el('span', sem.label);
    tag.className = 'tag sem-badge';
    tag.setAttribute('data-card-kind', sem.kind);
    tag.setAttribute('data-sem-tone', semTone);
    top.append(tag);
  } else {
    const kindKey = { suggestion: 'kind_suggestion', insights: 'kind_insights', history: 'kind_history', factcheck: 'kind_factcheck', highlight: 'kind_highlight' }[item.kind];
    if (kindKey) { const tag = chromeSpan(kindKey); tag.className = 'tag'; top.append(tag); }
  }
  if (item.t != null) top.append(el('span', '[' + fmtClock(item.t) + ']'));
  if (item.sourceLabel) {
    const lbl = String(item.sourceLabel)
      .replace(/(^|[·•\s])them($|[·•\s])/gi, (_, a, b) => a + speakerName('them') + b)
      .replace(/(^|[·•\s])me($|[·•\s])/gi, (_, a, b) => a + speakerName('me') + b);
    top.append(el('span', lbl));
  }
  const spk = item.speaker || item.spk || item.who || '';
  if (spk !== '' && spk != null) top.append(el('span', speakerName(spk)));
  if (item.verdict) top.append(Object.assign(el('span', String(item.verdict)), { className: 'pill' }));
  const text = item.foot ? cardText(item).replace('\n' + item.foot, '') : cardText(item);
  const body = el('div');
  body.className = 'fdx';
  renderMarkdown(body, text || item.title || '');
  const idx = String(state.contextTexts.push(text) - 1);
  window.pendingResearchCards = window.pendingResearchCards || new Set();
  const pendingResearchCards = window.pendingResearchCards;
  const actions = el('div');
  actions.className = 'card-actions';
  const srcBuilt = buildSourcesDrawer(item, asList(item.sources), actions);
  const contract = window.ThtProactiveContract;
  const showDeep = contract?.shouldShowDeepResearch
    ? contract.shouldShowDeepResearch(sem, srcBuilt.count > 0)
    : (!sem || ['blind_spot', 'external_case', 'memory_conflict', 'best_practice', 'gap'].includes(sem.kind) || srcBuilt.count === 0);
  if (showDeep) {
    const isPro = contract?.isResearchProAccount ? contract.isResearchProAccount(window.THT_BOOT || {}) : true;
    const rb = actionButton('act_research', { 'data-research': idx });
    const cardKey = currentId() + ':' + (item.id || idx);
    const lrList = Array.isArray(state.research) ? state.research : (state.research && state.research.items) || [];
    const matchedLr = (lrList || []).find(lr => lr && ((item.id && (String(lr.cardId || '') === String(item.id) || String(lr.id || '') === String(item.id))) || (lr.text && text && lr.text === text))) || null;
    let btnState = 'idle';
    if (matchedLr) {
      const st = matchedLr.state || matchedLr.status;
      if (st === 'pending' || st === 'running' || st === 'done') btnState = st;
    }
    if (btnState === 'idle' && pendingResearchCards.has(cardKey)) btnState = 'pending';
    if (btnState === 'running' || btnState === 'done') pendingResearchCards.delete(cardKey);
    rb.dataset.cardId = String(item.id || '');
    rb.dataset.itemId = (matchedLr && matchedLr.id) || '';
    rb.dataset.lrState = btnState;
    if (contract?.researchButtonLabel) rb.textContent = contract.researchButtonLabel({ langOrEn: state.uiLang || state.lang || 'zh', isPro, state: btnState === 'idle' ? 'idle' : btnState });
    const enUi = (state.uiLang || state.lang || 'zh') === 'en';
    if (btnState === 'pending' || btnState === 'running') {
      const baseText = btnState === 'pending' ? (enUi ? 'Researching…' : '深度研究中…') : (enUi ? 'Researching · Stop' : '深度研究中 · 停止');
      const cancelText = enUi ? 'Cancel research' : '取消研究';
      rb.textContent = baseText;
      rb.title = cancelText;
      rb.onmouseenter = () => { rb.textContent = cancelText; };
      rb.onmouseleave = () => { rb.textContent = baseText; };
    } else {
      rb.onmouseenter = null;
      rb.onmouseleave = null;
      rb.title = '';
    }
    if (!isPro) rb.dataset.proGate = '1';
    actions.append(rb);
  }
  const downKey = 'tht-card-down:' + (state.sessionId || '') + ':' + (item.id || idx);
  let isDown = false; try { isDown = localStorage.getItem(downKey) === '1'; } catch {}
  const td = el('button', '');
  td.type = 'button';
  td.className = 'card-act mw-thumb-down';
  td.setAttribute('aria-pressed', String(isDown));
  td.setAttribute('aria-label', state.lang === 'en' ? 'Not helpful' : '这条不太有帮助');
  td.title = state.lang === 'en' ? 'Not helpful' : '这条不太有帮助';
  td.innerHTML = '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.5 10.5V13a1.5 1.5 0 0 1-1.5 1.5l-2.2-4.7V3.5h6.1a1.5 1.5 0 0 1 1.48 1.25l.65 4a1.5 1.5 0 0 1-1.48 1.75H9.5z"/><path d="M5.8 3.5H3.5a1 1 0 0 0-1 1v4.3a1 1 0 0 0 1 1h2.3"/></svg>';
  td.onclick = () => {
    isDown = !isDown;
    td.setAttribute('aria-pressed', String(isDown));
    try { if (isDown) localStorage.setItem(downKey, '1'); else localStorage.removeItem(downKey); } catch {}
    try {
      const tok = window.THT_BOOT?.relayToken || '';
      fetch('/asr-relay/card-feedback', { method: 'POST', headers: { 'Content-Type': 'application/json', ...(tok ? { 'x-tht-token': tok } : {}) }, body: JSON.stringify({ sessionId: state.sessionId || '', cardId: item.id || '', cardKind: (sem && sem.kind) || item.cardKind || 'unknown', uiLang: String(state.lang || 'zh').slice(0, 2), title: item.title || '', text: String(text || '').slice(0, 280), action: isDown ? 'thumbs_down' : 'retract_thumbs_down' }) }).catch(() => {});
    } catch {}
  };
  actions.append(td);
  card.append(top, body, srcBuilt.links, actions);
  return card;
}
function renderLatestTranscript() {
  const rows = transcriptRows(), last = rows[rows.length - 1];
  const partial = viewingLive() && state.interim;
  const text = partial || (last && ((speakerName(last.spk ?? last.speaker) + '：') + (last.text || ''))) || '';
  document.getElementById('latest-transcript-text').textContent = text;
  document.getElementById('latest-transcript').hidden = state.tab === 'transcript' || !text;
}
function liteTranslateTarget() {
  const v = String(state.transcriptOutputLang || window.THT_BOOT?.transcriptOutputLang || 'auto');
  return ['en', 'ja', 'zh'].includes(v) ? v : 'auto';
}
function liteNeedsTranslate(t, lang) {
  if (typeof t !== 'string' || !t.trim()) return false;
  if (lang === 'en') return /[\u3040-\u30ff\u4e00-\u9fff]/.test(t);
  if (lang === 'ja') return !/[\u3040-\u30ff]/.test(t) && (/[a-zA-Z]{4}/.test(t) || /[\u4e00-\u9fff]{3}/.test(t));
  return !/[\u4e00-\u9fff]/.test(t) && (/[a-zA-Z]{4}/.test(t) || /[\u3040-\u30ff]{3}/.test(t));
}
let liteTrBusy = false, liteTrTimer = null, liteTrLangLoaded = false;
function scheduleLiteTranscriptTranslate() {
  if (!liteTrLangLoaded) {
    liteTrLangLoaded = true;
    fetch('/setup', { cache: 'no-store' }).then(r => r.ok ? r.json() : null).then(j => {
      if (j && j.transcriptOutputLang) { state.transcriptOutputLang = j.transcriptOutputLang; scheduleLiteTranscriptTranslate(); }
    }).catch(() => {});
  }
  const lang = liteTranslateTarget();
  if (lang === 'auto' || liteTrBusy || liteTrTimer) return;
  liteTrTimer = setTimeout(async () => {
    liteTrTimer = null;
    const target = liteTranslateTarget();
    if (target === 'auto' || liteTrBusy) return;
    state.transcriptTranslations = state.transcriptTranslations || {};
    state.transcriptTranslations[target] = state.transcriptTranslations[target] || {};
    const map = state.transcriptTranslations[target];
    const missing = [...new Set(transcriptRows().map(r => r.text || '').filter(t => liteNeedsTranslate(t, target) && !map[t]))].reverse().slice(0, 4);
    if (!missing.length) return;
    liteTrBusy = true;
    try {
      const tok = window.THT_BOOT?.relayToken || '';
      const r = await fetch('/hub/translate?token=' + encodeURIComponent(tok), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(tok ? { 'x-tht-token': tok } : {}) },
        body: JSON.stringify({ language: target, strings: missing })
      });
      const j = r.ok ? await r.json() : null;
      if (Array.isArray(j?.strings) && j.strings.length === missing.length) {
        missing.forEach((s, idx) => { map[s] = j.strings[idx]; });
        renderTranscript();
      }
    } catch {} finally { liteTrBusy = false; }
  }, 250);
}
function renderTranscript() {
  renderLatestTranscript();
  scheduleLiteTranscriptTranslate();
  const trLang = liteTranslateTarget();
  const trMap = trLang !== 'auto' ? (state.transcriptTranslations?.[trLang] || {}) : {};
  const box = document.getElementById('transcript-list');
  const jump = document.getElementById('btn-jump-latest');
  const near = box.scrollHeight - box.scrollTop - box.clientHeight < 48;
  const q = String(document.getElementById('tr-filter-input').value || '').trim().toLowerCase();
  const rows = [];
  for (const row of transcriptRows()) {
    const name = speakerName(row.spk != null ? row.spk : row.speaker);
    const rawText = row.text || '';
    const text = (trLang !== 'auto' && trMap[rawText]) ? trMap[rawText] : rawText;
    if (q && (name + ' ' + text).toLowerCase().indexOf(q) < 0) continue;
    const wrap = el('div');
    wrap.className = 'tr-row';
    const meta = el('div');
    meta.className = 'tr-meta';
    const tm = el('span', '[' + fmtClock(rowSeconds(row)) + ']');
    const sp = el('span', name);
    sp.className = 'tr-spk ' + spkClass(name);
    meta.append(tm, sp);
    const body = el('p', text);
    body.className = 'tr-text';
    wrap.append(meta, body);
    rows.push(wrap);
  }
  const p = phase();
  if (viewingLive() && state.interim && (p === 'listening' || p === 'paused' || p === 'connecting')) {
    const live = el('p', state.interim);
    live.className = 'interim';
    rows.push(live);
  }
  box.replaceChildren(...rows);
  if (near) {
    box.scrollTop = box.scrollHeight;
    jump.hidden = true;
  } else jump.hidden = false;
}
function renderReceipt() {
  const box = document.getElementById('memory-receipt');
  const text = document.getElementById('memory-receipt-text');
  const counts = state.memory && state.memory.counts;
  if (!state.ended || !counts) { box.hidden = true; return; }
  box.hidden = false;
  const n = counts.active != null ? counts.active : 0;
  text.textContent = state.uiLang === 'en' ? ('Smart title updated · ' + n + ' silent memories') : ('已更新智能标题 · 静默记忆 ' + n + ' 条');
  text.setAttribute('data-chrome', '');
}
function renderAccount() {
  const box = document.getElementById('account-box');
  const a = state.account || {};
  const signed = !!(a.email || (a.status && a.status !== 'signed_out' && a.plan));
  box.replaceChildren();
  if (!signed) {
    const link = el('a', tKey('sign_in'));
    link.setAttribute('href', '/seatnote/account.html');
    link.setAttribute('data-chrome', '');
    link.setAttribute('data-k', 'sign_in');
    box.append(link);
    document.getElementById('account-plan').textContent = '';
    document.getElementById('account-hours').textContent = '';
    return;
  }
  box.append(el('p', a.email || ''));
  document.getElementById('account-plan').textContent = a.plan || '';
  const used = a.aiHoursUsed != null ? a.aiHoursUsed : '';
  const limit = a.aiHoursLimit != null ? a.aiHoursLimit : '';
  document.getElementById('account-hours').textContent = used === '' && limit === '' ? '' : (used + ' / ' + limit);
}
function renderMcp() {
  const status = document.getElementById('mcp-status');
  const map = { not_connected: 'mcp_not_connected', connected: 'mcp_connected', profile_received: 'mcp_profile_received', disconnected: 'mcp_disconnected' };
  const key = map[(state.mcp && state.mcp.status) || 'not_connected'] || 'mcp_not_connected';
  status.textContent = tKey(key);
  status.setAttribute('data-chrome', '');
  status.setAttribute('data-k', key);
  const host = document.getElementById('mcp-clients');
  host.replaceChildren();
  for (const c of (state.mcp && state.mcp.clients) || []) {
    const b = el('button', c.label || c.id || '');
    b.setAttribute('type', 'button');
    b.setAttribute('data-client-id', c.id || '');
    host.append(b);
  }
}
let memoryAddPending = false, profileSavePending = false;
const profileDirty = new Map();
function fillProfile() {
  const p = (state.memory && state.memory.profile) || {};
  const map = { 'profile-name': p.name, 'profile-role': p.role, 'profile-domain': p.domain, 'profile-preferences': p.preferences, 'profile-notes': p.customNotes };
  for (const id of Object.keys(map)) {
    const node = document.getElementById(id);
    if (!node || document.activeElement === node || profileDirty.has(id)) continue;
    node.value = map[id] || '';
  }
}
function renderProjects() {
  const host = document.getElementById('mem-projects');
  if (!host) return;
  host.replaceChildren();
  const projects = ((state.memory && state.memory.projects) || []).filter(p => !p.status || p.status === 'active');
  for (const p of projects) {
    const row = el('div');
    row.className = 'mem-project';
    row.append(el('strong', p.title || p.id || ''));
    row.append(el('p', p.summary || ''));
    const count = Array.isArray(p.sourceMeetings) ? p.sourceMeetings.length : (Number(p.sourceMeetings) || 0);
    row.append(el('span', String(count)));
    const forget = el('button', tKey('forget'));
    forget.setAttribute('type', 'button');
    forget.setAttribute('data-chrome', '');
    forget.setAttribute('data-forget-project', p.id || '');
    row.append(forget);
    host.append(row);
  }
}
function chartFragments(html) {
  const parts = [];
  const re = /<svg\b[\s\S]*?<\/svg>|<div class="tw">[\s\S]*?<\/table><\/div>|<div class="lr-chart-legend">[\s\S]*?<\/div>/gi;
  let match;
  while ((match = re.exec(String(html || '')))) parts.push(match[0]);
  const useful = parts.filter(part => /<svg\b/i.test(part) || /<td\b/i.test(part));
  if (!useful.length) return '';
  const legend = parts.filter(part => /lr-chart-legend/.test(part));
  return useful.concat(useful.some(part => /<svg\b/i.test(part)) ? legend : []).join('');
}
function richReportHtml(item) {
  let html = '';
  try {
    if (window.ThtLiveResearch && typeof window.ThtLiveResearch.reportHtml === 'function') {
      html = chartFragments(window.ThtLiveResearch.reportHtml(item, { readonly: true }) || '');
    }
  } catch (e) {}
  if (html) return html;
  const md = [item.conclusion].concat((item.subs || []).map(s => s.section && s.section.answer)).filter(Boolean).join('\n\n');
  if (!/\|[^\n]+\|/.test(md)) return '';
  try {
    if (window.ThtSafeMarkdown && typeof window.ThtSafeMarkdown.markdown === 'function') return window.ThtSafeMarkdown.markdown(md) || '';
  } catch (e) {}
  return '';
}
function renderReport(item) {
  if (!item) return;
  state.reportItem = item;
  document.getElementById('report-title').textContent = item.title || '';
  const st = document.getElementById('report-status');
  st.textContent = researchStatus(item);
  st.setAttribute('data-chrome', '');
  document.getElementById('report-conclusion').textContent = item.conclusion || (item.quick && item.quick.answer) || '';
  const subs = document.getElementById('report-subs');
  subs.replaceChildren();
  for (const s of item.subs || []) {
    subs.append(el('h3', s.q || ''));
    subs.append(el('p', (s.section && s.section.answer) || ''));
  }
  document.getElementById('report-rich').innerHTML = richReportHtml(item);
  const sources = document.getElementById('report-sources');
  sources.replaceChildren();
  for (const src of presentation(item)?.sources || []) {
    const href = safeUrl(src && src.url);
    if (!href) continue;
    const li = el('li');
    const a = el('a', (src && (src.title || href)) || href);
    a.setAttribute('href', href);
    a.setAttribute('rel', 'noopener noreferrer');
    a.setAttribute('target', '_blank');
    li.append(a);
    sources.append(li);
  }
}
function renderSessionList() {
  const host = document.getElementById('session-list');
  const q = String(document.getElementById('session-search-input').value || '').trim().toLowerCase();
  host.replaceChildren();
  for (const row of state.meetings) {
    const title = row.topicTitle || row.title || row.id || '';
    if (q && String(title).toLowerCase().indexOf(q) < 0) continue;
    const b = el('button');
    b.className = 'pop-item';
    b.setAttribute('type', 'button');
    b.setAttribute('data-session-id', row.id || '');
    if (row.id && row.id === state.viewId) b.setAttribute('aria-current', 'true');
    const meta = el('span');
    const live = row.recording || (row.id && row.id === state.native.sessionId && state.native.active);
    if (live) {
      meta.textContent = tKey('live_badge');
      meta.setAttribute('data-chrome', '');
    } else {
      const date = row.start ? String(row.start).slice(0, 10) : '';
      const dur = row.durationSec != null ? fmtClock(row.durationSec) : '';
      meta.textContent = [date, dur].filter(Boolean).join(' · ');
    }
    b.append(el('strong', title), meta);
    host.append(b);
  }
}
function renderAll() {
  paintChrome();
  renderTitle();
  renderRec();
  renderProactive();
  renderTranscript();
  renderChat();
  renderReceipt();
  if (state.account) renderAccount();
  if (state.mcp) renderMcp();
  if (state.memory) {
    renderProjects();
    if (state.memory.profile) fillProfile();
  }
  if (state.reportItem) renderReport(state.reportItem);
  syncToggles();
}
function selectTab(name) {
  state.tab = ['proactive', 'transcript', 'outputs'].includes(name) ? name : 'proactive';
  for (const key of ['proactive', 'transcript', 'outputs']) {
    const on = state.tab === key, tab = document.getElementById('tab-' + key);
    tab.setAttribute('aria-selected', on ? 'true' : 'false'); tab.tabIndex = on ? 0 : -1;
    document.getElementById('panel-' + key).hidden = !on;
  }
  if (state.tab === 'proactive') {
    state.unreadProactiveCount = 0;
    const badge = document.getElementById('tab-proactive-badge');
    if (badge) { badge.textContent = ''; badge.hidden = true; }
  }
  renderLatestTranscript(); syncTopbarScroll();
}
function openDrawer(name) {
  const main = document.getElementById('lite-main');
  if (!state.openDrawerName) state.focusReturn = document.activeElement;
  state.openDrawerName = name;
  main.inert = true;
  const report = document.getElementById('report-drawer');
  const settings = document.getElementById('settings-drawer');
  report.hidden = name !== 'report';
  settings.hidden = name !== 'settings';
  report.classList.toggle('is-open', name === 'report');
  settings.classList.toggle('is-open', name === 'settings');
  document.getElementById('btn-settings').setAttribute('aria-expanded', name === 'settings' ? 'true' : 'false');
  const back = document.getElementById(name === 'report' ? 'btn-report-back' : 'btn-settings-back');
  if (back && back.focus) back.focus();
}
function closeDrawers() {
  state.openDrawerName = '';
  document.getElementById('lite-main').inert = false;
  const report = document.getElementById('report-drawer');
  const settings = document.getElementById('settings-drawer');
  report.hidden = true;
  settings.hidden = true;
  report.classList.remove('is-open');
  settings.classList.remove('is-open');
  document.getElementById('btn-settings').setAttribute('aria-expanded', 'false');
  const back = state.focusReturn;
  state.focusReturn = null;
  if (back && typeof back.focus === 'function') back.focus();
}
function openReport(item) {
  if (typeof item === 'string') item = (state.research || []).find(x => x.id === item) || null;
  if (!item || !presentation(item)?.hasReport) return;
  renderReport(item);
  openDrawer('report');
}
function openSettings() {
  openDrawer('settings');
  refreshSettings();
}
function closeMicPopover() {
  state.micOpen = false;
  const pop = document.getElementById('mic-popover');
  if (pop) pop.hidden = true;
  document.getElementById('btn-mic-source')?.setAttribute('aria-expanded', 'false');
  document.getElementById('btn-mic-idle')?.setAttribute('aria-expanded', 'false');
}
function closePopovers() {
  state.sessionOpen = false;
  state.handoverOpen = false;
  document.getElementById('session-popover').hidden = true;
  document.getElementById('handover-popover').hidden = true;
  document.getElementById('btn-session').setAttribute('aria-expanded', 'false');
  document.getElementById('btn-handover').setAttribute('aria-expanded', 'false');
  closeMicPopover();
}
function selectedMicUID() {
  let cfg = {};
  try { cfg = JSON.parse(localStorage.getItem('tht-settings') || '{}'); } catch (e) {}
  return state.native.requestedInputUID ?? cfg.nativeInputUID ?? '';
}
function renderMicMenu() {
  const list = document.getElementById('mic-popover-list');
  if (!list) return;
  list.replaceChildren();
  const selected = selectedMicUID();
  const rows = [{ uid: '', name: tKey('mic_auto') }, ...(Array.isArray(state.native.inputDevices) ? state.native.inputDevices : [])];
  for (const row of rows) {
    const b = el('button', row.name || '');
    b.type = 'button';
    b.className = 'mic-item';
    b.setAttribute('role', 'menuitemradio');
    b.setAttribute('aria-checked', String(row.uid === selected));
    b.disabled = state.micSwitching;
    b.addEventListener('click', () => chooseMicSource(row.uid));
    list.append(b);
  }
}
async function toggleMicMenu() {
  state.micOpen = !state.micOpen;
  const pop = document.getElementById('mic-popover');
  if (pop) pop.hidden = !state.micOpen;
  const expanded = state.micOpen ? 'true' : 'false';
  document.getElementById('btn-mic-source')?.setAttribute('aria-expanded', expanded);
  document.getElementById('btn-mic-idle')?.setAttribute('aria-expanded', expanded);
  if (!state.micOpen) return;
  state.sessionOpen = false;
  state.handoverOpen = false;
  document.getElementById('session-popover').hidden = true;
  document.getElementById('handover-popover').hidden = true;
  document.getElementById('btn-session').setAttribute('aria-expanded', 'false');
  document.getElementById('btn-handover').setAttribute('aria-expanded', 'false');
  renderMicMenu();
  if (!Array.isArray(state.native.inputDevices) || !state.native.inputDevices.length) {
    try { await pollStatus(); } catch (e) {}
    if (state.micOpen) renderMicMenu();
  }
}
async function chooseMicSource(uid) {
  if (state.micSwitching) return;
  state.micSwitching = true;
  renderRec();
  try {
    const ns = state.native || {};
    const sid = ns.sessionId;
    if (!ns.active || !sid) {
      const res = await post('/asr-relay/native/input-preference', { inputUID: uid });
      if (res.ok === false) throw Error(res.error || 'input preference failed');
    } else {
      const res = await post('/asr-relay/native/microphone-switch', { sessionId: sid, inputUID: uid });
      const requestId = res.microphoneChange && res.microphoneChange.requestId;
      if (!requestId) throw Error(res.error || 'not accepted');
      let receipt = null;
      for (let i = 0; i < 12; i++) {
        await new Promise(resolve => later(resolve, 500));
        const next = await get('/asr-relay/native/status');
        if (!next || next.ok === false) continue;
        applyNative(next);
        if (next.sessionId !== sid || !next.active) throw Error('meeting changed');
        if (next.microphoneReceipt && next.microphoneReceipt.requestId === requestId) {
          receipt = next.microphoneReceipt;
          break;
        }
      }
      if (!receipt || !receipt.ok) throw Error((receipt && receipt.error) || 'unconfirmed');
    }
    let cfg = {};
    try { cfg = JSON.parse(localStorage.getItem('tht-settings') || '{}'); } catch (e) {}
    cfg.nativeInputUID = uid;
    localStorage.setItem('tht-settings', JSON.stringify(cfg));
    state.native = Object.assign({}, state.native, { requestedInputUID: uid });
    closeMicPopover();
    toast(tKey('mic_switched'));
  } catch (e) {
    toast(tKey('mic_switch_fail'));
  } finally {
    state.micSwitching = false;
    renderRec();
  }
}
async function refreshSettings() {
  const [account, mcp, mem, setup] = await Promise.all([
    get('/asr-relay/account/status'),
    get('/setup/mcp-connection'),
    get('/asr-relay/structured-memory'),
    get('/setup')
  ]);
  state.account = account || {};
  state.mcp = mcp || {};
  if (mem && (mem.profile || mem.projects || mem.counts || mem.ok)) state.memory = mem;
  const base = document.getElementById('byok-base');
  const model = document.getElementById('byok-model');
  if (base && document.activeElement !== base) base.value = (setup && (setup.base || setup.LLM_BASE_URL)) || '';
  if (model && document.activeElement !== model) model.value = (setup && (setup.model || setup.LLM_MODEL)) || '';
  renderAccount();
  renderMcp();
  fillProfile();
  renderProjects();
}
async function reloadMemory() {
  const mem = await get('/asr-relay/structured-memory');
  if (mem && (mem.profile || mem.projects || mem.counts || mem.ok)) state.memory = mem;
  renderProjects();
  renderReceipt();
  fillProfile();
}
async function ensureSession() {
  const existing = currentId();
  if (existing) return existing;
  const sequence = state.sessionSequence;
  const note = await post('/asr-relay/meeting-board', {
    action: 'new-note', requestId: uuid(), lang: launchLang(), uiLang: uiLang(), prepareStart: true
  });
  if (note.ok === false || note.error) throw Error(note.error || 'Could not create meeting');
  if (sequence !== state.sessionSequence || currentId()) throw Error(uiLang() === 'en' ? 'Meeting changed; please retry' : '会议已变化，请重试');
  const id = (note && note.prepared && note.prepared.sessionId) || (note && note.id) || '';
  if (id) {
    state.viewId = id;
    state.session = Object.assign({ transcript: [], highlights: [], factchecks: [], names: {} }, state.session, { id });
    try { if (history && history.replaceState) history.replaceState(null, '', './lite.html?id=' + encodeURIComponent(id)); } catch (e) {}
  }
  if (!id) throw Error('Missing meeting ID');
  return id;
}
async function submitAsk() {
  if (state.asking) return;
  const input = document.getElementById('lite-ask-input');
  const draft = input.value, text = String(draft || '').trim();
  if (!text) return;
  state.asking = true;
  const sequence = state.sessionSequence, draftSequence = state.askDraftSequence, effort = state.effort === 'deep' ? 'deep' : 'quick';
  try {
    const id = await ensureSession();
    if (effort === 'deep') {
      const res = await post('/asr-relay/live-research', { id, action: 'open', text, effort: 'deep' });
      if (res.ok === false || res.error || (res.ok !== true && !Array.isArray(res.items))) throw Error(res.error || tKey('toast_test_fail'));
      if (sequence !== state.sessionSequence || currentId() !== id || res.id !== id) return;
      if (input.value === draft && draftSequence === state.askDraftSequence) input.value = '';
      await refreshResearch(id);
    } else {
      const res = await post('/workspace-assistant', { action: 'auto', comment: text, requestId: uuid(), contextId: id, pageContext: { page: 'meeting', view: '', motherDocumentId: '', blockIds: [], placement: 'replace', projectId: '', objectId: '', sourceIds: [], targetSourceIds: [], quote: '' }, lang: uiLang(), model: localStorage.getItem('tht-agent-model') || '', effort: '', materialIds: [] });
      if (res.ok === false || res.error || !res.job) throw Error(res.error || tKey('toast_test_fail'));
      if (sequence !== state.sessionSequence || currentId() !== id || (res.job.contextId && res.job.contextId !== id)) return;
      ++state.jobsSequence;
      state.jobs = state.jobs.filter(j => j.id !== res.job.id).concat(res.job); state.chatFolded = false;
      if (input.value === draft && draftSequence === state.askDraftSequence) input.value = '';
      renderChat();
    }
    captureMeetingViewState();
    renderProactive();
  } catch (e) { toast(e.message); }
  finally { state.asking = false; }
}
async function askFollowup() {
  if (state.followupPending) return;
  const input = document.getElementById('report-ask-input');
  const draft = input.value, text = String(draft || '').trim();
  if (!text || !state.reportItem) return;
  const id = currentId(), itemId = state.reportItem.id, sequence = state.sessionSequence, draftSequence = state.followupDraftSequence;
  state.followupPending = true;
  try {
    const res = await post('/asr-relay/live-research', { id, itemId, action: 'ask', text });
    if (res.ok === false || res.error || (res.ok !== true && !Array.isArray(res.items))) throw Error(res.error || tKey('toast_test_fail'));
    if (sequence !== state.sessionSequence || currentId() !== id || state.reportItem?.id !== itemId || res.id !== id) return;
    if (input.value === draft && draftSequence === state.followupDraftSequence) input.value = '';
    await refreshResearch(id);
    if (sequence !== state.sessionSequence || currentId() !== id || state.reportItem?.id !== itemId) return;
    const fresh = (state.research || []).find(x => x.id === itemId);
    if (fresh) renderReport(fresh);
  } catch (e) { toast(e.message); }
  finally { state.followupPending = false; }
}
async function addMemory() {
  const input = document.getElementById('mem-add-input');
  const draft = input.value, text = String(draft || '').trim();
  if (!text || memoryAddPending) return;
  memoryAddPending = true;
  const button = document.getElementById('btn-mem-add');
  button.disabled = true;
  try {
    const res = await post('/asr-relay/structured-memory', { action: 'import-external', text });
    if (res?.ok !== true) throw Error(res?.error || tKey('toast_copy_fail'));
    if (input.value === draft) input.value = '';
    toast(tKey('toast_saved'));
    await reloadMemory();
  } catch (e) { toast(e.message); }
  finally { memoryAddPending = false; button.disabled = false; }
}
async function saveProfile() {
  if (profileSavePending) return;
  const fields = { 'profile-name': 'name', 'profile-role': 'role', 'profile-domain': 'domain', 'profile-preferences': 'preferences', 'profile-notes': 'customNotes' };
  const snapshot = {}, profile = {};
  for (const [id, key] of Object.entries(fields)) {
    snapshot[id] = document.getElementById(id).value;
    profile[key] = val(id);
  }
  profileSavePending = true;
  try {
    const res = await post('/asr-relay/structured-memory', { action: 'update-profile', profile });
    if (res?.ok !== true) throw Error(res?.error || tKey('toast_test_fail'));
    state.memory = { ...state.memory, profile: { ...state.memory?.profile, ...profile } };
    for (const id of Object.keys(fields)) {
      const value = document.getElementById(id).value;
      if (value === snapshot[id]) profileDirty.delete(id);
      else profileDirty.set(id, value);
    }
    toast(tKey('toast_profile'));
  } catch (e) { toast(e.message); }
  finally { profileSavePending = false; }
}
async function saveByok() {
  const body = { LLM_BASE_URL: val('byok-base'), LLM_MODEL: val('byok-model') };
  const key = val('byok-key');
  if (key) body.DEEPSEEK_API_KEY = key;
  const res = await post('/setup', body);
  toast(res && res.ok === false ? (res.error || tKey('toast_test_fail')) : tKey('toast_saved_byok'));
}
async function testByok() {
  if (state.native.active || state.native.starting || phase() === 'listening' || phase() === 'paused' || phase() === 'connecting') {
    toast(tKey('toast_test_idle'));
    return;
  }
  const body = { LLM_BASE_URL: val('byok-base'), LLM_MODEL: val('byok-model') };
  const key = val('byok-key');
  if (key) body.DEEPSEEK_API_KEY = key;
  const res = await post('/setup/test', body);
  toast(res && res.ok === false ? (res.error || tKey('toast_test_fail')) : tKey('toast_test_ok'));
}
async function refreshResearch(id) {
  id = id || currentId();
  if (!id) return;
  const sequence = ++state.researchSequence, sessionSequence = state.sessionSequence;
  const data = await get('/asr-relay/live-research?id=' + encodeURIComponent(id));
  if (sequence !== state.researchSequence || sessionSequence !== state.sessionSequence || id !== currentId() || state.pageHidden) return;
  if (data.ok !== false && data.id === id && Array.isArray(data.items)) {
    state.research = data.items;
    renderProactive();
  }
}
function sameTranscriptRow(a, b) {
  const aid = a.seg || a.id, bid = b.seg || b.id;
  if (aid && bid) return aid === bid;
  const at = rowSeconds(a), bt = rowSeconds(b);
  return at === bt && a.text === b.text && String(a.spk ?? a.speaker ?? '') === String(b.spk ?? b.speaker ?? '');
}
function appendTranscript(rows, row) {
  if (!rows.some(x => sameTranscriptRow(x, row))) rows.push(row);
}
async function loadSession(id, socket) {
  if (!id) return;
  const firstDraft = !currentId() ? document.getElementById('lite-ask-input').value : '';
  const sequence = ++state.sessionSequence, researchSequence = ++state.researchSequence;
  const read = { id, events: [] };
  state.sessionRead = read;
  if (state.viewId && state.viewId !== id) captureMeetingViewState();
  state.viewId = id;
  if (state.session?.id !== id) {
    state.session = { id, transcript: [], highlights: [], factchecks: [], names: {} };
    state.research = []; state.interim = ''; state.cards = null; state.jobs = []; state.reportItem = null;
    if (state.openDrawerName === 'report') closeDrawers();
    document.getElementById('lite-ask-input').value = '';
    restoreMeetingViewState(id);
    if (firstDraft) document.getElementById('lite-ask-input').value = firstDraft;
    renderAll();
  }
  const current = () => sequence === state.sessionSequence && id === currentId() && !state.pageHidden && (!socket || socket === state.ws);
  try {
    const exp = await get('/asr-relay/export-state?ids=' + encodeURIComponent(id));
    if (!current()) return;
    const sess = exp.sessions?.find(x => x.id === id);
    if (exp.ok !== false && (!exp.id || exp.id === id) && sess) {
      state.session = Object.assign({ transcript: [], highlights: [], factchecks: [], names: {} }, sess, { id });
      // A viewer snapshot received during this read has newer recording spans.
      if (read.recordingClock) Object.assign(state.session, read.recordingClock);
      state.session.transcript = (sess.transcript || []).slice();
      for (const row of read.events) appendTranscript(state.session.transcript, row);
      delete state.session.summary;
    } else if (exp.ok !== false && state.session?.id !== id) {
      state.session = { id, transcript: read.events.slice(), highlights: [], factchecks: [], names: {} };
    }
    const lr = await get('/asr-relay/live-research?id=' + encodeURIComponent(id));
    if (!current()) return;
    if (researchSequence === state.researchSequence && lr.ok !== false && lr.id === id && Array.isArray(lr.items)) state.research = lr.items;
    try { if (history && history.replaceState) history.replaceState(null, '', './lite.html?id=' + encodeURIComponent(id)); } catch (e) {}
    renderAll();
    refreshJobs(id);
  } finally { if (state.sessionRead === read) state.sessionRead = null; }
}
async function toggleSession() {
  state.sessionOpen = !state.sessionOpen;
  document.getElementById('session-popover').hidden = !state.sessionOpen;
  document.getElementById('btn-session').setAttribute('aria-expanded', state.sessionOpen ? 'true' : 'false');
  if (!state.sessionOpen) return;
  state.handoverOpen = false;
  document.getElementById('handover-popover').hidden = true;
  document.getElementById('btn-handover').setAttribute('aria-expanded', 'false');
  closeMicPopover();
  const data = await get('/asr-relay/meeting-list');
  state.meetings = (data && (data.sessions || data.meetings)) || [];
  renderSessionList();
}
function toggleHandover() {
  state.handoverOpen = !state.handoverOpen;
  document.getElementById('handover-popover').hidden = !state.handoverOpen;
  document.getElementById('btn-handover').setAttribute('aria-expanded', state.handoverOpen ? 'true' : 'false');
  if (state.handoverOpen) {
    state.sessionOpen = false;
    document.getElementById('session-popover').hidden = true;
    document.getElementById('btn-session').setAttribute('aria-expanded', 'false');
    closeMicPopover();
    const first = document.getElementById('ho-copy-all');
    if (first && first.focus) first.focus();
  }
}
function snapshotModel() {
  const s = state.session || {};
  const insights = [];
  for (const h of s.highlights || []) insights.push({ category: 'highlight', text: h.text || h.body || '' });
  for (const f of s.factchecks || []) insights.push({ verdict: f.verdict || '', text: f.text || f.claim || f.point || '' });
  const cards = state.cards || {};
  for (const key of ['suggestion', 'insights', 'history']) {
    for (const c of asList(cards[key])) insights.push({ category: key, text: cardText(c) });
  }
  return {
    title: s.title || '',
    topicTitle: s.topicTitle || '',
    happening: happeningPlain(),
    research: state.research || [],
    insights,
    transcript: transcriptRows(),
    names: s.names || {}
  };
}
function buildHandoverMarkdown(model) {
  const m = model || snapshotModel();
  const title = String(m.topicTitle || m.title || 'Untitled session').trim() || 'Untitled session';
  const lines = ['# ' + title, ''];
  if (m.happening) lines.push('## Happening now', '', String(m.happening).trim(), '');
  lines.push('## Deep Research', '');
  for (const item of m.research || m.items || []) {
    lines.push('### ' + (item.title || 'Research'), '');
    const body = item.conclusion || (item.quick && item.quick.answer) || '';
    if (body) lines.push(String(body), '');
  }
  lines.push('## Insights', '');
  for (const row of m.insights || []) {
    const bits = [row.verdict, row.category, row.text || row.body].filter(Boolean);
    if (bits.length) lines.push(bits.join(' — '), '');
  }
  lines.push('## Full Transcript', '');
  const names = m.names || (state.session && state.session.names) || {};
  for (const row of m.transcript || []) {
    const spk = row.speaker || speakerName(row.spk, { names });
    lines.push('**[' + fmtClock(rowSeconds(row)) + '] ' + spk + ':** ' + (row.text || ''), '');
  }
  return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}
function oneResearch(it) {
  const lines = ['# ' + (it.title || 'Research'), ''];
  const lead = it.conclusion || (it.quick && it.quick.answer) || '';
  if (lead) lines.push(String(lead), '');
  for (const s of it.subs || []) lines.push('## ' + (s.q || ''), '', (s.section && s.section.answer) || '', '');
  lines.push('## Sources', '');
  for (const src of it.sources || []) {
    const href = safeUrl(src && src.url);
    if (href) lines.push('- [' + ((src && src.title) || href) + '](' + href + ')');
  }
  return lines.join('\n').trim() + '\n';
}
function buildResearchMarkdown(item) {
  const list = item ? [item] : (state.reportItem ? [state.reportItem] : (state.research || []));
  if (!list.length) return '# Research\n';
  return list.map(oneResearch).join('\n');
}
function transcriptPlain() {
  return transcriptRows().map(row => '[' + fmtClock(rowSeconds(row)) + '] ' + speakerName(row.spk != null ? row.spk : row.speaker) + ': ' + (row.text || '')).join('\n');
}
function slug(title) {
  const s = String(title || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return s || 'session';
}
function downloadMarkdown(filename, text) {
  try {
    if (typeof Blob !== 'function' || typeof URL === 'undefined' || typeof URL.createObjectURL !== 'function') {
      toast(tKey('toast_export_fail'));
      return;
    }
    const blob = new Blob([text], { type: 'text/markdown' });
    const href = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('href', href);
    a.setAttribute('download', filename);
    a.hidden = true;
    document.body.append(a);
    if (typeof a.click === 'function') a.click();
    a.remove();
    if (typeof URL.revokeObjectURL === 'function') URL.revokeObjectURL(href);
    toast(tKey('toast_export'));
  } catch (e) {
    toast(tKey('toast_export_fail'));
  }
}
async function setPinned(on) {
  state.pinned = !!on;
  localStorage.setItem('tht-lite-pinned', state.pinned ? '1' : '0');
  await post('/setup/ui-mode', { litePinned: state.pinned });
  if (window.liveMateNativeWindow === true) {
    try { await window.webkit?.messageHandlers?.liveMateWindow?.postMessage({ action: 'setWindowPinned', pinned: state.pinned }); } catch (e) {}
  } else toast(tKey('toast_desktop'));
  syncToggles();
}
async function setStealth(on) {
  state.stealth = !!on;
  localStorage.setItem('tht-lite-stealth', state.stealth ? '1' : '0');
  await post('/setup/ui-mode', { liteStealth: state.stealth });
  if (window.liveMateNativeWindow === true) {
    try { await window.webkit?.messageHandlers?.liveMateWindow?.postMessage({ action: 'setWindowStealth', stealth: state.stealth }); } catch (e) {}
  } else toast(tKey('toast_desktop'));
  syncToggles();
}
async function sendCommand(command) {
  if (state.commandPending || (state.startPending && command !== 'resume' && command !== 'stop')) return false;
  const sessionId = state.native.sessionId || state.viewId || '';
  state.commandPending = true;
  renderRec();
  try {
    // #84 P0：接入中点「停止」= 取消接入（cancel-start），不必等 start 落地。
    if (command === 'stop' && state.native.starting && !state.native.active) {
      let res = await post('/asr-relay/native/cancel-start', { launchId: state.native.launchId || '' });
      if (res.ok !== true || res.stale || res.active) res = await post('/asr-relay/native/command', { sessionId: res.sessionId || sessionId, command });
      if (res.ok !== true) throw Error(res.error || tKey('toast_test_fail'));
      state.startPending = false;
      ++state.nativeSequence;
      state.native = Object.assign({}, state.native, res);
      if (!res.active && !res.stale) markEnded();
      return true;
    }
    const res = await post('/asr-relay/native/command', { sessionId, command });
    if (res.ok !== true) throw Error(res.error || tKey('toast_test_fail'));
    if (sessionId !== (state.native.sessionId || state.viewId || '')) return false;
    ++state.nativeSequence;
    if (command === 'stop') markEnded();
    else if (command === 'pause') state.native = Object.assign({}, state.native, { active: true, phase: 'paused', paused: true });
    else if (command === 'resume') {
      if (state.clockSessionId === sessionId) state.clockAt = Date.now();
      state.native = Object.assign({}, state.native, { active: true, phase: 'listening', paused: false });
      state.ended = false;
    }
    return true;
  } catch (e) { toast(e.message); return false; }
  finally { state.commandPending = false; renderRec(); }
}
async function startListening({continueMeetingId} = {}) {
  if (state.startPending || state.commandPending || state.installPending) return;
  state.startPending = true;
  const sequence = state.sessionSequence;
  const targetCurrentId = currentId();
  renderRec();
  try {
    if (state.native.active && phase() === 'paused') return await sendCommand('resume');
    if (state.native.active || state.native.starting) { toast(tKey('toast_listening')); return; }
    const note = continueMeetingId
      ? await post('/asr-relay/meeting-board', {
          action: 'continue-context', sessionId: continueMeetingId, lang: launchLang(), uiLang: uiLang()
        })
      : await post('/asr-relay/meeting-board', {
          action: 'new-note', requestId: uuid(), lang: launchLang(), uiLang: uiLang(), prepareStart: true
        });
    if (sequence !== state.sessionSequence) return;
    if (continueMeetingId && currentId() !== targetCurrentId) return;
    if (note.ok === false || note.error) throw Error(note.error || tKey('toast_test_fail'));
    const sessionId = note.prepared?.sessionId || note.id || '';
    if (!sessionId) throw Error('Missing meeting ID');
    if (continueMeetingId && note.prepared?.sessionId !== continueMeetingId) throw Error('Missing meeting ID');
    const continuationToken = note.prepared?.continuationToken || note.continuationToken || '';
    const launchBody = {
      autoStart: true,
      sessionId,
      continuationToken,
      lang: note.prepared?.lang || launchLang(),
      uiLang: uiLang()
    };
    if (note.prepared && Object.prototype.hasOwnProperty.call(note.prepared, 'brief')) launchBody.brief = note.prepared.brief;
    const res = await post('/asr-relay/native/launch', launchBody);
    if (res.ok !== true) throw Error(res.error || tKey('toast_test_fail'));
    if (sequence !== state.sessionSequence) return;
    if (continueMeetingId && currentId() !== targetCurrentId) return;
    if (continueMeetingId) {
      state.ended = false;
      state.endedLatch = false;
      renderAll();
    } else {
      ++state.sessionSequence; ++state.researchSequence;
      state.viewId = sessionId;
      state.clockBase = 0; state.clockAt = 0; state.clockSessionId = sessionId;
      state.ended = false;
      state.endedLatch = false;
      state.session = { id: sessionId, title: '', transcript: [], highlights: [], factchecks: [], names: {} };
      state.research = [];
      renderAll();
    }
  } catch (e) { toast(e.message); }
  finally { state.startPending = false; renderRec(); }
}
async function newSession() {
  if (state.native.active || state.native.starting) {
    toast(tKey('toast_listening'));
    return;
  }
  closePopovers();
  await startListening();
}
function markEnded() {
  if (state.endedLatch) return;
  state.endedLatch = true;
  state.ended = true;
  state.wasActive = false;
  state.native = Object.assign({}, state.native, { active: false, phase: 'ended', paused: false });
  renderRec();
  refreshAfterEnd();
}
async function refreshAfterEnd() {
  for (let i = 0; i < 3; i++) {
    const list = await get('/asr-relay/meeting-list');
    const mem = await get('/asr-relay/structured-memory');
    const id = state.viewId || state.native.sessionId || '';
    const row = ((list && list.sessions) || []).find(s => s.id === id);
    if (row) {
      state.session = Object.assign({}, state.session, { title: row.title || (state.session && state.session.title) || '', topicTitle: row.topicTitle || (state.session && state.session.topicTitle) || '' });
      renderTitle();
    }
    if (mem && (mem.profile || mem.projects || mem.counts)) {
      state.memory = mem;
      renderReceipt();
    }
    if (i < 2) await new Promise(resolve => later(resolve, 800));
  }
}
function applyNative(s) {
  if (!s || typeof s !== 'object' || s.ok === false) return;
  ++state.nativeSequence;
  const prev = !!state.native.active;
  const wasPaused = state.native.phase === 'paused' || state.native.paused;
  state.native = Object.assign({}, state.native, s);
  if (s.cards && viewingLive()) { state.cards = s.cards; if (state.session && state.session.id === s.sessionId) state.session.nativeInsights = s.cards; }
  if (s.expertStatus && typeof s.expertStatus === 'object') state.expertStatus = s.expertStatus;
  else if (s.active === false) state.expertStatus = { state: 'idle', count: 0 };
  if (s.interimText != null) state.interim = s.interimText;
  if (s.audioSeconds != null) noteClock(s.audioSeconds);
  else if (state.clockSessionId === state.native.sessionId && wasPaused !== (state.native.phase === 'paused' || state.native.paused)) state.clockAt = Date.now();
  if (s.sessionId && !state.viewId) state.viewId = s.sessionId;
  if (s.active) {
    state.wasActive = true;
    state.ended = false;
    state.endedLatch = false;
  } else if (prev && s.active === false) markEnded();
  renderRec();
  renderProactive();
  if (viewingLive()) renderTranscript();
  ensureClock();
}
async function pollStatus(socket) {
  const sequence = state.nativeSequence;
  const data = await get('/asr-relay/native/status');
  if (sequence !== state.nativeSequence || state.pageHidden || (socket && socket !== state.ws)) return;
  if (data && typeof data === 'object') applyNative(data);
}
function schedulePoll() {
  if (state.pageHidden) return;
  if (state.pollTimer) clearTimeout(state.pollTimer);
  const ms = (state.native.active || state.native.starting) ? 1000 : 2500;
  state.pollTimer = later(async () => {
    try { await pollStatus(); if (state.jobs.some(j => !['completed', 'failed', 'cancelled', 'stopped'].includes(j.state))) await refreshJobs(currentId()); } catch (e) {}
    schedulePoll();
  }, ms);
}
function ensureClock() {
  if (state.pageHidden) return;
  if (state.clockTimer) return;
  const tick = () => {
    state.clockTimer = null;
    const p = phase();
    if (p === 'listening' || p === 'connecting' || p === 'paused') {
      const timer = document.getElementById('rec-timer');
      if (timer) timer.textContent = fmtClock(shownClock());
      state.clockTimer = later(tick, 1000);
    }
  };
  state.clockTimer = later(tick, 1000);
}
function wsBase() {
  return (location.protocol === 'https:' ? 'wss:' : 'ws:') + '//' + location.host + '/asr-relay';
}
function connectWs() {
  if (state.pageHidden || typeof WebSocket !== 'function' || (state.ws && state.ws.readyState <= 1)) return;
  let ws;
  const retry = () => {
    if (state.pageHidden || state.wsRetryTimer) return;
    const delay = Math.min(15000, 1000 * Math.pow(2, Math.min(state.wsRetryAttempt++, 4)));
    state.wsRetryTimer = later(() => { state.wsRetryTimer = null; connectWs(); }, delay);
  };
  try { ws = new WebSocket(wsBase() + '?token=' + encodeURIComponent(token()) + '&role=view'); }
  catch (e) { retry(); return; }
  state.ws = ws;
  const current = () => state.ws === ws && !state.pageHidden;
  const disconnect = () => {
    if (!current()) return;
    state.ws = null;
    ws.onopen = ws.onmessage = ws.onerror = ws.onclose = null;
    try { ws.close(); } catch (e) {}
    retry();
  };
  ws.onopen = async () => {
    if (!current()) return;
    if (state.wsRetryTimer) clearTimeout(state.wsRetryTimer);
    state.wsRetryTimer = null; state.wsRetryAttempt = 0;
    try { ws.send(JSON.stringify({ type: 'view' })); } catch (e) { disconnect(); return; }
    // The existing viewer snapshot restores live state; the read restores the
    // selected (possibly historical) session and research missed while offline.
    const id = currentId();
    await Promise.all([id ? loadSession(id, ws) : Promise.resolve(), pollStatus(ws)]);
  };
  ws.onmessage = ev => {
    if (!current()) return;
    let msg = null;
    try { msg = JSON.parse(ev.data); } catch (e) { return; }
    handleWs(msg || {});
  };
  ws.onclose = ws.onerror = disconnect;
}
function suspendLite() {
  state.pageHidden = true;
  ++state.sessionSequence; ++state.researchSequence;
  for (const key of ['wsRetryTimer', 'pollTimer', 'clockTimer']) {
    if (state[key]) clearTimeout(state[key]);
    state[key] = null;
  }
  const ws = state.ws; state.ws = null;
  if (ws) {
    ws.onopen = ws.onmessage = ws.onerror = ws.onclose = null;
    try { ws.close(); } catch (e) {}
  }
}
window.addEventListener?.('pagehide', suspendLite);
window.addEventListener?.('pageshow', () => {
  if (!state.pageHidden) return;
  state.pageHidden = false; connectWs(); schedulePoll(); ensureClock();
});
function handleWs(msg) {
  const type = msg.type;
  if (type === 'snapshot') {
    const sess = msg.session || null;
    if (sess && eventForView(sess)) {
      state.session = Object.assign({}, state.session?.id === sess.id ? state.session : {}, sess);
      if (state.sessionRead?.id === sess.id) state.sessionRead.recordingClock = {
        start: state.session.start, end: state.session.end, recordingSpans: state.session.recordingSpans
      };
      if (state.sessionRead?.id === sess.id) state.sessionRead.events.push(...(sess.transcript || []));
      if (sess.id && !state.viewId) state.viewId = sess.id;
      renderTitle();
      renderProactive();
      renderTranscript();
    }
    if (msg.native || msg.status) applyNative(msg.native || msg.status);
  } else if (type === 'partial') {
    if (!eventForView(msg)) return;
    state.interim = msg.text || msg.interim || msg.interimText || '';
    renderTranscript();
  } else if (type === 'final') {
    if (!eventForView(msg)) return;
    state.session = state.session || {};
    state.session.transcript = state.session.transcript || [];
    const row = { t: msg.t != null ? msg.t : (msg.atSec != null ? msg.atSec : (msg.at != null ? msg.at : shownClock())), text: msg.text || '', spk: msg.spk != null ? msg.spk : (msg.speaker || ''), ...(msg.seg ? { seg: msg.seg } : {}) };
    if (row.text) {
      appendTranscript(state.session.transcript, row);
      if (state.sessionRead?.id === currentId()) state.sessionRead.events.push(row);
    }
    state.interim = '';
    renderTranscript();
  } else if (type === 'names') {
    if (!eventForView(msg)) return;
    state.session = state.session || {};
    state.session.names = msg.names || state.session.names || {};
    renderTranscript();
  } else if (type === 'native-status') applyNative(msg.status || msg);
  else if (type === 'live-report-updated' && eventForView(msg)) refreshResearch(currentId());
  else if (type === 'live-research-updated' && eventForView(msg)) {
    if (msg.data && msg.data.id === currentId()) { state.research = msg.data; renderProactive(); }
    refreshResearch(currentId());
  }
  else if ((type === 'native-insights' || type === 'discussion-summary') && eventForView(msg)) {
    state.session = state.session || { id: currentId() };
    const insights = msg.cards || msg.nativeInsights;
    if (insights) state.session.nativeInsights = insights;
    else if (type === 'discussion-summary') state.session.nativeInsights = Object.assign({}, state.session.nativeInsights, { discussion: msg.discussion || msg.summary });
    else loadSession(currentId());
    renderProactive();
  }
  else if (type === 'meeting-scenario' && msg.scenario) {
    if (state.session) state.session.meetingScenario = msg.scenario;
    window.THT_INTERVIEW_QR?.syncScenario?.({ sessionId: msg.sessionId || currentId() || '', mode: msg.scenario.mode || '' });
  } else if (type === 'interview-card' && msg.card) {
    if (state.session) state.session.interviewCard = msg.card;
    window.dispatchEvent(new CustomEvent('tht-interview-card', { detail: { sessionId: msg.sessionId || currentId() || '', card: msg.card } }));
  } else if (type === 'interview-wiped') {
    if (state.session) { state.session.interviewCard = null; state.session.transcript = []; }
    window.dispatchEvent(new CustomEvent('tht-interview-wiped', { detail: { sessionId: msg.sessionId || currentId() || '' } }));
    renderTranscript();
  } else if (type === 'ended' && eventForView(msg)) markEnded();
  else if (type === 'asr-status') {
    if (!eventForView(msg)) return;
    state.native = Object.assign({}, state.native, { asrStatus: msg.status || msg.asrStatus || '' });
    renderRec();
  } else if (type === 'volume' && eventForView(msg)) {
    state.native.audioLevel = msg.level ?? msg.audioLevel ?? msg.volume ?? 0; renderRec();
  } else if (type === 'error') toast(msg.message || msg.error || '');
}
function paintUpdateBusy() {
  renderRec();
  document.getElementById('btn-check-update').disabled = state.installPending;
  document.getElementById('btn-install-update').disabled = state.installPending || state.updateChecking;
  for (const ch of ['stable', 'candidate']) document.getElementById('channel-' + ch).disabled = state.installPending;
}
async function checkUpdates() {
  if (state.installPending) return;
  const sequence = ++state.updateSequence, channel = state.channel;
  state.updateOffer = null; state.updateChecking = true; paintUpdateBusy();
  const data = await get('/asr-relay/update?channel=' + encodeURIComponent(channel));
  if (sequence !== state.updateSequence || channel !== state.channel) return;
  state.updateChecking = false;
  const box = document.getElementById('update-status');
  box.removeAttribute('data-chrome'); box.removeAttribute('data-k');
  if (data.ok !== true) box.textContent = data.error || (uiLang() === 'en' ? 'Unable to check for updates' : '暂时无法检查更新');
  else if (data.hasUpdate && data.latest) {
    box.textContent = String(data.latest);
    if (/^[a-f0-9]{64}$/i.test(data.sha256 || '') && (!data.channel || data.channel === channel)) {
      state.updateOffer = { version: data.latest, sha256: data.sha256, channel, hasUpdate: true, sequence };
    }
  } else {
    box.textContent = tKey('up_to_date');
    box.setAttribute('data-chrome', ''); box.setAttribute('data-k', 'up_to_date');
  }
  paintUpdateBusy();
}
async function installUpdate() {
  if (state.installPending || state.updateChecking) return;
  if (state.startPending || state.commandPending || state.native.active || state.native.starting || phase() === 'listening' || phase() === 'paused' || phase() === 'connecting') {
    toast(tKey('toast_install_blocked')); return;
  }
  const offer = state.updateOffer;
  if (!offer?.hasUpdate || !offer.version || !/^[a-f0-9]{64}$/i.test(offer.sha256 || '') || offer.channel !== state.channel || offer.sequence !== state.updateSequence) { toast(tKey('toast_check_first')); return; }
  state.installPending = true; paintUpdateBusy();
  try {
    const url = '/asr-relay/update?channel=' + encodeURIComponent(offer.channel) + '&version=' + encodeURIComponent(offer.version) + '&sha256=' + encodeURIComponent(offer.sha256);
    const res = await post(url, {});
    if (res.ok !== true) throw Error(res.error || tKey('toast_test_fail'));
    state.updateOffer = null;
    toast(tKey('toast_updated'));
  } catch (e) { toast(e.message); }
  finally { state.installPending = false; paintUpdateBusy(); }
}
async function copyMcp() {
  const res = await post('/setup/mcp-connection', {
    action: 'connect', client: 'citeside-lite', requestId: uuid(), scope: { meetings: 'all' }
  });
  await copyText(JSON.stringify((res && res.config) || res || {}, null, 2));
}
function setChannel(ch) {
  if (state.installPending) return;
  ++state.updateSequence; state.updateOffer = null; state.updateChecking = false;
  paintUpdateBusy();
  state.channel = ch === 'candidate' ? 'candidate' : 'stable';
  localStorage.setItem('tht-update-channel', state.channel);
  syncToggles();
}
function setTongue(v) {
  state.tongue = v === 'zh' || v === 'en' ? v : 'auto';
  localStorage.setItem('tht-tongue', state.tongue);
  syncToggles();
}
function setTheme(theme) {
  state.theme = theme === 'light' || theme === 'dark' ? theme : 'auto';
  localStorage.setItem('tht-lite-theme', state.theme);
  document.documentElement.setAttribute('data-theme', state.theme);
  syncToggles();
  return state.theme;
}
function setUiLang(lang) {
  state.uiLang = lang === 'en' ? 'en' : 'zh';
  try { localStorage.setItem('tht-ui', state.uiLang); } catch (e) {}
  document.documentElement.lang = state.uiLang === 'en' ? 'en' : 'zh-CN';
  renderAll();
  return state.uiLang;
}
function readPrefs() {
  let ui = '';
  try { ui = localStorage.getItem('tht-ui') || ''; } catch (e) {}
  if (ui !== 'en' && ui !== 'zh') ui = String((navigator && navigator.language) || '').toLowerCase().indexOf('en') === 0 ? 'en' : 'zh';
  state.uiLang = ui;
  let theme = 'auto', tongue = 'auto', channel = 'stable';
  try { theme = localStorage.getItem('tht-lite-theme') || 'auto'; } catch (e) {}
  try { tongue = localStorage.getItem('tht-tongue') || 'auto'; } catch (e) {}
  try { channel = localStorage.getItem('tht-update-channel') || 'stable'; } catch (e) {}
  state.theme = theme === 'light' || theme === 'dark' ? theme : 'auto';
  state.tongue = tongue === 'zh' || tongue === 'en' ? tongue : 'auto';
  state.channel = channel === 'candidate' ? 'candidate' : 'stable';
  try { state.pinned = localStorage.getItem('tht-lite-pinned') === '1'; } catch (e) {}
  try { state.stealth = localStorage.getItem('tht-lite-stealth') === '1'; } catch (e) {}
  try { state.silentMemory = localStorage.getItem('tht-lite-silent') !== '0'; } catch (e) { state.silentMemory = true; }
}
function closestAttr(e, sel) {
  return e && e.target && e.target.closest ? e.target.closest(sel) : null;
}
function listed(nodes) {
  const out = [];
  if (!nodes) return out;
  for (let i = 0; i < nodes.length; i++) out.push(nodes[i]);
  return out;
}
function interactiveTarget(target) {
  if (!target || !target.closest) return false;
  const tags = ['button', 'a', 'input', 'textarea', 'select', 'summary'];
  for (let i = 0; i < tags.length; i++) {
    if (target.closest(tags[i])) return true;
  }
  return !!target.closest('[role="tab"]');
}
function onWindowDrag(e) {
  if (window.liveMateNativeWindow !== true || e.button !== 0) return;
  if (interactiveTarget(e.target)) return;
  try { window.webkit?.messageHandlers?.liveMateWindow?.postMessage({ action: 'dragWindow' }); } catch (err) {}
}
function syncTopbarScroll() {
  const topbar = document.getElementById('topbar');
  if (!topbar) return;
  const scroller = document.getElementById(state.tab === 'transcript' ? 'transcript-list' : state.tab === 'outputs' ? 'output-list' : 'proactive-scroll');
  topbar.classList.toggle('is-scrolled', !!(scroller && scroller.scrollTop > 4));
}
function installFocusFallback() {
  if (!(typeof HTMLElement === 'undefined' || !('focusGroup' in HTMLElement.prototype))) return;
  const bar = document.getElementById('qw-toolbar');
  if (bar) {
    const buttons = () => listed(bar.querySelectorAll('button'));
    const initial = buttons();
    for (let i = 0; i < initial.length; i++) initial[i].tabIndex = i === 0 ? 0 : -1;
    bar.addEventListener('focusin', ev => {
      const items = buttons();
      if (items.indexOf(ev.target) < 0) return;
      for (let i = 0; i < items.length; i++) items[i].tabIndex = items[i] === ev.target ? 0 : -1;
    });
    bar.addEventListener('keydown', e => {
      if (e.isComposing || e.keyCode === 229) return;
      const dir = typeof getComputedStyle === 'function' ? getComputedStyle(bar).direction : 'ltr';
      const rtl = dir === 'rtl';
      const vertical = bar.getAttribute('aria-orientation') === 'vertical';
      const items = buttons();
      const idx = items.indexOf(document.activeElement);
      let next = -1;
      if (e.key === 'Home') next = 0;
      else if (e.key === 'End') next = items.length - 1;
      else if (vertical && e.key === 'ArrowDown') { if (idx < 0) return; next = (idx + 1) % items.length; }
      else if (vertical && e.key === 'ArrowUp') { if (idx < 0) return; next = (idx - 1 + items.length) % items.length; }
      else if (!vertical && e.key === 'ArrowRight') { if (idx < 0) return; next = (idx + (rtl ? -1 : 1) + items.length) % items.length; }
      else if (!vertical && e.key === 'ArrowLeft') { if (idx < 0) return; next = (idx + (rtl ? 1 : -1) + items.length) % items.length; }
      else return;
      if (next < 0 || !items[next]) return;
      e.preventDefault?.();
      items[next].focus();
    });
  }
  const menu = document.getElementById('handover-group');
  if (menu) {
    menu.setAttribute('role', 'menu');
    const items = listed(menu.querySelectorAll('button'));
    for (let i = 0; i < items.length; i++) {
      if (!items[i].getAttribute('role')) items[i].setAttribute('role', 'menuitem');
    }
    menu.addEventListener('keydown', e => {
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Home' && e.key !== 'End') return;
      const list = listed(menu.querySelectorAll('button'));
      const idx = list.indexOf(document.activeElement);
      if (idx < 0) return;
      e.preventDefault?.();
      let next = 0;
      if (e.key === 'Home') next = 0;
      else if (e.key === 'End') next = list.length - 1;
      else if (e.key === 'ArrowUp') next = (idx - 1 + list.length) % list.length;
      else next = (idx + 1) % list.length;
      if (list[next] && list[next].focus) list[next].focus();
    });
  }
}
function bind() {
  document.getElementById('output-list').addEventListener('click', e => { const open = closestAttr(e, '[data-open-report]'); if (open) openReport(open.getAttribute('data-open-report')); });
  document.getElementById('tab-outputs').addEventListener('click', () => selectTab('outputs'));
  document.getElementById('latest-transcript').addEventListener('click', () => { selectTab('transcript'); document.getElementById('tab-transcript').focus(); });
  document.getElementById('toggle-conversation').addEventListener('click', () => { state.chatFolded = !state.chatFolded; renderChat(); captureMeetingViewState(); });
  const convStripBtn = document.getElementById('conversation-strip');
  if (convStripBtn) convStripBtn.addEventListener('click', () => { state.chatFolded = false; renderChat(); captureMeetingViewState(); });
  document.getElementById('lite-ask-input').addEventListener('input', () => { ++state.askDraftSequence; captureMeetingViewState(); });
  document.getElementById('report-ask-input').addEventListener('input', () => { ++state.followupDraftSequence; });
  document.getElementById('tab-proactive').addEventListener('click', () => selectTab('proactive'));
  document.getElementById('tab-transcript').addEventListener('click', () => selectTab('transcript'));
  document.getElementById('lite-tabs').addEventListener('keydown', e => {
    if (e.isComposing || e.keyCode === 229) return;
    const tabs = Array.from(document.querySelectorAll('[role="tab"]'));
    const i = tabs.indexOf(e.target);
    if (i < 0) return;
    let n = i;
    if (e.key === 'ArrowRight') n = (i + 1) % tabs.length;
    else if (e.key === 'ArrowLeft') n = (i - 1 + tabs.length) % tabs.length;
    else if (e.key === 'Home') n = 0;
    else if (e.key === 'End') n = tabs.length - 1;
    else return;
    e.preventDefault?.();
    selectTab(tabs[n].id.replace('tab-', ''));
    tabs[n].focus();
  });
  document.getElementById('lite-ask-input').addEventListener('keydown', e => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault?.(); submitAsk(); }
  });
  document.getElementById('ask-form').addEventListener('submit', e => { e.preventDefault?.(); submitAsk(); });
  document.getElementById('lite-ask-submit').addEventListener('click', e => { e.preventDefault?.(); submitAsk(); });
  document.getElementById('btn-effort').addEventListener('click', () => {
    state.effort = state.effort === 'deep' ? 'quick' : 'deep';
    syncToggles();
  });
  document.getElementById('report-ask-input').addEventListener('keydown', e => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === 'Enter') { e.preventDefault?.(); askFollowup(); }
  });
  document.getElementById('report-ask').addEventListener('submit', e => { e.preventDefault?.(); askFollowup(); });
  document.getElementById('mem-add-input').addEventListener('keydown', e => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === 'Enter') { e.preventDefault?.(); addMemory(); }
  });
  document.getElementById('mem-add-form').addEventListener('submit', e => { e.preventDefault?.(); addMemory(); });
  document.getElementById('btn-mem-add').addEventListener('click', e => { e.preventDefault?.(); addMemory(); });
  document.getElementById('session-search-input').addEventListener('keydown', e => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === 'Enter') e.preventDefault?.();
  });
  document.getElementById('session-search-input').addEventListener('input', () => renderSessionList());
  document.getElementById('tr-filter-input').addEventListener('keydown', e => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === 'Enter') e.preventDefault?.();
  });
  document.getElementById('tr-filter-input').addEventListener('input', () => renderTranscript());
  for (const id of ['profile-name', 'profile-role', 'profile-domain', 'profile-preferences', 'profile-notes']) {
    document.getElementById(id).addEventListener('input', () => profileDirty.set(id, document.getElementById(id).value));
    document.getElementById(id).addEventListener('keydown', e => {
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault?.(); saveProfile(); }
    });
  }
  for (const id of ['byok-base', 'byok-model', 'byok-key']) {
    document.getElementById(id).addEventListener('keydown', e => {
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === 'Enter') { e.preventDefault?.(); saveByok(); }
    });
  }
  document.addEventListener('keydown', e => {
    if (e.isComposing || e.keyCode === 229) return;
    if ((e.metaKey || e.ctrlKey) && e.key === ',') {
      e.preventDefault?.();
      if (state.openDrawerName === 'settings') closeDrawers();
      else openSettings();
      return;
    }
    if (e.key !== 'Escape') return;
    if (state.openDrawerName) { e.preventDefault?.(); closeDrawers(); return; }
    closePopovers();
  });
  document.getElementById('btn-session').addEventListener('click', e => { e.stopPropagation?.(); toggleSession(); });
  document.getElementById('btn-handover').addEventListener('click', e => { e.stopPropagation?.(); toggleHandover(); });
  document.getElementById('btn-mic-source')?.addEventListener('click', e => { e.stopPropagation?.(); toggleMicMenu(); });
  document.getElementById('btn-mic-idle')?.addEventListener('click', e => { e.stopPropagation?.(); toggleMicMenu(); });
  document.getElementById('btn-new-session').addEventListener('click', () => newSession());
  document.getElementById('session-list').addEventListener('click', e => {
    const b = closestAttr(e, '[data-session-id]');
    if (!b) return;
    loadSession(b.getAttribute('data-session-id'));
    closePopovers();
  });
  document.getElementById('ho-copy-all').addEventListener('click', () => { copyText(buildHandoverMarkdown()); closePopovers(); });
  document.getElementById('ho-export').addEventListener('click', () => {
    const s = state.session || {};
    downloadMarkdown('citeside-' + slug(s.topicTitle || s.title) + '.md', buildHandoverMarkdown());
    closePopovers();
  });
  document.getElementById('ho-copy-research').addEventListener('click', () => { copyText(buildResearchMarkdown()); closePopovers(); });
  document.getElementById('ho-copy-transcript').addEventListener('click', () => { copyText(transcriptPlain()); closePopovers(); });
  async function collapseToMini() {
    const ns = state.native || {};
    const id = ns.sessionId || currentId() || '';
    if (!ns.active || !id) return false;
    captureMeetingViewState();
    const alreadyMini = typeof document !== 'undefined' && document.visibilityState === 'hidden';
    if (alreadyMini) {
      try { await post('/asr-relay/native/panel-presence', { clientId: 'lite-' + id.slice(0, 8), sessionId: id, foreground: false }); } catch (e) {}
      try { await post('/asr-relay/native/panel-show', { sessionId: id, view: 'capsule' }); return true; } catch (e) { return false; }
    }
    if (window.liveMateNativeWindow === true && window.webkit?.messageHandlers?.liveMateWindow) {
      try {
        await window.webkit.messageHandlers.liveMateWindow.postMessage({ sessionId: id, view: 'capsule', source: 'button' });
        return true;
      } catch (e) {
        toast((e && e.message) || tKey('toast_test_fail'));
        return false;
      }
    }
    toast(tKey('toast_desktop'));
    return false;
  }
  window.thtCollapseToMini = collapseToMini;
  document.getElementById('btn-mini')?.addEventListener('click', () => collapseToMini());
  document.getElementById('btn-home')?.addEventListener('click', async () => {
    const target = './index.html?view=home';
    captureMeetingViewState();
    await post('/setup/ui-mode', { uiMode: 'full' });
    let handled = false;
    try {
      const r = await window.webkit?.messageHandlers?.liveMateWindow?.postMessage({ action: 'setUiMode', mode: 'full', url: target });
      handled = r && r.navigated === true;
    } catch (e) {}
    if (!handled && location && location.assign) location.assign(target);
  });
  document.getElementById('btn-full').addEventListener('click', async () => {
    const id = currentId();
    const target = './index.html' + (id ? '?id=' + encodeURIComponent(id) : '');
    captureMeetingViewState();
    await post('/setup/ui-mode', { uiMode: 'full' });
    let handled = false;
    try {
      const r = await window.webkit?.messageHandlers?.liveMateWindow?.postMessage({ action: 'setUiMode', mode: 'full', url: target });
      handled = r && r.navigated === true;
    } catch (e) {}
    if (!handled && location && location.assign) location.assign(target);
  });
  document.getElementById('btn-settings').addEventListener('click', () => openSettings());
  document.getElementById('btn-settings-back').addEventListener('click', () => closeDrawers());
  document.getElementById('btn-report-back').addEventListener('click', () => closeDrawers());
  document.getElementById('btn-report-copy').addEventListener('click', () => copyText(buildResearchMarkdown(state.reportItem)));
  document.getElementById('btn-copy-transcript').addEventListener('click', () => copyText(transcriptPlain()));
  document.getElementById('btn-jump-latest').addEventListener('click', () => {
    const box = document.getElementById('transcript-list');
    box.scrollTop = box.scrollHeight;
    document.getElementById('btn-jump-latest').hidden = true;
  });
  document.getElementById('btn-start').addEventListener('click', () => startListening());
  document.getElementById('btn-continue-meeting').addEventListener('click', () => startListening({continueMeetingId: currentId()}));
  document.getElementById('btn-new-meeting').addEventListener('click', () => newSession());
  document.getElementById('btn-pause').addEventListener('click', () => sendCommand('pause'));
  document.getElementById('btn-resume').addEventListener('click', () => sendCommand('resume'));
  document.getElementById('btn-stop').addEventListener('click', () => sendCommand('stop'));
  document.getElementById('btn-pin').addEventListener('click', () => setPinned(!state.pinned));
  document.getElementById('btn-stealth').addEventListener('click', () => setStealth(!state.stealth));
  document.getElementById('memory-receipt').addEventListener('click', () => openSettings());
  document.getElementById('btn-silent').addEventListener('click', async () => {
    state.silentMemory = !state.silentMemory;
    localStorage.setItem('tht-lite-silent', state.silentMemory ? '1' : '0');
    await post('/setup/ui-mode', { silentMemory: state.silentMemory });
    syncToggles();
  });
  document.getElementById('btn-mcp-copy').addEventListener('click', () => copyMcp());
  document.getElementById('mcp-clients').addEventListener('click', async e => {
    const b = closestAttr(e, '[data-client-id]');
    if (!b) return;
    await post('/setup/mcp-connection', { action: 'autoconnect', clientId: b.getAttribute('data-client-id') });
    const mcp = await get('/setup/mcp-connection');
    if (mcp && mcp.status) state.mcp = mcp;
    renderMcp();
  });
  document.getElementById('btn-profile-save').addEventListener('click', () => saveProfile());
  document.getElementById('btn-forget-profile').addEventListener('click', async () => {
    const b = document.getElementById('btn-forget-profile');
    if (b.disabled) return;
    if (b.getAttribute('data-armed') === '1') {
      b.removeAttribute('data-armed');
      b.setAttribute('data-k', 'forget');
      b.textContent = tKey('forget');
      b.disabled = true;
      try {
        const res = await post('/asr-relay/structured-memory', { action: 'forget-profile' });
        if (res?.ok !== true) throw Error(res?.error || tKey('toast_test_fail'));
        toast(tKey('toast_forgotten'));
        await reloadMemory();
      } catch (e) { toast(e.message); }
      finally { b.disabled = false; }
    } else {
      b.setAttribute('data-armed', '1');
      b.removeAttribute('data-k');
      b.textContent = tKey('confirm_forget');
      b.setAttribute('data-chrome', '');
    }
  });
  document.getElementById('mem-projects').addEventListener('click', async e => {
    const b = closestAttr(e, '[data-forget-project]');
    if (!b || b.disabled) return;
    if (b.getAttribute('data-armed') === '1') {
      const id = b.getAttribute('data-forget-project');
      b.removeAttribute('data-armed');
      b.disabled = true;
      b.textContent = tKey('forget');
      try {
        const res = await post('/asr-relay/structured-memory', { action: 'forget-project', id });
        if (res?.ok !== true) throw Error(res?.error || tKey('toast_test_fail'));
        toast(tKey('toast_forgotten'));
        await reloadMemory();
      } catch (e) { toast(e.message); }
      finally { b.disabled = false; }
    } else {
      b.setAttribute('data-armed', '1');
      b.textContent = tKey('confirm_forget');
      b.setAttribute('data-chrome', '');
    }
  });
  document.getElementById('proactive-stream').addEventListener('click', e => {
    const srcToggle = closestAttr(e, '[data-toggle-sources]');
    if (srcToggle) {
      const card = closestAttr(e, '.feed-entry');
      const drawer = card && card.querySelector ? card.querySelector('.sources-drawer') : null;
      if (drawer) {
        drawer.hidden = !drawer.hidden;
        srcToggle.setAttribute('aria-expanded', String(!drawer.hidden));
        const sk = srcToggle.getAttribute('data-source-key') || '';
        if (sk) { if (!drawer.hidden) openSourceDrawers.add(sk); else openSourceDrawers.delete(sk); }
      }
      return;
    }
    const deep = closestAttr(e, '[data-deep]');
    const stop = closestAttr(e, '[data-stop]');
    const open = closestAttr(e, '[data-open-report]');
    const save = closestAttr(e, '[data-save-context]');
    const research = closestAttr(e, '[data-research]');
    const id = currentId(), sequence = state.sessionSequence;
    if (deep || stop) {
      const target = deep || stop;
      post('/asr-relay/live-research', { id, action: deep ? 'deep' : 'stop', itemId: target.getAttribute(deep ? 'data-deep' : 'data-stop') }).then(() => { if (currentId() === id && sequence === state.sessionSequence) return refreshResearch(id); });
    }
    else if (open) openReport(open.getAttribute('data-open-report'));
    else if (save) {
      const text = state.contextTexts[Number(save.getAttribute('data-save-context'))] || '';
      if (!text) return;
      post('/asr-relay/structured-memory', { action: 'import-external', text }).then(res => toast(res && res.ok === false ? (res.error || tKey('toast_copy_fail')) : tKey('toast_saved')));
    } else if (research) {
      const lrState = research.dataset.lrState || '';
      if (['pending', 'running'].includes(lrState)) {
        window.pendingResearchCards = window.pendingResearchCards || new Set();
        const pendSet = window.pendingResearchCards;
        const rIdx = research.getAttribute('data-research');
        pendSet.delete(currentId() + ':' + (research.dataset.cardId || rIdx));
        pendSet.delete(currentId() + ':' + rIdx);
        research.dataset.lrState = 'idle';
        research.title = '';
        research.onmouseenter = null;
        research.onmouseleave = null;
        research.textContent = tKey('act_research');
        post('/asr-relay/live-research', { id: currentId(), action: 'stop', ...(research.dataset.itemId ? { itemId: research.dataset.itemId } : {}), ...(research.dataset.cardId ? { cardId: research.dataset.cardId } : {}) }).then(() => refreshResearch(currentId()));
        return;
      }
      if (lrState === 'done' && research.dataset.itemId) { openReport(research.dataset.itemId); return; }
      const text = state.contextTexts[Number(research.getAttribute('data-research'))] || '';
      if (!text || research.disabled) return;
      const contract = window.ThtProactiveContract;
      const hostCard = research.closest('.card, .signal-card, article, div');
      const showLitePaywall = () => {
        if (!hostCard) return;
        const old = hostCard.querySelector('.mw-pro-paywall'); if (old) { old.remove(); return; }
        const verifiedCount = (Array.isArray(state.signals) ? state.signals : []).filter(x => x && (x.cardKind === 'fact_check' || (Array.isArray(x.sources) && x.sources.length > 0))).length;
        const masBuild = !!(window.CITESIDE_MAS || window.THT_BOOT?.masBuild);
        const spec = contract?.researchPaywallSpec
          ? contract.researchPaywallSpec({ langOrEn: state.uiLang || state.lang || 'zh', verifiedCount, masBuild })
          : { valueLine: (state.uiLang === 'en' ? `Verified ${verifiedCount} items this meeting` : `本场已为你核实 ${verifiedCount} 处`), reassureLine: contract?.paywallReassureText?.(state.uiLang || state.lang || 'zh') || (state.uiLang === 'en' ? 'Your past meeting notes always stay readable and exportable.' : '你的历史会议纪要与笔记永远可读、可随时导出。'), masOnly: masBuild, masHint: state.uiLang === 'en' ? 'Manage account at citeside.com' : '在 citeside.com 管理账号', ctaLabel: state.uiLang === 'en' ? 'Upgrade to Pro' : '升级 Pro', upgradeHref: 'account.html?view=plans' };
        const openPlans = () => { fetch('/account/open-plans', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }).then(r => { if (!r.ok) window.open(spec.upgradeHref, '_blank', 'noopener,noreferrer'); }).catch(() => window.open(spec.upgradeHref, '_blank', 'noopener,noreferrer')); };
        let box;
        if (contract?.buildBorderlessPaywall) {
          box = contract.buildBorderlessPaywall(document, spec, { onUpgrade: openPlans });
        } else {
          box = el('div'); box.className = 'mw-pro-paywall'; box.setAttribute('role', 'region');
          const val = el('div', spec.valueLine); val.className = 'mw-pro-paywall-val'; box.append(val);
          const reassure = el('div'); reassure.className = 'mw-pro-paywall-reassure';
          const dot = el('span'); dot.className = 'mw-pro-paywall-reassure-dot'; dot.setAttribute('aria-hidden', 'true');
          reassure.append(dot, el('span', spec.reassureLine || '')); box.append(reassure);
          if (spec.masOnly) {
            const hint = el('span', spec.masHint); hint.className = 'mw-pro-paywall-mas'; box.append(hint);
          } else {
            const cta = el('a', spec.ctaLabel); cta.className = 'mw-pro-paywall-cta'; cta.href = spec.upgradeHref; cta.target = '_blank'; cta.rel = 'noopener noreferrer';
            cta.onclick = (ev) => { ev.preventDefault(); openPlans(); };
            box.append(cta);
          }
        }
        hostCard.append(box);
      };
      const isPro = contract?.isResearchProAccount ? contract.isResearchProAccount(window.THT_BOOT || {}) : true;
      if (!isPro || research.dataset.proGate === '1') { showLitePaywall(); return; }
      window.pendingResearchCards = window.pendingResearchCards || new Set();
      const pendSet = window.pendingResearchCards;
      const cardKey = currentId() + ':' + (research.dataset.cardId || research.getAttribute('data-research'));
      pendSet.add(cardKey);
      research.dataset.lrState = 'pending';
      const enUi = (state.uiLang || state.lang || 'zh') === 'en';
      const pendText = enUi ? 'Researching…' : '深度研究中…';
      const cancelText = enUi ? 'Cancel research' : '取消研究';
      research.textContent = pendText;
      research.title = cancelText;
      research.onmouseenter = () => { research.textContent = cancelText; };
      research.onmouseleave = () => { research.textContent = pendText; };
      toast(state.uiLang === 'en' ? 'Starting deep research…' : '已发起深度研究…');
      const resetResearchBtn = () => {
        pendSet.delete(cardKey);
        research.dataset.lrState = 'idle';
        research.title = '';
        research.onmouseenter = null;
        research.onmouseleave = null;
        research.textContent = tKey('act_research');
      };
      ensureSession().then(async targetId => {
        if (sequence !== state.sessionSequence || currentId() !== targetId) return;
        const result = await post('/asr-relay/live-research', { id: targetId, action: 'open', ...(research.dataset.cardId ? { cardId: research.dataset.cardId } : {}), ...(research.dataset.cardKind ? { cardKind: research.dataset.cardKind } : {}), uiLang: document.documentElement.lang === 'en' ? 'en' : 'zh', fast: true, text, effort: 'deep' });
        if (result.ok === false || sequence !== state.sessionSequence || currentId() !== targetId) {
          resetResearchBtn();
          const errCode = String(result?.code || result?.error || '');
          if (contract?.isResearchEntitlementError?.(errCode)) {
            research.dataset.proGate = '1';
            research.textContent = contract.researchButtonLabel({ langOrEn: state.uiLang || state.lang || 'zh', isPro: false, state: 'idle' });
            showLitePaywall();
            return;
          }
          if (result && result.error) toast(result.error);
          return;
        }
        await refreshResearch(targetId);
      }).catch(() => { resetResearchBtn(); });
    }
  });
  document.getElementById('ui-zh').addEventListener('click', () => setUiLang('zh'));
  document.getElementById('ui-en').addEventListener('click', () => setUiLang('en'));
  document.getElementById('theme-auto').addEventListener('click', () => setTheme('auto'));
  document.getElementById('theme-light').addEventListener('click', () => setTheme('light'));
  document.getElementById('theme-dark').addEventListener('click', () => setTheme('dark'));
  document.getElementById('tongue-auto').addEventListener('click', () => setTongue('auto'));
  document.getElementById('tongue-zh').addEventListener('click', () => setTongue('zh'));
  document.getElementById('tongue-en').addEventListener('click', () => setTongue('en'));
  document.getElementById('channel-stable').addEventListener('click', () => setChannel('stable'));
  document.getElementById('channel-candidate').addEventListener('click', () => setChannel('candidate'));
  document.getElementById('btn-check-update').addEventListener('click', () => checkUpdates());
  document.getElementById('btn-install-update').addEventListener('click', () => installUpdate());
  document.getElementById('btn-byok-save').addEventListener('click', () => saveByok());
  document.getElementById('btn-byok-test').addEventListener('click', () => testByok());
  document.addEventListener('click', e => {
    const t = e.target;
    if (!t || !t.closest) return;
    if (!state.chatFolded && state.jobs.some(j => !j.candidateId && (j.contextId || j.meetingId) === currentId())) {
      const sel = window.getSelection ? String(window.getSelection()).trim() : '';
      if (!sel && !t.closest('.ordinary-conversation, .composer-wrap, button, a, input, textarea, select, label, summary, [role="button"], .popover-card, .drawer')) {
        state.chatFolded = true;
        renderChat();
        captureMeetingViewState();
      }
    }
    if (t.closest('#session-popover') || t.closest('#handover-popover') || t.closest('#mic-popover') || t.closest('#btn-session') || t.closest('#btn-handover') || t.closest('#btn-mic-source') || t.closest('#btn-mic-idle')) return;
    closePopovers();
  });
  const topbar = document.getElementById('topbar');
  if (topbar) topbar.addEventListener('mousedown', onWindowDrag);
  const heads = document.querySelectorAll('.drawer-head');
  for (let i = 0; i < heads.length; i++) heads[i].addEventListener('mousedown', onWindowDrag);
  const proactiveScroll = document.getElementById('proactive-scroll');
  const transcriptList = document.getElementById('transcript-list');
  if (proactiveScroll) proactiveScroll.addEventListener('scroll', () => syncTopbarScroll());
  if (transcriptList) transcriptList.addEventListener('scroll', () => syncTopbarScroll());
  installFocusFallback();
}
function loadFixture(fix) {
  fix = fix || {};
  if (fix.id) state.viewId = fix.id;
  if (fix.session) state.session = fix.session;
  if (fix.research) state.research = fix.research;
  if (fix.items) state.research = fix.items;
  if (fix.cards) state.cards = fix.cards;
  if (fix.native) state.native = Object.assign({}, state.native, fix.native);
  renderAll();
}
async function run() {
  readPrefs();
  try { state.viewId = new URLSearchParams(location.search).get('id') || ''; } catch (e) {}
  document.documentElement.lang = state.uiLang === 'en' ? 'en' : 'zh-CN';
  document.documentElement.setAttribute('data-theme', state.theme);
  bind();
  renderAll();
  if (typeof requestAnimationFrame === 'function') {
    requestAnimationFrame(() => { try { window.webkit?.messageHandlers?.liveMateWindow?.postMessage({ action: 'uiModeReady' })?.catch?.(() => {}); } catch (e) {} });
  } else {
    try { window.webkit?.messageHandlers?.liveMateWindow?.postMessage({ action: 'uiModeReady' })?.catch?.(() => {}); } catch (e) {}
  }
  try {
    const [setup] = await Promise.all([get('/setup').catch(() => null), pollStatus().catch(() => null)]);
    if (setup && typeof setup === 'object') {
      if (typeof setup.litePinned === 'boolean') state.pinned = setup.litePinned;
      if (typeof setup.liteStealth === 'boolean') state.stealth = setup.liteStealth;
      if (typeof setup.silentMemory === 'boolean') state.silentMemory = setup.silentMemory;
      syncToggles();
    }
  } catch (e) {}
  let qid = '';
  try { qid = new URLSearchParams(location.search).get('id') || ''; } catch (e) {}
  const targetId = qid || state.viewId || '';
  if (targetId) { restoreMeetingViewState(targetId); try { await loadSession(targetId); } catch (e) {} }
  try { connectWs(); } catch (e) {}
  schedulePoll();
  ensureClock();
}
window.thtOpenPanel = panel => {
  if (panel === 'settings' || panel === 'update') {
    openSettings();
    if (panel === 'update') checkUpdates();
  }
};
const api = { captureMeetingViewState, setUiLang, setTheme, buildHandoverMarkdown, buildResearchMarkdown, openReport, openSettings, closeDrawers, loadFixture, applyNative, ready: null };
window.ThtLite = api;
api.ready = document.readyState === 'loading' ? new Promise(resolve => document.addEventListener('DOMContentLoaded', () => resolve(run()))) : run();
})();
