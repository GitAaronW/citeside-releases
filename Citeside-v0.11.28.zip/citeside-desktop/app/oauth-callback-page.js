'use strict';
// Shared trilingual (EN / ZH / JA) brand-grade OAuth callback page for local loopback redirects.
// Zero external dependencies; strictly escapes all dynamic content and validates local return URLs.

function normalizeLang(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return '';
  if (raw === 'ja' || raw.startsWith('ja-') || raw.startsWith('jp')) return 'ja';
  if (raw === 'zh' || raw.startsWith('zh-')) return 'zh';
  if (raw === 'en' || raw.startsWith('en-')) return 'en';
  return '';
}

function resolveLang(explicitLang, acceptLanguage) {
  const direct = normalizeLang(explicitLang);
  if (direct) return direct;
  const header = String(acceptLanguage || '').trim();
  if (header) {
    const entries = header
      .split(',')
      .map((part, idx) => {
        const [tagPart, ...params] = part.trim().split(';');
        const qParam = params.find(p => /^\s*q\s*=/.test(p));
        const q = qParam ? Number(qParam.split('=')[1]) : 1;
        return { tag: (tagPart || '').trim(), q: Number.isFinite(q) ? q : 0, idx };
      })
      .filter(e => e.tag && e.q > 0)
      .sort((a, b) => b.q - a.q || a.idx - b.idx);
    for (const entry of entries) {
      const matched = normalizeLang(entry.tag);
      if (matched) return matched;
    }
  }
  return 'en';
}

function escHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function safeReturnUrl(value) {
  const fallback = 'http://127.0.0.1:47823/seatnote/';
  if (!value || typeof value !== 'string') return fallback;
  try {
    const u = new URL(value);
    if (
      u.protocol === 'http:' &&
      ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname) &&
      !u.username &&
      !u.password
    ) {
      return u.href;
    }
  } catch {}
  return fallback;
}

const SERVICE_NAMES = {
  'google-calendar': {
    en: 'Google Calendar',
    zh: 'Google 日历',
    ja: 'Google カレンダー',
  },
  'google-drive': {
    en: 'Google Drive',
    zh: 'Google Drive',
    ja: 'Google ドライブ',
  },
  notion: {
    en: 'Notion',
    zh: 'Notion',
    ja: 'Notion',
  },
};

const COPY = {
  en: {
    success: {
      heading: s => `${s} connected`,
      sub: 'You can close this tab and return to Citeside.',
      cta: 'Return to Citeside',
      hint: 'Citeside is ready in the background.',
    },
    returned: {
      heading: s => `${s} connected`,
      sub: 'Authorization received. You can close this tab and return to Citeside.',
      cta: 'Return to Citeside',
      hint: 'Your schedule will sync automatically.',
    },
    cancelled: {
      heading: s => `${s} connection cancelled`,
      sub: 'No changes were made. You can close this tab or try again from Citeside.',
      cta: 'Return to Citeside',
      hint: 'You can reconnect anytime in Settings.',
    },
    expired: {
      heading: 'Authorization expired',
      sub: s => `This ${s} sign-in session has expired. Return to Citeside and start again.`,
      cta: 'Try again in Citeside',
      hint: 'This tab can be safely closed.',
    },
    invalid: {
      heading: 'Invalid authorization callback',
      sub: 'This link is no longer valid. Return to Citeside to try again.',
      cta: 'Try again in Citeside',
      hint: 'This tab can be safely closed.',
    },
    error: {
      heading: s => `Couldn’t connect ${s}`,
      sub: 'Something went wrong while completing authorization. Return to Citeside to try again.',
      cta: 'Try again in Citeside',
      hint: 'Your existing data and settings are untouched.',
    },
  },
  zh: {
    success: {
      heading: s => `已连接 ${s}`,
      sub: '现在可以关闭此页面并返回 Citeside。',
      cta: '返回 Citeside',
      hint: 'Citeside 已在后台准备就绪。',
    },
    returned: {
      heading: s => `已连接 ${s}`,
      sub: '授权已返回，可以关闭此页面并切回 Citeside 查看连接结果。',
      cta: '返回 Citeside',
      hint: '日程与资料将自动同步。',
    },
    cancelled: {
      heading: s => `已取消连接 ${s}`,
      sub: '未做任何更改。可以关闭此页面，随时在 Citeside 中重新连接。',
      cta: '返回 Citeside',
      hint: '此页面可随时关闭。',
    },
    expired: {
      heading: '授权已过期',
      sub: s => `本次 ${s} 授权会话已过期，请回到 Citeside 重新发起连接。`,
      cta: '返回 Citeside 重试',
      hint: '此页面可随时关闭。',
    },
    invalid: {
      heading: '授权回调无效',
      sub: '此授权链接已失效，请回到 Citeside 重新连接。',
      cta: '返回 Citeside 重试',
      hint: '此页面可随时关闭。',
    },
    error: {
      heading: s => `未能连接 ${s}`,
      sub: '完成授权时出现问题，请回到 Citeside 重试。',
      cta: '返回 Citeside 重试',
      hint: '你的会议记录与设置不受影响。',
    },
  },
  ja: {
    success: {
      heading: s => `${s}を接続しました`,
      sub: 'このタブを閉じて Citeside に戻れます。',
      cta: 'Citeside に戻る',
      hint: 'Citeside の準備が整いました。',
    },
    returned: {
      heading: s => `${s}を接続しました`,
      sub: '認証が完了しました。このタブを閉じて Citeside に戻ってください。',
      cta: 'Citeside に戻る',
      hint: '予定や資料は自動的に同期されます。',
    },
    cancelled: {
      heading: s => `${s}の接続をキャンセルしました`,
      sub: '変更は行われていません。このタブを閉じるか、Citeside からやり直せます。',
      cta: 'Citeside に戻る',
      hint: '設定からいつでも再接続できます。',
    },
    expired: {
      heading: '認証の有効期限が切れました',
      sub: s => `${s}の認証セッションが期限切れです。Citeside に戻ってやり直してください。`,
      cta: 'Citeside で再試行',
      hint: 'このタブは閉じて問題ありません。',
    },
    invalid: {
      heading: '無効な認証コールバックです',
      sub: 'このリンクは無効です。Citeside に戻ってもう一度お試しください。',
      cta: 'Citeside で再試行',
      hint: 'このタブは閉じて問題ありません。',
    },
    error: {
      heading: s => `${s}を接続できませんでした`,
      sub: '認証の完了中に問題が発生しました。Citeside に戻って再試行してください。',
      cta: 'Citeside で再試行',
      hint: '既存のデータと設定はそのまま保持されます。',
    },
  },
};

function statusIcon(tone) {
  if (tone === 'success') {
    return `<div class="icon icon-ok" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path class="check-path" d="M5 13l4.5 4.5L19 7.5"/></svg></div>`;
  }
  if (tone === 'cancelled') {
    return `<div class="icon icon-muted" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/></svg></div>`;
  }
  return `<div class="icon icon-err" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4.5"/><circle cx="12" cy="16.8" r=".7" fill="currentColor" stroke="none"/><path d="M10.3 3.9 2.6 17.3A2 2 0 0 0 4.3 20.3h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/></svg></div>`;
}

function renderOAuthCallbackPage(options = {}) {
  const service = SERVICE_NAMES[options.service] ? options.service : 'google-calendar';
  const status = ['success', 'returned', 'cancelled', 'expired', 'invalid', 'error'].includes(options.status)
    ? options.status
    : 'success';
  const lang = resolveLang(options.lang, options.acceptLanguage);
  const htmlLang = lang === 'zh' ? 'zh-CN' : lang === 'ja' ? 'ja' : 'en';
  const serviceName = SERVICE_NAMES[service][lang] || SERVICE_NAMES[service].en;
  const pack = (COPY[lang] || COPY.en)[status] || COPY.en.success;
  const heading = typeof pack.heading === 'function' ? pack.heading(serviceName) : pack.heading;
  const sub = typeof pack.sub === 'function' ? pack.sub(serviceName) : pack.sub;
  const cta = pack.cta;
  const hint = pack.hint;
  const detail = String(options.detail || '').trim().slice(0, 240);
  const tone = status === 'success' || status === 'returned' ? 'success' : status === 'cancelled' ? 'cancelled' : 'error';
  const returnHref = safeReturnUrl(options.returnUrl);

  return `<!doctype html>
<html lang="${htmlLang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="referrer" content="no-referrer">
<title>${escHtml(heading)} — Citeside</title>
<style>
:root{color-scheme:light dark;--bg-a:#FAF9FF;--bg-b:#F3F0FF;--bg-c:#F8F7FC;--card:rgba(255,255,255,.92);--border:rgba(108,92,231,.14);--shadow:0 24px 64px rgba(45,42,84,.10),0 2px 10px rgba(45,42,84,.04);--ink:#1D1D24;--muted:#676A76;--faint:#8E91A0;--brand:#6C5CE7;--brand-hover:#5845E0;--ok-bg:rgba(22,163,74,.10);--ok-fg:#15803D;--err-bg:rgba(220,38,38,.09);--err-fg:#B91C1C;--muted-bg:rgba(103,106,118,.10);--muted-fg:#525563;--detail-bg:rgba(108,92,231,.05)}
@media (prefers-color-scheme:dark){:root{--bg-a:#111118;--bg-b:#171525;--bg-c:#12121A;--card:rgba(26,26,35,.92);--border:rgba(167,155,255,.16);--shadow:0 24px 64px rgba(0,0,0,.45);--ink:#F3F3F8;--muted:#A1A4B3;--faint:#767988;--brand:#7C6EF0;--brand-hover:#6C5CE7;--ok-bg:rgba(34,197,94,.14);--ok-fg:#4ADE80;--err-bg:rgba(248,113,113,.14);--err-fg:#F87171;--muted-bg:rgba(161,164,179,.14);--muted-fg:#B4B7C5;--detail-bg:rgba(167,155,255,.08)}}
*{box-sizing:border-box}
html,body{height:100%;margin:0}
body{display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","PingFang SC","Hiragino Sans","Segoe UI",sans-serif;color:var(--ink);background:radial-gradient(ellipse 68% 54% at 86% 6%,rgba(123,107,255,.16) 0%,transparent 65%),radial-gradient(ellipse 60% 50% at 12% 94%,rgba(152,168,255,.14) 0%,transparent 62%),linear-gradient(180deg,var(--bg-a) 0%,var(--bg-b) 54%,var(--bg-c) 100%);-webkit-font-smoothing:antialiased}
.card{width:min(420px,100%);padding:38px 34px 32px;border-radius:22px;background:var(--card);border:1px solid var(--border);box-shadow:var(--shadow);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);text-align:center}
.brand{display:inline-flex;align-items:center;gap:8px;margin-bottom:26px;font-size:13px;font-weight:600;letter-spacing:-.01em;color:var(--muted)}
.brand svg{width:22px;height:22px;display:block}
.icon{width:54px;height:54px;margin:0 auto 20px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.icon svg{width:26px;height:26px}
.icon-ok{background:var(--ok-bg);color:var(--ok-fg)}
.icon-err{background:var(--err-bg);color:var(--err-fg)}
.icon-muted{background:var(--muted-bg);color:var(--muted-fg)}
h1{margin:0 0 10px;font-size:20px;font-weight:630;line-height:1.3;letter-spacing:-.022em}
.sub{margin:0 auto;max-width:320px;font-size:14px;line-height:1.6;color:var(--muted)}
.detail{margin:16px auto 0;padding:9px 12px;border-radius:10px;background:var(--detail-bg);font-size:12px;line-height:1.5;color:var(--muted);word-break:break-word}
.actions{margin-top:26px;display:flex;flex-direction:column;align-items:center;gap:12px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:184px;height:40px;padding:0 22px;border:0;border-radius:999px;background:var(--brand);color:#fff;font:560 13.5px/1 inherit;text-decoration:none;cursor:pointer;box-shadow:0 6px 18px rgba(108,92,231,.24);transition:background .15s ease,transform .14s ease,box-shadow .15s ease}
.btn:hover{background:var(--brand-hover);transform:translateY(-1px);box-shadow:0 8px 22px rgba(108,92,231,.30)}
.btn:active{transform:scale(.98)}
.hint{margin:0;font-size:12px;color:var(--faint)}
</style>
</head>
<body>
<main class="card" role="main">
  <div class="brand" aria-label="Citeside">
    <svg viewBox="0 0 28 28" fill="none" aria-hidden="true">
      <rect width="28" height="28" rx="8" fill="#6C5CE7"/>
      <path d="M6.5 14.5h3l2.1-5.5 3.2 10 2.3-6.2 1.8 1.7h2.6" stroke="#fff" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <span>Citeside</span>
  </div>
  ${statusIcon(tone)}
  <h1>${escHtml(heading)}</h1>
  <p class="sub">${escHtml(sub)}</p>
  ${detail ? `<p class="detail">${escHtml(detail)}</p>` : ''}
  <div class="actions">
    <a class="btn" id="return-btn" href="${escHtml(returnHref)}">${escHtml(cta)}</a>
    <p class="hint">${escHtml(hint)}</p>
  </div>
</main>
<script>
(function(){
  var btn=document.getElementById('return-btn');
  if(btn){
    btn.addEventListener('click',function(e){
      try{
        if(window.opener&&!window.opener.closed){window.opener.focus();window.close();e.preventDefault();return;}
        var href=btn.getAttribute('href')||'';
        var u=new URL(href,location.href);
        if((u.hostname==='127.0.0.1'||u.hostname==='localhost'||u.hostname==='[::1]')&&u.pathname.indexOf('/seatnote/')===0){
          e.preventDefault();
          window.close();
          var h=document.querySelector('.hint');
          if(h)h.textContent=${JSON.stringify(lang === 'zh' ? '授权已完成，请切回 Citeside 应用并关闭此标签页。' : lang === 'ja' ? '認証が完了しました。Citeside アプリに戻り、このタブを閉じてください。' : 'Authorization complete. Please switch back to Citeside App and close this tab.')};
          return;
        }
      }catch(_){}
    });
  }
})();
</script>
</body>
</html>`;
}

module.exports = { resolveLang, normalizeLang, renderOAuthCallbackPage };
