'use strict';
// In-app report. The app stores the submission itself.
// This module does not start a mail client.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAX_TEXT = 4000;
const MAX_DIAG = 20000;
const MAX_IMAGE = 1500000;
const MAX_REFINES = 2;
const MAX_ATTACHMENTS = 4;

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function scrubSecrets(value) {
  return String(value || '')
    .replace(/\u0000/g, '')
    .replace(/-----BEGIN [A-Z0-9 ]+PRIVATE KEY-----[\s\S]*?-----END [A-Z0-9 ]+PRIVATE KEY-----/g, '[已隐藏私钥]')
    .replace(/\b(?:sk|pk|rk)-[A-Za-z0-9_-]{8,}\b/g, 'sk-***')
    .replace(/\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{12,}\b/g, 'gh-***')
    .replace(/\bgithub_pat_[A-Za-z0-9_]{12,}\b/g, 'gh-***')
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]{8,}/gi, 'Bearer ***')
    .replace(/\b(api[_-]?key|access[_-]?token|secret|password|passwd|token)\s*[:=]\s*(['"]?)[^\s'",;]{4,}\2/gi, '$1=***');
}

function cleanText(value, max) {
  const text = scrubSecrets(value).trim();
  if (text.length > max) return { error: '内容太长' };
  return { text };
}

function imageBytes(image) {
  if (image == null || image === '') return null;
  if (typeof image !== 'object') return { error: '截图格式不对' };
  const type = String(image.type || '');
  if (type !== 'image/png' && type !== 'image/jpeg') return { error: '截图只接收 PNG 或 JPEG' };
  const raw = String(image.data || '').replace(/^data:[^,]+,/, '').replace(/\s/g, '');
  if (!raw || !/^[A-Za-z0-9+/=]+$/.test(raw)) return { error: '截图格式不对' };
  const buf = Buffer.from(raw, 'base64');
  if (!buf.length || buf.length > MAX_IMAGE) return { error: '截图太大' };
  const png = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
  const jpeg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  if (type === 'image/png' ? !png : !jpeg) return { error: '截图格式不对' };
  return { buf, ext: png ? 'png' : 'jpg' };
}

function wrapSandboxDoc(bodyHtml, scriptJs) {
  return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<style>' +
    '*{box-sizing:border-box;margin:0;padding:0}' +
    'body{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","PingFang SC",sans-serif;background:#141824;color:#eef1f7;font-size:12px;line-height:1.5;padding:8px}' +
    '.bar{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:6px 8px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:8px;margin-bottom:8px}' +
    '.muted{color:#98a2b3;font-size:11px}' +
    '.chip{border:1px solid rgba(110,142,251,.42);background:rgba(110,142,251,.16);color:#dbe4ff;border-radius:7px;padding:3px 8px;font-size:11.5px;cursor:pointer}' +
    '.chip:hover{background:rgba(110,142,251,.28)}' +
    '.panel{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:5px}' +
    '.item{border:0;background:transparent;color:#eef1f7;text-align:left;padding:5px 7px;border-radius:6px;font-size:11.5px;cursor:pointer;display:flex;justify-content:space-between;width:100%}' +
    '.item:hover,.item.cur{background:rgba(110,142,251,.18);color:#dbe4ff}' +
    '.ok{color:#6ee7b7;font-size:11.5px}' +
    '.warn{color:#fca5a5;font-size:11.5px}' +
    '</style></head><body>' + bodyHtml +
    (scriptJs ? '<script>' + scriptJs + '</script>' : '') +
    '</body></html>';
}

function preview(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return { ok: false, status: 400, error: '格式不对' };
  const text = cleanText(body.text, MAX_TEXT);
  if (text.error) return { ok: false, status: 400, error: text.error };
  if (!text.text) return { ok: false, status: 400, error: '请先说说遇到的问题或想要的改进' };
  const refinements = Array.isArray(body.refinements)
    ? body.refinements.map(x => scrubSecrets(x).trim()).filter(Boolean)
    : [];
  const refineNote = typeof body.refineNote === 'string' ? scrubSecrets(body.refineNote).trim() : '';
  if (refineNote) {
    if (refinements.length >= MAX_REFINES) {
      return { ok: false, status: 429, code: 'refine_limit_reached', error: '这条建议已达补充上限，可以直接发送或清空重写' };
    }
    refinements.push(refineNote.slice(0, 400));
  }
  const suffix = refinements.length ? `（已加入补充：${escHtml(refinements[refinements.length - 1])}）` : '';
  const isLite = /小窗|历史|找不到|刚才那场|切回/.test(text.text);
  const isCopy = !isLite && /复制|三句话|3\s*句话|精简|纪要|总结/.test(text.text);
  let title, summary, beforeHtml, afterHtml;
  if (isLite) {
    title = '小窗顶部新增「最近会议」快速切换';
    summary = '你希望在轻巧小窗里不用退回大窗口，就能一键切回刚才那场会。改完后顶部会多一个轻量的「最近会议」下拉入口。';
    beforeHtml = wrapSandboxDoc('<div class="bar"><span>轻巧小窗</span><span class="muted">无历史入口</span></div><div class="panel"><div class="muted">刚结束一场会切到小窗，想翻回去只能先切回大窗口…</div></div>');
    afterHtml = wrapSandboxDoc(
      '<div class="bar"><button type="button" class="chip" id="toggle">🕒 <span id="cur">最近会议 ▾</span></button><span class="muted">小窗内直切</span></div>' +
      '<div class="panel" id="drop"><button type="button" class="item cur" data-name="产品周会 · 刚刚"><span>产品周会</span><span class="muted">刚刚</span></button><button type="button" class="item" data-name="客户沟通 · 今天 11:00"><span>客户沟通</span><span class="muted">今天 11:00</span></button></div>' +
      '<div class="ok" id="st" style="margin-top:6px">已定位：产品周会 · 刚刚 ' + suffix + '</div>',
      'var drop=document.getElementById("drop"),cur=document.getElementById("cur"),st=document.getElementById("st");document.getElementById("toggle").onclick=function(){drop.style.display=drop.style.display==="none"?"flex":"none";};document.querySelectorAll(".item").forEach(function(b){b.onclick=function(){document.querySelectorAll(".item").forEach(function(x){x.classList.remove("cur");});b.classList.add("cur");var n=b.getAttribute("data-name");cur.textContent=n.split(" · ")[0]+" ▾";st.textContent="已平滑切换到："+n;};});'
    );
  } else if (isCopy) {
    title = '会后总结新增「复制 3 句话精简版」';
    summary = '你希望开完会后不用手动删减长纪要，点一下就能拿到可直接发群的 3 句话核心结论。';
    beforeHtml = wrapSandboxDoc('<div class="bar"><span>会后总结</span><span class="muted">仅整篇长文</span></div><div class="panel"><div class="muted">每次发群都要手动挑结论、删细节，容易漏掉下一步。</div></div>');
    afterHtml = wrapSandboxDoc('<div class="bar"><span>会后总结</span><button type="button" class="chip" id="copy">复制 3 句话版</button></div><div class="panel"><div class="ok" id="st">结论 + 负责人 + 下一步已整理好 ' + suffix + '</div></div>', 'document.getElementById("copy").onclick=function(){document.getElementById("st").textContent="✨ 已整理好 3 句话精简结论，可直接粘贴到群里！";};');
  } else {
    title = '改进建议：' + text.text.slice(0, 22) + (text.text.length > 22 ? '…' : '');
    summary = `你希望解决「${text.text.slice(0, 120)}${text.text.length > 120 ? '…' : ''}」。改完后相关入口会放到一眼可见的位置，操作一步到位。`;
    beforeHtml = wrapSandboxDoc('<div class="bar"><span>当前体验</span></div><div class="panel"><div class="muted">「' + escHtml(text.text.slice(0, 90)) + '」</div><div class="warn">当前缺少顺手的直接入口。</div></div>');
    afterHtml = wrapSandboxDoc('<div class="bar"><span>优化后</span><button type="button" class="chip" id="try">点我试一下</button></div><div class="panel"><div class="ok" id="st">高频动作一步到位，不打断当前工作流 ' + suffix + '</div></div>', 'document.getElementById("try").onclick=function(){document.getElementById("st").textContent="✨ 操作已即时生效，顺手不打扰！";};');
  }
  if (refinements.length) summary += ' 另外，已按你的补充加入「' + refinements.join('」「') + '」。';
  return {
    ok: true,
    channel: 'local',
    round: refinements.length + 1,
    remainingRefines: MAX_REFINES - refinements.length,
    maxRefines: MAX_REFINES,
    title,
    summary,
    beforeHtml,
    afterHtml,
    refinements
  };
}

function accept({ dataDir, body, now = () => new Date() }) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return { ok: false, status: 400, error: '格式不对' };
  const text = cleanText(body.text, MAX_TEXT);
  if (text.error) return { ok: false, status: 400, error: text.error };
  const hasAttachments = Array.isArray(body.attachments) && body.attachments.length > 0;
  if (!text.text && !hasAttachments) return { ok: false, status: 400, error: '请先写一点内容' };
  const diag = cleanText(body.diagnostics || '', MAX_DIAG);
  if (diag.error) return { ok: false, status: 400, error: '诊断信息太长' };
  const image = imageBytes(body.image);
  if (image && image.error) return { ok: false, status: 400, error: image.error };

  const savedAttachments = [];
  if (Array.isArray(body.attachments)) {
    if (body.attachments.length > MAX_ATTACHMENTS) return { ok: false, status: 400, error: `最多附带 ${MAX_ATTACHMENTS} 项图片或文件` };
    for (const item of body.attachments) {
      if (!item || typeof item !== 'object') return { ok: false, status: 400, error: '附件格式不对' };
      const safeName = scrubSecrets(String(item.name || '未命名文件')).replace(/[/\\]/g, '_').trim().slice(0, 80) || '未命名文件';
      if (item.isImage && typeof item.dataUrl === 'string') {
        const m = /^data:(image\/(?:png|jpeg));base64,(.+)$/.exec(item.dataUrl);
        if (m) {
          const checked = imageBytes({ type: m[1], data: m[2] });
          if (checked && checked.error) return { ok: false, status: 400, error: checked.error };
          savedAttachments.push({ name: safeName, isImage: true, ext: checked.ext, buf: checked.buf, sizeText: String(item.sizeText || '') });
          continue;
        }
      }
      savedAttachments.push({ name: safeName, isImage: false, sizeText: String(item.sizeText || '') });
    }
  }

  const stamp = now();
  const id = stamp.toISOString().replace(/[-:]/g, '').replace(/\..*/, '') + '-' + crypto.randomBytes(4).toString('hex');
  const dir = path.join(dataDir, 'feedback');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(dir, 0o700); } catch (_) {}
  let imageName = '';
  if (image && image.buf) {
    imageName = id + '.' + image.ext;
    fs.writeFileSync(path.join(dir, imageName), image.buf, { mode: 0o600 });
  }
  const attachmentMeta = [];
  savedAttachments.forEach((a, idx) => {
    if (a.buf) {
      const fileName = `${id}-att-${idx}.${a.ext}`;
      fs.writeFileSync(path.join(dir, fileName), a.buf, { mode: 0o600 });
      attachmentMeta.push({ name: a.name, isImage: true, file: fileName, sizeText: a.sizeText });
    } else {
      attachmentMeta.push({ name: a.name, isImage: false, sizeText: a.sizeText });
    }
  });
  const record = {
    id,
    at: stamp.toISOString(),
    channel: 'app',
    mode: body.mode === 'preview' ? 'preview' : 'direct',
    text: text.text || '（仅附带截图或附件）',
    ...(body.summary ? { summary: scrubSecrets(body.summary).slice(0, 600) } : {}),
    ...(Array.isArray(body.refinements) && body.refinements.length ? { refinements: body.refinements.map(x => scrubSecrets(x).slice(0, 400)) } : {}),
    diagnostics: diag.text,
    image: imageName,
    ...(attachmentMeta.length ? { attachments: attachmentMeta } : {})
  };
  fs.writeFileSync(path.join(dir, id + '.json'), JSON.stringify(record), { mode: 0o600 });
  return { ok: true, saved: true, channel: 'app', id };
}

module.exports = { accept, preview, scrubSecrets };
