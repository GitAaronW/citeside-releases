'use strict';
// Layout owns visibility and panel sizes only. Capture, conversation and document keep their owners.
(()=>{
 if(parent!==window)return;
 const frame=document.getElementById('workspace-frame'),panel=document.getElementById('myagent-panel');
 if(!frame||!panel)return;
 // New workspaces start with the conversation and its working document. The
 // shared transcript tab remains available; explicit prior choices win.
 const state={left:true,right:true};let explicitRight=false,selectedTab='document',transcriptReturn=null;
 // At narrow widths the shared panel replaces the timeline; it never overlays it.
 const panelFull=()=>false;let ended=null,curSid='',liveSid='',recordingSnapshot=null;
 const narrow=()=>window.innerWidth<1100;
 let transcriptRows=[],transcriptNames={},transcriptStart=null,liveTranscript=null;
 const compact=()=>window.innerWidth<=760;
 try{const saved=JSON.parse(localStorage.getItem('tht-meeting-workspace-panels')||'{}');for(const key of ['left','right'])if(typeof saved[key]==='boolean')state[key]=saved[key];explicitRight=typeof saved.right==='boolean';if(['document','transcript','report'].includes(saved.tab))selectedTab=saved.tab;}catch{}
 const maximum={left:640,right:960};
 // 全屏比例：1200 及以下沿用右栏 58%（中窗不变）。到 13 寸全屏 1470 收到 42% 后，
 // 16 寸和外接大屏用同一个比例往上长。上限跟窗口走（48%），不再用 960px 把右栏钉死。
 function rightCap(viewport){const width=Number(viewport);return Math.max(960,Number.isFinite(width)?Math.round(width*0.48):0);}
 // Approved .body: the document column is 300px until the user resizes it.
 function defaultRightWidth(){return 300;}
 window.thtMeetingColumnWidth=viewport=>({right:defaultRightWidth(viewport),cap:rightCap(viewport)});
 const widths={left:Math.round(Math.min(420,Math.max(230,window.innerWidth*.245))),right:defaultRightWidth(window.innerWidth)};
 let rightChosen=false;
 try{const saved=JSON.parse(localStorage.getItem('tht-meeting-workspace-widths')||'{}');for(const key of ['left','right'])if(Number.isFinite(saved[key])){widths[key]=Math.max(key==='left'?220:260,Math.min(key==='right'?rightCap(window.innerWidth):maximum[key],saved[key]));if(key==='right')rightChosen=true;}if(Number.isFinite(saved.ratio)&&saved.ratio>.1&&saved.ratio<.9){widths.ratio=saved.ratio;rightChosen=true;}}catch{}
 const preferred={...state};
 // 复审 V06：文档栏浮层阈值 980 也算一档，跨 980（如 1000→960）同样重新判定，保留用户显式打开的偏好。
 const sizeMode=()=>(compact()?'compact':narrow()?'narrow':'wide')+(panelFull()?':float':'');
 let currentSize=sizeMode();
 function adaptSize(){Object.assign(state,preferred);}
 adaptSize();
 const bar=document.createElement('nav');bar.className='mw-bar';bar.setAttribute('aria-label','会议工作区 / Meeting workspace');
 const homeBack=document.createElement('button');homeBack.type='button';homeBack.id='mw-home';homeBack.className='mw-home';homeBack.innerHTML='<span class="mw-home-chevron">‹</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 11l8-7 8 7M6 10v9h12v-9"/></svg><span class="mw-home-label">主页</span>';homeBack.setAttribute('aria-label','返回主页');
 // Navigation only: the existing home route keeps the recorder and same meeting alive.
 homeBack.onclick=()=>document.querySelector('.dh-home-toggle')?.click();
 // These application destinations belong on Home. Reuse its mounted navigation
 // and the existing handlers; redraws must not remove the two missing links.
 const homeNavigation=document.querySelector('.dh-nav-body');
 function syncHomeNavigation(){
  if(document.body.classList.contains('citeside-home-v16'))return;
  if(!homeNavigation)return;const en=document.documentElement?.lang==='en',settings=homeNavigation.querySelector('.dh-settings');
  for(const [cls,zh,english,path,run] of [
   ['dh-notes','我的笔记','My notes','M5 3h14v18H5z M8 8h8 M8 12h8 M8 16h5',()=>window.thtOpenWorkbench?.('notes')],
   ['dh-history','历史会议','Meeting history','M12 8v5l3 2 M21 12a9 9 0 1 1-3-6.7',()=>document.getElementById('b-hist')?.click()]
  ]){
   let button=homeNavigation.querySelector('.'+cls);
   if(!button){button=document.createElement('button');button.type='button';button.className=cls;button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="'+path+'"/></svg><span></span>';button.onclick=run;homeNavigation.insertBefore(button,settings);}
   const label=en?english:zh,span=button.querySelector('span');if(span.textContent!==label)span.textContent=label;button.title=label;button.setAttribute('aria-label',label);
  }
 }
 syncHomeNavigation();if(homeNavigation)new MutationObserver(syncHomeNavigation).observe(homeNavigation,{childList:true});
 window.addEventListener('tht-language-change',syncHomeNavigation);
 const title=document.createElement('strong');title.textContent='会议 / Meeting';
 const buttons={},rightText=document.createElement('span');
 for(const [key,label] of [['left','实时转写'],['right','产出']]){
  const button=document.createElement('button');button.type='button';button.className='mw-toggle-'+key;
  const left=key==='left';button.innerHTML='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path class="sidebar-fill" d="'+(left?'M9.5 4.5H5.5A2 2 0 0 0 3.5 6.5v11a2 2 0 0 0 2 2h4Z':'M14.5 4.5h4a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-4Z')+'" fill="currentColor" stroke="none"/><rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="'+(left?'M9.5 4v16':'M14.5 4v16')+'"/></svg>';
  button.setAttribute('aria-controls',left?'mw-transcript-panel':'mw-outputs');button.onclick=()=>{stopDrag();state[key]=!state[key];if(key==='right')selectedTab='document';savePanel();layout();};buttons[key]=button;
 }
 const directActions=document.createElement('div');directActions.className='mw-document-actions mw-document-footer';
 const overflowActions=[];let summaryAction=null;
 const live=document.createElement('span');live.className='mw-live-status';live.classList.add('latest');live.hidden=true;const end=document.createElement('button');end.type='button';end.className='mw-end';end.hidden=true;end.onclick=()=>{
  if(curSid&&!ended&&meetingNativeStatus().active!==true&&['stop','fail','asr'].includes(controlState))return recoverInterrupted();
  const stop=document.getElementById('stop'),en=document.documentElement.lang==='en';
  if(!stop||typeof stop.click!=='function'){finishNote.textContent=en?'Stop is unavailable. Refresh and try again.':'停止控制暂不可用，请刷新后重试';return;}
  if(stop.disabled){finishNote.textContent=en?'Ending is already in progress. Please wait.':'正在结束，请稍候';return;}
  if(typeof window!=='undefined'&&window.thtLiveSend&&window.thtLiveSend.cancelAll)window.thtLiveSend.cancelAll();if(recmenu)recmenu.hidden=true;
  finishNote.textContent='';try{stop.click();}catch{finishNote.textContent=en?'Could not stop. Please try again.':'没能停止，请重试';}
 };
 for(const [id,zh,en]of [['mw-summary','总结','Summary'],['mw-notice','最近通知','Recent notification']]){const action=document.createElement('button');action.type='button';action.id=id;const label=()=>{const text=document.documentElement.lang==='en'?en:zh;action.textContent=text;action.setAttribute('aria-label',text);if(id==='mw-notice')action.hidden=!window.thtHasNotice?.();};label();action.onclick=()=>{if(id==='mw-summary'){if(document.body.classList.contains('mw-report-mode')&&!document.body.classList.contains('mw-doc-view'))window.thtLiveReport?.toggleView?.();if(!(state.right&&selectedTab==='document')||outputSelection!=='document'){selectedTab='document';outputSelection='document';state.right=true;transcriptReturn=null;savePanel();layout();}frame.contentDocument?.body?.classList.add('mw-summary-open');frame.contentWindow?.postMessage({type:'tht-summary-toggle',open:true},location.origin);return;}if(id==='mw-notice'){openNotice();return;}document.getElementById(id)?.click();};if(id==='mw-summary'){action.className='mw-summary-entry';summaryAction=action;directActions.append(action);}else{overflowActions.push(action);directActions.append(action);}}
 // Document tools remain directly reachable without an overflow menu.
 const topicAction=document.createElement('button');topicAction.type='button';topicAction.id='mw-track-topic';
 const topicEntry=document.createElement('section');topicEntry.className='mw-topic-entry';topicEntry.dataset.topicEntry='';topicEntry.hidden=true;
 const topicForm=document.createElement('form');topicForm.dataset.topicAdd='';
 const topicLabel=document.createElement('label'),topicInput=document.createElement('input');topicInput.name='topic';topicInput.maxLength=120;topicInput.required=true;
 const topicLabelText=document.createElement('span');topicLabel.append(topicLabelText,topicInput);
 const topicSubmit=document.createElement('button');topicSubmit.type='submit';
 const topicStatus=document.createElement('small');topicStatus.dataset.topicStatus='';topicStatus.setAttribute('role','status');
 topicForm.onsubmit=e=>{e.preventDefault();e.stopPropagation();void window.thtChangeMeetingTopic?.('add','',topicInput.value,topicSubmit);};
 topicForm.append(topicLabel,topicSubmit);topicEntry.append(topicForm,topicStatus);overflowActions.push(topicAction);directActions.append(topicAction);
 const documentEnglish=()=>(frame.contentDocument?.documentElement?.lang||document.documentElement?.lang)==='en';
 const topicLabels=()=>{const en=documentEnglish();topicAction.textContent=en?'Track a topic':'追踪一个话题';topicLabelText.textContent=en?'Topic to follow':'想追踪的话题';topicSubmit.textContent=en?'Add':'新增';topicAction.hidden=!curSid||!!ended;};
 function syncDocumentActions(){
  const en=documentEnglish();
  overflowActions[0].hidden=!window.thtHasNotice?.();
  overflowActions[0].textContent=en?'Recent notification':'最近通知';
  summaryAction.textContent=en?'Summary':'总结';summaryAction.setAttribute('aria-label',summaryAction.textContent);
 }
 const closeTopicEntry=()=>{topicEntry.hidden=true;topicInput.value='';topicStatus.textContent='';delete topicEntry.dataset.topicSession;};
 topicAction.onclick=()=>{if(!curSid||ended)return;topicLabels();topicEntry.dataset.topicSession=curSid;topicEntry.hidden=false;topicInput.focus();};
 topicLabels();
 window.addEventListener('tht-topics-saved',e=>{if(e.detail?.id!==topicEntry.dataset.topicSession)return;closeTopicEntry();topicAction.focus();});
 window.addEventListener('tht-meeting-navigating',()=>{closeTopicEntry();topicAction.hidden=true;});
 window.addEventListener('tht-proactive-data',e=>{const session=e.detail?.session;if(session?.id!==topicEntry.dataset.topicSession||session?.end)closeTopicEntry();if(session?.end)topicAction.hidden=true;else topicLabels();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!topicEntry.hidden){e.preventDefault();closeTopicEntry();topicAction.focus();}});
 document.addEventListener('pointerdown',e=>{if(!topicEntry.hidden&&!topicEntry.contains(e.target)&&e.target!==topicAction)closeTopicEntry();});
 const sub=document.createElement('span');sub.className='mw-sub';sub.hidden=true;
 // Approved recording control: a source picker and one direct recording action.
 const pill=document.createElement('div');pill.className='mw-pill';pill.hidden=true;
 pill.innerHTML='<span class="mw-wave" aria-hidden="true">'+'<i></i>'.repeat(11)+'</span><span class="mw-spin" aria-hidden="true"></span><span class="mw-t">00:00</span><span class="mw-pstate" role="status"></span>';
 const recmenu=document.createElement('div');recmenu.className='mw-recmenu';recmenu.hidden=true;recmenu.setAttribute('role','menu');recmenu.setAttribute('aria-label',document.documentElement.lang==='en'?'Recording options':'录音选项');
 const source=document.createElement('button');source.type='button';source.className='mw-source';source.innerHTML='<svg class="mw-source-mic" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5.5" y="2" width="5" height="8" rx="2.5"/><path d="M3.2 7.8a4.8 4.8 0 0 0 9.6 0M8 12.6V14.5M5.8 14.5h4.4"/></svg><svg class="mw-source-caret" viewBox="0 0 10 10" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 3.8 5 6.3 7.5 3.8"/></svg>';const sourceLabel=document.documentElement.lang==='en'?'Switch audio & microphone':'切换声音与麦克风';source.title=sourceLabel;source.setAttribute('aria-label',sourceLabel);source.setAttribute('aria-haspopup','menu');source.setAttribute('aria-expanded','false');
 let controlState='stop',sourceError='',retryFailed=false;
 const resume=document.createElement('button');resume.type='button';resume.className='mw-resume';resume.hidden=true;
 resume.onclick=async()=>{if(resume.disabled)return;resume.disabled=true;const requestedId=curSid;sourceError='';retryFailed=false;try{if(controlState==='asr'){const result=await window.thtWorkspaceNative.request('asr-retry',{sessionId:requestedId});window.dispatchEvent(new CustomEvent('tht-asr-status',{detail:{sessionId:requestedId,asrStatus:result.asrStatus}}));}else await undoEnd();}catch{if(curSid===requestedId){retryFailed=controlState!=='asr';sourceError=document.documentElement.lang==='en'?'Retry failed. Try again.':'重试未成功，请再试';}}finally{resume.disabled=false;statusSignature='';updateStatus();}};
 const recsep=document.createElement('i');recsep.className='mw-sep';
 const synced=document.createElement('span');synced.className='mw-syncd';synced.hidden=true;
 async function chooseSource(uid){
  const ns=window.thtNativeStatus||{},sid=ns.sessionId;source.disabled=true;sourceError='';
  try{
   const bridge=window.thtWorkspaceNative;if(!bridge)throw Error('unavailable');
   if(!ns.active)await bridge.request('input-preference',{inputUID:uid});
   else{
    const result=await bridge.request('microphone-switch',{sessionId:sid,inputUID:uid}),requestId=result.microphoneChange?.requestId;if(!requestId)throw Error('not accepted');
    let receipt;
    for(let i=0;i<12;i++){await new Promise(resolve=>setTimeout(resolve,500));const next=await bridge.request('status');bridge.update(next);if(next.sessionId!==sid||!next.active)throw Error('meeting changed');if(next.microphoneReceipt?.requestId===requestId){receipt=next.microphoneReceipt;break;}}
    if(!receipt?.ok)throw Error('unconfirmed');
   }
   const cfg=JSON.parse(localStorage.getItem('tht-settings')||'{}');cfg.nativeInputUID=uid;localStorage.setItem('tht-settings',JSON.stringify(cfg));bridge.setInput(uid);recmenu.hidden=true;
  }catch{sourceError=document.documentElement.lang==='en'?'Could not switch input':'输入源未切换';}
  finally{source.disabled=false;source.setAttribute('aria-expanded',String(!recmenu.hidden));statusSignature='';updateStatus();}
 }
 source.onclick=()=>{
  recmenu.hidden=!recmenu.hidden;source.setAttribute('aria-expanded',String(!recmenu.hidden));if(recmenu.hidden)return;
  recmenu.replaceChildren();const ns=window.thtNativeStatus||{};let cfg={};try{cfg=JSON.parse(localStorage.getItem('tht-settings')||'{}');}catch{}const selected=ns.requestedInputUID??cfg.nativeInputUID??'';
  for(const row of [{uid:'',name:document.documentElement.lang==='en'?'Auto':'自动'},...(ns.inputDevices||[])]){const b=document.createElement('button');b.type='button';b.textContent=row.name;b.setAttribute('role','menuitemradio');b.setAttribute('aria-checked',String(row.uid===selected));b.onclick=()=>chooseSource(row.uid);recmenu.append(b);}
  const anchor=pill.getBoundingClientRect(),bounds=bar.getBoundingClientRect(),mw=recmenu.offsetWidth||180,maxLeft=Math.max(8,(bounds.width||window.innerWidth||0)-mw-8);recmenu.style.left=Math.max(8,Math.min(anchor.left-bounds.left,maxLeft))+'px';
 };
 const pause=document.createElement('button');pause.type='button';pause.className='mw-pause';pause.hidden=true;
 pause.onclick=async()=>{const raw=window.thtNativeStatus||{},recordingId=window.thtRecordingMeetingId?.()||(raw.starting?raw.pendingSessionId:raw.active?raw.sessionId:'')||'';if(pause.disabled||!curSid||recordingId!==curSid||raw.captureEnding||!window.thtPauseControl?.state?.()?.available)return;pause.disabled=true;try{await window.thtPauseControl?.toggle?.();}finally{pause.disabled=false;statusSignature='';updateStatus();}};
 pill.append(pause,source,end,resume);
 const intel=document.createElement('button');intel.type='button';intel.className='mw-intel';intel.textContent='主动智能';intel.setAttribute('aria-expanded','false');
 const intelLayer=document.createElement('aside');intelLayer.className='mw-intelligence-layer';intelLayer.hidden=true;document.body.append(intelLayer);
 const intelText=item=>{const text=typeof item==='string'?item:String(item?.text||item?.title||'');return text.trim();};
 window.thtOpenMeetingIntelligence=()=>{intelLayer.hidden=!intelLayer.hidden;intel.setAttribute('aria-expanded',String(!intelLayer.hidden));};
 intel.onclick=()=>window.thtOpenMeetingIntelligence();
 window.addEventListener('tht-proactive-data',e=>{
  const data=e.detail||{},session=data.session||{},id=String(session.id||data.id||'');if(!id||(curSid&&id!==curSid))return;
  intelLayer.dataset.meeting=id;
  const bag=session.nativeInsights||{};
  const lines=[...(Array.isArray(bag.insights)?bag.insights:[]),bag.suggestion].map(intelText).filter(Boolean);
  intelLayer.replaceChildren();
  for(const line of lines){const item=document.createElement('p');item.className='mw-intel-item';item.textContent=line;intelLayer.append(item);}
  if(!lines.length){const empty=document.createElement('p');empty.className='mw-intel-empty';empty.textContent=document.documentElement.lang==='en'?'Nothing new in this meeting yet.':'这场还没有新的判断。';intelLayer.append(empty);}
 });
 window.thtCollapseToMini=()=>{if(window.liveMateNativeWindow!==true)return false;if(typeof window.thtRequestMiniPanel==='function')return window.thtRequestMiniPanel();return false;};
 const transcriptEntry=document.createElement('button');transcriptEntry.type='button';transcriptEntry.id='mw-transcript-entry';transcriptEntry.className='mw-transcript-entry';transcriptEntry.textContent=document.documentElement.lang==='en'?'Transcript':'转写';transcriptEntry.setAttribute('aria-controls','mw-transcript-panel');transcriptEntry.onclick=()=>openTranscript();
 const settingsEntry=document.createElement('button');settingsEntry.type='button';settingsEntry.className='mw-settings-entry';const settingsLabel=document.documentElement.lang==='en'?'Settings':'设置';settingsEntry.setAttribute('aria-label',settingsLabel);settingsEntry.title=settingsLabel;settingsEntry.innerHTML='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>';settingsEntry.onclick=()=>document.getElementById('gear2')?.click();
 const spacer=document.createElement('div');spacer.className='sp';
 const globalActions=document.createElement('div');globalActions.className='mw-global-actions';
 homeBack.classList.add('mw-back');

 const recordingRow=document.createElement('div');recordingRow.className='mw-recording-row';recordingRow.append(pill,recmenu);
 // 0-Friction Top Understanding Bar (P1-CARD-003):
 // Works with zero clicks (defaults to conservative mode at t=0); 1 click switches
 // & locks scenario for this meeting and saves local-only attendee preference.
 const SCENARIO_FALLBACK_MODES=[
  {mode:'active',zh:'积极模式',en:'Active',tagZh:'默认',tagEn:'Default',descZh:'默认主动出卡：覆盖事实核查、讨论盲区、外部案例与跨会记忆冲突',descEn:'Default proactive mode: fact checks, blind spots, external benchmarks & memory conflicts',goalZh:'主动捕捉事实核查、关键盲区、外部对照案例与跨会记忆冲突',goalEn:'Proactively surface fact checks, blind spots, external benchmarks and memory conflicts'},
  {mode:'conservative',zh:'保守模式',en:'Conservative',tagZh:'低打扰',tagEn:'Quiet',descZh:'仅放行硬证据卡（事实核查、跨会记忆冲突），适合只想安静听会时切换',descEn:'Only hard-evidence cards (fact checks & memory conflicts) for minimal interruption',goalZh:'仅在有硬证据（事实核查或跨会记忆冲突）时提醒',goalEn:'Surface only hard-evidence fact checks or cross-meeting memory conflicts'},
  {mode:'interview',zh:'用户调研访谈',en:'User Interview',tagZh:'高频重点',tagEn:'Key mode',descZh:'追踪访谈盲区、未量化细节与外部对照案例',descEn:'Track interview blind spots, unquantified gaps and external references',goalZh:'捕捉未覆盖的访谈盲区、关键事实核查与外部对照案例',goalEn:'Spot uncovered interview blind spots, fact checks and external benchmarks'},
  {mode:'review',zh:'研究型 / 方案评审',en:'Design / Tech Review',tagZh:'高频重点',tagEn:'Key mode',descZh:'注入外部行业案例、对标数据、反例与架构盲区',descEn:'Inject external benchmarks, counterexamples and technical blind spots',goalZh:'找出方案技术盲区、成熟产品对标数据、反例与历史决策冲突',goalEn:'Surface technical blind spots, benchmarks, counterexamples and past decision conflicts'},
  {mode:'client',zh:'客户商务沟通',en:'Client & Sales',tagZh:'',tagEn:'',descZh:'竞品核查、合规背书数据与历史承诺冲突提醒',descEn:'Competitor fact-checks, compliance references and commitment conflicts',goalZh:'核实对方提到的竞品方案与合规依据，警惕历史承诺冲突',goalEn:'Verify competitor claims and compliance facts; catch commitment conflicts'},
  {mode:'1on1',zh:'1:1 沟通',en:'1:1 Check-in',tagZh:'极静',tagEn:'Quiet',descZh:'极静低打扰，仅在记忆冲突或关键事实偏差时开口',descEn:'Ultra-quiet: speak only on memory conflicts or clear factual discrepancies',goalZh:'保持安静，仅在跨会记忆冲突或硬事实偏差时提醒',goalEn:'Stay quiet except for cross-meeting memory conflicts or hard factual discrepancies'},
  {mode:'sync',zh:'常规同步 / 周会',en:'Team Sync',tagZh:'低打扰',tagEn:'Quiet',descZh:'过滤常规进度同步，仅拦记忆冲突与关键事实核查',descEn:'Filter routine updates; interrupt only for memory conflicts or fact checks',goalZh:'安静过滤常规进度播报，只拦跨会记忆冲突与硬事实偏差',goalEn:'Filter routine status updates; flag memory conflicts and hard fact checks only'}
 ];
 let scenarioState=null,scenarioBusy=false,scenarioError='';
 const understandingWrap=document.createElement('div');understandingWrap.className='mw-understanding-wrap';understandingWrap.hidden=true;
 const understandingBtn=document.createElement('button');understandingBtn.type='button';understandingBtn.id='mw-understanding-btn';understandingBtn.className='mw-understanding-bar';understandingBtn.setAttribute('aria-expanded','false');understandingBtn.setAttribute('aria-haspopup','dialog');
 const uBadge=document.createElement('span');uBadge.className='mw-u-badge';
 const uMode=document.createElement('span');uMode.className='mw-u-mode';
 const uSep=document.createElement('span');uSep.className='mw-u-sep';uSep.textContent='·';
 const uGoal=document.createElement('span');uGoal.className='mw-u-goal';
 const uChevron=document.createElement('span');uChevron.className='mw-u-chevron';uChevron.textContent='▾';uChevron.setAttribute('aria-hidden','true');
 understandingBtn.append(uBadge,uMode,uSep,uGoal,uChevron);
 const understandingPop=document.createElement('div');understandingPop.id='mw-understanding-popover';understandingPop.className='mw-understanding-popover';understandingPop.hidden=true;understandingPop.setAttribute('role','dialog');
 const popHead=document.createElement('div');popHead.className='mw-pop-head';
 const popTitle=document.createElement('span');popTitle.className='mw-pop-title';
 const popHint=document.createElement('span');popHint.className='mw-pop-hint';
 popHead.append(popTitle,popHint);
 const popModeGrid=document.createElement('div');popModeGrid.className='mw-mode-grid';
 const goalForm=document.createElement('form');goalForm.className='mw-goal-row';
 const goalInput=document.createElement('input');goalInput.type='text';goalInput.className='mw-goal-input';goalInput.maxLength=200;
 const goalBtn=document.createElement('button');goalBtn.type='submit';goalBtn.className='mw-goal-btn';
 goalForm.append(goalInput,goalBtn);
 const popFoot=document.createElement('div');popFoot.className='mw-pop-foot';
 const popErr=document.createElement('div');popErr.className='mw-pop-err';popErr.hidden=true;popErr.setAttribute('role','status');
 understandingPop.append(popHead,popModeGrid,goalForm,popFoot,popErr);
 understandingWrap.append(understandingBtn,understandingPop);
 function defaultScenarioView(){
  const en=document.documentElement.lang==='en',first=SCENARIO_FALLBACK_MODES[0];
  return {mode:first.mode,label:en?first.en:first.zh,goal:en?first.goalEn:first.goalZh,locked:false,source:'default',sourceLabel:en?'Active':'默认积极',hardEvidenceOnly:false,options:SCENARIO_FALLBACK_MODES.map(m=>({mode:m.mode,label:en?m.en:m.zh,tag:en?m.tagEn:m.tagZh,shortDesc:en?m.descEn:m.descZh,defaultGoal:en?m.goalEn:m.goalZh}))};
 }
 function closeUnderstanding(){understandingPop.hidden=true;understandingBtn.classList.remove('open');understandingBtn.setAttribute('aria-expanded','false');scenarioError='';popErr.hidden=true;}
 function renderUnderstanding(){
  const show=active()&&!!curSid&&!ended;
  understandingWrap.hidden=!show;
  if(!show){closeUnderstanding();return;}
  const en=document.documentElement.lang==='en';
  const sc=scenarioState||defaultScenarioView();
  uBadge.textContent=sc.sourceLabel||(sc.locked?(en?'Locked':'已锁定'):(en?'Active':'默认积极'));
  uBadge.dataset.locked=sc.locked?'1':'0';
  uMode.textContent=sc.label||(en?'Active':'积极模式');
  uGoal.textContent=sc.goal||'';
  uSep.hidden=!sc.goal;
  understandingBtn.setAttribute('aria-label',(en?'Meeting mode: ':'当前会议理解：')+uMode.textContent);
  popTitle.textContent=en?'Meeting mode (optional · 1-click switch)':'当前会议理解（不点也能跑，随时 1 秒切换）';
  popHint.textContent=en?'Applies instantly · Locks for this meeting':'即时生效 · 本场锁定';
  goalInput.placeholder=en?'Optional: add what you most want from this meeting':'可选：补一句本场最想拿到的信息（回车生效）';
  goalBtn.textContent=en?'Apply':'应用';
  goalBtn.disabled=scenarioBusy;
  popFoot.textContent=en?'Corrections stay on this device to remember what meetings this group usually holds.':'纠偏结果只存本机，用于学习这几个人通常开什么会。';
  popErr.textContent=scenarioError;popErr.hidden=!scenarioError;
  if(document.activeElement!==goalInput)goalInput.value=sc.locked&&sc.source==='user'?(sc.goal||''):'';
  const options=Array.isArray(sc.options)&&sc.options.length?sc.options:defaultScenarioView().options;
  popModeGrid.replaceChildren();
  for(const opt of options){
   const b=document.createElement('button');b.type='button';b.className='mw-mode-opt'+(opt.mode===sc.mode?' active':'');b.dataset.pickMode=opt.mode;b.disabled=scenarioBusy;
   const top=document.createElement('div');top.className='mw-mode-opt-top';
   const name=document.createElement('span');name.className='mw-mode-opt-name';name.textContent=opt.label;
   top.append(name);
   if(opt.tag){const tag=document.createElement('span');tag.className='mw-mode-opt-tag';tag.textContent=opt.tag;top.append(tag);}
   const desc=document.createElement('div');desc.className='mw-mode-opt-desc';desc.textContent=opt.shortDesc||'';
   b.append(top,desc);
   b.onclick=()=>applyScenarioOverride({mode:opt.mode});
   popModeGrid.append(b);
  }
 }
 async function applyScenarioOverride(patch){
  if(!curSid||ended||scenarioBusy)return;
  const en=document.documentElement.lang==='en';
  scenarioBusy=true;scenarioError='';renderUnderstanding();
  try{
   let token='';try{token=JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}
   const base=typeof window.relayBase==='function'?window.relayBase():'';
   const res=await fetch(base+'/meeting-scenario?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:curSid,lang:en?'en':'zh',...patch}),signal:AbortSignal.timeout(8000)});
   const data=await res.json();
   if(!res.ok||!data.ok||!data.scenario)throw Error('save_failed');
   scenarioState=data.scenario;
   closeUnderstanding();
  }catch{
   scenarioError=en?'Could not switch mode. Please try again.':'未能切换场景，请重试。';
  }finally{
   scenarioBusy=false;renderUnderstanding();
  }
 }
 understandingBtn.onclick=e=>{
  e.stopPropagation();
  const nextOpen=understandingPop.hidden;
  understandingPop.hidden=!nextOpen;
  understandingBtn.classList.toggle('open',nextOpen);
  understandingBtn.setAttribute('aria-expanded',String(nextOpen));
  if(nextOpen)renderUnderstanding();
 };
 goalForm.onsubmit=e=>{
  e.preventDefault();
  const val=goalInput.value.trim();
  const mode=scenarioState?.mode||'active';
  void applyScenarioOverride({mode,goal:val});
 };
 document.addEventListener('pointerdown',e=>{if(!understandingPop.hidden&&!understandingWrap.contains(e.target))closeUnderstanding();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!understandingPop.hidden){e.preventDefault();e.stopPropagation();closeUnderstanding();understandingBtn.focus?.();}});
 window.addEventListener('tht-meeting-scenario',e=>{const d=e.detail||{};if(d.sessionId&&curSid&&d.sessionId!==curSid)return;if(d.scenario){scenarioState=d.scenario;renderUnderstanding();}});
 window.addEventListener('tht-language-change',renderUnderstanding);

 bar.append(homeBack,buttons.left,title,recordingRow,understandingWrap,spacer);document.body.append(bar);
 document.addEventListener('pointerdown',e=>{if(!recmenu.hidden&&!recmenu.contains(e.target)&&!pill.contains(e.target)){recmenu.hidden=true;source.setAttribute('aria-expanded','false');}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!recmenu.hidden){recmenu.hidden=true;source.setAttribute('aria-expanded','false');source.focus?.();}});
 // Reuse the real status node and recorder handlers; no cloned controls or capture commands.
 function pinLatestLine(){let layer=document.querySelector('.mw-chat-layer');if(!layer){layer=document.createElement('aside');layer.className='mw-chat-layer';document.body.append(layer);}if(live.parentElement===layer)return;const rest=[...layer.children].filter(node=>node!==live);layer.replaceChildren(live,...rest);}
 pinLatestLine();
 function active(){return !document.body.classList.contains('document-home-open')&&frame.hidden===false;}
 // An interrupted meeting can be ended now instead of waiting for automatic recovery.
 // Recording pause/end stay in the pill menu; interrupted-session recovery stays on the bar.
 // After capture, network or server loss, both exits stay on the bar itself.
 const finish=document.createElement('button');finish.type='button';finish.className='mw-finish-saved';finish.hidden=true;
 const finishNote=document.createElement('span');finishNote.className='mw-finish-status';finishNote.setAttribute('role','status');pill.append(finishNote);
 const interruptEnd=document.createElement('button');interruptEnd.type='button';interruptEnd.className='mw-interrupt-end';interruptEnd.hidden=true;
 const organize=document.createElement('button');organize.type='button';organize.className='mw-organize';organize.hidden=true;
 let finishPending=false,finishedId='',audioHealth='';
 window.addEventListener('tht-meeting-navigating',()=>{finish.hidden=true;interruptEnd.hidden=true;organize.hidden=true;finishNote.textContent='';});
 const IMMEDIATE_CAPTURE=new Set(['callback-stalled','input-ended','input-muted','suspended']);
 const DELAYED_CAPTURE=new Set(['disconnected','no-signal']);
 const TRANSIENT_ERROR=/最后一句尚未送达|收尾未确认|正在重试保存|Last sentence not delivered|Final save unconfirmed/i;
 const healthName=v=>String(v&&typeof v==='object'?v.state||'':v||'');
 let slowKey='',slowSince=0,interruptVisible=false;
 const nowMs=()=>typeof window.thtNow==='function'?window.thtNow():Date.now();
 function slowHeld(key){
  const now=nowMs();
  if(!key){slowKey='';slowSince=0;return false;}
  if(key!==slowKey){slowKey=key;slowSince=now;return false;}
  return now-slowSince>8000;
 }
 function meetingNativeStatus(){
  const ns=window.thtNativeStatus||{},id=curSid||window.thtViewedMeetingId||'',pending=String(ns.pendingSessionId||''),session=String(ns.sessionId||''),errorId=String(ns.errorSessionId||'');
  if(id&&![pending,session,errorId].includes(id))return {};
  const ownsCapture=!id||session===id||pending===id;
  return {...ns,captureRecovery:ownsCapture?ns.captureRecovery:'',captureHealth:ownsCapture?ns.captureHealth:'',audioLevel:ownsCapture?ns.audioLevel:0,captureReady:ownsCapture?ns.captureReady:false,starting:!!ns.starting&&(!id||pending===id||(!pending&&session===id)),active:!!ns.active&&(!id||session===id),error:errorId&&id&&errorId!==id?'':ns.error,asrStatus:session&&id&&session!==id?null:ns.asrStatus};
 }
 function meetingInterrupted(st){
  const ns=meetingNativeStatus();
  const names=[healthName(ns.captureHealth),st,healthName(audioHealth)];
  if(names.some(name=>IMMEDIATE_CAPTURE.has(name)))return true;
  if(ns.transcriptionInterrupted||(!ns.asrStatus&&window.thtRecordingMeetingId?.()===curSid&&(window.thtTranscriptionInterrupted||window.thtNativeLinkDown)))return true;
  if(ns.sessionId&&ns.sessionId===curSid&&ns.active===false&&!ns.starting)return true;
  const delayed=names.filter(name=>DELAYED_CAPTURE.has(name));
  const err=String(ns.error||'');
  const errHere=!!err&&(!ns.errorSessionId||ns.errorSessionId===curSid||ns.sessionId===curSid)&&!TRANSIENT_ERROR.test(err);
  return slowHeld([...delayed,errHere?err:''].filter(Boolean).join('|'));
 }
 function recordingSeconds(snapshot,at){
  if(!snapshot)return null;
  const stamp=value=>typeof value==='number'?value:Date.parse(value||''),start=stamp(snapshot.start),end=snapshot.end?stamp(snapshot.end):Number(at);
  if(!Number.isFinite(start)||!Number.isFinite(end))return null;
  const gap=(snapshot.recordingSpans||[]).reduce((sum,span)=>{const previous=stamp(span.previousEnd),continued=stamp(span.continuedAt);return sum+(Number.isFinite(previous)&&Number.isFinite(continued)?Math.max(0,Math.min(end,continued)-Math.max(start,previous)):0);},0);
  return Math.max(0,Math.floor((end-start-gap)/1000));
 }
 const durationText=seconds=>(seconds>=3600?[Math.floor(seconds/3600),Math.floor(seconds/60)%60,seconds%60]:[Math.floor(seconds/60),seconds%60]).map(value=>String(value).padStart(2,'0')).join(':');
 let recordingContinuation=null,clockAnchor=null;
 // Helper audioSeconds restarts for each continued capture; the saved spans retain prior time.
 window.thtAccumulatedCaptureSeconds=(ns,segmentSeconds)=>{
  if(!recordingSnapshot||recordingSnapshot.id!==ns.sessionId)return segmentSeconds;
  if(ns.captureMode==='browser')return recordingSeconds(recordingSnapshot,nowMs())??segmentSeconds;
  if(recordingContinuation?.id===ns.sessionId&&recordingSnapshot.end){const prior=recordingSeconds(recordingSnapshot,nowMs());return prior===null?segmentSeconds:prior+Math.max(0,segmentSeconds);}
  const spans=recordingSnapshot.recordingSpans||[],last=spans.at(-1);
  if(!last)return segmentSeconds;
  const prior=recordingSeconds({...recordingSnapshot,end:last.previousEnd},nowMs());
  return prior===null?segmentSeconds:prior+Math.max(0,segmentSeconds);
 };
 function recordingClock(fallback){
  const ns=meetingNativeStatus(),id=recordingSnapshot?.id||curSid;
  if(!id)return fallback;
  const remember=seconds=>{clockAnchor={id,seconds};return durationText(seconds);};
  if(ns.active&&ns.sessionId===id&&ns.captureMode==='native'&&Number.isFinite(Number(ns.audioSeconds))){
   const frozen=ns.phase==='paused'||ns.captureEnding||window.thtNativeLinkDown||!nativeSeenAt;
   const segment=Math.max(0,Number(ns.audioSeconds))+(frozen?0:Math.min(6000,Math.max(0,nowMs()-nativeSeenAt))/1000);
   return remember(Math.floor(window.thtAccumulatedCaptureSeconds(ns,segment)));
  }
  if(recordingSnapshot?.end){const seconds=recordingSeconds(recordingSnapshot,nowMs());return seconds===null?fallback:remember(seconds);}
  const running=ns.active===true||!!(id&&window.thtRecordingMeetingId?.()===id);
  if(!running||window.thtPauseControl?.state?.()?.paused||['stop','fail'].includes(controlState)){
   if(clockAnchor?.id===id)return durationText(clockAnchor.seconds);
   const parts=String(fallback||'00:00').split(':').map(Number),seconds=parts.every(Number.isFinite)?parts.reduce((n,x)=>n*60+x,0):0;
   return remember(Math.max(0,Math.floor(seconds)));
  }
  const seconds=recordingSeconds(recordingSnapshot,nowMs());return seconds===null?fallback:remember(seconds);
 }
 async function undoEnd(){
  recmenu.hidden=true;const id=curSid;if(!id)return;
  const previousEnd=recordingSnapshot?.end;recordingContinuation={id};
  let accepted;try{accepted=await window.thtStartRecording?.(null,{continueMeetingId:id});}catch{accepted=false;}
  if(curSid!==id){recordingContinuation=null;return;}
  if(accepted===true){
   if(recordingSnapshot?.id===id){const spans=recordingSnapshot.recordingSpans||[];recordingSnapshot={...recordingSnapshot,end:null,recordingSpans:previousEnd&&!spans.some(span=>String(span.previousEnd)===String(previousEnd))?[...spans,{previousEnd,continuedAt:nowMs()}]:spans};}
   ended=null;finishedId='';sourceError='';retryFailed=false;statusSignature='';
  }else{retryFailed=true;sourceError=document.documentElement.lang==='en'?'Could not connect. Retry.':'录音未接上，请重试';}
  recordingContinuation=null;
 }
 function enterWrapup(id){
  try{
   if(!window.thtViewedMeetingId||window.thtViewedMeetingId===id)window.thtViewedMeetingId=id;
   window.thtTranscriptionInterrupted=false;window.thtNativeLinkDown=false;audioHealth='';
   const ns=window.thtNativeStatus||{};
   window.thtNativeStatus={...ns,active:false,starting:false,sessionId:'',pendingSessionId:'',captureHealth:'',error:'',phase:'ended'};
   window.dispatchEvent(new CustomEvent('tht-native-status',{detail:window.thtNativeStatus}));
   const start=ended?.start||Date.now();
   window.dispatchEvent(new CustomEvent('tht-proactive-data',{detail:{id,session:{id,start,end:Date.now()}}}));
   const host=document.querySelector('#myagent-panel .ma-insights')||document.getElementById('myagent-panel');
   window.thtPostmeeting?.mount?.(host,{id,fresh:true});
  }catch{}
  // 待定老化由服务端启动和每小时扫描负责，结束会议不触发。
 }
 async function completeSaved(id){
  const en=document.documentElement.lang==='en';
  finishPending=true;finish.disabled=true;interruptEnd.disabled=true;organize.disabled=true;finishNote.textContent=en?'Saving…':'正在收尾…';
  try{
   let token='';try{token=JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}
   const response=await fetch('/meeting-finish?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id}),signal:AbortSignal.timeout(30000)});
   const result=await response.json();if(!response.ok||!result.ok)throw Error(result.error||String(response.status));
   finishedId=id;
   if(curSid!==id)return;
   finishNote.textContent=result.status==='queued'?(en?'Ended. Organizing saved content…':'已结束，正在整理已保存的内容…'):result.status==='saved'?(en?'Ended and saved. Organization needs retry.':'已结束并保存，整理排队失败，请在会后重试。'):(en?'This meeting has already ended.':'本场已结束。');
   window.dispatchEvent(new CustomEvent('tht-meeting-finished',{detail:{id,status:result.status}}));
   enterWrapup(id);
  }catch(error){if(curSid===id)finishNote.textContent=document.documentElement.lang==='en'?'Could not finish. Click End & organize to retry.':'未能结束，请再点「结束并整理」重试。';}
  finally{finishPending=false;finish.disabled=false;interruptEnd.disabled=false;organize.disabled=false;statusSignature='';updateStatus();}
 }
 finish.onclick=async()=>{
  const id=curSid,en=document.documentElement.lang==='en';
  if(!id||finishPending||!window.confirm(en?'End this interrupted meeting and organize its saved content?':'结束这场中断的会议，并整理已保存的内容？'))return;
  if(typeof window!=='undefined'&&window.thtLiveSend&&window.thtLiveSend.cancelAll)window.thtLiveSend.cancelAll();
  await completeSaved(id);
 };
 async function recoverInterrupted(){
  const id=curSid,en=document.documentElement.lang==='en';
  if(!id||finishPending||ended||id===finishedId)return;
  if(!window.confirm(en?'End this interrupted meeting and organize its saved content?':'结束这场中断的会议，并整理已保存的内容？'))return;
  if(typeof window!=='undefined'&&window.thtLiveSend&&window.thtLiveSend.cancelAll)window.thtLiveSend.cancelAll();
  const ns=window.thtNativeStatus||{};
  const nativeHeld=!!(ns.sessionId===id&&ns.captureMode!=='browser');
  const browserHeld=!nativeHeld&&!!((ns.captureMode==='browser'&&ns.sessionId===id)||window.thtRecordingMeetingId?.()===id);
  if(browserHeld){
   finishPending=true;
   try{
    const stop=document.getElementById('stop');
    const fail=()=>{if(curSid===id)finishNote.textContent=en?'Could not end this meeting. Try again.':'没能结束这场会议，请再试一次';};
    if(!stop||stop.disabled||typeof stop.click!=='function'){fail();return;}
    const hiddenBefore=!!stop.hidden;
    try{stop.click();}catch{fail();return;}
    const live=window.thtNativeStatus||{};
    const released=(window.thtRecordingMeetingId?.()||'')!==id&&!(live.captureMode==='browser'&&live.active&&live.sessionId===id);
    if(!(!!stop.hidden&&!hiddenBefore)&&!released){fail();return;}
    finishedId=id;
    if(curSid===id){finishNote.textContent=en?'Ended. Organizing saved content…':'已结束，正在整理已保存的内容…';window.dispatchEvent(new CustomEvent('tht-meeting-finished',{detail:{id,status:'stop'}}));enterWrapup(id);}
   }finally{finishPending=false;statusSignature='';updateStatus();}
   return;
  }
  if(nativeHeld){
   let closed=false;
   finishPending=true;finish.disabled=true;interruptEnd.disabled=true;organize.disabled=true;finishNote.textContent=en?'Saving…':'正在收尾…';
   try{
    const response=await fetch('/native/end',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sessionId:id}),signal:AbortSignal.timeout(30000)});
    const result=await response.json();if(!response.ok||result.ok===false)throw Error(result.error||String(response.status));
    finishedId=id;closed=true;
    if(curSid===id){finishNote.textContent=en?'Ended. Organizing saved content…':'已结束，正在整理已保存的内容…';window.dispatchEvent(new CustomEvent('tht-meeting-finished',{detail:{id,status:'ended'}}));enterWrapup(id);}
   }catch{}
   finally{finishPending=false;finish.disabled=false;interruptEnd.disabled=false;organize.disabled=false;}
   if(closed){statusSignature='';updateStatus();return;}
  }
  await completeSaved(id);
 }
 interruptEnd.onclick=recoverInterrupted;organize.onclick=recoverInterrupted;
 const handles={};let stopDrag=()=>{};
 const minimum={left:220,right:260};
 function sideBudget(){return Math.max(0,window.innerWidth*.48-24);}
 function sideMinimum(){return Math.min(160,sideBudget()/Math.max(1,Number(state.left)+Number(state.right)));}
 function measured(){
  const min=sideMinimum(),result={left:state.left?Math.max(min,widths.left):0,right:state.right?Math.max(min,widths.right):0},sum=result.left+result.right,n=Number(state.left)+Number(state.right),floor=n*min,budget=sideBudget();
  if(sum>budget&&n){const ratio=Math.max(0,(budget-floor)/Math.max(1,sum-floor));for(const side of ['left','right'])if(state[side])result[side]=min+(result[side]-min)*ratio;}
  return result;
 }
 function widthLimit(key){const other=key==='left'?'right':'left';return Math.max(sideMinimum(),sideBudget()-measured()[other]);}
 function changeWidth(key,delta){const current=measured();for(const side of ['left','right'])if(state[side])widths[side]=current[side];widths[key]=Math.max(sideMinimum(),Math.min(widthLimit(key),measured()[key]+delta));layout();}
 function saveWidths(){try{localStorage.setItem('tht-meeting-workspace-widths',JSON.stringify(widths));}catch{}}
 for(const key of ['left','right']){
  const handle=document.createElement('div');handle.className='mw-splitter mw-splitter-'+key;handle.setAttribute('role','separator');handle.setAttribute('aria-orientation','vertical');handle.setAttribute('aria-label',key==='left'?'调整实时转写宽度 / Resize live transcript':'调整上下文背景宽度 / Resize context background');
  handle.onpointerdown=e=>{
   if(handle.hidden||e.button!==0)return;e.preventDefault();stopDrag();let x=e.clientX,id=e.pointerId;
   const stop=()=>{handle.onpointermove=handle.onpointerup=handle.onpointercancel=handle.onlostpointercapture=null;document.body.classList.remove('mw-resizing');try{handle.releasePointerCapture(id);}catch{}saveWidths();stopDrag=()=>{};};
   stopDrag=stop;document.body.classList.add('mw-resizing');
   try{handle.setPointerCapture(id);}catch{stop();return;}
   handle.onpointermove=next=>{const delta=(next.clientX-x)*(key==='right'?-1:1);x=next.clientX;changeWidth(key,delta);};
   handle.onpointerup=handle.onpointercancel=handle.onlostpointercapture=stop;
  };
  handle.onkeydown=e=>{if(handle.hidden||!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();changeWidth(key,(e.key==='ArrowRight'?20:-20)*(key==='right'?-1:1));saveWidths();};
  handle.ondblclick=()=>{stopDrag();widths[key]=key==='left'?240:300;saveWidths();layout(true);};
  handles[key]=handle;document.body.append(handle);
 }
 window.addEventListener('blur',()=>stopDrag());
 const notice=document.getElementById('notice');
 const noticeLayer=document.createElement('aside');noticeLayer.className='mw-notice-layer';noticeLayer.hidden=true;noticeLayer.setAttribute('role','region');noticeLayer.setAttribute('aria-label','最近通知');
 const noticeClose=document.createElement('button');noticeClose.type='button';noticeClose.className='mw-notice-close';noticeClose.textContent='×';noticeClose.setAttribute('aria-label','关闭最近通知');noticeClose.onclick=closeNotice;noticeLayer.append(noticeClose);document.body.append(noticeLayer);
 function closeNotice(){noticeLayer.hidden=true;if(notice?.parentElement===noticeLayer)document.body.append(notice);}
 function openNotice(){window.thtRestoreNotice?.();if(!notice)return;noticeLayer.append(notice);noticeLayer.hidden=false;}
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!noticeLayer.hidden)closeNotice();});
 window.addEventListener('tht-meeting-navigating',closeNotice);
 window.addEventListener('tht-notice-change',()=>{if(notice?.hidden)closeNotice();});

 const readyBar=document.getElementById('ready-bar');
 let previousReadyHeight=0;
 const readyLandedSessions=new Set();
 function noticeSpace(){
  const readyBounds=readyBar&&!readyBar.hidden?readyBar.getBoundingClientRect?.():null;
  const readyHeight=Math.ceil(readyBounds?.height||0);
  const homeHeight=document.body.classList.contains('document-home-open')&&notice&&!notice.hidden&&!notice.dataset.meetingId&&notice.parentElement!==noticeLayer?Math.ceil(notice.getBoundingClientRect?.()?.height||0):0;
  const value=(readyHeight+homeHeight)+'px';
  const toolbarBottom=Math.max(52,Math.ceil(bar.getBoundingClientRect?.()?.bottom||52));
  const contentTop=Math.max(toolbarBottom,readyHeight?Math.ceil(readyBounds.bottom):toolbarBottom)+'px';
  document.body.style.setProperty('--mw-content-top',contentTop);
  const sid=curSid||window.thtViewedMeetingId||'',ns=meetingNativeStatus();
  const recording=ns.active||ns.starting||window.thtRecordingMeetingId?.()===sid;
  if(sid&&readyHeight&&!previousReadyHeight&&!readyLandedSessions.has(sid)&&!recording){const feed=panel.querySelector('.ma-feed');if(feed)feed.scrollTop=0;}
  if(sid)readyLandedSessions.add(sid);
  previousReadyHeight=readyHeight;
  document.body.style.setProperty('--mw-notice-height',value);
  frame.contentDocument?.body?.style?.setProperty('--mw-notice-height',value);
 }
 window.addEventListener('tht-notice-change',noticeSpace);
 window.addEventListener('resize',noticeSpace);
 if(notice?.getBoundingClientRect&&typeof ResizeObserver!=='undefined')new ResizeObserver(noticeSpace).observe(notice);
 if(readyBar?.getBoundingClientRect&&typeof ResizeObserver!=='undefined')new ResizeObserver(noticeSpace).observe(readyBar);
 if(readyBar&&typeof MutationObserver!=='undefined')new MutationObserver(noticeSpace).observe(readyBar,{attributes:true,attributeFilter:['hidden']});
 frame.addEventListener('load',noticeSpace);
 noticeSpace();
 let lastLayout='',wasMeeting=false;
 // The conversation column is the workspace centre: an unrelated Escape or toggle
 // must not leave it hidden behind an unchanged layout cache.
 function keepConversation(){const has=(el,c)=>!!el?.classList?.contains?.(c);if(panel.hidden||has(panel,'ma-collapsed')||!has(document.body,'myagent-open')){panel.hidden=false;panel.classList?.remove?.('ma-collapsed');document.body.classList?.add?.('myagent-open');}}
 const transcriptSeconds=value=>{const base=window.ThtMeetingTime.meetingTimestamp(0,transcriptStart),at=window.ThtMeetingTime.meetingTimestamp(value,transcriptStart);return Number.isFinite(at)&&Number.isFinite(base)?Math.max(0,(at-base)/1000):0;};
 const mk=(tag,cls)=>{const n=document.createElement(tag);n.className=cls;return n;};
 if(selectedTab==='report')selectedTab='document';
 const tabButtons={};
 tabButtons.transcript=transcriptEntry;tabButtons.document=mk('button','mw-tab-document');
 tabButtons.document.onclick=()=>{selectedTab='document';state.right=true;savePanel();layout();};
 const liteEntry=mk('button','mw-lite-entry');liteEntry.type='button';liteEntry.setAttribute('aria-label','切换到极简窗口');liteEntry.title='切换到极简窗口';liteEntry.innerHTML='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 14h6v6M3 21l7-7M20 10h-6V4M21 3l-7 7M4 10h6V4M3 3l7 7M20 14h-6v6M21 21l-7-7"/></svg>';liteEntry.onclick=()=>window.thtSwitchToLiteMode?.();
 bar.append(buttons.right,liteEntry,settingsEntry);

 // V1.6 sharing dialog. Its entry belongs to the approved Home detail modal.
 function meetingShareFlow({save,send,onState,current,requestId}){
  let attempt=null;
  return {
   async cancel(){const a=attempt;if(!a||a.done||a.cancelled)return;a.cancelled=true;await send({action:'cancel',id:a.id,requestId:a.requestId});},
   async generate(id){if(attempt&&!attempt.done&&!attempt.cancelled)return;const a={id,requestId:requestId(),done:false,cancelled:false};attempt=a;onState('saving');
    try{const saved=await save(id);if(a.cancelled||!current(id)){a.done=true;return;}onState('generating');const result=await send({id,...saved,requestId:a.requestId});
     if(a.cancelled||!current(id)){if(!result.cancelled)await send({action:'cancel',id,requestId:a.requestId});return;}
     if(result.cancelled)return;a.done=true;onState('ready',result);
    }catch(error){a.done=true;if(!a.cancelled||error.code==='share_revoke_unconfirmed')onState('error',error);}
   }
  };
 }
 const cloudShareDialog=mk('dialog','mw-cloud-share-dialog'),cloudShareHeading=mk('h2',''),cloudShareTitle=mk('p','mw-cloud-share-title'),cloudShareFormat=mk('div','mw-cloud-share-format'),cloudShareFormatTitle=mk('strong',''),cloudShareFormatService=mk('span',''),cloudShareTtlWrap=mk('div','mw-cloud-share-ttl'),cloudShareTtlLabel=mk('label',''),cloudShareTtl=mk('select',''),cloudShareDescription=mk('p','mw-cloud-share-description'),cloudShareLabel=mk('label',''),cloudShareLink=mk('input',''),cloudShareHint=mk('p','mw-cloud-share-hint'),cloudShareMdRow=mk('div','mw-cloud-share-md-row'),cloudShareMdCopy=mk('button',''),cloudShareMdFull=mk('button',''),cloudShareMdDownload=mk('button',''),cloudShareFooter=mk('div','mw-cloud-share-footer'),cloudShareReturn=mk('button',''),cloudShareGenerate=mk('button','primary');
 cloudShareDialog.id='mw-cloud-share-dialog';cloudShareDialog.setAttribute('aria-labelledby','mw-cloud-share-heading');cloudShareHeading.id='mw-cloud-share-heading';cloudShareTtl.id='mw-cloud-share-ttl';cloudShareTtlLabel.setAttribute('for',cloudShareTtl.id);cloudShareTtlWrap.hidden=true;cloudShareTtlWrap.append(cloudShareTtlLabel,cloudShareTtl);cloudShareDescription.setAttribute('role','status');cloudShareLink.id='mw-cloud-share-link';cloudShareLink.readOnly=true;cloudShareLabel.setAttribute('for',cloudShareLink.id);cloudShareReturn.type=cloudShareGenerate.type=cloudShareMdCopy.type=cloudShareMdFull.type=cloudShareMdDownload.type='button';cloudShareMdRow.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 4px;';cloudShareMdCopy.style.cssText=cloudShareMdFull.style.cssText=cloudShareMdDownload.style.cssText='padding:7px 12px;border-radius:8px;border:1px solid var(--border,rgba(15,23,42,.15));background:transparent;color:inherit;font-size:13px;cursor:pointer;';cloudShareMdRow.append(cloudShareMdCopy,cloudShareMdFull,cloudShareMdDownload);cloudShareFormat.append(cloudShareFormatTitle,cloudShareFormatService);cloudShareFooter.append(cloudShareReturn,cloudShareGenerate);cloudShareDialog.append(cloudShareHeading,cloudShareTitle,cloudShareFormat,cloudShareTtlWrap,cloudShareDescription,cloudShareLabel,cloudShareLink,cloudShareHint,cloudShareMdRow,cloudShareFooter);document.body.append(cloudShareDialog);
 let cloudShareUrl='',cloudShareId='',cloudSharePrepare=null,cloudShareLang='',cloudShareTtlHours=null;
 const shareEnglish=()=>String(cloudShareLang||document.documentElement?.lang||'').toLowerCase().startsWith('en');
 const shareText=(zh,en)=>shareEnglish()?en:zh;
 function shareTtlOptions(){const snap=window.thtCloudAccountSnapshot?.();const raw=Array.isArray(snap?.shareHours)?snap.shareHours:Array.isArray(snap?.shareTtlOptions)?snap.shareTtlOptions:[];return [...new Set(raw.map(Number).filter(h=>Number.isInteger(h)&&h>=1&&h<=24))].sort((a,b)=>a-b);}
 async function cloudShareRequest(body){let token=window.THT_BOOT?.relayToken||'';if(!token)try{token=JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}const payload=(body&&!body.action&&Number.isInteger(cloudShareTtlHours))?{...body,hours:cloudShareTtlHours}:body;const response=await fetch('/meeting-cloud-share?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json','x-tht-token':token},body:JSON.stringify(payload)});const result=await response.json();if(!response.ok||!result.ok)throw Object.assign(Error(result.error||shareText('云分享未成功，请重试。','Cloud sharing failed. Please retry.')),{code:result.code});return result;}
 const cloudShareFlow=meetingShareFlow({requestId:()=>crypto.randomUUID(),current:id=>cloudShareDialog.open&&cloudShareId===id,
  save:async id=>{if(typeof cloudSharePrepare!=='function')throw Error(shareText('笔记保存入口暂不可用，请重新打开本场笔记。','Note saving is unavailable. Reopen this meeting note.'));return cloudSharePrepare(id);},send:cloudShareRequest,
  onState:(status,value)=>{const busy=status==='saving'||status==='generating';cloudShareGenerate.disabled=busy;cloudShareDescription.hidden=status==='ready';cloudShareDescription.classList.toggle('error',status==='error');
   if(status==='ready'){cloudShareUrl=value.url;cloudShareLink.value=value.url;cloudShareLabel.hidden=cloudShareLink.hidden=false;cloudShareGenerate.textContent=shareText('复制链接','Copy link');}
   else{cloudShareDescription.textContent=status==='saving'?shareText('正在保存当前笔记…','Saving the current note…'):status==='generating'?shareText('正在生成云文档链接…','Creating the cloud document link…'):value?.message||'';if(status==='error'&&!cloudShareDialog.open&&value?.code==='share_revoke_unconfirmed')cloudShareDialog.showModal?.();}
  }
 });
 function closeCloudShare(){cloudShareDialog.close?.();cloudShareFlow.cancel().catch(error=>{cloudShareDescription.textContent=error.message;cloudShareDescription.hidden=false;cloudShareDescription.classList.add('error');cloudShareDialog.showModal?.();});}
 window.thtOpenMeetingCloudShare=context=>{if(!context?.id||typeof context.prepareSavedRevision!=='function')return false;cloudShareLang=['zh','en'].includes(context.lang)?context.lang:'';cloudShareId=String(context.id);cloudSharePrepare=context.prepareSavedRevision;cloudShareUrl='';const forbid=!!(window.CitesidePrivacy?.state?.forbidShare||window.THT_BOOT?.privacy?.forbidShare);const gatedFree=!!(window.CitesideTier?.isCloudManaged?.()&&!window.CitesideTier?.has?.('plus'));const ttls=shareTtlOptions();cloudShareTtlHours=null;if(typeof cloudShareTtl!=='undefined'&&cloudShareTtl){cloudShareTtl.replaceChildren();if(!forbid&&!gatedFree&&ttls.length>=2){cloudShareTtlWrap.hidden=false;cloudShareTtlLabel.textContent=shareText('链接有效期','Link expiry');for(const h of ttls){const opt=document.createElement('option');opt.value=String(h);opt.textContent=h===1?shareText('1 小时','1 hour'):shareText(h+' 小时',h+' hours');cloudShareTtl.append(opt);}cloudShareTtl.value=String(ttls.includes(24)?24:ttls[ttls.length-1]);cloudShareTtlHours=Number(cloudShareTtl.value);cloudShareTtl.onchange=()=>{cloudShareTtlHours=Number(cloudShareTtl.value);};}else if(typeof cloudShareTtlWrap!=='undefined'&&cloudShareTtlWrap){cloudShareTtlWrap.hidden=true;}}cloudShareTitle.textContent=String(context.title||'');cloudShareHeading.textContent=shareText('分享会议笔记','Share meeting notes');cloudShareFormatTitle.textContent=gatedFree?shareText('Markdown 免费分享 · 24 小时云文档（Plus）','Free Markdown · 24h Cloud Link (Plus)'):shareText('24 小时云文档链接','24-hour cloud document link');cloudShareFormatService.textContent=gatedFree?shareText('免费版可直接复制或导出 Markdown；升级 Plus 解锁 24 小时在线只读链接','Copy or export Markdown free; upgrade to Plus for 24h read-only links'):shareText('使用 Citeside 内置云文档服务（同时支持 Markdown 复制/导出）','Using built-in Citeside cloud docs (Markdown copy/export also included)');cloudShareDescription.textContent=forbid?shareText('已开启全局「禁止分享锁」，外发分享已禁用。可在设置 → 隐私中解除。','Outbound sharing is disabled by the global Forbid-Share lock in Settings → Privacy.'):gatedFree?shareText('你可以直接复制或导出 Markdown 分享给同事；24 小时云文档链接为 Plus ($19.90/月) 及以上方案权益。','Copy or export Markdown right now; 24-hour expiring cloud links require Plus ($19.90/mo) or higher.'):shareText('将会议笔记保存为云文档，并生成可分享的 24 小时链接。','Save meeting notes as a cloud document and create a shareable 24-hour link.');cloudShareDescription.hidden=false;cloudShareDescription.classList.remove('error');cloudShareHint.textContent=shareText('链接默认 24 小时有效，仅包含完整文字笔记和已完成研究，不含逐字稿或录音。','Links expire after 24 hours by default and contain full text notes and completed research, without transcripts or recordings.');cloudShareLabel.textContent=shareText('分享链接','Share link');cloudShareLabel.hidden=cloudShareLink.hidden=true;cloudShareLink.value='';if(typeof cloudShareMdCopy!=='undefined'&&cloudShareMdCopy){cloudShareMdCopy.textContent=shareText('复制纪要','Copy summary');cloudShareMdCopy.disabled=forbid;}if(typeof cloudShareMdFull!=='undefined'&&cloudShareMdFull){cloudShareMdFull.textContent=shareText('复制全文','Copy full + transcript');cloudShareMdFull.disabled=forbid;}if(typeof cloudShareMdDownload!=='undefined'&&cloudShareMdDownload){cloudShareMdDownload.textContent=shareText('下载 .md','Download .md');cloudShareMdDownload.disabled=forbid;}cloudShareReturn.textContent=shareText('返回笔记','Back to notes');cloudShareGenerate.textContent=gatedFree?shareText('升级 Plus 解锁','Upgrade to Plus'):shareText('生成链接','Create link');cloudShareGenerate.disabled=forbid;cloudShareDialog.showModal?.();return true;};
 window.thtCloseMeetingCloudShare=closeCloudShare;
 async function shareMarkdown(mode){
  if(!cloudShareId||typeof cloudSharePrepare!=='function')return;
  cloudShareMdCopy.disabled=cloudShareMdFull.disabled=cloudShareMdDownload.disabled=true;
  cloudShareDescription.classList.remove('error');cloudShareDescription.hidden=false;
  cloudShareDescription.textContent=shareText('正在整理 Markdown…','Preparing Markdown…');
  try{
   const saved=await cloudSharePrepare(cloudShareId);
   const res=await cloudShareRequest({action:'markdown',id:cloudShareId,...saved,includeTranscript:mode==='full'});
   const md=String(res.markdown||'');
   if(mode==='copy'||mode==='full'){
    try{await navigator.clipboard.writeText(md);}catch{const ta=document.createElement('textarea');ta.value=md;document.body.append(ta);ta.select();document.execCommand('copy');ta.remove();}
    cloudShareDescription.textContent=mode==='full'?shareText('已复制完整纪要 + 转写全文到剪贴板。','Copied summary + full transcript to clipboard.'):shareText('已复制会议纪要 Markdown 到剪贴板。','Copied summary Markdown to clipboard.');
   }else{
    const safeName=String(res.title||'meeting-notes').replace(/[\\/:*?"<>|]+/g,'-').slice(0,60)||'meeting-notes';
    const blob=new Blob([md],{type:'text/markdown;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=safeName+'.md';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
    cloudShareDescription.textContent=shareText('已导出 Markdown 文件：'+safeName+'.md','Exported Markdown file: '+safeName+'.md');
   }
  }catch(e){
   cloudShareDescription.textContent=e.message||shareText('Markdown 导出失败，请重试。','Markdown export failed. Please retry.');
   cloudShareDescription.classList.add('error');
  }finally{
   const forbid=!!(window.CitesidePrivacy?.state?.forbidShare||window.THT_BOOT?.privacy?.forbidShare);
   cloudShareMdCopy.disabled=cloudShareMdFull.disabled=cloudShareMdDownload.disabled=forbid;
  }
 }
 cloudShareMdCopy.onclick=()=>shareMarkdown('copy');
 cloudShareMdFull.onclick=()=>shareMarkdown('full');
 cloudShareMdDownload.onclick=()=>shareMarkdown('download');
 cloudShareReturn.onclick=closeCloudShare;cloudShareDialog.addEventListener('cancel',event=>{event.preventDefault();closeCloudShare();});cloudShareDialog.addEventListener('click',event=>{if(event.target!==cloudShareDialog)return;const r=cloudShareDialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeCloudShare();});
 cloudShareGenerate.onclick=async()=>{if(window.CitesideTier?.isCloudManaged?.()&&!window.CitesideTier?.has?.('plus')){closeCloudShare();window.CitesideTier.openUpgrade('plus',shareText('24 小时限时分享链接','24-hour expiring share links'));return;}if(cloudShareUrl){try{await navigator.clipboard.writeText(cloudShareUrl);}catch{cloudShareLink.select();}return;}await cloudShareFlow.generate(cloudShareId);};
 window.addEventListener('tht-meeting-navigating',()=>{if(cloudShareDialog.open)closeCloudShare();});

 // The editor is in a same-origin iframe. Adopt the actual controls so their
 // handlers keep the workspace owner while their layout follows the document.
 const trackedTopics=document.createElement('div');trackedTopics.className='mw-tracked-topics';
 trackedTopics.onclick=e=>{const b=e.target.closest('[data-topic-action]');if(!b)return;e.preventDefault();e.stopPropagation();void window.thtChangeMeetingTopic?.(b.dataset.topicAction,b.dataset.topicId,b.dataset.topicTitle,b);};
 window.thtSetDocumentTopics=html=>{if(trackedTopics.dataset.html===html)return;trackedTopics.innerHTML=html;trackedTopics.dataset.html=html;};
 function mountDocumentActions(){
  const doc=frame.contentDocument,host=doc?.querySelector('.mother-document-footer')||doc?.querySelector('.mother-workspace');
  if(typeof host?.append==='function'&&directActions.parentElement!==host)host.append(directActions);
  // Forms and tracked content are document sections, not rows of footer actions.
  if(host?.matches('.mother-document-footer')&&topicEntry.parentElement!==host.parentElement)host.after(topicEntry,trackedTopics);
 }
 let documentToolsObserver;
 function observeDocumentTools(){
  documentToolsObserver?.disconnect();mountDocumentActions();
  if(frame.contentDocument?.body){documentToolsObserver=new MutationObserver(mountDocumentActions);documentToolsObserver.observe(frame.contentDocument.body,{childList:true,subtree:true});}
 }
 frame.addEventListener('load',observeDocumentTools);observeDocumentTools();
 frame.addEventListener('load',()=>{const label=()=>{topicLabels();syncDocumentActions();};frame.contentWindow?.addEventListener('tht-board-language',()=>queueMicrotask(label));label();});
 frame.addEventListener('load',()=>{frame.contentDocument?.addEventListener('keydown',e=>{if(e.key==='Escape'&&!topicEntry.hidden){e.preventDefault();e.stopImmediatePropagation();closeTopicEntry();topicAction.focus();}},true);});
 const txpanel=mk('section','mw-transcript-panel'),txcount=mk('span','mw-txcount'),txlist=mk('div','mw-txlist'),latest=mk('button','mw-back-latest');
 txpanel.id='mw-transcript-panel';txpanel.setAttribute('role','region');txpanel.setAttribute('aria-labelledby','mw-transcript-title');txlist.tabIndex=0;txlist.setAttribute('aria-label','逐句转写 / Transcript sentences');
 latest.type='button';latest.hidden=true;roundLatest(latest);
 const txTitle=mk('h2','mw-transcript-title');txTitle.id='mw-transcript-title';txTitle.textContent=document.documentElement.lang==='en'?'Transcript':'实时转写';
 txpanel.append(txTitle,txcount,txlist,latest);document.body.append(txpanel);
 if(typeof document.body.insertBefore==='function')document.body.insertBefore(txpanel,panel);
 const sideHead=mk('header','mw-side-head'),sideLabel=mk('span','mw-side-label'),fold=mk('button','mw-side-fold');
 sideLabel.id='mw-output-heading';fold.type='button';fold.innerHTML='<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="3" width="12" height="10" rx="2"/><path d="M10 3v10M5.5 6.5 7.5 8l-2 1.5"/></svg>';
 fold.onclick=closeRight;sideHead.append(sideLabel,fold);document.body.append(sideHead);
 // Output navigation owns presentation only; the same editor remains mounted.
 const outputs=mk('section','mw-outputs'),outputList=mk('div','mw-output-list'),outputEmpty=mk('p','mw-output-empty'),outputBack=mk('button','mw-output-back'),outputDetail=mk('article','mw-output-detail'),outputTitle=mk('h4','mw-output-title'),outputBody=mk('div','mw-output-body');
 outputs.id='mw-outputs';outputs.setAttribute('role','region');outputs.setAttribute('aria-labelledby','mw-output-heading');
 outputBack.type='button';outputDetail.append(outputTitle,outputBody);
 // My Task Pre-Execution V2 ("我的任务提前试跑 + 一进两出") inside Outputs panel
 const preexecHost=mk('div','mw-preexec-host');preexecHost.hidden=true;
 const preexecIgnoredBar=mk('div','mw-preexec-ignored');preexecIgnoredBar.hidden=true;
 const handoffScrim=mk('div','mw-handoff-scrim');handoffScrim.hidden=true;document.body.append(handoffScrim);
 outputs.append(preexecHost,outputBack,outputList,outputEmpty,outputDetail,preexecIgnoredBar);document.body.append(outputs);
 let preexecState={prefs:{autoRunPureDraft:true,mcpConnected:false},items:[],ignored:[],activeCount:0,runningCount:0,readyCount:0,ignoredCount:0,silentOtherCount:0};
 let preexecSelectedId='',preexecIgnoredOpen=false,preexecCopiedId='',preexecBusy=false;
 let handoffState={open:false,taskId:'',mode:'copy',checks:{context:true,quote:true,memory:true,draft:true},extra:'',preview:'',sentLabel:''};
 function preexecApiBase(){
  let token='';try{token=JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}
  const base=typeof window.relayBase==='function'?window.relayBase():'';
  return {base,token};
 }
 async function preexecRequest(body){
  const {base,token}=preexecApiBase();
  const res=await fetch(base+'/my-task-preexec?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(15000)});
  const data=await res.json();
  if(!res.ok||!data.ok)throw Error(data.error||'request_failed');
  if(data.state){preexecState=data.state;paintPreexec();}
  return data;
 }
 function findPreexecItem(id){return (preexecState.items||[]).find(x=>x.id===id)||(preexecState.ignored||[]).find(x=>x.id===id)||null;}
 function openPreexecHandoff(taskId){
  const item=findPreexecItem(taskId);if(!item)return;
  handoffState={open:true,taskId,mode:preexecState.prefs?.mcpConnected?'mcp':'copy',checks:{context:true,quote:true,memory:true,draft:item.status==='ready'},extra:'',preview:'',sentLabel:''};
  void refreshHandoffPreview();
  paintHandoffModal();
 }
 function closePreexecHandoff(){handoffState.open=false;handoffScrim.hidden=true;}
 async function refreshHandoffPreview(){
  const item=findPreexecItem(handoffState.taskId);if(!item)return;
  const sid=curSid||window.thtViewedMeetingId||'';
  if(sid){
   try{
    const res=await preexecRequest({action:'handoff',id:sid,taskId:item.id,mode:'copy',checks:handoffState.checks,extra:handoffState.extra});
    handoffState.preview=res.prompt||'';paintHandoffModal();return;
   }catch{}
  }
  const blocks=[`# 任务目标\n请帮我完成：${item.title}`];
  if(handoffState.checks.quote&&item.quote)blocks.push(`# 相关原话摘录\n${item.quote}`);
  if(handoffState.checks.draft&&item.status==='ready'&&item.draft)blocks.push(`# 当前轻初稿\n${item.draft}`);
  if(handoffState.extra.trim())blocks.push(`# 补充要求\n${handoffState.extra.trim()}`);
  handoffState.preview=blocks.join('\n\n');paintHandoffModal();
 }
 function paintHandoffModal(){
  handoffScrim.hidden=!handoffState.open;
  if(!handoffState.open)return;
  const item=findPreexecItem(handoffState.taskId);if(!item){closePreexecHandoff();return;}
  const en=document.documentElement.lang==='en',isMcp=handoffState.mode==='mcp',draftReady=item.status==='ready';
  const card=mk('div','mw-handoff-card');card.setAttribute('role','dialog');card.setAttribute('aria-modal','true');
  const head=mk('div','mw-handoff-head'),htitle=mk('strong','mw-handoff-title'),hclose=mk('button','mw-handoff-close');
  htitle.textContent=en?'Hand off to my AI':'交给我的 AI';hclose.type='button';hclose.textContent='×';hclose.setAttribute('aria-label',en?'Close':'关闭');hclose.onclick=closePreexecHandoff;
  head.append(htitle,hclose);
  const body=mk('div','mw-handoff-body');
  const modeSeg=mk('div','mw-preexec-seg');
  const bCopy=mk('button','mw-preexec-seg-btn'),bMcp=mk('button','mw-preexec-seg-btn');
  bCopy.type=bMcp.type='button';
  bCopy.textContent=en?'Copy full Prompt (0 quota)':'未连 MCP · 复制完整 Prompt（0 消耗额度）';
  bMcp.textContent=en?'Connected MCP · Send directly':'已连 MCP · 直发给我的 AI';
  bCopy.classList.toggle('active',!isMcp);bMcp.classList.toggle('active',isMcp);
  bCopy.onclick=()=>{handoffState.mode='copy';handoffState.sentLabel='';paintHandoffModal();};
  bMcp.onclick=()=>{handoffState.mode='mcp';handoffState.sentLabel='';paintHandoffModal();};
  modeSeg.append(bCopy,bMcp);
  const chkGrid=mk('div','mw-handoff-checks');
  const chkDefs=[
   ['context',en?'Meeting background':'本场会议背景',false],
   ['quote',en?'Relevant quote':'相关原话摘录',false],
   ['memory',en?'Memory constraints':'历史记忆约束',false],
   ['draft',draftReady?(en?'Current draft':'当前轻初稿'):(en?'Current draft (not ready)':'当前轻初稿（尚未生成）'),!draftReady]
  ];
  for(const [k,labelText,disabled] of chkDefs){
   const lbl=mk('label','mw-handoff-chk'+(disabled?' disabled':''));
   const inp=document.createElement('input');inp.type='checkbox';inp.checked=!disabled&&!!handoffState.checks[k];inp.disabled=disabled;
   inp.onchange=()=>{handoffState.checks[k]=inp.checked;handoffState.sentLabel='';void refreshHandoffPreview();};
   const sp=document.createElement('span');sp.textContent=labelText;lbl.append(inp,sp);chkGrid.append(lbl);
  }
  const extraInp=document.createElement('input');extraInp.type='text';extraInp.className='mw-handoff-extra';extraInp.maxLength=400;
  extraInp.placeholder=en?'Additional instructions for external AI (optional)…':'补充对外部 AI 的额外要求（可选）…';
  extraInp.value=handoffState.extra;
  extraInp.oninput=()=>{handoffState.extra=extraInp.value;handoffState.sentLabel='';void refreshHandoffPreview();};
  const prevBox=mk('pre','mw-handoff-preview');prevBox.textContent=handoffState.preview||'';
  body.append(modeSeg,chkGrid,extraInp,prevBox);
  const foot=mk('div','mw-handoff-foot'),noteEl=mk('span','mw-handoff-note'),subBtn=mk('button','mw-preexec-btn pri');
  noteEl.textContent=isMcp?(en?'Send structured context directly via MCP.':'通过 MCP 直发给你的外部 AI。'):(en?'Copy and paste to your AI with 0 Citeside quota used.':'复制后粘贴到常用外部 AI，0 消耗 Citeside 额度。');
  subBtn.type='button';
  subBtn.textContent=handoffState.sentLabel||(isMcp?(en?'Send to my AI':'直发给我的 AI'):(en?'Copy full Prompt':'一键复制完整 Prompt'));
  subBtn.onclick=async()=>{
   const sid=curSid||window.thtViewedMeetingId||'';
   try{
    const res=sid?await preexecRequest({action:'handoff',id:sid,taskId:item.id,mode:handoffState.mode,checks:handoffState.checks,extra:handoffState.extra}):{prompt:handoffState.preview};
    const txt=res.prompt||handoffState.preview||'';
    if(!isMcp&&navigator.clipboard?.writeText)navigator.clipboard.writeText(txt).catch(()=>{});
    handoffState.sentLabel=isMcp?(en?'✓ Sent via MCP':'✓ 已通过 MCP 直发给你的 AI'):(en?'✓ Copied (0 quota)':'✓ 已复制完整 Prompt（0 消耗额度）');
    paintHandoffModal();
   }catch{}
  };
  foot.append(noteEl,subBtn);card.append(head,body,foot);
  handoffScrim.replaceChildren(card);
 }
 handoffScrim.onclick=e=>{if(e.target===handoffScrim)closePreexecHandoff();};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&handoffState.open){e.preventDefault();e.stopPropagation();closePreexecHandoff();}});
 function paintPreexec(){
  const items=Array.isArray(preexecState.items)?preexecState.items:[];
  const ignored=Array.isArray(preexecState.ignored)?preexecState.ignored:[];
  const en=document.documentElement.lang==='en',sid=curSid||window.thtViewedMeetingId||'';
  const hasAny=items.length>0||ignored.length>0;
  preexecHost.hidden=!hasAny;
  preexecIgnoredBar.hidden=ignored.length===0;
  if(!hasAny){preexecHost.replaceChildren();preexecIgnoredBar.replaceChildren();return;}
  preexecHost.replaceChildren();
  const topRow=mk('div','mw-preexec-top');
  const topTitle=mk('span','mw-preexec-heading');topTitle.textContent=en?'My task drafts':'我的任务提前试跑';
  const prefSeg=mk('div','mw-preexec-seg');
  const pAuto=mk('button','mw-preexec-seg-btn'),pAsk=mk('button','mw-preexec-seg-btn');
  pAuto.type=pAsk.type='button';
  pAuto.textContent=en?'Auto draft':'自动后台试跑';pAsk.textContent=en?'Ask first':'先问我再跑';
  const isAuto=preexecState.prefs?.autoRunPureDraft!==false;
  pAuto.classList.toggle('active',isAuto);pAsk.classList.toggle('active',!isAuto);
  pAuto.onclick=()=>{void preexecRequest({action:'pref',id:sid,autoRunPureDraft:true}).catch(()=>{});};
  pAsk.onclick=()=>{void preexecRequest({action:'pref',id:sid,autoRunPureDraft:false}).catch(()=>{});};
  prefSeg.append(pAuto,pAsk);topRow.append(topTitle,prefSeg);preexecHost.append(topRow);
  const selected=preexecSelectedId?items.find(x=>x.id===preexecSelectedId&&x.status==='ready'):null;
  if(selected){
   const detail=mk('div','mw-preexec-detail');
   const back=mk('button','mw-output-back');back.type='button';back.textContent=en?'‹ All drafts':'‹ 返回任务列表';back.onclick=()=>{preexecSelectedId='';paintPreexec();};
   const h=mk('div','mw-preexec-dtitle');h.textContent=selected.title;
   const acts=mk('div','mw-preexec-acts');
   const bCopy=mk('button','mw-preexec-btn pri'),bHand=mk('button','mw-preexec-btn'),bIgn=mk('button','mw-preexec-ghost');
   bCopy.type=bHand.type=bIgn.type='button';
   bCopy.textContent=preexecCopiedId===selected.id?(en?'✓ Copied':'✓ 已复制初稿'):(en?'Copy draft':'复制初稿');
   bCopy.onclick=()=>{if(navigator.clipboard?.writeText)navigator.clipboard.writeText(selected.draft||'').catch(()=>{});preexecCopiedId=selected.id;paintPreexec();setTimeout(()=>{if(preexecCopiedId===selected.id){preexecCopiedId='';paintPreexec();}},1600);};
   bHand.textContent=en?'Hand off to my AI ↗':'交给我的 AI ↗';bHand.onclick=()=>openPreexecHandoff(selected.id);
   bIgn.textContent=en?'Ignore':'忽略';bIgn.onclick=()=>{preexecSelectedId='';void preexecRequest({action:'ignore',id:sid,taskId:selected.id}).catch(()=>{});};
   acts.append(bCopy,bHand,bIgn);
   const doc=mk('div','mw-preexec-doc');
   const paras=Array.isArray(selected.paragraphs)&&selected.paragraphs.length?selected.paragraphs:[selected.draft||''];
   const upd=new Set(selected.updatedIndices||[]);
   paras.forEach((p,idx)=>{const d=mk('div','mw-preexec-para'+(upd.has(idx)?' updated':''));d.textContent=p;doc.append(d);});
   detail.append(back,h,acts,doc);
   if(Array.isArray(selected.thread)&&selected.thread.length){
    const th=mk('div','mw-preexec-thread');
    for(const m of selected.thread){const row=mk('div','mw-preexec-msg '+m.role);row.textContent=(m.role==='ai'?'Citeside：':'')+m.text;th.append(row);}
    detail.append(th);
   }
   const form=document.createElement('form');form.className='mw-preexec-compose';
   const inp=document.createElement('input');inp.type='text';inp.className='mw-preexec-input';inp.maxLength=500;
   inp.placeholder=en?'Enter revision notes or ask a follow-up…':'输入修改意见，或继续追问这条任务…';
   const send=mk('button','mw-preexec-send');send.type='submit';send.textContent='↑';send.disabled=preexecBusy;
   form.onsubmit=async e=>{
    e.preventDefault();const val=inp.value.trim();if(!val||preexecBusy||!sid)return;
    preexecBusy=true;send.disabled=true;inp.value='';
    try{await preexecRequest({action:'revise',id:sid,taskId:selected.id,instruction:val});}
    catch{}finally{preexecBusy=false;paintPreexec();}
   };
   form.append(inp,send);
   const qhint=mk('div','mw-preexec-qhint');qhint.textContent=en?'Revising or asking here uses quota; copying Prompt to your AI uses 0 quota.':'在 Citeside 内继续改写或追问将消耗额度；点上方「交给我的 AI ↗」复制 Prompt 零消耗。';
   detail.append(form,qhint);preexecHost.append(detail);
  }else{
   for(const item of items){
    const card=mk('div','mw-preexec-card '+item.status);
    if(item.status==='pending_confirm'){
     const head=mk('div','mw-preexec-chead'),ttl=mk('div','mw-preexec-ctitle'),nm=mk('button','mw-preexec-ghost');
     ttl.textContent=item.confirmHeadline||item.title;nm.type='button';nm.textContent=en?'Not mine':'不是我的';
     nm.onclick=()=>{void preexecRequest({action:'ignore',id:sid,taskId:item.id}).catch(()=>{});};
     head.append(ttl,nm);
     const acts=mk('div','mw-preexec-acts');
     const bRun=mk('button','mw-preexec-btn pri'),bHand=mk('button','mw-preexec-btn');
     bRun.type=bHand.type='button';
     bRun.textContent=en?'▶ Try draft':'▶ 试跑初稿';bRun.onclick=()=>{void preexecRequest({action:'run',id:sid,taskId:item.id}).catch(()=>{});};
     bHand.textContent=en?'Hand off to my AI ↗':'交给我的 AI ↗';bHand.onclick=()=>openPreexecHandoff(item.id);
     acts.append(bRun,bHand);card.append(head,acts);
    }else if(item.status==='running'){
     const top=mk('div','mw-preexec-rtop');
     const dot=mk('span','mw-preexec-breath');dot.setAttribute('aria-hidden','true');
     const txt=mk('span','mw-preexec-rtxt');txt.textContent=en?'Drafting in background…':'正在后台起草初稿…';
     top.append(dot,txt);
     const sub=mk('div','mw-preexec-rsub');sub.textContent=item.title;
     const acts=mk('div','mw-preexec-acts');
     const bCan=mk('button','mw-preexec-btn'),bHand=mk('button','mw-preexec-btn');
     bCan.type=bHand.type='button';
     bCan.textContent=en?'Cancel':'取消';bCan.onclick=()=>{void preexecRequest({action:'cancel',id:sid,taskId:item.id}).catch(()=>{});};
     bHand.textContent=en?'Hand off to my AI ↗':'交给我的 AI ↗';bHand.onclick=()=>openPreexecHandoff(item.id);
     acts.append(bCan,bHand);card.append(top,sub,acts);
    }else if(item.status==='ready'){
     const row=mk('button','mw-output-item');row.type='button';
     const copy=mk('span','mw-output-copy'),nm=mk('b','mw-output-name'),kd=mk('small','mw-output-kind');
     nm.textContent=item.title;kd.textContent=en?'Draft ready · click to review or revise':'初稿已就绪 · 点击查看、原地改写或交给外部 AI';
     copy.append(nm,kd);row.append(copy);
     row.onclick=()=>{preexecSelectedId=item.id;paintPreexec();};
     card.append(row);
    }
    preexecHost.append(card);
   }
  }
  preexecIgnoredBar.replaceChildren();
  if(ignored.length>0){
   const tog=mk('button','mw-preexec-ign-toggle');tog.type='button';tog.setAttribute('aria-expanded',String(preexecIgnoredOpen));
   tog.textContent=(en?`Ignored (${ignored.length})`:`已忽略 (${ignored.length})`)+(preexecIgnoredOpen?' ▴':' ▾');
   tog.onclick=()=>{preexecIgnoredOpen=!preexecIgnoredOpen;paintPreexec();};
   preexecIgnoredBar.append(tog);
   if(preexecIgnoredOpen){
    const list=mk('div','mw-preexec-ign-list');
    for(const it of ignored){
     const r=mk('div','mw-preexec-ign-row'),nm=mk('span','mw-preexec-ign-name'),rb=mk('button','mw-preexec-restore');
     nm.textContent=it.title;rb.type='button';rb.textContent=en?'Restore as my task':'撤销忽略 / 重新判定为我的任务';
     rb.onclick=()=>{void preexecRequest({action:'restore',id:sid,taskId:it.id}).catch(()=>{});};
     r.append(nm,rb);list.append(r);
    }
    preexecIgnoredBar.append(list);
   }
  }
 }
 window.addEventListener('tht-my-task-preexec',e=>{const d=e.detail||{};if(d.sessionId&&curSid&&d.sessionId!==curSid)return;if(d.state){preexecState=d.state;paintPreexec();}});
 window.addEventListener('tht-language-change',()=>{paintPreexec();paintHandoffModal();});
 const liveOutputs=mk('div','lr-scope');outputList.append(liveOutputs);window.thtLiveResearch?.bind(liveOutputs);window.thtLiveResearch?.bind(outputBody);
 const initialOutputLive=window.thtLiveResearch?.data();
 let outputLive=initialOutputLive?.id===window.thtViewedMeetingId?initialOutputLive:null;
 let outputSelection='',outputDocument=null,outputReport=null,outputMeeting=window.thtViewedMeetingId||'',outputSignature='';
 const outputText=(zh,en)=>document.documentElement.lang==='en'?en:zh;
 function readStoredBookmarks(mid){if(!mid)return [];try{const all=JSON.parse(localStorage.getItem('citeside-meeting-bookmarks-v1')||'{}');return Array.isArray(all[mid])?all[mid]:[];}catch{return [];}}
 function removeStoredBookmark(mid,bmId){if(!mid)return;try{const all=JSON.parse(localStorage.getItem('citeside-meeting-bookmarks-v1')||'{}');const cur=Array.isArray(all[mid])?all[mid]:[];all[mid]=cur.filter(x=>x.id!==bmId);localStorage.setItem('citeside-meeting-bookmarks-v1',JSON.stringify(all));if(typeof CustomEvent==='function')window.dispatchEvent?.(new CustomEvent('tht-bookmarks-updated',{detail:{meetingId:mid}}));}catch{}}
 function outputItems(){
  const viewedId=window.thtViewedMeetingId||'';
  const items=[];
  const seenLr=new Set();
  for(const lr of (outputLive?.items||[])){
   const pres=window.ThtLiveResearch?.researchPresentation?.(lr);
   if(!pres)continue;
   const tk=String(lr.title||'').replace(/\s+/g,' ').trim().slice(0,40).toLowerCase();
   if(tk&&seenLr.has(tk))continue;
   if(tk)seenLr.add(tk);
   if(!pres.hasReport&&['running','queued','refining'].includes(pres.status)){
    const subs=Array.isArray(lr.subs)?lr.subs:[];
    const doneCount=subs.filter(s=>s&&s.state==='done').length;
    items.push({
     id:'lr-active:'+lr.id,rawId:lr.id,kind:'research',
     title:lr.title||outputText('深度研究任务','Deep research'),
     label:subs.length?outputText('深度研究中 · 已查 '+doneCount+'/'+subs.length+' 项','Researching · '+doneCount+'/'+subs.length):outputText('深度研究中…','Researching…'),
     text:lr.conclusion||outputText('正在后台深度研究中，完成后可在此直接打开完整报告。','Deep research is running in the background. Open the full report here once ready.'),
    });
   }
  }
  if(outputDocument?.id&&(ended||(outputDocument.text&&outputDocument.text.trim().length>20))){
   items.push({
    id:'document',rawId:outputDocument.id,kind:'document',
    title:outputDocument.title||outputText('会议纪要文档','Meeting notes'),
    label:outputText('会议纪要文档','Meeting notes'),
    text:outputDocument.text||'',
   });
  }
  for(const b of readStoredBookmarks(viewedId)){
   items.push({
    id:'bm:'+b.id,rawId:b.id,kind:'bookmark',
    title:b.title||outputText('已收藏发现','Bookmarked finding'),
    label:b.semanticBadge?.label||outputText('已收藏发现','Bookmarked'),
    text:b.text||'',
    sources:Array.isArray(b.sources)?b.sources:[],
   });
  }
  return items;
 }
 const outputIcons={document:'<path d="M4 2.5h6.5L14 6v9.5H4zM6.5 9h5M6.5 12h5"/>',research:'<path fill="currentColor" stroke="none" d="M9 1.5l1.7 5.8 5.8 1.7-5.8 1.7L9 16.5l-1.7-5.8L1.5 9l5.8-1.7z"/>',draft:'<path d="M3 15l1-3.5L12.5 3l2.5 2.5L6.5 14z"/>',bookmark:'<path d="M5 3h8a1 1 0 0 1 1 1v12l-5-3.2L4 16V4a1 1 0 0 1 1-1z"/>'};
 function paintOutputs(){
  const viewedId=window.thtViewedMeetingId||'';
  if(outputMeeting!==viewedId){outputMeeting=viewedId;outputLive=null;outputDocument=null;outputReport=null;outputSelection='';}
  if(outputLive?.id!==viewedId)outputLive=null;
  const liveState=window.thtLiveResearch?.state?.(),ownLiveState=liveState?.id===viewedId?liveState:{};
  const liveId=outputSelection.startsWith('live:')?outputSelection.slice(5):'',liveItem=outputLive?.items?.find(i=>i.id===liveId&&window.ThtLiveResearch.researchPresentation(i).hasReport);
  const rows=outputItems(),en=document.documentElement.lang==='en',item=rows.find(r=>r.id===outputSelection)||(outputSelection==='document'&&outputDocument?.id?{...outputDocument,id:'document',kind:'document'}:null);
  const reports=(outputLive?.items||[]).filter(i=>window.ThtLiveResearch?.researchPresentation(i).hasReport);
  const liveContent=reports.length>0;
  if(!item&&!liveItem)outputSelection='';
  const signature=JSON.stringify([rows,en,outputSelection,outputLive,ownLiveState.deletedTodo||'']);
  if(signature!==outputSignature){outputSignature=signature;
   outputList.replaceChildren(...rows.map(row=>{
    const b=mk('button','mw-output-item'),icon=mk('span','mw-output-icon '+row.kind),copy=mk('span','mw-output-copy'),name=mk('b','mw-output-name'),label=mk('small','mw-output-kind');
    b.type='button';b.dataset.kind=row.kind;b.dataset.outputId=row.id;
    icon.setAttribute('aria-hidden','true');icon.innerHTML='<svg viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'+(outputIcons[row.kind]||outputIcons.bookmark)+'</svg>';
    name.textContent=row.title||row.text.split('\n')[0];label.textContent=row.label;b.title=name.textContent;copy.append(name,label);b.append(icon,copy);b.onclick=()=>{outputSelection=row.id;outputs.scrollTop=0;layout(true);};return b;
   }));
   if(liveContent){liveOutputs.innerHTML=window.ThtLiveResearch.outputHtml({...outputLive,minutes:{},items:reports},{});outputList.prepend(liveOutputs);}else liveOutputs.innerHTML='';
   outputTitle.textContent=liveItem?'':item?.title||'';
   if(!liveItem)delete outputBody.dataset.lrSignature;
   if(liveItem){const cached=window.thtLiveResearch?.data();if(cached?.id===viewedId)window.thtLiveResearch.renderReport(outputBody,liveId);else{delete outputBody.dataset.lrSignature;outputBody.innerHTML=window.ThtLiveResearch.reportHtml({...liveItem,meetingTitle:outputLive.title},{readonly:true});}}else if(item?.kind==='bookmark'){
    outputBody.replaceChildren();
    const p=document.createElement('p');p.className='mw-bm-detail-body';p.textContent=item.text||'';outputBody.append(p);
    if(item.sources?.length){
     const ul=document.createElement('ul');ul.className='mw-bm-detail-sources';
     for(const s of item.sources){if(!s?.url)continue;try{const u=new URL(s.url);if(!['http:','https:'].includes(u.protocol))continue;const li=document.createElement('li'),a=document.createElement('a');a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';a.textContent=(s.title||s.name||u.hostname)+' ↗';li.append(a);ul.append(li);}catch{}}
     if(ul.children.length)outputBody.append(ul);
    }
    const rm=document.createElement('button');rm.type='button';rm.className='mw-bm-remove';rm.textContent=outputText('从收藏移除','Remove bookmark');rm.onclick=()=>{removeStoredBookmark(viewedId,item.rawId);outputSelection='';paintOutputs();};outputBody.append(rm);
   }else if(item?.kind==='research'&&window.ThtSafeMarkdown){outputBody.innerHTML=window.ThtSafeMarkdown.markdown(item.text||'');}else outputBody.textContent=item?.text||'';

  }
  outputEmpty.textContent=outputText('点击发现卡片的「深度研究」或「收藏」，以及会后自动整理纪要，都会沉淀在这里。','Deep research reports, bookmarked findings, and post-meeting summaries appear here.');
  outputBack.textContent=outputText('‹ 全部产出','‹ All outputs');outputBack.hidden=!!liveItem||!item;
  outputList.hidden=!!item||!!liveItem;outputEmpty.hidden=!!rows.length||!!item||liveContent;outputDetail.hidden=(!item&&!liveItem)||item?.kind==='document';
  const open=active()&&state.right&&selectedTab==='document',editor=open&&item?.kind==='document';
  outputs.hidden=!open;outputs.classList.toggle('mw-outputs-editor',!!editor);
  document.body.classList.toggle('mw-output-editor',!!editor);document.body.classList.toggle('mw-output-browser',!!(open&&!editor));
  const artifactOpen=Boolean(open&&liveItem);
  document.body.classList.toggle('mw-artifact-expanded',artifactOpen);
  if(!artifactOpen)document.body.classList.remove('mw-artifact-wide');
 }
 window.thtToggleArtifactWide=()=>{if(!document.body.classList.contains('mw-artifact-expanded'))return false;return document.body.classList.toggle('mw-artifact-wide');};
 outputBack.onclick=()=>{const previous=outputSelection;outputSelection='';outputs.scrollTop=0;document.body.classList.remove('mw-artifact-expanded','mw-artifact-wide');layout(true);outputList.children&&[...outputList.children].find(b=>b.dataset.outputId===previous)?.focus?.();};
 function clearOutputs(){outputLive=null;outputDocument=null;outputReport=null;outputSelection='';outputMeeting='';preexecSelectedId='';preexecIgnoredOpen=false;closePreexecHandoff();document.body.classList.remove('mw-artifact-expanded','mw-artifact-wide');paintOutputs();paintPreexec();}
 window.addEventListener('tht-bookmarks-updated',()=>paintOutputs());
 window.addEventListener('tht-meeting-navigating',clearOutputs);
 window.addEventListener('tht-proactive-data',e=>{const d=e.detail||{},id=d.id||d.session?.id;if(!id||id!==window.thtViewedMeetingId||d.session?.id&&d.session.id!==id)return;
  if(outputMeeting&&outputMeeting!==id)clearOutputs();outputMeeting=id;
  if(d.source?.motherDocumentId&&outputDocument?.id!==d.source.motherDocumentId)outputDocument={id:d.source.motherDocumentId,title:d.source.title||d.session?.title||''};
  if(d.session?.myTaskPreexec){preexecState=d.session.myTaskPreexec;paintPreexec();}
  paintOutputs();
 });
 window.thtOpenResearchReport=id=>{if(outputLive?.id!==window.thtViewedMeetingId||!outputLive.items?.some(item=>item.id===id&&window.ThtLiveResearch.researchPresentation(item).hasReport))return;outputSelection='live:'+id;selectedTab='document';state.right=true;savePanel();layout(true);};
 window.thtCloseResearchReport=()=>{outputSelection='';document.body.classList.remove('mw-artifact-expanded','mw-artifact-wide');layout(true);};
 window.addEventListener('tht-live-research-updated',e=>{if(e.detail?.id!==window.thtViewedMeetingId)return;if(outputMeeting!==e.detail.id)clearOutputs();outputLive=e.detail;paintOutputs();});
 window.addEventListener('tht-report-updated',e=>{const d=e.detail||{};if(!d.id||d.id!==window.thtViewedMeetingId)return;if(outputMeeting!==d.id)clearOutputs();outputReport=d.report;paintOutputs();});
 window.addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow||e.data?.type!=='tht-output-document'||e.data.meetingId!==window.thtViewedMeetingId)return;if(outputMeeting!==e.data.meetingId)clearOutputs();outputDocument=e.data.document;paintOutputs();});
 let txSig='',following=true,highlightTimer=0;
 let txSession='',txPartial=null,txFinals=[],txNodes=[],txLines=[],txRowNodes=[];
 const txSpeaker=row=>String(row?.speaker??row?.spk??row?.who??'');
 const txSegment=row=>String(row?.id??row?.seg??row?.segId??'');
 const txNormText=row=>String(row?.text||'').replace(/\s+/g,' ').trim();
 const txSameRow=(a,b)=>{const sa=txSegment(a),sb=txSegment(b);if(sa&&sb&&sa===sb)return true;const ta=txNormText(a),tb=txNormText(b);return !!ta&&ta===tb;};
 function clearTxPartial(){if(!txPartial)return;txPartial=null;fillTx();}
 function savePanel(){preferred.left=state.left;preferred.right=state.right;explicitRight=true;try{localStorage.setItem('tht-meeting-workspace-panels',JSON.stringify({left:state.left,right:state.right,tab:selectedTab}));}catch{}}
 function closeRight(){stopDrag();state.right=false;transcriptReturn=null;savePanel();layout();tabButtons[selectedTab]?.focus?.();}

 function toLatest(){following=true;latest.hidden=true;txlist.scrollTop=txlist.scrollHeight;}
 txlist.onscroll=()=>{following=txlist.scrollHeight-txlist.scrollTop-txlist.clientHeight<40;latest.hidden=following;};latest.onclick=toLatest;
 function openTranscript(at){
  state.left=true;savePanel();layout();fillTx();
  if(at===undefined){toLatest();return;}
  const seconds=transcriptSeconds(at);let index=transcriptRows.findIndex((r,i)=>seconds>=transcriptSeconds(r.atSec??r.t??r.at)&&(i===transcriptRows.length-1||seconds<transcriptSeconds(transcriptRows[i+1].atSec??transcriptRows[i+1].t??transcriptRows[i+1].at)));
  if(index<0&&transcriptRows.length)index=0;
  const row=txRowNodes[index];if(!row)return;
  following=false;latest.hidden=false;row.scrollIntoView?.({block:'center'});clearTimeout(highlightTimer);
  for(const n of txlist.children)n.classList.remove('mw-source-highlight');row.classList.add('mw-source-highlight');highlightTimer=setTimeout(()=>row.classList.remove('mw-source-highlight'),2000);
 }
 function toggleTranscript(){state.left=!state.left;savePanel();layout();}
 window.thtOpenTranscript=openTranscript;
 // Render the source transcript, even while its old iframe panel is folded.
 function transcriptClock(value){return window.ThtMeetingTime.meetingClock(value,transcriptStart);}
 function transcriptSpeaker(row,rows,names,en){
  const key=String(row.speaker??row.spk??row.who??'');
  const name=names?.[key]||row.speakerIdentity?.name;
  if(typeof name==='string'&&name.trim()&&!/^(?:vp-)?[a-f0-9-]{32,}$/i.test(name.trim())&&!/^\d+$/.test(name.trim()))return name.trim();
  const fixed=window.ThtSpeakerLabels.defaults(en,window.__roomMode);
  if(Object.hasOwn(fixed,key))return fixed[key];
  if(!key.trim())return '';
  const ids=[...new Set(rows.map(r=>String(r.speaker??r.spk??r.who??'')).filter(id=>id.trim()&&!Object.hasOwn(fixed,id)))];
  return (en?'Speaker ':'说话人 ')+(ids.indexOf(key)<0?'?':ids.indexOf(key)+1);
 }
 // Reconcile sentence nodes in place. Live finals occupy their future source
 // index until the authoritative snapshot arrives; they never enter stored data.
 function fillTx(){
  const en=document.documentElement.lang==='en';
  const recentSaved=transcriptRows.slice(-8);
  txFinals=txFinals.filter(item=>item.index>=transcriptRows.length&&!recentSaved.some(saved=>txSameRow(saved,item.row)));
  const rows=[...transcriptRows,...txFinals.map(item=>item.row)];
  if(txPartial&&rows.length&&txSameRow(rows[rows.length-1],txPartial))txPartial=null;
  if(txPartial)rows.push(txPartial);
  const sig=JSON.stringify([txSession,rows,transcriptNames,en]);if(sig===txSig)return;txSig=sig;
  const oldScroll=txlist.scrollTop;
  const count=transcriptRows.length+txFinals.length;
  const countText=count?(en?count+' lines':count+' 句'):'';if(txcount.textContent!==countText)txcount.textContent=countText;
  if(!rows.length){for(const line of txLines)line.node.remove();txLines=[];txNodes=[];txRowNodes=[];if(!txlist.children.length){const p=mk('p','mw-txempty');p.textContent=en?'Nothing transcribed yet.':'还没有转写';txlist.append(p);}return;}
  if(!txLines.length)txlist.replaceChildren();
  let group=-1,offset=0,previous='';txRowNodes=[];
  rows.forEach((row,i)=>{
   const partial=row===txPartial,key=txSpeaker(row);
   if(i===0||!key||key!==previous){group++;offset=0;}
   previous=key;
   let line=txLines[group];
   if(!line){const node=mk('div','mw-ln'),label=mk('span','mw-lt'),body=document.createElement('p');node.append(label,body);line={node,label,body};txLines.push(line);txlist.append(node);}
   if(i===0||txRowNodes[i-1]!==line.node){const label=[transcriptClock(row.at??row.atSec??row.t),transcriptSpeaker(row,rows,transcriptNames,en)].filter(Boolean).join(' · ');if(line.label.textContent!==label)line.label.textContent=label;}
   let text=txNodes[i];if(!text){text=document.createElement('span');txNodes.push(text);}
   const value=(txRowNodes[i-1]===line.node?' ':'')+(frame.contentWindow?.thtProfileDisplay?.(row.text||'')??(row.text||''));
   if(text.textContent!==value)text.textContent=value;
   const cls=partial?'mw-txpartial':'';if(text.className!==cls)text.className=cls;
   if(line.body.children[offset]!==text)line.body.insertBefore(text,line.body.children[offset]||null);offset++;
   txRowNodes.push(line.node);
  });
  while(txNodes.length>rows.length)txNodes.pop().remove();
  while(txLines.length>group+1)txLines.pop().node.remove();
  if(following)toLatest();else{txlist.scrollTop=oldScroll;latest.hidden=false;}
 }
 function paintPanel(on){const open=!!(on&&state.right),transcript=!!(on&&state.left);
  transcriptEntry.hidden=false;directActions.hidden=selectedTab!=='document';if(selectedTab!=='document'||!open)closeTopicEntry();
  mountDocumentActions();txpanel.hidden=!transcript;document.body.classList.toggle('mw-transcript-visible',transcript);
  for(const [name,b] of Object.entries(tabButtons)){b.setAttribute('aria-selected',String(open&&selectedTab===name));b.setAttribute('aria-pressed',String(open&&selectedTab===name));b.textContent=document.documentElement.lang==='en'?(name==='transcript'?'Transcript':'Outputs'):(name==='transcript'?'完整转写':'产出内容');b.setAttribute('aria-label',b.textContent);b.tabIndex=0;}
  paintOutputs();sideHead.hidden=!open;sideLabel.textContent=tabButtons[selectedTab]?.textContent||'';fold.setAttribute('aria-label',document.documentElement.lang==='en'?'Collapse sidebar':'收起侧栏');fold.title=document.documentElement.lang==='en'?'Collapse sidebar':'收起侧栏';
  if(open)fillTx();updateSubtitle();
 }
 live.tabIndex=0;live.setAttribute('role','button');live.title='打开完整转写（T）';live.onclick=()=>openTranscript();live.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openTranscript();}};
 // One owner for the optional report and existing document/transcript bay.
 window.thtMeetingPanel={getState:()=>({open:active()&&state.right,view:selectedTab}),show:view=>{
  if(!active()||!['document','report'].includes(view))return false;
  stopDrag();selectedTab='document';outputSelection=view==='report'?(outputItems().find(i=>i.kind==='research')?.id||''):'document';state.right=true;transcriptReturn=null;savePanel();layout();return true;
 }};
 window.thtMeetingSid=()=>active()?curSid:'';
 const loading=mk('div','mw-loading');loading.hidden=true;loading.setAttribute('role','status');document.body.append(loading);
 let meetingLoadTimer=0,loadingMeeting='';
 function waitForMeeting(){
  clearTimeout(meetingLoadTimer);
  meetingLoadTimer=setTimeout(()=>{
   if(loading.hidden||loadingMeeting!==window.thtViewedMeetingId)return;
   loading.dataset.state='failed';title.textContent=document.documentElement.lang==='en'?'Could not open meeting':'会议未能打开';
   loading.textContent=document.documentElement.lang==='en'?'Could not open meeting.':'会议暂时未能打开。';
   const retry=mk('button','mw-load-retry'),home=mk('button','mw-load-home');retry.type=home.type='button';
   retry.textContent=document.documentElement.lang==='en'?'Retry':'重试';home.textContent=document.documentElement.lang==='en'?'Back to home':'返回首页';
   retry.onclick=()=>{loading.dataset.state='loading';title.textContent=document.documentElement.lang==='en'?'Loading…':'正在打开…';loading.textContent=document.documentElement.lang==='en'?'Opening meeting…':'正在打开会议…';window.thtOpenMeeting?.(loadingMeeting);waitForMeeting();};
   home.onclick=()=>{clearTimeout(meetingLoadTimer);loading.hidden=true;document.querySelector('.dh-home-toggle')?.click();};loading.append(retry,home);
  },18000);
 }
 window.addEventListener('tht-meeting-navigating',()=>{loadingMeeting=window.thtViewedMeetingId;loading.dataset.state='loading';waitForMeeting();loading.textContent=document.documentElement.lang==='en'?'Opening meeting…':'正在打开会议…';loading.hidden=false;liveTranscript=null;transcriptRows=[];txPartial=null;txFinals=[];txSession='';following=true;transcriptReturn=null;curSid='';ended=null;recordingSnapshot=null;sourceError='';retryFailed=false;scenarioState=null;scenarioError='';closeUnderstanding();renderUnderstanding();title.textContent=document.documentElement.lang==='en'?'Loading…':'正在打开…';live.textContent='';live.hidden=true;txSig='';fillTx();});
 window.addEventListener('tht-profile-updated',()=>{txSig='';live.dataset.k='';fillTx();updateSubtitle();});
 function viewedSnapshot(data){const id=data?.session?.id;return !!id&&(!window.thtViewedMeetingId||id===window.thtViewedMeetingId)&&(!data.id||data.id===id);}
 window.addEventListener('tht-proactive-data',e=>{if(!viewedSnapshot(e.detail))return;clearTimeout(meetingLoadTimer);loading.hidden=true;const sid=String(e.detail.session?.id||'');if(sid!==txSession){txSession=sid;txPartial=null;txFinals=[];txlist.replaceChildren();txNodes=[];txLines=[];txRowNodes=[];}transcriptStart=e.detail.session?.start??e.detail.session?.startTs;transcriptNames=e.detail.session?.names||{};transcriptRows=e.detail.session?.fullTranscript||e.detail.session?.transcript||[];if(e.detail.session?.meetingScenario)scenarioState=e.detail.session.meetingScenario;txSig='';fillTx();updateSubtitle();renderUnderstanding();});
 document.addEventListener('keydown',e=>{if(!active()||e.defaultPrevented||e.metaKey||e.ctrlKey||e.altKey)return;
  const t=e.target;if(t&&(t.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName||'')))return;if(document.querySelector('dialog[open]'))return;
  if(e.key==='Escape'&&ended&&recmenu.hidden){e.preventDefault();homeBack.click();return;}
  if(e.key==='Escape'&&state.right){if(!recmenu.hidden)return;e.preventDefault();closeRight();return;}
  // Esc peels one layer at a time: menus, then the right panel, then back to home.
  if(e.key==='Escape'){if(!recmenu.hidden||document.querySelector('details[open],.ma-add-menu'))return;const home=document.querySelector('.dh-home-toggle');if(!home||home.hidden)return;e.preventDefault();home.click();return;}
  if((e.key==='t'||e.key==='T')&&!e.repeat){e.preventDefault();toggleTranscript();return;}
 });
 // Keyboard events from the document iframe do not bubble into the workspace.
 window.addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow)return;if(e.data?.type==='tht-panel-key'){if(e.data.key==='Escape'){if(ended)homeBack.click();else closeRight();}else if(e.data.key==='t')toggleTranscript();}if(e.data?.type==='tht-panel-transcript')openTranscript(e.data.at);});

 const handoffKey='citeside-meeting-view-v1';let restoredViewSession='';
 function restoreMeetingView(){const id=window.thtViewedMeetingId||curSid;if(!id||restoredViewSession===id)return;restoredViewSession=id;try{const saved=JSON.parse(sessionStorage.getItem(handoffKey)||'null');if(saved?.version!==1||saved.sessionId!==id)return;for(const side of ['left','right']){if(typeof saved.full?.[side]==='boolean')state[side]=preferred[side]=saved.full[side];if(Number.isFinite(saved.full?.widths?.[side]))widths[side]=saved.full.widths[side];}}catch{}}
 window.thtCaptureMeetingViewState=()=>{const sessionId=window.thtViewedMeetingId||curSid;if(!sessionId)return null;try{const old=JSON.parse(sessionStorage.getItem(handoffKey)||'null'),prior=old?.version===1&&old.sessionId===sessionId?old:{},agent=window.thtCaptureMeetingChatState?.()||{},draft=agent.draft??document.querySelector('.ma-shared-form textarea')?.value??prior.draft??'';const saved={...prior,version:1,sessionId,draft,full:{left:state.left,right:state.right,widths:{...widths}},...agent};sessionStorage.setItem(handoffKey,JSON.stringify(saved));return saved;}catch{return null;}};
 function layout(force=false){
  restoreMeetingView();
  if(active())keepConversation();
  const on=active(),sizes=measured(),key=JSON.stringify([on,selectedTab,outputSelection,state.left,state.right,sizes.left,sizes.right,window.innerWidth,document.body.className]);if(!force&&lastLayout===key)return;lastLayout=key;document.body.classList.toggle('meeting-workspace',on);const leaving=wasMeeting&&!on;wasMeeting=on;if(leaving)window.myAgentClose?.();bar.hidden=!on;{const ta=document.querySelector('.ma-shared-form textarea'),en=document.documentElement.lang==='en';if(ta)ta.placeholder=on?(en?'Ask about this meeting, or have me do something…':'就本次会议提问，或让我去做…'):(en?'Ask across meetings and docs, or have me do something…':'问所有会议和文档，或让我去做…');}
  if(!on)closeNotice();if(!on)stopDrag();
  const float=on&&state.right&&panelFull();document.body.classList.toggle('mw-panel-full',float);
  for(const side of ['left','right']){
   document.body.style.setProperty('--mw-'+side,sizes[side]+'px');
   const handle=handles[side];handle.hidden=!on||!state[side];handle.tabIndex=handle.hidden?-1:0;
   handle.setAttribute('aria-valuemin',String(Math.round(sideMinimum())));handle.setAttribute('aria-valuemax',String(Math.round(widthLimit(side))));handle.setAttribute('aria-valuenow',String(Math.round(sizes[side])));
  }
  const en=document.documentElement?.lang==='en';
  document.body.classList.toggle('mw-left-closed',!state.left);document.body.classList.toggle('mw-right-closed',!state.right);
  for(const side of ['left','right']){const button=buttons[side],label=(state[side]?(en?'Collapse ':'收起'):(en?'Expand ':'展开'))+(side==='left'?(en?'transcript':'实时转写'):(en?'outputs':'产出'));
   button.setAttribute('aria-expanded',String(state[side]));button.setAttribute('aria-pressed',String(state[side]));button.setAttribute('aria-label',label);button.title=label;}
  homeBack.setAttribute('aria-label',en?'Back to home':'返回首页');homeBack.title=en?'Back to home':'返回首页';
  if(on){panel.hidden=false;panel.classList.remove('ma-collapsed');document.body.classList.add('myagent-open');}
  paintPanel(on);
  frame.contentWindow?.postMessage({type:'tht-workspace-layout',enabled:on,left:false,right:state.right&&selectedTab==='document',outputDetail:outputSelection==='document',float,widths:sizes},location.origin);
  window.thtLiveReport?.syncPanel?.();
  noticeSpace();
  if(typeof ensurePostPoll==='function')ensurePostPoll();
 }
 window.addEventListener('tht-language-change',()=>{const en=document.documentElement.lang==='en';transcriptEntry.textContent=en?'Transcript':'完整转写';settingsEntry.textContent=en?'Settings':'设置';tabButtons.document.textContent=en?'Outputs':'产出内容';layout(true);fillTx();updateStatus();});
 window.addEventListener('resize',()=>{stopDrag();const next=sizeMode();if(next!==currentSize){currentSize=next;adaptSize();}layout();});
 frame.addEventListener('load',()=>{layout(true);window.thtPostmeeting?.relocateTasks?.();window.thtLiveReport?.paint?.();});
 // Reuse the existing right document pane rather than introducing another panel.
 window.thtMeetingTasksHost=()=>{
  const doc=frame.contentDocument,box=doc?.querySelector('.mother-workspace');if(!box)return null;
  let tasks=box.querySelector('.pm-meeting-tasks');if(!tasks){tasks=doc.createElement('section');tasks.className='pm-meeting-tasks';box.insertBefore(tasks,box.querySelector('.mother-editor'));}
  const live=box.querySelector('.meeting-todos');if(live)live.hidden=true;
  return tasks;
 };
 // A title copied verbatim into the first paragraph is displayed once. Nothing is
 // removed from the candidate or stored document; changed wording remains visible.
 function presentInsights(){
  const watching=panel._insightWatch;
  if(watching&&typeof watching.disconnect==='function')watching.disconnect();
  try{presentInsightPass();}finally{if(watching&&typeof watching.observe==='function')watching.observe(panel,{childList:true,subtree:true});}
  function presentInsightPass(){
  const openEvidence=panel._openEvidence||(panel._openEvidence=new Map());
  const arrivals=panel._feedArrivals||(panel._feedArrivals=new Set());
  const evidenceLabel=document.documentElement&&document.documentElement.lang==='en'?'Quote':'原话';
  const leadPlain=lead=>{
   const nodes=lead.childNodes;
   if(nodes&&nodes.length)return [...nodes].filter(n=>n.nodeType===3||(n.nodeType===1&&n.className!=='mw-insight-time'&&n.className!=='mw-quote')).map(n=>n.textContent||'').join('').trim();
   return String(lead.textContent||'').trim();
  };
  const quoteOf=text=>{
   const raw=String(text||'').trim();
   if(!raw||/^(?:引用原文暂未载入|Source excerpt not loaded)/.test(raw))return '';
   const stamp=raw.match(/^(\d+:\d{2}(?::\d{2})?) · /);if(!stamp)return '';
   const hm=stamp[1].split(':').slice(0,2).join(':'),parts=raw.split(' · ');
   const spoken=(parts.length>=3?parts.slice(2):parts.slice(1)).join(' · ').trim();
   if(!spoken||/^(?:引用原文暂未载入|Source excerpt not loaded)/.test(spoken))return '';
   return hm+' 「'+spoken+'」';
  };
  for(const card of panel.querySelectorAll('.ma-insight')){
   const heading=card.querySelector(':scope > strong'),lead=card.querySelector(':scope > div .ma-answer > p:first-child');
   if(!heading)continue;
   const title=[...heading.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
   if(lead)lead.classList.toggle('mw-duplicate-lead',!!title&&leadPlain(lead)===title);
   const evidenceHost=card.querySelector('.mw-send-head')?.parentElement||(typeof lead?.append==='function'?lead:card);
   const hasExternalSource=!!card.querySelector(':scope > div .ma-insight-sources .mw-source-link');
   const source=hasExternalSource?null:[...card.querySelectorAll(':scope > div .ma-insight-sources > p')].find(source=>/^(\d+:\d{2}(?::\d{2})?) · /.test(source.textContent));
   const quoteText=quoteOf(source?.textContent),cid=card.dataset&&card.dataset.candidateId||'';
   if(cid&&!arrivals.has(curSid+'\n'+cid)){arrivals.add(curSid+'\n'+cid);card.classList.add('mw-arrive');if(['insight','background','verification'].includes(card.dataset.kind))card.classList.add('mw-spark-arrive');}
   let time=card.querySelector('.mw-insight-time');
   if(!time&&card.children)time=[...card.children].find(n=>n.className==='mw-insight-time')||null;
   if(quoteText&&!time){time=document.createElement('button');time.type='button';time.className='mw-insight-time';evidenceHost.append(time);}
   if(time&&quoteText){
    time.disabled=false;time.hidden=false;
    time.onclick=()=>{
     const shown=quoteOf(source?.textContent);if(!shown)return;
     let quote=card.querySelector('.mw-quote');if(!quote&&card.children)quote=[...card.children].find(n=>n.className==='mw-quote')||null;
     const key=cid||shown;
     if(quote){quote.hidden=!quote.hidden;if(quote.hidden){openEvidence.delete(key);return;}if(quote.textContent!==shown)quote.textContent=shown;openEvidence.set(key,true);return;}
     quote=document.createElement('p');quote.className='mw-quote';quote.textContent=shown;evidenceHost.append(quote);openEvidence.set(key,true);
    };
    if(time.textContent!==evidenceLabel)time.textContent=evidenceLabel;time.setAttribute('aria-label',evidenceLabel);
    if(cid&&openEvidence.get(cid)){let quote=card.querySelector('.mw-quote');if(!quote&&card.children)quote=[...card.children].find(n=>n.className==='mw-quote')||null;if(!quote){quote=document.createElement('p');quote.className='mw-quote';quote.textContent=quoteText;evidenceHost.append(quote);}else{quote.hidden=false;if(quote.textContent!==quoteText)quote.textContent=quoteText;}}
   }else if(time){time.hidden=true;time.disabled=true;time.onclick=null;if(time.textContent)time.textContent='';if(cid)openEvidence.delete(cid);const stale=card.querySelector('.mw-quote');if(stale)stale.hidden=true;}
   card.classList.toggle('mw-has-time',!!quoteText);
  }
  }
 }
 if(panel.querySelectorAll){presentInsights();const insightWatch=new MutationObserver(()=>presentInsights());panel._insightWatch=insightWatch;insightWatch.observe(panel,{childList:true,subtree:true});}
 new MutationObserver(()=>layout()).observe(document.body,{attributes:true,attributeFilter:['class']});
 new MutationObserver(()=>layout()).observe(frame,{attributes:true,attributeFilter:['hidden']});
 new MutationObserver(()=>{if(active())keepConversation();}).observe(panel,{attributes:true,attributeFilter:['hidden','class']});
 // Do not move or recreate the composer, editor or conversation when panels fold.
 window.addEventListener('tht-proactive-data',e=>{if(!viewedSnapshot(e.detail))return;const data=e.detail;{const name=String(data.meetingTitle||data.session?.topicTitle||data.session?.title||data.source?.title||'').trim();const named=!!name&&!/^未命名(笔记|会议)?$|^untitled|^无有效内容$|^过短会话$|^short session$|^no substantive content$/i.test(name),en=document.documentElement.lang==='en';const project=String(data.projects?.find(p=>p.id===data.source?.projectId)?.title||data.project?.title||data.project?.name||data.projectTitle||data.session?.projectTitle||'').trim();title.textContent=[project,named?name:(en?'New meeting':'新会议')].filter(Boolean).join(' · ');title.title=title.textContent;
  // v5 会后（design-final）：结束的会标题前 ✦（会后按内容起的名），副标题换成「· 10-25 10:30 · 41 分钟」，顶栏 pill 显示时长 + 已结束。
  const stamp=v=>typeof v==='number'?v:Date.parse(v||''),st=stamp(data.session?.start),en2=stamp(data.session?.end);ended=Number.isFinite(en2)?{start:st,end:en2}:null;
  // r7 原型 final.html 会后：标题不加 ✦、不加日期副标题，只靠 pill「mm:ss 已结束」表达结束。
  const nextSid=String(data.session?.id||'');if(nextSid!==curSid){sourceError='';retryFailed=false;window.thtTranscriptionInterrupted=false;}if(data.session&&nextSid)recordingSnapshot={...(recordingSnapshot?.id===nextSid?recordingSnapshot:{}),...data.session};if(nextSid!==curSid&&ended&&panelFull()){selectedTab='transcript';state.right=true;transcriptReturn=null;}curSid=nextSid;statusSignature='';layout();sub.hidden=true;sub.textContent='';}});
 window.addEventListener('tht-live-transcript',e=>{
  if(e.detail?.sessionId!==window.thtRecordingMeetingId?.()||e.detail.sessionId!==curSid)return;
  const m=e.detail;
  if(m.type==='final'&&[...transcriptRows.slice(-8),...txFinals.map(item=>item.row)].some(row=>txSameRow(row,m))){txPartial=null;fillTx();return;}
  if(m.type==='partial'){
   const last=txFinals.at(-1)?.row||transcriptRows.at(-1);
   txPartial=String(m.text||'').trim()?{...m,speaker:txSpeaker(m)||txSpeaker(last),at:m.at??last?.at??Date.now()}:null;
  }else if(m.type==='final'){
   if(String(m.text||'').trim())txFinals.push({index:transcriptRows.length+txFinals.length,row:{...m,speaker:txSpeaker(m)||txSpeaker(txPartial),at:m.at??txPartial?.at??Date.now()}});
   txPartial=null;
  }
  liveTranscript=m;fillTx();updateSubtitle();
 });
 const subtitleStarts=new Map(),firstWords=new Set();
 function liveWaveHeights(level){const n=Math.max(0,Math.min(1,Number(level)||0));return [0.45,1,0.7].map(weight=>Math.round(6+n*10*weight));}
 function pillWaveHeights(level){const n=Math.min(1,2*Math.sqrt(Math.max(0,Math.min(1,Number(level)||0))));return [0.3,0.55,0.8,0.6,1,0.7,0.9,0.5,0.75,0.45,0.3].map(weight=>Math.round(3+n*15*weight));}
 function paintPillWave(){const wave=pill.querySelector?.('.mw-wave');if(!wave)return;const moving=controlState==='rec'||controlState==='asr',level=moving?Math.max(Number(meetingNativeStatus().audioLevel)||0,Number(window.thtBrowserAudioLevel)||0,window.thtWorkspaceAudio?.active?Number(window.thtWorkspaceAudio.level)||0:0):0;wave.querySelectorAll('i').forEach((bar,i)=>{const height=pillWaveHeights(level)[i];if(height!=null)bar.style.height=height+'px';});}
 window.addEventListener('tht-workspace-audio',paintPillWave);window.addEventListener('tht-asr-status',e=>{if(e.detail?.sessionId===curSid&&e.detail.asrStatus){if(['blocked','retrying','disconnected','error','closed'].includes(e.detail.asrStatus.state))clearTxPartial();if(e.detail.asrStatus.state==='connected')window.thtTranscriptionInterrupted=false;window.thtNativeStatus={...window.thtNativeStatus,asrStatus:e.detail.asrStatus};statusSignature='';}});
 window.addEventListener('tht-recording-started',e=>{const id=e.detail?.id;if(id){subtitleStarts.set(id,performance.now());firstWords.delete(id);liveTranscript=null;clearTxPartial();window.thtTranscriptionInterrupted=false;}updateSubtitle();});
 function updateSubtitle(){
  const fd=frame.contentDocument,el=fd?.querySelector('.surface-elapsed'),status=fd?.querySelector('.surface-audio-status'),st=status?.dataset?.state,pc=window.thtPauseControl?.state?.(),u=liveTranscript?.sessionId===curSid?liveTranscript:transcriptRows.at(-1),txt=u?.text?.trim()||'';
  const recordingId=window.thtRecordingMeetingId?.()||'',starting=st==='starting'||!!meetingNativeStatus().starting;
  const recording=!!recordingId||starting||!!el?.classList.contains('recording');
  if(recordingId&&!subtitleStarts.has(recordingId))subtitleStarts.set(recordingId,window.thtRecordingStartMono?.()??performance.now());
  live.hidden=!loading.hidden||!!(recordingId&&curSid!==recordingId)||!active()||!recording||!!pc?.paused||st==='paused'||state.left;
  const text=txt||(document.documentElement.lang==='en'?'Listening…':'正在听…');
  const key=curSid+'\n'+text;
  const d=u?.latencyDiagnostic,latencyKey=d?d.key+':'+d.seq:'';
  const changed=live.dataset.k!==key||(!live.hidden&&(live.dataset.latencyKey!==latencyKey||(u?.type==='partial'&&!firstWords.has(curSid))));
  const level=Math.max(Number(window.thtNativeStatus?.audioLevel)||0,Number(window.thtBrowserAudioLevel)||0);
  if(changed){live.dataset.k=key;live.replaceChildren();const wave=mk('span','mw-lv');wave.setAttribute('aria-hidden','true');for(const height of liveWaveHeights(level)){const bar=mk('i','');bar.style.height=height+'px';wave.append(bar);}live.append(wave);const t=mk('span','mw-ltxt');t.textContent=frame.contentWindow?.thtProfileDisplay?.(text) ?? text;live.append(t);}
  live.querySelectorAll('.mw-lv i').forEach((bar,i)=>{const height=liveWaveHeights(level)[i];if(height!=null)bar.style.height=height+'px';});
  live.classList.toggle('mw-has-line',!!txt);
  if(txt&&!live.hidden&&changed){
   const now=performance.now(),received=d&&window.ThtLatency?.snapshot(curSid).find(r=>r.key===d.key&&r.seq===d.seq&&r.stage==='partial_receive');
   if(d)window.ThtLatency?.mark(curSid,d.key,'dom_update',{seq:d.seq,...(received?{receiveToDomMs:now-received.monoMs}:{})});
   if(u?.type==='partial'&&!firstWords.has(curSid)&&subtitleStarts.has(curSid)){
    window.ThtLatency?.mark(curSid,d?.key||curSid+':first-word','first_word',{seq:d?.seq,startToDomMs:now-subtitleStarts.get(curSid)});firstWords.add(curSid);
   }
   live.dataset.latencyKey=latencyKey;
  }
 }
 let statusSignature='';
 function updateStatus(){topicLabels();syncDocumentActions();const el=frame.contentDocument?.querySelector('.surface-elapsed'),status=frame.contentDocument?.querySelector('.surface-audio-status'),st=status?.dataset?.state;const rawNative=window.thtNativeStatus||{},recordingId=window.thtRecordingMeetingId?.()||(rawNative.starting?rawNative.pendingSessionId:rawNative.active?rawNative.sessionId:'')||'',foreign=!!(curSid&&recordingId&&recordingId!==curSid),captureIdle=rawNative.active===false&&!rawNative.starting&&!recordingId,showing=!captureIdle&&!foreign&&!!el&&(!!el.classList.contains('recording')||['starting','sound','quiet','paused','waiting','disconnected'].includes(st));const ns=meetingNativeStatus(),heard=!!ns.active&&(Number(ns.audioSeconds)>0||Number(ns.audioLevel)>0||(ns.recentTranscript||[]).some(row=>String(row?.text||'').trim())),captureConnected=!!ns.captureReady||heard;if(ns.asrStatus?.state==='connected'&&!ended&&!['disconnected','error','failed','ended'].includes(st))window.thtTranscriptionInterrupted=false;const interrupted=meetingInterrupted(st);if(txPartial&&(foreign||ended||window.thtPauseControl?.state?.()?.paused||st==='paused'||interrupted||['disconnected','error','failed','ended'].includes(st)||['blocked','retrying','disconnected','error','closed'].includes(ns.asrStatus?.state)||(!recordingId&&!ns.active&&!showing)))clearTxPartial();const signature=JSON.stringify([showing,captureIdle,window.thtRecordingMeetingId?.(),ns.starting,ns.active,ns.captureReady,heard,ns.sessionId,ns.captureRecovery,healthName(ns.captureHealth),ns.error,ns.captureMode,ns.asrStatus,sourceError,retryFailed,st,interrupted,window.thtNativeLinkDown,window.thtTranscriptionInterrupted,audioHealth,window.thtPauseControl?.state?.(),ended,curSid,finishedId,active(),document.documentElement.lang,window.thtLiveReport?.state?.notion,document.getElementById('stop')?.disabled,document.getElementById('b-native')?.hidden]);if(signature===statusSignature){paintPillWave();return;}statusSignature=signature;interruptVisible=interrupted;const owned=window.thtRecordingMeetingId?.()===curSid||ns.sessionId===curSid,openMeeting=!!curSid&&!ended&&active()&&curSid!==finishedId;finish.hidden=!openMeeting||owned;const showPair=openMeeting&&(!owned||interrupted);interruptEnd.hidden=organize.hidden=!showPair;const en=document.documentElement?.lang==='en';source.setAttribute('aria-label',en?'Recording options':'录音选项');recmenu.setAttribute('aria-label',en?'Recording options':'录音选项');finish.textContent=en?'End & organize':'结束并整理';interruptEnd.textContent=en?'End meeting':'结束会议';organize.textContent=en?'Start wrap-up':'开始整理';end.hidden=!showing;updateSubtitle();end.textContent=en?'End meeting':'结束会议';end.setAttribute('aria-label',en?'End':'结束');
  const pc=window.thtPauseControl?.state?.()||{available:false,paused:st==='paused'},paused=!foreign&&(!!pc.paused||st==='paused');
  const over=!showing&&!!ended&&active(),dur=over&&Number.isFinite(ended.start)?Math.max(0,Math.round((ended.end-ended.start)/1000)):0,hms=n=>(n>=3600?[Math.floor(n/3600),Math.floor(n/60)%60,n%60]:[Math.floor(n/60),n%60]).map(x=>String(x).padStart(2,'0')).join(':');if(showing&&curSid)liveSid=curSid;
  const starting=!captureConnected&&(!!ns.starting||(!foreign&&st==='starting')),asr=ns.asrStatus?.state;
  const failed=retryFailed||(!starting&&((ns.captureRecovery==='failed')||(!!ns.error&&!ns.captureReady)||['input-ended','input-muted','callback-stalled','suspended'].includes(healthName(ns.captureHealth))||(!foreign&&['error','failed'].includes(st))));
  const hasTranscript=[...transcriptRows,...(recordingSnapshot?.fullTranscript||[]),...(recordingSnapshot?.transcript||[])].some(row=>String(row?.text||'').trim());
  // A stopped live session may not have received its end timestamp yet.
  const start=recordingSnapshot?.start,startedAt=typeof start==='number'?start:Date.parse(start||''),stopped=!showing&&!ns.active&&!starting&&!!curSid&&active()&&(captureIdle||hasTranscript||Number.isFinite(startedAt)&&startedAt<nowMs());
  controlState=starting?'join':failed?'fail':over||paused||stopped?'stop':((asr==='blocked')||interrupted)?'asr':'rec';
  const neverStarted=over&&Number.isFinite(ended.start)&&ended.start===ended.end&&!hasTranscript;
  pill.hidden=!active()||neverStarted||(!showing&&!over&&!stopped&&!failed&&!ns.active&&!starting);if(pill.hidden)recmenu.hidden=true;
  pill.className='mw-pill'+(controlState==='stop'?' ended':controlState==='asr'?' disconnected':controlState==='fail'?' failed':controlState==='join'?' connecting':'');pill.dataset.state=controlState;
  const pt=pill.querySelector?.('.mw-t'),ps=pill.querySelector?.('.mw-pstate');if(pt){pt.textContent=recordingClock(over?hms(dur):el?.textContent||'00:00');pt.hidden=!['rec','stop'].includes(controlState);}
  if(ps)ps.textContent=sourceError||(ns.captureEnding?(en?'Saving stopped recording':'录音已停止，正在保存'):controlState==='join'?(en?'Connecting':'接入中'):controlState==='asr'?(en?'Transcription disconnected':'转写断开'):controlState==='fail'?(en?'Recording did not connect':'录音没接上'):'');
  end.hidden=pill.hidden||!(showing||ns.active||starting||!!curSid&&!ended&&curSid!==finishedId);end.textContent='';end.setAttribute('aria-label',en?'Stop':'停止');
  pause.hidden=pill.hidden||!curSid||recordingId!==curSid||!pc.available||!!ns.captureEnding;pause.setAttribute('aria-label',en?(paused?'Resume':'Pause'):(paused?'继续':'暂停'));pause.setAttribute('aria-pressed',String(paused));pause.innerHTML=paused?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="m9 5 10 7-10 7Z"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M8 5v14M16 5v14"/></svg>';
  resume.hidden=!!ns.captureEnding||paused||!['stop','asr','fail'].includes(controlState);resume.textContent=controlState==='stop'?(en?'Continue':'继续'):(en?'Retry':'重试');
  synced.hidden=true;finish.hidden=interruptEnd.hidden=organize.hidden=true;
  end.disabled=false;end.setAttribute('aria-busy',String(!!document.getElementById('stop')?.disabled));paintPillWave();renderUnderstanding();window.dispatchEvent(new Event('tht-workspace-status'));}
 let nativeSeenAt=0;
 const updateClock=()=>{const ns=meetingNativeStatus(),now=nowMs(),down=!!(nativeSeenAt&&ns&&(ns.active||ns.sessionId===curSid)&&now-nativeSeenAt>6000);if(down!==!!window.thtNativeLinkDown){window.thtNativeLinkDown=down;statusSignature='';}const on=meetingInterrupted(frame.contentDocument?.querySelector('.surface-audio-status')?.dataset?.state);if(on!==interruptVisible||down!==!!window.thtNativeLinkDown){statusSignature='';updateStatus();}{const value=recordingClock(frame.contentDocument?.querySelector('.surface-elapsed')?.textContent||'00:00'),text=pill.querySelector?.('.mw-t');if(text&&text.textContent!==value)text.textContent=value;}};
 setInterval(updateClock,1000);
 window.thtExpandSameWindow=async()=>{
  const sessionId=curSid||(typeof window.thtViewedMeetingId==='string'?window.thtViewedMeetingId:'')||new URLSearchParams(location.search).get('id')||'';
  const token=window.THT_BOOT?.relayToken||'';
  const response=await fetch('/native/owner-open-main?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sessionId})});
  return response.json();
 };
 window.addEventListener('tht-native-status',e=>{
  const detail=e.detail||{},sid=String(detail.sessionId||'');
  const viewed=typeof window.thtViewedMeetingId==='string'?window.thtViewedMeetingId:'';
  if(!sid||sid!==(viewed||curSid||sid))return;
  if(!curSid)curSid=sid;
  if(sid!==curSid)return;
  const expSt=detail.expertStatus;
  let chk=panel.querySelector('.mw-checking-pill');
  if(expSt&&expSt.state==='checking'){
    const feedHost=panel.querySelector('.ma-insights')||panel;
    if(!chk){
      chk=document.createElement('div');chk.className='mw-checking-pill';chk.setAttribute('aria-live','polite');
      const dot=document.createElement('span');dot.className='mw-checking-dot';dot.setAttribute('aria-hidden','true');
      const lbl=document.createElement('span');lbl.className='mw-checking-text';
      chk.append(dot,lbl);
    }
    if(chk.parentElement!==feedHost||chk.nextElementSibling)feedHost.append(chk);
    const lbl=chk.querySelector('.mw-checking-text');
    const isTradeoff=expSt.kind==='best_practice';
    const rawTopic=String(expSt.topic||expSt.query||expSt.claim||expSt.label||'').replace(/\s+/g,' ').trim();
    const shortTopic=rawTopic.length>16?rawTopic.slice(0,16)+'…':rawTopic;
    const msg=(document.documentElement.lang==='en')
      ?(shortTopic?(isTradeoff?'Comparing: '+shortTopic:'Verifying: '+shortTopic):(isTradeoff?'Comparing industry approaches…':'Verifying external source…'))
      :(shortTopic?(isTradeoff?'正在对比「'+shortTopic+'」…':'正在核实「'+shortTopic+'」…'):(isTradeoff?'正在对比行业方案…':'正在核实外部资料…'));
    if(lbl)lbl.textContent=msg;
    chk.hidden=!msg;
  }else if(chk){
    chk.hidden=true;
  }
  if(detail.scenario){scenarioState=detail.scenario;renderUnderstanding();}
  let added=false;
  for(const row of detail.recentTranscript||[]){
    const text=String(row?.text||'').trim();if(!text)continue;
    if(transcriptRows.some(existing=>txSameRow(existing,row)))continue;
    transcriptRows.push(row);added=true;
  }
  if(!added)return;
  txSig='';fillTx();updateSubtitle();
 });
 let statusQueued=false;function scheduleStatus(){if(statusQueued)return;statusQueued=true;queueMicrotask(()=>{statusQueued=false;updateStatus();});}
 window.addEventListener('tht-native-status',()=>{nativeSeenAt=typeof window.thtNow==='function'?window.thtNow():Date.now();});
 window.addEventListener('tht-audio-health',e=>{audioHealth=healthName(e.detail?.state??e.detail);statusSignature='';scheduleStatus();});
 window.addEventListener('tht-notice-change',()=>{const text=String(document.getElementById('notice')?.textContent||'');if(/中断|中转断开|interrupted|没有被记录|not recorded|连接中断/i.test(text))window.thtTranscriptionInterrupted=true;else if(!text.trim())window.thtTranscriptionInterrupted=false;statusSignature='';scheduleStatus();});
 for(const name of ['tht-proactive-data','tht-live-transcript','tht-pause-state','tht-recording-started','tht-native-status','tht-asr-status'])window.addEventListener(name,scheduleStatus);
 new MutationObserver(scheduleStatus).observe(panel,{childList:true,subtree:true});
 new MutationObserver(scheduleStatus).observe(document.body,{attributes:true,attributeFilter:['class']});
 let recorderObserver;function observeRecorder(){recorderObserver?.disconnect();const root=frame.contentDocument?.querySelector('.surface-record-dock');if(root){recorderObserver=new MutationObserver(scheduleStatus);recorderObserver.observe(root,{attributes:true,subtree:true,attributeFilter:['class','data-state']});}scheduleStatus();}
 frame.addEventListener('load',observeRecorder);observeRecorder();

 // Post-meeting auto-summary live status banner (Granola-style feedback)
 const postBar=mk('div','mw-post-summary-bar');postBar.id='mw-post-summary-bar';postBar.hidden=true;postBar.setAttribute('role','status');
 postBar.style.cssText='display:none;align-items:center;gap:8px;padding:8px 14px;margin:8px 14px 4px;border-radius:10px;background:rgba(91,87,214,.08);color:var(--ink,#1d1d1f);font-size:13px;';
 const postDot=mk('span','mw-checking-dot');postDot.setAttribute('aria-hidden','true');
 const postText=mk('span','');
 const postRetry=mk('button','');postRetry.type='button';postRetry.hidden=true;
 postRetry.style.cssText='margin-left:auto;padding:3px 10px;border-radius:6px;border:1px solid rgba(91,87,214,.35);background:transparent;color:#5B57D6;font-size:12px;cursor:pointer;flex-shrink:0;';
 postBar.append(postDot,postText,postRetry);
 let postPollTimer=0,postPollSid='',postLastStatus='';
 function setPostBar(show){postBar.hidden=!show;postBar.style.display=show?'flex':'none';}
 function postToken(){let t=window.THT_BOOT?.relayToken||'';if(!t)try{t=JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}return t;}
 function stopPostPoll(){clearTimeout(postPollTimer);postPollTimer=0;}
 function mountPostBar(){
  const head=outputs.querySelector('#mw-output-heading');
  if(head&&head.parentElement===outputs){if(postBar.previousElementSibling!==head)head.after(postBar);return;}
  if(outputs&&postBar.parentElement!==outputs)outputs.prepend(postBar);
 }
 function postHeaders(tok,json){return {...(json?{'Content-Type':'application/json'}:{}),...(tok?{'x-tht-token':tok}:{})};}
 async function triggerManualSummary(sid,mode){
  const en=document.documentElement.lang==='en',tok=postToken(),q=tok?'&token='+encodeURIComponent(tok):'';
  postRetry.disabled=true;postDot.hidden=false;postRetry.hidden=true;
  postText.textContent=en?'✦ Generating meeting summary…':'✦ 正在整理会议纪要…';
  setPostBar(true);
  try{
   const body=mode==='force'?{op:'start',force:true}:{op:'retry',block:'summary'};
   await fetch('/asr-relay/native/postmeeting?id='+encodeURIComponent(sid)+q,{method:'POST',headers:postHeaders(tok,true),body:JSON.stringify(body)});
  }catch{}
  try{await fetch('/meeting-retry'+(tok?'?token='+encodeURIComponent(tok):''),{method:'POST',headers:postHeaders(tok,true),body:JSON.stringify({id:sid})});}catch{}
  postLastStatus='running';stopPostPoll();postPollTimer=setTimeout(()=>pollPostSummary(sid),2500);
 }
 async function pollPostSummary(sid){
  if(!sid||sid!==curSid||!ended||!active()){setPostBar(false);stopPostPoll();return;}
  const en=document.documentElement.lang==='en';
  try{
   const tok=postToken();
   const res=await fetch('/asr-relay/post-meeting-state?id='+encodeURIComponent(sid)+(tok?'&token='+encodeURIComponent(tok):''),{headers:postHeaders(tok,false)});
   if(res.status===404){
    const justEnded=ended&&Number.isFinite(ended.end)&&(Date.now()-ended.end)<20000;
    if(justEnded){
     mountPostBar();postLastStatus='running';setPostBar(true);postDot.hidden=false;postRetry.hidden=true;
     postText.textContent=en?'✦ Auto-generating meeting summary…':'✦ 正在自动整理会议纪要…';
     postPollTimer=setTimeout(()=>pollPostSummary(sid),2500);
    }else{setPostBar(false);stopPostPoll();}
    return;
   }
   if(!res.ok)throw Error('status_'+res.status);
   const data=await res.json();
   if(sid!==curSid||!ended)return;
   const st=data?.progress?.summary?.status||data?.state?.progress?.summary?.status||'';
   mountPostBar();
   if(st==='pending'||st==='running'){
    postLastStatus=st;setPostBar(true);postDot.hidden=false;postRetry.hidden=true;
    postText.textContent=en?'✦ Auto-generating meeting summary…':'✦ 正在自动整理会议纪要…';
    postPollTimer=setTimeout(()=>pollPostSummary(sid),3000);
   }else if(st==='done'){
    const wasRunning=postLastStatus==='pending'||postLastStatus==='running';
    postLastStatus='done';stopPostPoll();
    if(wasRunning){
     setPostBar(true);postDot.hidden=true;postRetry.hidden=true;
     postText.textContent=en?'✓ Meeting summary ready':'✓ 会议纪要已自动整理完成';
     try{window.thtOpenMeeting?.(sid);}catch{}
     setTimeout(()=>{if(curSid===sid&&postLastStatus==='done')setPostBar(false);},6000);
    }else{setPostBar(false);}
   }else if(st==='skipped'){
    postLastStatus='skipped';stopPostPoll();
    setPostBar(true);postDot.hidden=true;postRetry.hidden=false;
    postText.textContent=en?'Short recording — auto-summary skipped.':'转写较短，未自动整理会议纪要。';
    postRetry.textContent=en?'Generate summary':'立即整理纪要';
    postRetry.disabled=false;
    postRetry.onclick=()=>triggerManualSummary(sid,'force');
   }else if(st==='failed'){
    postLastStatus='failed';stopPostPoll();
    setPostBar(true);postDot.hidden=true;postRetry.hidden=false;
    postText.textContent=en?'Meeting summary did not finish.':'会议纪要自动整理未完成。';
    postRetry.textContent=en?'Retry summary':'重试整理';
    postRetry.disabled=false;
    postRetry.onclick=()=>triggerManualSummary(sid,'retry');
   }else{setPostBar(false);}
  }catch{if(sid===curSid&&ended)postPollTimer=setTimeout(()=>pollPostSummary(sid),5000);}
 }
 function ensurePostPoll(){
  if(!ended||!curSid||!active()){setPostBar(false);stopPostPoll();if(!curSid||!ended){postPollSid='';postLastStatus='';}return;}
  if(postPollSid!==curSid){postPollSid=curSid;postLastStatus='';stopPostPoll();void pollPostSummary(curSid);}
 }
 window.addEventListener('tht-proactive-data',ensurePostPoll);
 window.addEventListener('tht-meeting-finished',()=>{postPollSid='';ensurePostPoll();});
 window.addEventListener('tht-meeting-navigating',()=>{setPostBar(false);stopPostPoll();postPollSid='';postLastStatus='';});

 // Transcript navigation is independent from the timeline's unread count.
 function roundLatest(btn){
  btn.textContent=document.documentElement.lang==='en'?'Back to latest ↓':'回到最新 ↓';
  btn.setAttribute('aria-label',btn.textContent);return btn;
 }
 layout();
})();
