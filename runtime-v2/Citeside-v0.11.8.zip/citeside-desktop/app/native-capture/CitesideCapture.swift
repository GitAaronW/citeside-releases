import Foundation
import AppKit
import ScreenCaptureKit
import Speech
import AVFoundation
import CoreMedia
import CoreImage
import CoreAudio
import Darwin
import CryptoKit
import Security

// A request is consumed once by this recorder generation, without opening capture.
struct CaptureRetryGate {
    var acknowledged=""
    mutating func handle(_ request:[String:Any],sessionId:String,command:String,paused:Bool,ready:Bool,recover:()->Void) -> Bool? {
        guard let requestId=request["requestId"] as? String,!requestId.isEmpty,
              request["sessionId"] as? String == sessionId,!sessionId.isEmpty,
              requestId != acknowledged,command.isEmpty,!paused else { return nil }
        acknowledged=requestId
        guard ready else { return false }
        recover();return true
    }
}

// Bounded SCStream stop receipts belong to one CaptureEngine. Pending OS calls
// survive a timeout; retries observe them instead of issuing concurrent stops.
@MainActor final class CaptureStopCoordinator {
    let timeout:Double
    private var pending=Set<Int>(),stopped=Set<Int>(),failed=Set<Int>()
    private var waiting:Task<Bool,Never>?
    init(timeout:Double=3) { self.timeout=timeout }
    func stop(_ operations:[@MainActor () async throws -> Void]) async -> Bool {
        if let waiting=waiting { return await waiting.value }
        failed.removeAll()
        for (index,operation) in operations.enumerated() where !stopped.contains(index) && !pending.contains(index) {
            pending.insert(index)
            Task { @MainActor in
                do { try await operation();self.stopped.insert(index) }
                catch { self.failed.insert(index) }
                self.pending.remove(index)
            }
        }
        // An unstructured wait has a total deadline; a task group would wait for
        // a non-cooperative stopCapture child even after cancellation.
        let wait=Task { @MainActor in
            let deadline=ProcessInfo.processInfo.systemUptime+self.timeout
            repeat {
                if !self.failed.isEmpty { return false }
                if self.stopped.count==operations.count { return true }
                try? await Task.sleep(nanoseconds:10_000_000)
            } while ProcessInfo.processInfo.systemUptime<deadline
            return false
        }
        waiting=wait;let result=await wait.value;waiting=nil;return result
    }
}

// Start and stop receipts belong to the stream identity, including a start
// that is still awaiting ScreenCaptureKit when Quit arrives.
@MainActor final class CaptureStreamReceipts {
    private final class Receipt {
        weak var stream:AnyObject?;var starting:Task<Void,Error>?,stopping:Task<Void,Error>?;var started=false,stopped=false
        init(_ stream:AnyObject) { self.stream=stream }
    }
    private var receipts=[ObjectIdentifier:Receipt]()
    func start(_ stream:AnyObject,operation:@escaping @MainActor () async throws -> Void) async throws {
        receipts=receipts.filter { $0.value.stream != nil }
        let id=ObjectIdentifier(stream),receipt=Receipt(stream);receipts[id]=receipt
        let task=Task { @MainActor in try await operation();receipt.started=true }
        receipt.starting=task
        defer { receipt.starting=nil }
        try await task.value
    }
    func didStop(_ stream:AnyObject) { if let receipt=receipts[ObjectIdentifier(stream)],receipt.stream === stream { receipt.stopped=true } }
    func stop(_ stream:AnyObject?,operation:@escaping @MainActor () async throws -> Void) async throws {
        guard let stream=stream,let receipt=receipts[ObjectIdentifier(stream)],receipt.stream === stream else { return }
        if let task=receipt.starting {
            // A failed start never acquired capture. A successful late start
            // must be stopped before this receipt can confirm cleanup.
            do { try await task.value } catch { return }
        }
        guard receipt.started,!receipt.stopped else { return }
        if let task=receipt.stopping { try await task.value;return }
        let task=Task { @MainActor in try await operation();receipt.stopped=true }
        receipt.stopping=task
        defer { receipt.stopping=nil }
        try await task.value
    }
}

// CoreAudio inventory reads metadata only; it never requests capture permission.
struct MicrophoneDevice {
    let id:AudioDeviceID;let uid:String;let name:String;let isDefault:Bool
    var json:[String:Any] { ["uid":uid,"name":name,"isDefault":isDefault] }
}
func microphoneDevices()->[MicrophoneDevice] {
    var address=AudioObjectPropertyAddress(mSelector:kAudioHardwarePropertyDevices,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
    var size:UInt32=0
    guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),&address,0,nil,&size)==noErr else { return [] }
    var ids=[AudioDeviceID](repeating:0,count:Int(size)/MemoryLayout<AudioDeviceID>.size)
    guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&address,0,nil,&size,&ids)==noErr else { return [] }
    var defaultID:AudioDeviceID=0;var defaultSize=UInt32(MemoryLayout<AudioDeviceID>.size)
    address.mSelector=kAudioHardwarePropertyDefaultInputDevice
    _ = AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&address,0,nil,&defaultSize,&defaultID)
    func string(_ id:AudioDeviceID,_ selector:AudioObjectPropertySelector)->String {
        var a=AudioObjectPropertyAddress(mSelector:selector,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var value:CFString="" as CFString;var n=UInt32(MemoryLayout<CFString>.size)
        guard AudioObjectGetPropertyData(id,&a,0,nil,&n,&value)==noErr else { return "" };return value as String
    }
    return ids.compactMap { id in
        var a=AudioObjectPropertyAddress(mSelector:kAudioDevicePropertyStreamConfiguration,mScope:kAudioDevicePropertyScopeInput,mElement:kAudioObjectPropertyElementMain);var n:UInt32=0
        guard AudioObjectGetPropertyDataSize(id,&a,0,nil,&n)==noErr,n>0 else { return nil }
        let memory=UnsafeMutableRawPointer.allocate(byteCount:Int(n),alignment:MemoryLayout<AudioBufferList>.alignment);defer { memory.deallocate() }
        guard AudioObjectGetPropertyData(id,&a,0,nil,&n,memory)==noErr else { return nil }
        let buffers=UnsafeMutableAudioBufferListPointer(memory.assumingMemoryBound(to:AudioBufferList.self))
        guard buffers.reduce(0,{$0+Int($1.mNumberChannels)})>0 else { return nil }
        let uid=string(id,kAudioDevicePropertyDeviceUID);guard !uid.isEmpty else { return nil }
        return MicrophoneDevice(id:id,uid:uid,name:string(id,kAudioObjectPropertyName),isDefault:id==defaultID)
    }
}

// Desktop system + microphone capture for the existing meeting Session.
// Cloud ASR uses the configured local relay; otherwise Apple recognition stays local.
struct PageGate {
    var anchor: [UInt8]?; var candidate: [UInt8]?; var stable = 0
    var lastSent: Double = -100
    static func distance(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return 1 }
        let changed = zip(a,b).filter { abs(Int($0.0)-Int($0.1)) > 22 }.count
        return Double(changed)/Double(a.count)
    }
    mutating func accepts(_ sample: [UInt8], now: Double) -> Bool {
        if let a = anchor, Self.distance(a,sample) < 0.14 { candidate=nil; stable=0; return false }
        if let c=candidate, Self.distance(c,sample) < 0.055 { stable += 1 }
        else { candidate=sample; stable=1 }
        guard stable >= 3, now-lastSent >= 4 else { return false }
        anchor=sample; candidate=nil; stable=0; lastSent=now; return true
    }
}
// Read activity metadata only; no tap, recording, or new permission is created.
@available(macOS 14.2, *)
func meetingInputProcesses() -> Set<Int32>? {
    var list=AudioObjectPropertyAddress(mSelector:kAudioHardwarePropertyProcessObjectList,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
    var size:UInt32=0
    guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),&list,0,nil,&size)==noErr else { return nil }
    var objects=[AudioObjectID](repeating:0,count:Int(size)/MemoryLayout<AudioObjectID>.size)
    guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&list,0,nil,&size,&objects)==noErr else { return nil }
    var result=Set<Int32>()
    for object in objects {
        var input=AudioObjectPropertyAddress(mSelector:kAudioProcessPropertyIsRunningInput,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var active:UInt32=0,n:UInt32=4
        guard AudioObjectGetPropertyData(object,&input,0,nil,&n,&active)==noErr,active != 0 else { continue }
        var address=AudioObjectPropertyAddress(mSelector:kAudioProcessPropertyPID,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var pid:Int32=0;n=4
        guard AudioObjectGetPropertyData(object,&address,0,nil,&n,&pid)==noErr,pid != ProcessInfo.processInfo.processIdentifier,let app=NSRunningApplication(processIdentifier:pid) else { continue }
        let b=(app.bundleIdentifier ?? "").lowercased()
        if meetingInputApp(bundle:b) { result.insert(pid) }
    }
    return result
}
struct MeetingTarget {
    let window: SCWindow
    var json: [String:Any] { ["windowId":Int(window.windowID), "bundleId":window.owningApplication?.bundleIdentifier ?? "", "title":window.title ?? "会议"] }
}
// Apps whose live microphone use means a call. Arc is company.thebrowser.Browser; Tencent Meeting is com.tencent.meeting.
func meetingInputApp(bundle: String) -> Bool {
    let b=bundle.lowercased()
    return ["lark","feishu","zoom","teams","chrome","safari","firefox","edge","webex","thebrowser","tencent.meeting","wemeet","dingtalk"].contains { b.contains($0) }
}
func recognizedMeeting(bundle: String, title: String) -> Bool {
    let b=bundle.lowercased(), t=title.lowercased()
    if b.contains("lark") || b.contains("feishu") { return ["会议","meeting","视频通话","video call"].contains { t.contains($0) } }
    if b.contains("zoom") { return t.contains("zoom meeting") || t.contains("zoom 会议") }
    if b.contains("teams") {
        // Chat, channel and app-section windows name their section as a "|" segment
        // ("Sales call prep | Chat"); only a call or meeting window may match.
        let sections:Set<String>=["chat","activity","calendar","teams and channels","teams","channels","files","聊天","活动","日历","团队和频道","文件"]
        if t.split(separator:"|").map({ $0.trimmingCharacters(in:.whitespaces) }).contains(where:{ sections.contains($0) }) { return false }
        // Match English words, not Recall / callback / meetingnotes names.
        return t.range(of:"\\b(meeting|call)\\b", options:.regularExpression) != nil
            || t.contains("会议") || t.contains("通话")
    }
    if b.contains("tencent.meeting") || b.contains("wemeet") {
        // The home window is titled just the app name; an in-meeting window shows the
        // topic with the app name, the meeting id, or sharing state.
        if ["腾讯会议","tencent meeting","voov meeting","voov"].contains(t.trimmingCharacters(in:.whitespaces)) { return false }
        return ["会议号","meeting id","共享屏幕","屏幕共享","screen sharing","正在讲话"].contains { t.contains($0) }
            || t.range(of:"\\S.*[-–|]\\s*(腾讯会议|tencent meeting|voov meeting)$", options:.regularExpression) != nil
    }
    if b.contains("dingtalk") {
        // The main window is "钉钉" / "DingTalk"; calls open their own window.
        return ["钉钉会议","视频会议","语音通话","视频通话","dingtalk meeting","video meeting","video call","voice call","会议号"].contains { t.contains($0) }
    }
    if b.contains("webex") { return t.contains("meeting") || t.contains("会议") }
    let browser=["chrome","safari","edgemac","thebrowser","firefox"].contains { b.contains($0) }
    return browser && (t.contains("google meet") || t.hasPrefix("meet -") || t.hasPrefix("meet –") || t.contains("meet.google.com"))
}
enum CaptureError: LocalizedError {
    // A pinned browser window must still show the same meeting tab.
    case message(String)
    var errorDescription: String? { if case .message(let s)=self { return s }; return nil }
}
// Permission denial needs an explicit recovery action: macOS may not show
// another prompt after a prior denial or an upgraded helper identity.
enum CapturePermission: String, LocalizedError {
    case screen = "ScreenCapture", microphone = "Microphone", speech = "SpeechRecognition"
    var settingsURL: URL { URL(string:"x-apple.systempreferences:com.apple.preference.security?Privacy_"+rawValue)! }
    func message(english: Bool) -> String {
        switch self {
        case .screen: return english ? "Screen & System Audio Recording is not authorized. Recording has not started." : "录屏与系统录音权限未生效，尚未开始录制。"
        case .microphone: return english ? "Microphone is not authorized. Recording has not started." : "麦克风权限未生效，尚未开始录制。"
        case .speech: return english ? "Speech Recognition is not authorized. Recording has not started." : "语音识别权限未生效，尚未开始录制。"
        }
    }
    var errorDescription: String? { message(english:false) }
}
func authorizedScreenContent<T>(load: () async throws -> T, request: () -> Bool) async throws -> T {
    do { return try await load() }
    catch {
        guard (error as NSError).domain == SCStreamErrorDomain, (error as NSError).code == SCStreamError.Code.userDeclined.rawValue else { throw error }
        _ = request()
        // CoreGraphics can disagree with ScreenCaptureKit. Only an actual SCK
        // retry can prove access; never reject a working SCK grant on CG's Bool.
        do { return try await load() }
        catch {
            guard (error as NSError).domain == SCStreamErrorDomain, (error as NSError).code == SCStreamError.Code.userDeclined.rawValue else { throw error }
            throw CapturePermission.screen
        }
    }
}
// Screen metadata is not proof of full screen capture access. Live preflight
// belongs to this helper, separately from the main application's screenshot gate.
// Status and refresh never enumerate content or start capture.
struct ScreenPermissionReport {
    var verifiedAt:Date? = nil
    var verifiedState = "unknown"
    mutating func verified(_ state:String,now:Date=Date()) { verifiedState=state;verifiedAt=now }
    func status(preflight:Bool,now:Date=Date()) -> String {
        if preflight { return "authorized" }
        if let at=verifiedAt,now.timeIntervalSince(at)<15,verifiedState=="denied" { return "denied" }
        return "unknown"
    }
}
func screenPermissionMetadata(load:() async throws -> Void) async -> String {
    do { try await load();return "unknown" }
    catch {
        let e=error as NSError
        return e.domain==SCStreamErrorDomain && e.code==SCStreamError.Code.userDeclined.rawValue ? "denied":"unknown"
    }
}
final class LocalAPI {
    let base: URL;var owner:String
    init(_ server: String,owner:String="") {
        self.owner=owner
        guard let u=URL(string:server),u.scheme=="http",["127.0.0.1","::1","[::1]"].contains(u.host ?? ""),u.user==nil,u.password==nil,u.port != nil else { fatalError("Invalid local server") }
        base=u
    }
    // A singleton may retain an older loopback address. Only an idle handoff
    // may adopt the new launcher's exact same-port endpoint; never retry writes.
    static func handoffEndpoint(_ value:String,current:URL) -> URL? {
        guard let u=URL(string:value),u.scheme=="http",["127.0.0.1","::1","[::1]"].contains(u.host ?? ""),u.user==nil,u.password==nil,u.port==current.port,u.port != nil,
              (u.path.isEmpty || u.path=="/"),u.query==nil,u.fragment==nil else { return nil }
        return u
    }
    func request(_ route: String, _ body: [String:Any]?=nil) async throws -> [String:Any] {
        var req=URLRequest(url:base.appendingPathComponent("native/"+route));req.timeoutInterval = route == "end" ? 20 : 7
        if !owner.isEmpty { req.setValue(owner,forHTTPHeaderField:"X-THT-Native-Owner") }
        if let body=body { req.httpMethod="POST";req.setValue("application/json",forHTTPHeaderField:"Content-Type");req.httpBody=try JSONSerialization.data(withJSONObject:body) }
        let (data,response)=try await URLSession.shared.data(for:req)
        let j=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] ?? [:]
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { let code = j["error"] as? String; throw CaptureError.message(code == "native_start_superseded" ? "这次开始已被新的录音取代，关掉这个窗口即可" : code ?? "本机连接失败") }
        return j
    }
}
// Recognizer partials can revise earlier words. Timestamp boundaries ensure
// a correction to old text does not suppress the following new sentence.
struct SpeechPiece { let start:Double;let end:Double;let range:NSRange }
struct SpeechDelta {
    var through:Double = -1
    mutating func take(_ text:String,pieces:[SpeechPiece],limit:Int?=nil) -> String? {
        let source=text as NSString;let end=min(limit ?? source.length,source.length)
        let fresh=pieces.filter { $0.start >= through-0.05 && $0.end > through+0.02 && NSMaxRange($0.range)<=end }
        guard let first=fresh.first,let last=fresh.last,first.range.location<end else { return nil }
        let value=source.substring(with:NSRange(location:first.range.location,length:end-first.range.location)).trimmingCharacters(in:.whitespacesAndNewlines)
        guard !value.isEmpty else { return nil };through=last.end;return value
    }
}
final class SpeechStream {
    let queue: DispatchQueue; let recognizer: SFSpeechRecognizer
    let emit: (String,String)->Void; let failure:(String)->Void
    var request: SFSpeechAudioBufferRecognitionRequest?; var task:SFSpeechRecognitionTask?
    var epoch=0;var delta=SpeechDelta();var latest="";var pieces:[SpeechPiece]=[];var lastUpdate=Date.distantPast
    var rotate: DispatchSourceTimer?;var silence:DispatchSourceTimer?;var running=false;var errors=0
    init(locale:String, queue:DispatchQueue, emit:@escaping(String,String)->Void, failure:@escaping(String)->Void) throws {
        guard let r=SFSpeechRecognizer(locale:Locale(identifier:locale)),r.supportsOnDeviceRecognition else { throw CaptureError.message("这门语言的本机转写不可用；请在 macOS 下载语音识别语言后重试") }
        self.queue=queue;self.recognizer=r;self.emit=emit;self.failure=failure
    }
    func start() {
        guard !running else { return };running=true;errors=0;open()
        let r=DispatchSource.makeTimerSource(queue:queue);r.schedule(deadline:.now()+20,repeating:20);r.setEventHandler { [weak self] in self?.rotateRequest() };r.resume();rotate=r
        let s=DispatchSource.makeTimerSource(queue:queue);s.schedule(deadline:.now()+1,repeating:0.5);s.setEventHandler { [weak self] in
            guard let self=self,self.running,Date().timeIntervalSince(self.lastUpdate)>1.1 else { return };self.commit(self.latest)
        };s.resume();silence=s
    }
    func open() {
        epoch += 1;let token=epoch;delta=SpeechDelta();latest="";pieces=[]
        let r=SFSpeechAudioBufferRecognitionRequest();r.requiresOnDeviceRecognition=true;r.shouldReportPartialResults=true;r.taskHint = .dictation
        request=r
        task=recognizer.recognitionTask(with:r) { [weak self] result,error in
            guard let self=self else { return };self.queue.async {
                guard self.running,self.epoch==token else { return }
                if let result=result {
                    self.errors=0
                    let transcription=result.bestTranscription;let text=transcription.formattedString
                    self.pieces=transcription.segments.map { SpeechPiece(start:$0.timestamp,end:$0.timestamp+$0.duration,range:$0.substringRange) }
                    if text != self.latest { self.lastUpdate=Date();self.latest=text }
                    if result.isFinal { self.commit(text);self.rotateRequest();return }
                    if let end=text.range(of:"[。！？.!?]",options:[.regularExpression,.backwards]) {
                        self.commit(String(text[..<end.upperBound]))
                    }
                }
                // 216/301 = 取消，1110 = 静音没识别到话：都不算故障。真故障也不永久停：
                // 退避 1/2/4…30 秒重开识别请求，录音始终不受影响，恢复后 errors 归零。
                if let error=error, ![216,301,1110].contains((error as NSError).code) {
                    self.errors += 1
                    if self.errors == 1 || self.errors % 5 == 0 { self.failure("本机转写暂时中断，正在自动恢复："+error.localizedDescription) }
                    let wait=min(30.0,pow(2.0,Double(self.errors-1)))
                    self.queue.asyncAfter(deadline:.now()+wait) { [weak self] in
                        guard let self=self,self.running,self.epoch==token else { return };self.rotateRequest()
                    }
                }
            }
        }
    }
    func commit(_ text:String) {
        if let tail=delta.take(latest,pieces:pieces,limit:text.utf16.count) { emit(UUID().uuidString,tail) }
    }
    func rotateRequest() { guard running else { return };commit(latest);request?.endAudio();task?.cancel();open() }
    func append(_ buffer:CMSampleBuffer) { if running { request?.appendAudioSampleBuffer(buffer) } }
    func append(_ buffer:AVAudioPCMBuffer) { if running { request?.append(buffer) } }
    func stop() { commit(latest);running=false;rotate?.cancel();silence?.cancel();request?.endAudio();task?.cancel();request=nil;task=nil;epoch += 1 }
}
// Both sources share the host clock. Never concatenate microphone buffers onto
// system buffers: doing so doubles time and loses overlapping speech.
struct TimelineMixer {
    let origin:Double
    var through=0
    var blocks:[Int:[Float]]=[:]
    mutating func add(_ values:[Float],at:Double) {
        let start=Int(((at-origin)*16000).rounded())
        guard start < through*320+16000*30 else { return }
        for (i,value) in values.enumerated() {
            let sample=start+i;guard sample>=through*320 else { continue }
            let block=sample/320,offset=sample%320
            if blocks[block]==nil { blocks[block]=[Float](repeating:0,count:320) }
            blocks[block]![offset] += value.isFinite ? value:0
        }
    }
    mutating func drain(to time:Double,final:Bool=false)->[[Float]] {
        let target=final ? (blocks.keys.max().map{$0+1} ?? through):max(through,Int((time-origin)*50)-10)
        guard target>through else { return [] }
        var result:[[Float]]=[]
        while through<target { result.append((blocks.removeValue(forKey:through) ?? [Float](repeating:0,count:320)).map{max(-1,min(1,$0))});through += 1 }
        return result
    }
}
// Audio captured after Start but before the meeting file exists. Bounded; the oldest bytes go first.
struct PrerollBuffer {
    let limit:Int;var data=Data();var dropped=0
    init(limit:Int) { self.limit=limit }
    mutating func append(_ bytes:Data) { data.append(bytes);if data.count>limit { let extra=data.count-limit;data.removeFirst(extra);dropped+=extra } }
    mutating func take()->Data { defer { data=Data() };return data }
}
// Monotonic deadline shared by retries and the independent watchdog.
struct StreamRecoveryPlan {
    let started:Double
    var attempt=0
    func expired(_ now:Double)->Bool { now-started>=60 }
    mutating func delay(_ now:Double)->Double {
        let wait=min(pow(2,Double(min(attempt,5))),max(0,60-(now-started)))
        attempt+=1;return wait
    }
}

final class CaptureEngine: NSObject, SCStreamOutput, SCStreamDelegate {
    let queue=DispatchQueue(label:"com.citeside.capture")
    let ci=CIContext(options:[.cacheIntermediates:false])
    let pcm:(Data)->Void;var pendingPCM=Data();let text:(String,String)->Void;let frame:(Data)->Void;let failure:(String)->Void
    var recoveryChanged:((String)->Void)?
    var recoveryTask:Task<Void,Never>?;var recoveryDeadline:Task<Void,Never>?;var recoveryGeneration=0
    var stoppedStreamIDs=Set<ObjectIdentifier>()
    @MainActor lazy var streamReceipts=CaptureStreamReceipts()
    var targetWindowID:CGWindowID?;var captureReady=false;var systemAudioUnavailable=false
    private let streamLock=NSLock();private var currentScreen:SCStream?;private var currentAudio:SCStream?
    var screen:SCStream? { get { streamLock.lock();defer { streamLock.unlock() };return currentScreen } set { streamLock.lock();currentScreen=newValue;streamLock.unlock() } }
    var audio:SCStream? { get { streamLock.lock();defer { streamLock.unlock() };return currentAudio } set { streamLock.lock();currentAudio=newValue;streamLock.unlock() } };var speech:SpeechStream?;var file:FileHandle?
    // Recording starts on Start; the server's meeting file is attached once it exists (60 s cap).
    var preroll=PrerollBuffer(limit:16000*2*60);var attached=false
    var inputUID="";var inputName=""
    var microphone:AVAudioEngine?;var mixTimer:DispatchSourceTimer?;var mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime)
    let mixedFormat=AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:16000,channels:1,interleaved:false)!
    var microphoneFrames=0;var systemFrames=0;var microphonePeak:Float=0;var systemPeak:Float=0;var microphoneLastAt=Date.distantPast;var systemLastAt=Date.distantPast;var microphoneLevel:Float=0;var systemLevel:Float=0
    func audioEvidence()->[String:Any] { queue.sync { ["microphoneFrames":microphoneFrames,"systemFrames":systemFrames,"microphonePeak":microphonePeak,"systemPeak":systemPeak,"microphoneLevel":Date().timeIntervalSince(microphoneLastAt)<1 ? microphoneLevel:0,"systemLevel":Date().timeIntervalSince(systemLastAt)<1 ? systemLevel:0] } }
    let meterLock=NSLock()
    func meterSnapshot()->Double { meterLock.lock();defer{meterLock.unlock()};return Date().timeIntervalSince(audioLevelAt)<1 ? audioLevel:0 }
    var gate=PageGate();var seconds:Double=0;var audioLevel:Double=0;var audioLevelAt=Date.distantPast;var paused=false;var closing=false
    init(pcm:@escaping(Data)->Void,text:@escaping(String,String)->Void,frame:@escaping(Data)->Void,failure:@escaping(String)->Void) { self.pcm=pcm;self.text=text;self.frame=frame;self.failure=failure }
    func start(target:MeetingTarget?,content:SCShareableContent,locale:String,audioPath:String,cloudASR:Bool,inputUID:String="") async throws {
        try await begin(target:target,content:content,locale:locale,cloudASR:cloudASR,inputUID:inputUID);try await attach(audioPath:audioPath)
    }
    // Write what was heard before the meeting existed, then continue into the same file.
    func attach(audioPath:String) async throws {
        guard FileManager.default.fileExists(atPath:audioPath) else { throw CaptureError.message("本机录音文件未创建") }
        let handle=try FileHandle(forWritingTo:URL(fileURLWithPath:audioPath));try handle.seekToEnd()
        try await withCheckedThrowingContinuation { (c:CheckedContinuation<Void,Error>) in queue.async {
            do { let early=self.preroll.take();if !early.isEmpty { try handle.write(contentsOf:early) };self.file=handle;self.attached=true;c.resume() } catch { c.resume(throwing:error) }
        } }
    }
    @MainActor func begin(target:MeetingTarget?,content:SCShareableContent,locale:String,cloudASR:Bool,inputUID:String="") async throws {
        if !cloudASR { speech=try SpeechStream(locale:locale,queue:queue,emit:text,failure:failure)
        queue.sync { speech?.start() } }
        targetWindowID=target?.window.windowID
        let streams=try makeStreams(content:content)
        screen=streams.0;audio=streams.1
        let a=streams.1
        do {
            // inputNode synchronously waits on the audio-unit queue. On the main
            // thread that queue can be inside a HAL call which itself needs the
            // main thread, so the start never returns.
            try await withCheckedThrowingContinuation { (c:CheckedContinuation<Void,Error>) in
                DispatchQueue.global(qos:.userInitiated).async {
                    do { try self.switchMicrophone(uid:inputUID);c.resume() }
                    catch { c.resume(throwing:error) }
                }
            }
            queue.sync { mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime) }
            if let stream=screen { try await streamReceipts.start(stream) { try await stream.startCapture() } };if let stream=a { try await streamReceipts.start(stream) { try await stream.startCapture() } }
            let timer=DispatchSource.makeTimerSource(queue:queue);timer.schedule(deadline:.now(),repeating:.milliseconds(20));timer.setEventHandler { [weak self] in self?.flushMix() };mixTimer=timer;timer.resume();captureReady=true;systemAudioUnavailable=a == nil;if systemAudioUnavailable || !stoppedStreamIDs.isEmpty { recoverStreams() }
        }
        catch { _ = await stop();throw error }
    }
    func makeStreams(content:SCShareableContent) throws -> (SCStream?,SCStream?) {
        guard let display=content.displays.first else { return (nil,nil) }
        let target=content.windows.first { $0.windowID==targetWindowID }
        var screen:SCStream?
        if let target=target { let size=target.frame.size;let scale=min(1,960/max(size.width,size.height))
        let vc=SCStreamConfiguration();vc.width=max(32,Int(size.width*scale));vc.height=max(32,Int(size.height*scale));vc.minimumFrameInterval=CMTime(value:1,timescale:3);vc.showsCursor=false;vc.queueDepth=3;vc.capturesAudio=false
        let vs=SCStream(filter:SCContentFilter(desktopIndependentWindow:target),configuration:vc,delegate:self)
        try vs.addStreamOutput(self,type:.screen,sampleHandlerQueue:queue);screen=vs }
        let ac=SCStreamConfiguration();ac.capturesAudio=true;ac.sampleRate=16000;ac.channelCount=1;ac.excludesCurrentProcessAudio=true;ac.width=32;ac.height=32;ac.minimumFrameInterval=CMTime(value:1,timescale:1)
        let own=content.applications.filter { $0.processID==ProcessInfo.processInfo.processIdentifier }
        let a=SCStream(filter:SCContentFilter(display:display,excludingApplications:own,exceptingWindows:[]),configuration:ac,delegate:self)
        try a.addStreamOutput(self,type:.audio,sampleHandlerQueue:queue);
        return (screen,a)
    }
    // Only SCStream is replaced: microphone, mixer origin, file and speech stay alive.
    @MainActor func recoverStreams() {
        guard captureReady,!closing,recoveryTask==nil else { return }
        recoveryGeneration+=1;let generation=recoveryGeneration
        recoveryChanged?(systemAudioUnavailable ? "system-audio-unavailable":"recovering")
        recoveryDeadline=Task { @MainActor [weak self] in
            do { try await Task.sleep(nanoseconds:60_000_000_000) } catch { return }
            guard let self=self,!self.closing,self.recoveryGeneration==generation else { return }
            self.recoveryGeneration+=1;self.recoveryTask?.cancel();self.recoveryTask=nil
            self.recoveryChanged?(self.systemAudioUnavailable ? "system-audio-unavailable":"failed")
            // A stalled SCStream await must not permanently end background recovery.
            do { try await Task.sleep(nanoseconds:1_000_000_000) } catch { return }
            guard !self.closing,self.recoveryGeneration==generation+1 else { return }
            self.recoverStreams()
        }
        recoveryTask=Task { @MainActor [weak self] in
            guard let self=self else { return }
            var plan=StreamRecoveryPlan(started:ProcessInfo.processInfo.systemUptime)
            let oldScreen=self.screen,oldAudio=self.audio
            self.screen=nil;self.audio=nil
            // Some stopped streams never complete stopCapture; retire them off the retry path.
            Task { try? await self.streamReceipts.stop(oldScreen) { try await oldScreen?.stopCapture() };try? await self.streamReceipts.stop(oldAudio) { try await oldAudio?.stopCapture() } }
            while !Task.isCancelled && !self.closing && self.recoveryGeneration==generation {
                let delay=min(2,plan.delay(ProcessInfo.processInfo.systemUptime))
                do { try await Task.sleep(nanoseconds:UInt64(delay*1_000_000_000)) } catch { return }
                guard !plan.expired(ProcessInfo.processInfo.systemUptime),!self.closing,self.recoveryGeneration==generation else { return }
                var candidate:(SCStream?,SCStream?)?
                do {
                    let content=try await SCShareableContent.excludingDesktopWindows(false,onScreenWindowsOnly:true)
                    guard !Task.isCancelled,!self.closing,self.recoveryGeneration==generation else { return }
                    let next=try self.makeStreams(content:content);candidate=next
                    guard let nextAudio=next.1 else {
                        self.systemAudioUnavailable=true;self.recoveryChanged?("system-audio-unavailable");continue
                    }
                    self.stoppedStreamIDs.removeAll();self.screen=next.0;self.audio=next.1
                    if let stream=next.0 { try await self.streamReceipts.start(stream) { try await stream.startCapture() } };try await self.streamReceipts.start(nextAudio) { try await nextAudio.startCapture() }
                    if self.stoppedStreamIDs.contains(ObjectIdentifier(nextAudio)) || (next.0.map { self.stoppedStreamIDs.contains(ObjectIdentifier($0)) } ?? false) { throw CaptureError.message("流启动后已停止") }
                    guard !Task.isCancelled,!self.closing,self.recoveryGeneration==generation else {
                        try? await self.streamReceipts.stop(next.0) { try await next.0?.stopCapture() };try? await self.streamReceipts.stop(nextAudio) { try await nextAudio.stopCapture() };return
                    }
                    self.systemAudioUnavailable=false;self.recoveryDeadline?.cancel();self.recoveryTask=nil;self.recoveryChanged?("ready");return
                } catch {
                    // A cancelled old attempt must never clear a newer connection.
                    if self.recoveryGeneration==generation { self.screen=nil;self.audio=nil }
                    try? await self.streamReceipts.stop(candidate?.0) { try await candidate?.0?.stopCapture() };try? await self.streamReceipts.stop(candidate?.1) { try await candidate?.1?.stopCapture() }
                    guard self.recoveryGeneration==generation else { return }
                }
            }
        }
    }
    // Start the replacement first. System stream, timeline, file and ASR stay intact.
    func switchMicrophone(uid:String) throws {
        guard !closing else { throw CaptureError.message("会议已结束") }
        let devices=microphoneDevices()
        guard let device=devices.first(where:{ uid.isEmpty ? $0.isDefault:$0.uid==uid }) else { throw CaptureError.message("所选麦克风已断开；原声音来源保持不变") }
        if microphone != nil && inputUID==device.uid { return }
        let mic=AVAudioEngine(),input=mic.inputNode
        guard let unit=input.audioUnit else { throw CaptureError.message("无法连接麦克风") }
        var deviceID=device.id
        guard AudioUnitSetProperty(unit,kAudioOutputUnitProperty_CurrentDevice,kAudioUnitScope_Global,0,&deviceID,UInt32(MemoryLayout<AudioDeviceID>.size))==noErr else { throw CaptureError.message("无法切换到所选麦克风；原声音来源保持不变") }
        var actualID:AudioDeviceID=0;var actualSize=UInt32(MemoryLayout<AudioDeviceID>.size)
        guard AudioUnitGetProperty(unit,kAudioOutputUnitProperty_CurrentDevice,kAudioUnitScope_Global,0,&actualID,&actualSize)==noErr,actualID==device.id else { throw CaptureError.message("录音端未确认所选麦克风；原声音来源保持不变") }
        let inputFormat=input.outputFormat(forBus:0)
            guard inputFormat.sampleRate>0,inputFormat.channelCount>0,let converter=AVAudioConverter(from:inputFormat,to:mixedFormat) else { throw CaptureError.message("麦克风不可用，未开始仅录系统声音的会议") }
            input.installTap(onBus:0,bufferSize:2048,format:inputFormat) { [weak self] buffer,time in
                guard let self=self,let converted=AVAudioPCMBuffer(pcmFormat:self.mixedFormat,frameCapacity:AVAudioFrameCount(Double(buffer.frameLength)*16000/inputFormat.sampleRate)+32) else { return }
                var supplied=false;var conversionError:NSError?
                converter.convert(to:converted,error:&conversionError) { _,status in
                    if supplied { status.pointee = .noDataNow;return nil };supplied=true;status.pointee = .haveData;return buffer
                }
                if let error=conversionError { self.queue.async { if self.microphone === mic && !self.closing { self.failure("麦克风采集失败："+error.localizedDescription) } };return }
                guard let samples=converted.floatChannelData?[0] else { return }
                let values=Array(UnsafeBufferPointer(start:samples,count:Int(converted.frameLength))),at=AVAudioTime.seconds(forHostTime:time.hostTime)
                self.queue.async { if self.microphone === mic && !self.paused && !self.closing { self.microphoneFrames+=values.count;self.microphoneLastAt=Date();self.microphoneLevel=values.reduce(0){max($0,abs($1))};self.microphonePeak=max(self.microphonePeak,values.reduce(0){max($0,abs($1))});self.mixer.add(values,at:at) } }
            }
        do { try mic.start() } catch { input.removeTap(onBus:0);mic.stop();throw error }
        let old=queue.sync { ()->AVAudioEngine? in
            let previous=microphone;microphone=mic;inputUID=device.uid;inputName=device.name;return previous
        }
        old?.inputNode.removeTap(onBus:0);old?.stop()

    }
    func pause(_ value:Bool) async {
        await withCheckedContinuation { (c:CheckedContinuation<Void,Never>) in queue.async { self.paused=value;if value { self.flushMix(final:true);self.speech?.stop() } else { self.mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime);self.gate=PageGate();self.speech?.start() };c.resume() } }
    }
    private var stopCoordinator:CaptureStopCoordinator?;private var stopTailFlushed=false
    @MainActor func stop(discardPending:Bool=false) async -> Bool {
        closing=true;captureReady=false;recoveryGeneration+=1;recoveryTask?.cancel();recoveryDeadline?.cancel();recoveryTask=nil;microphone?.inputNode.removeTap(onBus:0);microphone?.stop();microphone=nil;mixTimer?.cancel();mixTimer=nil
        let tailSaved=await withCheckedContinuation { (c:CheckedContinuation<Bool,Never>) in queue.async {
            if !self.stopTailFlushed { self.stopTailFlushed=true;if !discardPending { self.flushMix(final:true) };self.pendingPCM.removeAll();self.speech?.stop() }
            do { try self.file?.synchronize();try self.file?.close();self.file=nil;c.resume(returning:true) }
            catch { self.failure("录音文件收尾失败："+error.localizedDescription);c.resume(returning:false) }
        } }
        let coordinator=stopCoordinator ?? CaptureStopCoordinator();stopCoordinator=coordinator
        let stoppingScreen=screen,stoppingAudio=audio
        let confirmed=await coordinator.stop([{ try await self.streamReceipts.stop(stoppingScreen) { try await stoppingScreen?.stopCapture() } },{ try await self.streamReceipts.stop(stoppingAudio) { try await stoppingAudio?.stopCapture() } }])
        if confirmed { screen=nil;audio=nil };return confirmed && tailSaved
    }
    func stream(_ stream:SCStream,didStopWithError error:Error) {
        Task { @MainActor [weak self] in
            guard let self=self,(stream === self.screen || stream === self.audio) else { return }
            self.streamReceipts.didStop(stream)
            guard !self.closing else { return }
            self.stoppedStreamIDs.insert(ObjectIdentifier(stream));self.recoverStreams()
        }
    }
    func stream(_ stream:SCStream,didOutputSampleBuffer sampleBuffer:CMSampleBuffer,of type:SCStreamOutputType) {
        guard !paused,!closing,sampleBuffer.isValid else { return }
        if type == .audio {
            guard stream === audio else { return }
            acceptSystemAudio(sampleBuffer)
            return
        }
        guard type == .screen,stream === screen,let pixel=sampleBuffer.imageBuffer else { return }
        if let a=CMSampleBufferGetSampleAttachmentsArray(sampleBuffer,createIfNecessary:false) as? [[SCStreamFrameInfo:Any]],let raw=a.first?[.status] as? Int,raw != SCFrameStatus.complete.rawValue { return }
        let image=CIImage(cvPixelBuffer:pixel);let extent=image.extent
        let thumb=image.transformed(by:CGAffineTransform(scaleX:64/extent.width,y:36/extent.height))
        var luminance=[UInt8](repeating:0,count:64*36)
        luminance.withUnsafeMutableBytes { ci.render(thumb,toBitmap:$0.baseAddress!,rowBytes:64,bounds:CGRect(x:0,y:0,width:64,height:36),format:.L8,colorSpace:CGColorSpaceCreateDeviceGray()) }
        guard gate.accepts(luminance,now:ProcessInfo.processInfo.systemUptime),let cg=ci.createCGImage(image,from:extent) else { return }
        let bitmap=NSBitmapImageRep(cgImage:cg)
        for quality in [0.55,0.35,0.20] { if let jpeg=bitmap.representation(using:.jpeg,properties:[.compressionFactor:quality]),jpeg.count<=160000 { frame(jpeg);return } }
    }
    func acceptSystemAudio(_ sampleBuffer:CMSampleBuffer) {
        do { let values=try systemSamples(sampleBuffer);systemFrames+=values.count;systemLastAt=Date();systemLevel=values.reduce(0){max($0,abs($1))};systemPeak=max(systemPeak,systemLevel);mixer.add(values,at:CMSampleBufferGetPresentationTimeStamp(sampleBuffer).seconds) }
        catch { failure("系统声音采集失败："+error.localizedDescription) }
    }
    func systemSamples(_ sample:CMSampleBuffer) throws -> [Float] {
        guard let desc=sample.formatDescription,let format=CMAudioFormatDescriptionGetStreamBasicDescription(desc)?.pointee else { return [] }
        guard format.mFormatID==kAudioFormatLinearPCM,format.mChannelsPerFrame==1,abs(format.mSampleRate-16000)<1 else { throw CaptureError.message("系统声音格式不符合本机录音要求") }
        var list=AudioBufferList(mNumberBuffers:1,mBuffers:AudioBuffer(mNumberChannels:1,mDataByteSize:0,mData:nil));var block:CMBlockBuffer?
        let code=CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sample,bufferListSizeNeededOut:nil,bufferListOut:&list,bufferListSize:MemoryLayout<AudioBufferList>.size,blockBufferAllocator:nil,blockBufferMemoryAllocator:nil,flags:0,blockBufferOut:&block)
        guard code==noErr,let ptr=list.mBuffers.mData else { throw CaptureError.message("系统声音缓冲区不可读") }
        let count=CMSampleBufferGetNumSamples(sample)
        // Reject truncated/foreign PCM before constructing an unsafe buffer.
        let bytesPerSample=Int(format.mBitsPerChannel/8)
        guard count>0,bytesPerSample>0,count<=Int(list.mBuffers.mDataByteSize)/bytesPerSample,
              format.mFormatFlags & kAudioFormatFlagIsBigEndian == 0 else {
            throw CaptureError.message("系统声音缓冲区长度或字节序无效")
        }
        if format.mFormatFlags & kAudioFormatFlagIsFloat != 0 && format.mBitsPerChannel==32 {
            return Array(UnsafeBufferPointer(start:ptr.assumingMemoryBound(to:Float.self),count:count))
        } else if format.mBitsPerChannel==16 && format.mFormatFlags & kAudioFormatFlagIsSignedInteger != 0 { return UnsafeBufferPointer(start:ptr.assumingMemoryBound(to:Int16.self),count:count).map{Float($0)/32768} }
        else { throw CaptureError.message("系统声音编码暂不支持") }
    }
    func flushMix(final:Bool=false) {
        guard final || (!paused && !closing) else { return }
        for values in mixer.drain(to:ProcessInfo.processInfo.systemUptime,final:final) {
            guard let buffer=AVAudioPCMBuffer(pcmFormat:mixedFormat,frameCapacity:320),let samples=buffer.floatChannelData?[0] else { continue }
            buffer.frameLength=320;for i in 0..<320 { samples[i]=values[i] };speech?.append(buffer)
            let pcm=values.map{Int16(max(-32768,min(32767,Int($0*32767))))},bytes=pcm.withUnsafeBytes{Data($0)}
            let power=values.reduce(0.0){$0+Double($1*$1)}
            meterLock.lock();audioLevel=min(1,sqrt(power/320)*5);audioLevelAt=Date();meterLock.unlock()
            do { if attached { try file?.write(contentsOf:bytes) } else { preroll.append(bytes) } } catch { failure("原始录音保存失败："+error.localizedDescription) }
            // Saving and live transport are independent: a file failure must not mute PCM.
            seconds += 0.02
            pendingPCM.append(bytes);if pendingPCM.count>=6400 { self.pcm(pendingPCM);pendingPCM.removeAll(keepingCapacity:true) }
        }
        if final && !pendingPCM.isEmpty { self.pcm(pendingPCM);pendingPCM.removeAll(keepingCapacity:true) }
    }
}
// MINI WINDOW (design-final.html #s-mini, 2026-10-25): tokens follow the design's light/dark palette.
func hexColor(_ hex:UInt32,_ alpha:CGFloat=1)->NSColor { NSColor(srgbRed:CGFloat((hex>>16)&0xff)/255,green:CGFloat((hex>>8)&0xff)/255,blue:CGFloat(hex&0xff)/255,alpha:alpha) }
func tone(_ light:NSColor,_ dark:NSColor)->NSColor { NSColor(name:nil) { $0.bestMatch(from:[.aqua,.darkAqua]) == .darkAqua ? dark:light } }
enum MiniTone {
    static let fg=tone(hexColor(0x161616),hexColor(0xececea));static let muted=tone(hexColor(0x6a6a66),hexColor(0x9a9a95))
    static let faint=tone(hexColor(0x9b9b96),hexColor(0x6e6e6a));static let line=tone(hexColor(0xe2e2de),hexColor(0x2c2c2a))
    static let panel=tone(hexColor(0xffffff),hexColor(0x1a1a1a));static let accent=tone(hexColor(0x0A74E0),hexColor(0x6CB2FF))
    static let finding=tone(hexColor(0x5B57D6),hexColor(0xA9A6FF));static let task=tone(hexColor(0x0A7A72),hexColor(0x4FD1C0))
    static let rail=tone(hexColor(0x1C2440,0.15),hexColor(0xFFFFFF,0.16))
    static let recording=hexColor(0xff9f0a) // Recording stays amber. Accent is the clickable blue shared with the main window.
    static let warn=tone(hexColor(0x8a5a00),hexColor(0xe0a84a));static let glass=tone(hexColor(0xffffff,0.72),hexColor(0x1e1e1d,0.66))
    static let glassLine=tone(hexColor(0x000000,0.08),hexColor(0xffffff,0.08))
}
// Layer colours are CGColors, so they are resolved again whenever the appearance changes.
final class ToneBox:NSView {
    var fill:NSColor? { didSet { needsDisplay=true } };var stroke:NSColor? { didSet { needsDisplay=true } };var radius:CGFloat=0 { didSet { needsDisplay=true } }
    init(fill:NSColor?,stroke:NSColor?=nil,radius:CGFloat=0) {
        self.fill=fill;self.stroke=stroke;self.radius=radius;super.init(frame:.zero)
        wantsLayer=true;layerContentsRedrawPolicy = .onSetNeedsDisplay;translatesAutoresizingMaskIntoConstraints=false
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    override var wantsUpdateLayer:Bool { true }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance();needsDisplay=true }
    override func updateLayer() {
        effectiveAppearance.performAsCurrentDrawingAppearance {
            layer?.backgroundColor=fill?.cgColor;layer?.borderColor=stroke?.cgColor
            layer?.borderWidth=stroke==nil ? 0:1;layer?.cornerRadius=radius
        }
    }
}
// Recording uses amber with a soft pulse; pause is a hollow grey dot; idle is faint.
final class RecDot:NSView {
    var state="idle" { didSet { if state != oldValue { needsDisplay=true;syncPulse() } } }
    let ring=CALayer()
    override init(frame:NSRect) {
        super.init(frame:frame);wantsLayer=true;layerContentsRedrawPolicy = .onSetNeedsDisplay;translatesAutoresizingMaskIntoConstraints=false
        widthAnchor.constraint(equalToConstant:8).isActive=true;heightAnchor.constraint(equalToConstant:8).isActive=true
        ring.frame=NSRect(x:0,y:0,width:8,height:8);ring.cornerRadius=4;ring.opacity=0;layer?.addSublayer(ring)
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    override var wantsUpdateLayer:Bool { true }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance();needsDisplay=true }
    override func updateLayer() {
        effectiveAppearance.performAsCurrentDrawingAppearance {
            let color=state=="rec" ? MiniTone.recording:MiniTone.faint
            layer?.backgroundColor=(state=="paused" ? NSColor.clear:color).cgColor;layer?.cornerRadius=4
            layer?.borderColor=color.cgColor;layer?.borderWidth=state=="paused" ? 1:0
            ring.backgroundColor=MiniTone.recording.withAlphaComponent(0.35).cgColor
        }
    }
    func syncPulse() {
        ring.removeAllAnimations()
        guard state=="rec",!NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else { return }
        let scale=CABasicAnimation(keyPath:"transform.scale");scale.fromValue=1;scale.toValue=2.75
        let fade=CABasicAnimation(keyPath:"opacity");fade.fromValue=0.9;fade.toValue=0
        let group=CAAnimationGroup();group.animations=[scale,fade];group.duration=1.8;group.repeatCount = .infinity
        ring.add(group,forKey:"pulse")
    }
}
// .btn (and .btn.primary): 32pt rounded control drawn with the design tokens.
final class MiniActionButton:NSButton {
    var primary=false { didSet { needsDisplay=true } }
    var link=false { didSet { needsDisplay=true } }
    var cardKey="";var cardText=""   // Deep research: which card this button researches
    init(title:String,primary:Bool=false,link:Bool=false,target:AnyObject?,action:Selector?) {
        super.init(frame:.zero);self.title=title;self.primary=primary;self.link=link;self.target=target;self.action=action
        isBordered=false;setButtonType(.momentaryPushIn);translatesAutoresizingMaskIntoConstraints=false
        if !link { heightAnchor.constraint(equalToConstant:32).isActive=true }
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    var titleFont:NSFont { link ? NSFont.systemFont(ofSize:12.5,weight:.regular) : NSFont.systemFont(ofSize:13.5,weight:.medium) }
    override var intrinsicContentSize:NSSize {
        let text=(title as NSString).size(withAttributes:[.font:titleFont])
        if link { return NSSize(width:ceil(text.width)+2,height:18) }
        return NSSize(width:ceil(text.width)+26,height:32)
    }
    override func draw(_ dirtyRect:NSRect) {
        let font=titleFont
        if link {
            let color=isEnabled ? MiniTone.accent:MiniTone.faint
            let attrs:[NSAttributedString.Key:Any]=[.font:font,.foregroundColor:color]
            let size=(title as NSString).size(withAttributes:attrs)
            (title as NSString).draw(at:NSPoint(x:0,y:(bounds.height-size.height)/2),withAttributes:attrs)
            return
        }
        let showBlue=primary && isEnabled
        let shape=NSBezierPath(roundedRect:bounds.insetBy(dx:0.5,dy:0.5),xRadius:8,yRadius:8)
        (showBlue ? MiniTone.accent:MiniTone.panel).setFill();shape.fill()
        if !showBlue { MiniTone.line.setStroke();shape.lineWidth=1;shape.stroke() }
        if isHighlighted { NSColor.black.withAlphaComponent(0.06).setFill();shape.fill() }
        let dark=effectiveAppearance.bestMatch(from:[.darkAqua,.aqua]) == .darkAqua
        let color=showBlue ? (dark ? NSColor(srgbRed:22/255,green:22/255,blue:22/255,alpha:1):NSColor.white):(isEnabled ? MiniTone.fg:MiniTone.faint)
        let attrs:[NSAttributedString.Key:Any]=[.font:font,.foregroundColor:color]
        let size=(title as NSString).size(withAttributes:attrs)
        (title as NSString).draw(at:NSPoint(x:(bounds.width-size.width)/2,y:(bounds.height-size.height)/2),withAttributes:attrs)
    }
}
// .ib: 32×32 borderless icon button in the muted ink.
func miniIconButton(_ symbol:String,_ label:String,target:AnyObject,action:Selector)->NSButton {
    let b=NSButton(title:"",target:target,action:action);b.isBordered=false;b.setButtonType(.momentaryPushIn)
    b.image=NSImage(systemSymbolName:symbol,accessibilityDescription:label)?.withSymbolConfiguration(.init(pointSize:13,weight:.regular));b.imagePosition = .imageOnly
    b.contentTintColor=MiniTone.muted;b.toolTip=label;b.setAccessibilityLabel(label);b.translatesAutoresizingMaskIntoConstraints=false
    b.widthAnchor.constraint(equalToConstant:32).isActive=true;b.heightAnchor.constraint(equalToConstant:32).isActive=true
    return b
}
// .lab: 12.5 system caption. The clock uses the system font with tabular digits.
func miniDrawRail(in rect:NSRect,fade:Bool,gap:NSRect?=nil) {
    guard rect.width>0,rect.height>0 else { return }
    func paint(_ piece:NSRect,fadePiece:Bool) {
        guard piece.width>0,piece.height>0.4 else { return }
        if !fadePiece { MiniTone.rail.setFill();piece.fill();return }
        guard let ctx=NSGraphicsContext.current?.cgContext else { MiniTone.rail.setFill();piece.fill();return }
        ctx.saveGState();ctx.clip(to:piece)
        let color=MiniTone.rail.cgColor,clear=MiniTone.rail.withAlphaComponent(0).cgColor
        if let g=CGGradient(colorsSpace:CGColorSpaceCreateDeviceRGB(),colors:[color,clear] as CFArray,locations:[0,1]) {
            ctx.drawLinearGradient(g,start:CGPoint(x:piece.midX,y:piece.minY),end:CGPoint(x:piece.midX,y:piece.maxY),options:[])
        }
        ctx.restoreGState()
    }
    let hole=gap ?? NSRect.null
    let cut=hole.isNull ? NSRect.null:rect.intersection(hole)
    if cut.isNull || cut.width<=0 || cut.height<=0 { paint(rect,fadePiece:fade);return }
    paint(NSRect(x:rect.minX,y:rect.minY,width:rect.width,height:max(0,cut.minY-rect.minY)),fadePiece:false)
    paint(NSRect(x:rect.minX,y:cut.maxY,width:rect.width,height:max(0,rect.maxY-cut.maxY)),fadePiece:fade)
}
func miniTopicTitle(_ title:String,time:String)->NSAttributedString {
    let paragraph=NSMutableParagraphStyle();paragraph.lineBreakMode = .byWordWrapping
    let out=NSMutableAttributedString(string:title,attributes:[.font:NSFont.systemFont(ofSize:14.5,weight:.semibold),.foregroundColor:MiniTone.fg,.paragraphStyle:paragraph])
    if !time.isEmpty { out.append(NSAttributedString(string:"  "+time,attributes:[.font:NSFont.monospacedDigitSystemFont(ofSize:12.5,weight:.regular),.foregroundColor:MiniTone.muted,.paragraphStyle:paragraph])) }
    return out
}
func miniCaption(_ text:String,time:String,color:NSColor=MiniTone.muted,weight:NSFont.Weight = .regular)->NSAttributedString {
    let s=NSMutableAttributedString(string:text,attributes:[.font:NSFont.systemFont(ofSize:12.5,weight:weight),.foregroundColor:color])
    if !time.isEmpty { s.append(NSAttributedString(string:"  "+time,attributes:[.font:NSFont.monospacedDigitSystemFont(ofSize:12.5,weight:.regular),.foregroundColor:MiniTone.faint])) }
    return s
}
func miniDisplayText(_ raw:String)->String {
    raw.split(separator:"\n",omittingEmptySubsequences:false).map { line in
        line.replacingOccurrences(of:#"^\s*(?:动作|建议|Action|Suggestion)\s*[:：]\s*"#,with:"",options:.regularExpression)
    }.joined(separator:"\n").trimmingCharacters(in:.whitespacesAndNewlines)
}
func miniSentenceSplit(_ text:String)->(String,String) {
    var index=text.startIndex
    while index<text.endIndex {
        let ch=text[index]
        let next=text.index(after:index)
        let isCjk=ch=="。"||ch=="！"||ch=="？"
        let isAscii=ch=="."||ch=="!"||ch=="?"
        if isCjk || (isAscii && (next==text.endIndex || text[next].isWhitespace)) {
            return (String(text[..<next]), String(text[next...]))
        }
        index=next
    }
    return (text,"")
}
func clockText(_ seconds:Int,hours:Bool)->String { let s=max(0,seconds);return hours || s>=3600 ? String(format:"%02d:%02d:%02d",s/3600,s/60%60,s%60):String(format:"%02d:%02d",s/60,s%60) }
final class AudioMeter:NSView {
    var level:Double=0 { didSet { needsDisplay=true } }
    // mini = the design's .lv: four 2.5pt accent bars at 6/12/8/11pt, faint 3pt when idle or paused.
    var mini=false { didSet { invalidateIntrinsicContentSize();needsDisplay=true } };var dim=false { didSet { needsDisplay=true } }
    override var intrinsicContentSize:NSSize { mini ? NSSize(width:16,height:14):NSSize(width:30,height:18) }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance();needsDisplay=true }
    override func draw(_ dirtyRect:NSRect) {
        if mini {
            let value=max(0,min(1,level)),quiet=dim || value<=0.015
            for (i,h0) in [6.0,12.0,8.0,11.0].enumerated() {
                let h=quiet ? 3:max(3,CGFloat(h0)*CGFloat(0.4+0.6*value))
                (quiet ? MiniTone.faint:MiniTone.recording).setFill()
                NSBezierPath(roundedRect:NSRect(x:CGFloat(i)*4.5,y:(bounds.height-h)/2,width:2.5,height:h),xRadius:1.25,yRadius:1.25).fill()
            }
            return
        }
        let value=max(0,min(1,level));let weights:[Double]=[0.45,0.8,1,0.65,0.35]
        for (i,w) in weights.enumerated() {
            let h=max(3,CGFloat(value*w)*16)
            (value>0.015 ? MiniTone.recording:NSColor.tertiaryLabelColor).setFill()
            NSBezierPath(roundedRect:NSRect(x:CGFloat(i)*6,y:(bounds.height-h)/2,width:3,height:h),xRadius:1.5,yRadius:1.5).fill()
        }
    }
}
// Pure presentation state: polling/status changes never choose a window mode.
struct MiniUnreadState {
    var session=""
    var seen:[String:String]=[:]
    var unread=false
    mutating func update(session next:String,content:[String:String],viewed:Bool) {
        if session != next { session=next;seen=[:];unread=false }
        if next.isEmpty { unread=false;return }
        if content.contains(where:{ seen[$0.key] != $0.value }) { unread=true }
        for (key,value) in content { seen[key]=value }
        if viewed { unread=false }
    }
}
func miniMainIsForeground(policy:Bool,ownerPID:Int32,frontmostPID:Int32?,visible:Bool)->Bool {
    if ownerPID>0 { return frontmostPID == ownerPID && visible }
    return policy
}
func miniContentFingerprints(_ status:[String:Any])->[String:String] {
    let cards=status["cards"] as? [String:Any] ?? [:]
    var result:[String:String]=[:]
    func add(_ item:[String:Any],kind:String) {
        guard let text=item["text"] as? String,!text.isEmpty else { return }
        let key=item["key"] as? String ?? text
        result[kind+":"+key]=text
    }
    for row in cards["history"] as? [[String:Any]] ?? [] { add(row,kind:row["kind"] as? String ?? "insight") }
    if let row=cards["suggestion"] as? [String:Any] { add(row,kind:"suggestion") }
    for row in cards["insights"] as? [[String:Any]] ?? [] { add(row,kind:"insight") }
    if let row=status["confirmation"] as? [String:Any],let id=row["id"] as? String {
        result["confirmation:"+id]=(row["question"] as? String ?? "")+"|"+(row["statement"] as? String ?? "")
    }
    return result
}
enum MiniView:String { case expanded,compact,capsule,transcript,hidden }
// Presentation never owns the recording lifecycle. Preserve the top-right anchor.
func miniFrame(_ old:NSRect,size:NSSize,screens:[NSRect])->NSRect {
    guard let screen=screens.max(by:{ a,b in
        let ia=old.intersection(a),ib=old.intersection(b)
        return (ia.isNull ? 0:ia.width*ia.height)<(ib.isNull ? 0:ib.width*ib.height)
    }) else { return NSRect(x:old.maxX-size.width,y:old.maxY-size.height,width:size.width,height:size.height) }
    let width=min(size.width,screen.width),height=min(size.height,screen.height)
    return NSRect(x:min(max(old.maxX-width,screen.minX),screen.maxX-width),y:min(max(old.maxY-height,screen.minY),screen.maxY-height),width:width,height:height)
}
// No saved shape: a recording opens the compact bar. Saved expanded / capsule is left alone.
func recordingMiniView()->MiniView { .compact }
func placedMiniFrame(on screen:NSRect,size:NSSize)->NSRect {
    let old=NSRect(x:screen.maxX-size.width-18,y:screen.maxY-size.height-18,width:size.width,height:size.height)
    return miniFrame(old,size:size,screens:[screen])
}
func recordingMiniShouldAppear(viewMode:MiniView,sessionActive:Bool,sharesScreen:Bool)->Bool {
    sessionActive && viewMode == .hidden && !sharesScreen
}
func displayIndex(containing rect:NSRect,displays:[NSRect])->Int? {
    let center=NSPoint(x:rect.midX,y:rect.midY)
    if let hit=displays.firstIndex(where:{ $0.contains(center) }) { return hit }
    var best:Int?=nil
    var area:CGFloat=0
    for (i,d) in displays.enumerated() {
        let overlap=d.intersection(rect)
        let next=overlap.isNull ? 0:overlap.width*overlap.height
        if next>area { area=next;best=i }
    }
    return area>0 ? best:nil
}
func framesShareDisplay(_ mini:NSRect,_ main:NSRect,displays:[NSRect])->Bool {
    guard let a=displayIndex(containing:mini,displays:displays),let b=displayIndex(containing:main,displays:displays) else { return false }
    return a==b
}
func appKitRect(fromQuartzWindow bounds:[String:CGFloat],primaryHeight:CGFloat)->NSRect {
    let x=bounds["X"] ?? 0,y=bounds["Y"] ?? 0,w=bounds["Width"] ?? 0,h=bounds["Height"] ?? 0
    return NSRect(x:x,y:primaryHeight-y-h,width:w,height:h)
}
final class MeetingPanel:NSPanel {
    var onHide:(()->Void)?
    override var canBecomeKey:Bool { true };override var canBecomeMain:Bool { false }
    override func cancelOperation(_ sender:Any?) { onHide?() }
}
final class CapsuleSurface:NSView {
    var hoverChanged:((Bool)->Void)?
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        for area in trackingAreas { removeTrackingArea(area) }
        addTrackingArea(NSTrackingArea(rect:.zero,options:[.mouseEnteredAndExited,.activeAlways,.inVisibleRect],owner:self,userInfo:nil))
    }
    override func mouseEntered(with event:NSEvent) { hoverChanged?(true) }
    override func mouseExited(with event:NSEvent) { hoverChanged?(false) }
}
// One transparent row. Full text stays visible; Deep research is a blue word after the latest finding.
func miniLabelStyle(_ category:String)->(color:NSColor,mark:String) {
    if category=="发现" || category=="Finding" { return (MiniTone.finding,"find") }
    if category=="建议" || category=="Suggestion" || category=="建议行动" || category=="Suggested action" { return (MiniTone.task,"bolt") }
    if category=="待办" || category=="To-do" { return (MiniTone.task,"check") }
    return (MiniTone.muted,"")
}
func miniDrawMark(_ kind:String,_ color:NSColor,in rect:NSRect) {
    let s=min(rect.width,rect.height)/24
    func p(_ x:CGFloat,_ y:CGFloat)->NSPoint { NSPoint(x:rect.minX+x*s,y:rect.minY+y*s) }
    if kind=="find" || kind=="bolt" {
        let path=NSBezierPath()
        if kind=="find" { path.move(to:p(12,3));path.line(to:p(13.9,8.6));path.line(to:p(19.5,11));path.line(to:p(13.9,13.4));path.line(to:p(12,19));path.line(to:p(10.1,13.4));path.line(to:p(4.5,11));path.line(to:p(10.1,8.6)) }
        else { path.move(to:p(13.4,2.5));path.line(to:p(5,13.6));path.line(to:p(11,14.6));path.line(to:p(9.8,21.2));path.line(to:p(19,10.4));path.line(to:p(12.5,9.4)) }
        path.close();color.setFill();path.fill();return
    }
    color.setStroke()
    let ring=NSBezierPath(ovalIn:rect.insetBy(dx:1.2,dy:1.2));ring.lineWidth=1.4;ring.stroke()
    let tick=NSBezierPath();tick.move(to:p(8,12.3));tick.line(to:p(10.8,15.1));tick.line(to:p(16,9.6));tick.lineWidth=1.5;tick.lineCapStyle = .round;tick.lineJoinStyle = .round;tick.stroke()
}
final class FlippedCardStack:NSStackView { override var isFlipped:Bool { true } }
// The chapter stack is y-up. This overlay is flipped so the rail is measured from the top, and it does not take clicks.
final class MiniRailOverlay:NSView {
    var mark:String
    var fade=false { didSet { if fade != oldValue { needsDisplay=true } } }
    init(mark:String) { self.mark=mark;super.init(frame:.zero);translatesAutoresizingMaskIntoConstraints=false }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    override var isFlipped:Bool { true }
    override var isOpaque:Bool { false }
    override func hitTest(_ point:NSPoint)->NSView? { nil }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance();needsDisplay=true }
    override func draw(_ dirtyRect:NSRect) {
        let originY:CGFloat=mark=="node" ? 9:mark=="dot" ? 7.5:0
        let gap:NSRect?=mark=="node" ? NSRect(x:8.5,y:9,width:1.5,height:8):mark=="dot" ? NSRect(x:8.5,y:7.5,width:1.5,height:5):nil
        miniDrawRail(in:NSRect(x:8.5,y:originY,width:1.5,height:max(0,bounds.height-originY)),fade:fade,gap:gap)
        if mark=="node" { MiniTone.fg.setFill();NSBezierPath(ovalIn:NSRect(x:5,y:9,width:8,height:8)).fill() }
        else if mark=="dot" { MiniTone.faint.setFill();NSBezierPath(ovalIn:NSRect(x:6.5,y:7.5,width:5,height:5)).fill() }
    }
}
final class MiniInsightButton:NSButton {
    let category:String;let bodyText:String;var expanded=false;var sourceLabel="";var stableKey="";var readMore="展开全文";var collapse="收起"
    var time="";var rowHover=false;var railFade=false { didSet { if railFade != oldValue { needsDisplay=true } } }
    var railStartsAtMark=false { didSet { if railStartsAtMark != oldValue { needsDisplay=true } } }
    var deepButton:MiniActionButton?
    static let textWidth:CGFloat=304,lineHeight:CGFloat=22
    init(category:String,text:String,target:AnyObject?,action:Selector) {
        self.category=category;bodyText=miniDisplayText(text)
        super.init(frame:.zero);title=category+" · "+bodyText;self.target=target;self.action=action
        isBordered=false;setButtonType(.momentaryPushIn);toolTip=text
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    func attachDeep(_ button:MiniActionButton) {
        deepButton?.removeFromSuperview();deepButton=button;button.translatesAutoresizingMaskIntoConstraints=true;addSubview(button);layoutDeep()
    }
    func bodyAttributed()->NSAttributedString {
        let paragraph=NSMutableParagraphStyle();paragraph.lineBreakMode = .byWordWrapping;paragraph.minimumLineHeight=Self.lineHeight;paragraph.maximumLineHeight=Self.lineHeight
        let lead=miniSentenceSplit(bodyText)
        let out=NSMutableAttributedString()
        func add(_ text:String,_ weight:NSFont.Weight) {
            guard !text.isEmpty else { return }
            out.append(NSAttributedString(string:text,attributes:[.font:NSFont.systemFont(ofSize:14.5,weight:weight),.foregroundColor:MiniTone.fg,.paragraphStyle:paragraph]))
        }
        let isTitle = !miniLabelStyle(category).mark.isEmpty
        add(lead.0,isTitle ? .semibold:.regular);add(lead.1,.regular)
        return out
    }
    // Measure the final line with the same TextKit layout used for the body. The link
    // follows the sentence, wrapping only when the remaining line cannot hold it.
    var deepFrame:NSRect {
        guard let d=deepButton else { return .zero }
        let storage=NSTextStorage(attributedString:bodyAttributed()),layout=NSLayoutManager()
        let container=NSTextContainer(containerSize:NSSize(width:Self.textWidth,height:6000))
        container.lineFragmentPadding=0;layout.addTextContainer(container);storage.addLayoutManager(layout)
        layout.ensureLayout(for:container)
        let width=min(Self.textWidth,max(18,d.intrinsicContentSize.width))
        guard layout.numberOfGlyphs>0 else { return NSRect(x:28,y:20,width:width,height:18) }
        let last=layout.numberOfGlyphs-1
        let line=layout.lineFragmentUsedRect(forGlyphAt:last,effectiveRange:nil)
        let x=line.maxX+6
        if x+width<=Self.textWidth { return NSRect(x:28+x,y:20+line.minY+2,width:width,height:18) }
        return NSRect(x:28,y:20+textHeight+2,width:width,height:18)
    }
    func layoutDeep() { deepButton?.frame=deepFrame }
    override func layout() { super.layout();layoutDeep() }
    var textHeight:CGFloat {
        let rect=bodyAttributed().boundingRect(with:NSSize(width:Self.textWidth,height:6000),options:[.usesLineFragmentOrigin,.usesFontLeading])
        return max(Self.lineHeight,ceil(rect.height))
    }
    override var isFlipped:Bool { true }
    override var intrinsicContentSize:NSSize { NSSize(width:332,height:max(20+textHeight,deepFrame.maxY)+14) }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance();needsDisplay=true }
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        for area in trackingAreas { removeTrackingArea(area) }
        addTrackingArea(NSTrackingArea(rect:.zero,options:[.mouseEnteredAndExited,.activeAlways,.inVisibleRect],owner:self,userInfo:nil))
    }
    override func mouseEntered(with event:NSEvent) { super.mouseEntered(with:event);rowHover=true;needsDisplay=true }
    override func mouseExited(with event:NSEvent) { super.mouseExited(with:event);rowHover=false;needsDisplay=true }
    override func draw(_ dirtyRect:NSRect) {
        let style=miniLabelStyle(category),clock=rowHover ? time:""
        let markTop:CGFloat=style.mark.isEmpty ? 0:2.5
        let originY=railStartsAtMark ? markTop:CGFloat(0)
        let gap:NSRect?=style.mark.isEmpty ? nil:NSRect(x:8.5,y:2.5,width:1.5,height:15)
        miniDrawRail(in:NSRect(x:8.5,y:originY,width:1.5,height:max(0,bounds.height-originY)),fade:railFade,gap:gap)
        if style.mark.isEmpty { miniCaption(category,time:clock).draw(at:NSPoint(x:28,y:0)) }
        else { miniDrawMark(style.mark,style.color,in:NSRect(x:1.5,y:2.5,width:15,height:15));miniCaption(category,time:clock,color:style.color,weight:.semibold).draw(at:NSPoint(x:28,y:0)) }
        bodyAttributed().draw(with:NSRect(x:28,y:20,width:Self.textWidth,height:textHeight),options:[.usesLineFragmentOrigin])
    }
}
// MENUBAR (Aaron 2026-10-24, checked against Granola): icon only, items that do not apply are hidden
// rather than greyed, one Show/Hide toggle. English is the source string; Chinese is its translation.
// Pure so --self-test can check every state without putting anything on screen.
enum AppName { static let en="Citeside";static let zh="Citeside" }
struct MenuEntry:Equatable { let key:String;let title:String;let hidden:Bool;let enabled:Bool }
func menuBarEntries(english:Bool,active:Bool,paused:Bool,busy:Bool,miniVisible:Bool,elapsed:Int)->[MenuEntry] {
    func tr(en:String,zh:String)->String { english ? en:zh }
    let name=english ? AppName.en:AppName.zh,seconds=max(0,elapsed)
    let clock=seconds>=3600 ? String(format:"%d:%02d:%02d",seconds/3600,seconds/60%60,seconds%60):String(format:"%02d:%02d",seconds/60,seconds%60)
    return [
        MenuEntry(key:"status",title:(paused ? tr(en:"Paused",zh:"已暂停"):tr(en:"Listening",zh:"听会中"))+" "+clock,hidden:!active,enabled:false),
        MenuEntry(key:"start",title:tr(en:"Start Listening",zh:"开始听会"),hidden:active || busy,enabled:true),
        MenuEntry(key:"mini",title:miniVisible ? tr(en:"Hide Mini Window",zh:"隐藏小窗"):tr(en:"Show Mini Window",zh:"显示小窗"),hidden:!active,enabled:true),
        MenuEntry(key:"pause",title:paused ? tr(en:"Resume Listening",zh:"继续听会"):tr(en:"Pause Listening",zh:"暂停听会"),hidden:!active,enabled:!busy),
        MenuEntry(key:"end",title:tr(en:"End Meeting",zh:"结束会议"),hidden:!active,enabled:!busy),
        MenuEntry(key:"sep-meeting",title:"",hidden:!active,enabled:false),
        MenuEntry(key:"open",title:tr(en:"Open \(name)",zh:"打开\(name)"),hidden:false,enabled:true),
        MenuEntry(key:"sep-quit",title:"",hidden:false,enabled:false),
        MenuEntry(key:"quit",title:tr(en:"Quit \(name)",zh:"退出\(name)"),hidden:false,enabled:true),
    ]
}
// The menu bar shows only the icon; the words go into its hover tip (PRD 2h).
func menuBarToolTip(english:Bool,active:Bool,paused:Bool,detail:String)->String {
    func tr(en:String,zh:String)->String { english ? en:zh }
    var parts=[english ? AppName.en:AppName.zh]
    if !detail.isEmpty { parts.append(detail) } else { parts.append(!active ? tr(en:"Not listening",zh:"没在听会"):paused ? tr(en:"Paused",zh:"已暂停"):tr(en:"Listening",zh:"听会中")) }
    if active { parts.append(tr(en:"Hiding the mini window keeps listening",zh:"隐藏小窗不会停止听会")) }
    return parts.joined(separator:" · ")
}
// The design's microphone (24pt SVG scaled to 18pt) as a template image, so macOS supplies the light/dark tint.
// While a meeting runs a mark sits at the top right: a red dot when listening, pause bars when paused.
func menuBarImage(badge:String)->NSImage {
    let image=NSImage(size:NSSize(width:18,height:18),flipped:true){_ in
        let ink=NSColor.black
        ink.setStroke()
        let k:CGFloat=0.75
        func p(_ x:CGFloat,_ y:CGFloat)->NSPoint { NSPoint(x:x*k,y:y*k) }
        let body=NSBezierPath(roundedRect:NSRect(x:9*k,y:3*k,width:6*k,height:12*k),xRadius:3*k,yRadius:3*k)
        let arc=NSBezierPath();arc.appendArc(withCenter:p(12,11),radius:7*k,startAngle:0,endAngle:180,clockwise:false)
        arc.move(to:p(12,18));arc.line(to:p(12,21))
        for path in [body,arc] { path.lineWidth=1.5;path.lineCapStyle = .round;path.lineJoinStyle = .round;path.stroke() }
        if badge=="listening" || badge=="paused" {
            let ring=NSRect(x:12.5,y:0.5,width:5,height:5)
            NSGraphicsContext.current?.compositingOperation = .clear;NSBezierPath(ovalIn:ring.insetBy(dx:-1.2,dy:-1.2)).fill()
            NSGraphicsContext.current?.compositingOperation = .sourceOver

        }
        return true
    }
    // Keep the microphone template in every state. A separate view supplies the coloured dot.
    image.isTemplate = true;return image
}


// Separate from the template image so macOS can tint the microphone for any menu-bar appearance.
final class MenuRecordingBadge:NSView {
    var state="" { didSet { isHidden=state.isEmpty;needsDisplay=true } }
    override func hitTest(_ point:NSPoint)->NSView? { nil }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance();needsDisplay=true }
    override func draw(_ dirtyRect:NSRect) {
        let dot=NSBezierPath(ovalIn:bounds.insetBy(dx:0.5,dy:0.5))
        if state=="listening" { MiniTone.recording.setFill();dot.fill() }
        else if state=="paused" { NSColor.secondaryLabelColor.setStroke();dot.lineWidth=1;dot.stroke() }
    }
}

final class PendingAudioSpool {
    struct Stored { let seq: Int; let pcm: Data; let capturedAtMs: Int }
    let root: URL
    let serviceName: String
    private let injected: SymmetricKey?
    private var key: SymmetricKey?
    private var opened = false
    private let account = "audio-spool"
    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? URL(fileURLWithPath: NSTemporaryDirectory())
        root = base.appendingPathComponent("Citeside/pending-spool", isDirectory: true)
        serviceName = "CitesidePendingSpool"
        injected = nil
    }
    init(root: URL, key: SymmetricKey) {
        self.root = root
        serviceName = "CitesidePendingSpoolTest"
        injected = key
        self.key = key
        opened = true
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    }
    init(root: URL, service: String) {
        self.root = root
        serviceName = service
        injected = nil
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    }
    func ensure() -> SymmetricKey? {
        Self.keychainLock.lock()
        defer { Self.keychainLock.unlock() }
        if opened { return key }
        opened = true
        if let injected { key = injected; return key }
        guard let interaction = Self.suspendKeychainInteraction() else { return nil }
        defer { SecKeychainSetUserInteractionAllowed(interaction.boolValue) }
        switch readKey() {
        case .value(let found):
            key = found
            return key
        case .missing:
            break
        case .unavailable:
            return nil
        }
        let fresh = SymmetricKey(size: .bits256)
        let data = fresh.withUnsafeBytes { Data($0) }
        var add = query(returnData: false)
        add[kSecValueData as String] = data
        guard SecItemAdd(add as CFDictionary, nil) == errSecSuccess else { return nil }
        guard case .value(let back) = readKey(), back.withUnsafeBytes({ Data($0) }) == data else { return nil }
        key = back
        return key
    }
    func protect(session: String, seq: Int, capturedAtMs: Int, pcm: Data) {
        guard seq > 0, capturedAtMs > 0, !pcm.isEmpty, !session.isEmpty, let key = ensure() else { return }
        let url = folder(session).appendingPathComponent("s-\(seq)-\(capturedAtMs).bin")
        if FileManager.default.fileExists(atPath: url.path) { return }
        guard let sealed = seal(pcm, key: key, aad: aad(session, seq, capturedAtMs, "s")) else { return }
        _ = publish(sealed, to: url)
    }
    func protectOverflow(session: String, capturedAtMs: Int, pcm: Data) {
        guard capturedAtMs > 0, !pcm.isEmpty, !session.isEmpty, let key = ensure() else { return }
        let name = "o-\(capturedAtMs)-\(UUID().uuidString.prefix(8)).bin"
        guard let sealed = seal(pcm, key: key, aad: aad(session, 0, capturedAtMs, "o")) else { return }
        _ = publish(sealed, to: folder(session).appendingPathComponent(name))
    }
    func remove(session: String, seq: Int) {
        guard seq > 0 else { return }
        for url in files(session, prefix: "s-") where parseSeq(url.lastPathComponent) == seq {
            try? FileManager.default.removeItem(at: url)
        }
    }
    func sweep(nowMs: Int) {
        let limit = 24 * 60 * 60 * 1000
        guard let folders = try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil) else { return }
        for folder in folders {
            guard let names = try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil) else { continue }
            for url in names {
                guard let at = parseCapturedAt(url.lastPathComponent), nowMs >= at, nowMs - at >= limit else { continue }
                try? FileManager.default.removeItem(at: url)
            }
        }
    }
    func unacked(session: String) -> [Stored] {
        guard let key = ensure() else { return [] }
        var out: [Stored] = []
        for url in files(session, prefix: "s-") {
            guard let seq = parseSeq(url.lastPathComponent), let at = parseCapturedAt(url.lastPathComponent) else { continue }
            guard let raw = try? Data(contentsOf: url), let pcm = openBox(raw, key: key, aad: aad(session, seq, at, "s")) else { continue }
            out.append(Stored(seq: seq, pcm: pcm, capturedAtMs: at))
        }
        return out.sorted { $0.seq < $1.seq }
    }
    func adoptOverflow(session: String, seq: Int) -> Stored? {
        guard seq > 0, let key = ensure() else { return nil }
        guard let url = files(session, prefix: "o-").sorted(by: { $0.lastPathComponent < $1.lastPathComponent }).first else { return nil }
        guard let at = parseCapturedAt(url.lastPathComponent), let raw = try? Data(contentsOf: url), let pcm = openBox(raw, key: key, aad: aad(session, 0, at, "o")) else { return nil }
        if unacked(session: session).contains(where: { $0.capturedAtMs == at && $0.pcm == pcm }) {
            try? FileManager.default.removeItem(at: url)
            return nil
        }
        protect(session: session, seq: seq, capturedAtMs: at, pcm: pcm)
        guard unacked(session: session).contains(where: { $0.seq == seq && $0.pcm == pcm }) else { return nil }
        try? FileManager.default.removeItem(at: url)
        return Stored(seq: seq, pcm: pcm, capturedAtMs: at)
    }
    func deleteKeychainItem() {
        Self.keychainLock.lock()
        defer { Self.keychainLock.unlock() }
        guard let interaction = Self.suspendKeychainInteraction() else { return }
        defer { SecKeychainSetUserInteractionAllowed(interaction.boolValue) }
        SecItemDelete(query(returnData: false) as CFDictionary)
    }
    func keychainPresent() -> Bool {
        if case .value = readKey() { return true }
        return false
    }
    private enum KeyRead { case value(SymmetricKey); case missing; case unavailable }
    // File-based macOS keychains can ignore kSecUseAuthenticationUIFail.
    // Serialize and scope the legacy switch; never prompt during capture or
    // leave interaction disabled for other users of Security.framework.
    private static let keychainLock = NSRecursiveLock()
    private static func suspendKeychainInteraction() -> DarwinBoolean? {
        var previous: DarwinBoolean = false
        guard SecKeychainGetUserInteractionAllowed(&previous) == errSecSuccess,
              SecKeychainSetUserInteractionAllowed(false) == errSecSuccess else { return nil }
        return previous
    }
    private func query(returnData: Bool) -> [String: Any] {
        var q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: serviceName,
            kSecAttrAccount as String: account,
            kSecUseAuthenticationUI as String: kSecUseAuthenticationUIFail,
        ]
        if returnData {
            q[kSecReturnData as String] = true
            q[kSecMatchLimit as String] = kSecMatchLimitOne
        }
        return q
    }
    private func readKey() -> KeyRead {
        Self.keychainLock.lock()
        defer { Self.keychainLock.unlock() }
        guard let interaction = Self.suspendKeychainInteraction() else { return .unavailable }
        defer { SecKeychainSetUserInteractionAllowed(interaction.boolValue) }
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query(returnData: true) as CFDictionary, &item)
        if status == errSecSuccess, let data = item as? Data, data.count == 32 { return .value(SymmetricKey(data: data)) }
        if status == errSecItemNotFound { return .missing }
        return .unavailable
    }
    private func folder(_ session: String) -> URL {
        let digest = SHA256.hash(data: Data(session.utf8))
        let hex = digest.map { String(format: "%02x", $0) }.joined()
        return root.appendingPathComponent(String(hex.prefix(32)), isDirectory: true)
    }
    private func files(_ session: String, prefix: String) -> [URL] {
        let dir = folder(session)
        guard let names = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) else { return [] }
        return names.filter { $0.lastPathComponent.hasPrefix(prefix) && $0.lastPathComponent.hasSuffix(".bin") }
    }
    private func parseSeq(_ name: String) -> Int? {
        let parts = name.split(separator: "-")
        guard parts.count == 3, parts[0] == "s", let seq = Int(parts[1]), seq > 0 else { return nil }
        return seq
    }
    private func parseCapturedAt(_ name: String) -> Int? {
        let parts = name.split(separator: "-")
        if parts.count == 3, parts[0] == "s", let at = Int(parts[2].replacingOccurrences(of: ".bin", with: "")), at > 0 { return at }
        if parts.count == 3, parts[0] == "o", let at = Int(parts[1]), at > 0 { return at }
        return nil
    }
    private func aad(_ session: String, _ seq: Int, _ capturedAtMs: Int, _ kind: String) -> Data {
        Data("\(kind)\n\(session)\n\(seq)\n\(capturedAtMs)".utf8)
    }
    private func seal(_ pcm: Data, key: SymmetricKey, aad: Data) -> Data? {
        guard let nonce = try? AES.GCM.Nonce(), let box = try? AES.GCM.seal(pcm, using: key, nonce: nonce, authenticating: aad), let combined = box.combined else { return nil }
        return combined
    }
    private func openBox(_ data: Data, key: SymmetricKey, aad: Data) -> Data? {
        guard let box = try? AES.GCM.SealedBox(combined: data) else { return nil }
        return try? AES.GCM.open(box, using: key, authenticating: aad)
    }
    private func publish(_ data: Data, to url: URL) -> Bool {
        let folder = url.deletingLastPathComponent()
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: url.path) { return true }
            let tmp = folder.appendingPathComponent(".tmp-" + UUID().uuidString)
            guard FileManager.default.createFile(atPath: tmp.path, contents: data, attributes: [.posixPermissions: 0o600]) else { return false }
            let fh = try FileHandle(forWritingTo: tmp)
            do { try fh.synchronize(); try fh.close() } catch { try? FileManager.default.removeItem(at: tmp); return false }
            if FileManager.default.fileExists(atPath: url.path) { try? FileManager.default.removeItem(at: tmp); return true }
            try FileManager.default.moveItem(at: tmp, to: url)
            return true
        } catch {
            return false
        }
    }
}

final class AppDelegate:NSObject,NSApplicationDelegate,NSWindowDelegate,NSMenuDelegate {
    var api:LocalAPI;let locale:String;var english:Bool;let autoStart:Bool
    var panel:MeetingPanel!;var status:NSTextField!;var cards=FlippedCardStack();var startButton:NSButton!;var pauseButton:NSButton!;var endButton:NSButton!
    var terminateAfterSave=false;var quitInFlight=false;var quitApproved=false
    var captureRecovery="ready";var reconnectButton:NSButton!
    var recoveryPermission:CapturePermission?;var permissionSettingsButton:NSButton!
    var lastPermissionReport=Date.distantPast
    var screenPermissionReport=ScreenPermissionReport()
    var mirroring=false;var meter=AudioMeter();var compactMeter=AudioMeter();var capsuleMeter=AudioMeter();var sessionId="";var lastSessionId="";var transportIssue=false;var transportMessage="";var captureRetryGate=CaptureRetryGate();var lastMicrophoneRequest="";var lastMicrophoneError="";var heartbeating=false;var engine:CaptureEngine?;var busy=false;var paused=false;var error="";var tick:Timer?
    var captureGeneration=0
    var audioQueue:[(Int,Data,Double)]=[];var nextAudioSequence=1;var cloudASR=false;var textQueue:[(String,String)]=[];var pendingFrame:Data?;var sending=false;var lastCards="";var lastHeartbeat=Date()
    var pendingAudio=false;let audioSpool=PendingAudioSpool();var pendingCapturedAt=[Int:Int]()
    var mainOpenPending=false;var mainWindowPID:pid_t=0;var latestPanelStatus:[String:Any]=[:];var localMainVisibleOverride:Bool?
    var lastPanelPolicyKey="",dismissedPanelSession=""
    var panelPolicySuppressed=false;var awaitingInitialPanelPolicy=false;var policyResumeView=recordingMiniView()
    var mainRestoreEpoch="",mainRestoreSerial=0,retiredMainRestoreEpochs=Set<String>()
    var viewMode=MiniView.hidden;var expandedRoot:NSStackView!;var compactRoot:NSStackView!;var compactButton:NSButton!;var compactPause:NSButton!;var compactEnd:NSButton!;var compactStart:NSButton!;var mirrorSeconds:Double=0;var statusItem:NSStatusItem!;var menuItems=[String:NSMenuItem]();var menuBadge="";let menuRecordingBadge=MenuRecordingBadge();var expandedHeight:CGFloat=170;var cardCount=0
    var miniUnread=MiniUnreadState();var unreadMainRequestSession="";var capsuleUnread=NSView()
    var capsuleRoot=NSStackView();var capsuleDot=RecDot();var capsuleTimer=NSTextField(labelWithString:"00:00");var capsulePause:NSButton!;var capsuleEnd:NSButton!
    var preferredMiniView=recordingMiniView();var recoveryResumeView:MiniView?
    var transcriptRoot:NSStackView!;var transcriptEntry:NSButton!
    var hoverPanel:MeetingPanel?;var hoverText:NSTextView?;var hoverDismiss:DispatchWorkItem?
    var hovering=false;var recentTranscript="";var transcriptPreview:NSTextView!;var transcriptScroll=NSScrollView();var notNowButton:NSButton!
    var watchScanAt=Date.distantPast;var notifiedWindows=[UInt32:Date]();var watchEnabled=true
    var recDot=RecDot();var timerLabel=NSTextField(labelWithString:"00:00:00");var hideButton:NSButton!;var openButton:NSButton!
    var chapterBlock=NSStackView();var chapterCaption=NSTextField(labelWithString:"");var chapterLabel=NSTextField(wrappingLabelWithString:"")
    var gistBlock=NSStackView();var gistCaption=NSTextField(labelWithString:"");var gistLabel=NSTextField(wrappingLabelWithString:"")
    var chapterRail=MiniRailOverlay(mark:"node");var gistRail=MiniRailOverlay(mark:"dot")
    var bodyStack=NSStackView();var footerBlock=NSStackView();var footerText=NSTextField(labelWithString:"");var statusNotice=false
    var deepSession="";var deepJobs:[String:String]=[:]   // card key → "" / accepted / running:n / done / failed
    // F-01: the launch identity the server minted for this start; echoed on launch-ack / start / cancel-start so a late start from an older launch cannot consume a newer one.
    var pendingLaunchId=""
    func launchBody(_ id:String,_ body:[String:Any]=[:])->[String:Any] { var b=body;if !id.isEmpty { b["launchId"]=id };return b }
    func startLaunch(_ id:String) { pendingLaunchId=id;startClicked();pendingLaunchId="" }
    var expandedCards=Set<String>();var expandSignals=Set<String>();var historySession="";var presentedRoot:NSStackView?;var presentationConstraints:[NSLayoutConstraint]=[];var cardScroll=NSScrollView();var cardViewport:NSLayoutConstraint!;var joinTarget:UInt32?
    init(server:String,locale:String,english:Bool,autoStart:Bool,owner:String="") { api=LocalAPI(server,owner:owner);self.locale=locale;self.english=english;self.autoStart=autoStart }
    // English is the source string; Chinese is its translation. Each string lives in one call.
    func tr(en:String,zh:String)->String { english ? en : zh }
    func applicationDidFinishLaunching(_ notification:Notification) {
        DistributedNotificationCenter.default().addObserver(self,selector:#selector(claimOwner(_:)),name:Notification.Name("LiveMateCaptureOwner"),object:String(api.base.port!))
        if !api.owner.isEmpty { Task { @MainActor in
            do { _ = try await api.request("owner-helper-ready",["pid":Int(ProcessInfo.processInfo.processIdentifier)]) }
            catch { showError(tr(en:"Main window not confirmed. Reopen the mini window from Citeside.",zh:"主窗口归属未确认，请从主窗口重新打开小窗")) }
        } }
        NSApp.setActivationPolicy(.accessory)
        panel=MeetingPanel(contentRect:NSRect(x:0,y:0,width:360,height:170),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
        panel.title=tr(en:"Citeside · Mini",zh:"Citeside · 小窗");panel.level = .floating;panel.isFloatingPanel=true;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false
        panel.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary];panel.standardWindowButton(.zoomButton)?.isHidden=true;panel.standardWindowButton(.miniaturizeButton)?.isHidden=true
        panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=true
        // .mini: frosted glass (behind-window blur + the design's glass tint), radius 18, hairline, shadow.
        let surface=CapsuleSurface();surface.wantsLayer=true;surface.layer?.cornerRadius=18;surface.layer?.masksToBounds=true
        surface.hoverChanged={ [weak self] inside in self?.setTranscriptHover(inside) }
        panel.contentView=surface
        let blur=NSVisualEffectView();blur.material = .popover;blur.blendingMode = .behindWindow;blur.state = .active;blur.translatesAutoresizingMaskIntoConstraints=false
        let mask=NSImage(size:NSSize(width:37,height:37),flipped:false) { rect in NSColor.black.setFill();NSBezierPath(roundedRect:rect,xRadius:18,yRadius:18).fill();return true }
        mask.capInsets=NSEdgeInsets(top:18,left:18,bottom:18,right:18);mask.resizingMode = .stretch;blur.maskImage=mask
        let glass=ToneBox(fill:MiniTone.glass,stroke:MiniTone.glassLine,radius:18)
        for layerView in [blur,glass] as [NSView] {
            surface.addSubview(layerView)
            NSLayoutConstraint.activate([layerView.leadingAnchor.constraint(equalTo:surface.leadingAnchor),layerView.trailingAnchor.constraint(equalTo:surface.trailingAnchor),layerView.topAnchor.constraint(equalTo:surface.topAnchor),layerView.bottomAnchor.constraint(equalTo:surface.bottomAnchor)])
        }
        panel.delegate=self;panel.isMovableByWindowBackground=true;panel.onHide={ [weak self] in self?.hidePanel() }
        let root=NSStackView();root.orientation = .vertical;root.alignment = .leading;root.spacing=0;root.translatesAutoresizingMaskIntoConstraints=false
        expandedRoot=root
        func divider()->NSView { let d=ToneBox(fill:MiniTone.glassLine);d.widthAnchor.constraint(equalToConstant:360).isActive=true;d.heightAnchor.constraint(equalToConstant:1).isActive=true;return d }
        // .mini-h: timer pill · pause/resume · back to main window · hide (hiding keeps listening).
        let heading=NSStackView();heading.orientation = .horizontal;heading.alignment = .centerY;heading.spacing=8;heading.edgeInsets=NSEdgeInsets(top:10,left:14,bottom:10,right:10);heading.translatesAutoresizingMaskIntoConstraints=false
        root.addArrangedSubview(heading);heading.widthAnchor.constraint(equalToConstant:360).isActive=true
        let pill=ToneBox(fill:MiniTone.panel,stroke:MiniTone.line,radius:15);pill.heightAnchor.constraint(equalToConstant:30).isActive=true
        let pillRow=NSStackView(views:[recDot,timerLabel]);pillRow.orientation = .horizontal;pillRow.alignment = .centerY;pillRow.spacing=8;pillRow.edgeInsets=NSEdgeInsets(top:0,left:10,bottom:0,right:12);pillRow.translatesAutoresizingMaskIntoConstraints=false;pill.addSubview(pillRow)
        NSLayoutConstraint.activate([pillRow.leadingAnchor.constraint(equalTo:pill.leadingAnchor),pillRow.trailingAnchor.constraint(equalTo:pill.trailingAnchor),pillRow.topAnchor.constraint(equalTo:pill.topAnchor),pillRow.bottomAnchor.constraint(equalTo:pill.bottomAnchor)])
        timerLabel.font=NSFont.monospacedDigitSystemFont(ofSize:13,weight:.medium);timerLabel.textColor=MiniTone.fg
        pill.setContentHuggingPriority(.required,for:.horizontal);heading.addArrangedSubview(pill)
        let spacer=NSView();spacer.translatesAutoresizingMaskIntoConstraints=false;spacer.setContentHuggingPriority(.init(1),for:.horizontal);spacer.setContentCompressionResistancePriority(.init(1),for:.horizontal);heading.addArrangedSubview(spacer)
        startButton=MiniActionButton(title:tr(en:"Start",zh:"开始"),primary:true,target:self,action:#selector(startClicked));heading.addArrangedSubview(startButton)
        pauseButton=miniIconButton("pause.fill",tr(en:"Pause",zh:"暂停"),target:self,action:#selector(pauseClicked));pauseButton.isHidden=true;heading.addArrangedSubview(pauseButton)
        openButton=miniIconButton("arrow.up.left.and.arrow.down.right",tr(en:"Back to main window",zh:"展开回主窗口"),target:self,action:#selector(openMain));heading.addArrangedSubview(openButton)
        heading.addArrangedSubview(miniIconButton("minus",tr(en:"Collapse to capsule",zh:"收起为胶囊"),target:self,action:#selector(collapseToCapsule)))
        hideButton=miniIconButton("xmark",tr(en:"Hide mini window; keep listening",zh:"隐藏小窗，听会继续"),target:self,action:#selector(hidePanel));heading.addArrangedSubview(hideButton)
        // End lives in the menu bar (design: the mini window has no End control).
        endButton=NSButton(title:tr(en:"End",zh:"结束"),target:self,action:#selector(endClicked));endButton.isHidden=true
        root.addArrangedSubview(divider())
        // .mini-b: chapter, what is happening, notices, outside-information cards.
        bodyStack.orientation = .vertical;bodyStack.alignment = .leading;bodyStack.spacing=12;bodyStack.edgeInsets=NSEdgeInsets(top:12,left:14,bottom:12,right:14);bodyStack.translatesAutoresizingMaskIntoConstraints=false
        root.addArrangedSubview(bodyStack);bodyStack.widthAnchor.constraint(equalToConstant:360).isActive=true
        for (block,caption,label,font,lines) in [(chapterBlock,chapterCaption,chapterLabel,NSFont.systemFont(ofSize:14.5,weight:.semibold),2),(gistBlock,gistCaption,gistLabel,NSFont.systemFont(ofSize:14.5,weight:.regular),8)] {
            block.orientation = .vertical;block.alignment = .leading;block.spacing=2;block.isHidden=true
            caption.isHidden=true;caption.translatesAutoresizingMaskIntoConstraints=false;caption.heightAnchor.constraint(equalToConstant:20).isActive=true
            label.font=font;label.textColor=MiniTone.fg;label.preferredMaxLayoutWidth=304;label.maximumNumberOfLines=lines;label.lineBreakMode = .byWordWrapping;label.cell?.truncatesLastVisibleLine=lines>0
            label.translatesAutoresizingMaskIntoConstraints=false;label.widthAnchor.constraint(equalToConstant:304).isActive=true
            block.addArrangedSubview(caption);block.addArrangedSubview(label);bodyStack.addArrangedSubview(block)
            block.widthAnchor.constraint(equalToConstant:332).isActive=true
        }
        chapterLabel.maximumNumberOfLines=0
        chapterLabel.cell?.truncatesLastVisibleLine=false
        chapterBlock.edgeInsets=NSEdgeInsets(top:2,left:28,bottom:16,right:0)
        gistBlock.edgeInsets=NSEdgeInsets(top:0,left:28,bottom:20,right:0)
        bodyStack.setCustomSpacing(0,after:chapterBlock);bodyStack.setCustomSpacing(0,after:gistBlock)
        func pinRail(_ rail:MiniRailOverlay,_ block:NSStackView) {
            block.addSubview(rail)
            NSLayoutConstraint.activate([rail.leadingAnchor.constraint(equalTo:block.leadingAnchor),rail.trailingAnchor.constraint(equalTo:block.trailingAnchor),rail.topAnchor.constraint(equalTo:block.topAnchor),rail.bottomAnchor.constraint(equalTo:block.bottomAnchor)])
        }
        pinRail(chapterRail,chapterBlock);pinRail(gistRail,gistBlock)
        status=NSTextField(wrappingLabelWithString:tr(en:"Return to your meeting and press Start",zh:"切回会议窗口，点开始"));status.font = .systemFont(ofSize:12.5);status.maximumNumberOfLines=2;status.lineBreakMode = .byTruncatingTail;status.textColor=MiniTone.muted;status.preferredMaxLayoutWidth=332
        status.translatesAutoresizingMaskIntoConstraints=false;status.widthAnchor.constraint(equalToConstant:332).isActive=true;bodyStack.addArrangedSubview(status)
        permissionSettingsButton=MiniActionButton(title:tr(en:"Open Permission Settings",zh:"打开权限设置"),target:self,action:#selector(openPermissionSettings));permissionSettingsButton.isHidden=true;bodyStack.addArrangedSubview(permissionSettingsButton)
        reconnectButton=MiniActionButton(title:tr(en:"Reconnect",zh:"重新连接"),target:self,action:#selector(reconnectCapture));reconnectButton.isHidden=true;bodyStack.addArrangedSubview(reconnectButton)
        cards.orientation = .vertical;cards.alignment = .leading;cards.spacing=0
        cardScroll.documentView=cards;cardScroll.hasVerticalScroller=true;cardScroll.autohidesScrollers=true;cardScroll.drawsBackground=false;cardScroll.borderType = .noBorder;cardScroll.translatesAutoresizingMaskIntoConstraints=false;bodyStack.addArrangedSubview(cardScroll)
        cardScroll.widthAnchor.constraint(equalToConstant:332).isActive=true;cardViewport=cardScroll.heightAnchor.constraint(equalToConstant:0);cardViewport.isActive=true;cardScroll.isHidden=true
        // .mini-f: level meter + the latest transcript line, one line with an ellipsis.
        footerBlock.orientation = .vertical;footerBlock.alignment = .leading;footerBlock.spacing=0;footerBlock.addArrangedSubview(divider())
        let footer=NSStackView();footer.orientation = .horizontal;footer.alignment = .centerY;footer.spacing=8;footer.edgeInsets=NSEdgeInsets(top:9,left:22.5,bottom:9,right:14);footer.translatesAutoresizingMaskIntoConstraints=false;footer.widthAnchor.constraint(equalToConstant:360).isActive=true
        meter.mini=true;meter.translatesAutoresizingMaskIntoConstraints=false;meter.setContentHuggingPriority(.required,for:.horizontal);footer.addArrangedSubview(meter)
        footerText.font = .systemFont(ofSize:12.5);footerText.textColor=MiniTone.muted;footerText.lineBreakMode = .byTruncatingTail;footerText.maximumNumberOfLines=1;footerText.cell?.truncatesLastVisibleLine=true
        footerText.setContentCompressionResistancePriority(.init(1),for:.horizontal);footer.addArrangedSubview(footerText)
        footerBlock.addArrangedSubview(footer);footerBlock.isHidden=true;root.addArrangedSubview(footerBlock)
        // One narrow, draggable capsule. Disclosure never starts/stops capture.
        compactRoot=NSStackView();compactRoot.orientation = .horizontal;compactRoot.alignment = .centerY;compactRoot.spacing=2;compactRoot.edgeInsets=NSEdgeInsets(top:8,left:8,bottom:8,right:8);compactRoot.translatesAutoresizingMaskIntoConstraints=false
        func icon(_ name:String,_ label:String,_ action:Selector)->NSButton {
            let b=NSButton(title:"",target:self,action:action);b.isBordered=false;b.setButtonType(.momentaryPushIn)
            b.image=NSImage(systemSymbolName:name,accessibilityDescription:label);b.imagePosition = .imageOnly
            b.toolTip=label;b.setAccessibilityLabel(label)
            b.widthAnchor.constraint(equalToConstant:44).isActive=true;b.heightAnchor.constraint(equalToConstant:36).isActive=true
            return b
        }
        compactButton=NSButton(title:"00:00",target:self,action:#selector(openMain));compactButton.isBordered=false;compactButton.font = .monospacedDigitSystemFont(ofSize:10,weight:.medium);compactButton.widthAnchor.constraint(equalToConstant:44).isActive=true;compactButton.heightAnchor.constraint(equalToConstant:24).isActive=true;compactButton.setAccessibilityLabel(tr(en:"Open Citeside",zh:"打开Citeside"));compactRoot.addArrangedSubview(compactButton)
        compactMeter.mini=true;compactMeter.translatesAutoresizingMaskIntoConstraints=false;compactRoot.addArrangedSubview(compactMeter)
        compactMeter.widthAnchor.constraint(equalToConstant:28).isActive=true
        compactPause=icon("pause",tr(en:"Pause listening",zh:"暂停听会"),#selector(pauseClicked));compactRoot.addArrangedSubview(compactPause)
        compactStart=icon("record.circle",tr(en:"Start listening",zh:"开始听会"),#selector(startClicked));compactRoot.addArrangedSubview(compactStart)
        transcriptEntry=icon("captions.bubble",tr(en:"Transcript · CC",zh:"逐字稿 · CC"),#selector(toggleTranscript));compactRoot.addArrangedSubview(transcriptEntry)
        compactRoot.addArrangedSubview(icon("macwindow",tr(en:"Open main window",zh:"打开主窗口"),#selector(openMain)))
        compactEnd=icon("stop",tr(en:"End and save",zh:"结束并保存"),#selector(endClicked));compactRoot.addArrangedSubview(compactEnd)
        notNowButton=icon("xmark",tr(en:"Not now",zh:"暂不开始"),#selector(dismissDetection));notNowButton.isHidden=true;compactRoot.addArrangedSubview(notNowButton)
        capsuleRoot.orientation = .horizontal;capsuleRoot.alignment = .centerY;capsuleRoot.spacing=4;capsuleRoot.edgeInsets=NSEdgeInsets(top:4,left:12,bottom:4,right:8);capsuleRoot.translatesAutoresizingMaskIntoConstraints=false
        capsuleDot.translatesAutoresizingMaskIntoConstraints=false;capsuleDot.widthAnchor.constraint(equalToConstant:8).isActive=true;capsuleDot.heightAnchor.constraint(equalToConstant:8).isActive=true;capsuleRoot.addArrangedSubview(capsuleDot)
        capsuleUnread.translatesAutoresizingMaskIntoConstraints=false;capsuleUnread.wantsLayer=true;capsuleUnread.layer?.backgroundColor=NSColor.systemBlue.cgColor;capsuleUnread.layer?.cornerRadius=3;capsuleUnread.widthAnchor.constraint(equalToConstant:6).isActive=true;capsuleUnread.heightAnchor.constraint(equalToConstant:6).isActive=true;capsuleUnread.setAccessibilityLabel(tr(en:"New insights",zh:"有新内容"));capsuleUnread.isHidden=true;capsuleRoot.addArrangedSubview(capsuleUnread)
        capsuleTimer.font = .monospacedDigitSystemFont(ofSize:12,weight:.medium);capsuleTimer.textColor=MiniTone.fg;capsuleTimer.widthAnchor.constraint(equalToConstant:64).isActive=true;capsuleRoot.addArrangedSubview(capsuleTimer)
        capsuleMeter.mini=true;capsuleMeter.translatesAutoresizingMaskIntoConstraints=false;capsuleRoot.addArrangedSubview(capsuleMeter)
        capsuleMeter.widthAnchor.constraint(equalToConstant:28).isActive=true
        capsulePause=miniIconButton("pause.fill",tr(en:"Pause listening",zh:"暂停听会"),target:self,action:#selector(pauseClicked));capsuleRoot.addArrangedSubview(capsulePause)
        capsuleRoot.addArrangedSubview(miniIconButton("arrow.up.left.and.arrow.down.right",tr(en:"Expand mini window",zh:"展开小窗"),target:self,action:#selector(expandFromCapsule)))
        capsuleRoot.addArrangedSubview(miniIconButton("macwindow",tr(en:"Back to main window",zh:"展开回主窗口"),target:self,action:#selector(openMain)))
        capsuleRoot.addArrangedSubview(miniIconButton("xmark",tr(en:"Hide mini window; keep listening",zh:"隐藏小窗，听会继续"),target:self,action:#selector(hidePanel)))
        capsuleEnd=miniIconButton("stop.fill",tr(en:"End and save",zh:"结束并保存"),target:self,action:#selector(endClicked));capsuleRoot.addArrangedSubview(capsuleEnd)
        transcriptRoot=NSStackView();transcriptRoot.orientation = .vertical;transcriptRoot.alignment = .leading;transcriptRoot.spacing=10;transcriptRoot.edgeInsets=NSEdgeInsets(top:12,left:14,bottom:12,right:14);transcriptRoot.translatesAutoresizingMaskIntoConstraints=false
        let transcriptHeading=NSStackView();transcriptHeading.spacing=8;transcriptHeading.widthAnchor.constraint(equalToConstant:282).isActive=true
        let ccTitle=NSTextField(labelWithString:tr(en:"Live transcript",zh:"实时逐字稿"));ccTitle.font = .systemFont(ofSize:13,weight:.semibold);transcriptHeading.addArrangedSubview(ccTitle)
        let ccFold=NSButton(title:tr(en:"Collapse",zh:"收起"),target:self,action:#selector(collapsePanel));ccFold.bezelStyle = .rounded;transcriptHeading.addArrangedSubview(ccFold);transcriptRoot.addArrangedSubview(transcriptHeading)
        transcriptPreview=NSTextView(frame:NSRect(x:0,y:0,width:282,height:240));transcriptPreview.font = .systemFont(ofSize:13);transcriptPreview.textColor = .labelColor;transcriptPreview.isEditable=false;transcriptPreview.isSelectable=true;transcriptPreview.drawsBackground=false;transcriptPreview.isVerticallyResizable=true;transcriptPreview.isHorizontallyResizable=false;transcriptPreview.autoresizingMask = [.width];transcriptPreview.textContainer?.widthTracksTextView=true
        transcriptScroll.documentView=transcriptPreview;transcriptScroll.hasVerticalScroller=true;transcriptScroll.autohidesScrollers=true;transcriptScroll.drawsBackground=false;transcriptScroll.translatesAutoresizingMaskIntoConstraints=false;transcriptRoot.addArrangedSubview(transcriptScroll);transcriptScroll.widthAnchor.constraint(equalToConstant:282).isActive=true;transcriptScroll.heightAnchor.constraint(equalToConstant:240).isActive=true
        let ccOpen=NSButton(title:tr(en:"View all in Citeside",zh:"在Citeside查看全部"),target:self,action:#selector(openMain));ccOpen.bezelStyle = .rounded;transcriptRoot.addArrangedSubview(ccOpen)
        setupMenu()
        if let rect=NSScreen.main?.visibleFrame { panel.setFrameOrigin(NSPoint(x:rect.maxX-78,y:rect.maxY-panel.frame.height-18)) }
        if !CommandLine.arguments.contains("--presentation-test"),let saved=UserDefaults.standard.string(forKey:"miniWindowFrame") { panel.setFrame(NSRectFromString(saved),display:false) }
        preparePanelPresentation(waitForPolicy:autoStart || !api.owner.isEmpty || CommandLine.arguments.contains("--watch"))
        NotificationCenter.default.addObserver(self,selector:#selector(screensChanged),name:NSApplication.didChangeScreenParametersNotification,object:nil)
        NSWorkspace.shared.notificationCenter.addObserver(self,selector:#selector(presentationEnvironmentChanged),name:NSWorkspace.didActivateApplicationNotification,object:nil)
        NSWorkspace.shared.notificationCenter.addObserver(self,selector:#selector(presentationEnvironmentChanged),name:NSWorkspace.activeSpaceDidChangeNotification,object:nil)
        NSWorkspace.shared.notificationCenter.addObserver(self,selector:#selector(wokeUp),name:NSWorkspace.didWakeNotification,object:nil)
        tick=Timer.scheduledTimer(withTimeInterval:0.5,repeats:true) { [weak self] _ in self?.heartbeat() }
        if CommandLine.arguments.contains("--watch") { concealPanel() }
        if autoStart { let id=argument("--launch-id","");Task { @MainActor in _ = try? await api.request("launch-ack",launchBody(id));startLaunch(id) } }
    }
    func setupMenu() {
        statusItem=NSStatusBar.system.statusItem(withLength:NSStatusItem.variableLength)
        let menu=NSMenu();menu.autoenablesItems=false;menu.delegate=self
        let actions:[(String,Selector)]=[("status",#selector(noAction)),("start",#selector(startClicked)),("mini",#selector(toggleMiniWindow)),("pause",#selector(pauseClicked)),("end",#selector(endClicked)),("sep-meeting",#selector(noAction)),("open",#selector(openMain)),("sep-quit",#selector(noAction)),("quit",#selector(quitClicked))]
        for (key,action) in actions {
            let item:NSMenuItem
            if key.hasPrefix("sep-") { item = .separator() } else { item=NSMenuItem(title:key,action:action,keyEquivalent:"");item.target=self }
            menu.addItem(item);menuItems[key]=item
        }
        menuItems["quit"]?.keyEquivalent="q"
        menuItems["mini"]?.toolTip=tr(en:"Hiding the mini window keeps listening",zh:"隐藏小窗不会停止听会")
        statusItem.menu=menu;statusItem.button?.imagePosition = .imageOnly
        statusItem.button?.image=menuBarImage(badge:"")
        if let button=statusItem.button {
            menuRecordingBadge.translatesAutoresizingMaskIntoConstraints=false;menuRecordingBadge.isHidden=true;button.addSubview(menuRecordingBadge)
            NSLayoutConstraint.activate([menuRecordingBadge.widthAnchor.constraint(equalToConstant:5),menuRecordingBadge.heightAnchor.constraint(equalToConstant:5),menuRecordingBadge.centerXAnchor.constraint(equalTo:button.centerXAnchor,constant:6),menuRecordingBadge.centerYAnchor.constraint(equalTo:button.centerYAnchor,constant:6)])
        }
        refreshMenu()
    }
    @objc func noAction() {}
    func menuWillOpen(_ menu:NSMenu) { refreshMenu() }
    func refreshMenu() {
        guard statusItem != nil else { return }
        let active = !sessionId.isEmpty,elapsed=Int(mirroring ? mirrorSeconds:(engine?.seconds ?? 0))
        for entry in menuBarEntries(english:english,active:active,paused:paused,busy:busy,miniVisible:panel?.isVisible == true && viewMode != .hidden,elapsed:elapsed) {
            guard let item=menuItems[entry.key] else { continue }
            if !item.isSeparatorItem && item.title != entry.title { item.title=entry.title };item.isHidden=entry.hidden;item.isEnabled=entry.enabled
        }
        let badge = !active ? "":paused ? "paused":"listening"
        if badge != menuBadge { menuBadge=badge;statusItem.button?.image=menuBarImage(badge:badge);menuRecordingBadge.state=badge }
        statusItem.button?.setAccessibilityLabel(english ? AppName.en:AppName.zh)
        statusItem.button?.toolTip=menuBarToolTip(english:english,active:active,paused:paused,detail:status?.stringValue ?? "")
        menuItems["mini"]?.toolTip=tr(en:"Hiding the mini window keeps listening",zh:"隐藏小窗不会停止听会")
    }
    @objc func toggleMiniWindow() { if panel.isVisible && viewMode != .hidden { hidePanel() } else { reopenPanel() } }
    // The menu follows the app's interface language, also when it is switched mid-meeting.
    func applyUILanguage(_ j:[String:Any]) {
        guard let language=j["uiLang"] as? String,language=="en"||language=="zh",(language=="en") != english else { return }
        english = language=="en";refreshPresentation()
    }
    @objc func quitClicked() { NSApp.terminate(nil) }
    func refreshPresentation() {
        if !sessionId.isEmpty && unreadMainRequestSession == sessionId && localMainVisible && miniBlockedByMain(policyForeground:false) { miniUnread.unread=false;capsuleUnread.isHidden=true;unreadMainRequestSession="" }
        // Idle or policy-hidden: do not walk the window list. One list covers both decisions.
        if !sessionId.isEmpty && !panelPolicySuppressed {
            let windows=CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? []
            let mini=viewMode == .hidden ? targetMiniFrame() : panel.frame
            let shares=mainSharesMini(windows:windows,mini:mini,policyForeground:false)
            if (viewMode != .hidden || panel.isVisible) && shares { concealPanel();return }
            if !awaitingInitialPanelPolicy && !mainOpenPending && recordingMiniShouldAppear(viewMode:viewMode,sessionActive:sessionId != dismissedPanelSession,sharesScreen:shares) { revealRecordingMiniBar();return }
        }
        // A hidden expanded stack still contributes its minimum fitting size to
        // NSPanel. Keep only the visible mode attached so the mini bar can shrink.
        let visibleRoot = viewMode == .capsule ? capsuleRoot:(viewMode == .compact ? compactRoot!:(viewMode == .transcript ? transcriptRoot!:expandedRoot!))
        if presentedRoot !== visibleRoot,let body=panel.contentView {
            NSLayoutConstraint.deactivate(presentationConstraints);presentedRoot?.removeFromSuperview()
            body.addSubview(visibleRoot);presentedRoot=visibleRoot
            presentationConstraints=[visibleRoot.leadingAnchor.constraint(equalTo:body.leadingAnchor),visibleRoot.trailingAnchor.constraint(equalTo:body.trailingAnchor),visibleRoot.topAnchor.constraint(equalTo:body.topAnchor),visibleRoot.bottomAnchor.constraint(lessThanOrEqualTo:body.bottomAnchor)]
            NSLayoutConstraint.activate(presentationConstraints)
            body.layoutSubtreeIfNeeded()
        }
        if viewMode == .expanded && panel.isVisible && !panelPolicySuppressed { miniUnread.unread=false }
        capsuleUnread.isHidden = !miniUnread.unread
        let active = !sessionId.isEmpty
        let recovering=captureRecovery != "ready" && active
        reconnectButton.isHidden=captureRecovery != "failed" || !active
        if recovering { status.stringValue=tr(en:captureRecovery == "system-audio-unavailable" ? "Microphone only for now: screen locked or display asleep. System audio resumes automatically after unlocking.":captureRecovery == "failed" ? "Sound needs reconnecting":"Recovering sound…",zh:captureRecovery == "system-audio-unavailable" ? "暂时只录麦克风：屏幕已锁定或显示器休眠，解锁后自动恢复系统声音":captureRecovery == "failed" ? "声音尚未恢复，请重新连接":"正在恢复声音…") }
        chapterCaption.isHidden=true;gistCaption.isHidden=true
        chapterBlock.isHidden=recovering || chapterLabel.stringValue.isEmpty
        gistBlock.isHidden=recovering || gistLabel.stringValue.isEmpty
        cardScroll.isHidden=recovering || cardCount==0
        syncMiniRails()
        if recovering { footerBlock.isHidden=true }
        notNowButton.isHidden = active || !meetingCandidate || busy
        let transcriptText=recentTranscript.isEmpty ? tr(en:paused ? "Paused. Resume when ready.":"Waiting for the first transcript…",zh:paused ? "已暂停，点击继续听会":"等待第一段转写…"):recentTranscript
        if transcriptPreview.string != transcriptText {
            let offset=transcriptScroll.contentView.bounds.origin
            let followsLatest=offset.y+transcriptScroll.contentView.bounds.height >= transcriptPreview.bounds.height-24
            transcriptPreview.string=transcriptText;transcriptPreview.layoutManager?.ensureLayout(for:transcriptPreview.textContainer!)
            let needed=transcriptPreview.layoutManager?.usedRect(for:transcriptPreview.textContainer!).height ?? 240
            transcriptPreview.setFrameSize(NSSize(width:282,height:max(240,needed+16)))
            if followsLatest { transcriptPreview.scrollRangeToVisible(NSRange(location:transcriptPreview.string.utf16.count,length:0)) }
            else { transcriptScroll.contentView.scroll(to:offset);transcriptScroll.reflectScrolledClipView(transcriptScroll.contentView) }
        }
        transcriptPreview.isHidden = false
        compactStart.isHidden=active;compactStart.isEnabled = !busy;compactEnd.isHidden = !active;compactEnd.isEnabled = !busy
        startButton.isHidden=active;pauseButton.isHidden = !active;endButton.isHidden = !active;pauseButton.title=tr(en:paused ? "Resume":"Pause",zh:paused ? "继续":"暂停")
        let pauseLabel=tr(en:paused ? "Resume listening":"Pause listening",zh:paused ? "继续听会":"暂停听会")
        pauseButton.image=NSImage(systemSymbolName:paused ? "play.fill":"pause.fill",accessibilityDescription:pauseLabel)?.withSymbolConfiguration(.init(pointSize:13,weight:.regular));pauseButton.imagePosition = .imageOnly;pauseButton.toolTip=pauseLabel;pauseButton.setAccessibilityLabel(pauseLabel)
        let elapsedNow=max(0,Int(mirroring ? mirrorSeconds:(engine?.seconds ?? 0)))
        capsuleDot.state = !active ? "idle":paused ? "paused":"rec"
        capsuleTimer.stringValue=clockText(active ? elapsedNow:0,hours:false)
        capsuleTimer.setAccessibilityLabel(tr(en:"Elapsed time ",zh:"已听会 ")+capsuleTimer.stringValue)
        capsulePause.image=NSImage(systemSymbolName:paused ? "play.fill":"pause.fill",accessibilityDescription:pauseLabel)
        capsulePause.toolTip=pauseLabel;capsulePause.setAccessibilityLabel(pauseLabel);capsulePause.isEnabled=active && !busy;capsuleEnd.isEnabled=active && !busy
        recDot.state = !active ? "idle":paused ? "paused":"rec";timerLabel.stringValue=clockText(active ? elapsedNow:0,hours:true)
        timerLabel.textColor = active ? MiniTone.fg:MiniTone.faint
        meter.dim = !active || paused || transportIssue || !error.isEmpty;footerBlock.isHidden = !active || recovering
        if footerText.stringValue.isEmpty || !active { footerText.stringValue=tr(en:paused ? "Paused":"Waiting for the first transcript…",zh:paused ? "已暂停":"等待第一段转写…") }
        status.isHidden = !recovering && active && !paused && error.isEmpty && !transportIssue && !statusNotice
        compactPause.isHidden = !active;compactPause.image=NSImage(systemSymbolName:paused ? "play":"pause",accessibilityDescription:tr(en:paused ? "Resume listening":"Pause listening",zh:paused ? "继续听会":"暂停听会"));compactPause.setAccessibilityLabel(tr(en:paused ? "Resume listening":"Pause listening",zh:paused ? "继续听会":"暂停听会"));compactPause.toolTip=compactPause.accessibilityLabel()
        startButton.isEnabled = !busy;pauseButton.isEnabled = !busy && engine?.closing != true;endButton.isEnabled = !busy;compactPause.isEnabled = !busy && engine?.closing != true
        refreshMenu()
        let brief = (!error.isEmpty || transportIssue) ? tr(en:"Needs attention",zh:"需注意") : busy ? tr(en:"Working",zh:"正在处理") : active ? tr(en:paused ? "Paused":"Listening",zh:paused ? "已暂停":"正在听") : lastSessionId.isEmpty ? tr(en:"Ready",zh:"待开始"):tr(en:"Ended",zh:"已结束")
        let elapsed=max(0,Int(mirroring ? mirrorSeconds:(engine?.seconds ?? 0)))
        compactButton.title=active ? String(format:"%02d:%02d",elapsed/60,elapsed%60):tr(en:"Open",zh:"打开")
        compactButton.toolTip=brief+" · "+status.stringValue+tr(en:" · Open Citeside",zh:" · 打开Citeside")
        if !active || paused || transportIssue || !error.isEmpty { meter.level=0;compactMeter.level=0;capsuleMeter.level=0 }
        statusItem.button?.toolTip=menuBarToolTip(english:english,active:active,paused:paused,detail:status.stringValue)
        refreshHoverPreview()
        guard viewMode != .hidden else { return }
        let screenHeight=NSScreen.screens.first(where:{$0.visibleFrame.intersects(panel.frame)})?.visibleFrame.height ?? 800
        // .mini-b scrolls past 380pt: the card list takes whatever the other body rows leave.
        bodyStack.layoutSubtreeIfNeeded()
        let others=bodyStack.arrangedSubviews.filter { $0 !== cardScroll && !$0.isHidden }.reduce(CGFloat(0)) { $0+ceil($1.fittingSize.height)+bodyStack.spacing }
        cardViewport.constant=min(cards.frame.height,max(100,min(380-24-others,screenHeight-200)))
        expandedRoot.layoutSubtreeIfNeeded();expandedHeight=max(80,ceil(expandedRoot.fittingSize.height))
        let chrome=panel.frame.height-(panel.contentView?.frame.height ?? panel.frame.height)
        transcriptRoot.layoutSubtreeIfNeeded();compactRoot.layoutSubtreeIfNeeded();capsuleRoot.layoutSubtreeIfNeeded()
        let height=viewMode == .capsule ? 44:(viewMode == .compact ? 52:(viewMode == .transcript ? max(112,min(screenHeight-40,ceil(transcriptRoot.fittingSize.height))):expandedHeight))
        let size=NSSize(width:viewMode == .capsule ? max(280,ceil(capsuleRoot.fittingSize.width)):(viewMode == .compact ? max(246,ceil(compactRoot.fittingSize.width)):(viewMode == .transcript ? 310:360)),height:height+chrome)
        let next=miniFrame(panel.frame,size:size,screens:NSScreen.screens.map { $0.visibleFrame });if next != panel.frame { panel.setFrame(next,display:true);panel.invalidateShadow() }
    }
    // A separate preview keeps the capsule and pointer target stationary. Moving
    // into the preview cancels dismissal; CC still pins the normal transcript.
    func setTranscriptHover(_ inside:Bool) {
        hovering=inside;hoverDismiss?.cancel()
        guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false),viewMode == .compact else { hovering=false;hoverPanel?.orderOut(nil);return }
        if inside { refreshHoverPreview();return }
        let work=DispatchWorkItem { [weak self] in
            guard let self=self else { return }
            self.dismissHoverPreview(at:NSEvent.mouseLocation)
        }
        hoverDismiss=work;DispatchQueue.main.asyncAfter(deadline:.now()+0.2,execute:work)
    }
    func dismissHoverPreview(at pointer:NSPoint) {
        guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false),viewMode == .compact else { hoverPanel?.orderOut(nil);return }
        if panel.frame.contains(pointer) || (hoverPanel?.isVisible == true && hoverPanel!.frame.contains(pointer)) { return }
        hovering=false;hoverPanel?.orderOut(nil)
    }
    func refreshHoverPreview() {
        guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false),viewMode == .compact else { hoverPanel?.orderOut(nil);return }
        guard hovering || hoverPanel?.isVisible == true else { return }
        if hoverPanel == nil {
            let preview=MeetingPanel(contentRect:NSRect(x:0,y:0,width:310,height:212),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
            preview.level = .floating;preview.isFloatingPanel=true;preview.hidesOnDeactivate=false;preview.isReleasedWhenClosed=false
            preview.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary];preview.isOpaque=false;preview.backgroundColor = .clear;preview.hasShadow=true
            let surface=CapsuleSurface();surface.wantsLayer=true;surface.layer?.cornerRadius=14;surface.layer?.backgroundColor=NSColor.windowBackgroundColor.cgColor
            surface.layer?.borderWidth=1;surface.layer?.borderColor=NSColor.separatorColor.withAlphaComponent(0.5).cgColor
            surface.hoverChanged={ [weak self] inside in self?.setTranscriptHover(inside) };preview.contentView=surface
            let title=NSTextField(labelWithString:tr(en:"Live transcript",zh:"实时逐字稿"));title.font = .systemFont(ofSize:13,weight:.semibold);title.frame=NSRect(x:14,y:176,width:180,height:20);surface.addSubview(title)
            let pin=NSButton(title:tr(en:"Keep open",zh:"固定展开"),target:self,action:#selector(toggleTranscript));pin.bezelStyle = .rounded;pin.frame=NSRect(x:202,y:171,width:96,height:30);surface.addSubview(pin)
            let scroll=NSScrollView(frame:NSRect(x:12,y:12,width:286,height:152));scroll.hasVerticalScroller=true;scroll.autohidesScrollers=true;scroll.drawsBackground=false
            let text=NSTextView(frame:NSRect(x:0,y:0,width:282,height:152));text.isEditable=false;text.isSelectable=true;text.drawsBackground=false;text.font = .systemFont(ofSize:13);text.textContainerInset=NSSize(width:2,height:4);text.isVerticallyResizable=true;text.textContainer?.widthTracksTextView=true
            scroll.documentView=text;surface.addSubview(scroll);hoverText=text;hoverPanel=preview
        }
        let text=recentTranscript.isEmpty ? tr(en:paused ? "Paused. Resume when ready.":"Waiting for the first transcript…",zh:paused ? "已暂停，点击继续听会":"等待第一段转写…"):recentTranscript
        if hoverText?.string != text {
            let scroll=hoverText?.enclosingScrollView
            let followsLatest=(scroll?.contentView.bounds.maxY ?? 0)>=(hoverText?.bounds.height ?? 0)-24
            hoverText?.string=text
            if followsLatest { hoverText?.scrollRangeToVisible(NSRange(location:text.utf16.count,length:0)) }
        }
        let frame=panel.frame
        let screen=NSScreen.screens.first(where:{$0.visibleFrame.intersects(frame)})?.visibleFrame ?? frame
        let x=frame.minX-310 >= screen.minX ? frame.minX-310:frame.maxX
        let next=miniFrame(NSRect(x:x,y:frame.maxY-212,width:310,height:212),size:NSSize(width:310,height:212),screens:[screen])
        hoverPanel?.setFrame(next,display:true);hoverPanel?.orderFrontRegardless()
    }
    @objc func toggleIntelligence() { guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false) else { return };hovering=false;hoverDismiss?.cancel();viewMode = viewMode == .expanded ? .compact:.expanded;refreshPresentation();orderMiniFront() }
    @objc func toggleTranscript() { guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false) else { return };hovering=false;hoverDismiss?.cancel();viewMode = viewMode == .transcript ? .compact:.transcript;refreshPresentation();orderMiniFront() }
    @objc func dismissDetection() { inputNotifiedAt=Date();meetingCandidate=false;hidePanel() }
    func presentDetection() {
        // 2026-10-27 baseline: a detected call must not open the old capsule.
        // The main window is the only surface. Status text is set by the caller.
    }
    @objc func showPanel() {
        guard !panelPolicySuppressed else { return }
        if sessionId.isEmpty && !CommandLine.arguments.contains("--presentation-test") { return }
        let target=targetMiniFrame()
        guard !miniBlockedByMain(policyForeground:false,mini:target) else { return }
        viewMode = preferredMiniView;panel.setFrame(target,display:true);refreshPresentation();orderMiniFront()
    }
    func orderMiniFront() {
        guard viewMode != .hidden,!miniBlockedByMain(policyForeground:false) else { return }
        if sessionId.isEmpty && !CommandLine.arguments.contains("--presentation-test") { concealPanel();return }
        panel.orderFrontRegardless();savePosition()
    }
    func revealRecordingMiniBar() {
        if mainOpenPending { return }
        let active = !sessionId.isEmpty && sessionId != dismissedPanelSession
        let target=targetMiniFrame()
        guard recordingMiniShouldAppear(viewMode:viewMode,sessionActive:active,sharesScreen:miniBlockedByMain(policyForeground:false,mini:target)) else { return }
        if awaitingInitialPanelPolicy { awaitingInitialPanelPolicy=false;panelPolicySuppressed=false }
        showPanel()
    }
    @objc func reopenPanel() {
        // Idle Dock/menu must not revive the old capsule; open the main window only.
        guard !sessionId.isEmpty else { openMain();return }
        let id=sessionId
        Task { @MainActor in
            do {
                let receipt=try await api.request("owner-panel-reopen",["sessionId":id,"view":preferredMiniView.rawValue])
                guard acceptsMainRestorePolicy(receipt) else { return }
                if let pid=(receipt["panelPolicy"] as? [String:Any])?["mainPid"] as? Int { mainWindowPID=pid_t(pid) }
                mainOpenPending=false
                if mainWindowPID>0 { NSRunningApplication(processIdentifier:mainWindowPID)?.hide() }
                acceptPanelReopen(receipt,session:id)
            } catch {
                guard sessionId==id else { return }
                let alert=NSAlert();alert.messageText=tr(en:"Unable to show mini window",zh:"暂时无法显示小窗")
                alert.informativeText=tr(en:"Listening continues. Try again shortly, or open Citeside.",zh:"听会仍在继续。请稍后重试，或打开Citeside查看。")
                alert.addButton(withTitle:tr(en:"OK",zh:"好"));alert.runModal()
            }
        }
    }
    func acceptPanelReopen(_ receipt:[String:Any],session id:String) {
        guard sessionId==id,receipt["active"] as? Bool == true,
              let policy=receipt["panelPolicy"] as? [String:Any],policy["sessionId"] as? String == id else { return }
        dismissedPanelSession="";policyResumeView=preferredMiniView
        // Reopening remembers the mini shape while main-window exclusion still wins.
        applyPanelPolicy(receipt)
    }
    @objc func collapseToCapsule() { guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false) else { return };viewMode = .capsule;preferredMiniView = .capsule;policyResumeView = .capsule;hovering=false;hoverPanel?.orderOut(nil);refreshPresentation();savePosition() }
    @objc func expandFromCapsule() { guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false) else { return };viewMode = .expanded;preferredMiniView = .expanded;policyResumeView = .expanded;refreshPresentation();savePosition() }
    @objc func collapsePanel() { guard !panelPolicySuppressed,!miniBlockedByMain(policyForeground:false) else { return };viewMode = .compact;refreshPresentation();orderMiniFront() }
    @objc func hidePanel() {
        if !sessionId.isEmpty {
            dismissedPanelSession=sessionId
            let id=sessionId
            Task { _ = try? await api.request("owner-panel-dismiss",["sessionId":id]) }
        }
        concealPanel()
    }
    func preparePanelPresentation(waitForPolicy:Bool) {
        // Startup keeps the status item only. Recording is what orders the bar front.
        awaitingInitialPanelPolicy=waitForPolicy;panelPolicySuppressed=waitForPolicy
        if !CommandLine.arguments.contains("--presentation-test"),let saved=UserDefaults.standard.string(forKey:"miniWindowMode"),let mode=MiniView(rawValue:saved),mode != .hidden { preferredMiniView=mode }
        policyResumeView=preferredMiniView;viewMode = .hidden;panel.orderOut(nil)
        if waitForPolicy { return }
        if !CommandLine.arguments.contains("--presentation-test") { openMain() }
    }
    // The meeting window is the one NativeMain titles. A 500×500 untitled backing
    // window of the same process is not the big window, so it must not hide the mini panel.
    static func meetingWindowOnScreen(_ windows:[[String:Any]], pid:pid_t)->Bool {
        meetingWindowFrame(windows,pid:pid) != nil
    }
    static func meetingWindowFrame(_ windows:[[String:Any]], pid:pid_t)->NSRect? {
        for w in windows {
            guard w[kCGWindowOwnerPID as String] as? Int32==pid,
                  w[kCGWindowLayer as String] as? Int==0,
                  let bounds=w[kCGWindowBounds as String] as? [String:CGFloat] else { continue }
            let name=w[kCGWindowName as String] as? String ?? ""
            if ["Citeside"].contains(name) && (bounds["Width"] ?? 0)>200 && (bounds["Height"] ?? 0)>100 {
                let primary=NSScreen.screens.first { $0.frame.origin == .zero } ?? NSScreen.screens.first
                return appKitRect(fromQuartzWindow:bounds,primaryHeight:primary?.frame.height ?? 0)
            }
        }
        return nil
    }
    // Place a restored mini window by the pointer; only a foreground main window suppresses it.
    func targetMiniFrame()->NSRect {
        let screen=NSScreen.screens.first { $0.frame.contains(NSEvent.mouseLocation) } ?? NSScreen.main
        guard let rect=screen?.visibleFrame else { return panel.frame }
        return placedMiniFrame(on:rect,size:panel.frame.size)
    }
    func miniBlockedByMain(policyForeground:Bool,mini:NSRect?=nil)->Bool {
        if CommandLine.arguments.contains("--presentation-test"),let value=localMainVisibleOverride { return value }
        let windows=CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? []
        let frame=mini ?? (viewMode == .hidden ? targetMiniFrame() : panel.frame)
        return mainSharesMini(windows:windows,mini:frame,policyForeground:policyForeground)
    }
    func mainSharesMini(windows:[[String:Any]],mini:NSRect,policyForeground:Bool)->Bool {
        if CommandLine.arguments.contains("--presentation-test"),let value=localMainVisibleOverride { return value }
        return miniMainIsForeground(policy:policyForeground,ownerPID:mainWindowPID,
            frontmostPID:NSWorkspace.shared.frontmostApplication?.processIdentifier,
            visible:Self.meetingWindowOnScreen(windows,pid:mainWindowPID))
    }
    var localMainVisible:Bool {
        if CommandLine.arguments.contains("--presentation-test"),let value=localMainVisibleOverride { return value }
        guard mainWindowPID>0 else { return false }
        let windows=CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? []
        return Self.meetingWindowOnScreen(windows, pid:mainWindowPID)
    }
    @objc func presentationEnvironmentChanged() { if localMainVisible { mainOpenPending=false };if !latestPanelStatus.isEmpty { applyPanelPolicy(latestPanelStatus) } }
    func placeOnCurrentScreen() { panel.setFrame(targetMiniFrame(),display:true) }
    func acceptsMainRestorePolicy(_ j:[String:Any])->Bool {
        guard let policy=j["panelPolicy"] as? [String:Any],let epoch=policy["mainRestoreEpoch"] as? String,let serial=policy["mainRestoreSerial"] as? Int else { return mainRestoreEpoch.isEmpty }
        if retiredMainRestoreEpochs.contains(epoch) { return false }
        if epoch != mainRestoreEpoch {
            if !mainRestoreEpoch.isEmpty { retiredMainRestoreEpochs.insert(mainRestoreEpoch) }
            mainRestoreEpoch=epoch;mainRestoreSerial=serial;return true
        }
        guard serial>=mainRestoreSerial else { return false }
        mainRestoreSerial=serial;return true
    }
    func applyPanelPolicy(_ j:[String:Any]) {
        guard acceptsMainRestorePolicy(j) else { return }
        latestPanelStatus=j
        if let pid=(j["panelPolicy"] as? [String:Any])?["mainPid"] as? Int { mainWindowPID=pid_t(pid) }
        guard let policy=j["panelPolicy"] as? [String:Any],policy["managed"] as? Bool == true else {
            // A standalone helper can work without an owner policy. An owned
            // helper waits for its main window; a watcher stays unobtrusive.
            if awaitingInitialPanelPolicy && api.owner.isEmpty {
                // An ownerless status used to order this panel on screen. That is the
                // capsule beside the main window with no meeting
                // (2026-10-27 17:11, helper launched --start and no --owner).
                awaitingInitialPanelPolicy=false;panelPolicySuppressed=false
                if panel.isVisible || viewMode != .hidden { concealPanel() }
            }
            return
        }
        awaitingInitialPanelPolicy=false
        let id=policy["sessionId"] as? String ?? ""
        let show=policy["show"] as? Bool == true && id != dismissedPanelSession
        let mainForeground=miniBlockedByMain(policyForeground:policy["mainForeground"] as? Bool == true)
        if mainForeground { mainOpenPending=false }
        let key=id+":"+String(show)+(mainForeground ? ":main":"")+":"+String(policy["serial"] as? Int ?? 0)+":"+String(policy["mainRestoreSerial"] as? Int ?? 0)
        let changed=key != lastPanelPolicyKey
        // The idle key used to be exactly ":false". Serial fields made it ":false:0:0",
        // so a finished meeting never released the menu. Main-foreground stays suppressed.
        let previousIdle = lastPanelPolicyKey == ":false" || (lastPanelPolicyKey.hasPrefix(":false:") && !lastPanelPolicyKey.contains(":main:"))
        let hadMeetingPolicy = !lastPanelPolicyKey.isEmpty && !previousIdle
        // This is a continuing visibility constraint, not a one-shot command.
        // Local CC/lightbulb/menu actions must not bring either panel back over
        // the foreground main window while the server policy remains hidden.
        let suppress = mainOpenPending || mainForeground || !show && ( !sessionId.isEmpty || !id.isEmpty || hadMeetingPolicy)
        if suppress && !panelPolicySuppressed && viewMode != .hidden { policyResumeView=viewMode }
        if changed && !id.isEmpty && !lastPanelPolicyKey.isEmpty && !lastPanelPolicyKey.hasPrefix(id+":") { policyResumeView = .expanded }
        let wasSuppressed=panelPolicySuppressed
        panelPolicySuppressed=suppress;lastPanelPolicyKey=key
        // No local session means this helper is not the one recording, so it does not keep a bar.
        if suppress || sessionId.isEmpty {
            if viewMode != .hidden || panel.isVisible || hoverPanel?.isVisible == true { concealPanel() }
        } else if show && (changed || wasSuppressed) {
            placeOnCurrentScreen()
            let requested=(policy["view"] as? String).flatMap { MiniView(rawValue:$0) }
            viewMode=requested == .compact ? .capsule:(requested == .hidden ? policyResumeView:(requested ?? policyResumeView));refreshPresentation();orderMiniFront()
        }
        if suppress,policy["mainRestorePending"] as? Bool == true,!api.owner.isEmpty,let serial=policy["mainRestoreSerial"] as? Int,serial>0 {
            hoverPanel?.orderOut(nil)
            if !panel.isVisible && hoverPanel?.isVisible != true {
                Task { @MainActor in
                    guard self.lastPanelPolicyKey==key,!self.panel.isVisible,self.hoverPanel?.isVisible != true else { return }
                    _ = try? await self.api.request("main-handoff-ack",["serial":serial,"hidden":true,"pid":Int(ProcessInfo.processInfo.processIdentifier)])
                }
            }
        }
        // An explicit main-to-mini transfer is complete only after this helper
        // actually orders the requested panel on screen. A serial ties the
        // acknowledgement to exactly one request and rejects late callbacks.
        if !suppress,show,panel.isVisible,!api.owner.isEmpty,let serial=policy["serial"] as? Int,serial>0 {
            Task { @MainActor in
                guard self.lastPanelPolicyKey==key,self.panel.isVisible,!self.miniBlockedByMain(policyForeground:false) else { return }
                do { _ = try await self.api.request("panel-handoff-ack",["sessionId":id,"serial":serial,"visible":true,"pid":Int(ProcessInfo.processInfo.processIdentifier)]) }
                catch {
                    if error.localizedDescription=="native_panel_handoff_stale",self.lastPanelPolicyKey==key { self.noteStaleHandoff() }
                }
            }
        }
    }
    // A rejected ack used to hide the mini panel, and the main window then came back.
    // While this meeting is on screen and the big window is not, keep the mini panel.
    func noteStaleHandoff() {
        guard !lastPanelPolicyKey.isEmpty else { return }
        if panel.isVisible && !sessionId.isEmpty && !panelPolicySuppressed && !miniBlockedByMain(policyForeground:false) && !mainOpenPending { return }
        concealPanel();lastPanelPolicyKey=""
    }
    func concealPanel() { hovering=false;hoverDismiss?.cancel();savePosition();viewMode = .hidden;panel.orderOut(nil);refreshPresentation() }
    @objc func screensChanged() { Task { @MainActor in self.presentationEnvironmentChanged();self.refreshPresentation();self.engine?.recoverStreams() } }
    @objc func wokeUp() { Task { @MainActor in self.engine?.recoverStreams() } }
    @objc func reconnectCapture() { Task { @MainActor in self.engine?.recoverStreams() } }
    func updateCaptureRecovery(_ state:String) {
        if state == "recovering",captureRecovery == "ready" { recoveryResumeView=viewMode;if viewMode != .hidden { viewMode = .expanded } }
        captureRecovery=state
        if state == "ready",let previous=recoveryResumeView { if viewMode != .hidden { viewMode=previous };recoveryResumeView=nil }
        refreshPresentation()
    }
    func savePosition() { guard captureRecovery == "ready" else { return };if viewMode == .expanded || viewMode == .capsule { preferredMiniView=viewMode };guard !CommandLine.arguments.contains("--presentation-test"),viewMode != .hidden else { return };UserDefaults.standard.set(NSStringFromRect(panel.frame),forKey:"miniWindowFrame");UserDefaults.standard.set(viewMode.rawValue,forKey:"miniWindowMode") }
    func windowDidMove(_ notification:Notification) { refreshHoverPreview();savePosition() }
    func windowShouldClose(_ sender:NSWindow)->Bool { hidePanel();return false }
    func applicationShouldHandleReopen(_ sender:NSApplication,hasVisibleWindows flag:Bool)->Bool { openMain();return false }
    func showError(_ message:String) { error=message;status.stringValue=message;refreshPresentation() }
    func showTransportError(_ message:String) { transportIssue=true;transportMessage=message;status.stringValue=error.isEmpty ? message:error;refreshPresentation() }
    func recoverTransport() {
        transportIssue=false;transportMessage=""
        if sessionId.isEmpty { status.stringValue=error.isEmpty ? tr(en:"Return to your meeting and press Start",zh:"切回会议窗口，点开始"):error }
        refreshPresentation()
    }
    func joinMeeting(_ link:String,launchId:String="") {
        if CommandLine.arguments.contains("--owner-binding-test") { return }
        guard !busy,sessionId.isEmpty,engine==nil,let url=URL(string:link),url.scheme=="https",["vc.feishu.cn","vc.larksuite.com","meet.google.com"].contains(url.host ?? "") else { return }
        busy=true;status.stringValue=tr(en:"Opening meeting; finish sign-in or the waiting room if needed",zh:"正在打开会议；如有登录或等候室请先完成");refreshPresentation()
        Task { @MainActor in
            var handedToCapture=false
            defer { if !handedToCapture { busy=false;refreshPresentation() } }
            do {
                _ = try await api.request("launch-ack",launchBody(launchId))
                guard NSWorkspace.shared.open(url) else { throw CaptureError.message("会议链接未能打开") }
                busy=false;handedToCapture=true;startLaunch(launchId)
            } catch {
                _ = try? await api.request("cancel-start",launchBody(launchId,["error":error.localizedDescription]))
                showError(error.localizedDescription)
            }
        }
    }
    @objc func startClicked() {
        if CommandLine.arguments.contains("--owner-binding-test") { return }
        guard !busy,sessionId.isEmpty,engine==nil else { return }
        let launchId=pendingLaunchId;pendingLaunchId=""
        // A fresh attempt must not present the previous meeting while permission
        // requests are pending or after they fail. Saved meeting data stays intact.
        recentTranscript="";mirrorSeconds=0;paused=false;mirroring=false
        transportIssue=false;transportMessage="";error="";meter.level=0;compactMeter.level=0;capsuleMeter.level=0
        recoveryPermission=nil;permissionSettingsButton.isHidden=true
        lastCards="";cardCount=0;confirmationHandlers=[];expandedCards=[]
        for view in cards.arrangedSubviews { cards.removeArrangedSubview(view);view.removeFromSuperview() }
        cardScroll.isHidden=true
        captureRecovery="ready";captureRetryGate=CaptureRetryGate();recoveryResumeView=nil;busy=true;status.stringValue=tr(en:"Connecting…",zh:"正在接入会议…");refreshPresentation()
        Task { @MainActor in
            do {
                if let current=try? await api.request("status"),current["active"] as? Bool == true,current["captureMode"] as? String == "browser" {
                    adoptBrowser(current);busy=false;refreshPresentation();return
                }
                // Decide from the actual ScreenCaptureKit authorization result.
                // The system permission request remains required; no bypass.
                let audioConfig=try await api.request("audio-config");cloudASR=audioConfig["transport"] as? String == "pcm"
                if !cloudASR { let authorized=await withCheckedContinuation { (c:CheckedContinuation<Bool,Never>) in SFSpeechRecognizer.requestAuthorization { c.resume(returning:$0 == .authorized) } }
                guard authorized else { throw CapturePermission.speech }
                }
                let micAuthorized=await AVCaptureDevice.requestAccess(for:.audio)
                guard micAuthorized else { throw CapturePermission.microphone }
                if !cloudASR { guard let recognizer=SFSpeechRecognizer(locale:Locale(identifier:locale)),recognizer.supportsOnDeviceRecognition else { throw CaptureError.message(tr(en:"On-device recognition is unavailable for this language",zh:"这门语言尚未支持本机转写；请先下载系统识别语言")) } }
                let content=try await authorizedScreenContent(load: {
                    try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
                }, request: { CGRequestScreenCaptureAccess() })
                // Audio is desktop-wide. A meeting window is optional and does not
                // become an implicit permission to upload its screen contents.
                joinTarget=nil
                let target:MeetingTarget?=nil
                // Record from the click: the meeting and transcription connect while audio is already buffered.
                captureGeneration+=1;let generation=captureGeneration
                nextAudioSequence=1;audioQueue=[];pendingCapturedAt=[:];textQueue=[]
                let capture=CaptureEngine(pcm:{ [weak self] data in let capturedMono=ProcessInfo.processInfo.systemUptime*1000;DispatchQueue.main.async { guard let self=self,self.captureGeneration==generation else { return };self.notePendingSpool(data);// 上传积压不再暂停录音：本机文件照常写，积压超过 30 分钟（9000×200ms）才不再排队，跳过的那段由会后重转写补上；序号不跳，服务端不报 gap
                    if self.audioQueue.count<9000 { self.audioQueue.append((self.nextAudioSequence,data,capturedMono));self.nextAudioSequence+=1 };if self.audioQueue.count==150 && !self.paused { self.showTransportError(self.tr(en:"Live transcript is catching up; recording continues",zh:"实时转写在追赶，录音照常进行")) };self.flushEvents() } },text:{ [weak self] key,text in DispatchQueue.main.async { guard let self=self,self.captureGeneration==generation else { return };self.textQueue.append((key,text));self.flushEvents() } },frame:{ [weak self] data in DispatchQueue.main.async { guard let self=self,self.captureGeneration==generation else { return };self.pendingFrame=data;self.flushEvents() } },failure:{ [weak self] message in DispatchQueue.main.async { guard let self=self,self.captureGeneration==generation else { return };self.showError(message) } }) // 采集或本机转写出错只提示、不暂停：另一路声音和本机录音继续
                capture.recoveryChanged={ [weak self, weak capture] state in guard let self=self,let capture=capture,self.engine === capture else { return };self.updateCaptureRecovery(state) }
                engine=capture;try await capture.begin(target:target,content:content,locale:locale,cloudASR:cloudASR,inputUID:audioConfig["inputUID"] as? String ?? "")
                status.stringValue=tr(en:"Recording · connecting transcription…",zh:"录音中 · 正在连接转写…")
                let j=try await api.request("start",launchBody(launchId,["lang":locale.hasPrefix("en") ? "en" : "zh","uiLang":english ? "en" : "zh"]))
                guard let id=j["sessionId"] as? String else { throw CaptureError.message("已有会议在采集；请先结束当前采集") }
                sessionId=id;lastSessionId=id;lastHeartbeat=Date();error="";revealRecordingMiniBar()
                guard let asr=j["asr"] as? [String:Any],(asr["transport"] as? String == "pcm")==cloudASR else { throw CaptureError.message("转写配置已变化，请重新开始") }
                if let requested=j["inputUID"] as? String,requested != (audioConfig["inputUID"] as? String ?? "") { try capture.switchMicrophone(uid:requested) }
                pendingAudio=j["pendingAudio"] as? Bool == true
                if pendingAudio { restorePendingSpool() }
                else if let file=j["audioPath"] as? String, !file.isEmpty { try await capture.attach(audioPath:file) }
                else { throw CaptureError.message("已有会议在采集；请先结束当前采集") }
                flushEvents()
                _ = try await api.request("ready",["sessionId":id])

                startButton.isHidden=true;pauseButton.isHidden=false;endButton.isHidden=false;lastCards="";renderStatus(j)
            } catch { let stopConfirmed=await cleanupFailedStart();let permission=error as? CapturePermission
                let message=stopConfirmed ? (permission?.message(english:english) ?? error.localizedDescription):tr(en:"Recording stop unconfirmed; retry quitting.",zh:"录音停止尚未确认，请重试退出")
                try? await api.request("cancel-start",launchBody(launchId,["error":message,"captureStopped":stopConfirmed]));showError(message)
                if let permission=permission { showPermissionRecovery(permission) }
            }
            busy=false;refreshPresentation()
        }
    }
    func showPermissionRecovery(_ permission:CapturePermission) {
        // ScreenCaptureKit may return userDeclined while macOS still has its
        // consent dialog open. Never activate our app or run a second modal
        // alert here: doing so obscures the only dialog that can grant access.
        recoveryPermission=permission;permissionSettingsButton.isHidden=false
        permissionSettingsButton.toolTip=tr(en:"Complete the macOS permission dialog first. If no dialog is visible, open permission settings. Recording has not started.",zh:"先完成系统授权框；若没有授权框，打开权限设置。尚未录制。")
    }
    @objc func openPermissionSettings() {
        guard let permission=recoveryPermission else { return }
        if !NSWorkspace.shared.open(permission.settingsURL) {
            showError(tr(en:"Could not open System Settings. Open Privacy & Security manually and check Citeside Helper permissions; recording has not started.",zh:"无法打开系统设置，请手动打开“隐私与安全性”检查Citeside权限；尚未开始录制"))
        }
    }
    func findTarget(_ content:SCShareableContent,front:pid_t?) throws -> MeetingTarget {
        let order=(CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? []).compactMap { $0[kCGWindowNumber as String] as? UInt32 }
        let windows=content.windows.filter { $0.windowLayer==0 && $0.frame.width>200 && $0.frame.height>120 }
        if let current=windows.filter({ window in window.owningApplication?.processID==front && window.owningApplication?.processID != ProcessInfo.processInfo.processIdentifier && !["Citeside"].contains(where: { (window.title ?? "").contains($0) })}).sorted(by:{(order.firstIndex(of:$0.windowID) ?? 999)<(order.firstIndex(of:$1.windowID) ?? 999)}).first { return MeetingTarget(window:current) }
        if let detected=windows.first(where:{recognizedMeeting(bundle:$0.owningApplication?.bundleIdentifier ?? "",title:$0.title ?? "")}) { return MeetingTarget(window:detected) }
        if let pin=UserDefaults.standard.dictionary(forKey:"pinnedMeetingWindow"),let id=pin["windowId"] as? Int,let bundle=pin["bundleId"] as? String,let title=pin["title"] as? String,let old=windows.first(where:{Int($0.windowID)==id && $0.owningApplication?.bundleIdentifier==bundle && $0.title==title}) { return MeetingTarget(window:old) }
        throw CaptureError.message(tr(en:"Return to the meeting or playback window and press Start here",zh:"切回要听的会议或播放窗口，点小窗的开始"))
    }
    func notePendingSpool(_ data: Data) {
        guard pendingAudio, !sessionId.isEmpty, !data.isEmpty else { return }
        let at = Int(Date().timeIntervalSince1970 * 1000)
        if audioQueue.count < 9000 {
            pendingCapturedAt[nextAudioSequence] = at
            audioSpool.protect(session: sessionId, seq: nextAudioSequence, capturedAtMs: at, pcm: data)
        } else {
            audioSpool.protectOverflow(session: sessionId, capturedAtMs: at, pcm: data)
        }
    }
    func restorePendingSpool() {
        guard pendingAudio, !sessionId.isEmpty else { return }
        let nowMs = Int(Date().timeIntervalSince1970 * 1000)
        audioSpool.sweep(nowMs: nowMs)
        let old = audioSpool.unacked(session: sessionId).sorted { $0.seq < $1.seq }
        var seq = max((old.map { $0.seq }.max() ?? 0) + 1, 1)
        var merged: [(Int, Data, Double)] = []
        for item in old {
            pendingCapturedAt[item.seq] = item.capturedAtMs
            merged.append((item.seq, item.pcm, 0))
        }
        for item in audioQueue {
            let at = pendingCapturedAt[item.0] ?? nowMs
            pendingCapturedAt[seq] = at
            audioSpool.protect(session: sessionId, seq: seq, capturedAtMs: at, pcm: item.1)
            merged.append((seq, item.1, item.2))
            seq += 1
        }
        if merged.count > 9000 { merged = Array(merged.prefix(9000)) }
        audioQueue = merged
        nextAudioSequence = max(seq, (merged.map { $0.0 }.max() ?? 0) + 1)
    }
    func adoptOneOverflow() {
        guard pendingAudio, !sessionId.isEmpty, audioQueue.count < 9000 else { return }
        let queued = Set(audioQueue.map { $0.0 })
        if let stored = audioSpool.unacked(session: sessionId).first(where: { !queued.contains($0.seq) }) {
            pendingCapturedAt[stored.seq] = stored.capturedAtMs
            audioQueue.append((stored.seq, stored.pcm, 0))
            nextAudioSequence = max(nextAudioSequence, stored.seq + 1)
            return
        }
        guard let adopted = audioSpool.adoptOverflow(session: sessionId, seq: nextAudioSequence) else { return }
        pendingCapturedAt[nextAudioSequence] = adopted.capturedAtMs
        audioQueue.append((nextAudioSequence, adopted.pcm, 0))
        nextAudioSequence += 1
    }
    func flushEvents() {
        guard !sending,!sessionId.isEmpty else { return };sending=true;let id=sessionId;let generation=captureGeneration
        Task { @MainActor in
            defer { sending=false }
            do {
                if pendingAudio { audioSpool.sweep(nowMs: Int(Date().timeIntervalSince1970 * 1000)) }
                while sessionId==id && captureGeneration==generation,!audioQueue.isEmpty {
                    let e=audioQueue[0]
                    var body:[String:Any]=["sessionId":id,"seq":e.0,"pcm":e.1.base64EncodedString(),"latencyDiagnostic":["key":"native:\(id):\(e.0)","seq":e.0,"clock":"uptime","captureMonoMs":e.2,"sendMonoMs":ProcessInfo.processInfo.systemUptime*1000,"captureToSendMs":ProcessInfo.processInfo.systemUptime*1000-e.2]]
                    if let at=pendingCapturedAt[e.0] { body["capturedAt"]=at }
                    let ack=try await api.request("audio", body)
                    guard sessionId==id && captureGeneration==generation else { return }
                    guard ack["seq"] as? Int == e.0 else { throw CaptureError.message("音频确认不匹配") }
                    if pendingAudio { audioSpool.remove(session: id, seq: e.0); pendingCapturedAt[e.0]=nil }
                    audioQueue.removeFirst()
                    if pendingAudio { adoptOneOverflow() }
                }
                while sessionId==id && captureGeneration==generation,!textQueue.isEmpty { let e=textQueue[0];try await api.request("text",["sessionId":id,"key":e.0,"text":e.1]);guard sessionId==id && captureGeneration==generation else { return };textQueue.removeFirst() }
                if sessionId==id && captureGeneration==generation,let image=pendingFrame { pendingFrame=nil;do { try await api.request("frame",["sessionId":id,"jpeg":image.base64EncodedString()]) } catch { if sessionId==id && captureGeneration==generation && pendingFrame==nil { pendingFrame=image };throw error } }
            } catch { if error.localizedDescription=="meeting_ended" { await finishEndedSession(id,generation:generation) } else if sessionId==id && captureGeneration==generation { showTransportError(tr(en:"Disconnected, reconnecting",zh:"与Citeside断开，正在重连")) } }
        }
    }
    func adoptBrowser(_ j:[String:Any]) {
        guard let id=j["sessionId"] as? String else { return }
        let tookOver=sessionId != id
        mirroring=true;sessionId=id;lastSessionId=id;error="";paused=j["phase"] as? String == "paused"
        startButton.isHidden=true;pauseButton.isHidden=false;endButton.isHidden=false;renderStatus(j)
        if tookOver { revealRecordingMiniBar() }
    }
    // Only a process-local explicit end receipt authorizes dropping this capture.
    @MainActor func finishEndedSession(_ id:String,generation:Int?=nil) async {
        guard !id.isEmpty,sessionId==id,!mirroring,generation==nil || generation==captureGeneration else { return }
        busy=true;captureGeneration+=1
        let capture=engine
        sessionId="";engine=nil;audioQueue=[];textQueue=[];pendingFrame=nil
        _ = await capture?.stop(discardPending:true)
        resetSession();busy=false;refreshPresentation()
    }
    func resetSession() {
        captureGeneration+=1;audioQueue=[];textQueue=[];pendingFrame=nil;pendingAudio=false;pendingCapturedAt=[:];error=""
        captureRecovery="ready";sessionId="";mirroring=false;mirrorSeconds=0;paused=false;engine=nil;recentTranscript="";hovering=false;meter.level=0;compactMeter.level=0;capsuleMeter.level=0;transportIssue=false;transportMessage=""
        startButton.isHidden=false;pauseButton.isHidden=true;endButton.isHidden=true
        status.stringValue=tr(en:"Ended · Continue in Citeside",zh:"已结束 · 可回Citeside继续");refreshPresentation();hidePanel()
    }
    var meetingCandidate=false
    var inputNotifiedAt=Date.distantPast
    func detectMeeting() {
        if CommandLine.arguments.contains("--owner-binding-test") { return }
        guard watchEnabled,sessionId.isEmpty,!busy,Date().timeIntervalSince(watchScanAt)>5 else { return };watchScanAt=Date()
        if #available(macOS 14.2, *),let active=meetingInputProcesses() {
            meetingCandidate = !active.isEmpty
            if meetingCandidate,!panelPolicySuppressed,Date().timeIntervalSince(inputNotifiedAt)>1800 { inputNotifiedAt=Date();status.stringValue=tr(en:"Call activity detected; press Start to listen",zh:"检测到通话，点开始听会");presentDetection() }
            return
        }
        // Older macOS fallback: window metadata only; no capture until Start.
        guard CGPreflightScreenCaptureAccess() else { return }
        let windows=(CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? [])
        for w in windows {
            guard let pid=w[kCGWindowOwnerPID as String] as? Int32,let app=NSRunningApplication(processIdentifier:pid),let title=w[kCGWindowName as String] as? String,let id=w[kCGWindowNumber as String] as? UInt32,recognizedMeeting(bundle:app.bundleIdentifier ?? "",title:title) else { continue }
            guard Date().timeIntervalSince(notifiedWindows[id] ?? .distantPast)>1800 else { continue }
            if panelPolicySuppressed { meetingCandidate=true;joinTarget=id;return }
            notifiedWindows[id]=Date();meetingCandidate=true;joinTarget=id;status.stringValue=tr(en:"Meeting detected: ",zh:"发现会议：")+title;presentDetection();return
        }
    }
    // Idle and refresh use non-prompting status APIs. Only an explicit request
    // may invoke the system permission API; neither action starts capture.
    func reportPermissions() async {
        func microphone() -> String {
            switch AVCaptureDevice.authorizationStatus(for:.audio) { case .authorized:return "authorized";case .denied:return "denied";case .restricted:return "restricted";case .notDetermined:return "notDetermined";@unknown default:return "unknown" }
        }
        func report() -> [String:Any] { ["microphone":microphone(),"screen":screenPermissionReport.status(preflight:CGPreflightScreenCaptureAccess())] }
        guard let j=try? await api.request("permissions",report()),let kind=j["request"] as? String,!kind.isEmpty else { return }
        if kind == "microphone" {
            if microphone()=="notDetermined" { _ = await AVCaptureDevice.requestAccess(for:.audio) }
            else if microphone() != "authorized" { NSWorkspace.shared.open(CapturePermission.microphone.settingsURL) }
        } else if kind == "screen" {
            // A focus/settings refresh reads only this helper's CG state.
            // Metadata enumeration can prompt and does not prove image access.
            if j["verifyOnly"] as? Bool != true,!CGPreflightScreenCaptureAccess() { _ = CGRequestScreenCaptureAccess() }
            let state=CGPreflightScreenCaptureAccess() ? "authorized":"unknown"
            screenPermissionReport.verified(state)
            if state != "authorized" && j["verifyOnly"] as? Bool != true { NSWorkspace.shared.open(CapturePermission.screen.settingsURL) }
        }
        _ = try? await api.request("permissions",report())
    }
    func heartbeat() {
        guard !heartbeating else { return }
        heartbeating=true
        Task { @MainActor in
            defer { heartbeating=false }
            let id=sessionId;let generation=captureGeneration
            do {
                if sessionId.isEmpty || mirroring {
                    // microphoneDevices() is a synchronous HAL call. Doing it on the main
                    // thread while start is also inside CoreAudio wedges both sides.
                    // The owner fixture exercises lifecycle receipts without querying hardware or permissions.
                    if !CommandLine.arguments.contains("--owner-binding-test") {
                        if !api.owner.isEmpty && !busy { _ = try? await api.request("input-devices",["inputDevices":microphoneDevices().map{$0.json}]) }
                        if sessionId.isEmpty && Date().timeIntervalSince(lastPermissionReport)>=2 { lastPermissionReport=Date();await reportPermissions() }
                    }
                    let j=try await api.request("status");applyUILanguage(j)
                    // The helper, not a newly restarted server, owns the truth about its
                    // local engine. Never retire an active or starting recorder.
                    if j["command"] as? String == "update-quit" {
                        if sessionId.isEmpty && engine == nil && !busy && !quitInFlight { quitApproved=true;NSApp.terminate(nil) }
                        return
                    }
                    if j["command"] as? String == "quit",!api.owner.isEmpty { NSApp.terminate(nil);return }
                    if CommandLine.arguments.contains("--owner-binding-test") { return }
                    if transportIssue { recoverTransport() }
                    if j["active"] as? Bool == true,j["captureMode"] as? String == "browser" { adoptBrowser(j) }
                    else if mirroring { resetSession() }
                    else if j["command"] as? String == "join",let link=j["meetingUrl"] as? String,!busy { joinMeeting(link,launchId:j["launchId"] as? String ?? "") }
                    else if j["command"] as? String == "start",!busy { let id=j["launchId"] as? String ?? "";_ = try? await api.request("launch-ack",launchBody(id));startLaunch(id) }
                    else if j["active"] as? Bool != true { detectMeeting() }
                    applyPanelPolicy(j)
                    return
                }
                flushEvents()
                let level=paused ? 0:(engine?.meterSnapshot() ?? 0)
                meter.level=level;compactMeter.level=level;capsuleMeter.level=level
                var beat:[String:Any]=["sessionId":id,"audioSeconds":engine?.seconds ?? 0,"audioLevel":level,"error":error,"view":viewMode.rawValue,"inputUID":engine?.inputUID ?? "","inputName":engine?.inputName ?? "","inputDevices":microphoneDevices().map{$0.json},"captureRecovery":captureRecovery,"captureRetryAck":captureRetryGate.acknowledged,"audioEvidence":engine?.audioEvidence() ?? [:]]
                beat["capturePaused"]=paused || engine?.closing == true;beat["captureEnding"]=engine?.closing == true;beat["pendingAudioPackets"]=audioQueue.count
                let j=try await api.request("heartbeat",beat);lastHeartbeat=Date()
                guard sessionId==id else { return };guard captureGeneration==generation else { return };applyUILanguage(j);if transportIssue && textQueue.isEmpty && audioQueue.isEmpty && pendingFrame==nil { recoverTransport() }
                if let command=j["command"] as? String { if command=="quit",!api.owner.isEmpty { NSApp.terminate(nil);return };if command=="stop" { endClicked();return };if command=="pause" && !paused { pauseClicked() };if command=="resume" && paused { pauseClicked() } }
                // The same owner heartbeat delivers a session-bound request. Never replace
                // the engine or reset its timeline/file; stop/pause always take priority.
                if let retry=j["captureRetry"] as? [String:Any] {
                    let accepted=captureRetryGate.handle(retry,sessionId:id,command:j["command"] as? String ?? "",paused:paused,ready:engine?.captureReady == true && engine?.closing == false) { self.engine?.recoverStreams() }
                    if accepted == false { showError(tr(en:"Recording is not ready to reconnect",zh:"录音端尚未就绪，无法重新连接")) }
                }
                if let change=j["microphoneChange"] as? [String:Any],let requestId=change["requestId"] as? String,let uid=change["inputUID"] as? String {
                    var switchError=""
                    if lastMicrophoneRequest==requestId { switchError=lastMicrophoneError }
                    else {
                        do { if let expires=change["expiresAt"] as? Double,Date().timeIntervalSince1970*1000>expires { throw CaptureError.message("设备切换请求已超时，原输入保持不变；可重试") };guard let capture=engine else { throw CaptureError.message("录音引擎未连接，未切换麦克风") };try capture.switchMicrophone(uid:uid) } catch { switchError=error.localizedDescription }
                        lastMicrophoneRequest=requestId;lastMicrophoneError=switchError
                    }
                    _ = try await api.request("microphone-ack",["sessionId":id,"requestId":requestId,"error":switchError,"inputUID":engine?.inputUID ?? "","inputName":engine?.inputName ?? ""])
                }
                renderStatus(j);applyPanelPolicy(j)
            } catch {
                if error.localizedDescription=="meeting_ended" {
                    await finishEndedSession(id,generation:generation)
                } else if error.localizedDescription=="no_native_meeting" || error.localizedDescription=="meeting_changed" {
                    guard !id.isEmpty,!mirroring,sessionId==id else { return }
                    // These responses do not prove this recording was ended: the
                    // backend may have restarted or switched to another session.
                    // Keep local recording and unsent events until an explicit stop.
                    showTransportError(tr(en:"Meeting connection lost; local recording and pending events have not been delivered",zh:"会议连接中断；本机录音和待发送内容尚未送达"))
                } else if !api.owner.isEmpty,error.localizedDescription=="native_owner_unknown" {
                    do {
                        _ = try await api.request("owner-register",[:])
                        _ = try await api.request("owner-helper-ready",["pid":Int(ProcessInfo.processInfo.processIdentifier)])
                    } catch { showTransportError(error.localizedDescription) }
                } else { meter.level=0;compactMeter.level=0;capsuleMeter.level=0;showTransportError(error.localizedDescription) }
                // Unknown server state never ends local capture or claims a save receipt.
            }
        }
    }
    func drainEvents() async -> Bool {
        // Keep the session and its queued final text until the server acknowledges it.
        for _ in 0..<150 {
            // flushEvents marks sending synchronously, even for an empty queue.
            // Observe completion before scheduling the next transport task.
            if !sending && textQueue.isEmpty && audioQueue.isEmpty && pendingFrame==nil { return true }
            flushEvents()
            try? await Task.sleep(nanoseconds:100_000_000)
        }
        return false
    }
    var confirmationHandlers:[ConfirmationHandler]=[]
    func renderStatus(_ j:[String:Any]) {
        miniUnread.update(session:sessionId,content:miniContentFingerprints(j),viewed:viewMode == .expanded && panel.isVisible && !panelPolicySuppressed)
        capsuleUnread.isHidden = !miniUnread.unread
        let recent=j["recentTranscript"] as? [[String:Any]] ?? []
        recentTranscript=recent.map { row in
            let seconds=max(0,Int(row["t"] as? Double ?? 0))
            return String(format:"%02d:%02d  ",seconds/60,seconds%60)+(row["text"] as? String ?? "")
        }.joined(separator:"\n")
        if mirroring { mirrorSeconds=j["audioSeconds"] as? Double ?? 0;paused=j["phase"] as? String == "paused";let level=paused ? 0:(j["audioLevel"] as? Double ?? 0);meter.level=level;compactMeter.level=level;capsuleMeter.level=level }
        if error.isEmpty && !transportIssue { let phase=j["phase"] as? String ?? "listening";status.stringValue=phase=="thinking" ? tr(en:"Assessing new information…",zh:"正在判断这条信息…") : phase=="paused" ? tr(en:"Paused",zh:"已暂停") : phase=="model_unavailable" ? tr(en:"Insights unavailable; recording continues",zh:"提醒暂不可用，录音继续") : (mirroring ? tr(en:"Listening · Synced with main window",zh:"正在听 · 与大窗同步"):(cloudASR ? tr(en:"Listening · Configured ASR",zh:"正在听 · 已配置转写") : tr(en:"Listening · On device",zh:"正在听 · 本机转写"))) }
        let phaseNow=j["phase"] as? String ?? "";statusNotice = phaseNow=="model_unavailable"
        if let last=recent.last?["text"] as? String,!last.isEmpty { footerText.stringValue=last;footerText.toolTip=last }
        renderDiscussion((j["cards"] as? [String:Any])?["discussion"] as? [String:Any])
        if mirroring && error.isEmpty && !transportIssue && !paused,let gate=j["gate"] as? [String:Any],gate["degraded"] as? Bool == true { statusNotice=true;status.stringValue=gate["local"] as? Bool == true ? tr(en:"Listening · JEV unavailable; local selection",zh:"正在听 · JEV 不可用，改用本机筛选"):tr(en:"Listening · JEV selection paused",zh:"正在听 · JEV 筛选暂停") }
        refreshPresentation()
        let c=j["cards"] as? [String:Any] ?? [:]
        if historySession != sessionId { historySession=sessionId;expandedCards=[];cardScroll.contentView.scroll(to:.zero) }
        let top=cardScroll.contentView.bounds.origin.y
        let anchor=cards.arrangedSubviews.first { $0.frame.maxY>top }
        let anchorKey=anchor?.identifier;let offset=top-(anchor?.frame.minY ?? top)
        if deepSession != sessionId { deepSession=sessionId;deepJobs=[:] }
        var shownCards=c;shownCards.removeValue(forKey:"discussion")
        let displayed:[String:Any]=["cards":shownCards,"confirmation":j["confirmation"] ?? NSNull(),"deep":deepJobs]
        guard let data=try? JSONSerialization.data(withJSONObject:displayed),let key=String(data:data,encoding:.utf8),key != lastCards else { return };lastCards=key
        confirmationHandlers=[]
        for view in cards.arrangedSubviews { cards.removeArrangedSubview(view);view.removeFromSuperview() }
        var rows:[(String,[String:Any],Bool)]=[]
        if let confirmation=j["confirmation"] as? [String:Any],let cid=confirmation["id"] as? String {
            let question=NSTextField(wrappingLabelWithString:tr(en:"Your call · ",zh:"需要你确认 · ")+(confirmation["question"] as? String ?? ""));question.font = .systemFont(ofSize:13,weight:.medium);cards.addArrangedSubview(question)
            let statement=confirmation["statement"] as? String ?? ""
            let proposal=NSTextField(wrappingLabelWithString:statement);proposal.font = .systemFont(ofSize:12);proposal.textColor = .secondaryLabelColor;proposal.toolTip=statement;cards.addArrangedSubview(proposal)
            for label in [question,proposal] {
                label.translatesAutoresizingMaskIntoConstraints=false
                let bounds=(label.stringValue as NSString).boundingRect(with:NSSize(width:332,height:2000),options:[.usesLineFragmentOrigin,.usesFontLeading],attributes:[.font:label.font!])
                let height=ceil(bounds.height)+8
                label.widthAnchor.constraint(equalToConstant:332).isActive=true;label.heightAnchor.constraint(equalToConstant:height).isActive=true
            }
            let controls=NSStackView();controls.orientation = .horizontal;controls.spacing=8
            for (label,response) in [(tr(en:"Confirm",zh:"确认"),"confirm"),(tr(en:"Correct",zh:"纠正"),"correct"),(tr(en:"Later",zh:"稍后"),"later")] {
                let button=NSButton(title:label,target:nil,action:nil);button.bezelStyle = .rounded
                let handler=ConfirmationHandler { [weak self] in guard let self=self else { return };if response=="correct" { self.openMain();return };button.isEnabled=false;Task { @MainActor in do { let next=try await self.api.request("confirmation",["sessionId":self.sessionId,"confirmationId":cid,"response":response]);self.lastCards="";self.renderStatus(next) }catch{button.isEnabled=true;self.showError(error.localizedDescription)} } }
                button.target=handler;button.action=#selector(ConfirmationHandler.click);confirmationHandlers.append(handler);controls.addArrangedSubview(button)
            };cards.addArrangedSubview(controls)
        }
        if let s=c["suggestion"] as? [String:Any],s["text"] is String { rows.append((tr(en:"Suggestion",zh:"建议"),s,false)) }
        let findingLabel=tr(en:"Finding",zh:"发现")
        for insight in (c["insights"] as? [[String:Any]] ?? []) { if insight["text"] is String { rows.append((findingLabel,insight,false)) } }
        let currentRows=rows
        let history=c["history"] as? [[String:Any]] ?? []
        let currentByKey=Dictionary(currentRows.compactMap { row -> (String,(String,[String:Any],Bool))? in
            guard let key=row.1["key"] as? String,!key.isEmpty else { return nil };return (key,row)
        },uniquingKeysWith: { _,new in new })
        let suggestionLabel=tr(en:"Suggestion",zh:"建议")
        var seenKeys=Set<String>()
        rows=history.compactMap { item -> (String,[String:Any],Bool)? in
            let key=item["key"] as? String ?? ""
            if !key.isEmpty && !seenKeys.insert(key).inserted { return nil }
            if let current=currentByKey[key] { return current }
            let kind=item["kind"] as? String ?? "insight"
            return (kind=="suggestion" ? suggestionLabel:findingLabel,item,true)
        }
        // Preserve each existing row's position; only genuinely new rows append.
        rows += currentRows.filter { row in
            guard let key=row.1["key"] as? String,!key.isEmpty else { return true }
            return seenKeys.insert(key).inserted
        }
        let latestFinding=rows.lastIndex { $0.0==findingLabel }
        for (index,(label,item,_)) in rows.enumerated() {
            let text=item["text"] as? String ?? ""
            let b=MiniInsightButton(category:label,text:text,target:self,action:#selector(toggleCard(_:)));b.stableKey=item["key"] as? String ?? text;b.expanded=expandedCards.contains(b.stableKey);b.sourceLabel=item["sourceLabel"] as? String ?? "";b.readMore=tr(en:"Read more",zh:"展开全文");b.collapse=tr(en:"Collapse",zh:"收起");b.identifier=NSUserInterfaceItemIdentifier(b.stableKey);b.translatesAutoresizingMaskIntoConstraints=false
            b.time=cardTime(b.sourceLabel)
            if index==latestFinding && !sessionId.isEmpty { b.attachDeep(makeDeepButton(key:b.stableKey,text:text)) }
            cards.addArrangedSubview(b)
            let height=b.intrinsicContentSize.height
            b.widthAnchor.constraint(equalToConstant:332).isActive=true;b.heightAnchor.constraint(equalToConstant:height).isActive=true
        }
        cardCount=rows.count+(j["confirmation"] is [String:Any] ? 1:0)
        let contentHeight=ceil(cards.fittingSize.height)
        cards.setFrameSize(NSSize(width:332,height:contentHeight));cardScroll.isHidden=cardCount==0;refreshPresentation()
        cards.layoutSubtreeIfNeeded()
        if let key=anchorKey,let next=cards.arrangedSubviews.first(where:{$0.identifier==key}) { cardScroll.contentView.scroll(to:NSPoint(x:0,y:max(0,next.frame.minY+offset))) }
        else { cardScroll.contentView.scroll(to:NSPoint(x:0,y:top)) }
        cardScroll.reflectScrolledClipView(cardScroll.contentView)
    }
    // 同一场同一张卡只记一次；账本写失败不影响卡片。
    func reportCardExpand(_ sender:MiniInsightButton) {
        let id=sessionId,key=sender.stableKey
        guard !id.isEmpty,expandSignals.insert(id+"|"+key).inserted else { return }
        let kind=sender.category=="发现" ? "insight":"suggestion"
        Task { _=try? await api.request("card-signal",["sessionId":id,"cardId":key,"key":key,"action":"expand","kind":kind]) }
    }
    @objc func toggleCard(_ sender:MiniInsightButton) {
        if expandedCards.contains(sender.stableKey) { expandedCards.remove(sender.stableKey) }else{expandedCards.insert(sender.stableKey)}
        sender.expanded=expandedCards.contains(sender.stableKey)
        if sender.expanded { reportCardExpand(sender) }
        for c in sender.constraints where c.firstAttribute == .height { c.constant=sender.intrinsicContentSize.height }
        sender.invalidateIntrinsicContentSize();sender.needsDisplay=true;cards.layoutSubtreeIfNeeded();cards.setFrameSize(NSSize(width:332,height:ceil(cards.fittingSize.height)));refreshPresentation()
    }
    // Chapter = latest chapter title; "what is happening" = the rolling discussion summary.
    func renderDiscussion(_ d:[String:Any]?) {
        let chapters=d?["chapters"] as? [[String:Any]] ?? []
        let last=chapters.last
        let title=((last?["title"] as? String) ?? (d?["title"] as? String) ?? "").trimmingCharacters(in:.whitespacesAndNewlines)
        let gist=((d?["text"] as? String) ?? (last?["text"] as? String) ?? "").trimmingCharacters(in:.whitespacesAndNewlines)
        let chapterAt=(last?["t"] as? Double).map { clockText(Int($0),hours:false) } ?? ""
        chapterCaption.isHidden=true;chapterCaption.stringValue=""
        gistCaption.isHidden=true;gistCaption.stringValue=""
        if title.isEmpty { chapterLabel.stringValue="";chapterLabel.toolTip=nil }
        else { chapterLabel.attributedStringValue=miniTopicTitle(title,time:chapterAt);chapterLabel.toolTip=title }
        chapterBlock.isHidden=title.isEmpty || sessionId.isEmpty
        gistLabel.stringValue=gist;gistLabel.toolTip=gist;gistBlock.isHidden=gist.isEmpty || sessionId.isEmpty
    }
    func syncMiniRails() {
        let cardsShown = !cardScroll.isHidden && cardCount>0
        chapterRail.fade = !chapterBlock.isHidden && gistBlock.isHidden && !cardsShown
        gistRail.fade = !gistBlock.isHidden && !cardsShown
        let buttons=cards.arrangedSubviews.compactMap { $0 as? MiniInsightButton }
        for (i,button) in buttons.enumerated() { button.railFade = i==buttons.count-1;button.railStartsAtMark = i==0 }
    }
    // sourceLabel is "m:ss · speaker"; the card shows the time as mm:ss.
    func cardTime(_ source:String)->String {
        let head=source.components(separatedBy:" · ").first ?? ""
        let parts=head.split(separator:":").compactMap { Int($0) }
        guard parts.count==head.split(separator:":").count,(2...3).contains(parts.count) else { return "" }
        let seconds=parts.reduce(0) { $0*60+$1 };return clockText(seconds,hours:false)
    }
    // Deep research on one card (MINI-01): POST /native/research {sessionId, cardId, text} starts a real research job for
    // this card; the label follows the job receipt (accepted → running n/4 → done / failed) polled from /native/research-status.
    // The result is merged into the meeting report under 外部研究. Never changes the meeting's tier.
    func deepTitle(_ state:String)->String {
        if state=="accepted" { return tr(en:"Queued…",zh:"已受理…") }
        if state.hasPrefix("running:") { let n=state.dropFirst(8);return tr(en:"Researching \(n)/4",zh:"研究中 \(n)/4") }
        if state=="done" { return tr(en:"Added to report",zh:"已并进研报") }
        if state=="failed" { return tr(en:"Failed · Retry",zh:"研究失败 · 重试") }
        return tr(en:"Deep research",zh:"深度研究")
    }
    func makeDeepButton(key:String,text:String)->MiniActionButton {
        let state=deepJobs[key] ?? ""
        let b=MiniActionButton(title:deepTitle(state),link:true,target:self,action:#selector(deepResearchClicked(_:)));b.cardKey=key;b.cardText=text
        b.isEnabled=state.isEmpty || state=="failed"
        b.toolTip=tr(en:"Research this card and add the result to the meeting report",zh:"研究这张卡片，结果并进会议研报");return b
    }
    func setDeep(_ key:String,_ state:String,_ sender:MiniActionButton) {
        deepJobs[key]=state
        if sender.cardKey==key {
            sender.title=deepTitle(state);sender.isEnabled=state=="failed";sender.needsDisplay=true
            if let card=sender.superview as? MiniInsightButton {
                card.layoutDeep()
                for c in card.constraints where c.firstAttribute == .height { c.constant=card.intrinsicContentSize.height }
                card.invalidateIntrinsicContentSize();card.needsDisplay=true
            }
        }
    }
    @objc func deepResearchClicked(_ sender:MiniActionButton) {
        let key=sender.cardKey,text=sender.cardText,prior=deepJobs[key] ?? ""
        guard !sessionId.isEmpty,!key.isEmpty,!text.isEmpty,prior.isEmpty || prior=="failed" else { return }
        let id=sessionId;setDeep(key,"accepted",sender)
        Task { @MainActor in
            do {
                var r=try await api.request("research",["sessionId":id,"cardId":key,"text":text])
                for _ in 0..<450 {
                    guard sessionId==id else { return }
                    let state=r["state"] as? String ?? ""
                    if state=="done" { setDeep(key,"done",sender);return }
                    if state=="failed" { throw CaptureError.message(r["error"] as? String ?? tr(en:"Research failed",zh:"研究失败")) }
                    setDeep(key,state=="running" ? "running:\((r["step"] as? Int) ?? 1)":"accepted",sender)
                    try await Task.sleep(nanoseconds:2_000_000_000)
                    r=try await api.request("research-status",["sessionId":id,"cardId":key])
                }
                throw CaptureError.message(tr(en:"Research timed out",zh:"研究超时"))
            } catch { guard sessionId==id else { return };setDeep(key,"failed",sender);showError(error.localizedDescription) }
        }
    }
    @objc func pauseClicked() {
        guard engine?.closing != true else { return }
        guard !busy,!sessionId.isEmpty else { return };busy=true;refreshPresentation();let value = !paused
        Task { @MainActor in
            defer { busy=false;refreshPresentation() }
            if mirroring {
                do { _ = try await api.request("command",["sessionId":sessionId,"command":value ? "pause":"resume"]) }
                catch { showError(error.localizedDescription) };return
            }
            if !value && !audioQueue.isEmpty { guard await drainEvents() else { showError(tr(en:"Audio is retrying; resume shortly",zh:"音频还在重试，请稍后继续"));return } }
            await engine?.pause(value)
            // Local capture has acknowledged the state. Uploading its final
            // frames must not delay the visible pause/resume state.
            paused=value
            pauseButton.title=tr(en:paused ? "Resume":"Pause",zh:paused ? "继续":"暂停")
            refreshPresentation()
            if value {
                let saved=await drainEvents()
                if !saved { paused=true;pauseButton.title=tr(en:"Resume",zh:"继续");showError(tr(en:"Saving the last sentence; retry shortly",zh:"最后一句还在保存，请稍后重试"));return }
            }
            do {
                _ = try await api.request("pause",["sessionId":sessionId,"paused":value])
                paused=value;if !value { error="" };pauseButton.title=tr(en:paused ? "Resume":"Pause",zh:paused ? "继续":"暂停")
            } catch { if value { paused=true } else { await engine?.pause(true);paused=true };showError(error.localizedDescription) }
        }
    }
    func cleanupFailedStart() async -> Bool {
        let capture=engine,id=sessionId,generation=captureGeneration
        guard await capture?.stop() != false,engine === capture,sessionId==id,captureGeneration==generation else { return false }
        if !sessionId.isEmpty {
            // Begin may have recorded audio before attach/ready failed. Preserve
            // its final packets/text just as the ordinary End path does.
            guard await drainEvents(),engine === capture,sessionId==id,captureGeneration==generation else { return false }
            do { try await api.request("end",["sessionId":id]) } catch { return false }
            guard engine === capture,sessionId==id,captureGeneration==generation else { return false }
            sessionId="";engine=nil;hidePanel()
        }
        else if engine != nil { engine=nil;audioQueue=[];textQueue=[] }
        return true
    }
    func stopUnstartedCaptureForQuit() async -> Bool {
        guard let capture=engine else { return true };let generation=captureGeneration
        guard await capture.stop(),engine === capture,sessionId.isEmpty,captureGeneration==generation else { return false }
        engine=nil;return true
    }
    @objc func endClicked() {
        guard !busy,!sessionId.isEmpty else { return };busy=true;refreshPresentation();let id=sessionId,generation=captureGeneration
        Task { @MainActor in
            if mirroring {
                do { _ = try await api.request("command",["sessionId":id,"command":"stop"]) }
                catch { showError(error.localizedDescription) };busy=false;refreshPresentation();return
            }
            let stopped=await engine?.stop()
            guard sessionId==id,captureGeneration==generation else { return }
            guard stopped != false else {
                showError(tr(en:"Recording stop unconfirmed. Retry ending.",zh:"录音停止尚未确认，请重试结束"));busy=false;refreshPresentation();finishQuit(false);return
            }
            // Capture is already stopped even if delivery/save needs a retry.
            // Heartbeats must freeze the clock and must not offer a false Resume.
            paused=true;refreshPresentation()
            flushEvents()
            // Recognition emits its last local partial before the existing Session is finalized.
            let delivered=await drainEvents()
            guard sessionId==id,captureGeneration==generation else { return }
            if delivered {
                do { try await api.request("end",["sessionId":id]);sessionId="";engine=nil;audioQueue=[];textQueue=[];pendingFrame=nil;paused=false;error="";status.stringValue=tr(en:"Ended · Continue in Citeside",zh:"已结束 · 可回Citeside继续");startButton.isHidden=false;pauseButton.isHidden=true;endButton.isHidden=true;hidePanel();finishQuit(true) }
                catch { showError(tr(en:"Final save unconfirmed, retrying",zh:"收尾未确认，正在重试"));finishQuit(false) }
            } else {
                // PCM is already closed. Keep unacked spool files; do not report the live tail as delivered.
                do {
                    try await api.request("end",["sessionId":id,"liveTail":"unconfirmed"])
                    if sessionId==id && captureGeneration==generation {
                        sessionId="";engine=nil;audioQueue=[];textQueue=[];pendingFrame=nil;paused=false
                        error=tr(en:"Ended · Unconfirmed live tail remains on this Mac",zh:"已结束 · 未确认的实时尾段留在本机")
                        status.stringValue=error;startButton.isHidden=false;pauseButton.isHidden=true;endButton.isHidden=true;hidePanel();finishQuit(true)
                    }
                } catch { showError(tr(en:"Last sentence not delivered; audio saved locally, retrying",zh:"最后一句尚未送达，录音已留在本机；正在重试保存"));finishQuit(false) }
            }
            busy=false;refreshPresentation()
        }
    }
    @objc func openMain() { mainOpenPending=true;if viewMode != .hidden { policyResumeView=viewMode };concealPanel();if CommandLine.arguments.contains("--presentation-test") { return };openMainWindow(panel:"") }
    func openMainWindow(panel:String) { let id=sessionId.isEmpty ? lastSessionId:sessionId;Task { @MainActor in do { _ = try await api.request(api.owner.isEmpty ? "open-main":"owner-open-main",["sessionId":id,"panel":panel]);if panel.isEmpty && !id.isEmpty { self.unreadMainRequestSession=id;self.refreshPresentation() } }catch{mainOpenPending=false;presentationEnvironmentChanged();showError(tr(en:"Unable to open Citeside: ",zh:"无法打开Citeside：")+error.localizedDescription)} } }
    @objc func claimOwner(_ notification:Notification) {
        guard api.owner.isEmpty,sessionId.isEmpty,engine==nil,!busy,
              let token=notification.userInfo?["owner"] as? String,
              token.range(of:"^[a-f0-9]{64}$",options:.regularExpression) != nil,
              let endpoint=LocalAPI.handoffEndpoint(notification.userInfo?["server"] as? String ?? api.base.absoluteString,current:api.base) else { return }
        let previousAPI=api
        busy=true
        Task { @MainActor in
            defer { busy=false;refreshPresentation() }
            let candidate=LocalAPI(endpoint.absoluteString,owner:token)
            do {
                _ = try await candidate.request("owner-helper-ready",["pid":Int(ProcessInfo.processInfo.processIdentifier)])
                guard api === previousAPI,api.owner.isEmpty,sessionId.isEmpty,engine==nil else { return }
                api=candidate
            } catch { showError(tr(en:"Main window not confirmed. Please retry.",zh:"主窗口归属未确认，请重试")) }
        }
    }
    func finishQuit(_ saved:Bool) {
        guard terminateAfterSave else { return }
        terminateAfterSave=false
        Task { @MainActor in
            do {
                if saved {
                    if !api.owner.isEmpty {
                        _ = try await api.request("owner-quit",[:])
                        _ = try await api.request("owner-quit-ready",[:])
                    }
                    quitApproved=true;NSApp.terminate(nil)
                } else {
                    if !api.owner.isEmpty { _ = try? await api.request("owner-quit-failed",["error":tr(en:"Final save unconfirmed. Audio is kept on this Mac.",zh:"收尾未确认，录音保留在本机")]) }
                    quitInFlight=false
                }
            } catch {
                quitInFlight=false
                if !api.owner.isEmpty { _ = try? await api.request("owner-quit-failed",["error":tr(en:"Quit not confirmed. Please retry.",zh:"退出回执未确认，请重试")]) }
                showError(tr(en:"Quit not confirmed. Please try again shortly.",zh:"退出未确认，请稍后重试"))
            }
        }
    }
    func applicationShouldTerminate(_ sender:NSApplication)->NSApplication.TerminateReply {
        if quitApproved { return .terminateNow }
        if quitInFlight { return .terminateCancel }
        if !sessionId.isEmpty && !mirroring {
            guard !busy else { return .terminateCancel }
            quitInFlight=true;terminateAfterSave=true;endClicked();return .terminateCancel
        }
        // Return immediately so Swift concurrency can deliver the save receipt.
        // Re-enter termination only after the asynchronous handshake succeeds.
        if engine != nil {
            guard !busy else { return .terminateCancel }
            quitInFlight=true;terminateAfterSave=true;busy=true
            Task { @MainActor in
                let stopped=await stopUnstartedCaptureForQuit();busy=false
                if !stopped { showError(tr(en:"Recording stop unconfirmed; retry quitting.",zh:"录音停止尚未确认，请重试退出")) }
                refreshPresentation();finishQuit(stopped)
            }
            return .terminateCancel
        }
        if !api.owner.isEmpty { quitInFlight=true;terminateAfterSave=true;finishQuit(true);return .terminateCancel }
        return .terminateNow
    }
}
// Resolve symlinks before checking the directory boundary (program-old is not program).
func captureLaunchAllowed(_ executable: String, home: String, dev: String?) -> Bool {
    if dev == "1" { return true }
    let base=URL(fileURLWithPath:home).appendingPathComponent("Library/Application Support/Citeside/program").resolvingSymlinksInPath().standardizedFileURL.path
    let actual=URL(fileURLWithPath:executable).resolvingSymlinksInPath().standardizedFileURL.path
    return actual.hasPrefix(base + "/")
}
let argv=CommandLine.arguments
// Pure self-tests do not open a capture window. All interactive/probe modes obey the guard.
if !(argv.count == 2 && argv[1] == "--self-test") && !captureLaunchAllowed(Bundle.main.executablePath ?? argv[0], home:NSHomeDirectory(), dev:ProcessInfo.processInfo.environment["THT_DEV"]) {
    let alert=NSAlert()
    alert.messageText="Citeside启动已拦截"
    alert.informativeText="这份录音组件不在正式安装目录，已停止启动。请打开正式安装版；开发调试需显式设置 THT_DEV=1。"
    alert.runModal()
    exit(78)
}

func argument(_ key:String,_ fallback:String)->String { if let i=argv.firstIndex(of:key),i+1<argv.count { return argv[i+1] };return fallback }
// Synthetic pipeline verification: no device, permission prompt, server, or ASR.
// Exercise the actual SCK sample decoder, shared timeline, PCM file and packets.
if argv.contains("--audio-fixture-test") {
    do {
        let directory=URL(fileURLWithPath:argument("--output",NSTemporaryDirectory()+"livemate-fixture-"+UUID().uuidString))
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
        let path=directory.appendingPathComponent("synthetic-mix.pcm")
        guard !FileManager.default.fileExists(atPath:path.path) else { throw CaptureError.message("Fixture output already exists") }
        _=FileManager.default.createFile(atPath:path.path,contents:nil,attributes:[.posixPermissions:0o600])
        var packets=[Data]();var failures=[String]()
        let engine=CaptureEngine(pcm:{packets.append($0)},text:{_,_ in preconditionFailure("No ASR in fixture test")},frame:{_ in preconditionFailure("No screen in fixture test")},failure:{failures.append($0)})
        engine.file=try FileHandle(forWritingTo:path);engine.attached=true;engine.mixer=TimelineMixer(origin:100)
        func sample(_ values:[Float],at:Double,rate:Double=16000) throws -> CMSampleBuffer {
            var asbd=AudioStreamBasicDescription(mSampleRate:rate,mFormatID:kAudioFormatLinearPCM,mFormatFlags:kAudioFormatFlagIsFloat|kAudioFormatFlagIsPacked,mBytesPerPacket:4,mFramesPerPacket:1,mBytesPerFrame:4,mChannelsPerFrame:1,mBitsPerChannel:32,mReserved:0)
            var description:CMAudioFormatDescription?
            guard CMAudioFormatDescriptionCreate(allocator:kCFAllocatorDefault,asbd:&asbd,layoutSize:0,layout:nil,magicCookieSize:0,magicCookie:nil,extensions:nil,formatDescriptionOut:&description)==noErr,let description=description else { throw CaptureError.message("Fixture format failed") }
            var block:CMBlockBuffer?
            let data=values.withUnsafeBytes{Data($0)}
            guard CMBlockBufferCreateWithMemoryBlock(allocator:kCFAllocatorDefault,memoryBlock:nil,blockLength:data.count,blockAllocator:kCFAllocatorDefault,customBlockSource:nil,offsetToData:0,dataLength:data.count,flags:0,blockBufferOut:&block)==noErr,let block=block else { throw CaptureError.message("Fixture allocation failed") }
            let code=data.withUnsafeBytes{CMBlockBufferReplaceDataBytes(with:$0.baseAddress!,blockBuffer:block,offsetIntoDestination:0,dataLength:data.count)}
            guard code==noErr else { throw CaptureError.message("Fixture copy failed") }
            var buffer:CMSampleBuffer?
            guard CMAudioSampleBufferCreateReadyWithPacketDescriptions(allocator:kCFAllocatorDefault,dataBuffer:block,formatDescription:description,sampleCount:values.count,presentationTimeStamp:CMTime(seconds:at,preferredTimescale:16000),packetDescriptions:nil,sampleBufferOut:&buffer)==noErr,let buffer=buffer else { throw CaptureError.message("Fixture sample failed") }
            return buffer
        }
        let blocks=53 // 1.06s includes a partial final transport packet.
        var expected=[Float]()
        for block in 0..<blocks {
            var system=[Float](),microphone=[Float]()
            for offset in 0..<320 {
                let phase:Double=Double(block*320+offset)*2.0*Double.pi/16000.0
                system.append(Float(sin(phase*440.0))*Float(0.25))
                microphone.append(Float(sin(phase*880.0))*Float(0.125))
            }
            let timestamp=100+Double(block)*0.02
            engine.acceptSystemAudio(try sample(system,at:timestamp))
            engine.mixer.add(microphone,at:timestamp)
            expected += zip(system,microphone).map { $0.0 + $0.1 }
        }
        engine.flushMix(final:true)
        try engine.file?.synchronize();try engine.file?.close();engine.file=nil
        let data=try Data(contentsOf:path)
        precondition(failures.isEmpty && data.count==blocks*320*2,"No lost frames or doubled duration")
        precondition(packets.reduce(Data(),+)==data,"Transport packets must match saved PCM, including final tail")
        let decoded=data.withUnsafeBytes{Array($0.bindMemory(to:Int16.self))}
        precondition(zip(decoded,expected).allSatisfy{abs(Int($0.0)-Int($0.1*32767))<=1},"Simultaneous sources must mix at the same host timestamp")
        do { _=try engine.systemSamples(sample([0,0],at:100,rate:48000));preconditionFailure("Unexpected format accepted") }
        catch { /* The configured system stream must deliver 16k mono. */ }
        let result:[String:Any]=["result":"passed","syntheticOnly":true,"deviceCapture":false,"networkRequests":0,"frames":decoded.count,"seconds":Double(decoded.count)/16000,"bytes":data.count,"packets":packets.count,"systemFrames":engine.systemFrames,"systemPeak":engine.systemPeak,"checks":["CMSampleBuffer float32 decoding","system + microphone timeline overlap","PCM16LE file equals transport","final partial packet","invalid sample rate rejected"]]
        try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]).write(to:directory.appendingPathComponent("verification.json"))
        print(String(data:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),encoding:.utf8)!);exit(0)
    } catch { fputs("Audio fixture failed: \(error.localizedDescription)\n",stderr);exit(1) }
}

if argv.contains("--diagnostics") {
    let mic=AVCaptureDevice.authorizationStatus(for:.audio),speech=SFSpeechRecognizer.authorizationStatus()
    let micName:String
    switch mic { case .authorized:micName="authorized";case .denied:micName="denied";case .restricted:micName="restricted";case .notDetermined:micName="notDetermined";@unknown default:micName="unknown" }
    let speechName:String
    switch speech { case .authorized:speechName="authorized";case .denied:speechName="denied";case .restricted:speechName="restricted";case .notDetermined:speechName="notDetermined";@unknown default:speechName="unknown" }
    let result:[String:Any] = ["screenAudioAuthorized":CGPreflightScreenCaptureAccess(),"microphoneAuthorization":mic.rawValue,"speechAuthorization":speech.rawValue,"microphoneStatus":micName,"speechStatus":speechName,"note":"Run outside the execution sandbox; preflight does not prove audio delivery."]
    if let json=try? JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),let text=String(data:json,encoding:.utf8) { print(text) };exit(0)
}
// Opt-in hardware probe. Capture ONLY this app's generated tone, never global
// output, microphone, video, or a real meeting. Any system permission prompt
// is left for the user; CoreGraphics preflight never substitutes for actual SCK.
if argv.contains("--system-audio-test") {
    let testApp=NSApplication.shared;testApp.setActivationPolicy(.accessory)
    Task { @MainActor in
        var stream:SCStream?
        do {
            // SCK is authoritative; CoreGraphics preflight can be false for an existing SCK grant.
            // A real system authorization prompt remains under user control.
            let directory=URL(fileURLWithPath:argument("--output",NSTemporaryDirectory()+"livemate-system-test-"+UUID().uuidString))
            try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
            let testWindow=NSWindow(contentRect:NSRect(x:200,y:200,width:380,height:100),styleMask:[.titled],backing:.buffered,defer:false)
            testWindow.title="Citeside · 合成系统音频测试"
            let label=NSTextField(labelWithString:"播放 440 Hz 测试音 · 3 秒后停止\n只采集本测试程序，不采集麦克风")
            label.frame=NSRect(x:20,y:25,width:340,height:50);testWindow.contentView?.addSubview(label)
            testWindow.orderFrontRegardless()
            defer { testWindow.orderOut(nil) }
            try await Task.sleep(nanoseconds:500_000_000)
            let content=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
            guard let display=content.displays.first,let own=content.applications.first(where:{$0.processID==ProcessInfo.processInfo.processIdentifier}) else { throw CaptureError.message("Cannot isolate this test application; capture refused") }
            let path=directory.appendingPathComponent("self-tone-only.pcm")
            guard !FileManager.default.fileExists(atPath:path.path) else { throw CaptureError.message("Test output exists") }
            _=FileManager.default.createFile(atPath:path.path,contents:nil,attributes:[.posixPermissions:0o600])
            var errors=[String]()
            let engine=CaptureEngine(pcm:{_ in},text:{_,_ in},frame:{_ in preconditionFailure("No screen output allowed")},failure:{errors.append($0)})
            engine.file=try FileHandle(forWritingTo:path);engine.mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime)
            let config=SCStreamConfiguration();config.capturesAudio=true;config.sampleRate=16000;config.channelCount=1;config.excludesCurrentProcessAudio=false;config.width=32;config.height=32;config.minimumFrameInterval=CMTime(value:1,timescale:1)
            let capture=SCStream(filter:SCContentFilter(display:display,including:[own],exceptingWindows:[]),configuration:config,delegate:engine)
            stream=capture;try capture.addStreamOutput(engine,type:.audio,sampleHandlerQueue:engine.queue)
            try await capture.startCapture()
            var wav=Data()
            func word<T:FixedWidthInteger>(_ value:T) { var v=value.littleEndian;withUnsafeBytes(of:&v){wav.append(contentsOf:$0)} }
            let count=32000
            wav.append(contentsOf:Array("RIFF".utf8));word(UInt32(36+count*2));wav.append(contentsOf:Array("WAVEfmt ".utf8));word(UInt32(16));word(UInt16(1));word(UInt16(1));word(UInt32(16000));word(UInt32(32000));word(UInt16(2));word(UInt16(16));wav.append(contentsOf:Array("data".utf8));word(UInt32(count*2))
            for index in 0..<count { let phase=Double(index)*2.0*Double.pi*440.0/16000.0;word(Int16(sin(phase)*8000.0)) }
            let player=try AVAudioPlayer(data:wav,fileTypeHint:AVFileType.wav.rawValue)
            player.volume=0.3;player.prepareToPlay()
            guard player.play() else { throw CaptureError.message("Synthetic tone playback failed") }
            try await Task.sleep(nanoseconds:3_000_000_000)
            player.stop();try await capture.stopCapture();stream=nil
            engine.queue.sync { engine.flushMix(final:true);try? engine.file?.synchronize();try? engine.file?.close();engine.file=nil }
            let data=try Data(contentsOf:path),samples=data.withUnsafeBytes{Array($0.bindMemory(to:Int16.self))}
            let power=samples.reduce(0.0){$0+pow(Double($1)/32768.0,2)}
            let rms=sqrt(power/Double(max(1,samples.count)))
            let evidence=engine.audioEvidence()
            guard errors.isEmpty,engine.systemFrames>16000,engine.systemPeak>0.005,rms>0.001 else { throw CaptureError.message("No non-silent system tone received; device validation failed") }
            let result:[String:Any]=["result":"passed","bundlePath":Bundle.main.bundlePath,"bundleIdentifier":Bundle.main.bundleIdentifier ?? "","pid":Int(ProcessInfo.processInfo.processIdentifier),"coreGraphicsPreflight":CGPreflightScreenCaptureAccess(),"captureScope":"this app only","testToneHz":440,"microphoneCaptured":false,"screenFramesCaptured":false,"externalRequests":0,"bytes":data.count,"rms":rms,"evidence":evidence]
            try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys,.prettyPrinted]).write(to:directory.appendingPathComponent("system-verification.json"))
            print(String(data:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),encoding:.utf8)!);exit(0)
        } catch {
            try? await stream?.stopCapture()
            let result:[String:Any]=["result":"blocked","error":error.localizedDescription,"bundlePath":Bundle.main.bundlePath,"bundleIdentifier":Bundle.main.bundleIdentifier ?? "","pid":Int(ProcessInfo.processInfo.processIdentifier),"coreGraphicsPreflight":CGPreflightScreenCaptureAccess(),"microphoneCaptured":false]
            if let directory=argv.firstIndex(of:"--output"),directory+1<argv.count { try? JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:argv[directory+1]).appendingPathComponent("system-verification.json")) }
            fputs("System audio test blocked: \(error.localizedDescription)\n",stderr);exit(78)
        }
    }
    testApp.run();exit(0)
}

if argv.contains("--self-test") {
    do {
        let handoff=AppDelegate(server:"http://127.0.0.1:47823",locale:"zh-CN",english:false,autoStart:false)
    // A launcher must never redirect or quit a locally active/busy recorder.
    let originalAPI=handoff.api
    let claim=Notification(name:Notification.Name("LiveMateCaptureOwner"),userInfo:["owner":String(repeating:"a",count:64),"server":originalAPI.base.absoluteString])
    handoff.sessionId="active-handoff-fixture";handoff.claimOwner(claim)
    precondition(handoff.api === originalAPI && handoff.sessionId=="active-handoff-fixture" && !handoff.busy && !handoff.quitApproved)
    handoff.sessionId="";handoff.busy=true;handoff.claimOwner(claim)
    precondition(handoff.api === originalAPI && handoff.busy && !handoff.quitApproved)
    handoff.busy=false
    for rejected in ["http://127.0.0.1:1","http://192.0.2.1:\(originalAPI.base.port!)"] {
        handoff.claimOwner(Notification(name:claim.name,userInfo:["owner":String(repeating:"a",count:64),"server":rejected]))
        precondition(handoff.api === originalAPI && !handoff.busy && handoff.api.owner.isEmpty)
    }
        let idleEngine=CaptureEngine(pcm:{_ in preconditionFailure("Handoff fixture cannot capture")},text:{_,_ in},frame:{_ in},failure:{_ in})
        handoff.engine=idleEngine;handoff.claimOwner(claim)
        precondition(handoff.api === originalAPI && !handoff.busy && !idleEngine.closing && !handoff.quitApproved)
        handoff.engine=nil
        print("OWNER_HANDOFF_GUARDS_PASS active/busy/engine unchanged; wrong-port/nonloopback rejected; capture=false")

        let current=URL(string:"http://127.0.0.1:47823")!
        precondition(LocalAPI.handoffEndpoint("http://[::1]:47823",current:current)?.port == 47823)
        precondition(LocalAPI.handoffEndpoint("http://127.0.0.1:47823",current:current) == current)
        for rejected in ["http://[::1]:47824","http://192.0.2.1:47823","https://127.0.0.1:47823","http://user@127.0.0.1:47823","http://127.0.0.1:47823/path","http://127.0.0.1:47823?x=1","http://127.0.0.1:47823#x"] {
            precondition(LocalAPI.handoffEndpoint(rejected,current:current) == nil,"Handoff cannot change service or route outside loopback")
        }
        var gate=CaptureRetryGate(),recoveries=0
        let request:[String:Any]=["sessionId":"synthetic-session","requestId":"synthetic-request"]
        precondition(gate.handle(request,sessionId:"other",command:"",paused:false,ready:true) { recoveries+=1 } == nil)
        for command in ["stop","pause","resume"] { precondition(gate.handle(request,sessionId:"synthetic-session",command:command,paused:false,ready:true) { recoveries+=1 } == nil) }
        precondition(gate.handle(request,sessionId:"synthetic-session",command:"",paused:true,ready:true) { recoveries+=1 } == nil)
        precondition(recoveries == 0 && gate.acknowledged.isEmpty)
        precondition(gate.handle(request,sessionId:"synthetic-session",command:"",paused:false,ready:true) { recoveries+=1 } == true)
        precondition(gate.handle(request,sessionId:"synthetic-session",command:"",paused:false,ready:true) { recoveries+=1 } == nil)
        precondition(recoveries == 1 && gate.acknowledged == "synthetic-request")
        var unready=CaptureRetryGate()
        precondition(unready.handle(request,sessionId:"synthetic-session",command:"",paused:false,ready:false) { recoveries+=1 } == false)
        precondition(recoveries == 1)
        print("capture-retry gate: session isolation, duplicate/control priority and unready rejection passed; no capture opened")
        var retry=StreamRecoveryPlan(started:100)
        precondition([retry.delay(100),retry.delay(101),retry.delay(103),retry.delay(107)] == [1,2,4,8])
        precondition(!retry.expired(159.9) && retry.expired(160))
        precondition(retry.delay(159)==1 && retry.delay(160)==0)
        func visible(_ e:[MenuEntry])->[String] { e.filter { !$0.hidden }.map { $0.title } }
        // PRD 2h: unused items are hidden, never greyed; separators are hidden with the block they close.
        let idle=menuBarEntries(english:true,active:false,paused:false,busy:false,miniVisible:false,elapsed:0)
        precondition(visible(idle)==["Start Listening","Open Citeside","","Quit Citeside"],"idle menu: start / open / — / quit")
        let live=menuBarEntries(english:true,active:true,paused:false,busy:false,miniVisible:true,elapsed:754)
        precondition(visible(live)==["Listening 12:34","Hide Mini Window","Pause Listening","End Meeting","","Open Citeside","","Quit Citeside"])
        precondition(live.first { $0.key=="status" }?.enabled == false,"status line is not clickable")
        let paused=menuBarEntries(english:false,active:true,paused:true,busy:true,miniVisible:false,elapsed:3725)
        precondition(visible(paused)==["已暂停 1:02:05","显示小窗","继续听会","结束会议","","打开Citeside","","退出Citeside"])
        precondition(paused.filter { ["pause","end"].contains($0.key) }.allSatisfy { !$0.enabled },"pause and end wait while a command is in flight")
        precondition(visible(menuBarEntries(english:false,active:false,paused:false,busy:false,miniVisible:true,elapsed:0))==["开始听会","打开Citeside","","退出Citeside"])
        let connecting=menuBarEntries(english:false,active:false,paused:false,busy:true,miniVisible:false,elapsed:0)
        precondition(visible(connecting)==["打开Citeside","","退出Citeside"] && connecting.filter { !$0.hidden && !$0.key.hasPrefix("sep-") }.allSatisfy { $0.enabled },"idle while connecting hides Start instead of greying it")
        precondition(menuBarToolTip(english:false,active:false,paused:false,detail:"")=="Citeside · 没在听会")
        precondition(menuBarToolTip(english:false,active:true,paused:false,detail:"")=="Citeside · 听会中 · 隐藏小窗不会停止听会","empty detail still names the state")
        precondition(menuBarToolTip(english:true,active:true,paused:true,detail:"")=="Citeside · Paused · Hiding the mini window keeps listening")
        precondition(menuBarToolTip(english:false,active:true,paused:false,detail:"听会中")=="Citeside · 听会中 · 隐藏小窗不会停止听会")
        precondition(menuBarImage(badge:"").isTemplate && menuBarImage(badge:"paused").isTemplate && menuBarImage(badge:"listening").isTemplate,"microphone remains template in every state; recording dot is a separate overlay")
        print("MENUBAR_MODEL_PASS states=5")
    }
    precondition(recognizedMeeting(bundle:"us.zoom.xos",title:"Zoom Meeting"))
    precondition(recognizedMeeting(bundle:"company.thebrowser.Browser",title:"Meet - abc-defg-hij"))
    precondition(meetingInputApp(bundle:"com.tencent.meeting") && meetingInputApp(bundle:"com.alibaba.DingTalkMac") && meetingInputApp(bundle:"company.thebrowser.Browser"))
    precondition(!meetingInputApp(bundle:"com.apple.VoiceMemos") && !meetingInputApp(bundle:"com.apple.Music"))
    precondition(recognizedMeeting(bundle:"com.microsoft.teams2",title:"Design review | Meeting"))
    precondition(recognizedMeeting(bundle:"com.microsoft.teams2",title:"Call with Alex"))
    precondition(recognizedMeeting(bundle:"com.microsoft.teams2",title:"设计评审 | 会议"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Recall project | Chat"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Callback discussion | Chat"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Meetingnotes | Chat"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Calendar | Microsoft Teams"))
    // Chat, channel and section windows whose names contain "call" / "meeting" words.
    for chat in ["Sales call prep | Chat","Meeting prep | Chat | Microsoft Teams","Chat | Weekly call | Microsoft Teams","Call center | Teams and channels | Microsoft Teams","Meeting recap | Activity | Microsoft Teams","周会 会议纪要 | 聊天"] { precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:chat), chat) }
    precondition(recognizedMeeting(bundle:"com.microsoft.teams2",title:"Meeting in \"General\" | Microsoft Teams"))
    precondition(recognizedMeeting(bundle:"com.tencent.meeting",title:"产品周会 - 腾讯会议") && recognizedMeeting(bundle:"com.tencent.meeting",title:"会议号 123 456 789") && recognizedMeeting(bundle:"com.tencent.meeting",title:"Weekly sync | Tencent Meeting"))
    precondition(!recognizedMeeting(bundle:"com.tencent.meeting",title:"腾讯会议") && !recognizedMeeting(bundle:"com.tencent.meeting",title:"Tencent Meeting") && !recognizedMeeting(bundle:"com.tencent.meeting",title:"历史会议"))
    precondition(recognizedMeeting(bundle:"com.alibaba.DingTalkMac",title:"钉钉会议") && recognizedMeeting(bundle:"com.alibaba.DingTalkMac",title:"视频会议 - 产品评审") && recognizedMeeting(bundle:"com.alibaba.DingTalkMac",title:"DingTalk Meeting"))
    precondition(!recognizedMeeting(bundle:"com.alibaba.DingTalkMac",title:"钉钉") && !recognizedMeeting(bundle:"com.alibaba.DingTalkMac",title:"DingTalk") && !recognizedMeeting(bundle:"com.alibaba.DingTalkMac",title:"项目群"))
    precondition(recognizedMeeting(bundle:"com.bytedance.Lark",title:"视频会议"))
    precondition(!recognizedMeeting(bundle:"com.bytedance.Lark",title:"Messages"))
    var mix=TimelineMixer(origin:100)
    mix.add([Float](repeating:0.25,count:320),at:100);mix.add([Float](repeating:0.5,count:320),at:100)
    let simultaneous=mix.drain(to:100.23)
    precondition(simultaneous.count==1 && simultaneous[0].count==320 && simultaneous[0].allSatisfy{$0==0.75},"Two simultaneous sources must occupy the same 20ms, not 40ms")
    mix.add([Float](repeating:1,count:320),at:100);precondition(mix.blocks.isEmpty,"Late buffers must not rewrite saved audio")
    mix.add([Float](repeating:2,count:320),at:100.02);let final=mix.drain(to:100.25,final:true);precondition(final.count==1 && final[0].allSatisfy{$0==1})
    let screen=NSRect(x:0,y:0,width:1440,height:900),old=NSRect(x:1112,y:500,width:310,height:280)
    let compact=miniFrame(old,size:NSSize(width:246,height:66),screens:[screen])
    precondition(compact.maxX==old.maxX && compact.maxY==old.maxY)
    let restored=miniFrame(compact,size:NSSize(width:310,height:480),screens:[screen])
    precondition(restored.maxX==old.maxX && restored.maxY==old.maxY)
    let removedDisplay=miniFrame(NSRect(x:3000,y:1400,width:310,height:480),size:NSSize(width:246,height:66),screens:[screen])
    precondition(screen.contains(removedDisplay))
    let negativeDisplay=NSRect(x:-1600,y:0,width:1600,height:1000)
    precondition(negativeDisplay.contains(miniFrame(NSRect(x:-350,y:600,width:310,height:200),size:NSSize(width:246,height:66),screens:[screen,negativeDisplay])))
    var g=PageGate();let a=[UInt8](repeating:80,count:2304),b=[UInt8](repeating:200,count:2304)
    precondition(!g.accepts(a,now:0));precondition(!g.accepts(a,now:0.34));precondition(g.accepts(a,now:0.68));precondition(!g.accepts(a,now:9))
    var cursor=a;for i in 0..<40 { cursor[i]=255 };precondition(!g.accepts(cursor,now:10))
    precondition(!g.accepts(b,now:11));precondition(!g.accepts(b,now:11.34));precondition(g.accepts(b,now:11.68))
    precondition(recognizedMeeting(bundle:"com.bytedance.Feishu",title:"飞书会议"));precondition(!recognizedMeeting(bundle:"com.bytedance.Feishu",title:"飞书文档"));precondition(recognizedMeeting(bundle:"com.google.Chrome",title:"Meet - abc-defg-hij"));precondition(!recognizedMeeting(bundle:"com.google.Chrome",title:"Bank account"))
    var early=PrerollBuffer(limit:6);early.append(Data([1,2,3,4]));early.append(Data([5,6,7,8]))
    precondition(early.data==Data([3,4,5,6,7,8]) && early.dropped==2,"Preroll keeps the newest audio within its cap");precondition(early.take()==Data([3,4,5,6,7,8]) && early.data.isEmpty)
    var speechDelta=SpeechDelta()
    precondition(speechDelta.take("hello",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5))])=="hello")
    precondition(speechDelta.take("hello",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5))])==nil)
    precondition(speechDelta.take("Hallo world",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5)),SpeechPiece(start:1.1,end:2,range:NSRange(location:6,length:5))])=="world")
    print("native_self_test_passed");exit(0)
}
if argv.contains("--permission-self-test") {
    Task {
        let denied=NSError(domain:SCStreamErrorDomain,code:SCStreamError.Code.userDeclined.rawValue)
        let unrelated=NSError(domain:"permission-test",code:-99999)
        var loads=0,requests=0
        do {
            let value:Int=try await authorizedScreenContent(load:{ loads+=1;return 7 },request:{requests+=1;return false})
            precondition(value==7 && loads==1 && requests==0,"Working SCK access must not request permission again")
            loads=0;requests=0
            let recovered:Int=try await authorizedScreenContent(load:{ loads+=1;if loads==1 { throw denied };return 8 },request:{requests+=1;return false})
            precondition(recovered==8 && loads==2 && requests==1,"SCK recovery wins over false CG result")
            for cgResult in [false,true] {
                loads=0;requests=0
                do {
                    let _:Int=try await authorizedScreenContent(load:{loads+=1;throw denied},request:{requests+=1;return cgResult})
                    preconditionFailure("Denied SCK must never start recording")
                } catch CapturePermission.screen { precondition(loads==2 && requests==1) }
            }
            loads=0;requests=0
            do {
                let _:Int=try await authorizedScreenContent(load:{loads+=1;throw unrelated},request:{requests+=1;return true})
                preconditionFailure("Non-permission failure must propagate")
            } catch { precondition((error as NSError).code == -99999 && loads==1 && requests==0) }
            loads=0;requests=0
            let sameCodeOtherDomain=NSError(domain:"other-framework",code:SCStreamError.Code.userDeclined.rawValue)
            do {
                let _:Int=try await authorizedScreenContent(load:{loads+=1;throw sameCodeOtherDomain},request:{requests+=1;return true})
                preconditionFailure("An unrelated framework error cannot become a permission request")
            } catch { precondition((error as NSError).domain == "other-framework" && loads==1 && requests==0) }
            let clock=Date(timeIntervalSince1970:100)
            var permissionReport=ScreenPermissionReport()
            precondition(permissionReport.status(preflight:false,now:clock)=="unknown")
            permissionReport.verified("authorized",now:clock)
            precondition(permissionReport.status(preflight:false,now:clock.addingTimeInterval(14))=="unknown","Metadata success cannot prove screenshot access")
            precondition(permissionReport.status(preflight:false,now:clock.addingTimeInterval(15))=="unknown","Expired evidence cannot prove a grant or denial")
            precondition(permissionReport.status(preflight:true,now:clock.addingTimeInterval(15))=="authorized")
            permissionReport.verified("denied",now:clock)
            precondition(permissionReport.status(preflight:true,now:clock)=="authorized","Live preflight reflects changed system permission")
            loads=0
            let verifiedGrant=await screenPermissionMetadata { loads+=1 }
            precondition(verifiedGrant=="unknown" && loads==1)
            let verifiedDenial=await screenPermissionMetadata { throw denied }
            precondition(verifiedDenial=="denied")
            let verifiedError=await screenPermissionMetadata { throw unrelated }
            precondition(verifiedError=="unknown")
            precondition(CapturePermission.screen.settingsURL.absoluteString.hasSuffix("Privacy_ScreenCapture"))
            precondition(CapturePermission.microphone.settingsURL.absoluteString.hasSuffix("Privacy_Microphone"))
            precondition(CapturePermission.speech.settingsURL.absoluteString.hasSuffix("Privacy_SpeechRecognition"))
            await MainActor.run {
                _ = NSApplication.shared
                let recovery=AppDelegate(server:"http://127.0.0.1:47823",locale:"zh-CN",english:false,autoStart:false)
                recovery.permissionSettingsButton=NSButton();recovery.permissionSettingsButton.isHidden=true
                let wasActive=NSApp.isActive
                for permission:CapturePermission in [.screen,.microphone,.speech] {
                    recovery.showPermissionRecovery(permission)
                    precondition(recovery.recoveryPermission==permission && !recovery.permissionSettingsButton.isHidden)
                    precondition(NSApp.modalWindow==nil && NSApp.isActive==wasActive,"Permission recovery must not obstruct macOS consent or steal focus")
                    precondition(recovery.sessionId.isEmpty && recovery.engine==nil,"Recovery must not start capture")
                }
            }
            print("native_permission_self_test_passed: authorized, recovered, denied, unrelated-error, nonmodal-recovery; no capture or settings opened")
            exit(0)
        } catch { fputs("permission self-test failed: \(error)\n",stderr);exit(1) }
    }
    dispatchMain()
}
if argv.contains("--probe") {
    let r=SFSpeechRecognizer(locale:Locale(identifier:argument("--locale","zh-CN")))
    let j:[String:Any]=["screenPermission":CGPreflightScreenCaptureAccess(),"speechPermission":SFSpeechRecognizer.authorizationStatus().rawValue,"microphonePermission":AVCaptureDevice.authorizationStatus(for:.audio).rawValue,"onDevice":r?.supportsOnDeviceRecognition ?? false]
    print(String(data:try! JSONSerialization.data(withJSONObject:j),encoding:.utf8)!);exit(0)
}
// LaunchServices must not redirect a different installation/test port to the
// already running helper. A per-endpoint lock keeps repeated -n launches from
// creating a second recorder; the owner consumes the server's queued command.
let endpoint=argument("--server","http://127.0.0.1:47823")
let endpointPort=URL(string:endpoint)?.port ?? 47823
let instanceLock=CommandLine.arguments.contains("--presentation-test") ? -1 : Darwin.open((NSTemporaryDirectory()+"livemate-capture-\(getuid())-\(endpointPort).lock"),O_CREAT|O_RDWR|O_NOFOLLOW,0o600)
if !CommandLine.arguments.contains("--presentation-test") {
    guard instanceLock >= 0 else { fputs("Unable to establish capture instance lock\n",stderr);exit(1) }
    if flock(instanceLock,LOCK_EX|LOCK_NB) != 0 {
        let owner=argument("--owner","")
        if owner.range(of:"^[a-f0-9]{64}$",options:.regularExpression) != nil {
            // An idle watcher adopts only after the server validates this owner.
            // Active helpers keep their current ownership; no process is killed.
            DistributedNotificationCenter.default().postNotificationName(Notification.Name("LiveMateCaptureOwner"),object:String(endpointPort),userInfo:["owner":owner,"server":endpoint],deliverImmediately:true)
        }
        exit(0)
    }
}
let app=NSApplication.shared
let delegate=AppDelegate(server:argument("--server","http://127.0.0.1:47823"),locale:argument("--locale","zh-CN"),english:argument("--ui-lang",(Locale.preferredLanguages.first ?? "en").lowercased().hasPrefix("zh") ? "zh":"en")=="en",autoStart:argv.contains("--start"),owner:argument("--owner",""))
if argv.contains("--presentation-test") {
    if argv.contains("--continuity-bridge") {
        precondition(!argv.contains("--start") && argument("--owner","").isEmpty,"Fixture cannot start capture or bind a production owner")
    }
    // Exercise actual AppKit sizing and visibility without starting capture or
    // touching meeting data. Pure rectangle tests cannot detect fitting-size bugs.
    delegate.applicationDidFinishLaunching(Notification(name:NSApplication.didFinishLaunchingNotification))
    delegate.tick?.invalidate()
    if argv.contains("--amber-only") {
        precondition(argument("--server","")=="http://127.0.0.1:9" && !argv.contains("--start") && delegate.api.owner.isEmpty,"Amber screenshots are isolated and never capture audio")
        delegate.watchEnabled=false
        NSApp.appearance=NSAppearance(named:.aqua)
        let base=argument("--snapshot-dir","")
        precondition(!base.isEmpty,"Screenshot directory is required")
        func capture(_ view:NSView,_ name:String) {
            view.layoutSubtreeIfNeeded();view.displayIfNeeded()
            guard let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) else { preconditionFailure("Snapshot bitmap unavailable") }
            view.cacheDisplay(in:view.bounds,to:bitmap)
            try! bitmap.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:base+"/amber-"+name+".png"))
        }
        func capturePanel(_ name:String) {
            delegate.panel.orderFrontRegardless()
            RunLoop.current.run(until:Date().addingTimeInterval(0.3))
            capture(delegate.panel.contentView!,name)
            let shot=Process();shot.executableURL=URL(fileURLWithPath:"/usr/sbin/screencapture")
            shot.arguments=["-x","-o","-l\(delegate.panel.windowNumber)",base+"/amber-"+name+"-window.png"]
            try? shot.run();shot.waitUntilExit()
        }
        delegate.sessionId="presentation-only";delegate.mirroring=true;delegate.mirrorSeconds=72
        delegate.renderStatus(["phase":"listening","audioSeconds":72.0,"audioLevel":0.55])
        delegate.showPanel();delegate.expandFromCapsule()
        precondition(delegate.menuRecordingBadge.state=="listening" && delegate.statusItem.button!.image!.isTemplate)
        capture(delegate.statusItem.button!,"menubar")
        capturePanel("mini")
        delegate.collapseToCapsule();capturePanel("capsule")
        delegate.paused=true;delegate.refreshPresentation()
        precondition(delegate.menuRecordingBadge.state=="paused" && delegate.capsuleDot.state=="paused" && delegate.statusItem.button!.image!.isTemplate)
        capture(delegate.statusItem.button!,"menubar-paused");capturePanel("capsule-paused")
        delegate.paused=false;delegate.panel.appearance=NSAppearance(named:.darkAqua);delegate.refreshPresentation();capturePanel("capsule-dark")
        delegate.sessionId="";delegate.refreshPresentation();precondition(delegate.menuRecordingBadge.isHidden)
        print("AMBER_PRESENTATION_PASS: actual template button + independent amber/hollow-grey badge; mini/capsule; paused/dark/idle; synthetic data; no capture")
        exit(0)
    }
    if argv.contains("--continuity-bridge") {
        delegate.watchEnabled=false
        Task { @MainActor in
            do {
                let fixture=try await delegate.api.request("fixture")
                guard fixture["fixture"] as? String == "presentation-continuity-no-capture",let id=fixture["sessionId"] as? String,let doc=fixture["documentId"] as? String else { throw CaptureError.message("Isolated fixture handshake required") }
                if argv.contains("--observe-main-bridge") {
                    var observed=0
                    for _ in 0..<750 {
                        let event=try await delegate.api.request("fixture")
                        if event["complete"] as? Bool == true { break }
                        if let serial=event["serial"] as? Int,serial>observed,let owner=event["owner"] as? String,let foreground=event["foreground"] as? Bool {
                            let ownedAPI=LocalAPI(endpoint,owner:owner)
                            let state=try await ownedAPI.request("status")
                            precondition(state["active"] as? Bool == true && state["sessionId"] as? String == id)
                            delegate.adoptBrowser(state);delegate.applyPanelPolicy(state)
                            let actualForeground=delegate.miniBlockedByMain(policyForeground:foreground)
                            // OS activation may advance while the visibility request is in flight.
                            // Check the actual foreground rule, not the older wire snapshot.
                            if delegate.panel.isVisible != !actualForeground { continue }
                            precondition(delegate.engine == nil)
                            precondition(event["documentId"] as? String == doc)
                            _ = try await delegate.api.request("fixture-ack",["serial":serial,"visible":delegate.panel.isVisible,"actualForeground":actualForeground,"sessionId":id,"documentId":doc])
                            observed=serial
                        }
                        try await Task.sleep(nanoseconds:20_000_000)
                    }
                    let last=try await delegate.api.request("fixture")
                    precondition(last["complete"] as? Bool == true && observed>=5,"Actual main lifecycle must complete")
                    print("NATIVE_MAIN_CAPSULE_PASS events=\(observed) capture=false model=false main=actual-AppKit capsule=actual-AppKit")
                    exit(0)
                }
                var steps=[String]()
                @MainActor func sync(_ name:String,_ visible:Bool,_ paused:Bool) async throws {
                    let state=try await delegate.api.request("status")
                    precondition(state["sessionId"] as? String == id && state["active"] as? Bool == true)
                    delegate.adoptBrowser(state);delegate.applyPanelPolicy(state)
                    precondition(delegate.panel.isVisible == !delegate.miniBlockedByMain(policyForeground:!visible) && delegate.paused == paused && delegate.engine == nil)
                    let identity=try await delegate.api.request("fixture")
                    precondition(identity["documentId"] as? String == doc && identity["sessionId"] as? String == id)
                    steps.append(name)
                }
                func presence(_ foreground:Bool) async throws {
                    _ = try await delegate.api.request("panel-presence",["clientId":"continuity-main-fixture","sessionId":id,"foreground":foreground])
                }
                try await presence(false);try await sync("background-capsule",true,false)
                delegate.toggleTranscript()
                try await presence(true);try await sync("main-foreground-hides-capsule",false,false)
                try await presence(false);try await sync("main-background-restores-transcript",true,false)
                precondition(delegate.viewMode == .transcript)
                for paused in [true,false] {
                    delegate.pauseClicked()
                    for _ in 0..<100 { if !delegate.busy { break };try await Task.sleep(nanoseconds:20_000_000) }
                    precondition(!delegate.busy && delegate.error.isEmpty)
                    try await sync(paused ? "capsule-pause":"capsule-resume",true,paused)
                }
                _ = try await delegate.api.request("open-main",["sessionId":id])
                try await presence(true);try await sync("reopen-same-main",false,false)
                let receipt:[String:Any]=["passed":true,"sessionId":id,"documentId":doc,"steps":steps,"capture":false,"model":false,"mainWindow":"simulated-presence","capsule":"actual-AppKit"]
                let data=try JSONSerialization.data(withJSONObject:receipt,options:[.sortedKeys])
                print("NATIVE_CONTINUITY_PASS "+String(data:data,encoding:.utf8)!)
                exit(0)
            } catch { fputs("NATIVE_CONTINUITY_FAIL \(error)\n",stderr);exit(1) }
        }
        RunLoop.main.run()
        exit(1)
    }
    if argv.contains("--visibility-only") {
        delegate.sessionId="presentation-only"
        delegate.preparePanelPresentation(waitForPolicy:true)
        precondition(!delegate.panel.isVisible && delegate.awaitingInitialPanelPolicy,"Automatic startup waits for policy without flashing the capsule")
        delegate.showPanel();delegate.toggleTranscript();delegate.toggleIntelligence()
        precondition(!delegate.panel.isVisible,"Local actions cannot bypass the initial visibility handshake")
        delegate.applyPanelPolicy([:])
        precondition(!delegate.panel.isVisible && !delegate.awaitingInitialPanelPolicy,"No owner policy does not open the old capsule")
        delegate.preparePanelPresentation(waitForPolicy:true)
        // A pinned transcript and hover preview obey the same foreground policy.
        let hiddenPolicy:[String:Any]=["panelPolicy":["managed":true,"sessionId":"presentation-only","show":false]]
        let shownPolicy:[String:Any]=["panelPolicy":["managed":true,"sessionId":"presentation-only","show":true]]
        delegate.applyPanelPolicy(shownPolicy);delegate.toggleTranscript()
        delegate.applyPanelPolicy(hiddenPolicy)
        precondition(!delegate.panel.isVisible && delegate.hoverPanel?.isVisible != true,"Foreground hides the whole floating group")
        delegate.toggleTranscript();delegate.toggleIntelligence();delegate.showPanel();delegate.collapsePanel();delegate.setTranscriptHover(true)
        delegate.applyPanelPolicy(hiddenPolicy)
        precondition(!delegate.panel.isVisible && delegate.hoverPanel?.isVisible != true && !delegate.hovering && delegate.sessionId=="presentation-only","Local actions and unchanged hidden policy cannot revive floating windows")
        delegate.applyPanelPolicy(shownPolicy)
        precondition(delegate.panel.isVisible && delegate.viewMode == .transcript,"Background restores pinned transcript without changing meeting")
        delegate.applyPanelPolicy(shownPolicy)
        precondition(delegate.viewMode == .transcript,"Unchanged policy does not collapse the pinned view")
        delegate.collapsePanel();delegate.setTranscriptHover(true)
        precondition(delegate.hoverPanel?.isVisible == true,"The isolated helper creates the actual hover panel")
        delegate.applyPanelPolicy(hiddenPolicy)
        precondition(!delegate.panel.isVisible && delegate.hoverPanel?.isVisible != true,"Foreground hides a visible hover panel as well as the capsule")
        delegate.applyPanelPolicy(shownPolicy)
        precondition(delegate.viewMode == .compact && delegate.hoverPanel?.isVisible != true,"Restoring compact mode does not revive a stale hover")
        delegate.toggleIntelligence();delegate.applyPanelPolicy(hiddenPolicy);delegate.applyPanelPolicy(shownPolicy)
        precondition(delegate.viewMode == .expanded && delegate.panel.isVisible,"Background restores the expanded intelligence panel")
        delegate.dismissedPanelSession="presentation-only";delegate.concealPanel();delegate.applyPanelPolicy(shownPolicy)
        precondition(!delegate.panel.isVisible,"A status update does not undo same-meeting manual dismissal")
        delegate.acceptPanelReopen(["active":true,"panelPolicy":hiddenPolicy["panelPolicy"]!],session:"presentation-only")
        precondition(!delegate.panel.isVisible && delegate.dismissedPanelSession.isEmpty,"Explicit reopen preserves foreground suppression")
        delegate.applyPanelPolicy(shownPolicy)
        precondition(delegate.panel.isVisible && delegate.viewMode == .expanded && delegate.sessionId=="presentation-only","Returning to background after explicit reopen restores the same meeting")
        delegate.dismissedPanelSession="presentation-only";delegate.concealPanel();delegate.applyPanelPolicy(shownPolicy)
        delegate.acceptPanelReopen(["active":true,"panelPolicy":shownPolicy["panelPolicy"]!],session:"obsolete")
        precondition(!delegate.panel.isVisible && delegate.dismissedPanelSession=="presentation-only","Late receipt cannot reopen a different meeting")
        delegate.acceptPanelReopen(["active":true,"panelPolicy":shownPolicy["panelPolicy"]!],session:"presentation-only")
        precondition(delegate.panel.isVisible && delegate.viewMode == .expanded,"Explicit same-meeting reopen clears local dismissal")
        delegate.mainOpenPending=true;delegate.applyPanelPolicy(shownPolicy)
        precondition(!delegate.panel.isVisible,"Opening main suppresses late mini receipts")
        delegate.mainOpenPending=false;delegate.applyPanelPolicy(shownPolicy)
        delegate.localMainVisibleOverride=true
        delegate.presentationEnvironmentChanged()
        precondition(!delegate.panel.isVisible,"Visible main on the same display suppresses mini despite stale show policy")
        delegate.showPanel();delegate.collapsePanel();delegate.toggleTranscript()
        precondition(!delegate.panel.isVisible,"Local shortcuts cannot violate main visibility fence")
        delegate.localMainVisibleOverride=false;delegate.presentationEnvironmentChanged()
        precondition(delegate.panel.isVisible,"Space/main visibility transition restores same presentation")
        delegate.localMainVisibleOverride=nil
        delegate.applyPanelPolicy(["panelPolicy":["managed":true,"sessionId":"presentation-next","show":true]])
        precondition(delegate.viewMode == .expanded,"A different meeting does not inherit the previous pinned view")
        delegate.applyPanelPolicy(["panelPolicy":["managed":true,"sessionId":"","show":false]])
        delegate.sessionId="";delegate.applyPanelPolicy(["panelPolicy":["managed":true,"sessionId":"","show":false]])
        precondition(!delegate.panelPolicySuppressed,"Idle show-menu remains available after the meeting ends")
        let backing:[[String:Any]]=[[kCGWindowOwnerPID as String:Int32(4242),kCGWindowLayer as String:0,kCGWindowName as String:"",kCGWindowBounds as String:["X":CGFloat(0),"Y":CGFloat(456),"Width":CGFloat(500),"Height":CGFloat(500)]]]
        precondition(!AppDelegate.meetingWindowOnScreen(backing,pid:4242),"A 500x500 untitled window is not the meeting window")
        let meeting:[[String:Any]]=[[kCGWindowOwnerPID as String:Int32(4242),kCGWindowLayer as String:0,kCGWindowName as String:"Citeside",kCGWindowBounds as String:["Width":CGFloat(1120),"Height":CGFloat(808)]]]
        precondition(AppDelegate.meetingWindowOnScreen(meeting,pid:4242),"The titled meeting window still counts as the big window")
        delegate.sessionId="listening-session";delegate.localMainVisibleOverride=false;delegate.mainOpenPending=false
        delegate.applyPanelPolicy(["panelPolicy":["managed":true,"sessionId":"listening-session","show":true,"view":"expanded","mainForeground":false,"serial":9]])
        precondition(delegate.panel.isVisible && delegate.panel.title==delegate.tr(en:"Citeside · Mini",zh:"Citeside · 小窗"),"An active listening session keeps the mini panel on screen")
        delegate.noteStaleHandoff()
        precondition(delegate.panel.isVisible && !delegate.mainOpenPending,"A stale handoff leaves the mini panel up and does not restore the main window")
        delegate.panel.orderOut(nil);delegate.hoverPanel?.orderOut(nil)
        print("native_visibility_policy_passed capture=false network=false productionDefaults=false scope=helper-policy-only listening-mini=kept")
        exit(0)
    }
    precondition(delegate.viewMode == .hidden && !delegate.panel.isVisible && !delegate.startButton.isHidden,"Startup leaves the mini window hidden and keeps the status item")
    let primary=NSRect(x:0,y:0,width:1440,height:900),secondary=NSRect(x:1440,y:0,width:1440,height:900)
    precondition(framesShareDisplay(NSRect(x:1000,y:700,width:246,height:52),NSRect(x:40,y:40,width:1200,height:800),displays:[primary,secondary]),"A bar on the main window's display is the same screen")
    precondition(!framesShareDisplay(NSRect(x:1600,y:700,width:246,height:52),NSRect(x:40,y:40,width:1200,height:800),displays:[primary,secondary]),"Geometry distinguishes different displays")
    let stale=NSRect(x:1100,y:760,width:246,height:52),mainWin=NSRect(x:40,y:40,width:1200,height:800)
    let placed=placedMiniFrame(on:secondary,size:stale.size)
    precondition(framesShareDisplay(stale,mainWin,displays:[primary,secondary]) && !framesShareDisplay(placed,mainWin,displays:[primary,secondary]),"A hidden bar is judged on the screen it will open on")
    precondition(recordingMiniView() == .compact)
    precondition(recordingMiniShouldAppear(viewMode:.hidden,sessionActive:true,sharesScreen:false))
    precondition(!recordingMiniShouldAppear(viewMode:.hidden,sessionActive:true,sharesScreen:true))
    precondition(!recordingMiniShouldAppear(viewMode:.hidden,sessionActive:false,sharesScreen:false))
    precondition(!recordingMiniShouldAppear(viewMode:.expanded,sessionActive:true,sharesScreen:false))
    let quartz=appKitRect(fromQuartzWindow:["X":100,"Y":50,"Width":1120,"Height":800],primaryHeight:900)
    precondition(abs(quartz.minY-50)<0.1 && quartz.width==1120,"Quartz window bounds flip into the main window's display space")
    let savedMainPID=delegate.mainWindowPID
    delegate.mainWindowPID=12345
    let visibleMain:[[String:Any]]=[[kCGWindowOwnerPID as String:Int32(12345),kCGWindowLayer as String:0,kCGWindowName as String:"Citeside",kCGWindowBounds as String:["X":CGFloat(40),"Y":CGFloat(40),"Width":CGFloat(1200),"Height":CGFloat(800)]]]
    precondition(!delegate.mainSharesMini(windows:visibleMain,mini:NSRect(x:1600,y:700,width:246,height:52),policyForeground:false),"A visible background main window does not suppress the mini window")
    precondition(!delegate.mainSharesMini(windows:[],mini:secondary,policyForeground:false),"Mini window can return when the main window is no longer visible")
    delegate.mainWindowPID=savedMainPID
    precondition(delegate.compactRoot.arrangedSubviews.contains(delegate.compactMeter) && delegate.capsuleRoot.arrangedSubviews.contains(delegate.capsuleMeter),"Both compact surfaces display their live audio meters")
    delegate.localMainVisibleOverride=true;delegate.sessionId="presentation-only";delegate.revealRecordingMiniBar()
    precondition(!delegate.panel.isVisible && delegate.viewMode == .hidden,"Recording on the main window's display does not open the bar")
    delegate.localMainVisibleOverride=nil;delegate.revealRecordingMiniBar()
    precondition(delegate.panel.isVisible && delegate.viewMode == .compact,"Recording opens one compact bar")
    delegate.sessionId="";delegate.hidePanel()
    precondition(!delegate.panel.isVisible && delegate.viewMode == .hidden,"Ending the session hides the bar")
    delegate.revealRecordingMiniBar()
    precondition(!delegate.panel.isVisible,"The helper that is not recording stays hidden")
    delegate.preferredMiniView = .expanded;delegate.policyResumeView = .expanded;delegate.dismissedPanelSession=""
    delegate.viewMode = .expanded;delegate.refreshPresentation();delegate.panel.orderFrontRegardless()
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    let idleHeight=delegate.panel.contentView!.frame.height
    precondition(idleHeight<=140,"Empty mini window must not reserve a card area")
    delegate.showTransportError("Temporary connection failure");delegate.recoverTransport()
    precondition(delegate.error.isEmpty && !delegate.status.stringValue.contains("failure"))
    delegate.showError("Capture failed");delegate.showTransportError("Connection failed");delegate.recoverTransport()
    precondition(delegate.error=="Capture failed" && delegate.status.stringValue=="Capture failed","Reconnect must preserve capture errors")
    delegate.error="";delegate.sessionId="presentation-only"
    delegate.mirroring=true
    delegate.renderStatus(["phase":"listening","gate":["degraded":true,"local":true]])
    precondition(delegate.status.stringValue.contains("JEV"),"Shared mini window must reveal local JEV fallback")
    delegate.renderStatus(["phase":"paused","gate":["degraded":true,"local":true]])
    precondition(!delegate.status.stringValue.contains("JEV"),"Pause status takes priority over fallback")
    delegate.showError("Capture failed")
    delegate.renderStatus(["phase":"listening","gate":["degraded":true,"local":true]])
    precondition(delegate.status.stringValue=="Capture failed","Capture errors take priority over fallback")
    delegate.error="";delegate.mirroring=false;delegate.paused=false

    let long=String(repeating:"This is a long preview with evidence. ",count:12)
    delegate.renderStatus(["cards":["suggestion":["text":long],"insights":[["text":long],["text":long]]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==3 && delegate.cards.arrangedSubviews.count==3)
    if let card=delegate.cards.arrangedSubviews.first as? MiniInsightButton { let full=card.frame.height;delegate.toggleCard(card);delegate.panel.contentView?.layoutSubtreeIfNeeded();precondition(card.frame.height==full,"Full text stays visible; the row does not fold");precondition(card.toolTip?.contains(long)==true);delegate.toggleCard(card) }
    precondition(delegate.cardScroll.frame.height<=380 && delegate.panel.contentView!.frame.height<=delegate.cardScroll.frame.height+180,"The card list scrolls; the window does not grow with every line")
    let longGist=String(repeating:"要点要完整留下来。",count:20)
    delegate.renderStatus(["cards":["suggestion":["text":long],"insights":[["text":long],["text":long]],"discussion":["title":"长要点","text":longGist,"chapters":[["title":"长要点","text":longGist,"t":10.0]]]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.gistLabel.stringValue==longGist,"A long gist stays in the label")
    precondition(delegate.gistLabel.maximumNumberOfLines==8,"Gist visual lines stay capped")
    precondition(delegate.gistLabel.toolTip==longGist,"A long gist keeps its full tooltip")
    let gistH=ceil(delegate.gistBlock.fittingSize.height),chapterH=delegate.chapterBlock.isHidden ? 0:ceil(delegate.chapterBlock.fittingSize.height)
    precondition(delegate.panel.contentView!.frame.height<=delegate.cardScroll.frame.height+gistH+chapterH+180,"Long gist stays inside the measured window")
    let decimal=miniSentenceSplit("成本是 3.14 倍。先不动。"),englishSplit=miniSentenceSplit("Hello. World stays.")
    precondition(decimal.0=="成本是 3.14 倍。" && decimal.1=="先不动。","A decimal point does not end the sentence")
    precondition(englishSplit.0=="Hello." && englishSplit.1==" World stays.","The space after an English sentence stays in the rest")
    for card in delegate.cards.arrangedSubviews { precondition(card.toolTip?.contains(long)==true) }
    delegate.renderStatus(["cards":["suggestion":["text":long],"insights":[["text":long],["text":long]]],"confirmation":["id":"test-only","question":long,"statement":long]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==4 && delegate.cardScroll.frame.height<=380)
    precondition(delegate.cards.frame.height>delegate.cardScroll.frame.height,"Long confirmation remains scrollable")
    let old=(0..<8).map { ["key":"old-\($0)","text":long,"sourceLabel":"38:06 · Speaker 1"] }
    delegate.lastCards=""
    delegate.renderStatus(["cards":["suggestion":["key":"latest","text":long],"history":old]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==9 && delegate.cards.frame.height>delegate.cardScroll.frame.height)
    let anchor=delegate.cards.arrangedSubviews.first { $0.identifier?.rawValue=="old-4" }!
    let reading=anchor.frame.minY+12
    delegate.cardScroll.contentView.scroll(to:NSPoint(x:0,y:reading))
    delegate.renderStatus(["cards":["suggestion":["key":"new-latest","text":"A new reminder"],"history":old]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    let kept=delegate.cards.arrangedSubviews.first { $0.identifier?.rawValue=="old-4" }!
    precondition(abs(delegate.cardScroll.contentView.bounds.origin.y-kept.frame.minY-12)<2,"New reminders must preserve the history being read")
    delegate.lastCards=""
    delegate.renderStatus(["cards":["suggestion":["text":"A short actionable suggestion"],"insights":[]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==1 && delegate.panel.contentView!.frame.height<250)
    delegate.renderStatus(["cards":["insights":[]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardScroll.isHidden && delegate.panel.contentView!.frame.height<150)
    delegate.collapsePanel();delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.panel.frame.width >= 246 && delegate.panel.frame.width < 400 && abs(delegate.panel.frame.height-52)<1,"Quick controls use one small horizontal row")
    let mainShortcut=delegate.compactRoot.arrangedSubviews.compactMap { $0 as? NSButton }.first { $0.toolTip==delegate.tr(en:"Open main window",zh:"打开主窗口") }
    precondition(mainShortcut != nil && mainShortcut!.title.isEmpty && mainShortcut!.image != nil && mainShortcut!.action == #selector(AppDelegate.openMain),"The compact window has an explicit icon-only Open main window action")
    func snapshot(_ name:String) {
        guard let base=ProcessInfo.processInfo.environment["THT_PRESENTATION_SNAPSHOT"],let view=delegate.panel.contentView else { return }
        view.layoutSubtreeIfNeeded()
        guard let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) else { return }
        view.cacheDisplay(in:view.bounds,to:bitmap)
        if let data=bitmap.representation(using:.png,properties:[:]) { try? data.write(to:URL(fileURLWithPath:base+"-"+name+".png")) }
        // Real window capture (blur, shadow, rounded mask) next to the cached bitmap.
        RunLoop.current.run(until:Date().addingTimeInterval(0.3))
        let shot=Process();shot.executableURL=URL(fileURLWithPath:"/usr/sbin/screencapture");shot.arguments=["-x","-o","-l\(delegate.panel.windowNumber)",base+"-"+name+"-window.png"]
        try? shot.run();shot.waitUntilExit()
    }
    delegate.sessionId="presentation-only";delegate.mirroring=true;delegate.mirrorSeconds=72;delegate.refreshPresentation()
    precondition(delegate.compactButton.title=="01:12" && !delegate.compactPause.isHidden && !delegate.compactEnd.isHidden && delegate.compactStart.isHidden)
    precondition(delegate.startButton.isHidden && !delegate.pauseButton.isHidden && !delegate.endButton.isHidden,"Active mirrored controls agree")
    delegate.mirroring=false;delegate.refreshPresentation();precondition(delegate.startButton.isHidden && !delegate.pauseButton.isHidden && !delegate.endButton.isHidden,"Active native controls agree");delegate.mirroring=true;delegate.refreshPresentation()
    delegate.renderStatus(["phase":"listening","audioSeconds":72.0,"audioLevel":0.4,"recentTranscript":[["t":72.0,"text":"Keep the same meeting open."]]])
    precondition(delegate.compactMeter.level==0.4,"The waveform uses actual reported energy")
    snapshot("capsule")
    let capsuleFrame=delegate.panel.frame
    delegate.setTranscriptHover(true)
    precondition(delegate.hoverPanel?.isVisible == true && delegate.hoverText!.string.contains("01:12"),"Hover previews the same timestamped transcript")
    precondition(delegate.panel.frame==capsuleFrame && delegate.viewMode == .compact && delegate.sessionId=="presentation-only","Preview cannot move capsule or change meeting")
    if let base=ProcessInfo.processInfo.environment["THT_PRESENTATION_SNAPSHOT"],let view=delegate.hoverPanel?.contentView,let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) {
        view.cacheDisplay(in:view.bounds,to:bitmap)
        try? bitmap.representation(using:.png,properties:[:])?.write(to:URL(fileURLWithPath:base+"-hover.png"))
    }
    delegate.setTranscriptHover(false);delegate.setTranscriptHover(true)
    RunLoop.current.run(until:Date().addingTimeInterval(0.25))
    precondition(delegate.hoverPanel?.isVisible == true,"Entering preview cancels pending dismissal")
    delegate.toggleTranscript();delegate.setTranscriptHover(false)
    precondition(delegate.viewMode == .transcript && delegate.hoverPanel?.isVisible == false,"CC pins transcript independently of hover")
    delegate.toggleTranscript();delegate.setTranscriptHover(true);delegate.setTranscriptHover(false)
    delegate.hoverDismiss?.cancel()
    delegate.dismissHoverPreview(at:NSPoint(x:delegate.hoverPanel!.frame.midX,y:delegate.hoverPanel!.frame.midY))
    precondition(delegate.hoverPanel?.isVisible == true,"Moving into preview must not close it")
    delegate.dismissHoverPreview(at:NSPoint(x:-100000,y:-100000))
    precondition(delegate.hoverPanel?.isVisible == false && delegate.viewMode == .compact,"Leaving preview restores compact mode")
    precondition(delegate.panel.frame==capsuleFrame && delegate.sessionId=="presentation-only")
    delegate.toggleTranscript();snapshot("transcript");precondition(delegate.viewMode == .transcript && delegate.transcriptPreview.string.contains("01:12") && delegate.sessionId=="presentation-only")
    let longRows=(0..<120).map { ["t":Double($0*5),"text":"第\($0)段：这是本场会议的中文逐字稿，保留时间并让用户在阅读历史内容时不被新内容打断。"] as [String:Any] }
    delegate.renderStatus(["recentTranscript":longRows]);delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.transcriptPreview.frame.height>delegate.transcriptScroll.contentView.bounds.height,"Long transcript must scroll")
    delegate.transcriptScroll.contentView.scroll(to:NSPoint(x:0,y:40));delegate.transcriptScroll.reflectScrolledClipView(delegate.transcriptScroll.contentView)
    delegate.renderStatus(["recentTranscript":longRows+[["t":601.0,"text":"新增一段，不跳走正在读的位置。"]]])
    precondition(abs(delegate.transcriptScroll.contentView.bounds.origin.y-40)<2,"Appending preserves history position")
    snapshot("transcript-long")
    delegate.transcriptPreview.scrollRangeToVisible(NSRange(location:delegate.transcriptPreview.string.utf16.count,length:0))
    delegate.renderStatus(["recentTranscript":longRows+[["t":602.0,"text":"继续跟随最新内容。"]]])
    precondition(delegate.transcriptScroll.contentView.bounds.maxY>=delegate.transcriptPreview.bounds.height-24,"Reading latest keeps following latest")
    delegate.toggleTranscript();precondition(delegate.viewMode == .compact && delegate.sessionId=="presentation-only")
    delegate.renderStatus(["cards":["suggestion":["text":"先根据本场讨论生成可展示的方案草稿：用轻松、乐观的未来日常表达科技感，保留真实来源与待确认项。"],"insights":[["text":"老板提到 The Jetsons，指的是《杰森一家》：飞行汽车、机器人管家和充满想象力的家庭生活。这里强调的是乐观、亲切的科技，而非冰冷的机械感。"]]]]);delegate.toggleIntelligence();snapshot("intelligence");precondition(delegate.viewMode == .expanded && delegate.sessionId=="presentation-only")
    let now=Date().timeIntervalSince1970*1000
    let miniStatus:[String:Any]=["phase":"listening","audioSeconds":2287.0,"audioLevel":0.55,
        "recentTranscript":[["t":2280.0,"text":"So if we lock D1 this week, the Pin team can start the EVT plan before CDCP."]],
        "cards":["discussion":["title":"Pin binding decision","text":"The team is weighing whether Pin pairs to one phone only; hardware wants it settled before EVT.","updatedAt":now-20000,"chapters":[["title":"Pin binding decision (D1)","text":"Weighing one-phone pairing.","t":1940.0,"at":now-340000]]],
            "insights":[["key":"mini-outside","text":"Humane's AI Pin shipped single-device pairing and later had to add a companion app for multi-device; reviewers cited setup friction as a top complaint.","sourceLabel":"37:12 · Speaker 2"]]]]
    delegate.lastCards="";delegate.mirrorSeconds=2287;delegate.renderStatus(miniStatus);delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(!delegate.chapterBlock.isHidden && !delegate.gistBlock.isHidden && !delegate.footerBlock.isHidden && delegate.footerText.stringValue.contains("lock D1"),"Mini shows chapter, gist and latest line")
    precondition(delegate.chapterCaption.isHidden && delegate.gistCaption.isHidden,"Mini chapter and gist captions stay off the rail")
    precondition(delegate.chapterLabel.stringValue.contains("32:20"),"Topic clock stays on the title")
    precondition(delegate.chapterLabel.maximumNumberOfLines==0,"Topic title is not clipped, so the clock stays visible")
    precondition(delegate.gistLabel.stringValue=="The team is weighing whether Pin pairs to one phone only; hardware wants it settled before EVT.","A point is one sentence without a clock")
    if let row=delegate.cards.arrangedSubviews.compactMap({ $0 as? MiniInsightButton }).first {
        precondition(row.time=="37:12" && row.rowHover==false,"Finding time stays hidden until the row is hovered")
        precondition(row.deepFrame.minX>=28 && row.deepFrame.maxX<=332,"The sentence-end research link stays inside the text column")
        precondition(row.deepFrame.maxY<=row.intrinsicContentSize.height-14,"The full research link remains visible with the row spacing")
    }
    precondition((delegate.cards.arrangedSubviews.first as? MiniInsightButton)?.deepButton != nil,"Outside-info card offers Deep research")
    if let deep=(delegate.cards.arrangedSubviews.first as? MiniInsightButton)?.deepButton {
        precondition(deep.cardKey=="mini-outside" && deep.cardText.hasPrefix("Humane") && deep.isEnabled,"Deep research carries this card's identity")
        delegate.setDeep("mini-outside","running:2",deep);precondition(deep.title.contains("2/4") && !deep.isEnabled,"Deep research follows the receipt")
        delegate.setDeep("mini-outside","done",deep);precondition(deep.title==delegate.tr(en:"Added to report",zh:"已并进研报") && !deep.title.contains("深度分析"),"Done means merged into the report")
        delegate.setDeep("mini-outside","failed",deep);precondition(deep.isEnabled,"Failed research can be retried")
        delegate.deepJobs=[:];delegate.lastCards="";delegate.renderStatus(miniStatus);delegate.panel.contentView?.layoutSubtreeIfNeeded()
    }
    snapshot("mini")
    delegate.paused=true;delegate.renderStatus(miniStatus.merging(["phase":"paused"]) { $1 });snapshot("mini-paused");delegate.paused=false
    NSApp.appearance=NSAppearance(named:.darkAqua);delegate.renderStatus(miniStatus);snapshot("mini-dark");NSApp.appearance=nil
    if let base=ProcessInfo.processInfo.environment["THT_PRESENTATION_SNAPSHOT"] {
        for badge in ["idle","listening","paused"] {
            let icon=menuBarImage(badge:badge);let scale:CGFloat=4
            let rep=NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:Int(icon.size.width*scale),pixelsHigh:Int(icon.size.height*scale),bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
            rep.size=icon.size;NSGraphicsContext.saveGraphicsState();NSGraphicsContext.current=NSGraphicsContext(bitmapImageRep:rep)
            NSColor.white.setFill();NSRect(origin:.zero,size:icon.size).fill();icon.draw(in:NSRect(origin:.zero,size:icon.size))
            let dot=NSBezierPath(ovalIn:NSRect(x:13,y:13,width:4,height:4))
            if badge=="listening" { MiniTone.recording.setFill();dot.fill() }
            else if badge=="paused" { NSColor.secondaryLabelColor.setStroke();dot.lineWidth=1;dot.stroke() }
            NSGraphicsContext.restoreGraphicsState();try? rep.representation(using:.png,properties:[:])?.write(to:URL(fileURLWithPath:base+"-menubar-"+badge+".png"))
        }
    }
    delegate.expandFromCapsule();snapshot("mini")
    delegate.collapseToCapsule();snapshot("icon-capsule")
    precondition(delegate.viewMode == .capsule && delegate.panel.frame.width>=delegate.capsuleRoot.fittingSize.width && delegate.panel.frame.height<=44)
    let capsuleButtons=delegate.capsuleRoot.arrangedSubviews.compactMap { $0 as? NSButton }
    precondition(capsuleButtons.count==5 && capsuleButtons.contains { $0.action == #selector(AppDelegate.openMain) } && capsuleButtons.contains { $0.action == #selector(AppDelegate.hidePanel) } && capsuleButtons.contains { $0.action == #selector(AppDelegate.expandFromCapsule) },"Capsule directly offers main window, hide and expanded mini")
    delegate.paused=true;delegate.refreshPresentation();snapshot("icon-capsule-paused")
    precondition(delegate.capsulePause.accessibilityLabel()==delegate.tr(en:"Resume listening",zh:"继续听会"))
    delegate.paused=false;delegate.panel.appearance=NSAppearance(named:.darkAqua);delegate.refreshPresentation();snapshot("icon-capsule-dark")
    delegate.panel.appearance=NSAppearance(named:.aqua)
    delegate.updateCaptureRecovery("recovering");snapshot("recovering")
    precondition(!delegate.status.isHidden && delegate.cardScroll.isHidden && delegate.reconnectButton.isHidden)
    delegate.updateCaptureRecovery("failed");snapshot("reconnect")
    precondition(!delegate.reconnectButton.isHidden)
    delegate.updateCaptureRecovery("ready");precondition(delegate.viewMode == .capsule)
    delegate.expandFromCapsule()
    delegate.collapsePanel();delegate.paused=true;delegate.refreshPresentation();precondition(delegate.compactMeter.level==0)
    delegate.paused=false;delegate.showTransportError("Disconnected");precondition(delegate.compactMeter.level==0 && delegate.sessionId=="presentation-only")
    delegate.recoverTransport();delegate.renderStatus(["phase":"listening","audioSeconds":74.0,"audioLevel":0.2]);precondition(delegate.compactMeter.level==0.2 && delegate.compactButton.title=="01:14")
    delegate.renderStatus(["phase":"listening","audioSeconds":75.0,"audioLevel":0.0]);precondition(delegate.compactMeter.level==0)
    delegate.sessionId="";delegate.mirroring=false;delegate.meetingCandidate=true;delegate.refreshPresentation()
    precondition(!delegate.notNowButton.isHidden && !delegate.compactStart.isHidden,"Detected call offers Start and Not now")
    precondition(!delegate.startButton.isHidden && delegate.pauseButton.isHidden && delegate.endButton.isHidden,"Idle controls agree")
    delegate.dismissDetection();precondition(!delegate.panel.isVisible && !delegate.meetingCandidate,"Not now dismisses without capture")
    delegate.showPanel();precondition(delegate.panel.isVisible && abs(delegate.panel.frame.width-360)<1)
    delegate.hidePanel();precondition(!delegate.panel.isVisible)
    _=delegate.applicationShouldHandleReopen(app,hasVisibleWindows:false);precondition(!delegate.panel.isVisible && delegate.mainOpenPending,"Dock reopen asks for the main window and leaves the capsule hidden")
    delegate.hidePanel()
    delegate.sessionId="ended-fixture";delegate.mirroring=false
    let endedEngine=CaptureEngine(pcm:{_ in preconditionFailure("Ended engine emitted PCM")},text:{_,_ in},frame:{_ in},failure:{_ in})
    delegate.engine=endedEngine;delegate.audioQueue=[(1,Data([1,2]),0)];delegate.textQueue=[("k","queued")];delegate.pendingFrame=Data([1])
    var endedChecked=false
    Task { @MainActor in
        await delegate.finishEndedSession("ended-fixture")
        precondition(delegate.sessionId.isEmpty && delegate.engine==nil && !delegate.busy && !delegate.panel.isVisible,"meeting_ended releases idle owner claim guards")
        precondition(delegate.audioQueue.isEmpty && delegate.textQueue.isEmpty && delegate.pendingFrame==nil && endedEngine.closing && endedEngine.file==nil,"meeting_ended stops engine and clears events")
        let oldGeneration=delegate.captureGeneration
        delegate.captureGeneration+=1;delegate.sessionId="ended-fixture"
        await delegate.finishEndedSession("ended-fixture",generation:oldGeneration)
        precondition(delegate.sessionId=="ended-fixture","Late receipt cannot stop a resumed capture with the same ID")
        delegate.sessionId="next-fixture"
        await delegate.finishEndedSession("ended-fixture")
        precondition(delegate.sessionId=="next-fixture","Late end receipt cannot stop a new session")
        delegate.resetSession();endedChecked=true
    }
    let endDeadline=Date().addingTimeInterval(5)
    while !endedChecked && Date()<endDeadline { RunLoop.current.run(until:Date().addingTimeInterval(0.01)) }
    precondition(endedChecked,"meeting_ended idle transition completed")
    print("native_presentation_test_passed: meeting_ended idle/queues/stale receipt; 0/1/3 cards; scrollable confirmation; error recovery; horizontal compact shortcuts; hover preview/transition/pin/leave; expanded intelligence/CC; real/zero/paused/disconnected/recovered meter; fold; hide; reopen");exit(0)
}
app.delegate=delegate;app.run()

final class ConfirmationHandler:NSObject { let handler:()->Void;init(_ handler:@escaping()->Void){self.handler=handler};@objc func click(){handler()} }
