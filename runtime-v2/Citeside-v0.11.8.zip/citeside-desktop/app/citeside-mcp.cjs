"use strict";
// Standalone source entry: MCP clients load this plain CommonJS file, never compiled app modules.
// The official SDK owns framing, validation, protocol negotiation and EOF handling.
const { McpServer } = require("@modelcontextprotocol/server");
const { serveStdio } = require("@modelcontextprotocol/server/stdio");

function createServer({
  tools,
  invoke,
  onInitialized,
  serverInfo = { name: "citeside", version: require("../package.json").version },
}) {
  if (!Array.isArray(tools) || typeof invoke !== "function")
    throw new TypeError("MCP tools and restricted transport are required");
  const server = new McpServer(serverInfo);
  if (onInitialized)
    server.server.oninitialized = () => {
      void Promise.resolve(onInitialized()).catch(() => {});
    };
  for (const tool of tools) {
    server.registerTool(
      tool.name,
      {
        title: tool.title || tool.name,
        description: tool.description || "",
        inputSchema: tool.inputSchema,
        ...(tool.annotations ? { annotations: tool.annotations } : {}),
      },
      async (args) => {
        try {
          const result = await invoke(tool.name, args);
          return {
            content: [{ type: "text", text: JSON.stringify(result) }],
            ...(result?.ok === false ? { isError: true } : {}),
          };
        } catch {
          // Keep transport URLs, grants and native application internals out of protocol errors.
          return {
            content: [
              {
                type: "text",
                text: "Citeside connection unavailable. Open Citeside and check this connection.",
              },
            ],
            isError: true,
          };
        }
      },
    );
  }
  return server;
}

function start(options) {
  return serveStdio(() => createServer(options));
}

function clientOptions(env = process.env, fetchImpl = fetch) {
  const raw = env.CITESIDE_MCP_ORIGIN;
  let origin;
  try {
    origin = new URL(raw);
  } catch {
    throw Error("Citeside local connection configuration is missing");
  }
  if (
    origin.protocol !== "http:" ||
    origin.hostname !== "127.0.0.1" ||
    !origin.port ||
    origin.username ||
    origin.password ||
    origin.search ||
    origin.hash ||
    origin.pathname !== "/"
  )
    throw Error("Citeside requires an explicit local loopback origin");
  const grant = env.CITESIDE_MCP_GRANT;
  if (typeof grant !== "string" || !/^[A-Za-z0-9_-]{40,100}$/.test(grant))
    throw Error("Citeside connection grant is missing");
  const hit = async (method, params = {}) => {
    const response = await fetchImpl(
      origin.origin + "/asr-relay/mcp-connection",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + grant,
        },
        body: JSON.stringify({ method, params }),
        redirect: "error",
        signal: AbortSignal.timeout(10000),
      },
    );
    const value = await response.json();
    if (!response.ok || !value.ok) throw Error("Citeside connection denied");
    return value.result;
  };
  let hello;
  const ensureHello = () => {
    if (!hello)
      hello = hit("hello").catch((error) => {
        hello = null;
        throw error;
      });
    return hello;
  };
  return {
    tools: require("./citeside-mcp-tools.cjs").tools,
    onInitialized: ensureHello,
    invoke: async (name, args) => {
      await ensureHello();
      return hit("tools/call", { name, arguments: args });
    },
  };
}
if (require.main === module) {
  try {
    start(clientOptions());
  } catch {
    process.stderr.write(
      "Citeside MCP configuration unavailable. Open Citeside and create a connection.\n",
    );
    process.exitCode = 1;
  }
}
module.exports = { createServer, start, clientOptions };
