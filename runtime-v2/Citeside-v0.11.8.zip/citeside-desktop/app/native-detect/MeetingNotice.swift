import AppKit
import CoreAudio

// This process only reads Core Audio process metadata. It never creates an
// audio device, tap, capture session, or requests microphone authorization.
func emit(_ value: [String: Any]) {
    guard let data = try? JSONSerialization.data(withJSONObject: value), var line = String(data: data, encoding: .utf8) else { return }
    line += "\n"
    FileHandle.standardOutput.write(Data(line.utf8))
}
@available(macOS 14.2, *)
func inputApps() -> [String]? {
    var address = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyProcessObjectList, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
    var size: UInt32 = 0
    guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size) == noErr else { return nil }
    if size == 0 { return [] }
    var processes = [AudioObjectID](repeating: 0, count: Int(size) / MemoryLayout<AudioObjectID>.size)
    let status = processes.withUnsafeMutableBytes { AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, $0.baseAddress!) }
    guard status == noErr else { return nil }
    var apps = Set<String>()
    for process in processes {
        var running: UInt32 = 0, bytes = UInt32(MemoryLayout<UInt32>.size)
        address.mSelector = kAudioProcessPropertyIsRunningInput
        guard AudioObjectGetPropertyData(process, &address, 0, nil, &bytes, &running) == noErr, running != 0 else { continue }
        address.mSelector = kAudioProcessPropertyBundleID
        var bundle: Unmanaged<CFString>? = nil
        bytes = UInt32(MemoryLayout<Unmanaged<CFString>?>.size)
        guard AudioObjectGetPropertyData(process, &address, 0, nil, &bytes, &bundle) == noErr, let bundle = bundle else { continue }
        apps.insert(bundle.takeRetainedValue() as String)
    }
    return apps.sorted()
}
final class NoticePanel: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}
final class NoticeButton: NSButton {
    var primary = false
    override func draw(_ dirtyRect: NSRect) {
        let dark = effectiveAppearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
        if primary {
            (dark ? NSColor(calibratedWhite: 0.96, alpha: 1) : NSColor(calibratedWhite: 0.114, alpha: 1)).setFill()
            NSBezierPath(roundedRect: bounds, xRadius: 7, yRadius: 7).fill()
        }
        let color: NSColor = primary ? (dark ? NSColor(calibratedWhite: 0.114, alpha: 1) : .white) : .secondaryLabelColor
        let attr: [NSAttributedString.Key: Any] = [.font: NSFont.systemFont(ofSize: primary ? 13 : 12, weight: primary ? .medium : .regular), .foregroundColor: color]
        let size = (title as NSString).size(withAttributes: attr)
        (title as NSString).draw(at: NSPoint(x: primary ? (bounds.width-size.width)/2 : 0, y: (bounds.height-size.height)/2), withAttributes: attr)
    }
}
final class NoticeView: NSView {
    override func draw(_ rect: NSRect) {
        let dark = effectiveAppearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
        (dark ? NSColor(calibratedWhite: 0.173, alpha: 1) : .white).setFill()
        NSBezierPath(roundedRect: bounds, xRadius: 12, yRadius: 12).fill()
    }
}
final class Delegate: NSObject, NSApplicationDelegate {
    var panel: NoticePanel!
    var message: [String: Any] = [:]
    var lastApps: [String]? = nil
    var poll: Timer?
    var expiry: Timer?
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        panel = NoticePanel(contentRect: NSRect(x: 0, y: 0, width: 300, height: 85), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.level = .floating
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        panel.isOpaque = false; panel.backgroundColor = .clear; panel.hasShadow = true
        panel.hidesOnDeactivate = false; panel.isReleasedWhenClosed = false
        if #available(macOS 14.2, *) {
            scan()
            poll = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in self?.scan() }
        } else { emit(["type": "mic_unavailable"]) }
        DispatchQueue.global(qos: .utility).async {
            while let line = readLine() {
                guard line.utf8.count < 65536, let data = line.data(using: .utf8), let value = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { continue }
                DispatchQueue.main.async { self.receive(value) }
            }
            DispatchQueue.main.async { NSApp.terminate(nil) }
        }
    }
    @available(macOS 14.2, *)
    func scan() {
        guard let apps = inputApps() else { lastApps = nil; emit(["type": "mic_unavailable"]); return }
        if lastApps != apps { lastApps = apps; emit(["type": "mic", "apps": apps]) }
    }
    func label(_ text: String, _ frame: NSRect, size: CGFloat, bold: Bool = false, secondary: Bool = false) -> NSTextField {
        let field = NSTextField(labelWithString: text)
        field.frame = frame; field.font = .systemFont(ofSize: size, weight: bold ? .semibold : .regular)
        field.textColor = secondary ? .secondaryLabelColor : .labelColor
        field.lineBreakMode = .byTruncatingTail
        return field
    }
    func button(_ title: String, _ action: String, _ frame: NSRect, primary: Bool = false) -> NSButton {
        let b = NoticeButton(frame: frame); b.title = title; b.primary = primary
        b.isBordered = false; b.target = self; b.action = #selector(clicked(_:)); b.identifier = NSUserInterfaceItemIdentifier(action)
        b.setAccessibilityLabel(title)
        return b
    }
    @objc func clicked(_ sender: NSButton) {
        emit(["type": "action", "action": sender.identifier?.rawValue ?? "", "id": message["id"] ?? 0])
        panel.orderOut(nil); expiry?.invalidate()
    }
    func receive(_ value: [String: Any]) {
        if value["type"] as? String == "hide" { panel.orderOut(nil); expiry?.invalidate(); return }
        guard value["type"] as? String == "show" else { return }
        let changed = (message["id"] as? Int) != (value["id"] as? Int)
        message = value
        let en = value["language"] as? String == "en", kind = value["kind"] as? String ?? "start"
        let width: CGFloat = 300, height: CGFloat = 88
        let view = NoticeView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        var title = value["title"] as? String ?? "", subtitle = value["subtitle"] as? String ?? ""
        let app = value["app"] as? [String: Any], appName = app?["name"] as? String ?? ""
        if en {
            title = ["检测到会议":"Meeting detected", "检测到通话":"Call detected", "检测到语音通话":"Voice call detected", "会议结束了":"Meeting ended"][title] ?? title
            if kind == "end" { subtitle = appName + " has left the call" }
        }
        let actionTitle = kind == "end" ? (en ? "End recording" : "结束记录") : (en ? "Start recording" : "开始记录")
        let buttonWidth: CGFloat = en ? 112 : 76
        view.addSubview(label(title, NSRect(x: 12, y: 56, width: width-36-buttonWidth, height: 20), size: 13, bold: true))
        view.addSubview(label(subtitle, NSRect(x: 12, y: 38, width: width-36-buttonWidth, height: 18), size: 12, secondary: true))
        view.addSubview(button(actionTitle, kind == "end" ? "stop" : "start", NSRect(x: width-12-buttonWidth, y: 42, width: buttonWidth, height: 30), primary: true))
        let linkTitle = kind == "end" ? (en ? "Continue recording" : "继续记录") : (en ? "Not this time" : "这场不用")
        let linkWidth: CGFloat = en ? 120 : 48
        view.addSubview(button(linkTitle, kind == "end" ? "continue" : "dismiss", NSRect(x: 14, y: 12, width: linkWidth, height: 18)))
        if kind == "start", app != nil {
            view.addSubview(button((en ? "Don't remind for " : "不再提醒 ") + appName, "mute", NSRect(x: 14+linkWidth+16, y: 12, width: width-40-linkWidth, height: 18)))
        }
        panel.contentView = view
        if let screen = NSScreen.main ?? NSScreen.screens.first {
            let frame = screen.visibleFrame
            panel.setFrame(NSRect(x: frame.maxX-width-12, y: frame.maxY-height-10, width: width, height: height), display: true)
        }
        panel.orderFrontRegardless() // No activate(), makeKey(), or focus stealing.
        if changed { expiry?.invalidate(); expiry = Timer.scheduledTimer(withTimeInterval: 120, repeats: false) { [weak self] _ in self?.panel.orderOut(nil) } }
    }
}
let app = NSApplication.shared
let delegate = Delegate()
app.delegate = delegate
app.run()
