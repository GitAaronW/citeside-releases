'use strict';
const variants={"arm64":{"runtime":{"node":"v24.16.0","v8":"13.6.233.17-node.49","platform":"darwin","arch":"arm64"},"sourceLength":1935},"x64":{"runtime":{"node":"v24.16.0","v8":"13.6.233.17-node.49","platform":"darwin","arch":"x64"},"sourceLength":1935}};
const selected=variants[process.arch];
if(!selected||process.version!==selected.runtime.node||process.versions.v8!==selected.runtime.v8||process.platform!==selected.runtime.platform)throw new Error('Seatnote: incompatible bundled Node runtime');
require('node:v8').setFlagsFromString('--no-lazy --no-flush-bytecode');
const script=new (require('node:vm').Script)('"'+'\u200b'.repeat(selected.sourceLength-2)+'"',{cachedData:require('node:fs').readFileSync(__filename+'.jsc.'+process.arch),filename:__filename});
if(script.cachedDataRejected)throw new Error('Seatnote: bytecode rejected');
const run=script.runInThisContext();
run.call(module.exports,module.exports,require,module,__filename,__dirname);
