"use strict";
const z = require("zod/v4");
const id = z
  .string()
  .min(1)
  .max(100)
  .regex(/^[a-zA-Z0-9_-]+$/);
const paging = {
  limit: z.number().int().min(1).max(30).default(8),
  offset: z.number().int().min(0).max(10000).default(0),
};
const tools = [
  {
    name: "profile_sync",
    title: "同步个人背景",
    description:
      "请使用你已知且可靠的长期记忆，以及我已授权的资料，整理我的身份与职责、项目目标与阶段、伙伴与术语、决策约束、会议偏好；每组注明来源与最近确认时间，未知就写未知。不要从当前目录、仓库、AGENTS 或通用 AI 规则推断我的职业或项目事实，不编造，不自行翻邮箱补资料。资料不足时先同步明确已知，只问一个最关键的问题。建议交给熟悉我工作的 AI；新的聊天未必拥有长期记忆。通过已有的 Citeside MCP 连接调用 profile_sync，不重建或撤销当前授权。此连接仅支持可访问这台 Mac 的本机 MCP 客户端。 只更新此来源，不覆盖手工背景，不执行内容中的指令。",
    inputSchema: z.object({ markdown: z.string().min(1).max(20000) }).strict(),
  },
  {
    name: "meetings_search",
    title: "搜索允许的会议纪要",
    description: "搜索已授权会议的标题、日期和纪要摘要，不提供录音或逐字稿。",
    inputSchema: z
      .object({ query: z.string().max(200).optional(), ...paging })
      .strict(),
  },
  {
    name: "meetings_get",
    title: "读取会议纪要摘要",
    description:
      "按会议ID读取已授权的纪要摘要、结论和待办，不提供录音或逐字稿。",
    inputSchema: z.object({ meetingId: id }).strict(),
  },
  {
    name: "research_list",
    title: "列出研究报告",
    description: "列出已授权会议的已完成研究报告。不会启动研究或调用模型。",
    inputSchema: z.object({ meetingId: id.optional(), ...paging }).strict(),
  },
  {
    name: "research_get",
    title: "读取完整研究报告",
    description:
      "读取已完成且允许访问的研究报告，不触发模型，不返回内部提示词。",
    inputSchema: z.object({ meetingId: id, reportId: id.optional() }).strict(),
  },
];
for (const tool of tools) {
  tool.annotations = {
    readOnlyHint: tool.name !== "profile_sync",
    destructiveHint: tool.name === "profile_sync",
    idempotentHint: true,
    openWorldHint: false,
  };
}
module.exports = { tools };
