'use strict';
// Evidence, background and AI judgement are separate views of the Session journal.
// Per-page/session dedupe survives card re-rendering. An interaction is not exposure.
const liveSignalSeen = new Set(), liveSignalDismissed = new Set();
const liveSignalTimers = new Map();
let liveSignalObserver;
function watchLiveSignal(card, key, send) {
  if (typeof IntersectionObserver !== 'function' || liveSignalSeen.has(key + '|shown')) return;
  for (const [node, timer] of liveSignalTimers) if (!node.isConnected) { clearTimeout(timer); liveSignalTimers.delete(node); liveSignalObserver?.unobserve(node); }
  if (!liveSignalObserver) liveSignalObserver = new IntersectionObserver(entries => {
    for (const e of entries) {
      const node = e.target;
      if (e.isIntersecting && e.intersectionRatio >= 0.5) {
        if (!liveSignalTimers.has(node)) liveSignalTimers.set(node, setTimeout(() => {
          liveSignalTimers.delete(node); liveSignalObserver.unobserve(node);
          if (node.isConnected && !node.hidden) node._signalShown();
        }, 1000));
      } else { clearTimeout(liveSignalTimers.get(node)); liveSignalTimers.delete(node); }
    }
  }, {threshold: [0, 0.5]});
  card._signalShown = () => send('shown'); liveSignalObserver.observe(card);
}
window.THTLiveSignals = {
  attach(items, modules) {
    const groups = new Map(), loose = [];
    for (const item of items.filter(x => ['background','verification'].includes(x.channel))) {
      const ids = (item.sourceRefs || []).map(r => typeof r === 'string' ? r : r.segId);
      const candidates = modules.filter(m => m.kind !== 'summary');
      const module = candidates.find(m => m.topic === item.topic) || candidates.find(m => (m.sourceRefs || []).some(r => ids.includes(typeof r === 'string' ? r : r.segId)));
      if (!module) { loose.push(item); continue; }
      if (!groups.has(module.id)) groups.set(module.id, []);
      groups.get(module.id).push(item);
    }
    return {groups, loose};
  },
  render(item, {el, tr, refs, globalAct, openArtifact, sessionId, signal, copyText}) {
    const card = el('section', '', 'signal signal-' + item.channel);
    card.dataset.signalId = item.id;
    // The meeting picker is authoritative when this board switches meetings in place.
    const meetingId = sessionId || (typeof document !== 'undefined' && document.getElementById('meeting')?.value) || item.sessionId || '';
    const key = meetingId + '|' + item.id;
    const send = action => {
      if (!meetingId || !item.id) return;
      const once = key + '|' + action;
      if (['shown','expand'].includes(action)) { if (liveSignalSeen.has(once)) return; liveSignalSeen.add(once); }
      const record = {sessionId:meetingId,cardId:item.id,key:item.key || '',action,source:'meeting-board',kind:item.channel,text:String(item.point || item.claim || item.topic || '').slice(0,120)};
      try {
        if (signal) Promise.resolve(signal(record)).catch(()=>{});
        else {
          let token=''; try { token=JSON.parse(localStorage.getItem('tht-settings') || '{}').relayToken || ''; } catch {}
          fetch('/card-signal?token='+encodeURIComponent(token), {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(record)}).catch(()=>{});
        }
      } catch {}
    };
    if (liveSignalDismissed.has(key)) { card.hidden=true; return card; }
    const trackDetails = details => { details.addEventListener?.('toggle', () => { if (details.open) send('expand'); }); return details; };
    card.append(el('small', item.channel === 'judgment' ? tr('当前判断 · AI 推断，尚未确认','Current judgement · AI inference, unconfirmed') : item.channel === 'verification' ? tr('事实核查 · 公开检索','Fact check · Public search') : tr('背景补充 · 公开检索','Background · Public search'), 'signal-label'));
    card.append(el('h3', item.channel === 'judgment' ? item.point : item.entity || item.topic));
    if (item.channel === 'judgment') {
      const change = item.decisionChange;
      if (change && [change.previous, change.reason, change.current].every(x => typeof x === 'string' && x.trim())) {
        const figure = el('figure', '', 'decision-change');
        figure.append(el('figcaption', tr('判断如何改变 · AI 推断','How the judgement changed · AI inference')));
        const flow = el('ol', '', 'decision-change-flow');
        for (const [label, text] of [[tr('原判断','Previous'),change.previous],[tr('新依据','New basis'),change.reason],[tr('当前判断','Current'),change.current]]) {
          const step = el('li'); step.append(el('small',label),el('p',text)); flow.append(step);
        }
        figure.append(flow); card.append(figure);
      } else card.append(el('p', item.whyChanged, 'signal-reason'));
      if(String(item.openGap||'').trim()){const gap=el('p','','signal-gap');gap.append(el('small',tr('还没关上的缺口','Still open')),el('span',String(item.openGap).trim()));card.append(gap);}
      if(item.speechDraft){const speech=el('aside','','speech-draft');speech.append(el('small',tr('此刻可以这样说 · AI 草稿','Something you could say · AI draft')),el('p',item.speechDraft));card.append(speech);}
      if (item.artifactId && typeof openArtifact === 'function') {
        const open = el('button', tr('查看并修改图稿','View and edit diagram'));
        open.type='button'; open.onclick=()=>openArtifact(item.artifactId); card.append(open);
      }
      const correct = el('button', tr('纠正或继续问','Correct or ask'));
      correct.onclick = () => globalAct({comment:'',quote:item.point}); card.append(correct);
    } else {
      if (item.channel === 'verification') card.append(el('p', tr('待核查说法：','Claim to check: ') + item.claim));
      if (item.lookupState === 'ready') {
        if (item.point) card.append(el('p', item.point, 'signal-message'));
        if (item.whyUseful) card.append(el('p', item.whyUseful, 'signal-reason'));
        const evidence = trackDetails(el('details', '', 'signal-evidence'));
        evidence.append(el('summary', tr('查看来源', 'Sources')));
        for (const source of item.evidence || []) {
          if (!/^https?:\/\//.test(source.url || '')) continue;
          evidence.append(el('blockquote', source.excerpt));
          const a = el('a', source.title || source.url); a.href=source.url; a.target='_blank'; a.rel='noopener noreferrer'; evidence.append(a);
          const date=new Date(source.retrievedAt); if (!Number.isNaN(date.getTime())) evidence.append(el('small', tr('检索于 ','Retrieved ') + date.toLocaleString(), 'signal-date'));
        }
        evidence.append(el('small', tr('检索片段供核对，不代表整条说法已经验证。','Search excerpts for review; the full claim has not been verified.'), 'signal-caveat'));
        card.append(evidence);
      } else {
        const state = ({pending:tr('已识别，准备检索','Identified, preparing search'),searching:tr('正在检索公开来源…','Searching public sources…'),no_evidence:tr('未找到可用证据；不能据此判定真伪','No usable evidence; this does not establish truth or falsity'),unavailable:tr('检索暂不可用','Search unavailable')})[item.lookupState] || '';
        card.append(el('small',state,'signal-status'));
      }
    }
    if (item.sourceRefs?.length) { const d=trackDetails(refs(item)); d.dataset.key=item.id+':source';card.append(d); }
    const controls=el('div','','signal-actions');
    const copy=el('button',tr('复制','Copy'));copy.type='button';
    copy.onclick=async()=>{try { const text=[item.entity || item.topic,item.claim,item.point,item.whyChanged,item.whyUseful,item.openGap,item.caveat].filter(Boolean).join('\n'); if(copyText)await copyText(text);else await navigator.clipboard.writeText(text);send('copy'); } catch {} };
    const adopt=el('button',tr('采纳','Adopt'));adopt.type='button';
    adopt.onclick=()=>{if(adopt.disabled)return;send('adopt');adopt.disabled=true;adopt.textContent=tr('已采纳','Adopted');};
    const dismiss=el('button',tr('关闭','Dismiss'));dismiss.type='button';
    dismiss.onclick=()=>{send('dismiss');liveSignalDismissed.add(key);card.hidden=true;clearTimeout(liveSignalTimers.get(card));liveSignalTimers.delete(card);liveSignalObserver?.unobserve(card);};
    controls.append(copy,adopt,dismiss);card.append(controls);
    watchLiveSignal(card,key,send);
    return card;
  }
};
