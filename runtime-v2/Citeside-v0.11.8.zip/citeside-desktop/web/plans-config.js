/* 建议值，待确认。价格与每月时长只在此处维护；邀请赠送权益由账号服务返回。 */
window.THT_PLANS = Object.freeze([
  Object.freeze({ id: 'free', price: 0, hours: 3 }),
  Object.freeze({ id: 'pro', price: 24, hours: 15 }),
  Object.freeze({ id: 'max', price: 59, hours: 30 })
]);
