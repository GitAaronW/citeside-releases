'use strict';
// Layout owns visibility and panel sizes only. Capture, conversation and document keep their owners.
(()=>{
 if(parent!==window)return;
 const frame=document.getElementById('workspace-frame'),panel=document.getElementById('myagent-panel');
 if(!frame||!panel)return;
 // New workspaces start with the conversation and its working document. The
 // shared transcript tab remains available; explicit prior choices win.
 const state={left:false,right:true};let explicitRight=false,selectedTab='document',transcriptReturn=null;
 // At narrow widths the shared panel replaces the timeline; it never overlays it.
 const panelFull=()=>window.innerWidth<=760;let ended=null,curSid='',liveSid='',recordingSnapshot=null;
 const narrow=()=>window.innerWidth<1100;
 let transcriptRows=[],transcriptNames={},transcriptStart=null,liveTranscript=null;
 const compact=()=>window.innerWidth<=760;
 try{const saved=JSON.parse(localStorage.getItem('tht-meeting-workspace-panels')||'{}');for(const key of ['left','right'])if(key==='right'&&typeof saved[key]==='boolean')state[key]=saved[key];explicitRight=typeof saved.right==='boolean';if(['document','transcript','report'].includes(saved.tab))selectedTab=saved.tab;}catch{}
 const maximum={left:640,right:960};
 // 全屏比例：1200 及以下沿用右栏 58%（中窗不变）。到 13 寸全屏 1470 收到 42% 后，
 // 16 寸和外接大屏用同一个比例往上长。上限跟窗口走（48%），不再用 960px 把右栏钉死。
 function rightCap(viewport){const width=Number(viewport);return Math.max(960,Number.isFinite(width)?Math.round(width*0.48):0);}
 // Approved .body: the document column is 300px until the user resizes it.
 function defaultRightWidth(){return 300;}
 window.thtMeetingColumnWidth=viewport=>({right:defaultRightWidth(viewport),cap:rightCap(viewport)});
 const widths={left:Math.round(Math.min(420,Math.max(230,window.innerWidth*.245))),right:defaultRightWidth(window.innerWidth)};
 let rightChosen=false;
 try{const saved=JSON.parse(localStorage.getItem('tht-meeting-workspace-widths')||'{}');for(const key of ['left','right'])if(Number.isFinite(saved[key])){widths[key]=Math.max(key==='left'?220:260,Math.min(key==='right'?rightCap(window.innerWidth):maximum[key],saved[key]));if(key==='right')rightChosen=true;}if(Number.isFinite(saved.ratio)&&saved.ratio>.1&&saved.ratio<.9){widths.ratio=saved.ratio;rightChosen=true;}}catch{}
 const preferred={...state};
 // 复审 V06：文档栏浮层阈值 980 也算一档，跨 980（如 1000→960）同样重新判定，保留用户显式打开的偏好。
 const sizeMode=()=>(compact()?'compact':narrow()?'narrow':'wide')+(panelFull()?':float':'');
 let currentSize=sizeMode();
 function adaptSize(){Object.assign(state,preferred);state.left=false;if(panelFull()&&!explicitRight)state.right=false;}
 adaptSize();
 const bar=document.createElement('nav');bar.className='mw-bar';bar.setAttribute('aria-label','会议工作区 / Meeting workspace');
 const homeBack=document.createElement('button');homeBack.type='button';homeBack.id='mw-home';homeBack.className='mw-home';homeBack.innerHTML='<span class="mw-home-chevron">‹</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 11l8-7 8 7M6 10v9h12v-9"/></svg><span class="mw-home-label">主页</span>';homeBack.setAttribute('aria-label','返回主页');
 // Navigation only: the existing home route keeps the recorder and same meeting alive.
 homeBack.onclick=()=>document.querySelector('.dh-home-toggle')?.click();
 // These application destinations belong on Home. Reuse its mounted navigation
 // and the existing handlers; redraws must not remove the two missing links.
 const homeNavigation=document.querySelector('.dh-nav-body');
 function syncHomeNavigation(){
  if(!homeNavigation)return;const en=document.documentElement?.lang==='en',settings=homeNavigation.querySelector('.dh-settings');
  for(const [cls,zh,english,path,run] of [
   ['dh-notes','我的笔记','My notes','M5 3h14v18H5z M8 8h8 M8 12h8 M8 16h5',()=>window.thtOpenWorkbench?.('notes')],
   ['dh-history','历史会议','Meeting history','M12 8v5l3 2 M21 12a9 9 0 1 1-3-6.7',()=>document.getElementById('b-hist')?.click()]
  ]){
   let button=homeNavigation.querySelector('.'+cls);
   if(!button){button=document.createElement('button');button.type='button';button.className=cls;button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="'+path+'"/></svg><span></span>';button.onclick=run;homeNavigation.insertBefore(button,settings);}
   const label=en?english:zh,span=button.querySelector('span');if(span.textContent!==label)span.textContent=label;button.title=label;button.setAttribute('aria-label',label);
  }
 }
 syncHomeNavigation();if(homeNavigation)new MutationObserver(syncHomeNavigation).observe(homeNavigation,{childList:true});
 window.addEventListener('tht-language-change',syncHomeNavigation);
 const title=document.createElement('strong');title.textContent='会议 / Meeting';
 const buttons={},rightText=document.createElement('span');
 for(const [key,label] of [['right','会议面板 / Meeting panel']]){
  const button=document.createElement('button');button.type='button';const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('width','18');icon.setAttribute('height','18');icon.setAttribute('fill','none');icon.setAttribute('stroke','currentColor');icon.setAttribute('stroke-width','1.6');icon.setAttribute('aria-hidden','true');const outline=document.createElementNS(icon.namespaceURI,'rect');outline.setAttribute('x','3');outline.setAttribute('y','4');outline.setAttribute('width','18');outline.setAttribute('height','16');outline.setAttribute('rx','3');const pane=document.createElementNS(icon.namespaceURI,'rect');pane.setAttribute('class','mw-pane');pane.setAttribute('x',key==='left'?'4.2':'12.8');pane.setAttribute('y','5.2');pane.setAttribute('width','7');pane.setAttribute('height','13.6');pane.setAttribute('rx','1.2');const divider=document.createElementNS(icon.namespaceURI,'path');divider.setAttribute('d',key==='left'?'M9 4v16':'M15 4v16');icon.append(outline,pane,divider);button.append(icon);button.setAttribute('aria-label',label);button.title=label;
  button.className='mw-toggle-'+key;if(key==='right'){rightText.className='mw-toggle-text';rightText.hidden=true;button.append(rightText);}
  button.onclick=()=>{stopDrag();state.right=!state.right;savePanel();layout();};buttons[key]=button;
 }
 const directActions=document.createElement('div');directActions.className='mw-document-actions mw-document-footer';
 const overflowActions=[];let summaryAction=null;
 const live=document.createElement('span');live.className='mw-live-status';live.classList.add('latest');live.hidden=true;const end=document.createElement('button');end.type='button';end.className='mw-end';end.hidden=true;end.onclick=()=>{
  if(curSid&&!ended&&meetingNativeStatus().active!==true&&['stop','fail','asr'].includes(controlState))return recoverInterrupted();
  const stop=document.getElementById('stop'),en=document.documentElement.lang==='en';
  if(!stop||typeof stop.click!=='function'){finishNote.textContent=en?'Stop is unavailable. Refresh and try again.':'停止控制暂不可用，请刷新后重试';return;}
  if(stop.disabled){finishNote.textContent=en?'Ending is already in progress. Please wait.':'正在结束，请稍候';return;}
  if(typeof window!=='undefined'&&window.thtLiveSend&&window.thtLiveSend.cancelAll)window.thtLiveSend.cancelAll();if(recmenu)recmenu.hidden=true;
  finishNote.textContent='';try{stop.click();}catch{finishNote.textContent=en?'Could not stop. Please try again.':'没能停止，请重试';}
 };
 for(const [id,zh,en]of [['mw-summary','总结','Summary'],['mw-notice','最近通知','Recent notification']]){const action=document.createElement('button');action.type='button';action.id=id;const label=()=>{const text=document.documentElement.lang==='en'?en:zh;action.textContent=text;action.setAttribute('aria-label',text);if(id==='mw-notice')action.hidden=!window.thtHasNotice?.();};label();action.onclick=()=>{if(id==='mw-summary'){if(document.body.classList.contains('mw-report-mode')&&!document.body.classList.contains('mw-doc-view'))window.thtLiveReport?.toggleView?.();if(!(state.right&&selectedTab==='document')||outputSelection!=='document'){selectedTab='document';outputSelection='document';state.right=true;transcriptReturn=null;savePanel();layout();}frame.contentDocument?.body?.classList.add('mw-summary-open');frame.contentWindow?.postMessage({type:'tht-summary-toggle',open:true},location.origin);return;}if(id==='mw-notice'){openNotice();return;}document.getElementById(id)?.click();};if(id==='mw-summary'){action.className='mw-summary-entry';summaryAction=action;directActions.append(action);}else{overflowActions.push(action);directActions.append(action);}}
 // Document tools remain directly reachable without an overflow menu.
 const topicAction=document.createElement('button');topicAction.type='button';topicAction.id='mw-track-topic';
 const topicEntry=document.createElement('section');topicEntry.className='mw-topic-entry';topicEntry.dataset.topicEntry='';topicEntry.hidden=true;
 const topicForm=document.createElement('form');topicForm.dataset.topicAdd='';
 const topicLabel=document.createElement('label'),topicInput=document.createElement('input');topicInput.name='topic';topicInput.maxLength=120;topicInput.required=true;
 const topicLabelText=document.createElement('span');topicLabel.append(topicLabelText,topicInput);
 const topicSubmit=document.createElement('button');topicSubmit.type='submit';
 const topicStatus=document.createElement('small');topicStatus.dataset.topicStatus='';topicStatus.setAttribute('role','status');
 topicForm.onsubmit=e=>{e.preventDefault();e.stopPropagation();void window.thtChangeMeetingTopic?.('add','',topicInput.value,topicSubmit);};
 topicForm.append(topicLabel,topicSubmit);topicEntry.append(topicForm,topicStatus);overflowActions.push(topicAction);directActions.append(topicAction);
 const documentEnglish=()=>(frame.contentDocument?.documentElement?.lang||document.documentElement?.lang)==='en';
 const topicLabels=()=>{const en=documentEnglish();topicAction.textContent=en?'Track a topic':'追踪一个话题';topicLabelText.textContent=en?'Topic to follow':'想追踪的话题';topicSubmit.textContent=en?'Add':'新增';topicAction.hidden=!curSid||!!ended;};
 function syncDocumentActions(){
  const en=documentEnglish();
  overflowActions[0].hidden=!window.thtHasNotice?.();
  overflowActions[0].textContent=en?'Recent notification':'最近通知';
  summaryAction.textContent=en?'Summary':'总结';summaryAction.setAttribute('aria-label',summaryAction.textContent);
 }
 const closeTopicEntry=()=>{topicEntry.hidden=true;topicInput.value='';topicStatus.textContent='';delete topicEntry.dataset.topicSession;};
 topicAction.onclick=()=>{if(!curSid||ended)return;topicLabels();topicEntry.dataset.topicSession=curSid;topicEntry.hidden=false;topicInput.focus();};
 topicLabels();
 window.addEventListener('tht-topics-saved',e=>{if(e.detail?.id!==topicEntry.dataset.topicSession)return;closeTopicEntry();topicAction.focus();});
 window.addEventListener('tht-meeting-navigating',()=>{closeTopicEntry();topicAction.hidden=true;});
 window.addEventListener('tht-proactive-data',e=>{const session=e.detail?.session;if(session?.id!==topicEntry.dataset.topicSession||session?.end)closeTopicEntry();if(session?.end)topicAction.hidden=true;else topicLabels();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!topicEntry.hidden){e.preventDefault();closeTopicEntry();topicAction.focus();}});
 document.addEventListener('pointerdown',e=>{if(!topicEntry.hidden&&!topicEntry.contains(e.target)&&e.target!==topicAction)closeTopicEntry();});
 const sub=document.createElement('span');sub.className='mw-sub';sub.hidden=true;
 // Approved recording control: a source picker and one direct recording action.
 const pill=document.createElement('div');pill.className='mw-pill';pill.hidden=true;
 pill.innerHTML='<span class="mw-wave" aria-hidden="true">'+'<i></i>'.repeat(11)+'</span><span class="mw-spin" aria-hidden="true"></span><span class="mw-t">00:00</span><span class="mw-pstate" role="status"></span>';
 const recmenu=document.createElement('div');recmenu.className='mw-recmenu';recmenu.hidden=true;recmenu.setAttribute('role','menu');recmenu.setAttribute('aria-label',document.documentElement.lang==='en'?'Recording options':'录音选项');
 const source=document.createElement('button');source.type='button';source.className='mw-source';source.textContent='⌄';source.setAttribute('aria-label',document.documentElement.lang==='en'?'Recording options':'录音选项');source.setAttribute('aria-haspopup','menu');source.setAttribute('aria-expanded','false');
 let controlState='stop',sourceError='',retryFailed=false;
 const resume=document.createElement('button');resume.type='button';resume.className='mw-resume';resume.hidden=true;
 resume.onclick=async()=>{if(resume.disabled)return;resume.disabled=true;const requestedId=curSid;sourceError='';retryFailed=false;try{if(controlState==='asr'){const result=await window.thtWorkspaceNative.request('asr-retry',{sessionId:requestedId});window.dispatchEvent(new CustomEvent('tht-asr-status',{detail:{sessionId:requestedId,asrStatus:result.asrStatus}}));}else await undoEnd();}catch{if(curSid===requestedId){retryFailed=controlState!=='asr';sourceError=document.documentElement.lang==='en'?'Retry failed. Try again.':'重试未成功，请再试';}}finally{resume.disabled=false;statusSignature='';updateStatus();}};
 const recsep=document.createElement('i');recsep.className='mw-sep';
 const synced=document.createElement('span');synced.className='mw-syncd';synced.hidden=true;
 async function chooseSource(uid){
  const ns=window.thtNativeStatus||{},sid=ns.sessionId;source.disabled=true;sourceError='';
  try{
   const bridge=window.thtWorkspaceNative;if(!bridge)throw Error('unavailable');
   if(!ns.active)await bridge.request('input-preference',{inputUID:uid});
   else{
    const result=await bridge.request('microphone-switch',{sessionId:sid,inputUID:uid}),requestId=result.microphoneChange?.requestId;if(!requestId)throw Error('not accepted');
    let receipt;
    for(let i=0;i<12;i++){await new Promise(resolve=>setTimeout(resolve,500));const next=await bridge.request('status');bridge.update(next);if(next.sessionId!==sid||!next.active)throw Error('meeting changed');if(next.microphoneReceipt?.requestId===requestId){receipt=next.microphoneReceipt;break;}}
    if(!receipt?.ok)throw Error('unconfirmed');
   }
   const cfg=JSON.parse(localStorage.getItem('tht-settings')||'{}');cfg.nativeInputUID=uid;localStorage.setItem('tht-settings',JSON.stringify(cfg));bridge.setInput(uid);recmenu.hidden=true;
  }catch{sourceError=document.documentElement.lang==='en'?'Could not switch input':'输入源未切换';}
  finally{source.disabled=false;source.setAttribute('aria-expanded',String(!recmenu.hidden));statusSignature='';updateStatus();}
 }
 source.onclick=()=>{
  recmenu.hidden=!recmenu.hidden;source.setAttribute('aria-expanded',String(!recmenu.hidden));if(recmenu.hidden)return;
  recmenu.replaceChildren();const ns=window.thtNativeStatus||{};let cfg={};try{cfg=JSON.parse(localStorage.getItem('tht-settings')||'{}');}catch{}const selected=ns.requestedInputUID??cfg.nativeInputUID??'';
  for(const row of [{uid:'',name:document.documentElement.lang==='en'?'Auto':'自动'},...(ns.inputDevices||[])]){const b=document.createElement('button');b.type='button';b.textContent=row.name;b.setAttribute('role','menuitemradio');b.setAttribute('aria-checked',String(row.uid===selected));b.onclick=()=>chooseSource(row.uid);recmenu.append(b);}
  const mini=document.createElement('button');mini.type='button';mini.className='mw-mini-window';mini.setAttribute('role','menuitem');mini.textContent=document.documentElement.lang==='en'?'Mini window':'小窗模式';mini.onclick=()=>{frame.contentDocument?.querySelector('.surface-mini-window')?.click();recmenu.hidden=true;source.setAttribute('aria-expanded','false');};recmenu.append(mini);
  const anchor=pill.getBoundingClientRect(),bounds=bar.getBoundingClientRect();recmenu.style.left=Math.max(8,anchor.left-bounds.left)+'px';
 };
 pill.append(source,end,resume);
 const intel=document.createElement('button');intel.type='button';intel.className='mw-intel';intel.textContent='主动智能';intel.setAttribute('aria-expanded','false');
 const intelLayer=document.createElement('aside');intelLayer.className='mw-intelligence-layer';intelLayer.hidden=true;document.body.append(intelLayer);
 const intelText=item=>{const text=typeof item==='string'?item:String(item?.text||item?.title||'');return text.trim();};
 window.thtOpenMeetingIntelligence=()=>{intelLayer.hidden=!intelLayer.hidden;intel.setAttribute('aria-expanded',String(!intelLayer.hidden));};
 intel.onclick=()=>window.thtOpenMeetingIntelligence();
 window.addEventListener('tht-proactive-data',e=>{
  const data=e.detail||{},session=data.session||{},id=String(session.id||data.id||'');if(!id||(curSid&&id!==curSid))return;
  intelLayer.dataset.meeting=id;
  const bag=session.nativeInsights||{};
  const lines=[...(Array.isArray(bag.insights)?bag.insights:[]),bag.suggestion].map(intelText).filter(Boolean);
  intelLayer.replaceChildren();
  for(const line of lines){const item=document.createElement('p');item.className='mw-intel-item';item.textContent=line;intelLayer.append(item);}
  if(!lines.length){const empty=document.createElement('p');empty.className='mw-intel-empty';empty.textContent=document.documentElement.lang==='en'?'Nothing new in this meeting yet.':'这场还没有新的判断。';intelLayer.append(empty);}
 });
 window.thtCollapseToMini=()=>{if(window.liveMateNativeWindow!==true)return false;if(typeof window.thtRequestMiniPanel==='function')return window.thtRequestMiniPanel();return false;};
 const transcriptEntry=document.createElement('button');transcriptEntry.type='button';transcriptEntry.id='mw-transcript-entry';transcriptEntry.className='mw-transcript-entry';transcriptEntry.textContent=document.documentElement.lang==='en'?'Transcript':'转写';transcriptEntry.setAttribute('aria-controls','mw-transcript-panel');transcriptEntry.onclick=()=>openTranscript();
 const settingsEntry=document.createElement('button');settingsEntry.type='button';settingsEntry.className='mw-settings-entry';settingsEntry.textContent=document.documentElement.lang==='en'?'Settings':'设置';settingsEntry.onclick=()=>document.getElementById('gear2')?.click();
 const spacer=document.createElement('div');spacer.className='sp';
 const globalActions=document.createElement('div');globalActions.className='mw-global-actions';
 homeBack.classList.add('mw-back');

 bar.append(homeBack,title,pill,recmenu,spacer);document.body.append(bar);
 document.addEventListener('pointerdown',e=>{if(!recmenu.hidden&&!recmenu.contains(e.target)&&!pill.contains(e.target)){recmenu.hidden=true;source.setAttribute('aria-expanded','false');}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!recmenu.hidden){recmenu.hidden=true;source.setAttribute('aria-expanded','false');source.focus?.();}});
 // Reuse the real status node and recorder handlers; no cloned controls or capture commands.
 function pinLatestLine(){let layer=document.querySelector('.mw-chat-layer');if(!layer){layer=document.createElement('aside');layer.className='mw-chat-layer';document.body.append(layer);}if(live.parentElement===layer)return;const rest=[...layer.children].filter(node=>node!==live);layer.replaceChildren(live,...rest);}
 pinLatestLine();
 function active(){return !document.body.classList.contains('document-home-open')&&frame.hidden===false;}
 // An interrupted meeting can be ended now instead of waiting for automatic recovery.
 // Recording pause/end stay in the pill menu; interrupted-session recovery stays on the bar.
 // After capture, network or server loss, both exits stay on the bar itself.
 const finish=document.createElement('button');finish.type='button';finish.className='mw-finish-saved';finish.hidden=true;
 const finishNote=document.createElement('span');finishNote.className='mw-finish-status';finishNote.setAttribute('role','status');pill.append(finishNote);
 const interruptEnd=document.createElement('button');interruptEnd.type='button';interruptEnd.className='mw-interrupt-end';interruptEnd.hidden=true;
 const organize=document.createElement('button');organize.type='button';organize.className='mw-organize';organize.hidden=true;
 let finishPending=false,finishedId='',audioHealth='';
 window.addEventListener('tht-meeting-navigating',()=>{finish.hidden=true;interruptEnd.hidden=true;organize.hidden=true;finishNote.textContent='';});
 const IMMEDIATE_CAPTURE=new Set(['callback-stalled','input-ended','input-muted','suspended']);
 const DELAYED_CAPTURE=new Set(['disconnected','no-signal']);
 const TRANSIENT_ERROR=/最后一句尚未送达|收尾未确认|正在重试保存|Last sentence not delivered|Final save unconfirmed/i;
 const healthName=v=>String(v&&typeof v==='object'?v.state||'':v||'');
 let slowKey='',slowSince=0,interruptVisible=false;
 const nowMs=()=>typeof window.thtNow==='function'?window.thtNow():Date.now();
 function slowHeld(key){
  const now=nowMs();
  if(!key){slowKey='';slowSince=0;return false;}
  if(key!==slowKey){slowKey=key;slowSince=now;return false;}
  return now-slowSince>8000;
 }
 function meetingNativeStatus(){
  const ns=window.thtNativeStatus||{},id=curSid||window.thtViewedMeetingId||'',pending=String(ns.pendingSessionId||''),session=String(ns.sessionId||''),errorId=String(ns.errorSessionId||'');
  if(id&&![pending,session,errorId].includes(id))return {};
  const ownsCapture=!id||session===id||pending===id;
  return {...ns,captureRecovery:ownsCapture?ns.captureRecovery:'',captureHealth:ownsCapture?ns.captureHealth:'',audioLevel:ownsCapture?ns.audioLevel:0,captureReady:ownsCapture?ns.captureReady:false,starting:!!ns.starting&&(!id||pending===id||(!pending&&session===id)),active:!!ns.active&&(!id||session===id),error:errorId&&id&&errorId!==id?'':ns.error,asrStatus:session&&id&&session!==id?null:ns.asrStatus};
 }
 function meetingInterrupted(st){
  const ns=meetingNativeStatus();
  const names=[healthName(ns.captureHealth),st,healthName(audioHealth)];
  if(names.some(name=>IMMEDIATE_CAPTURE.has(name)))return true;
  if(ns.transcriptionInterrupted||(!ns.asrStatus&&window.thtRecordingMeetingId?.()===curSid&&(window.thtTranscriptionInterrupted||window.thtNativeLinkDown)))return true;
  if(ns.sessionId&&ns.sessionId===curSid&&ns.active===false&&!ns.starting)return true;
  const delayed=names.filter(name=>DELAYED_CAPTURE.has(name));
  const err=String(ns.error||'');
  const errHere=!!err&&(!ns.errorSessionId||ns.errorSessionId===curSid||ns.sessionId===curSid)&&!TRANSIENT_ERROR.test(err);
  return slowHeld([...delayed,errHere?err:''].filter(Boolean).join('|'));
 }
 function recordingSeconds(snapshot,at){
  if(!snapshot)return null;
  const stamp=value=>typeof value==='number'?value:Date.parse(value||''),start=stamp(snapshot.start),end=snapshot.end?stamp(snapshot.end):Number(at);
  if(!Number.isFinite(start)||!Number.isFinite(end))return null;
  const gap=(snapshot.recordingSpans||[]).reduce((sum,span)=>{const previous=stamp(span.previousEnd),continued=stamp(span.continuedAt);return sum+(Number.isFinite(previous)&&Number.isFinite(continued)?Math.max(0,Math.min(end,continued)-Math.max(start,previous)):0);},0);
  return Math.max(0,Math.floor((end-start-gap)/1000));
 }
 const durationText=seconds=>(seconds>=3600?[Math.floor(seconds/3600),Math.floor(seconds/60)%60,seconds%60]:[Math.floor(seconds/60),seconds%60]).map(value=>String(value).padStart(2,'0')).join(':');
 let recordingContinuation=null,clockAnchor=null;
 // Helper audioSeconds restarts for each continued capture; the saved spans retain prior time.
 window.thtAccumulatedCaptureSeconds=(ns,segmentSeconds)=>{
  if(!recordingSnapshot||recordingSnapshot.id!==ns.sessionId)return segmentSeconds;
  if(ns.captureMode==='browser')return recordingSeconds(recordingSnapshot,nowMs())??segmentSeconds;
  if(recordingContinuation?.id===ns.sessionId&&recordingSnapshot.end){const prior=recordingSeconds(recordingSnapshot,nowMs());return prior===null?segmentSeconds:prior+Math.max(0,segmentSeconds);}
  const spans=recordingSnapshot.recordingSpans||[],last=spans.at(-1);
  if(!last)return segmentSeconds;
  const prior=recordingSeconds({...recordingSnapshot,end:last.previousEnd},nowMs());
  return prior===null?segmentSeconds:prior+Math.max(0,segmentSeconds);
 };
 function recordingClock(fallback){
  const ns=meetingNativeStatus(),id=recordingSnapshot?.id||curSid;
  if(!id)return fallback;
  const remember=seconds=>{clockAnchor={id,seconds};return durationText(seconds);};
  if(ns.active&&ns.sessionId===id&&ns.captureMode==='native'&&Number.isFinite(Number(ns.audioSeconds))){
   const frozen=ns.phase==='paused'||ns.captureEnding||window.thtNativeLinkDown||!nativeSeenAt;
   const segment=Math.max(0,Number(ns.audioSeconds))+(frozen?0:Math.min(6000,Math.max(0,nowMs()-nativeSeenAt))/1000);
   return remember(Math.floor(window.thtAccumulatedCaptureSeconds(ns,segment)));
  }
  if(recordingSnapshot?.end){const seconds=recordingSeconds(recordingSnapshot,nowMs());return seconds===null?fallback:remember(seconds);}
  const running=ns.active===true||!!(id&&window.thtRecordingMeetingId?.()===id);
  if(!running||window.thtPauseControl?.state?.()?.paused||['stop','fail'].includes(controlState)){
   if(clockAnchor?.id===id)return durationText(clockAnchor.seconds);
   const parts=String(fallback||'00:00').split(':').map(Number),seconds=parts.every(Number.isFinite)?parts.reduce((n,x)=>n*60+x,0):0;
   return remember(Math.max(0,Math.floor(seconds)));
  }
  const seconds=recordingSeconds(recordingSnapshot,nowMs());return seconds===null?fallback:remember(seconds);
 }
 async function undoEnd(){
  recmenu.hidden=true;const id=curSid;if(!id)return;
  const previousEnd=recordingSnapshot?.end;recordingContinuation={id};
  let accepted;try{accepted=await window.thtStartRecording?.(null,{continueMeetingId:id});}catch{accepted=false;}
  if(curSid!==id){recordingContinuation=null;return;}
  if(accepted===true){
   if(recordingSnapshot?.id===id){const spans=recordingSnapshot.recordingSpans||[];recordingSnapshot={...recordingSnapshot,end:null,recordingSpans:previousEnd&&!spans.some(span=>String(span.previousEnd)===String(previousEnd))?[...spans,{previousEnd,continuedAt:nowMs()}]:spans};}
   ended=null;finishedId='';sourceError='';retryFailed=false;statusSignature='';
  }else{retryFailed=true;sourceError=document.documentElement.lang==='en'?'Could not connect. Retry.':'录音未接上，请重试';}
  recordingContinuation=null;
 }
 function enterWrapup(id){
  try{
   if(!window.thtViewedMeetingId||window.thtViewedMeetingId===id)window.thtViewedMeetingId=id;
   window.thtTranscriptionInterrupted=false;window.thtNativeLinkDown=false;audioHealth='';
   const ns=window.thtNativeStatus||{};
   window.thtNativeStatus={...ns,active:false,starting:false,sessionId:'',pendingSessionId:'',captureHealth:'',error:'',phase:'ended'};
   window.dispatchEvent(new CustomEvent('tht-native-status',{detail:window.thtNativeStatus}));
   const start=ended?.start||Date.now();
   window.dispatchEvent(new CustomEvent('tht-proactive-data',{detail:{id,session:{id,start,end:Date.now()}}}));
   const host=document.querySelector('#myagent-panel .ma-insights')||document.getElementById('myagent-panel');
   window.thtPostmeeting?.mount?.(host,{id,fresh:true});
  }catch{}
  // 待定老化由服务端启动和每小时扫描负责，结束会议不触发。
 }
 async function completeSaved(id){
  const en=document.documentElement.lang==='en';
  finishPending=true;finish.disabled=true;interruptEnd.disabled=true;organize.disabled=true;finishNote.textContent=en?'Saving…':'正在收尾…';
  try{
   let token='';try{token=JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}
   const response=await fetch('/meeting-finish?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id}),signal:AbortSignal.timeout(30000)});
   const result=await response.json();if(!response.ok||!result.ok)throw Error(result.error||String(response.status));
   finishedId=id;
   if(curSid!==id)return;
   finishNote.textContent=result.status==='queued'?(en?'Ended. Organizing saved content…':'已结束，正在整理已保存的内容…'):result.status==='saved'?(en?'Ended and saved. Organization needs retry.':'已结束并保存，整理排队失败，请在会后重试。'):(en?'This meeting has already ended.':'本场已结束。');
   window.dispatchEvent(new CustomEvent('tht-meeting-finished',{detail:{id,status:result.status}}));
   enterWrapup(id);
  }catch(error){if(curSid===id)finishNote.textContent=document.documentElement.lang==='en'?'Could not finish. Click End & organize to retry.':'未能结束，请再点「结束并整理」重试。';}
  finally{finishPending=false;finish.disabled=false;interruptEnd.disabled=false;organize.disabled=false;statusSignature='';updateStatus();}
 }
 finish.onclick=async()=>{
  const id=curSid,en=document.documentElement.lang==='en';
  if(!id||finishPending||!window.confirm(en?'End this interrupted meeting and organize its saved content?':'结束这场中断的会议，并整理已保存的内容？'))return;
  if(typeof window!=='undefined'&&window.thtLiveSend&&window.thtLiveSend.cancelAll)window.thtLiveSend.cancelAll();
  await completeSaved(id);
 };
 async function recoverInterrupted(){
  const id=curSid,en=document.documentElement.lang==='en';
  if(!id||finishPending||ended||id===finishedId)return;
  if(!window.confirm(en?'End this interrupted meeting and organize its saved content?':'结束这场中断的会议，并整理已保存的内容？'))return;
  if(typeof window!=='undefined'&&window.thtLiveSend&&window.thtLiveSend.cancelAll)window.thtLiveSend.cancelAll();
  const ns=window.thtNativeStatus||{};
  const nativeHeld=!!(ns.sessionId===id&&ns.captureMode!=='browser');
  const browserHeld=!nativeHeld&&!!((ns.captureMode==='browser'&&ns.sessionId===id)||window.thtRecordingMeetingId?.()===id);
  if(browserHeld){
   finishPending=true;
   try{
    const stop=document.getElementById('stop');
    const fail=()=>{if(curSid===id)finishNote.textContent=en?'Could not end this meeting. Try again.':'没能结束这场会议，请再试一次';};
    if(!stop||stop.disabled||typeof stop.click!=='function'){fail();return;}
    const hiddenBefore=!!stop.hidden;
    try{stop.click();}catch{fail();return;}
    const live=window.thtNativeStatus||{};
    const released=(window.thtRecordingMeetingId?.()||'')!==id&&!(live.captureMode==='browser'&&live.active&&live.sessionId===id);
    if(!(!!stop.hidden&&!hiddenBefore)&&!released){fail();return;}
    finishedId=id;
    if(curSid===id){finishNote.textContent=en?'Ended. Organizing saved content…':'已结束，正在整理已保存的内容…';window.dispatchEvent(new CustomEvent('tht-meeting-finished',{detail:{id,status:'stop'}}));enterWrapup(id);}
   }finally{finishPending=false;statusSignature='';updateStatus();}
   return;
  }
  if(nativeHeld){
   let closed=false;
   finishPending=true;finish.disabled=true;interruptEnd.disabled=true;organize.disabled=true;finishNote.textContent=en?'Saving…':'正在收尾…';
   try{
    const response=await fetch('/native/end',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sessionId:id}),signal:AbortSignal.timeout(30000)});
    const result=await response.json();if(!response.ok||result.ok===false)throw Error(result.error||String(response.status));
    finishedId=id;closed=true;
    if(curSid===id){finishNote.textContent=en?'Ended. Organizing saved content…':'已结束，正在整理已保存的内容…';window.dispatchEvent(new CustomEvent('tht-meeting-finished',{detail:{id,status:'ended'}}));enterWrapup(id);}
   }catch{}
   finally{finishPending=false;finish.disabled=false;interruptEnd.disabled=false;organize.disabled=false;}
   if(closed){statusSignature='';updateStatus();return;}
  }
  await completeSaved(id);
 }
 interruptEnd.onclick=recoverInterrupted;organize.onclick=recoverInterrupted;
 const handles={};let stopDrag=()=>{};
 const minimum={left:220,right:260};
 function measured(){
  // 右栏默认按 P1 批准稿为 300px；用户拖动后沿用保存的 widths.ratio。
  // 先定目标宽，再走下面的 budget 收缩，保证窗口变窄时中间至少留 420px、右栏不被截断。
  let wanted=widths.right;
  if(widths.ratio>0)wanted=Math.round(widths.ratio*window.innerWidth);
  else if(!rightChosen)wanted=defaultRightWidth(window.innerWidth);
  wanted=Math.max(minimum.right,Math.min(rightCap(window.innerWidth),wanted));
  const budget=Math.max(0,window.innerWidth-(compact()?280:420));
  const result={left:0,right:state.right?wanted:0};
  if(result.left+result.right>budget){
   const floor=(state.left?minimum.left:0)+(state.right?minimum.right:0);
   if(budget<floor){for(const key of ['left','right'])result[key]=state[key]?budget*minimum[key]/floor:0;}
   else{const extra=budget-floor,total=result.left+result.right-floor;for(const key of ['left','right'])if(state[key])result[key]=Math.floor(minimum[key]+(total?(result[key]-minimum[key])*extra/total:0));}
  }
  if(state.right&&panelFull())result.right=window.innerWidth;
  return result;
 }
 function widthLimit(key){return key==='right'?rightCap(window.innerWidth):maximum[key];}
 function changeWidth(key,delta){const sizes=measured(),other=key==='left'?'right':'left';widths[key]=Math.max(minimum[key],Math.min(widthLimit(key),window.innerWidth-420-sizes[other],sizes[key]+delta));if(key==='right'){widths.ratio=Math.round(widths.right/Math.max(1,window.innerWidth)*1e4)/1e4;rightChosen=true;}layout();}
 function saveWidths(){try{localStorage.setItem('tht-meeting-workspace-widths',JSON.stringify(widths));}catch{}}
 for(const key of ['left','right']){
  const handle=document.createElement('div');handle.className='mw-splitter mw-splitter-'+key;handle.setAttribute('role','separator');handle.setAttribute('aria-orientation','vertical');handle.setAttribute('aria-label',key==='left'?'调整实时转写宽度 / Resize live transcript':'调整上下文背景宽度 / Resize context background');
  handle.onpointerdown=e=>{
   if(handle.hidden||e.button!==0)return;e.preventDefault();stopDrag();let x=e.clientX,id=e.pointerId;
   const stop=()=>{handle.onpointermove=handle.onpointerup=handle.onpointercancel=handle.onlostpointercapture=null;document.body.classList.remove('mw-resizing');try{handle.releasePointerCapture(id);}catch{}saveWidths();stopDrag=()=>{};};
   stopDrag=stop;document.body.classList.add('mw-resizing');
   try{handle.setPointerCapture(id);}catch{stop();return;}
   handle.onpointermove=next=>{const delta=(next.clientX-x)*(key==='right'?-1:1);x=next.clientX;changeWidth(key,delta);};
   handle.onpointerup=handle.onpointercancel=handle.onlostpointercapture=stop;
  };
  handle.onkeydown=e=>{if(handle.hidden||!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();changeWidth(key,(e.key==='ArrowRight'?20:-20)*(key==='right'?-1:1));saveWidths();};
  handles[key]=handle;document.body.append(handle);
 }
 window.addEventListener('blur',()=>stopDrag());
 const notice=document.getElementById('notice');
 const noticeLayer=document.createElement('aside');noticeLayer.className='mw-notice-layer';noticeLayer.hidden=true;noticeLayer.setAttribute('role','region');noticeLayer.setAttribute('aria-label','最近通知');
 const noticeClose=document.createElement('button');noticeClose.type='button';noticeClose.className='mw-notice-close';noticeClose.textContent='×';noticeClose.setAttribute('aria-label','关闭最近通知');noticeClose.onclick=closeNotice;noticeLayer.append(noticeClose);document.body.append(noticeLayer);
 function closeNotice(){noticeLayer.hidden=true;if(notice?.parentElement===noticeLayer)document.body.append(notice);}
 function openNotice(){window.thtRestoreNotice?.();if(!notice)return;noticeLayer.append(notice);noticeLayer.hidden=false;}
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!noticeLayer.hidden)closeNotice();});
 window.addEventListener('tht-meeting-navigating',closeNotice);
 window.addEventListener('tht-notice-change',()=>{if(notice?.hidden)closeNotice();});

 const readyBar=document.getElementById('ready-bar');
 let previousReadyHeight=0;
 const readyLandedSessions=new Set();
 function noticeSpace(){
  const readyBounds=readyBar&&!readyBar.hidden?readyBar.getBoundingClientRect?.():null;
  const readyHeight=Math.ceil(readyBounds?.height||0);
  const homeHeight=document.body.classList.contains('document-home-open')&&notice&&!notice.hidden&&!notice.dataset.meetingId&&notice.parentElement!==noticeLayer?Math.ceil(notice.getBoundingClientRect?.()?.height||0):0;
  const value=(readyHeight+homeHeight)+'px';
  const contentTop=Math.max(52,readyHeight?Math.ceil(readyBounds.bottom):52)+'px';
  document.body.style.setProperty('--mw-content-top',contentTop);
  const sid=curSid||window.thtViewedMeetingId||'',ns=meetingNativeStatus();
  const recording=ns.active||ns.starting||window.thtRecordingMeetingId?.()===sid;
  if(sid&&readyHeight&&!previousReadyHeight&&!readyLandedSessions.has(sid)&&!recording){const feed=panel.querySelector('.ma-feed');if(feed)feed.scrollTop=0;}
  if(sid)readyLandedSessions.add(sid);
  previousReadyHeight=readyHeight;
  document.body.style.setProperty('--mw-notice-height',value);
  frame.contentDocument?.body?.style?.setProperty('--mw-notice-height',value);
 }
 window.addEventListener('tht-notice-change',noticeSpace);
 window.addEventListener('resize',noticeSpace);
 if(notice?.getBoundingClientRect&&typeof ResizeObserver!=='undefined')new ResizeObserver(noticeSpace).observe(notice);
 if(readyBar?.getBoundingClientRect&&typeof ResizeObserver!=='undefined')new ResizeObserver(noticeSpace).observe(readyBar);
 if(readyBar&&typeof MutationObserver!=='undefined')new MutationObserver(noticeSpace).observe(readyBar,{attributes:true,attributeFilter:['hidden']});
 frame.addEventListener('load',noticeSpace);
 noticeSpace();
 let lastLayout='',wasMeeting=false;
 // The conversation column is the workspace centre: an unrelated Escape or toggle
 // must not leave it hidden behind an unchanged layout cache.
 function keepConversation(){const has=(el,c)=>!!el?.classList?.contains?.(c);if(panel.hidden||has(panel,'ma-collapsed')||!has(document.body,'myagent-open')){panel.hidden=false;panel.classList?.remove?.('ma-collapsed');document.body.classList?.add?.('myagent-open');}}
 const transcriptSeconds=value=>{const base=window.ThtMeetingTime.meetingTimestamp(0,transcriptStart),at=window.ThtMeetingTime.meetingTimestamp(value,transcriptStart);return Number.isFinite(at)&&Number.isFinite(base)?Math.max(0,(at-base)/1000):0;};
 const mk=(tag,cls)=>{const n=document.createElement(tag);n.className=cls;return n;};
 if(selectedTab==='report')selectedTab='document';
 const tabButtons={};
 bar.append(spacer);
 for(const [name,zh,en] of [['transcript','完整转写','Transcript'],['document','产出内容','Outputs']]){
  const b=name==='transcript'?transcriptEntry:mk('button','mw-tab-'+name);b.type='button';if(name!=='transcript')b.id='mw-tab-'+name;b.setAttribute('role','tab');b.textContent=document.documentElement.lang==='en'?en:zh;b.setAttribute('aria-controls',name==='document'?'mw-outputs':'mw-transcript-panel');
  b.onclick=()=>{if(name==='transcript'){toggleTranscript();return;}state.right=!(state.right&&selectedTab===name);selectedTab=name;outputSelection='';transcriptReturn=null;closeTopicEntry();savePanel();layout();};
  b.classList.add('ib');b.tabIndex=0;tabButtons[name]=b;bar.append(b);
 }

 // The editor is in a same-origin iframe. Adopt the actual controls so their
 // handlers keep the workspace owner while their layout follows the document.
 const trackedTopics=document.createElement('div');trackedTopics.className='mw-tracked-topics';
 trackedTopics.onclick=e=>{const b=e.target.closest('[data-topic-action]');if(!b)return;e.preventDefault();e.stopPropagation();void window.thtChangeMeetingTopic?.(b.dataset.topicAction,b.dataset.topicId,b.dataset.topicTitle,b);};
 window.thtSetDocumentTopics=html=>{if(trackedTopics.dataset.html===html)return;trackedTopics.innerHTML=html;trackedTopics.dataset.html=html;};
 function mountDocumentActions(){
  const doc=frame.contentDocument,host=doc?.querySelector('.mother-document-footer')||doc?.querySelector('.mother-workspace');
  if(typeof host?.append==='function'&&directActions.parentElement!==host)host.append(directActions);
  // Forms and tracked content are document sections, not rows of footer actions.
  if(host?.matches('.mother-document-footer')&&topicEntry.parentElement!==host.parentElement)host.after(topicEntry,trackedTopics);
 }
 let documentToolsObserver;
 function observeDocumentTools(){
  documentToolsObserver?.disconnect();mountDocumentActions();
  if(frame.contentDocument?.body){documentToolsObserver=new MutationObserver(mountDocumentActions);documentToolsObserver.observe(frame.contentDocument.body,{childList:true,subtree:true});}
 }
 frame.addEventListener('load',observeDocumentTools);observeDocumentTools();
 frame.addEventListener('load',()=>{const label=()=>{topicLabels();syncDocumentActions();};frame.contentWindow?.addEventListener('tht-board-language',()=>queueMicrotask(label));label();});
 frame.addEventListener('load',()=>{frame.contentDocument?.addEventListener('keydown',e=>{if(e.key==='Escape'&&!topicEntry.hidden){e.preventDefault();e.stopImmediatePropagation();closeTopicEntry();topicAction.focus();}},true);});
 const txpanel=mk('section','mw-transcript-panel'),txcount=mk('span','mw-txcount'),txlist=mk('div','mw-txlist'),latest=mk('button','mw-back-latest');
 txpanel.id='mw-transcript-panel';txpanel.setAttribute('role','region');txpanel.setAttribute('aria-labelledby','mw-transcript-entry');txlist.tabIndex=0;txlist.setAttribute('aria-label','逐句转写 / Transcript sentences');
 latest.type='button';latest.hidden=true;roundLatest(latest);
 const txTitle=mk('h2','mw-transcript-title');txTitle.textContent=document.documentElement.lang==='en'?'Transcript':'完整转写';
 txpanel.append(txTitle,txcount,txlist,latest);document.body.append(txpanel);
 const sideHead=mk('header','mw-side-head'),sideLabel=mk('span','mw-side-label'),fold=mk('button','mw-side-fold');
 fold.type='button';fold.innerHTML='<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="3" width="12" height="10" rx="2"/><path d="M10 3v10M5.5 6.5 7.5 8l-2 1.5"/></svg>';
 fold.onclick=closeRight;sideHead.append(sideLabel,fold);document.body.append(sideHead);
 // Output navigation owns presentation only; the same editor remains mounted.
 const outputs=mk('section','mw-outputs'),outputList=mk('div','mw-output-list'),outputEmpty=mk('p','mw-output-empty'),outputBack=mk('button','mw-output-back'),outputDetail=mk('article','mw-output-detail'),outputTitle=mk('h4','mw-output-title'),outputBody=mk('div','mw-output-body');
 outputs.id='mw-outputs';outputs.setAttribute('role','region');outputs.setAttribute('aria-labelledby','mw-tab-document');
 outputBack.type='button';outputDetail.append(outputTitle,outputBody);outputs.append(outputBack,outputList,outputEmpty,outputDetail);document.body.append(outputs);
 const liveOutputs=mk('div','lr-scope');outputList.append(liveOutputs);window.thtLiveResearch?.bind(liveOutputs);window.thtLiveResearch?.bind(outputBody);
 let outputLive=window.thtLiveResearch?.data()||null;
 let outputSelection='',outputDocument=null,outputReport=null,outputMeeting='',outputSignature='';
 const outputText=(zh,en)=>document.documentElement.lang==='en'?en:zh;
 function outputItems(){
  const rows=[];
  if(outputDocument?.id&&outputDocument.hasContent!==false)rows.push({id:'document',kind:'document',title:outputDocument.title||outputText('方案文档','Solution document'),label:outputText('方案文档 · 随会议更新','Solution document · Updated with the meeting')});
  for(const r of outputReport?.researchResults||[])if(r.text?.trim())rows.push({...r,id:'research:'+r.id,kind:'research',label:outputText('深度研究结果','Deep research result')});
  const seen=new Set();
  for(const a of [...(outputReport?.myActions||[]),...(outputReport?.items||[])]){
   const versions=(a.draft?.versions||[]).filter(v=>v.markdown?.trim()),v=versions.at(-1),key=a.id||a.action?.do||a.do||a.text;
   if(!v||seen.has(key))continue;seen.add(key);
   rows.push({id:'draft:'+key,kind:'draft',title:a.do||a.action?.do||a.text||outputText('替我做的草稿','Draft prepared for me'),label:outputText('替我做的草稿','Draft prepared for me'),text:v.markdown});
  }
  return rows;
 }
 const outputIcons={document:'<path d="M4 2.5h6.5L14 6v9.5H4zM6.5 9h5M6.5 12h5"/>',research:'<path fill="currentColor" stroke="none" d="M9 1.5l1.7 5.8 5.8 1.7-5.8 1.7L9 16.5l-1.7-5.8L1.5 9l5.8-1.7z"/>',draft:'<path d="M3 15l1-3.5L12.5 3l2.5 2.5L6.5 14z"/>'};
 function paintOutputs(){
  const liveId=outputSelection.startsWith('live:')?outputSelection.slice(5):'',liveItem=outputLive?.items?.find(i=>i.id===liveId);
  const rows=outputItems(),en=document.documentElement.lang==='en',item=rows.find(r=>r.id===outputSelection)||(outputSelection==='document'&&outputDocument?.id?{...outputDocument,id:'document',kind:'document'}:null);
  const liveContent=!!outputLive&&((outputLive.items||[]).length>0||['discussion','conclusions','todos'].some(k=>(outputLive.minutes?.[k]||[]).length>0));
  if(!item&&!liveItem)outputSelection='';
  const signature=JSON.stringify([rows,en,outputSelection,outputLive,window.thtLiveResearch?.state?.()?.deletedTodo||'']);
  if(signature!==outputSignature){outputSignature=signature;
   outputList.replaceChildren(...rows.map(row=>{
    const b=mk('button','mw-output-item'),icon=mk('span','mw-output-icon '+row.kind),copy=mk('span','mw-output-copy'),name=mk('b','mw-output-name'),label=mk('small','mw-output-kind');
    b.type='button';b.dataset.kind=row.kind;b.dataset.outputId=row.id;
    icon.setAttribute('aria-hidden','true');icon.innerHTML='<svg viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'+outputIcons[row.kind]+'</svg>';
    name.textContent=row.title||row.text.split('\n')[0];label.textContent=row.label;b.title=name.textContent;copy.append(name,label);b.append(icon,copy);b.onclick=()=>{outputSelection=row.id;outputs.scrollTop=0;layout(true);};return b;
   }));
   if(liveContent){liveOutputs.innerHTML=window.ThtLiveResearch.outputHtml(outputLive,window.thtLiveResearch?.state?.()||{});outputList.prepend(liveOutputs);}else liveOutputs.innerHTML='';
   outputTitle.textContent=liveItem?'':item?.title||'';
   if(!liveItem)delete outputBody.dataset.lrSignature;
   if(liveItem)window.thtLiveResearch.renderReport(outputBody,liveId);else if(item?.kind==='research'&&window.ThtSafeMarkdown){outputBody.innerHTML=window.ThtSafeMarkdown.markdown(item.text||'');}else outputBody.textContent=item?.text||'';

  }
  outputEmpty.textContent=outputText('这场会还没有产出内容。','No outputs from this meeting yet.');
  outputBack.textContent=outputText('‹ 全部产出','‹ All outputs');outputBack.hidden=!!liveItem||!item;
  outputList.hidden=!!item||!!liveItem;outputEmpty.hidden=!!rows.length||!!item||liveContent;outputDetail.hidden=(!item&&!liveItem)||item?.kind==='document';
  const open=active()&&state.right&&selectedTab==='document',editor=open&&item?.kind==='document';
  outputs.hidden=!open;outputs.classList.toggle('mw-outputs-editor',!!editor);
  document.body.classList.toggle('mw-output-editor',!!editor);document.body.classList.toggle('mw-output-browser',!!(open&&!editor));
 }
 outputBack.onclick=()=>{const previous=outputSelection;outputSelection='';outputs.scrollTop=0;layout(true);outputList.children&&[...outputList.children].find(b=>b.dataset.outputId===previous)?.focus?.();};
 function clearOutputs(){outputLive=null;outputDocument=null;outputReport=null;outputSelection='';outputMeeting='';paintOutputs();}
 window.addEventListener('tht-meeting-navigating',clearOutputs);
 window.addEventListener('tht-proactive-data',e=>{const d=e.detail||{},id=d.id||d.session?.id;if(!id||id!==window.thtViewedMeetingId||d.session?.id&&d.session.id!==id)return;
  if(outputMeeting&&outputMeeting!==id)clearOutputs();outputMeeting=id;
  if(d.source?.motherDocumentId&&outputDocument?.id!==d.source.motherDocumentId)outputDocument={id:d.source.motherDocumentId,title:d.source.title||d.session?.title||''};
  paintOutputs();
 });
 window.thtOpenResearchReport=id=>{outputSelection='live:'+id;selectedTab='document';state.right=true;savePanel();layout(true);};
 window.thtCloseResearchReport=()=>{outputSelection='';layout(true);};
 window.addEventListener('tht-live-research-updated',e=>{if(e.detail?.id!==window.thtViewedMeetingId)return;outputLive=e.detail;paintOutputs();});
 window.addEventListener('tht-report-updated',e=>{const d=e.detail||{};if(!d.id||d.id!==window.thtViewedMeetingId)return;outputReport=d.report;paintOutputs();});
 window.addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow||e.data?.type!=='tht-output-document'||e.data.meetingId!==window.thtViewedMeetingId)return;outputDocument=e.data.document;paintOutputs();});
 let txSig='',following=true,highlightTimer=0;
 let txSession='',txPartial=null,txFinals=[],txNodes=[],txLines=[],txRowNodes=[];
 const txSpeaker=row=>String(row?.speaker??row?.spk??row?.who??'');
 const txSegment=row=>String(row?.id??row?.seg??row?.segId??'');
 function clearTxPartial(){if(!txPartial)return;txPartial=null;fillTx();}
 function savePanel(){preferred.right=state.right;explicitRight=true;try{localStorage.setItem('tht-meeting-workspace-panels',JSON.stringify({right:state.right,tab:selectedTab}));}catch{}}
 function closeRight(){stopDrag();state.right=false;transcriptReturn=null;savePanel();layout();tabButtons[selectedTab]?.focus?.();}

 function toLatest(){following=true;latest.hidden=true;txlist.scrollTop=txlist.scrollHeight;}
 txlist.onscroll=()=>{following=txlist.scrollHeight-txlist.scrollTop-txlist.clientHeight<40;latest.hidden=following;};latest.onclick=toLatest;
 function openTranscript(at){
  if(!(state.right&&selectedTab==='transcript'))transcriptReturn={right:state.right,tab:selectedTab};
  selectedTab='transcript';state.right=true;savePanel();layout();fillTx();
  if(at===undefined){toLatest();return;}
  const seconds=transcriptSeconds(at);let index=transcriptRows.findIndex((r,i)=>seconds>=transcriptSeconds(r.atSec??r.t??r.at)&&(i===transcriptRows.length-1||seconds<transcriptSeconds(transcriptRows[i+1].atSec??transcriptRows[i+1].t??transcriptRows[i+1].at)));
  if(index<0&&transcriptRows.length)index=0;
  const row=txRowNodes[index];if(!row)return;
  following=false;latest.hidden=false;row.scrollIntoView?.({block:'center'});clearTimeout(highlightTimer);
  for(const n of txlist.children)n.classList.remove('mw-source-highlight');row.classList.add('mw-source-highlight');highlightTimer=setTimeout(()=>row.classList.remove('mw-source-highlight'),2000);
 }
 function toggleTranscript(){if(state.right&&selectedTab==='transcript'){const previous=transcriptReturn||{right:true,tab:'document'};state.right=previous.right;selectedTab=previous.tab;transcriptReturn=null;savePanel();layout();}else openTranscript();}
 window.thtOpenTranscript=openTranscript;
 // Render the source transcript, even while its old iframe panel is folded.
 function transcriptClock(value){return window.ThtMeetingTime.meetingClock(value,transcriptStart);}
 function transcriptSpeaker(row,rows,names,en){
  const key=String(row.speaker??row.spk??row.who??'');
  const name=names?.[key]||row.speakerIdentity?.name;
  if(typeof name==='string'&&name.trim()&&!/^(?:vp-)?[a-f0-9-]{32,}$/i.test(name.trim())&&!/^\d+$/.test(name.trim()))return name.trim();
  const fixed=window.ThtSpeakerLabels.defaults(en,window.__roomMode);
  if(Object.hasOwn(fixed,key))return fixed[key];
  if(!key.trim())return '';
  const ids=[...new Set(rows.map(r=>String(r.speaker??r.spk??r.who??'')).filter(id=>id.trim()&&!Object.hasOwn(fixed,id)))];
  return (en?'Speaker ':'说话人 ')+(ids.indexOf(key)<0?'?':ids.indexOf(key)+1);
 }
 // Reconcile sentence nodes in place. Live finals occupy their future source
 // index until the authoritative snapshot arrives; they never enter stored data.
 function fillTx(){
  const en=document.documentElement.lang==='en';
  txFinals=txFinals.filter(item=>item.index>=transcriptRows.length);
  const rows=[...transcriptRows,...txFinals.map(item=>item.row)];
  if(txPartial)rows.push(txPartial);
  const sig=JSON.stringify([txSession,rows,transcriptNames,en]);if(sig===txSig)return;txSig=sig;
  const oldScroll=txlist.scrollTop;
  const count=transcriptRows.length+txFinals.length;
  const countText=count?(en?count+' lines':count+' 句'):'';if(txcount.textContent!==countText)txcount.textContent=countText;
  if(!rows.length){for(const line of txLines)line.node.remove();txLines=[];txNodes=[];txRowNodes=[];if(!txlist.children.length){const p=mk('p','mw-txempty');p.textContent=en?'Nothing transcribed yet.':'还没有转写';txlist.append(p);}return;}
  if(!txLines.length)txlist.replaceChildren();
  let group=-1,offset=0,previous='';txRowNodes=[];
  rows.forEach((row,i)=>{
   const partial=row===txPartial,key=txSpeaker(row);
   if(i===0||!key||key!==previous){group++;offset=0;}
   previous=key;
   let line=txLines[group];
   if(!line){const node=mk('div','mw-ln'),label=mk('span','mw-lt'),body=document.createElement('p');node.append(label,body);line={node,label,body};txLines.push(line);txlist.append(node);}
   if(i===0||txRowNodes[i-1]!==line.node){const label=[transcriptClock(row.at??row.atSec??row.t),transcriptSpeaker(row,rows,transcriptNames,en)].filter(Boolean).join(' · ');if(line.label.textContent!==label)line.label.textContent=label;}
   let text=txNodes[i];if(!text){text=document.createElement('span');txNodes.push(text);}
   const value=(txRowNodes[i-1]===line.node?' ':'')+(frame.contentWindow?.thtProfileDisplay?.(row.text||'')??(row.text||''));
   if(text.textContent!==value)text.textContent=value;
   const cls=partial?'mw-txpartial':'';if(text.className!==cls)text.className=cls;
   if(line.body.children[offset]!==text)line.body.insertBefore(text,line.body.children[offset]||null);offset++;
   txRowNodes.push(line.node);
  });
  while(txNodes.length>rows.length)txNodes.pop().remove();
  while(txLines.length>group+1)txLines.pop().node.remove();
  if(following)toLatest();else{txlist.scrollTop=oldScroll;latest.hidden=false;}
 }
 function paintPanel(on){const open=!!(on&&state.right),transcript=open&&selectedTab==='transcript';
  transcriptEntry.hidden=false;directActions.hidden=selectedTab!=='document';if(selectedTab!=='document'||!open)closeTopicEntry();
  mountDocumentActions();txpanel.hidden=!transcript;document.body.classList.toggle('mw-transcript-visible',transcript);
  for(const [name,b] of Object.entries(tabButtons)){b.setAttribute('aria-selected',String(open&&selectedTab===name));b.setAttribute('aria-pressed',String(open&&selectedTab===name));b.textContent=document.documentElement.lang==='en'?(name==='transcript'?'Transcript':'Outputs'):(name==='transcript'?'完整转写':'产出内容');b.setAttribute('aria-label',b.textContent);b.tabIndex=0;}
  paintOutputs();sideHead.hidden=!open;sideLabel.textContent=tabButtons[selectedTab]?.textContent||'';fold.setAttribute('aria-label',document.documentElement.lang==='en'?'Collapse sidebar':'收起侧栏');fold.title=document.documentElement.lang==='en'?'Collapse sidebar':'收起侧栏';
  if(open)fillTx();updateSubtitle();
 }
 live.tabIndex=0;live.setAttribute('role','button');live.title='打开完整转写（T）';live.onclick=()=>openTranscript();live.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openTranscript();}};
 // One owner for the optional report and existing document/transcript bay.
 window.thtMeetingPanel={getState:()=>({open:active()&&state.right,view:selectedTab}),show:view=>{
  if(!active()||!['document','report'].includes(view))return false;
  stopDrag();selectedTab='document';outputSelection=view==='report'?(outputItems().find(i=>i.kind==='research')?.id||''):'document';state.right=true;transcriptReturn=null;savePanel();layout();return true;
 }};
 window.thtMeetingSid=()=>active()?curSid:'';
 const loading=mk('div','mw-loading');loading.hidden=true;loading.setAttribute('role','status');document.body.append(loading);
 let meetingLoadTimer=0,loadingMeeting='';
 function waitForMeeting(){
  clearTimeout(meetingLoadTimer);
  meetingLoadTimer=setTimeout(()=>{
   if(loading.hidden||loadingMeeting!==window.thtViewedMeetingId)return;
   loading.dataset.state='failed';title.textContent=document.documentElement.lang==='en'?'Could not open meeting':'会议未能打开';
   loading.textContent=document.documentElement.lang==='en'?'Could not open meeting.':'会议暂时未能打开。';
   const retry=mk('button','mw-load-retry'),home=mk('button','mw-load-home');retry.type=home.type='button';
   retry.textContent=document.documentElement.lang==='en'?'Retry':'重试';home.textContent=document.documentElement.lang==='en'?'Back to home':'返回首页';
   retry.onclick=()=>{loading.dataset.state='loading';title.textContent=document.documentElement.lang==='en'?'Loading…':'正在打开…';loading.textContent=document.documentElement.lang==='en'?'Opening meeting…':'正在打开会议…';window.thtOpenMeeting?.(loadingMeeting);waitForMeeting();};
   home.onclick=()=>{clearTimeout(meetingLoadTimer);loading.hidden=true;document.querySelector('.dh-home-toggle')?.click();};loading.append(retry,home);
  },18000);
 }
 window.addEventListener('tht-meeting-navigating',()=>{loadingMeeting=window.thtViewedMeetingId;loading.dataset.state='loading';waitForMeeting();loading.textContent=document.documentElement.lang==='en'?'Opening meeting…':'正在打开会议…';loading.hidden=false;liveTranscript=null;transcriptRows=[];txPartial=null;txFinals=[];txSession='';following=true;transcriptReturn=null;curSid='';ended=null;recordingSnapshot=null;sourceError='';retryFailed=false;title.textContent=document.documentElement.lang==='en'?'Loading…':'正在打开…';live.textContent='';live.hidden=true;txSig='';fillTx();});
 window.addEventListener('tht-profile-updated',()=>{txSig='';live.dataset.k='';fillTx();updateSubtitle();});
 function viewedSnapshot(data){const id=data?.session?.id;return !!id&&(!window.thtViewedMeetingId||id===window.thtViewedMeetingId)&&(!data.id||data.id===id);}
 window.addEventListener('tht-proactive-data',e=>{if(!viewedSnapshot(e.detail))return;clearTimeout(meetingLoadTimer);loading.hidden=true;const sid=String(e.detail.session?.id||'');if(sid!==txSession){txSession=sid;txPartial=null;txFinals=[];txlist.replaceChildren();txNodes=[];txLines=[];txRowNodes=[];}transcriptStart=e.detail.session?.start??e.detail.session?.startTs;transcriptNames=e.detail.session?.names||{};transcriptRows=e.detail.session?.fullTranscript||e.detail.session?.transcript||[];txSig='';fillTx();updateSubtitle();});
 document.addEventListener('keydown',e=>{if(!active()||e.defaultPrevented||e.metaKey||e.ctrlKey||e.altKey)return;
  const t=e.target;if(t&&(t.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName||'')))return;if(document.querySelector('dialog[open]'))return;
  if(e.key==='Escape'&&ended&&recmenu.hidden){e.preventDefault();homeBack.click();return;}
  if(e.key==='Escape'&&state.right){if(!recmenu.hidden)return;e.preventDefault();closeRight();return;}
  // Esc peels one layer at a time: menus, then the right panel, then back to home.
  if(e.key==='Escape'){if(!recmenu.hidden||document.querySelector('details[open],.ma-add-menu'))return;const home=document.querySelector('.dh-home-toggle');if(!home||home.hidden)return;e.preventDefault();home.click();return;}
  if((e.key==='t'||e.key==='T')&&!e.repeat){e.preventDefault();toggleTranscript();return;}
 });
 // Keyboard events from the document iframe do not bubble into the workspace.
 window.addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow)return;if(e.data?.type==='tht-panel-key'){if(e.data.key==='Escape'){if(ended)homeBack.click();else closeRight();}else if(e.data.key==='t')toggleTranscript();}if(e.data?.type==='tht-panel-transcript')openTranscript(e.data.at);});

 function layout(force=false){
  if(active())keepConversation();
  const on=active(),sizes=measured(),key=JSON.stringify([on,selectedTab,outputSelection,state.right,sizes.left,sizes.right,window.innerWidth,document.body.className]);if(!force&&lastLayout===key)return;lastLayout=key;document.body.classList.toggle('meeting-workspace',on);const leaving=wasMeeting&&!on;wasMeeting=on;if(leaving)window.myAgentClose?.();bar.hidden=!on;{const ta=document.querySelector('.ma-shared-form textarea'),en=document.documentElement.lang==='en';if(ta)ta.placeholder=on?(en?'Ask about this meeting, or have me do something…':'就本次会议提问，或让我去做…'):(en?'Ask across meetings and docs, or have me do something…':'问所有会议和文档，或让我去做…');}
  if(!on)closeNotice();if(!on||compact())stopDrag();
  const float=on&&state.right&&panelFull();document.body.classList.toggle('mw-panel-full',float);
  for(const side of ['left','right']){
   document.body.style.setProperty('--mw-'+side,sizes[side]+'px');
   const handle=handles[side];handle.hidden=!on||compact()||!state[side]||(side==='left')||(side==='right'&&float);handle.tabIndex=handle.hidden?-1:0;
   handle.setAttribute('aria-valuemin',String(minimum[side]));handle.setAttribute('aria-valuemax',String(Math.min(widthLimit(side),window.innerWidth-420-sizes[side==='left'?'right':'left'])));handle.setAttribute('aria-valuenow',String(Math.round(sizes[side])));
  }
  const en=document.documentElement?.lang==='en';
  document.body.classList.add('mw-left-closed');document.body.classList.toggle('mw-right-closed',!state.right);
  buttons.right.setAttribute('aria-expanded',String(state.right));buttons.right.setAttribute('aria-label',en?'Toggle meeting panel':'开关会议面板');buttons.right.title=en?'Meeting panel':'会议面板';
  homeBack.setAttribute('aria-label',en?'Back to home':'返回首页');homeBack.title=en?'Back to home':'返回首页';
  rightText.hidden=true;buttons.right.setAttribute('aria-pressed',String(on&&state.right));
  if(on){panel.hidden=false;panel.classList.remove('ma-collapsed');document.body.classList.add('myagent-open');}
  paintPanel(on);
  frame.contentWindow?.postMessage({type:'tht-workspace-layout',enabled:on,left:false,right:state.right&&selectedTab==='document',outputDetail:outputSelection==='document',float,widths:sizes},location.origin);
  window.thtLiveReport?.syncPanel?.();
  noticeSpace();
 }
 window.addEventListener('tht-language-change',()=>{const en=document.documentElement.lang==='en';transcriptEntry.textContent=en?'Transcript':'完整转写';settingsEntry.textContent=en?'Settings':'设置';tabButtons.document.textContent=en?'Outputs':'产出内容';layout(true);fillTx();updateStatus();});
 window.addEventListener('resize',()=>{stopDrag();const next=sizeMode();if(next!==currentSize){currentSize=next;adaptSize();}layout();});
 frame.addEventListener('load',()=>{layout(true);window.thtPostmeeting?.relocateTasks?.();window.thtLiveReport?.paint?.();});
 // Reuse the existing right document pane rather than introducing another panel.
 window.thtMeetingTasksHost=()=>{
  const doc=frame.contentDocument,box=doc?.querySelector('.mother-workspace');if(!box)return null;
  let tasks=box.querySelector('.pm-meeting-tasks');if(!tasks){tasks=doc.createElement('section');tasks.className='pm-meeting-tasks';box.insertBefore(tasks,box.querySelector('.mother-editor'));}
  const live=box.querySelector('.meeting-todos');if(live)live.hidden=true;
  return tasks;
 };
 // A title copied verbatim into the first paragraph is displayed once. Nothing is
 // removed from the candidate or stored document; changed wording remains visible.
 function presentInsights(){
  const watching=panel._insightWatch;
  if(watching&&typeof watching.disconnect==='function')watching.disconnect();
  try{presentInsightPass();}finally{if(watching&&typeof watching.observe==='function')watching.observe(panel,{childList:true,subtree:true});}
  function presentInsightPass(){
  const openEvidence=panel._openEvidence||(panel._openEvidence=new Map());
  const arrivals=panel._feedArrivals||(panel._feedArrivals=new Set());
  const evidenceLabel=document.documentElement&&document.documentElement.lang==='en'?'Evidence':'依据';
  const leadPlain=lead=>{
   const nodes=lead.childNodes;
   if(nodes&&nodes.length)return [...nodes].filter(n=>n.nodeType===3||(n.nodeType===1&&n.className!=='mw-insight-time'&&n.className!=='mw-quote')).map(n=>n.textContent||'').join('').trim();
   return String(lead.textContent||'').trim();
  };
  const quoteOf=text=>{
   const raw=String(text||'').trim();
   if(!raw||/^(?:引用原文暂未载入|Source excerpt not loaded)/.test(raw))return '';
   const stamp=raw.match(/^(\d+:\d{2}(?::\d{2})?) · /);if(!stamp)return '';
   const hm=stamp[1].split(':').slice(0,2).join(':'),parts=raw.split(' · ');
   const spoken=(parts.length>=3?parts.slice(2):parts.slice(1)).join(' · ').trim();
   if(!spoken||/^(?:引用原文暂未载入|Source excerpt not loaded)/.test(spoken))return '';
   return hm+' 「'+spoken+'」';
  };
  for(const card of panel.querySelectorAll('.ma-insight')){
   const heading=card.querySelector(':scope > strong'),lead=card.querySelector(':scope > div .ma-answer > p:first-child');
   if(!heading)continue;
   const title=[...heading.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
   if(lead)lead.classList.toggle('mw-duplicate-lead',!!title&&leadPlain(lead)===title);
   const evidenceHost=card.querySelector('.mw-send-head')?.parentElement||(typeof lead?.append==='function'?lead:card);
   const source=[...card.querySelectorAll(':scope > div .ma-insight-sources > p')].find(source=>/^(\d+:\d{2}(?::\d{2})?) · /.test(source.textContent));
   const quoteText=quoteOf(source?.textContent),cid=card.dataset&&card.dataset.candidateId||'';
   if(cid&&!arrivals.has(curSid+'\n'+cid)){arrivals.add(curSid+'\n'+cid);card.classList.add('mw-arrive');if(['insight','background','verification'].includes(card.dataset.kind))card.classList.add('mw-spark-arrive');}
   let time=card.querySelector('.mw-insight-time');
   if(!time&&card.children)time=[...card.children].find(n=>n.className==='mw-insight-time')||null;
   if(quoteText&&!time){time=document.createElement('button');time.type='button';time.className='mw-insight-time';evidenceHost.append(time);}
   if(time&&quoteText){
    time.disabled=false;time.hidden=false;
    time.onclick=()=>{
     const shown=quoteOf(source?.textContent);if(!shown)return;
     let quote=card.querySelector('.mw-quote');if(!quote&&card.children)quote=[...card.children].find(n=>n.className==='mw-quote')||null;
     const key=cid||shown;
     if(quote){quote.hidden=!quote.hidden;if(quote.hidden){openEvidence.delete(key);return;}if(quote.textContent!==shown)quote.textContent=shown;openEvidence.set(key,true);return;}
     quote=document.createElement('p');quote.className='mw-quote';quote.textContent=shown;evidenceHost.append(quote);openEvidence.set(key,true);
    };
    if(time.textContent!==evidenceLabel)time.textContent=evidenceLabel;time.setAttribute('aria-label',evidenceLabel);
    if(cid&&openEvidence.get(cid)){let quote=card.querySelector('.mw-quote');if(!quote&&card.children)quote=[...card.children].find(n=>n.className==='mw-quote')||null;if(!quote){quote=document.createElement('p');quote.className='mw-quote';quote.textContent=quoteText;evidenceHost.append(quote);}else{quote.hidden=false;if(quote.textContent!==quoteText)quote.textContent=quoteText;}}
   }else if(time){time.hidden=true;time.disabled=true;time.onclick=null;if(time.textContent)time.textContent='';if(cid)openEvidence.delete(cid);const stale=card.querySelector('.mw-quote');if(stale)stale.hidden=true;}
   card.classList.toggle('mw-has-time',!!quoteText);
  }
  }
 }
 if(panel.querySelectorAll){presentInsights();const insightWatch=new MutationObserver(()=>presentInsights());panel._insightWatch=insightWatch;insightWatch.observe(panel,{childList:true,subtree:true});}
 new MutationObserver(()=>layout()).observe(document.body,{attributes:true,attributeFilter:['class']});
 new MutationObserver(()=>layout()).observe(frame,{attributes:true,attributeFilter:['hidden']});
 new MutationObserver(()=>{if(active())keepConversation();}).observe(panel,{attributes:true,attributeFilter:['hidden','class']});
 // Do not move or recreate the composer, editor or conversation when panels fold.
 window.addEventListener('tht-proactive-data',e=>{if(!viewedSnapshot(e.detail))return;const data=e.detail;{const name=String(data.meetingTitle||data.session?.topicTitle||data.session?.title||data.source?.title||'').trim();const named=!!name&&!/^未命名(笔记|会议)?$|^untitled|^过短会话$|^short session$/i.test(name),en=document.documentElement.lang==='en';const project=String(data.projects?.find(p=>p.id===data.source?.projectId)?.title||data.project?.title||data.project?.name||data.projectTitle||data.session?.projectTitle||'').trim();title.textContent=[project,named?name:(en?'New meeting':'新会议')].filter(Boolean).join(' · ');title.title=title.textContent;
  // v5 会后（design-final）：结束的会标题前 ✦（会后按内容起的名），副标题换成「· 10-25 10:30 · 41 分钟」，顶栏 pill 显示时长 + 已结束。
  const stamp=v=>typeof v==='number'?v:Date.parse(v||''),st=stamp(data.session?.start),en2=stamp(data.session?.end);ended=Number.isFinite(en2)?{start:st,end:en2}:null;
  // r7 原型 final.html 会后：标题不加 ✦、不加日期副标题，只靠 pill「mm:ss 已结束」表达结束。
  const nextSid=String(data.session?.id||'');if(nextSid!==curSid){sourceError='';retryFailed=false;}if(data.session&&nextSid)recordingSnapshot={...(recordingSnapshot?.id===nextSid?recordingSnapshot:{}),...data.session};if(nextSid!==curSid&&ended&&panelFull()){selectedTab='transcript';state.right=true;transcriptReturn=null;}curSid=nextSid;statusSignature='';layout();sub.hidden=true;sub.textContent='';}});
 window.addEventListener('tht-live-transcript',e=>{
  if(e.detail?.sessionId!==window.thtRecordingMeetingId?.()||e.detail.sessionId!==curSid)return;
  const m=e.detail;
  if(m.type==='final'&&txSegment(m)&&[...transcriptRows,...txFinals.map(item=>item.row)].some(row=>txSegment(row)===txSegment(m)))return;
  if(m.type==='partial'){
   const last=txFinals.at(-1)?.row||transcriptRows.at(-1);
   txPartial=String(m.text||'').trim()?{...m,speaker:txSpeaker(m)||txSpeaker(last),at:m.at??last?.at??Date.now()}:null;
  }else if(m.type==='final'){
   if(String(m.text||'').trim())txFinals.push({index:transcriptRows.length+txFinals.length,row:{...m,speaker:txSpeaker(m)||txSpeaker(txPartial),at:m.at??txPartial?.at??Date.now()}});
   txPartial=null;
  }
  liveTranscript=m;fillTx();updateSubtitle();
 });
 const subtitleStarts=new Map(),firstWords=new Set();
 function liveWaveHeights(level){const n=Math.max(0,Math.min(1,Number(level)||0));return [0.45,1,0.7].map(weight=>Math.round(6+n*10*weight));}
 function pillWaveHeights(level){const n=Math.min(1,2*Math.sqrt(Math.max(0,Math.min(1,Number(level)||0))));return [0.3,0.55,0.8,0.6,1,0.7,0.9,0.5,0.75,0.45,0.3].map(weight=>Math.round(3+n*15*weight));}
 function paintPillWave(){const wave=pill.querySelector?.('.mw-wave');if(!wave)return;const moving=controlState==='rec'||controlState==='asr',level=moving?Math.max(Number(meetingNativeStatus().audioLevel)||0,Number(window.thtBrowserAudioLevel)||0,window.thtWorkspaceAudio?.active?Number(window.thtWorkspaceAudio.level)||0:0):0;wave.querySelectorAll('i').forEach((bar,i)=>{const height=pillWaveHeights(level)[i];if(height!=null)bar.style.height=height+'px';});}
 window.addEventListener('tht-workspace-audio',paintPillWave);window.addEventListener('tht-asr-status',e=>{if(e.detail?.sessionId===curSid&&e.detail.asrStatus){if(['blocked','retrying','disconnected','error','closed'].includes(e.detail.asrStatus.state))clearTxPartial();window.thtNativeStatus={...window.thtNativeStatus,asrStatus:e.detail.asrStatus};statusSignature='';}});
 window.addEventListener('tht-recording-started',e=>{const id=e.detail?.id;if(id){subtitleStarts.set(id,performance.now());firstWords.delete(id);liveTranscript=null;clearTxPartial();}updateSubtitle();});
 function updateSubtitle(){
  const fd=frame.contentDocument,el=fd?.querySelector('.surface-elapsed'),status=fd?.querySelector('.surface-audio-status'),st=status?.dataset?.state,pc=window.thtPauseControl?.state?.(),u=liveTranscript?.sessionId===curSid?liveTranscript:transcriptRows.at(-1),txt=u?.text?.trim()||'';
  const recordingId=window.thtRecordingMeetingId?.()||'',starting=st==='starting'||!!meetingNativeStatus().starting;
  const recording=!!recordingId||starting||!!el?.classList.contains('recording');
  if(recordingId&&!subtitleStarts.has(recordingId))subtitleStarts.set(recordingId,window.thtRecordingStartMono?.()??performance.now());
  live.hidden=!loading.hidden||!!(recordingId&&curSid!==recordingId)||!active()||!recording||!!pc?.paused||st==='paused'||(state.right&&selectedTab==='transcript');
  const text=txt||(document.documentElement.lang==='en'?'Listening…':'正在听…');
  const key=curSid+'\n'+text;
  const d=u?.latencyDiagnostic,latencyKey=d?d.key+':'+d.seq:'';
  const changed=live.dataset.k!==key||(!live.hidden&&(live.dataset.latencyKey!==latencyKey||(u?.type==='partial'&&!firstWords.has(curSid))));
  const level=Math.max(Number(window.thtNativeStatus?.audioLevel)||0,Number(window.thtBrowserAudioLevel)||0);
  if(changed){live.dataset.k=key;live.replaceChildren();const wave=mk('span','mw-lv');wave.setAttribute('aria-hidden','true');for(const height of liveWaveHeights(level)){const bar=mk('i','');bar.style.height=height+'px';wave.append(bar);}live.append(wave);const t=mk('span','mw-ltxt');t.textContent=frame.contentWindow?.thtProfileDisplay?.(text) ?? text;live.append(t);}
  live.querySelectorAll('.mw-lv i').forEach((bar,i)=>{const height=liveWaveHeights(level)[i];if(height!=null)bar.style.height=height+'px';});
  live.classList.toggle('mw-has-line',!!txt);
  if(txt&&!live.hidden&&changed){
   const now=performance.now(),received=d&&window.ThtLatency?.snapshot(curSid).find(r=>r.key===d.key&&r.seq===d.seq&&r.stage==='partial_receive');
   if(d)window.ThtLatency?.mark(curSid,d.key,'dom_update',{seq:d.seq,...(received?{receiveToDomMs:now-received.monoMs}:{})});
   if(u?.type==='partial'&&!firstWords.has(curSid)&&subtitleStarts.has(curSid)){
    window.ThtLatency?.mark(curSid,d?.key||curSid+':first-word','first_word',{seq:d?.seq,startToDomMs:now-subtitleStarts.get(curSid)});firstWords.add(curSid);
   }
   live.dataset.latencyKey=latencyKey;
  }
 }
 let statusSignature='';
 function updateStatus(){topicLabels();syncDocumentActions();const el=frame.contentDocument?.querySelector('.surface-elapsed'),status=frame.contentDocument?.querySelector('.surface-audio-status'),st=status?.dataset?.state;const rawNative=window.thtNativeStatus||{},recordingId=window.thtRecordingMeetingId?.()||(rawNative.starting?rawNative.pendingSessionId:rawNative.active?rawNative.sessionId:'')||'',foreign=!!(curSid&&recordingId&&recordingId!==curSid),captureIdle=rawNative.active===false&&!rawNative.starting&&!recordingId,showing=!captureIdle&&!foreign&&!!el&&(!!el.classList.contains('recording')||['starting','sound','quiet','paused','waiting','disconnected'].includes(st));const ns=meetingNativeStatus(),heard=!!ns.active&&(Number(ns.audioSeconds)>0||Number(ns.audioLevel)>0||(ns.recentTranscript||[]).some(row=>String(row?.text||'').trim())),captureConnected=!!ns.captureReady||heard,interrupted=meetingInterrupted(st);if(txPartial&&(foreign||ended||window.thtPauseControl?.state?.()?.paused||st==='paused'||interrupted||['disconnected','error','failed','ended'].includes(st)||['blocked','retrying','disconnected','error','closed'].includes(ns.asrStatus?.state)||(!recordingId&&!ns.active&&!showing)))clearTxPartial();const signature=JSON.stringify([showing,captureIdle,window.thtRecordingMeetingId?.(),ns.starting,ns.active,ns.captureReady,heard,ns.sessionId,ns.captureRecovery,healthName(ns.captureHealth),ns.error,ns.captureMode,ns.asrStatus,sourceError,retryFailed,st,interrupted,window.thtNativeLinkDown,window.thtTranscriptionInterrupted,audioHealth,window.thtPauseControl?.state?.(),ended,curSid,finishedId,active(),document.documentElement.lang,window.thtLiveReport?.state?.notion,document.getElementById('stop')?.disabled,document.getElementById('b-native')?.hidden]);if(signature===statusSignature){paintPillWave();return;}statusSignature=signature;interruptVisible=interrupted;const owned=window.thtRecordingMeetingId?.()===curSid||ns.sessionId===curSid,openMeeting=!!curSid&&!ended&&active()&&curSid!==finishedId;finish.hidden=!openMeeting||owned;const showPair=openMeeting&&(!owned||interrupted);interruptEnd.hidden=organize.hidden=!showPair;const en=document.documentElement?.lang==='en';source.setAttribute('aria-label',en?'Recording options':'录音选项');recmenu.setAttribute('aria-label',en?'Recording options':'录音选项');finish.textContent=en?'End & organize':'结束并整理';interruptEnd.textContent=en?'End meeting':'结束会议';organize.textContent=en?'Start wrap-up':'开始整理';end.hidden=!showing;updateSubtitle();end.textContent=en?'End meeting':'结束会议';end.setAttribute('aria-label',en?'End':'结束');
  const pc=window.thtPauseControl?.state?.()||{available:false,paused:st==='paused'},paused=!foreign&&(!!pc.paused||st==='paused');
  const over=!showing&&!!ended&&active(),dur=over&&Number.isFinite(ended.start)?Math.max(0,Math.round((ended.end-ended.start)/1000)):0,hms=n=>(n>=3600?[Math.floor(n/3600),Math.floor(n/60)%60,n%60]:[Math.floor(n/60),n%60]).map(x=>String(x).padStart(2,'0')).join(':');if(showing&&curSid)liveSid=curSid;
  const starting=!captureConnected&&(!!ns.starting||(!foreign&&st==='starting')),asr=ns.asrStatus?.state;
  const failed=retryFailed||(!starting&&((ns.captureRecovery==='failed')||(!!ns.error&&!ns.captureReady)||['input-ended','input-muted','callback-stalled','suspended'].includes(healthName(ns.captureHealth))||(!foreign&&['error','failed'].includes(st))));
  const hasTranscript=[...transcriptRows,...(recordingSnapshot?.fullTranscript||[]),...(recordingSnapshot?.transcript||[])].some(row=>String(row?.text||'').trim());
  // A stopped live session may not have received its end timestamp yet.
  const start=recordingSnapshot?.start,startedAt=typeof start==='number'?start:Date.parse(start||''),stopped=!showing&&!ns.active&&!starting&&!!curSid&&active()&&(captureIdle||hasTranscript||Number.isFinite(startedAt)&&startedAt<nowMs());
  controlState=starting?'join':failed?'fail':over||paused||stopped?'stop':(['blocked','retrying'].includes(asr)||interrupted)?'asr':'rec';
  const neverStarted=over&&Number.isFinite(ended.start)&&ended.start===ended.end&&!hasTranscript;
  pill.hidden=!active()||neverStarted||(!showing&&!over&&!stopped&&!failed&&!ns.active&&!starting);if(pill.hidden)recmenu.hidden=true;
  pill.className='mw-pill'+(controlState==='stop'?' ended':controlState==='asr'?' disconnected':controlState==='fail'?' failed':controlState==='join'?' connecting':'');pill.dataset.state=controlState;
  const pt=pill.querySelector?.('.mw-t'),ps=pill.querySelector?.('.mw-pstate');if(pt){pt.textContent=recordingClock(over?hms(dur):el?.textContent||'00:00');pt.hidden=!['rec','stop'].includes(controlState);}
  if(ps)ps.textContent=sourceError||(ns.captureEnding?(en?'Saving stopped recording':'录音已停止，正在保存'):controlState==='join'?(en?'Connecting':'接入中'):controlState==='asr'?(en?'Transcription disconnected':'转写断开'):controlState==='fail'?(en?'Recording did not connect':'录音没接上'):'');
  end.hidden=pill.hidden||!(showing||ns.active||starting||!!curSid&&!ended&&curSid!==finishedId);end.textContent='';end.setAttribute('aria-label',en?'Stop':'停止');
  resume.hidden=!!ns.captureEnding||!['stop','asr','fail'].includes(controlState);resume.textContent=controlState==='stop'?(en?'Continue':'继续'):(en?'Retry':'重试');
  synced.hidden=true;finish.hidden=interruptEnd.hidden=organize.hidden=true;
  end.disabled=false;end.setAttribute('aria-busy',String(!!document.getElementById('stop')?.disabled));paintPillWave();window.dispatchEvent(new Event('tht-workspace-status'));}
 let nativeSeenAt=0;
 const updateClock=()=>{const ns=meetingNativeStatus(),now=nowMs(),down=!!(nativeSeenAt&&ns&&(ns.active||ns.sessionId===curSid)&&now-nativeSeenAt>6000);if(down!==!!window.thtNativeLinkDown){window.thtNativeLinkDown=down;statusSignature='';}const on=meetingInterrupted(frame.contentDocument?.querySelector('.surface-audio-status')?.dataset?.state);if(on!==interruptVisible||down!==!!window.thtNativeLinkDown){statusSignature='';updateStatus();}{const value=recordingClock(frame.contentDocument?.querySelector('.surface-elapsed')?.textContent||'00:00'),text=pill.querySelector?.('.mw-t');if(text&&text.textContent!==value)text.textContent=value;}};
 setInterval(updateClock,1000);
 window.thtExpandSameWindow=async()=>{
  const sessionId=curSid||(typeof window.thtViewedMeetingId==='string'?window.thtViewedMeetingId:'')||new URLSearchParams(location.search).get('id')||'';
  const token=window.THT_BOOT?.relayToken||'';
  const response=await fetch('/native/owner-open-main?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sessionId})});
  return response.json();
 };
 window.addEventListener('tht-native-status',e=>{
  const detail=e.detail||{},sid=String(detail.sessionId||'');
  const viewed=typeof window.thtViewedMeetingId==='string'?window.thtViewedMeetingId:'';
  if(!sid||sid!==(viewed||curSid||sid))return;
  if(!curSid)curSid=sid;
  if(sid!==curSid)return;
  const seen=new Set(transcriptRows.map(r=>r&&r.id!=null&&String(r.id)!==''?String(r.id):String(r?.text||'').trim()));
  let added=false;
  for(const row of detail.recentTranscript||[]){
    const text=String(row?.text||'').trim();if(!text)continue;
    const key=row.id!=null&&String(row.id)!==''?String(row.id):text;
    if(seen.has(key))continue;
    seen.add(key);transcriptRows.push(row);added=true;
  }
  if(!added)return;
  txSig='';fillTx();updateSubtitle();
 });
 let statusQueued=false;function scheduleStatus(){if(statusQueued)return;statusQueued=true;queueMicrotask(()=>{statusQueued=false;updateStatus();});}
 window.addEventListener('tht-native-status',()=>{nativeSeenAt=typeof window.thtNow==='function'?window.thtNow():Date.now();});
 window.addEventListener('tht-audio-health',e=>{audioHealth=healthName(e.detail?.state??e.detail);statusSignature='';scheduleStatus();});
 window.addEventListener('tht-notice-change',()=>{const text=String(document.getElementById('notice')?.textContent||'');if(/中断|中转断开|interrupted|没有被记录|not recorded|连接中断/i.test(text))window.thtTranscriptionInterrupted=true;else if(!text.trim())window.thtTranscriptionInterrupted=false;statusSignature='';scheduleStatus();});
 for(const name of ['tht-proactive-data','tht-live-transcript','tht-pause-state','tht-recording-started','tht-native-status','tht-asr-status'])window.addEventListener(name,scheduleStatus);
 new MutationObserver(scheduleStatus).observe(panel,{childList:true,subtree:true});
 new MutationObserver(scheduleStatus).observe(document.body,{attributes:true,attributeFilter:['class']});
 let recorderObserver;function observeRecorder(){recorderObserver?.disconnect();const root=frame.contentDocument?.querySelector('.surface-record-dock');if(root){recorderObserver=new MutationObserver(scheduleStatus);recorderObserver.observe(root,{attributes:true,subtree:true,attributeFilter:['class','data-state']});}scheduleStatus();}
 frame.addEventListener('load',observeRecorder);observeRecorder();

 // Transcript navigation is independent from the timeline's unread count.
 function roundLatest(btn){
  btn.textContent=document.documentElement.lang==='en'?'Back to latest ↓':'回到最新 ↓';
  btn.setAttribute('aria-label',btn.textContent);return btn;
 }
 layout();
})();
