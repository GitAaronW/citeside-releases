'use strict';
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory;
  else root.ThtLatency=factory(()=>performance.now());
})(typeof window==='undefined'?globalThis:window,function(now,limit=256,clock='performance'){
  const rows=[],frames=new WeakMap();let seq=0;
  const realm=Math.random().toString(36).slice(2);
  function mark(sessionId,key,stage,values={}){
    if(!['capture','packet_send','relay_receive','upstream_send','first_partial','partial_receive','dom_update','first_word','asr_arrive'].includes(stage))return;
    const row={sessionId:String(sessionId).slice(0,100),key:String(key).slice(0,140),stage,clock:['performance','uptime','hrtime'].includes(values.clock)?values.clock:clock,monoMs:Number.isFinite(values.monoMs)&&values.monoMs>=0?values.monoMs:now()};
    for(const k of ['seq','captureToSendMs','receiveToSendMs','sendToPartialMs','receiveToDomMs','startToDomMs','arrivedAt','speechEndToArriveMs'])if(Number.isFinite(values[k])&&values[k]>=0)row[k]=values[k];
    rows.push(row);if(rows.length>limit)rows.shift();return {...row};
  }
  return {
    mark,
    capture(sessionId,buffer){const n=++seq,key=realm+':'+n;const r=mark(sessionId,key,'capture',{seq:n});frames.set(buffer,{sessionId,key,seq:n,at:r.monoMs});},
    packet(buffer){const f=frames.get(buffer);if(!f)return null;frames.delete(buffer);const sent=now();return {...mark(f.sessionId,f.key,'packet_send',{seq:f.seq,monoMs:sent,captureToSendMs:sent-f.at}),captureMonoMs:f.at};},
    snapshot(sessionId){return rows.filter(r=>sessionId===undefined||r.sessionId===String(sessionId)).map(r=>({...r}));},
    clear(){rows.length=0;}
  };
});
