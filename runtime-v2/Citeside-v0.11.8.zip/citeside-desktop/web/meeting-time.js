// Presentation only. Source offsets remain seconds for seeking and ordering.
(function (root) {
  'use strict';
  const epoch = value => {
    if (value === null || value === undefined || value === '') return NaN;
    const n = typeof value === 'number' ? value : /^\d+(?:\.\d+)?$/.test(String(value)) ? Number(value) : Date.parse(value);
    return Number.isFinite(n) && Math.abs(n) <= 8.64e15 ? n : NaN;
  };
  function clockTime(value, timeZone = 'Asia/Shanghai') {
    const ms = epoch(value);
    if (!Number.isFinite(ms)) return '';
    return new Intl.DateTimeFormat('en-GB', {timeZone, hour:'2-digit', minute:'2-digit', hourCycle:'h23'}).format(new Date(ms));
  }
  function meetingTimestamp(value, start) {
    if (value === null || value === undefined || value === '') return NaN;
    if (typeof value === 'string' && /^\d+:\d{2}(?::\d{2})?$/.test(value)) {
      const parts = value.split(':').map(Number);
      if (parts.slice(1).some(n => n >= 60)) return NaN;
      return epoch(start) + parts.reduce((a,n) => a*60+n,0)*1000;
    }
    const n = Number(value);
    return Number.isFinite(n) ? (n > 1e11 ? n : n >= 0 ? epoch(start)+n*1000 : NaN) : epoch(value);
  }
  const meetingClock = (value, start, timeZone) => clockTime(meetingTimestamp(value, start), timeZone);
  const meetingRange = (value, start, timeZone) => String(value ?? '').split('–').map(v => meetingClock(v, start, timeZone)).filter(Boolean).join('–');
  const api = {clockTime, meetingTimestamp, meetingClock, meetingRange};
  if (root) root.ThtMeetingTime = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : null);
