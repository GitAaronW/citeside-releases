(function(root){'use strict';root.ThtSpeakerLabels={defaults:(en,room)=>en?{me:room?'In the room':'Me',them:'Online'}:{me:room?'在场':'我',them:'线上'}};})(window);
