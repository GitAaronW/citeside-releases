'use strict';
// 首次引导（真 app 版）。界面、文案、交互逐条照搬原型
// docs/design/proposals/20261108-onboarding.html；保留现有真实接口与安全退出边界。
// 原型里模拟的部分换成真接口：
//   权限 → GET /native/permissions（小助手上报）+ POST /native/permissions/request（弹系统框或开系统设置）
//   进度 → GET/POST /setup/onboarding（dataDir/onboarding.json，权限状态不存、实时读）
//   旧试听恢复 → 只读 state / 安全 stop；新引导不再启动试听。
// 走完或「稍后再说」都回首页 index.html，首页的引导气泡 / 继续设置条读 THT_BOOT.onboarding。
(function(){
const LANG=String(window.liveMateSystemLanguage||((navigator.languages||[navigator.language]).some(l=>/^zh/i.test(l||''))?'zh':'en'))==='en'?'en':'zh';
document.documentElement.lang=LANG==='en'?'en':'zh-CN';
const T={
zh:{
  c_t:'连接 Google 日历',c_l:'工作邮箱登录不包含日历授权。连接后仅读取你选择的日历与日程。',
  c_n:'你将在 Google 官方页面选择账号并单独确认只读权限。不会读取邮箱。',c_unconfigured:'日历连接服务尚未配置，请稍后重试。',c_retry:'重试连接服务',
  c_go:'连接 Google 日历',c_skip:'跳过，之后再连',c_ok_t:'已连接日历',c_today:'今天的会',c_go2:'继续',
  c_bl_t:'日历授权未完成',c_bl_n:'授权被取消或受到 Google / Workspace 限制。请核对官方页面的提示；不要绕过未验证应用或组织限制。',c_other:'换一个账号',
  g_wait_t:'在浏览器里完成授权',g_wait_l:'浏览器已打开 Google 授权页。',g_wait_w:'完成后自动回到这里',g_c:['选择账号','确认只读权限','返回 Citeside'],g_cancel:'取消',g_again:'没看到页面？重新打开',
  title:'Citeside',later:'稍后再说',back:'返回',next:'继续',
  w_t:'让好想法，在会上出现',w_l:'Citeside 实时记录并理解会议，主动递上有用的想法，不必等到会后再查。',
  w_s:{cal:'连接日历',mic:'允许听到你的声音',sys:'允许听到线上会的声音',ai:'让你的 AI 介绍一下你'},w_go:'开始',w_time:'大约 1 分钟',
  ai_t:'让熟悉你的 AI 介绍你',ai_l:'使用这台 Mac 上支持 MCP 的 AI 客户端。云端 AI 是否能连接取决于客户端能力。',
  ai_prompt:"请使用你已知且可靠的长期记忆，以及我已授权的资料，整理我的身份与职责、项目目标与阶段、伙伴与术语、决策约束、会议偏好；每组注明来源与最近确认时间，未知就写未知。不要从当前目录、仓库、AGENTS 或通用 AI 规则推断我的职业或项目事实，不编造，不自行翻邮箱补资料。资料不足时先同步明确已知，只问一个最关键的问题。建议交给熟悉我工作的 AI；新的聊天未必拥有长期记忆。通过已有的 Citeside MCP 连接调用 profile_sync，不重建或撤销当前授权。",
  ai_copy:'复制连接配置',ai_prompt_copy:'复制背景说明',ai_insufficient:'已收到资料 · 内容仍不足',ai_missing:'尚缺：',ai_config:'MCP 连接配置',ai_copied:'已复制',ai_n:'接收 AI 同步的个人背景；授权你的 AI 读取这台 Mac 上的会议纪要与研究报告。',
  ai_schedule:'你的 AI 支持定时任务时，可设置定期同步；也可随时在对话中要求同步。',ai_status:'连接状态',ai_connected:'已连接',ai_disconnected:'已断开，后续读取与同步已撤销。',ai_not_connected:'未连接',
  ai_waiting:'等待你的 AI 连接。请在 本机 MCP 客户端中添加已复制的配置。',ai_add:'在本机支持 MCP 的 AI 客户端中添加 Citeside。',ai_pending:'尚未收到个人背景。请在你的 AI 中发送同步指令。',ai_received:'已收到个人背景',
  ai_background:'来自你的 AI · 个人背景',ai_last_sync:'最近同步：',ai_retained:'已收到的背景保留在这台 Mac 上。',ai_revoke:'断开连接将撤销后续读写权限。',ai_disconnect:'断开连接',
  ai_fail:'连接状态暂时无法读取，请稍后重试。',ai_connect_fail:'连接配置未生成，请重试。',ai_copy_fail:'未能复制。下方配置已保留，可选中文字后按 ⌘C，或再点一次复制。',ai_disconnect_fail:'未能断开，后续读写权限尚未撤销，请重试。',
  m_t:'让Citeside听到你',m_l:'当面开会时，用麦克风记下现场说的话。',
  m_n:'仅在你开始记录后使用麦克风，结束记录后停止使用。请获得会上其他人的同意后再录音。',
  m_go:'允许使用麦克风',
  m_den_t:'麦克风还没打开',m_den_n:'打开系统设置，在<b>「隐私与安全性 › 麦克风」</b>里打开「Citeside」。改完回到这里，会自动继续。',
  open_set:'打开系统设置',waiting:'等你在系统设置里打开…回来后自动继续',
  s_t:'想让 Citeside 更懂你？',s_l:'开启画面分享权限，在你允许时截取会议画面，帮助它理解讨论内容。',
  s_n:'同时保留记录线上会议声音的能力，用来记下对方说的话。仅在你开始记录后使用，结束后停止。',
  s_go:'允许画面分享与系统声音',s_skip:'先跳过',
  s_den_t:'画面与系统声音权限还没打开',s_den_n:'可在系统设置的<b>「隐私与安全性 › 屏幕与系统录音」</b>中允许 Citeside。也可以先跳过，之后在设置里再开。',
  allowed:'已允许',
  t_sf_t:'试听还没停下来',t_sf_n:'停止请求没有成功，麦克风可能还在听。点「再停一次」重试，停下后才会离开这一页。',t_sf_go:'再停一次',
  recovery_t:'先结束上次的试听',recovery_n:'上次的试听尚未确认结束。请先停止，再继续设置。',recovery_unknown:'无法确认上次的录音状态，请重试检查。',recovery_check:'重试检查',recovery_busy:'正在确认停止…',
  finish:'完成',
  save_fail:'进度没保存上，下次打开可能要从这一步重来。',save_retry:'重试保存',save_leave:'不保存，直接离开'
},
en:{
  c_t:'Connect Google Calendar',c_l:'Work email sign-in does not authorize your calendar. Read only the calendars and events you choose.',
  c_n:'Choose your Google account and separately approve read-only access. Email is not read.',c_unconfigured:'Calendar connection is not configured. Try again later.',c_retry:'Retry connection service',
  c_go:'Connect Google Calendar',c_skip:'Skip for now',c_ok_t:'Calendar connected',c_today:'Today',c_go2:'Continue',
  c_bl_t:'Calendar authorization incomplete',c_bl_n:'Authorization was cancelled or restricted by Google or Workspace. Review the official page. Do not bypass unverified-app or organization restrictions.',c_other:'Use another account',
  g_wait_t:'Finish in your browser',g_wait_l:'Google’s sign-in page is open in your browser.',g_wait_w:'We’ll continue automatically when you’re done',g_c:['Choose account','Approve read-only access','Return to Citeside'],g_cancel:'Cancel',g_again:'Don’t see it? Open again',
  title:'Citeside',later:'Not now',back:'Back',next:'Continue',
  w_t:'Bring good ideas into the meeting',w_l:'Citeside records and understands meetings in real time, offering useful ideas without waiting until afterward.',
  w_s:{cal:'Connect your calendar',mic:'Let it hear you',sys:'Let it hear online calls',ai:'Let your AI introduce you'},w_go:'Get started',w_time:'About 1 minute',
  ai_t:'Let an AI familiar with you introduce you',ai_l:'Use a local AI client on this Mac that supports MCP. Cloud AI access depends on client capabilities.',
  ai_prompt:"Use only reliable long-term memory you already have and materials I authorized. Summarize my identity and responsibilities, project goals and stage, partners and terminology, decision constraints, and meeting preferences. State sources and last confirmation dates; mark unknowns. Never infer my profession or project facts from the working directory, repository, AGENTS or general AI rules. Do not invent facts or search email on your own. Sync explicitly known facts first, then ask only the most important question. Send this to an AI familiar with my work; a fresh chat may have no long-term memory. Call profile_sync through the existing Citeside MCP connection without recreating or revoking its grant.",
  ai_copy:'Copy connection configuration',ai_prompt_copy:'Copy background instructions',ai_insufficient:'Material received · More background needed',ai_missing:'Still missing: ',ai_config:'MCP connection configuration',ai_copied:'Copied',ai_n:'Receive personal background from your AI and allow it to read meeting notes and research reports on this Mac.',
  ai_schedule:'If your AI supports scheduled tasks, you can set up recurring sync or ask it to sync anytime.',ai_status:'Connection status',ai_connected:'Connected',ai_disconnected:'Disconnected. Further reading and syncing are revoked.',ai_not_connected:'Not connected',
  ai_waiting:'Waiting for your AI to connect. Add the copied configuration in a local MCP client.',ai_add:'Add Citeside in the MCP settings of a local MCP client.',ai_pending:'No personal background received yet. Ask your AI to sync it.',ai_received:'Personal background received',
  ai_background:'Personal background from your AI',ai_last_sync:'Last sync: ',ai_retained:'Previously received background stays on this Mac.',ai_revoke:'Disconnecting revokes further read and write access.',ai_disconnect:'Disconnect',
  ai_fail:'Connection status is unavailable. Try again shortly.',ai_connect_fail:'Could not generate the connection configuration. Try again.',ai_copy_fail:'Could not copy. The configuration is kept below: select it and press ⌘C, or copy again.',ai_disconnect_fail:'Could not disconnect. Further read and write access has not been revoked. Try again.',
  m_t:'Let Citeside hear you',m_l:'For in-person meetings, the microphone captures what’s said in the room.',
  m_n:'The microphone is used only after you start recording and stops when you finish. Obtain the other participants’ consent before recording.',
  m_go:'Allow microphone',
  m_den_t:'Microphone is off',m_den_n:'Open System Settings and turn on Citeside under <b>Privacy & Security › Microphone</b>. Come back and we’ll continue.',
  open_set:'Open System Settings',waiting:'Waiting for System Settings… we’ll continue automatically',
  s_t:'Help Citeside understand more',s_l:'Allow screen sharing so Citeside can capture meeting images when you permit it and understand the discussion.',
  s_n:'This also allows recording the other side of online meetings. Used only after you start recording and stopped when you finish.',
  s_go:'Allow screen sharing and system audio',s_skip:'Skip for now',
  s_den_t:'System audio is off',s_den_n:'Open System Settings and turn on Citeside under <b>Privacy & Security › Screen & System Audio Recording</b>. Or skip and turn it on later.',
  allowed:'Allowed',
  t_sf_t:'The trial hasn’t stopped',t_sf_n:'The stop request failed, so the microphone may still be listening. Press “Stop again”; this page stays open until it stops.',t_sf_go:'Stop again',
  recovery_t:'Finish the previous trial first',recovery_n:'The previous trial has not been confirmed stopped. Stop it before continuing setup.',recovery_unknown:'Unable to confirm the previous recording state. Check again.',recovery_check:'Check again',recovery_busy:'Confirming stop…',
  finish:'Done',
  save_fail:'Your progress wasn’t saved. Next time you may start from this step again.',save_retry:'Retry',save_leave:'Leave without saving'
}}[LANG];
document.title=T.title;

const IC={
  calbig:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="5" y="7" width="22" height="20" rx="4"/><path d="M5 13h22M11 4v6M21 4v6"/></svg>',
  back:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3 5 8l5 5"/></svg>',
  logo:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 13v6M11 9v14M16 5v22M21 10v12M26 14v4"/></svg>',
  mic:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="11" y="4" width="10" height="16" rx="5"/><path d="M6.5 15a9.5 9.5 0 0 0 19 0M16 24.5V28"/></svg>',
  sys:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="6" width="25" height="16" rx="3"/><path d="M11 27h10M16 22v5"/><path d="M12 12v4M16 10v8M20 12v4"/></svg>',
  talk:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8.5A3.5 3.5 0 0 1 8.5 5h15A3.5 3.5 0 0 1 27 8.5v10a3.5 3.5 0 0 1-3.5 3.5H14l-6 5v-5h0A3.5 3.5 0 0 1 5 18.5z"/><path d="M11 12h10M11 16h6"/></svg>',
  check:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3.5 8.5 3 3 6-7"/></svg>',
  excl:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 4v5M8 12v.01"/></svg>',
  lock:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="7" width="9" height="6.5" rx="1.5"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/></svg>',
  info:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 7v4M8 5v.01"/></svg>',
  x:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="m4.5 4.5 7 7M11.5 4.5l-7 7"/></svg>',
  spark:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M8 1.5 9.4 6.6 14.5 8 9.4 9.4 8 14.5 6.6 9.4 1.5 8 6.6 6.6z"/></svg>'
};

const STEPS=['welcome','cal','mic','sys','ai','done'],DONE=STEPS.indexOf('done'),AI=STEPS.indexOf('ai');
const KIND={mic:'microphone',sys:'screen'};
const boot=window.THT_BOOT||{};
const saved=boot.onboarding||{};
const directIntro=new URLSearchParams(location.search||'').get('step')==='ai';
// Restore named progress across versions; removing a trial never starts capture.
const savedStep=Number.isInteger(saved.step)?Math.max(0,saved.step):0;
const resumeStep=saved.version>=3?savedStep:saved.version===2?[0,1,2,3,4,4,5][Math.min(6,savedStep)]:[0,2,3,4,4,5][Math.min(5,savedStep)];
const S={step:directIntro?AI:Math.min(resumeStep,AI),cal:'idle',calConfigured:true,calEmail:'',calEvents:[],calEventsLoaded:false,mic:'idle',sys:saved.sys==='skipped'?'skipped':'idle',
  ask:{mic:false,sys:false,mainScreen:false,helperScreen:false},mainScreen:'unknown',helperScreen:'unknown',known:false,recovery:'checking',pendingLeave:null,
  ai:{items:[],msg:'',copied:false,loaded:false,busy:false,state:null,install:null,requestId:null,copyText:'',copyFailed:false,copying:false}};
const app=document.getElementById('app');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let timers=[],leaving=false;
const clearT=()=>{timers.forEach(clearTimeout);timers=[];};

// 复审 ONB-03：进度写入只认 2xx 回执；失败把这次的改动攒着，页面上明说「没保存」并给重试，不假装存好了。
let unsaved=null,saveFail=null;
async function persist(patch){
  if(directIntro)return true;
  const body={...(unsaved||{}),...patch};
  let ok=false;
  try{const r=await fetch('/setup/onboarding',{method:'POST',headers:{'content-type':'application/json','x-tht-token':boot.relayToken||''},body:JSON.stringify(body)});ok=r.ok;}catch(e){}
  unsaved=ok?null:body;return ok;
}
// Legacy recordings remain owned by the backend. Never clear a session on a failed stop.
let trialLive=false,stopP=null;
const STOP_POLLS=30,sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function trialState(){try{const r=await fetch('/native/trial/state',{cache:'no-store'});return r.ok?await r.json():null;}catch(e){return null}}
async function stopOnce(){
  let j=null;
  try{const r=await fetch('/native/trial/stop',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});const b=await r.json().catch(()=>({}));j=r.ok&&b.ok!==false?b:null;}catch(e){}
  for(let i=0;j&&j.state!=='done'&&j.state!=='failed'&&i<STOP_POLLS;i++){await sleep(500);j=await trialState()||j;}
  if(j?.state==='done'){trialLive=false;return true;}
  return false;
}
function stopRemote(){return stopP||(stopP=stopOnce().finally(()=>{stopP=null}));}
async function recoverTrial(){
  if(S.recovery==='stopping')return;
  S.recovery='stopping';render();
  if(!await stopRemote()){S.recovery='failed';render();return;}
  S.recovery=null;
  if(S.pendingLeave){const patch=S.pendingLeave;S.pendingLeave=null;return leave(patch);}
  if(saved.finished&&!directIntro){location.replace('index.html');return;}
  resumeOnboarding();
}
async function checkLegacyTrial(){
  S.recovery='checking';render();
  const j=await trialState();
  if(j?.state==='done'){trialLive=false;S.recovery=null;}
  else if(j&&['live','starting','stopping','failed'].includes(j.state)){trialLive=true;S.recovery=j.state==='failed'?'failed':'active';}
  else S.recovery='unknown';
  if(S.recovery)render();return !S.recovery;
}
async function leave(patch,{force=false}={}){
  if(leaving||S.recovery==='checking'||S.recovery==='unknown')return;
  if(trialLive){S.pendingLeave=patch;return recoverTrial();}
  leaving=true;stopCalendar();stopAi();
  if(!await persist(patch)&&!force){leaving=false;saveFail={patch,leave:true};render();return;}
  location.replace('index.html');
}
function recoveryStep(){
  const waiting=S.recovery==='checking'||S.recovery==='stopping',unknown=S.recovery==='unknown';
  return hero(IC.mic)+`<h1 id="h">${T.recovery_t}</h1><p class="lead">${unknown?T.recovery_unknown:S.recovery==='failed'?T.t_sf_n:T.recovery_n}</p><div class="spacer"></div><div class="acts">${waiting?`<span class="wait" role="status"><span class="spin"></span>${T.recovery_busy}</span>`:`<button class="btn lg pri" data-act="${unknown?'checktrial':'retrystop'}">${unknown?T.recovery_check:T.t_sf_go}</button>`}</div>`;
}

// ---------- 渲染（结构与原型同） ----------
const visibleSteps=()=>STEPS;
function dots(){const visible=visibleSteps(),index=visible.indexOf(STEPS[S.step]);return `<div class="dots" aria-label="${index+1} / ${visible.length}">${visible.map((_,i)=>`<i class="${i===index?'on':i<index?'done':''}"></i>`).join('')}</div>`}
function shell(inner){
  const back=!S.recovery&&!directIntro&&S.step>0&&S.step<DONE?`<button class="ib" data-act="back" aria-label="${T.back}">${IC.back}${T.back}</button>`:'<span></span>';
  const later=!S.recovery&&S.step<DONE?`<button class="ib" data-act="later">${T.later}</button>`:'<span></span>';
  return `<div class="stage"><section class="win" role="dialog" aria-modal="true" aria-labelledby="h"><div class="whead"><span class="l">${back}</span>${dots()}<span class="r">${later}</span></div><div class="wbody">${saveFail?saveNote():''}${inner}</div></section></div>`;
}
const saveNote=()=>`<div class="note warn" role="alert">${IC.info}<span>${T.save_fail} <button class="btn link" data-act="retrysave">${T.save_retry}</button>${saveFail.leave?`<button class="btn link" data-act="leaveunsaved">${T.save_leave}</button>`:''}</span></div>`;
const hero=(ic,badge)=>`<div class="hero">${ic}${badge==='ok'?`<span class="badge ok">${IC.check}</span>`:badge==='no'?`<span class="badge no">${IC.excl}</span>`:''}</div>`;


let calIv=null,calEpoch=0,calBusy=false;
function stopCalendar(){calEpoch++;if(calIv){clearInterval(calIv);calIv=null;}}
const calendarHeaders=()=>({'content-type':'application/json','x-tht-token':boot.relayToken||''});
const calendarBlocked=j=>/access_denied|test_user|testing|org_internal|admin_policy_enforced/i.test(j.authError||j.error||'');
async function calendarStatus(){
  try{const r=await fetch('/google/calendar',{cache:'no-store',headers:calendarHeaders()});return r.ok?await r.json():null;}catch(e){return null;}
}
async function calendarEvents(epoch){
  S.calEventsLoaded=true;
  try{
    const r=await fetch('/meeting-board?calendar=1&refresh=authorization',{cache:'no-store',headers:calendarHeaders()});
    if(!r.ok)return;const j=await r.json();
    if(epoch!==calEpoch||j.error)return;
    const today=new Date().toDateString();
    S.calEvents=(Array.isArray(j.events)?j.events:[]).filter(e=>new Date(e.start).toDateString()===today).sort((a,b)=>new Date(a.start)-new Date(b.start));
    if(STEPS[S.step]==='cal')render();
  }catch(e){}
}
function applyCalendar(j){
  if(!j)return;
  S.calConfigured=j.configured!==false;S.calEmail=j.email||'';
  S.cal=j.pending?'waiting':calendarBlocked(j)?'blocked':j.connected?'granted':'idle';
}
function watchCalendar(){
  if(calIv)return;
  const epoch=calEpoch;let reading=false;
  calIv=setInterval(async()=>{
    if(reading||epoch!==calEpoch)return;reading=true;
    const j=await calendarStatus();reading=false;
    if(epoch!==calEpoch||STEPS[S.step]!=='cal'||!j)return;
    applyCalendar(j);
    if(!S.calConfigured){stopCalendar();render();return;}
    if(!j.pending){stopCalendar();if(S.cal==='granted')calendarEvents(calEpoch);}
    render();
  },2000);
}
async function calendarConnect(){
  if(calBusy)return;calBusy=true;stopCalendar();const epoch=calEpoch;
  S.cal='waiting';S.calEvents=[];S.calEventsLoaded=false;render();
  try{
    const r=await fetch('/google/calendar/connect',{method:'POST',headers:calendarHeaders(),body:'{}'});
    const j=await r.json();
    if(epoch!==calEpoch)return;
    if(!r.ok||j.ok===false){S.cal=calendarBlocked(j)?'blocked':'idle';render();return;}
    watchCalendar();
  }catch(e){if(epoch===calEpoch){S.cal='idle';render();}}
  finally{calBusy=false;}
}
function calendarMeetings(){
  return S.calEvents.map(e=>`<div class="m"><time>${esc(new Date(e.start).toLocaleTimeString(LANG,{hour:'2-digit',minute:'2-digit',hour12:false}))}</time><b>${esc(e.title||'')}</b></div>`).join('');
}

function calStep(){
  if(!S.calConfigured)return hero(IC.calbig)+`<h1 id="h">${T.c_go}</h1><p class="lead">${T.c_unconfigured||'Calendar connection is not configured. Try again later.'}</p><div class="spacer"></div><div class="acts"><button class="btn sec" data-act="calretry">${T.c_retry||'Retry connection service'}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
  if(S.cal==='granted')return hero(IC.calbig,'ok')+`<h1 id="h">${T.c_ok_t}</h1><span class="acct">${esc(S.calEmail)}</span><div class="mlist">${calendarMeetings()}</div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="next">${T.c_go2}</button></div>`;
  if(S.cal==='blocked')return hero(IC.calbig,'no')+`<h1 id="h">${T.c_bl_t}</h1><div class="note warn">${IC.info}<span>${T.c_bl_n}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="calgo">${T.c_other}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
  if(S.cal==='waiting')return hero(IC.calbig)+`<h1 id="h">${T.g_wait_t}</h1><p class="lead">${T.g_wait_l}</p><div class="gchain">${T.g_c.map((c,i)=>`${i?'<span>›</span>':''}<b>${c}</b>`).join('')}</div><span class="wait" style="margin-top:20px"><span class="spin"></span>${T.g_wait_w}</span><div class="spacer"></div><div class="acts"><button class="btn link" data-act="gagain">${T.g_again}</button><button class="btn ghost" data-act="calcancel">${T.g_cancel}</button></div>`;
  return hero(IC.calbig)+`<h1 id="h">${T.c_t}</h1><p class="lead">${T.c_l}</p><div class="note">${IC.lock}<span>${T.c_n}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="calgo">${T.c_go}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
}

function permStep(kind){
  const st=S[kind],ic=kind==='mic'?IC.mic:IC.sys,p=kind==='mic'?'m':'s';
  if(st==='denied'||st==='waiting'){
    return hero(ic,'no')+`<h1 id="h">${T[p+'_den_t']}</h1><div class="note warn">${IC.info}<span>${T[p+'_den_n']}</span></div><div class="spacer"></div><div class="acts">`+
      `<button class="btn lg pri" data-act="openset" data-k="${kind}">${T.open_set}</button>`+
      (st==='waiting'?`<span class="wait"><span class="spin"></span>${T.waiting}</span>`:'')+
      (kind==='sys'?`<button class="btn link" data-act="skipsys">${T.s_skip}</button>`:'')+`</div>`;
  }
  const granted=st==='granted';
  return hero(ic,granted?'ok':'')+`<h1 id="h">${T[p+'_t']}</h1><p class="lead">${T[p+'_l']}</p><div class="note">${IC.lock}<span>${T[p+'_n']}</span></div><div class="spacer"></div><div class="acts">`+
    (granted?`<span class="state" role="status">${IC.check}${T.allowed}</span><button class="btn lg pri" data-act="next">${T.next}</button>`
      :`<button class="btn lg pri" data-act="ask" data-k="${kind}">${T[p+'_go']}</button>`+
       (kind==='sys'?`<button class="btn link" data-act="skipsys">${T.s_skip}</button>`:''))+`</div>`;
}
// The user's AI is the MCP client. Copying configuration is never a connection receipt.
let aiIv=null,aiEpoch=0,aiReading=false,aiRevision=0;
const aiHeaders=()=>({'content-type':'application/json','x-tht-token':boot.relayToken||''});
const connected=st=>st?.status==='connected'||st?.status==='profile_received';
function aiStep(){
  const a=S.ai,st=a.state,isConnected=connected(st),received=!!st?.profileReceivedAt||st?.profileItemCount>0;
  const canDisconnect=!!st?.connectionId&&(isConnected||st.awaitingClient===true);
  const status=isConnected?T.ai_connected:T.ai_not_connected;
  const description=st?.status==='disconnected'?T.ai_disconnected:isConnected?(received?(st?.profileCoverage?.status==='received'?T.ai_received:T.ai_insufficient):T.ai_pending):st?.awaitingClient?T.ai_waiting:T.ai_add;
  return `<h1 id="h" style="margin-top:12px">${T.ai_t}</h1><p class="lead">${T.ai_l}</p>`+
    `<div class="aibox"><pre class="aiprompt" id="aiprompt">${esc(a.copyFailed?a.copyText:T.ai_prompt)}</pre><button class="btn sec" data-act="aipromptcopy"${a.busy?' disabled':''}>${a.copied?T.ai_copied:T.ai_prompt_copy}</button></div>`+(!isConnected?`<div class="aibox"><p class="cap">${T.ai_config}</p><button class="btn sec" data-act="aicopy"${a.busy?' disabled':''}>${T.ai_copy}</button></div>`:'')+
    `<div class="note">${IC.lock}<span>${T.ai_n}</span></div><p class="cap">${T.ai_schedule}</p>`+
    (a.msg?`<p class="cap" role="status">${esc(a.msg)}</p>`:'')+
    `<div class="airead" aria-live="polite"><div class="lab">${T.ai_status}</div><p class="${isConnected?'state':'cap'}">${isConnected?IC.check:''}${status}</p><p class="cap">${description}</p>`+
    (a.items.length?`<div class="lab">${T.ai_background}</div><ul>${a.items.map(i=>`<li><span>${esc(i.text)}</span></li>`).join('')}</ul>`:'')+
    (received&&st?.profileCoverage?.missing?.length?`<p class="cap">${T.ai_missing}${esc(st.profileCoverage.missing.map(k=>({identity:LANG==='zh'?'身份与职责':'identity and responsibilities',project:LANG==='zh'?'项目目标与阶段':'project goals and stage',partner:LANG==='zh'?'伙伴与术语':'partners and terminology',constraint:LANG==='zh'?'决策约束':'decision constraints',meeting:LANG==='zh'?'会议偏好':'meeting preferences',provenance:LANG==='zh'?'来源与确认时间':'sources and confirmation dates'}[k]||k)).join('、'))}</p>`:'')+(st?.profileReceivedAt?`<p class="cap">${T.ai_last_sync}${esc(new Date(st.profileReceivedAt).toLocaleString(LANG))}</p>`:'')+`</div>`+
    `<p class="cap">${received?T.ai_retained:''}${canDisconnect?T.ai_revoke:''}</p><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="next">${T.finish}</button>`+
    (canDisconnect?`<button class="btn link" data-act="aidisconnect"${a.busy&&!a.copying?' disabled':''}>${T.ai_disconnect}</button>`:'')+`</div>`;
}
function stopAi(){if(aiIv){clearInterval(aiIv);aiIv=null;}aiEpoch++;}
function watchAi(){
  if(aiIv||document.hidden)return;
  aiIv=setInterval(()=>{if(!document.hidden&&STEPS[S.step]==='ai')aiLoad();},2000);
}
async function aiLoad(){
  if(aiReading||S.ai.busy)return;
  aiReading=true;S.ai.loaded=true;
  const epoch=aiEpoch,revision=aiRevision;
  try{
    const r=await fetch('/setup/mcp-connection',{cache:'no-store',headers:aiHeaders()});
    const j=r.ok?await r.json():null;
    if(epoch!==aiEpoch||revision!==aiRevision)return;
    if(j&&['not_connected','connected','profile_received','disconnected'].includes(j.status)){
      S.ai.state=j;
      S.ai.items=Array.isArray(j.profileItems)?j.profileItems:[];
      if(S.ai.msg===T.ai_fail)S.ai.msg='';
    }else S.ai.msg=T.ai_fail;
  }catch(e){if(epoch===aiEpoch&&revision===aiRevision)S.ai.msg=T.ai_fail;}
  finally{aiReading=false;if(epoch===aiEpoch&&STEPS[S.step]==='ai')render();}
}
async function aiAction(body){
  try{const r=await fetch('/setup/mcp-connection',{method:'POST',headers:aiHeaders(),body:JSON.stringify(body)});const j=await r.json();return r.ok&&j.ok!==false?j:null;}catch(e){return null;}
}
async function aiCopy(mode='config'){
  const a=S.ai;
  if(a.busy)return;
  const revision=++aiRevision;
  a.busy=true;a.msg='';render();
  const promptOnly=mode==='prompt'||connected(a.state);
  if(!promptOnly&&!a.install){
    if(a.state?.connectionId&&a.state?.awaitingClient){a.busy=false;a.msg=LANG==='zh'?'已有待连接授权；请使用之前复制的配置，或先断开后再生成。':'A pending grant already exists. Use its copied configuration, or disconnect before generating a new one.';render();return;}
    a.requestId=a.requestId||crypto.randomUUID();
    const j=await aiAction({action:'connect',client:'mcp-client',requestId:a.requestId,scope:{meetings:'all'}});
    if(revision!==aiRevision)return;
    if(!j||!(j.install?.config||j.config)){
      a.busy=false;a.msg=T.ai_connect_fail;render();return;
    }
    a.state=j;a.install=j.install||{config:j.config};
  }
  const text=promptOnly?T.ai_prompt:JSON.stringify(a.install.config,null,2);
  a.copyText=text;a.copying=true;render();
  try{
    await navigator.clipboard.writeText(text);
    if(revision!==aiRevision)return;
    a.copied=true;a.copyFailed=false;
  }catch(e){
    if(revision!==aiRevision)return;
    a.copied=false;a.copyFailed=true;a.msg=T.ai_copy_fail;
  }
  a.busy=false;a.copying=false;render();
  if(a.copyFailed){try{const el=document.getElementById('aiprompt');if(el)getSelection().selectAllChildren(el);}catch(e){}}
}
async function aiDisconnect(){
  const a=S.ai;
  if((a.busy&&!a.copying)||!a.state?.connectionId)return;
  aiRevision++;a.copying=false;a.busy=true;a.msg='';render();
  const j=await aiAction({action:'disconnect',connectionId:a.state.connectionId});
  a.busy=false;
  if(j?.status==='disconnected'){a.state=j;a.install=null;a.requestId=null;a.copied=false;a.copyText='';a.copyFailed=false;}
  else a.msg=T.ai_disconnect_fail;
  render();
}
function welcome(){
  return hero(IC.logo)+`<h1 id="h">${T.w_t}</h1><p class="lead">${T.w_l}</p><ol class="steplist">${visibleSteps().filter(k=>T.w_s[k]).map((step,i)=>`<li><span class="n">${i+1}</span>${T.w_s[step]}</li>`).join('')}</ol><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="next">${T.w_go}</button><span class="cap" style="margin-top:4px">${T.w_time}</span></div>`;
}
function render(){
  clearT();
  const k=STEPS[S.step];
  app.innerHTML=shell(S.recovery?recoveryStep():k==='welcome'?welcome():k==='cal'?calStep():k==='mic'?permStep('mic'):k==='sys'?permStep('sys'):aiStep());
  if(!S.recovery&&k==='cal'&&S.cal==='waiting'&&!calBusy)watchCalendar();
  if(!S.recovery&&k==='cal'&&S.cal==='granted'&&!S.calEventsLoaded)calendarEvents(calEpoch);
  if(!S.recovery&&k==='ai'){if(!S.ai.loaded)aiLoad();watchAi();}else stopAi();
}

function go(n){
  stopCalendar();stopAi();

  S.step=Math.max(0,Math.min(STEPS.length-1,n));
  if(STEPS[S.step]==='done')return leave({step:DONE,finished:true,sys:S.sys==='granted'?'granted':S.sys==='skipped'?'skipped':'idle'});
  const patch={step:S.step,sys:S.sys==='skipped'?'skipped':S.sys==='granted'?'granted':'idle'};
  persist(patch).then(ok=>{const was=!!saveFail;saveFail=ok?null:{patch};if(was!==!!saveFail)render();});
  render();
}

// ---------- 权限：实时读系统状态 ----------
const map=v=>v==='authorized'?'granted':v==='denied'||v==='restricted'?'denied':'idle';
async function readMainScreen(action='screenPermissionStatus'){
  const bridge=window.webkit?.messageHandlers?.liveMateWindow;
  if(!bridge)return 'unknown';
  try{
    const result=await bridge.postMessage({action});
    return ['authorized','denied','unknown'].includes(result?.screen)?result.screen:'unknown';
  }catch(e){return 'unknown';}
}
async function readPerms(){
  const helper=async()=>{try{const r=await fetch('/native/permissions',{cache:'no-store'});return r.ok?await r.json():null;}catch(e){return null;}};
  const [p,main]=await Promise.all([helper(),readMainScreen()]);
  S.mainScreen=main;S.helperScreen=p?.known?p.screen:'unknown';
  const screen=main==='authorized'&&S.helperScreen==='authorized'?'authorized':main==='denied'||S.helperScreen==='denied'?'denied':'unknown';
  return {known:!!p?.known,microphone:p?.known?p.microphone:'unknown',screen};
}
function applyPerms(p,initial){
  if(!p)return;S.known=!!p.known;
  let changed=false;
  for(const k of ['mic','sys']){
    const sysState=map(p[KIND[k]]);
    let next=S[k];
    if(sysState==='granted')next='granted';
    else if(k==='sys'&&S.sys==='skipped')next='skipped';
    else if(sysState==='denied')next=S[k]==='waiting'?'waiting':'denied';
    else if(S[k]==='granted')next='idle';
    if(next!==S[k]){
      S[k]=next;changed=true;
    }
  }
  if(changed&&!initial&&(STEPS[S.step]==='mic'||STEPS[S.step]==='sys'))render();
}
async function poll(){applyPerms(await readPerms())}
let requestingPermission=false;
async function request(k){
  if(requestingPermission)return;
  requestingPermission=true;
  try{
    if(k==='sys'){
      await readPerms();
      // One CTA asks one process only. The second permission needs the same
      // CTA again after the first result; no cascading system dialogs.
      if(S.mainScreen!=='authorized'){
        S.ask.mainScreen=true;lastPermissionRefresh.main=0;S.sys='waiting';render();
        await readMainScreen('screenPermissionRequest');
      }else if(S.helperScreen!=='authorized'){
        S.ask.helperScreen=true;lastPermissionRefresh.helper=0;S.sys='waiting';render();
        await fetch('/native/permissions/request',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:'screen'})});
      }
    }else{
      const r=await fetch('/native/permissions/request',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:KIND[k]})});
      const j=await r.json().catch(()=>({}));
      if(j.via==='settings'&&S[k]!=='granted'){S[k]='waiting';render();}
    }
  }catch(e){}
  finally{requestingPermission=false;poll();}
}

// ---------- 交互 ----------
app.addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');if(!b)return;const a=b.dataset.act,k=b.dataset.k;
  if(S.recovery){if(a==='retrystop')recoverTrial();else if(a==='checktrial')checkLegacyTrial().then(ok=>{if(ok)resumeOnboarding();});return;}
  if(a==='next')go(S.step+1);
  else if(a==='back')go(S.step-1);
  else if(a==='calgo'||a==='gagain')calendarConnect();
  else if(a==='calcancel'){stopCalendar();const cancelledAt=calEpoch;fetch('/google/calendar/cancel',{method:'POST',headers:calendarHeaders(),body:'{}'}).then(r=>r.json()).then(j=>{if(cancelledAt===calEpoch){applyCalendar(j);render();}}).catch(()=>{});S.cal='idle';render();}
  else if(a==='calretry'){calendarStatus().then(j=>{applyCalendar(j);render();});}
  else if(a==='calskip')go(S.step+1);
  else if(a==='later')leave({step:S.step});
  else if(a==='ask'||a==='openset'){S.ask[k]=true;request(k)}
  else if(a==='skipsys'){S.sys='skipped';go(S.step+1)}
  else if(a==='retrysave'){const f=saveFail;if(!f)return;saveFail=null;if(f.leave)leave(f.patch);else persist(f.patch).then(ok=>{if(!ok){saveFail=f;}render();});}
  else if(a==='leaveunsaved'){const f=saveFail;saveFail=null;leave(f?.patch||{step:S.step},{force:true});}
  else if(a==='aicopy')aiCopy();
  else if(a==='aipromptcopy')aiCopy('prompt');
  else if(a==='aidisconnect')aiDisconnect();
});
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&e.target.tagName!=='TEXTAREA'&&!(e.target.closest&&e.target.closest('button'))){const p=app.querySelector('.btn.pri');if(p){e.preventDefault();p.click()}}
  if(e.key==='Escape'&&S.step<DONE)leave({step:S.step});
});
// 关窗 / 刷新：页面没机会等回执，用 sendBeacon（不行就 keepalive fetch）把 stop 送出去
window.addEventListener('pagehide',()=>{
  stopCalendar();stopAi();
  if(!trialLive)return;
  const body=new Blob(['{}'],{type:'application/json'});let sent=false;
  try{sent=!!navigator.sendBeacon?.('/native/trial/stop',body)}catch(e){}
  if(!sent){try{fetch('/native/trial/stop',{method:'POST',headers:{'content-type':'application/json'},body:'{}',keepalive:true})}catch(e){}}
});
let refreshingPermission=false;
const lastPermissionRefresh={main:0,helper:0};
async function refreshOnReturn(){
  if(S.ask.sys&&!refreshingPermission){
    refreshingPermission=true;
    try{
      const now=Date.now();
      if(S.ask.mainScreen&&now-lastPermissionRefresh.main>=5000){
        lastPermissionRefresh.main=now;await readMainScreen('screenPermissionRefresh');
      }
      if(S.ask.helperScreen&&now-lastPermissionRefresh.helper>=5000){
        lastPermissionRefresh.helper=now;
        await fetch('/native/permissions/refresh',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:'screen'})});
      }
    }catch(e){}
    finally{refreshingPermission=false;}
  }
  poll();
  if(!S.recovery&&STEPS[S.step]==='ai'){aiLoad();watchAi();}
}
window.addEventListener('focus',refreshOnReturn);
window.addEventListener('citeside-native-active',refreshOnReturn);
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAi();else refreshOnReturn();});

// 启动：先读一次系统权限，停在的那一步已授权就直接跳到下一个没做完的步骤（spec §2）
let initialized=false;
async function resumeOnboarding(){
  if(initialized){render();return;}initialized=true;
  if(saved.finished===true&&!directIntro){location.replace('index.html');return;}
  const [p,calendar]=await Promise.all([readPerms(),calendarStatus()]);applyPerms(p,true);applyCalendar(calendar);

  if(S.known){
    while((STEPS[S.step]==='mic'&&S.mic==='granted')||(STEPS[S.step]==='sys'&&(S.sys==='granted'||S.sys==='skipped')))S.step++;
  }
  render();
  setInterval(()=>{if(!document.hidden&&(STEPS[S.step]==='mic'||STEPS[S.step]==='sys'))poll()},1000);
}
checkLegacyTrial().then(ok=>{if(ok)resumeOnboarding();});
})();
