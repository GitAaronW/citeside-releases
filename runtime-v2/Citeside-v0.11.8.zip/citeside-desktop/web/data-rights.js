'use strict';
// Standalone deep link: same tht-ui preference and data-i18n convention as 01-i18n.js.
(() => {
  const $ = id => document.getElementById(id);
  const I18N = {
    zh: {rights_title:'数据与连接',rights_intro:'都只在这台 Mac 上做。删除先进回收，30 天内可以恢复；供应商那边的副本要去各家手动删。',rights_meeting:'这一场会',rights_open_meeting:'从会议列表点进来，这里会显示这一场的导出和删除范围。',rights_export_md:'导出 Markdown',rights_export_json:'导出原始数据',rights_local:'删除后本机会移走',rights_hidden:'只隐藏、不改原记录',rights_vendor:'删不到的供应商副本',rights_delete:'删除这一场',rights_restore:'恢复这一场',rights_connections:'连接',rights_erase_title:'注销本机数据',rights_erase_intro:'清空这台 Mac 上Citeside的全部会议、录音、缓存和凭据，只留本机访问口令。不能撤销，做完要重启Citeside。',rights_confirm:'要继续，请输入',rights_erase:'注销'},
    en: {rights_title:'Data & connections',rights_intro:'These actions apply to this Mac. Deleted meetings can be restored for 30 days. Copies held by service providers must be deleted with each provider.',rights_meeting:'This meeting',rights_open_meeting:'Open this page from a meeting to see its export and deletion scope.',rights_export_md:'Export Markdown',rights_export_json:'Export original data',rights_local:'Local files moved to trash',rights_hidden:'Hidden references; original records stay',rights_vendor:'Copies this app cannot delete',rights_delete:'Delete this meeting',rights_restore:'Restore this meeting',rights_connections:'Connections',rights_erase_title:'Erase local data',rights_erase_intro:'Erase all meetings, recordings, caches and credentials on this Mac, keeping only its local access token. This cannot be undone. Restart Citeside afterwards.',rights_confirm:'To continue, enter',rights_erase:'Erase'}
  };
  let ui = (navigator.language||'zh').startsWith('zh')?'zh':'en';
  try { const saved=localStorage.getItem('tht-ui'); if(['zh','en'].includes(saved))ui=saved; } catch {}
  const tr = (zh,en) => ui==='en'?en:zh;
  const friendlyError = (error, fallback) => ui==='en' && /[\u3400-\u9fff]/.test(error||'') ? fallback : error||fallback;
  const tok = () => { let s = {}; try { s = JSON.parse(localStorage.getItem('tht-settings') || '{}'); } catch {} return encodeURIComponent(s.relayToken || (window.THT_BOOT && window.THT_BOOT.relayToken) || new URLSearchParams(location.search).get('token') || ''); };
  const url = p => '/asr-relay/' + p + (p.includes('?') ? '&' : '?') + 'token=' + tok();
  const api = (p, body) => fetch(url(p), body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), cache: 'no-store' } : { cache: 'no-store' })
    .then(r => r.json().catch(() => ({ ok: false, error: 'HTTP ' + r.status }))).catch(()=>({ok:false,error:tr('连接失败，请重试。','Connection failed. Try again.')}));
  const say = (el, text, ok) => { el.textContent = text; el.className = 'msg ' + (ok === true ? 'ok' : ok === false ? 'bad' : ''); };
  const li = (ul, items) => { ul.replaceChildren(...items.map(t => { const x = document.createElement('li'); x.textContent = t; return x; })); };
  const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  const id = new URLSearchParams(location.search).get('id') || '';
  async function meeting() {
    if (!id) return;
    $('meeting-none').classList.add('hide'); $('meeting-body').classList.remove('hide');
    const q = 'id=' + encodeURIComponent(id);
    $('export-md').href = url('meeting-export?' + q); $('export-json').href = url('meeting-export?' + q + '&format=json');
    const s = await api('meeting-delete-scope?' + q);
    if (!s.ok) { say($('meeting-msg'), friendlyError(s.error,tr('读不到这一场','Could not load this meeting. Retry by reopening this page.')), false); return; }
    li($('scope-local'), s.local.length ? s.local.map(x => x.item + (x.size ? ' (' + kb(x.size) + ')' : '')) : [tr('本机已经没有这一场的文件','No local files remain for this meeting.')]);
    li($('scope-hidden'),ui==='en'?['Meeting references in workspace and projects (original records stay).','Links to this meeting in living documents (hidden only).','Share records, delivery receipts and meeting-board tasks (without meeting text).']:s.hiddenOnly);
    li($('scope-vendor'), ui==='en'?['Notion: delete shared minutes pages in Notion. Local pending deliveries are deleted too.','Lark: delete archived documents, tasks and shared messages in Lark.','Slack: delete shared messages and files in Slack.','Speech and AI services: audio and text follow each provider’s retention policy. Citeside cannot remotely erase them or verify complete deletion.','Local mirrors: index entries are removed; backups follow their own retention policies.']:s.vendor.map(v => v.where + '：' + v.what + '。' + v.how));
    say($('scope-retention'),tr(s.retention,'Deleted meetings can be restored for 30 days, then local trash is permanently removed.'));
  }
  $('delete').onclick = async () => {
    if (!confirm(tr('删除这一场？30 天内可以在这里恢复。','Delete this meeting? You can restore it here within 30 days.'))) return;
    const r = await api('meeting-delete', { id });
    say($('meeting-msg'), r.ok ? tr('已删除，进了回收','Moved to trash.') : friendlyError(r.error,tr('删除失败，请重试。','Deletion failed. Try again.')), !!r.ok);
    if (r.ok) { $('delete').classList.add('hide'); $('restore').classList.remove('hide'); }
  };
  $('restore').onclick = async () => {
    const r = await api('meeting-restore', { id });
    say($('meeting-msg'), r.ok ? tr('已恢复','Restored.')+(r.warnings?.length?tr('；部分引用需检查。',' Some references need checking.'):'') : friendlyError(r.error,tr('没恢复完整','Restoration was incomplete. Try again.')), !!r.ok);
    if (r.ok) { $('restore').classList.add('hide'); $('delete').classList.remove('hide'); meeting(); }
  };
  const serviceName = s => ({'model-api':tr('模型接口','Model API'),volc:tr('火山语音','Volcano speech'),jev:'Jev','free-ai':tr('免费模型','Free AI'),lark:tr('飞书','Lark')})[s.id]||s.name;
  const serviceNote = s => ui!=='en'?s.note:s.id==='notion'?'Revoke external Notion access in the service that granted it.':s.id==='lark'?'Lark login is shared with command-line tools. Log out in the terminal if needed.':'';
  async function services() {
    const r = await api('connections');
    if (!r.ok) { say($('svc-msg'), friendlyError(r.error,tr('读不到连接状态','Could not load connections. Reopen this page to retry.')), false); return; }
    $('services').replaceChildren(...r.services.map(s => {
      const row = document.createElement('div'); row.className = 'row';
      const name = document.createElement('span'); name.className = 'name'; name.textContent = serviceName(s);
      if (serviceNote(s)) { const n = document.createElement('span'); n.className = 'note'; n.textContent = serviceNote(s); name.append(n); }
      const tag = document.createElement('span'); tag.className = 'tag' + (s.connected ? ' ok' : '');
      tag.textContent = s.manual ? tr('由命令行管理','Managed by CLI') : s.connected ? tr('已连接','Connected') : tr('未连接','Not connected');
      const b = document.createElement('button'); b.className = 'ghost'; b.textContent = s.manual ? tr('看命令','Show command') : tr('断开','Disconnect');
      b.disabled = !s.manual && !s.connected;
      b.onclick = async () => {
        if (s.manual) { say($('svc-msg'), tr('在终端运行：','Run in Terminal: ') + s.manual); return; }
        if (!confirm(tr('断开 '+serviceName(s)+'？会清掉这台 Mac 上保存的凭据，之后要用得重新连接。','Disconnect '+serviceName(s)+'? Local credentials will be cleared. Reconnect to use it again.'))) return;
        b.disabled=true;
        const x = await api('connections/disconnect', { service: s.id });
        say($('svc-msg'), x.ok ? serviceName(s)+tr(' 已断开。',' disconnected.') : friendlyError(x.error,tr('没断开，请重试。','Disconnect failed. Try again.')), !!x.ok);
        services();
      };
      row.append(name, tag, b); return row;
    }));
  }
  async function plan() {
    const r = await api('local-data/erase-plan');
    if (!r.ok) { say($('erase-msg'), friendlyError(r.error,tr('读不到数据目录','Could not load the data directory. Reopen this page to retry.')), false); return; }
    // Keep the server confirmation contract; English users type an English phrase.
    const word=tr(r.confirmWord,'ERASE LOCAL DATA');
    $('erase-word-hint').textContent = word;
    const total = r.entries.reduce((a, e) => a + e.bytes, 0);
    const p = document.createElement('p'); p.className = 'msg';
    p.textContent = tr('会删除 '+r.entries.length+' 项，共 '+kb(total)+'：','Will delete '+r.entries.length+' items ('+kb(total)+'): ')+r.entries.map(e => e.name).join(', ');
    $('erase-plan').replaceChildren(p);
    $('erase-word').oninput = () => { $('erase').disabled = $('erase-word').value.trim() !== word; };
    $('erase').onclick = async () => {
      if($('erase-word').value.trim()!==word)return;
      $('erase').disabled=true;
      const x = await api('local-data/erase', { confirm: r.confirmWord });
      say($('erase-msg'), x.ok ? tr('本机数据已清空。请退出并重新打开Citeside。','Local data erased. Quit and reopen Citeside.') : friendlyError(x.error,tr('有 '+(x.failed||[]).length+' 项没删掉，请重试。',(x.failed||[]).length+' items could not be deleted. Try again.')), !!x.ok);
      if (!x.ok) $('erase').disabled=false;
    };
  }
  function applyLang(){
    document.documentElement.lang=ui==='en'?'en':'zh-CN';
    for(const el of document.querySelectorAll('[data-i18n]'))el.textContent=I18N[ui][el.dataset.i18n];
    for(const b of document.querySelectorAll('#rights-lang [data-ui]'))b.setAttribute('aria-pressed',String(b.dataset.ui===ui));
    meeting();services();plan();
  }
  for(const b of document.querySelectorAll('#rights-lang [data-ui]'))b.onclick=()=>{ui=b.dataset.ui;try{localStorage.setItem('tht-ui',ui);}catch{}applyLang();};
  applyLang();
})();
