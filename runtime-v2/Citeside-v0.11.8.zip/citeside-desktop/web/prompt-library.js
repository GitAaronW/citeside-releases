'use strict';
// Only reusable instructions and bounded usage counts are stored; never meeting text.
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ThtPrompts=api;})(typeof window==='object'?window:globalThis,()=>{
 const defaults=[
 ['evidence','找关键证据','Find key evidence','找出支撑或反驳当前结论的关键证据，标明出处和日期。','Find evidence for or against the current conclusions, with sources and dates.'],
 ['compare','比较方案','Compare options','比较当前讨论的方案，列出目标、代价、风险和未确定事项。','Compare the options by goal, cost, risk and unresolved questions.'],
 ['todos','上周我答应了谁什么','What did I promise last week?','列出上周我明确答应他人的事项，保留来源，不推测负责人或期限。','List commitments I explicitly made last week. Include sources; do not guess owners or deadlines.'],
 ['open','这个项目现在卡在哪','What is blocking this project?','整理当前项目的阻碍和待决定事项，保留来源和不确定性。','Identify current project blockers and pending decisions, with sources and uncertainty.']
 ].map(([id,zh,en,promptZh,promptEn])=>({id,zh,en,promptZh,promptEn}));
 // r8 原型 final.html 会议页（PV.scope='meeting'）的默认提示词；会议页单独存一份，不和首页那组混。
 const meetingDefaults=[
 ['evidence','找关键证据','Find key evidence','找出支撑或反驳本场关键结论的证据，标出处和时间点。','Find evidence for or against the key conclusions of this meeting, with sources and timestamps.'],
 ['compare','比较方案','Compare options','把本场提到的几个方案按目标、代价、风险比一比，给出推荐和理由。','Compare the options raised in this meeting by goal, cost and risk, and recommend one with reasons.'],
 ['conflict','这条和上次说的冲突吗','Conflicts with last time?','这条和之前会议或文档里说的有没有冲突？列出原话和出处。','Does this conflict with what earlier meetings or docs said? Quote both with sources.'],
 ['open','列出还没定的事','List open questions','列出本场还没定的事，每条写卡在哪、谁能拍板。','List what this meeting has not decided yet, where each is stuck and who can decide.']
 ].map(([id,zh,en,promptZh,promptEn])=>({id,zh,en,promptZh,promptEn}));
 function create(storage,key='tht-prompt-library:v1',base=defaults){
  let state={items:base.map(x=>({...x})),usage:{}};
  try{const saved=JSON.parse(storage.getItem(key)||'null');if(saved?.version===1&&Array.isArray(saved.items)){state.items=saved.items.slice(0,30).filter(valid).filter(x=>!(x.id==='shawn'&&/Shawn/.test(x.zh||'')&&/Shawn 刚才的意思/.test(x.promptZh||''))).map(clean);   // 旧默认里写死人名的那条不再带出（自己改过的保留）
state.usage=Object.fromEntries(state.items.map(x=>[x.id,Math.min(100000,Math.max(0,Number(saved.usage?.[x.id])||0))]));}}catch{}
  function valid(x){return x&&typeof x.id==='string'&&x.id.trim()&&['zh','en'].some(k=>typeof x[k]==='string'&&x[k].trim())&&['promptZh','promptEn'].some(k=>typeof x[k]==='string'&&x[k].trim());}
  function clean(x){return Object.fromEntries(['id','zh','en','promptZh','promptEn'].map(k=>[k,String(x[k]||'').trim().slice(0,k.startsWith('prompt')?4000:80)]));}
  function save(){storage.setItem(key,JSON.stringify({version:1,...state}));}
  return {list:()=>state.items.map(x=>({...x})),recommended:()=>state.items.map((x,i)=>({...x,order:i})).sort((a,b)=>(state.usage[b.id]||0)-(state.usage[a.id]||0)||a.order-b.order).slice(0,3),
   put(item){if(!valid(item))throw Error('Enter a label and complete instruction.');const next=clean(item);next.zh=next.zh||next.en;next.en=next.en||next.zh;next.promptZh=next.promptZh||next.promptEn;next.promptEn=next.promptEn||next.promptZh;const at=state.items.findIndex(x=>x.id===next.id);if(at<0&&state.items.length>=30)throw Error('Maximum 30 prompts.');const before=state.items.slice();at<0?state.items.push(next):state.items.splice(at,1,next);try{save();}catch(e){state.items=before;throw e;}},
   remove(id){const at=state.items.findIndex(x=>x.id===id);if(at<0)return false;const before=state.items.slice();state.items.splice(at,1);try{save();}catch(e){state.items=before;throw e;}return true;},
   use(id){if(!state.items.some(x=>x.id===id))return;state.usage[id]=Math.min(100000,(state.usage[id]||0)+1);try{save();}catch{}},
   instruction:(id,lang)=>{const x=state.items.find(x=>x.id===id);return x?.[lang==='en'?'promptEn':'promptZh']||'';}};
 }
 return {create,meetingDefaults};
});
