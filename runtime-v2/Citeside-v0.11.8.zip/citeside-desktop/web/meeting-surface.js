/* The recorder, source board and rich document retain their existing owners. */
(()=>{
 const pane=document.querySelector('.transcript-pane'),record=document.querySelector('.meeting-record');if(!pane||!record)return;
 // A single replaceable recap lives outside the insight timeline and human document.
 const discussion=document.createElement('section'),discussionTitle=document.createElement('strong'),discussionText=document.createElement('p'),discussionSources=document.createElement('details'),discussionSourceTitle=document.createElement('summary'),discussionQuote=document.createElement('p');
 discussion.className='surface-discussion';discussion.hidden=true;discussion.setAttribute('aria-label','正在讨论 / Current discussion');
 discussion.style.cssText='padding:12px 0;border-bottom:1px solid #d9ddd7;overflow-wrap:anywhere';
 discussionText.style.cssText='margin:6px 0;line-height:1.55';discussionText.setAttribute('role','status');discussionText.setAttribute('aria-atomic','true');
 discussionSources.style.cssText='font-size:12px;line-height:1.5';discussionQuote.style.whiteSpace='pre-wrap';
 discussionSources.append(discussionSourceTitle,discussionQuote);discussion.append(discussionTitle,discussionText,discussionSources);pane.prepend(discussion);
 let discussionStatus=null,discussionKey='',discussionMeeting='';
 function paintDiscussion(current=session,lang=language){
  const value=discussionStatus?.discussion,same=!!current?.id&&discussionStatus?.sessionId===current.id;
  const show=same&&discussionStatus.active&&!current.end&&typeof value?.text==='string'&&!!value.text.trim()&&typeof value.quote==='string'&&!!value.quote.trim()&&Array.isArray(value.sourceIds)&&value.sourceIds.length>0;
  discussion.hidden=!show;
  if(!show){discussionText.textContent='';discussionQuote.textContent='';discussionSources.open=false;discussionKey='';return;}
  const en=lang==='en',paused=discussionStatus.phase==='paused';
  discussionTitle.textContent=paused?(en?'Current discussion · Paused':'正在讨论 · 已暂停'):(en?'Current discussion':'正在讨论');
  discussionSourceTitle.textContent=en?'Source excerpt':'来源原文';
  const key=JSON.stringify([current.id,value.text,value.quote,value.sourceIds]);
  if(key!==discussionKey){discussionText.textContent=value.text;discussionQuote.textContent=value.quote;if(discussionMeeting!==current.id)discussionSources.open=false;discussionKey=key;discussionMeeting=current.id;}
 }
 window.addEventListener('message',event=>{if(event.origin!==location.origin||event.source!==parent||event.data?.type!=='tht-discussion-status')return;if(event.data.sessionId&&event.data.sessionId!==session?.id)return;discussionStatus=event.data;paintDiscussion();});
 window.addEventListener('tht-board-data',event=>paintDiscussion(event.detail.data.session,event.detail.lang));
 window.addEventListener('tht-board-language',event=>paintDiscussion(session,event.detail.lang));
 document.body.classList.add('document-surface');
 const head=pane.querySelector('.record-heading'),controls=document.createElement('div'),collapse=document.createElement('button'),close=document.createElement('button'),restore=document.createElement('button'),elapsed=document.createElement('span');
 controls.className='surface-controls';collapse.type=close.type=restore.type='button';collapse.textContent='−';close.textContent='×';elapsed.className='surface-elapsed';head.prepend(elapsed);controls.append(collapse,close);const level=document.createElement('meter');level.className='surface-audio';level.min=0;level.max=1;level.value=0;level.setAttribute('aria-label','Audio input level');head.append(level);const audioStatus=document.createElement('span');audioStatus.className='surface-audio-status';audioStatus.setAttribute('role','status');head.append(audioStatus);head.append(controls);restore.className='transcript-restore';document.body.append(restore);
 const recap=document.querySelector('.recap-pane'),dock=document.createElement('aside'),summaryRestore=document.createElement('button');
 dock.className='surface-record-dock';dock.setAttribute('aria-label','Meeting records');document.body.append(dock);if(recap)dock.append(recap);dock.append(pane);
 summaryRestore.type='button';summaryRestore.className='summary-restore';document.body.append(summaryRestore);
 let summaryMode='closed',recordKey='',summaryChosen=false,endedSeen=false;function remember(){if(recordKey)try{localStorage.setItem(recordKey,JSON.stringify({summary:summaryMode,transcript:mode,...(summaryChosen?{summaryByUser:true}:{})}));}catch{}};
 // 诊断 2026-10-23 #1：结束且确实录过的会默认展开总结；用户自己开关过（summaryByUser）就照他的；进行中的会返回 null，沿用原规则。
 const postMeetingSummary=(current,saved={})=>{if(!current?.end||!(Array.isArray(current.transcript)&&current.transcript.length))return null;return saved.summaryByUser&&['open','collapsed','closed'].includes(saved.summary)?saved.summary:'open';};window.ThtPostMeetingSummary=postMeetingSummary;
 const reveal=()=>{if(parent!==window)parent.postMessage({type:'tht-summary-reveal'},location.origin);};const summaryControls=document.createElement('div'),summaryCollapse=document.createElement('button'),summaryClose=document.createElement('button'),summaryHead=document.createElement('div');
 summaryHead.className='record-heading';summaryControls.className='surface-controls';summaryCollapse.type=summaryClose.type='button';summaryCollapse.textContent='−';summaryClose.textContent='×';summaryControls.append(summaryCollapse,summaryClose);
 if(recap){summaryHead.append(recap.querySelector('h2'),summaryControls);recap.prepend(summaryHead);recap.classList.add('surface-summary');}
 function layout(){remember();if(parent!==window)parent.postMessage({type:'tht-record-panels',summary:summaryMode,transcript:mode},location.origin);document.body.classList.toggle('surface-records-open',mode!=='closed'||summaryMode!=='closed');dock.hidden=mode==='closed'&&summaryMode==='closed';}
 function setSummary(next){summaryMode=next;if(recap){recap.hidden=next==='closed';recap.classList.toggle('surface-collapsed',next==='collapsed');}summaryRestore.hidden=next!=='closed';summaryCollapse.setAttribute('aria-expanded',String(next==='open'));layout();}
 const chooseSummary=next=>{summaryChosen=true;setSummary(next);};summaryCollapse.onclick=()=>chooseSummary(summaryMode==='collapsed'?'open':'collapsed');summaryClose.onclick=()=>chooseSummary('closed');summaryRestore.onclick=()=>chooseSummary('open');
 const join=document.createElement('button');join.type='button';join.className='surface-join';join.hidden=true;document.querySelector('header .tools')?.prepend(join);let calendarEvent=null,canContinue=false;join.onclick=()=>{if(parent!==window)parent.postMessage(canContinue?{type:'tht-continue-meeting',id:session?.id}:{type:'tht-calendar-join',event:calendarEvent},location.origin);};
 const menu=document.querySelector(parent!==window?'.mother-document-footer':'.app-menu nav')||document.querySelector('.app-menu nav');for(const id of ['lang','export','assistant-toggle']){const control=document.getElementById(id);if(control)menu.append(control);}
 const format=document.createElement('button');format.type='button';format.className='surface-format';format.textContent='格式工具 / Formatting';format.onclick=()=>{document.body.classList.toggle('surface-format-open');document.querySelector('.app-menu').open=false;};menu.append(format);const small=document.createElement('button');small.type='button';small.textContent='小窗模式 / Mini window';small.onclick=()=>{parent.postMessage({type:'tht-app-panel',mode:'smallwindow'},location.origin);document.querySelector('.app-menu').open=false;};if(parent!==window)menu.append(small);
 let recordingSeconds=null,recordingState='idle';
 let mode='closed',session=null,language=localStorage.getItem('tht-board-lang')||'zh';
 function labels(){const en=language==='en';restore.textContent=en?'Transcript':'实时转写';summaryRestore.textContent=en?'Summary':'总结';summaryCollapse.setAttribute('aria-label',en?'Collapse summary':'折叠总结');summaryClose.setAttribute('aria-label',en?'Close summary':'关闭总结');join.textContent=canContinue?(en?'Start new meeting':'开始新会议'):(en?'Join':'加入');collapse.setAttribute('aria-label',en?'Collapse transcript':'折叠转写');close.setAttribute('aria-label',en?'Close transcript':'关闭转写');}
 function set(next){mode=next;pane.hidden=next==='closed';pane.classList.toggle('surface-collapsed',next==='collapsed');restore.hidden=next!=='closed';pane.classList.add('surface-transcript');collapse.setAttribute('aria-expanded',String(next==='open'));layout();document.querySelector('#record-toggle')?.setAttribute('aria-expanded',String(next!=='closed'));}
 collapse.onclick=()=>set(mode==='collapsed'?'open':'collapsed');close.onclick=()=>set('closed');restore.onclick=()=>set('open');window.addEventListener('tht-summary-toggle',()=>chooseSummary(summaryMode==='closed'?'open':'closed'));window.addEventListener('tht-transcript-toggle',()=>set(mode==='closed'?'open':'closed'));
 document.querySelector('#record-toggle').onclick=()=>set(mode==='closed'?'open':'closed');
 function candidateTranscript(data){
  const s=data.session||{},modules=data.source?.board?.modules||[],native=[s.nativeInsights?.suggestion,...(s.nativeInsights?.insights||[])].filter(Boolean);
  const ids=new Set([...modules,...native,...(s.factchecks||[])].flatMap(m=>m.sourceRefs||[]).map(ref=>typeof ref==='string'?ref:ref?.segId).filter(Boolean));
  return (s.transcript||[]).filter((row,i)=>{const id=String(row.segId||row.id||'segment-'+i);return ids.has(id)||ids.has(data.source?.id+':'+id)||ids.has(s.id+':'+id);}).map((row,i)=>({segId:String(row.segId||row.id||'segment-'+(s.transcript||[]).indexOf(row)),text:row.text,speaker:row.speaker||row.spk||row.who||'',t:row.t,at:row.at}));
 }
 window.addEventListener('tht-board-data',e=>{if(session?.id!==e.detail.data.session?.id){recordingSeconds=null;recordingState='idle';audioStatus.dataset.state='idle';audioStatus.textContent='';level.value=0;level.hidden=true;}session=e.detail.data.session;if(session?.end&&recordingState==='idle')recordingSeconds=null;tick();const nextKey='tht-record-panels:'+e.detail.id;if(recordKey!==nextKey){let saved={};try{saved=JSON.parse(localStorage.getItem(nextKey)||'{}');}catch{};recordKey=nextKey;summaryChosen=!!saved.summaryByUser;set(recordMode(saved.transcript));const post=postMeetingSummary(session,saved);setSummary(post||(workspaceLeft?'closed':recordMode(saved.summary)));if(post==='open')reveal();}else if(!endedSeen&&!summaryChosen&&postMeetingSummary(session)==='open'){setSummary('open');reveal();}endedSeen=!!session?.end;calendarEvent=e.detail.data.source?.calendarEvent;canContinue=!!(session?.end&&e.detail.data.source?.kind==='meeting');join.hidden=!(canContinue||(calendarEvent&&e.detail.data.source?.kind==='note'));document.body.classList.toggle('surface-prepared',!!calendarEvent&&e.detail.data.source?.kind==='note');language=e.detail.lang;labels();const detail={type:'tht-proactive-data',id:e.detail.id,lang:language,meetingTitle:e.detail.data.meetingTitle,timeAnchors:e.detail.data.timeAnchors||[],source:e.detail.data.source,session:{id:session?.id,title:session?.title,topicTitle:session?.topicTitle,start:session?.start,end:session?.end,transcript:candidateTranscript(e.detail.data),fullTranscript:session?.transcript||[],names:session?.names||{},nativeInsights:session?.nativeInsights,topicControls:session?.topicControls,factchecks:session?.factchecks},modules:e.detail.data.source?.board?.modules||[]};window.__thtProactiveData=detail;if(parent!==window)parent.postMessage(detail,location.origin);else window.dispatchEvent(new CustomEvent('tht-proactive-data',{detail}));});
 window.addEventListener('tht-board-loading',()=>{
  session=null;discussionStatus=null;paintDiscussion();recordingSeconds=null;recordingState='idle';level.value=0;level.hidden=true;audioStatus.textContent='';audioStatus.dataset.state='idle';
  calendarEvent=null;canContinue=false;join.hidden=true;recordKey='';endedSeen=false;summaryChosen=false;document.body.classList.remove('surface-prepared');tick();
 });
 window.addEventListener('tht-board-language',e=>{language=e.detail.lang;labels();});
 window.addEventListener('message',e=>{if(e.origin===location.origin&&e.source===parent&&e.data?.type==='tht-composer-layout'){const bottom=Number(e.data.bottom);if(Number.isFinite(bottom))document.documentElement.style.setProperty('--meeting-composer-bottom',Math.max(90,Math.min(innerHeight-100,bottom))+'px');const documentBottom=e.data.documentBottom;if(typeof documentBottom==='number'&&Number.isFinite(documentBottom))document.documentElement.style.setProperty('--meeting-document-bottom',Math.max(48,Math.min(Math.max(48,innerHeight-100),documentBottom))+'px');return;}if(e.origin===location.origin&&e.source===parent&&e.data?.type==='tht-summary-toggle'){chooseSummary(e.data.open===true||summaryMode==='closed'?'open':'closed');return;}if(e.origin===location.origin&&e.source===parent&&e.data?.type==='tht-transcript-toggle'){set(mode==='closed'?'open':'closed');return;}if(e.origin===location.origin&&e.source===parent&&e.data?.type==='tht-transcript-open'){set('open');return;}if(e.origin!==location.origin||e.source!==parent||e.data?.type!=='tht-audio-level')return;const same=!!session?.id&&e.data.sessionId===session.id;recordingSeconds=same&&typeof e.data.elapsedSeconds==='number'&&Number.isFinite(e.data.elapsedSeconds)?Math.max(0,e.data.elapsedSeconds):same&&!session?.end?recordingSeconds:null;level.value=same&&e.data.active?Math.max(0,Math.min(1,Number(e.data.level)||0)):0;level.hidden=!same||!e.data.active;const state=!same?'idle':e.data.state||(!e.data.active?'idle':level.value>.006?'sound':'quiet');const words={starting:['正在连接声音…','Connecting audio…'],idle:['未收音','Not listening'],sound:['收到声音','Sound received'],quiet:['暂时安静','Quiet'],paused:['已暂停','Paused'],disconnected:['连接中断','Connection lost'],waiting:['等待声音','Waiting for audio']};audioStatus.textContent=(words[state]||words.idle)[language==='en'?1:0];audioStatus.dataset.state=state;recordingState=state;tick();});
 let workspaceReady=false,workspaceLeft=false;
 function recordMode(saved){const chosen=['open','collapsed','closed'].includes(saved)?saved:(workspaceReady?'open':'closed');return workspaceLeft?'open':chosen;}
 window.addEventListener('message',e=>{
  if(e.origin!==location.origin||e.source!==parent||e.data?.type!=='tht-workspace-layout')return;
  const next=e.data;document.body.classList.toggle('mw-output-detail',!!(next.enabled&&next.outputDetail));document.body.classList.toggle('mw-child',!!next.enabled);document.body.classList.toggle('mw-float',!!(next.enabled&&next.float));
  for(const key of ['left','right']){document.body.classList.toggle('mw-'+key+'-closed',!next[key]);const width=next.widths?.[key];const viewport=Number(typeof innerWidth==='number'?innerWidth:NaN),rightCap=Math.max(960,Number.isFinite(viewport)?Math.round(viewport*0.48):0);if(Number.isFinite(width)&&width>=0&&width<=(key==='right'?rightCap:640))document.body.style.setProperty('--mw-'+key,width+'px');}
  const wasLeft=workspaceLeft;workspaceLeft=!!(next.enabled&&next.left!==false);
  if(next.enabled&&!workspaceReady){workspaceReady=true;const link=document.createElement('link');link.rel='stylesheet';link.href='meeting-workspace.css?v=63';document.head.append(link);}
  if(workspaceLeft){set('open');if(!wasLeft)setSummary(postMeetingSummary(session,{summary:summaryMode,summaryByUser:summaryChosen})||'closed');}
 });
 document.addEventListener('keydown',e=>{if(document.querySelector('dialog[open]'))return;if(parent===window||!workspaceReady||e.defaultPrevented||e.metaKey||e.ctrlKey||e.altKey||e.repeat)return;const t=e.target;if(t?.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(t?.tagName||''))return;if(e.key==='Escape'||e.key.toLowerCase()==='t'){e.preventDefault();parent.postMessage({type:'tht-panel-key',key:e.key==='Escape'?'Escape':'t'},location.origin);}});
 function transcriptElapsed(){
  const rows=session?.transcript;if(!Array.isArray(rows)||!rows.length)return 0;
  const start=Number(session.start)||Date.parse(session.start);let max=0,seen=false;
  for(const row of rows)for(const value of [row?.t,row?.at]){
   let sec=NaN;
   if(typeof value==='string'&&/^\d+:\d{2}(?::\d{2})?$/.test(value)){const p=value.split(':').map(Number);if(p.slice(1).every(n=>n<60))sec=p.reduce((a,n)=>a*60+n,0);}
   else if(typeof value==='number'||(typeof value==='string'&&/^\d+(?:\.\d+)?$/.test(value))){const n=Number(value);sec=n>1e11?(Number.isFinite(start)?Math.floor((n-start)/1000):NaN):n>=0?Math.floor(n):NaN;}
   else if(typeof value==='string'){const ms=Date.parse(value);if(Number.isFinite(ms)&&Number.isFinite(start))sec=Math.floor((ms-start)/1000);}
   if(Number.isFinite(sec)&&sec>=0&&(!seen||sec>max)){seen=true;max=sec;}
  }
  return seen?max:0;
 }
 function tick(){const start=Number(session?.start)||Date.parse(session?.start),end=Number(session?.end)||Date.parse(session?.end);const seconds=recordingSeconds!==null?Math.floor(recordingSeconds):Number.isFinite(start)&&Number.isFinite(end)?Math.max(0,Math.floor((end-start)/1000)):transcriptElapsed();elapsed.hidden=recordingState==='starting';audioStatus.setAttribute('aria-busy',String(recordingState==='starting'));const h=Math.floor(seconds/3600),clock=(h?h+':':'')+Math.floor(seconds%3600/60).toString().padStart(2,'0')+':'+(seconds%60).toString().padStart(2,'0');
  // An ended meeting shows its final state, not a recorder waiting for sound (audit #4).
  const ended=!!session?.end&&recordingSeconds===null&&recordingState==='idle',en=language==='en';
  // 诊断 2026-10-23 #1：从没录过的（日历「查看材料」打开的会前笔记，开始=结束、没有转写）显示「未开始」，不显示「已结束 · 00:00」。
  const notStarted=ended&&seconds===0&&!(session?.transcript?.length);
  elapsed.textContent=notStarted?(en?'Not started':'未开始'):ended?(en?'Ended · ':'已结束 · ')+clock:clock;elapsed.classList.toggle('ended',ended);audioStatus.hidden=ended;elapsed.classList.toggle('recording',['sound','quiet','paused','waiting','disconnected'].includes(recordingState));}
 set('closed');setSummary('closed');labels();tick();setInterval(tick,1000);
})();
/* 诊断 2026-10-23 #1：会议页上的待办，每条只有「我来做 / 派给别人」这一个入口。
   复用会后处理台的现有接口，不新建后端链路：GET /meeting-actions 读卡（卡不存在时它会在后台调模型生成，
   所以先用只读的 GET /home-items 判断这场有没有卡：有才自动读；没有就等用户点「整理待办」，回看旧会不花 token）；POST /meeting-action do:'claim'（我来做）；
   派给别人 = 卡还不是派人类型时先 POST /todo-say「第 N 条派给 X」改派（不外发），再 POST /meeting-action do:'send' + confirmed:true 真建飞书任务。 */
(()=>{
 const SELF=/^(?:我|本人|自己|me|myself)$/i,ISO=/^\d{4}-\d{2}-\d{2}$/;
 const isSelf=name=>SELF.test(name)||(data?.selfNames||[]).some(n=>n.toLowerCase()===String(name).toLowerCase());
 const liveCards=data=>(data?.cards||[]).filter(c=>c&&c.state!=='dismissed');
 const cardNumber=(data,cardId)=>liveCards(data).findIndex(c=>c.id===cardId)+1;
 // 名字要能被 /todo-say 的规则直接读懂（不落到模型）：不带标点、空格只用在英文名之间。
 const validName=value=>{const v=String(value||'').trim();return /^[^\s，,。;；的\d]{1,20}(?: [A-Za-z][A-Za-z.\-]{0,20})*$/.test(v)?v:'';};
 const claimRequest=(meetingId,card)=>({route:'/meeting-action',body:{id:meetingId,cardId:card.id,do:'claim'}});
 const assignRequests=(meetingId,data,card,name,due)=>{
  const d=card.draft||{},steps=[];
  if(card.kind!=='delegate')steps.push({route:'/todo-say',body:{id:meetingId,text:'第'+cardNumber(data,card.id)+'条派给'+name}});
  steps.push({route:'/meeting-action',body:{id:meetingId,cardId:card.id,do:'send',confirmed:true,draft:{assignee:name,...(d.assigneeId&&d.assignee===name?{assigneeId:d.assigneeId}:{}),due:ISO.test(String(due||''))?due:'',dueDefault:!!(d.dueDefault&&d.due===due),description:d.description||card.text||'',links:Array.isArray(d.links)?d.links:[]}}});
  return steps;
 };
 window.ThtMeetingTodos={liveCards,cardNumber,validName,claimRequest,assignRequests};
 const recap=document.querySelector('.recap-pane');if(!recap||typeof fetch!=='function')return;
 const make=(tag,text='',cls='')=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n;};
 const section=make('section','','surface-todos'),heading=make('h3'),list=make('ul'),status=make('p','','surface-todos-status'),people=make('datalist'),prepare=make('button','','surface-todos-prepare');
 people.id='surface-todo-people';prepare.type='button';section.hidden=true;section.append(heading,status,prepare,list,people);
 const context=recap.querySelector('#context-used');if(context)recap.insertBefore(section,context);else recap.append(section);
 let lang=localStorage.getItem('tht-board-lang')==='en'?'en':'zh',sid='',data=null,state='',error='',timer=0,polls=0;
 const notes=new Map(),forms=new Map(),busy=new Set(),uncertain=new Set(),sendStates=new Map(),sendTitles=new Map();
 let wasLive=false;
 const tr=(zh,en)=>lang==='en'?en:zh;
 const token=()=>{try{return JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{return '';}};
 const call=async(route,body)=>{
  const r=await fetch(route+(route.includes('?')?'&':'?')+'token='+encodeURIComponent(token()),body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(120000)}:{cache:'no-store',signal:AbortSignal.timeout(15000)});
  const j=await r.json().catch(()=>({}));if(!r.ok||j.ok===false){const e=Error(j.error||('HTTP '+r.status));e.status=r.status;e.uncertain=!!j.uncertain;throw e;}return j;
 };
 const load=async()=>{
  const requested=sid;clearTimeout(timer);
  try{const j=await call('/meeting-actions?id='+encodeURIComponent(requested));if(requested!==sid||j.sessionId&&j.sessionId!==sid||j.actions?.sessionId&&j.actions.sessionId!==sid)return;state=j.status||'';error=state==='done'?'':j.error||'';if(state==='done')data=j.actions;if(state==='running'&&polls++<36)timer=setTimeout(load,5000);}
  catch(e){if(requested!==sid)return;state='error';error=e.message||String(e);}
  paint();
 };
 // 只读探测：/home-items 只汇总已有的处理台卡，不生成。读不到或这场没有卡，就停在「整理待办」按钮上。
 const probe=async()=>{await load();};
 prepare.onclick=()=>{if(!sid||state!=='idle')return;state='running';polls=0;paint();load();};
 function bridgeScheduler(root){
  if(root.__thtLiveBridge)return root.__thtLiveBridge;
  const local=new Set(),payloads=new Map();
  let n=0;
  const post=msg=>{try{parent.postMessage(Object.assign({type:'tht-live-send'},msg),'*');}catch{}};
  const onMessage=e=>{
   const msg=e&&e.data;if(!msg||msg.type!=='tht-live-send')return;
   const item=payloads.get(msg.id);
   if(msg.op==='armed'&&msg.status&&msg.status!=='armed'){local.delete(msg.id);payloads.delete(msg.id);if(item&&item.onCancel)item.onCancel();return;}
   if(msg.op==='fire'){
    if(!item)return;
    local.delete(msg.id);payloads.delete(msg.id);
    Promise.resolve().then(()=>item.send?.()).then(
     ()=>post({type:'tht-live-send-result',token:msg.token,ok:true}),
     err=>post({type:'tht-live-send-result',token:msg.token,ok:false,error:String(err&&err.message||err),status:err&&err.status||0,uncertain:!!(err&&err.uncertain)})
    );
    return;
   }
   if(msg.op==='cancel'){local.delete(msg.id);payloads.delete(msg.id);if(item&&item.onCancel)item.onCancel();}
   if(msg.op==='fail'){local.delete(msg.id);payloads.delete(msg.id);if(item&&item.onFail)item.onFail(Object.assign(Error(msg.error||'状态未确认'),{status:msg.status||0,uncertain:msg.uncertain!==false}));}
  };
  if(typeof root.addEventListener==='function')root.addEventListener('message',onMessage);
  root.__thtLiveBridge={
   arm(id,payload){if(local.has(id))return {status:'once'};local.add(id);payloads.set(id,payload);post({op:'arm',id,token:String(++n)});return {status:'armed'};},
   undo(id){const item=payloads.get(id);local.delete(id);payloads.delete(id);if(item&&item.onCancel)item.onCancel();post({op:'undo',id});return {status:'cancelled'};},
   cancelAll(){const ids=[...local];for(const id of ids)this.undo(id);post({op:'cancelAll'});return ids;},
   pendingIds(){return [...local];}
  };
  return root.__thtLiveBridge;
 }
 function fallbackScheduler(){
  const pending=new Map(),sent=new Set(),inflight=new Set();
  return {arm(id,payload){if(sent.has(id)||pending.has(id)||inflight.has(id))return {status:'once'};const timer=setTimeout(()=>{pending.delete(id);let result;try{result=payload&&payload.send&&payload.send();}catch(error){if(payload&&payload.onFail)payload.onFail(error);return;}if(result&&typeof result.then==='function'){inflight.add(id);Promise.resolve(result).then(()=>{inflight.delete(id);sent.add(id);},error=>{inflight.delete(id);sent.delete(id);if(payload&&payload.onFail)payload.onFail(error);});return;}sent.add(id);},5000);pending.set(id,{timer,payload});return {status:'armed'};},undo(id){if(sent.has(id)||inflight.has(id))return {status:'sent'};const item=pending.get(id);if(!item)return {status:'idle'};clearTimeout(item.timer);pending.delete(id);if(item.payload&&item.payload.onCancel)item.payload.onCancel();return {status:'cancelled'};},cancelAll(){const ids=[...pending.keys()];for(const id of ids)this.undo(id);return ids;},pendingIds(){return [...pending.keys()];}};
 }
 function liveScheduler(){
  const root=typeof window!=='undefined'?window:{};
  try{
   if(typeof parent!=='undefined'&&parent&&parent!==root&&parent.thtLiveSend&&typeof parent.thtLiveSend.arm==='function')return parent.thtLiveSend;
  }catch{return bridgeScheduler(root);}
  if(root.thtLiveSend&&typeof root.thtLiveSend.arm==='function')return root.thtLiveSend;
  const fmt=root.LiveCardFormat;
  if(fmt&&typeof fmt.createSendScheduler==='function'){root.thtLiveSend=fmt.createSendScheduler({setTimer:(fn,ms)=>setTimeout(fn,ms),clearTimer:t=>clearTimeout(t),send:(id,payload)=>payload.send?.()});return root.thtLiveSend;}
  root.thtLiveSend=fallbackScheduler();
  return root.thtLiveSend;
 }
 const run=async(card,steps,fromScheduler)=>{
  const requested=sid,id=card.id;
  if(!fromScheduler&&steps.some(step=>step.body&&step.body.do==='send')){
   const armId='surface:'+requested+':'+id;
   const armed=liveScheduler().arm(armId,{send:()=>run(card,steps,true),onCancel:()=>{sendStates.delete(id);notes.delete(id);paint();},onFail:()=>{sendStates.delete(id);paint();}});
   if(armed&&armed.status==='armed'){const name=steps.find(step=>step.body?.do==='send')?.body.draft?.assignee||'';sendTitles.set(id,name&&!String(card.text).includes(name)?tr('给「'+name+'」','To '+name+' ')+card.text:card.text);sendStates.set(id,'pending');notes.set(id,tr('5 秒后发出，可撤销','Sends in 5 seconds. Undo is available.'));}
   paint();return;
  }
  if(fromScheduler)sendStates.set(id,'inflight');
  busy.add(id);notes.set(id,tr('处理中…','Working…'));paint();
  try{
   for(const step of steps){
    const send=step.body&&step.body.do==='send';
    if(send&&uncertain.has(id)){
     const ask=typeof confirm==='function'?confirm:null;
     if(!ask||!ask(tr('上次没确认发没发出去，确定再发？','The last attempt may already have gone out. Send again?')))
      throw Object.assign(Error(tr('未确认，没有重发','Not sent again')),{uncertain:true,status:409});
     step.body.retryConfirmed=true;
    }
    let j;try{j=await call(step.route,step.body);}catch(e){
     const aborted=/aborted|timeout|timed out|AbortError|TimeoutError/i.test(String(e&&(e.name||'')+' '+(e.message||'')));
     if(send&&e&&e.uncertain)uncertain.add(id);
     if(send&&aborted){uncertain.add(id);e=Object.assign(Error(tr('状态未确认','Status unconfirmed')),{uncertain:true,status:e.status||0});}
     throw e;
    }
    if(requested!==sid||j.sessionId&&j.sessionId!==sid||j.actions?.sessionId&&j.actions.sessionId!==sid)return;if(j.actions)data=j.actions;
    if(step.route==='/todo-say'&&j.focus&&j.focus!==id)throw Error(tr('待办列表刚变过，看一眼再派','The list just changed. Check it and try again.'));
    // 改派后服务端判断这个人就是你自己（卡仍是自己做），不外发。
    if(step.route==='/todo-say'&&(data.cards||[]).find(c=>c.id===id)?.kind!=='delegate')throw Error(tr('这是你自己，点「我来做」','That is you. Use Do it.'));
    if(send){sendStates.set(id,'sent');uncertain.delete(id);forms.delete(id);notes.set(id,j.alreadySent?tr('早就派过了，没重发','Already sent; not sent again'):'');}
    else if(step.body.do==='claim')notes.set(id,j.card?.claimFailed?(j.card.claimNote||''):'');
   }
  }catch(e){
   if(requested!==sid)return;
   const send=steps.some(s=>s.body&&s.body.do==='send');
   if(send)sendStates.delete(id);
   const msg=String(e&&e.message||e||'');
   if(send&&(e&&e.uncertain||/状态未确认|未确认，没有重发|上次发送结果还没确认|核对/.test(msg)))notes.set(id,msg);
   else notes.set(id,(send?tr('没派出去：','Not sent: '):tr('没成：','Failed: '))+(e.message||e));
   if(fromScheduler)throw e;
  }
  finally{if(requested===sid){busy.delete(id);paint();}}
 };
 const row=card=>{
  const item=make('li','','surface-todo'),d=card.draft||{},owner=card.owner||d.assignee||'',due=card.due||d.due||'',actions=make('div','','surface-todo-actions'),off=busy.has(card.id);
  const phase=sendStates.get(card.id);item.dataset.candidateId=card.id;
  if(phase){
   const complete=phase==='pending'||phase==='sent';
   if(complete)item.className+=' mw-done-line';
   item.append(make('span',complete?'✓':'',complete?'mw-done-mark':'mw-send-pending'),make('span',(complete?tr('已完成 · ','Done · '):tr('正在发出 · ','Sending · '))+(sendTitles.get(card.id)||card.text),'mw-done-title'));
   if(phase==='sent')return item;
  }else item.append(make('p',card.text||'','surface-todo-text'));
  if(card.background)item.append(make('p',card.background));
  if(card.actForMe){const draft=card.actForMe;item.append(make('p',draft.label||''));if(draft.error||draft.reason)item.append(make('p',draft.error||draft.reason));for(const [n,v] of (draft.versions||[]).entries()){const details=make('details'),pre=make('pre',v.markdown||'');pre.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere';details.open=draft.status==='ready'&&n===draft.versions.length-1;details.append(make('summary',tr('草案版本 ','Draft version ')+(n+1)),pre);item.append(details);}}
  if(card.readOnly)return item;
  const meta=[owner&&!/^(?:说话人\s*)?S\d{1,3}$/i.test(owner)?owner:'',due].filter(Boolean).join(' · ');if(meta)item.append(make('small',meta,'surface-todo-meta'));
  if(card.state==='claimed')actions.append(make('span',tr('已进我的待办','In my to-dos'),'surface-todo-done'));
  else if(card.state==='sent'){const who=d.assignee||owner,text=who?tr('已派给 ','Assigned to ')+who:tr('已派发','Assigned');if(card.sentRef?.url){const a=make('a',text+' ↗','surface-todo-done');a.href=card.sentRef.url;a.target='_blank';a.rel='noopener noreferrer';actions.append(a);}else actions.append(make('span',text,'surface-todo-done'));}
  else{
   const mine=make('button',tr('我来做','Do it'));mine.type='button';mine.disabled=off;mine.onclick=()=>{liveScheduler().undo('surface:'+sid+':'+card.id);notes.delete(card.id);run(card,[claimRequest(sid,card)]);};
   const other=make('button',tr('派给别人','Assign'));other.type='button';other.disabled=off;other.setAttribute('aria-expanded',String(forms.has(card.id)));
   other.onclick=()=>{if(forms.has(card.id))forms.delete(card.id);else forms.set(card.id,{name:owner&&!isSelf(owner)&&!/^(?:说话人\s*)?S\d{1,3}$/i.test(owner)?owner:'',due:ISO.test(due)?due:''});paint();};
   actions.append(mine,other);
   if(liveScheduler().pendingIds().includes('surface:'+sid+':'+card.id)){const undo=make('button',tr('撤销','Undo'));undo.type='button';undo.onclick=()=>{liveScheduler().undo('surface:'+sid+':'+card.id);notes.delete(card.id);paint();};actions.append(undo);}
  }
  item.append(actions);
  const form=forms.get(card.id);
  if(form&&card.state==='open'&&!sendStates.has(card.id)){
   const box=make('form','','surface-todo-assign'),name=make('input'),date=make('input'),go=make('button',tr('派发','Send')),cancel=make('button',tr('取消','Cancel'));
   name.type='text';name.value=form.name;name.placeholder=tr('派给谁','Who');name.setAttribute('aria-label',tr('负责人','Assignee'));name.setAttribute('list',people.id);name.oninput=()=>{form.name=name.value;};
   date.type='date';date.value=form.due;date.setAttribute('aria-label',tr('截止','Due'));date.oninput=()=>{form.due=date.value;};
   go.type='submit';go.disabled=off;cancel.type='button';cancel.onclick=()=>{forms.delete(card.id);notes.delete(card.id);paint();};
   box.onsubmit=e=>{e.preventDefault();const who=validName(name.value);if(!who){notes.set(card.id,tr('写一个名字，不带标点','Enter one name without punctuation'));paint();return;}if(isSelf(who)){notes.set(card.id,tr('这是你自己，点「我来做」','That is you. Use Do it.'));paint();return;}run(card,assignRequests(sid,data,card,who,date.value));};
   box.append(name,date,go,cancel);item.append(box,make('small',tr('点「派发」才真建飞书任务。','Nothing is created until you click Send.'),'surface-todo-hint'));
  }
  const note=notes.get(card.id);if(note)item.append(make('small',note,'surface-todo-note'));
  return item;
 };
 const paint=()=>{
  heading.textContent=tr('待办','To-dos');
  const cards=liveCards(data);section.hidden=!sid||!['idle','running','done','error','unavailable'].includes(state);
  prepare.textContent=tr('整理待办','Prepare to-dos');prepare.hidden=state!=='idle';
  status.textContent=state==='idle'?tr('这场还没整理出待办','No to-dos prepared for this meeting yet'):state==='unavailable'?(error||tr('这场会还没整理出总结，待办暂时整理不了','No summary yet, so to-dos cannot be prepared')):state==='running'?tr('正在整理待办，好了会自己出现。','Preparing to-dos. They will appear here.'):state==='error'?tr('待办没读到：','Could not load to-dos: ')+error:state==='done'&&!cards.length?tr('这场没有要处理的事。','Nothing to handle from this meeting.'):'';status.hidden=!status.textContent;
  // 选人沿用处理台的写法：手填名字；这场会里出现过的负责人放进候选。
  people.replaceChildren(...[...new Set(cards.map(c=>c.draft?.assignee||c.owner||'').filter(v=>v&&!isSelf(v)&&!/^(?:说话人\s*)?S\d{1,3}$/i.test(v)))].map(v=>{const o=make('option');o.value=v;return o;}));
  list.replaceChildren(...(state==='done'?cards.map(row):[]));
  if(state==='done') {
    if((data?.possibleActions||[]).length) {
      list.append(make('li',tr('可能是你','Possibly yours')));
      for(const a of data.possibleActions){
        const li=make('li',a.do||a.text||'');
        for(const [decision,label] of [['claim',tr('认领','Claim')],['dismiss',tr('划走','Move to full list')]]){
          const b=make('button',label);b.type='button';
          b.onclick=async()=>{b.disabled=true;try{await call('/action-attribution',{id:sid,actionId:a.id,decision});await load();}catch(e){b.title=e.message;b.disabled=false;}};
          li.append(b);
        }list.append(li);
      }
    }
    const all=data?.allActions||[];
    if(all.length){const li=make('li'),table=make('table'),head=make('tr');li.append(make('h4',tr('全量清单','All tasks')));head.append(make('th',tr('任务','Task')),make('th',tr('负责人','Owner')));table.append(head);for(const a of all){const trw=make('tr');trw.append(make('td',a.do||a.text||''),make('td',a.owner||tr('未指定','Unassigned')));table.append(trw);}li.append(table);list.append(li);}
  }
 };
 const cancelPending=()=>{for(const id of liveScheduler().pendingIds())if(id.startsWith('surface:'+sid+':'))liveScheduler().undo(id);};
 window.addEventListener('pagehide',cancelPending);
 window.addEventListener('beforeunload',cancelPending);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelPending();});
 window.addEventListener('tht-board-loading',()=>{cancelPending();wasLive=false;sendStates.clear();sendTitles.clear();sid='';data=null;state='';error='';polls=0;clearTimeout(timer);notes.clear();forms.clear();busy.clear();uncertain.clear();paint();});
 window.addEventListener('tht-board-data',e=>{
  const nextLang=e.detail.lang==='en'?'en':'zh',changed=nextLang!==lang;lang=nextLang;const s=e.detail.data.session,eligible=!!(s?.id&&(s.start||s.end)&&Array.isArray(s.transcript)&&s.transcript.length&&/^[A-Za-z0-9_-]{1,80}$/.test(String(s.id)));
  const next=eligible?String(s.id):'';
  if(next!==sid){cancelPending();wasLive=!!(next&&!s.end&&!s.finalized);sendStates.clear();sendTitles.clear();sid=next;data=null;state='';error='';polls=0;clearTimeout(timer);notes.clear();forms.clear();uncertain.clear();if(sid)probe();paint();return;}
  if(wasLive&&(s.end||s.finalized)){wasLive=false;cancelPending();}
  else if(next&&!s.end&&!s.finalized)wasLive=true;
  // 板子数据会反复推送；只在换会或换语言时重画，免得派发表单正填着被清掉。
  if(changed)paint();
 });
 window.addEventListener('tht-board-language',e=>{lang=e.detail.lang==='en'?'en':'zh';paint();});
})();
