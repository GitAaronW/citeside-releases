'use strict';
(() => {
  const root = document.getElementById('account-root');
  const toastNode = document.getElementById('account-toast');
  const boot = window.THT_BOOT || {};
  const params = new URLSearchParams(location.search);
  let storedLang;
  try { storedLang = localStorage.getItem('tht-ui') || localStorage.getItem('tht-board-lang'); } catch {}
  const english = (params.get('lang') || storedLang || navigator.language || '').startsWith('en');
  const T = (zh, en) => english ? en : zh;
  document.documentElement.lang = english ? 'en' : 'zh-CN';
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const paths = { arrow: 'M4 12h15m-6-6 6 6-6 6', chest: 'M5 4h14v16H5V4Zm4 8 2 2 4-4', check: 'm5 12 4 4L19 6', badge: 'm12 2 3 3 4 1 1 4 2 2-2 3-1 4-4 1-3 2-3-2-4-1-1-4-2-3 2-2 1-4 4-1 3-3Zm-4 10 3 3 5-6', shield: 'm12 2 8 4v6c0 5-8 10-8 10S4 17 4 12V6l8-4Zm-4 10 3 3 5-6', clock: 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM12 7v6l4 2', spark: 'm12 2 2 7 8 3-8 3-2 7-3-7-7-3 7-3 3-7Z', list: 'M9 5h12M9 12h12M9 19h12M3 5h1m-1 7h1m-1 7h1', ticket: 'M4 5h16v4a3 3 0 0 0 0 6v4H4v-4a3 3 0 0 0 0-6V5ZM14 5v3m0 3v2m0 3v3', alert: 'M12 3 2 21h20L12 3Zm0 6v5m0 3v1' };
  const icon = name => `<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name] || paths.spark}"/></svg>`;
  const button = (id, label, cls = 'btn', disabled = false) => `<button type="button" id="${id}" class="${cls}" ${disabled ? 'disabled' : ''}>${label}${cls === 'btn' ? icon('arrow') : ''}</button>`;
  const footer = (text, shield = false) => `<p class="foot">${icon(shield ? 'shield' : 'clock')}${text}</p>`;
  let account = {}, mine = {}, view = ['claim', 'share', 'plans', 'redeem'].includes(params.get('view')) ? params.get('view') : 'applogin';
  let authController, pendingGift = false, autoReturned = false;
  const nativePage = () => !!window.webkit?.messageHandlers?.liveMateWindow;
  async function returnToApp(){const result=await api('/account/return-to-app',{});if(!result.ok)message(T('请手动切回 Citeside；如果尚未打开，请先打开应用。','Switch back to Citeside. Open the app first if needed.'));}
  function browserSuccess(){authController?.dispose();authController=null;shell(`<h3>${T('授权成功','Authorization successful')}</h3><p class="lead">${T('账号已登录，请返回 Citeside 继续。','You are signed in. Return to Citeside to continue.')}</p>${button('return-app',T('返回 Citeside','Return to Citeside'))}`);document.getElementById('return-app').onclick=returnToApp;if(!autoReturned){autoReturned=true;void returnToApp();}}
  let selected = 0, claimState = 'ready', busy = false, toastTimer;
  const titles = () => [T('开会时，有人替你查好了资料', 'Someone looks things up while you talk'), T('会开完，待办已经写好', 'Meeting over. Action items written.'), T('听到一半，答案先到了', 'The answer shows up mid-meeting')];
  const date = n => Number.isFinite(Number(n)) && Number(n) > 0 ? new Date(Number(n)).toLocaleDateString(english ? 'en-US' : 'zh-CN', { year: 'numeric', month: english ? 'short' : 'long', day: 'numeric' }) : '—';
  const hours = value => Number.isFinite(Number(value)) ? String(Math.round(Number(value) * 10) / 10) : '0';
  // Server meter is usageAuthority server. Existing Pro keeps its own dates and posters.
  const serverMeter = () => account.usageAuthority === 'server';
  const trialMember = () => serverMeter() && account.plan === 'trial';
  const trialGift = () => serverMeter() && account.plan !== 'pro';
  const shownHours = () => { const n = Number(account.aiHoursLimit); return trialMember() && Number.isFinite(n) && n > 0 ? hours(n) : '20'; };
  const signedIn = () => account.status === 'signed_in';
  const hasAccess = () => signedIn() && account.access?.allowed === true;
  const offlineText = () => T('账号服务暂时连不上', 'The account service is temporarily unavailable');
  async function api(path, body) {
    try {
      const r = await fetch(path, { method: body === undefined ? 'GET' : 'POST', cache: 'no-store', signal: AbortSignal.timeout(5500), headers: { 'Content-Type': 'application/json', 'x-tht-token': boot.relayToken || '' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
      const data = await r.json();
      if (data.status === 'offline' || r.status >= 500) throw Error('offline');
      return data;
    } catch { return { ok: false, status: 'offline', code: 'offline' }; }
  }
  function toast(text) { clearTimeout(toastTimer); toastNode.textContent = text; toastNode.hidden = false; toastTimer = setTimeout(() => { toastNode.hidden = true; }, 3000); }
  async function continueSetup() { account = await api('/account/status'); if (!hasAccess()) return render(); location.assign(boot.onboarding?.finished ? '/seatnote/' : '/seatnote/onboarding.html'); }
  function message(text) { const node = document.getElementById('account-message'); if (node) node.textContent = text; }
  function shell(content, wide = false) { root.innerHTML = `<div class="win ${wide ? 'wide' : ''}"><div class="bd"><div class="ruler" aria-hidden="true"></div>${content}<p id="account-message" class="service-message" role="status"></p></div></div>`; root.hidden = false; }
  function login() {
    authController?.dispose();
    authController=window.CitesideAccountAuth.mount({host:root,text:T,render:(title,body)=>shell(`<h3>${escape(title)}</h3>${body}`),request:api,callback:{lang:english?'en':'zh',port:Number(location.port)},primaryIcon:icon('arrow'),allowCancel:false,loginDescription:T('首次登录赠送 15 小时会议额度和 30 次深度研究，每个账号仅领取一次。','Your first sign-in includes 15 meeting hours and 30 deep research runs, once per account.'),
      onSignedIn:async result=>{pendingGift=result.loginGrant?.granted===true;account=await api('/account/status');authController=null;try{localStorage.setItem('tht-account-changed',String(Date.now()));}catch{}await render();},
      onCancel:()=>{authController=null;login();}});
    const current=authController;
    api('/account/auth/config').then(config=>{if(current!==authController)return;current.setGoogleUrl(config.ok&&config.googleAvailable===true?window.CitesideAccountAuth.googleUrl(account.cloudUrl,location,english?'en':'zh'):'');});
  }

  function unavailable() {
    authController?.dispose();authController=null;
    shell(`<h3>${account.status === 'offline' ? offlineText() : T('账号服务暂不可用', 'Account service unavailable')}</h3>${button('retry', T('重试', 'Retry'))}`);
    document.getElementById('retry').onclick = start;
  }
  async function signout() {
    const result=await api('/account/logout',{});
    if(!result.ok){message(T('退出失败，请重试。','Sign-out failed. Please retry.'));return;}
    pendingGift=false;view='applogin';account=await api('/account/status');await render();
  }
  function gift() {
    pendingGift=false;
    shell(`<h3>${T('登录成功，额度已到账','Signed in. Your allowance is ready.')}</h3><p class="lead">${T('首次登录赠送已记在此账号上。','Your first-sign-in gift is saved to this account.')}</p><div class="ticket"><div><b>${escape(hours(account.aiHoursLimit))}${T(' 小时会议额度',' meeting hours')}</b><span>${escape(account.researchLimit)}${T(' 次深度研究',' deep research runs')}</span></div></div><p class="foot">${T('每个账号仅赠送一次，重复登录不叠加；已有权益保持不变。','Granted once per account. Signing in again does not add another gift. Existing benefits are preserved.')}</p>${button('continue',T('进入 Citeside','Enter Citeside'))}`);
    document.getElementById('continue').onclick=continueSetup;
  }
  function redeem() {
    shell(`<h3>${T('兑换会议额度','Redeem allowance')}</h3><p class="lead">${hasAccess()?T('输入兑换码，补充账号权益。','Enter a code to add account benefits.'):T('已登录。当前所需权益已用尽，请兑换后继续使用。','Signed in. Your allowance is unavailable or used up. Redeem a code to continue.')}</p><form id="redeem-form"><label class="sub" for="invite-code">${T('兑换码','Redemption code')}</label><input class="field" id="invite-code" required autocomplete="off" placeholder="${T('输入兑换码','Enter redemption code')}"><button class="btn" id="redeem-submit" type="submit">${T('兑换','Redeem')}${icon('arrow')}</button></form><p class="foot">${T('首次登录赠送 15 小时会议额度和 30 次深度研究；用尽后可使用兑换码补充相应权益。','First sign-in includes 15 meeting hours and 30 deep research runs. Redeem a code to add benefits after use.')}</p>${hasAccess()?button('continue',T('进入 Citeside','Enter Citeside'),'lnk'):''}${button('signout',T('退出账号','Sign out'),'lnk')}`);
    document.getElementById('continue')?.addEventListener('click',continueSetup);
    document.getElementById('signout').onclick=signout;
    document.getElementById('redeem-form').onsubmit=async event=>{
      event.preventDefault();if(busy)return;
      const input=document.getElementById('invite-code'),inviteCode=input.value.trim();
      if(!inviteCode){message(T('请输入兑换码','Enter a redemption code'));input.focus();return;}
      busy=true;const submit=document.getElementById('redeem-submit');submit.disabled=true;
      try{
        const result=await api('/account/claim',{inviteCode});
        if(!result.ok){if(result.code==='unauthorized'){account={status:'signed_out'};login();return;}message(result.status==='offline'?offlineText():T('兑换码无效、已领取或不符合领取条件，请检查后重试。','This code is invalid, already redeemed, or unavailable for this account. Check and retry.'));return;}
        account=await api('/account/status');
        if(account.status==='offline'||account.enabled===false){unavailable();return;}
        if(!hasAccess()){await render();message(T('当前仍没有可用权益，请检查兑换码或重试。','No allowance is available yet. Check the code or retry.'));return;}
        view='applogin';
        shell(`<h3>${T('兑换成功','Code redeemed')}</h3><p class="lead">${T('权益已记在此账号上。','Your benefits are saved to this account.')}</p>${button('continue',T('进入 Citeside','Enter Citeside'))}`);
        document.getElementById('continue').onclick=continueSetup;
      }finally{busy=false;submit.disabled=false;}
    };
  }
  function claim() {
    if (claimState === 'ready' && account.invite?.claimed) claimState = 'already';
    if (claimState === 'ready' && !account.invite?.eligible) claimState = 'no';
    let content = `<div class="membership-mark ${claimState === 'success' ? 'success' : ''}">${icon(claimState === 'success' ? 'check' : 'badge')}</div>`;
    if (claimState === 'success' && trialMember()) content += `<h3>${T('试用已生效', 'Your trial is on')}</h3><p class="lead">${T(`含 ${shownHours()} 小时。转写和 AI 共用这一笔，不会自动扣款。`, `${shownHours()} hours. Transcription and AI share them. You are not charged.`)}</p>${button('continue', T('继续', 'Continue'))}`;
    else if (claimState === 'success') content += `<h3>${T('30 天 Pro 已生效', 'Your 30 days of Pro are on')}</h3><p class="lead">${T(`到 ${escape(date(account.planUntil))}，含 ${hours(account.aiHoursLimit)} 小时 AI 开会时长。`, `Through ${escape(date(account.planUntil))}, with ${hours(account.aiHoursLimit)} AI meeting hours.`)}</p>${button('continue', T('继续', 'Continue'))}`;
    else if (claimState === 'already' && trialMember()) content += `<h3>${T('你已经领取过了', 'You already claimed this')}</h3><p class="lead">${T(`试用含 ${shownHours()} 小时，记在这个账号上。`, `This account has ${shownHours()} trial hours.`)}</p>${button('continue', T('继续', 'Continue'))}`;
    else if (claimState === 'already') content += `<h3>${T('你已经领取过了', 'You already claimed this')}</h3><p class="lead">${T(`Pro 到 ${escape(date(account.planUntil))}。`, `Pro runs through ${escape(date(account.planUntil))}.`)}</p>${button('continue', T('继续', 'Continue'))}`;
    else if (claimState === 'no') content += `<h3>${T('这个账号不能领取', 'This account is not eligible')}</h3><p class="lead">${T('礼物只给新账号。你可以继续用当前方案。', 'Gifts are for new accounts. Your current plan stays as it is.')}</p>${button('continue', T('继续', 'Continue'))}`;
    else if (trialGift()) content += `<h3>${T('朋友送你的礼物', 'A gift from a friend')}</h3><div class="ticket">${icon('chest')}<div><b>${T(shownHours() + ' 小时试用', shownHours() + ' hours of trial')}</b><span>${T('转写和 AI 共用这一笔时长', 'Transcription and AI share this one allowance')}</span></div><em>${T('待领取', 'Unclaimed')}</em></div>${button('claim', T('领取', 'Claim'))}${button('later', T('稍后', 'Later'), 'lnk')}${footer(T('不用绑卡 · 不会自动扣款', 'No card needed · Never auto-charged'), true)}`;
    else content += `<h3>${T('朋友送你的礼物', 'A gift from a friend')}</h3><div class="ticket">${icon('chest')}<div><b>${T('30 天 Pro', '30 days of Pro')}</b><span>${T('含 8 小时 AI 开会时长', 'Includes 8 AI meeting hours')}</span></div><em>${T('待领取', 'Unclaimed')}</em></div>${button('claim', T('领取', 'Claim'))}${button('later', T('稍后', 'Later'), 'lnk')}${footer(T('不用绑卡 · 到期不扣款', 'No card needed · Never auto-charged'), true)}`;
    shell(content);
    document.getElementById('continue')?.addEventListener('click', continueSetup);
    document.getElementById('later')?.addEventListener('click', continueSetup);
    document.getElementById('claim')?.addEventListener('click', async e => {
      if (busy) return; busy = true; e.currentTarget.disabled = true;
      const result = await api('/account/claim', {}); busy = false;
      if (result.status === 'offline') { message(offlineText()); document.getElementById('claim').disabled = false; return; }
      if (result.code === 'unauthorized') { account = { ...account, email: null }; login(); return; }
      if (['old_account', 'self_invite', 'invalid_invite'].includes(result.code)) claimState = 'no';
      else if (result.status === 'already_claimed') { account = { ...account, ...result }; claimState = 'already'; }
      else if (result.status === 'claimed') { account = { ...account, ...result }; claimState = 'success'; }
      else { message(result.error || offlineText()); document.getElementById('claim').disabled = false; return; }
      claim();
    });
  }
  function inviteUrl() { const url = new URL('/i/' + encodeURIComponent(mine.inviteCode), account.cloudUrl); return url.href; }
  async function copyShare(withImage) {
    const url = inviteUrl();
    const gift = trialGift() ? T('送你 20 小时试用', '20 hours of trial, for you') : T('送你 30 天 Pro', '30 days of Pro, for you');
    const text = `${titles()[selected]}\n${gift}\n${url}`;
    // Posters still say "送你 30 天 Pro". A 20h gift shares the link and this text only.
    if (!trialGift() && withImage && typeof navigator.clipboard?.write === 'function' && typeof ClipboardItem !== 'undefined') {
      try {
        const image = await fetch(new URL(`/share/poster-${selected + 1}${english ? '-en' : ''}.png`, account.cloudUrl), { credentials: 'omit', referrerPolicy: 'no-referrer' });
        if (image.ok && image.headers.get('content-type')?.startsWith('image/png')) {
          await navigator.clipboard.write([new ClipboardItem({ 'image/png': await image.blob(), 'text/plain': new Blob([text], { type: 'text/plain' }) })]);
          toast(T('已复制图文', 'Image and text copied')); return;
        }
      } catch {}
    }
    try { await navigator.clipboard.writeText(!trialGift() && withImage ? text + `\n${new URL(`/share/poster-${selected + 1}${english ? '-en' : ''}.png`, account.cloudUrl).href}` : (trialGift() ? text : url)); toast(T('已复制', 'Copied')); }
    catch { message(T('复制失败，请选择链接复制。', 'Could not copy. Select and copy the link.')); }
  }
  function share() {
    const count = Math.max(0, Number(mine.invitedCount) || 0), url = inviteUrl(), meter = trialGift();
    const countNote = meter ? T('朋友领取了，对方得到 20 小时试用。', 'A friend claimed it and received 20 hours of trial.') : T(`朋友领取了，你的 Pro 延长到 ${escape(date(account.planUntil))}。`, `A friend claimed it. Your Pro now runs to ${escape(date(account.planUntil))}.`);
    shell(`<h3>${meter ? T('送朋友 20 小时试用', 'Give a friend 20 hours of trial') : T('送朋友 30 天 Pro', 'Give a friend 30 days of Pro')}</h3><p class="lead">${meter ? T('朋友在 App 里领取。不用绑卡，不会自动扣款。', 'They claim it in the app. No card needed, and it never charges them.') : T('朋友在 App 领取，你也多 30 天。', 'They claim in the app. You get 30 days too.')}</p>${count ? `<div class="note ok">${icon('check')}${countNote}</div>` : ''}<div class="shares">${titles().map((title, i) => `<button type="button" class="sc ${i === selected ? 'on' : ''}" data-image="${i}" aria-pressed="${i === selected}"><b>${title}</b></button>`).join('')}</div><div class="code"><span>${escape(url)}</span>${button('copy', T('复制链接', 'Copy link'), 'mini')}</div>${button('share', T('分享', 'Share'))}${footer(count ? T(`已成功邀请 ${count} 人`, `${count} ${count === 1 ? 'friend' : 'friends'} joined`) : T('还没有人领取', 'Nobody has claimed yet'))}`);
    root.querySelectorAll('[data-image]').forEach(node => node.onclick = () => { selected = Number(node.dataset.image); share(); });
    document.getElementById('copy').onclick = () => copyShare(false);
    document.getElementById('share').onclick = async () => {
      if (navigator.share) {
        try {
          const payload = { title: T('Citeside', 'Citeside'), text: `${titles()[selected]}\n${trialGift() ? T('送你 20 小时试用', '20 hours of trial, for you') : T('送你 30 天 Pro', '30 days of Pro, for you')}`, url };
          if (!trialGift() && navigator.canShare) {
            try {
              const response = await fetch(new URL(`/share/poster-${selected + 1}${english ? '-en' : ''}.png`, account.cloudUrl), { credentials: 'omit', referrerPolicy: 'no-referrer' });
              if (response.ok && response.headers.get('content-type')?.startsWith('image/png')) {
                const files = [new File([await response.blob()], `citeside-${selected + 1}.png`, { type: 'image/png' })];
                if (navigator.canShare({ files })) payload.files = files;
              }
            } catch {}
          }
          await navigator.share(payload); return;
        }
        catch (e) { if (e.name === 'AbortError') return; }
      }
      await copyShare(true);
    };
  }
  function plans() {
    const trial = trialMember();
    const limit = trial ? Math.max(0, Number(account.aiHoursLimit) || 0) : Math.max(0, Number(account.aiHoursLimit) || window.THT_PLANS[0].hours), used = Math.max(0, Number(account.aiHoursUsed) || 0);
    const days = Math.max(0, Math.ceil((Number(account.planUntil) - Date.now()) / 86400000));
    const capped = trial ? limit > 0 && used >= limit : used >= limit, ending = account.plan === 'pro' && Number(account.planUntil) > 0 && days <= 3;
    let note = trial ? (capped ? T(`试用的 ${hours(limit)} 小时已经用完。转写会停在这里，不会自动扣款。`, `The ${hours(limit)} trial hours are used up. Transcription stops here. You are not charged.`) : T(`试用中：已用 ${hours(used)} / ${hours(limit)} 小时。转写和 AI 共用这一笔。`, `Trial: ${hours(used)} of ${hours(limit)} hours used. Transcription and AI share this allowance.`)) : capped ? T('本月 AI 时长用完了。录音和转写继续，AI 卡片和纪要下个周期恢复。', 'AI hours are used up this cycle. Recording and transcripts keep going. AI cards and notes return next cycle.') : ending ? T(`Pro 还有 ${days} 天到期。到期回到免费版，不会扣款。`, `Pro ends in ${days} days. You return to Free and are not charged.`) : account.plan === 'pro' ? T(`试用中：已用 ${hours(used)} / ${hours(limit)} 小时，到 ${escape(date(account.planUntil))}。`, `Trial: ${hours(used)} of ${hours(limit)} hours used, through ${escape(date(account.planUntil))}.`) : T(`已用 ${hours(used)} / ${hours(limit)} 小时。`, `${hours(used)} of ${hours(limit)} hours used.`);
    const planLabel = id => id !== 'free' ? T('即将开放', 'Coming soon') : account.plan === 'free' ? T('当前方案', 'Current') : trial ? T('不会自动扣款', 'Never auto-charged') : T('到期后回到这里', 'After trial');
    const features = [[T('会中 AI 卡片', 'Live AI cards'), T('会后纪要和待办', 'Notes and action items'), T('超出后只录音转写', 'Then recording and transcripts only')], [T('免费版全部内容', 'Everything in Free'), T('全部连接器', 'All connectors'), T('历史不限', 'Unlimited history')], [T('Pro 全部内容', 'Everything in Pro'), T('会后深度分析', 'Deep post-meeting analysis'), T('会中专家卡', 'Live expert cards')]];
    shell(`<h3>${T('方案', 'Plans')}</h3><div class="note ${capped ? 'warn' : 'info'}">${icon(capped ? 'alert' : 'check')}${note}${!capped && !ending ? '<div class="meter" role="meter" aria-valuemin="0" aria-valuemax="100"><i></i></div>' : ''}</div><div class="plans">${window.THT_PLANS.map((plan, i) => `<div class="plan ${plan.id === 'pro' ? 'hl' : ''}"><h4>${icon(['ticket', 'badge', 'chest'][i])}${plan.id === 'free' ? T('免费', 'Free') : plan.id === 'pro' ? 'Pro' : 'Max'}</h4><div class="p">$${plan.price}${plan.price ? `<small>${T(' /月', ' /mo')}</small>` : ''}</div><div class="h">${T(`每月 ${plan.hours} 小时`, `${plan.hours} hours a month`)}</div><ul>${features[i].map((f, j) => `<li>${icon(['spark', 'list', 'clock'][j])}${f}</li>`).join('')}</ul>${button(`plan-${plan.id}`, planLabel(plan.id), 'mini', true)}</div>`).join('')}</div>`, true);
    const meter = root.querySelector('.meter'); if (meter) { const value = Math.min(100, used / limit * 100); meter.setAttribute('aria-valuenow', String(value)); meter.firstElementChild.style.width = `${value}%`; }
  }
  async function render() {
    if (account.status === 'offline' || account.enabled === false || account.status === 'disabled') return unavailable();
    if (!signedIn()) return login();
    if (view === 'applogin' && !nativePage()) return browserSuccess();
    if (!hasAccess() || view === 'redeem') return redeem();
    if (pendingGift) return gift();
    if (view === 'applogin') return continueSetup();
    if (view === 'claim') return claim();
    if (view === 'plans') return plans();
    if (view === 'share') {
      mine = await api('/account/mine');
      if (!mine.ok || !mine.inviteCode || !account.cloudUrl) { shell(`<h3>${T('邀请朋友', 'Invite a friend')}</h3>`); message(offlineText()); return; }
      share();
    }
  }
  async function start() {
    // Consume and remove fragments before any network activity; never persist a login token here.
    const incoming = new URLSearchParams(location.hash.slice(1)).get('token');
    if (location.hash) history.replaceState(null, '', location.pathname + location.search);
    account = await api('/account/status');
    if (incoming) {
      const result = await api('/account/login/verify', { token: incoming, appLink: true });
      if (!result.ok) { login(); message(result.status === 'offline' ? offlineText() : T('登录链接已过期，请重新登录。', 'This sign-in link has expired. Please sign in again.')); return; }
      pendingGift=result.loginGrant?.granted===true;account = await api('/account/status');
      try { localStorage.setItem('tht-account-changed', String(Date.now())); } catch {}
    }
    await render();
  }
  window.addEventListener('pagehide',()=>authController?.dispose());
  const refreshAccountOnReturn = async () => { if (view !== 'applogin' || signedIn() || authController?.busy) return; const next = await api('/account/status'); if (next.status==='signed_in') { authController?.dispose();authController=null;account = next; await render(); } };
  window.addEventListener('focus',refreshAccountOnReturn);
  window.addEventListener('citeside-native-active',refreshAccountOnReturn);
  start();
})();
