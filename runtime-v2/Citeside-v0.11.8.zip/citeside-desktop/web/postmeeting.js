'use strict';(()=>{const relayBase=()=>'/asr-relay',timeoutSignal=ms=>AbortSignal.timeout(ms);const fetch=(url,opt)=>{const u=new URL(url,location.origin),token=new URLSearchParams(location.search).get('token')||(()=>{try{return JSON.parse(window.localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{return '';}})();if(token)u.searchParams.set('token',token);return window.fetch(u.href,opt);};
    // 会后结果：结论（前三行）+ 要你处理，共用服务端四块数据与首页投影。
    // 每块各有状态 pending / running / done / skipped / failed，按顺序流式出来；生成完可以原地编辑，编辑存成新版本，不覆盖旧版。
    // 只读、只轮询：前端从不触发生成。历史会议打开时拿到的就是终态，不轮询、不重跑。
    // 挂载点在 25d-timeline.js 的 tlPaint（会议已结束那一行之后）。
    const PM_ENDPOINT='/native/postmeeting?id=';
    const PM_POLL_MS=2500,PM_MOCK_MS=900,PM_POLL_MAX_MS=15*60*1000,PM_FAIL_MAX=3;
    const PM_BLOCKS=['summary','actions','drafts','decisions'];
    const PM_STATUS=new Set(['pending','running','done','skipped','failed']),PM_TERMINAL=new Set(['done','skipped','failed']);
    const pmT=(zh,en)=>document.documentElement.lang==='en'?en:zh;
    const pmEsc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
    // mock 只在开发 / 测试下用：测试和静态预览页显式设 window.THT_POSTMEETING_MOCK；本地 file:// 预览可加 ?pm-mock=1。线上拿不到接口就显示「重试」，不编内容。
    const pmMockAllowed=()=>{try{if(window.THT_POSTMEETING_MOCK)return true;return location.protocol==='file:'&&new URLSearchParams(location.search).get('pm-mock')==='1';}catch{return false;}};
    const pmMockVariant=()=>{const v=window.THT_POSTMEETING_MOCK;return typeof v==='string'?v:'';};

    // ——— mock：形状 = {meetingId, summary, actions:{mine,possibly_you,all}, drafts, decisions, progress}，每块带 status ———
    const pmMockFinal=id=>({meetingId:id,
      summary:{status:'done',text:pmT('评审了新版引导页。大家同意第一屏只讲一件事，第二屏文案太长要压到三句以内。跳过按钮放哪还没定，下次评审前要给结论。','Reviewed the new onboarding. Agreed the first screen says one thing; the second screen copy must shrink to three sentences. Placement of the skip button is still open.')},
      actions:{status:'done',
        mine:[{id:'a1',text:pmT('把引导页第二屏文案压到三句以内','Cut onboarding screen two copy to three sentences'),due:'2026-10-29'},{id:'a2',text:pmT('约设计过一遍空状态插画','Review empty-state illustrations with design')}],
        possibly_you:[{id:'p1',text:pmT('把评审结论同步给海外团队','Share the review outcome with the overseas team'),hint:pmT('会上说「产品这边同步一下」，没点名','Someone said “product will sync”, no name given')}],
        all:[{id:'a1',text:pmT('把引导页第二屏文案压到三句以内','Cut onboarding screen two copy to three sentences'),owner:pmT('我','Me')},{id:'a2',text:pmT('约设计过一遍空状态插画','Review empty-state illustrations with design'),owner:pmT('我','Me')},{id:'x1',text:pmT('出两版按钮动效','Two versions of the button motion'),owner:pmT('设计','Design')},{id:'x2',text:pmT('确认埋点口径','Confirm the analytics definitions'),owner:pmT('数据','Data')},{id:'p1',text:pmT('把评审结论同步给海外团队','Share the review outcome with the overseas team'),owner:''}]},
      drafts:{status:'done',items:[
        {id:'d1',for:'a1',kind:'text',title:pmT('第二屏文案三个备选','Three options for screen two copy'),line:pmT('按会上「一屏只讲一件事」改的','Rewritten around “one thing per screen”'),body:pmT('一、说一句，它就记下。\n二、开会时，它替你听。\n三、会开完，事情已经排好。','1. Say it once, it remembers.\n2. In meetings, it listens for you.\n3. When the meeting ends, the work is lined up.')},
        {id:'d2',for:'a2',kind:'message',title:pmT('约设计的消息','Message to design'),line:pmT('复制后自己发','Copy and send it yourself'),body:pmT('周四下午有空吗？想花 20 分钟一起过一下空状态插画，主要看第二屏。','Free Thursday afternoon? 20 minutes on the empty-state illustrations, mainly screen two.')},
        {id:'d3',for:'x1',kind:'text',title:pmT('不该出现','Should not show'),line:'',body:''}]},
      decisions:{status:'done',items:[{id:'q1',text:pmT('跳过按钮放右上还是底部','Skip button: top right or bottom'),context:pmT('两种说法都有人支持，会上没定','Both had support; not settled')}]},
      progress:{done:4,total:4}});
    // variant：'' 正常 / 'skipped' 试音会整场跳过 / 'failed' 待办没出来。fresh=刚结束（逐块流式），否则直接终态（历史会议）。
    const pmMockAt=(id,{fresh=false,step=99,variant='',retried=[]}={})=>{
      const s=pmMockFinal(id);
      if(variant==='skipped'){for(const k of PM_BLOCKS)s[k]={status:'skipped',reason:pmT('这是一场试音，没有整理会后内容','This was a sound check; nothing was prepared')};s.progress={done:4,total:4};return s;}
      if(variant==='failed'&&!retried.includes('actions')){s.actions={status:'failed'};s.drafts={status:'skipped',reason:pmT('待办没整理出来，草案先不做','Drafts wait for the action list')};}
      if(fresh)PM_BLOCKS.forEach((k,i)=>{if(step<i+1)s[k]={status:'pending'};else if(step===i+1)s[k]={status:'running',progress:.45};});
      s.progress={done:PM_BLOCKS.filter(k=>PM_TERMINAL.has(s[k].status)).length,total:PM_BLOCKS.length};
      return s;
    };

    // ——— 数据规整：缺块按 pending，缺列表按空 ———
    const pmList=x=>Array.isArray(x)?x.filter(i=>i&&typeof i==='object'):[];
    const pmNormalize=raw=>{
      const r=raw&&typeof raw==='object'?raw:{},blk=b=>{const o=b&&typeof b==='object'?b:{};return {...o,status:PM_STATUS.has(o.status)?o.status:'pending'};};
      const actions=blk(r.actions),drafts=blk(r.drafts),decisions=blk(r.decisions);
      for(const k of ['mine','possibly_you','all'])actions[k]=pmList(actions[k]);
      // Keep every item reachable even if a producer supplied only a subset list.
      actions.all=[...new Map([...actions.all,...actions.possibly_you,...actions.mine].map(i=>[i.id||i,i])).values()];
      drafts.items=pmList(drafts.items);decisions.items=pmList(decisions.items);
      return {meetingId:String(r.meetingId||''),version:Number.isInteger(r.version)?r.version:null,summary:blk(r.summary),actions,drafts,decisions,progress:r.progress&&typeof r.progress==='object'?r.progress:null};
    };
    const pmTerminal=s=>!!s&&PM_BLOCKS.every(k=>PM_TERMINAL.has(s[k].status));

    // ——— 本地覆盖层：编辑 = 追加版本（旧版保留）；认领 / 划走只动「可能是你」 ———
    const pmNewUi=()=>({tab:'mine',editing:'',editBaseVersion:null,open:new Set(),versions:{},claimed:[],dismissed:[],undo:null,copied:'',note:'',dirty:false,pending:[],confirming:new Set()});
    // 每场会一份覆盖层：内存 Map + localStorage（可能不可用，全部 try/catch）；未确认的写回留在 pending，服务端确认后才清（peer_review e208c78b）。
    const PM_LS='tht-pm-ui:',pmUis=new Map();
    const pmPersist=(id,ui)=>{try{localStorage.setItem(PM_LS+id,JSON.stringify({versions:ui.versions,claimed:ui.claimed,dismissed:ui.dismissed,pending:ui.pending}));}catch{}};
    const pmUiFor=id=>{if(pmUis.has(id))return pmUis.get(id);const ui=pmNewUi();
      try{const o=JSON.parse(localStorage.getItem(PM_LS+id)||'null');if(o&&typeof o==='object'){for(const k of ['claimed','dismissed','pending'])if(Array.isArray(o[k]))ui[k]=o[k];if(o.versions&&typeof o.versions==='object')ui.versions=o.versions;}}catch{}
      pmUis.set(id,ui);return ui;};
    const pmCurrent=(ui,key,orig)=>{const v=ui.versions[key],local=pm.mock||ui.pending.some(op=>op.op==='edit'&&op.target===key);return local&&v&&v.length?v[v.length-1].text:orig;};
    const pmSaveVersion=(ui,key,orig,text)=>{if(pmCurrent(ui,key,orig)===text)return false;const list=ui.versions[key]||(ui.versions[key]=[{text:String(orig??''),at:0,base:true}]);list.push({text,at:Date.now()});return true;};
    const pmView=(s,ui)=>{
      const a=s.actions,gone=new Set([...ui.claimed,...ui.dismissed]);
      const claimed=a.possibly_you.filter(i=>ui.claimed.includes(i.id));
      // Server personal-actions is authoritative; an owner label is never evidence.
      const mine=[...new Map([...a.mine,...claimed].map(i=>[i.id,i])).values()].filter(i=>!ui.dismissed.includes(i.id));
      const mineIds=new Set(mine.map(i=>i.id));
      return {mine,possibly:a.possibly_you.filter(i=>!gone.has(i.id)&&!mineIds.has(i.id)),all:a.all.map(i=>ui.claimed.includes(i.id)?{...i,owner:pmT('我','Me')}:i),
        drafts:s.drafts.items.filter(d=>!d.for||mineIds.has(d.for)),decisions:s.decisions.items.filter(i=>i.status==='agreed'||(!['done','approved','dismissed'].includes(i.status)&&i.pending!==false))};
    };

    // ——— 渲染（纯字符串，方便测试）。界面不出现技术词、id、编号；最多一个主按钮（这里一个都不需要）。 ———
    const PM_TITLE={summary:['结论','Conclusion'],actions:['会议待办','Meeting to-dos'],drafts:['替你做好的草案','Drafts ready for you'],decisions:['要你拍板的事','Needs your call']};
    const PM_RUN={summary:['正在整理纪要','Writing the notes'],actions:['正在理出待办','Sorting out actions'],drafts:['正在起草','Drafting'],decisions:['正在找要你定的事','Finding open calls']};
    const pmSkel=n=>`<div class="pm-skel" aria-hidden="true">${'<i></i>'.repeat(n)}</div>`;
    const pmEditable=(ui,key,text,cls)=>ui.editing===key
      ?`<div class="pm-edit"><textarea data-pm-edit="${pmEsc(key)}" rows="${Math.min(10,Math.max(3,String(text).split('\n').length+1))}">${pmEsc(text)}</textarea><div class="pm-row"><button type="button" class="pm-btn" data-pm="save" data-key="${pmEsc(key)}">${pmT('保存','Save')}</button><button type="button" class="pm-link" data-pm="cancel">${pmT('取消','Cancel')}</button></div></div>`
      :`<div class="${cls}">${pmEsc(text)}</div>${ui.versions[key]?.length>1?`<small class="pm-ver">${pmT('改过','Edited')}</small>`:''}`;
    const pmEditBtn=(ui,key)=>ui.editing===key?'':`<button type="button" class="pm-link" data-pm="edit" data-key="${pmEsc(key)}">${pmT('编辑','Edit')}</button>`;
    const pmEmpty=t=>`<p class="pm-empty">${t}</p>`;
    const pmSummaryHtml=(s,ui)=>{const key='summary',text=pmCurrent(ui,key,s.summary.text||'');
      if(!text)return pmEmpty(pmT('这场没有可整理的内容','Nothing to note from this meeting'));
      const expanded=ui.open.has('summary');
      return `<div${!expanded&&ui.editing!==key?' style="display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden"':''}>${pmEditable(ui,key,text,'pm-text')}</div><div class="pm-row"><button type="button" class="pm-link" data-pm="toggle" data-id="summary" aria-expanded="${expanded}">${expanded?pmT('收起','Show less'):pmT('展开全文','Read full summary')}</button>${pmEditBtn(ui,key)}</div>`;
    };
    const pmItem=(ui,i,extra='')=>{const key='action:'+i.id,text=pmCurrent(ui,key,i.text||'');return `<li class="pm-item">${pmEditable(ui,key,text,'pm-itext')}${i.due&&ui.editing!==key?`<small class="pm-due">${pmT('截止','Due')} ${pmEsc(i.due)}</small>`:''}${extra}</li>`;};
    // Both surfaces use the same postmeeting projection, including explicit Aaron assignments.
    const pmItems=(s,ui,includeAgreed=false)=>{const v=pmView(s,ui),closed=i=>['done','completed','cancelled','dismissed'].includes(i.status);
      return [...v.decisions.filter(i=>!ui.dismissed.includes(i.id)&&(includeAgreed||i.status!=='agreed')).map(i=>({...i,kind:'decision'})),...v.mine.filter(i=>!closed(i)).map(i=>({...i,kind:'action'})),...v.possibly.filter(i=>!closed(i)).map(i=>({...i,kind:'possible'}))].map(i=>({...i,drafts:v.drafts.filter(d=>d.for===i.id)})).concat(v.drafts.filter(d=>!d.for).map(d=>({...d,text:d.title||pmT('草案','Draft'),kind:'draft',drafts:[d]})));
    };
    window.thtPostmeetingItems=raw=>pmItems(pmNormalize(raw),pmUiFor(String(raw.meetingId||'')));
    const pmActionsHtml=(s,ui)=>{
      const items=pmItems(s,ui,true);
      const undo=ui.undo?`<p class="pm-undo">${pmT('已划走','Removed')}「${pmEsc(ui.undo.text)}」<button type="button" class="pm-link" data-pm="undo">${pmT('撤销','Undo')}</button></p>`:'';
      return undo+(items.length?`<ul class="pm-list">${items.map(i=>{
        const uncertain=i.kind==='possible',decision=i.kind==='decision',draft=i.drafts[0];
        const action=draft?'toggle':'edit',label=draft?pmT('看草案','View draft'):pmT('编辑','Edit');
        const button=(decision&&i.status==='agreed'?`<small class="pm-hint">${pmT('已同意','Agreed')}</small>`:decision&&ui.confirming.has(i.id)?`<small class="pm-hint">${pmT('保存中','Saving')}</small>`:'')+`<div class="pm-row"><button type="button" class="pm-btn" data-pm="${action}" data-key="action:${pmEsc(i.id)}" data-id="${pmEsc(draft?draft.id:i.id)}">${label}</button><button type="button" class="pm-link" data-pm="dismiss" data-id="${pmEsc(i.id)}">${pmT('划掉','Cross out')}</button></div>`;
        const details=i.drafts.length?pmDraftsHtml(s,ui,{drafts:i.drafts}):'';
        return pmItem(ui,i,`${uncertain?`<small class="pm-hint">${pmT('可能是你','Maybe yours')}</small>`:''}${i.context||i.hint?`<small class="pm-hint">${pmEsc(i.context||i.hint)}</small>`:''}${button}${details}`);
      }).join('')}</ul>`:'');
    };
    const pmDraftsHtml=(s,ui,v)=>v.drafts.length?`<ul class="pm-list pm-drafts">${v.drafts.map(d=>{
      const key='draft:'+d.id,open=ui.open.has(d.id),text=pmCurrent(ui,key,d.body||''),url=/^https?:\/\//.test(String(d.url||''))?d.url:'';
      const act=url?`<button type="button" class="pm-link" data-pm="open" data-id="${pmEsc(d.id)}">${pmT('打开','Open')}</button>`:`<button type="button" class="pm-link" data-pm="copy" data-id="${pmEsc(d.id)}">${ui.copied===d.id?pmT('已复制','Copied'):pmT('复制','Copy')}</button>`;
      return `<li class="pm-draft${open?' open':''}"><button type="button" class="pm-dhead" data-pm="toggle" data-id="${pmEsc(d.id)}" aria-expanded="${open}"><b>${pmEsc(d.title||pmT('草案','Draft'))}</b>${d.line?`<span>${pmEsc(d.line)}</span>`:''}</button>${open?`<div class="pm-dbody">${pmEditable(ui,key,text,'pm-text pm-pre')}${ui.editing===key?'':`<div class="pm-row">${act}${pmEditBtn(ui,key)}</div>`}</div>`:''}</li>`;}).join('')}</ul>`:pmEmpty(pmT('没有需要替你起草的','Nothing to draft for you'));
    const pmBlockHtml=(k,s,ui,v)=>{
      const b=s[k],[zh,en]=PM_TITLE[k],head=t=>`<header class="pm-h"><h3>${pmT(zh,en)}</h3>${t?`<span class="pm-st">${t}</span>`:''}</header>`;
      let inner;
      if(b.status==='pending')inner=head(pmT('稍等','Queued'))+pmSkel(3);
      else if(b.status==='running'){const p=Number(b.progress),known=Number.isFinite(p)&&p>0&&p<=1;inner=head(pmT('整理中','In progress'))+`<div class="pm-run"><span class="pm-bar${known?'':' pm-indef'}"><b${known?` style="width:${Math.round(p*100)}%"`:''}></b></span><span class="pm-runt">${pmT(...PM_RUN[k])}…</span></div>`+pmSkel(2);}
      else if(b.status==='skipped')return '';
      else if(b.status==='failed')inner=head('');
      else inner=head('')+pmSummaryHtml(s,ui);
      return `<section class="pm-block" data-block="${k}" data-status="${b.status}">${inner}</section>`;
    };
    const pmHtml=(s,ui,{missing=false}={})=>{
      // 服务端还没有这场的会后产物（比如会后整理上线前结束的会）：说清楚并给一个开始的入口，不冒充「没整理出来」。
      if(!s&&missing)return `<div class="pm-top"><h2>${pmT('会后整理','After the meeting')}</h2></div>`+(ui.note?`<p class="pm-note" role="status">${pmEsc(ui.note)}</p>`:'')+`<p class="pm-skip">${pmT('这场会还没整理会后内容。','This meeting has not been prepared yet.')}<button type="button" class="pm-btn" data-pm="start">${pmT('现在整理','Prepare now')}</button></p>`;
      if(!s)return `<div class="pm-top"><h2>${pmT('会后整理','After the meeting')}</h2><span class="pm-st">${pmT('稍等','Queued')}</span></div>`+['summary','actions'].map(k=>`<section class="pm-block" data-block="${k}" data-status="pending"><header class="pm-h"><h3>${pmT(...PM_TITLE[k])}</h3></header>${pmSkel(2)}</section>`).join('');
      const v=pmView(s,ui),done=pmTerminal(s),n=PM_BLOCKS.filter(k=>PM_TERMINAL.has(s[k].status)).length;
      const top=`<div class="pm-top"><h2>${pmT('会后整理','After the meeting')}</h2></div>`;
      const progress=!done?(window.thtResearchProgress?.html({state:'running',step:n,total:PM_BLOCKS.length},{language:document.documentElement.lang,label:pmT('正在整理会议内容','Preparing meeting notes'),hideCount:true})||`<p class="pm-st" role="status">${pmT('正在整理会议内容','Preparing meeting notes')}</p>`):'';
      const force=done&&PM_BLOCKS.every(k=>s[k].status==='skipped')?`<p class="pm-skip"><button type="button" class="pm-btn" data-pm="force">${pmT('现在整理','Prepare now')}</button></p>`:'';
      const failures=PM_BLOCKS.filter(k=>s[k].status==='failed');
      const failure=failures.length?`<p class="pm-fail" role="status">${pmEsc(failures.map(k=>pmT('会议内容暂未整理完成','Meeting notes are not ready yet')).filter((r,i,a)=>a.indexOf(r)===i).join(' · '))} · <button type="button" class="pm-link" data-pm="settings">${pmT('去接','Open settings')}</button>${failures.map(k=>` <button type="button" class="pm-link" data-pm="retry" data-block="${k}">${pmT('重试','Retry')} · ${pmT(...PM_TITLE[k])}</button>`).join('')}</p>`:'';
      if(force)return top+force+(ui.note?`<p class="pm-note" role="status">${pmEsc(ui.note)}</p>`:'');
      return top+failure+progress+force+(ui.note?`<p class="pm-note" role="status">${pmEsc(ui.note)}</p>`:'')+pmBlockHtml('summary',s,ui,v)+(pmItems(s,ui,true).length?`<section class="pm-block" data-block="actions"><header class="pm-h"><h3>${pmT('会议待办','Meeting to-dos')}</h3></header>${!done?`<p class="pm-st">${pmT('整理中','Preparing')}</p>`:''}${pmActionsHtml(s,ui,v)}</section>`:'');
    };

    // ——— 控制器：一场会一个实例；换场即丢弃旧的，迟到的响应不串场 ———
    const pm={id:'',ep:0,fresh:false,state:null,missing:false,ui:pmNewUi(),el:null,timer:0,started:0,fails:0,mock:null,sent:[]};
    // 轮询更新在编辑时先不重画（免得冲掉正在改的字）；用户自己的操作 force 重画。
    let pmReplayTimer=0,pmReplayState=null;
    const pmReplayHtml=()=>pmReplayState&&(pmReplayState.eligible||pmReplayState.status==='running'||pmReplayState.status==='failed')
      ? `<section class="pm-retranscribe"><button class="pm-btn" type="button" data-pm="retranscribe" ${pmReplayState.status==='running'?'disabled':''}>${pmReplayState.status==='running'?pmT('正在重新转写…','Transcribing…'):pmT('重新转写','Transcribe again')}</button><p role="status">${pmEsc(pmReplayState.error||pmT('从保存的录音恢复文字，原音频保留。','Recover text from the saved audio. The audio is kept.'))}</p></section>`:'';
    const pmReplayLoad=async(start=false)=>{
      const id=pm.id,ep=pm.ep;if(!id||pmMockAllowed())return;
      clearTimeout(pmReplayTimer);
      const current=()=>pm.id===id&&pm.ep===ep;
      if(start){pmReplayState={eligible:true,status:'running',error:''};pmRender();}
      try{
        const r=await fetch(relayBase()+'/meeting-retranscribe?id='+encodeURIComponent(id)+'&token='+encodeURIComponent(typeof cfg==='undefined'?'':cfg.relayToken||''),{method:start?'POST':'GET',cache:'no-store',signal:timeoutSignal(15000)});
        const result=await r.json();if(!current())return;
        if(!r.ok)throw Error(result.error||pmT('重新转写未完成，请重试。','Transcription failed. Retry.'));
        const previous=pmReplayState?.status;pmReplayState=result;pmRender();
        if(result.status==='running')pmReplayTimer=setTimeout(()=>pmReplayLoad(),1500);
        else if(result.status==='done'&&previous==='running'){window.thtOpenMeeting?.(id);}
      }catch(e){if(!current())return;if(start||pmReplayState?.status==='running'){pmReplayState={eligible:true,status:'failed',error:pmT('重新转写未完成，请检查转写设置后重试。音频仍保留。','Transcription failed. Check transcription settings and retry. Audio is kept.')};pmRender();}}
    };
    const pmResearchMinutes=(data={})=>{
      const s=pm.state,ui=pm.ui;
      if(!pmTerminal(s)||s.summary.status!=='done'||PM_BLOCKS.some(k=>s[k].status==='failed'))return pmReplayHtml()+pmHtml(s,ui,{missing:pm.missing});
      const v=pmView(s,ui),base=data.minutes||window.thtLiveResearch?.data?.()?.minutes||{};
      const summary=ui.versions.summary?.length?pmCurrent(ui,'summary',s.summary.text||''):'';
      const minutes={...base,...(summary?{conclusions:[summary]}:!base.conclusions?.length?{conclusions:[s.summary.text||''].filter(Boolean)}:{}),todos:(base.todos||v.all).filter(t=>!ui.dismissed.includes(t.id)).map(t=>({...t,text:pmCurrent(ui,'action:'+t.id,t.text)}))};
      const decisions=v.decisions.filter(i=>!ui.dismissed.includes(i.id)).map(i=>pmItem(ui,i,`<button type="button" class="pm-btn" data-pm="agree" data-id="${pmEsc(i.id)}">${pmT('同意','Agree')}</button>`)).join('');
      return pmReplayHtml()+window.thtLiveResearch.minutesHtml(minutes)+(ui.note?`<p role="status">${pmEsc(ui.note)}</p>`:'')+(v.drafts.length?pmDraftsHtml(s,ui,v):'')+(decisions?`<div class="mt">${pmT('要你拍板的事','Needs your call')}</div><ul class="pm-list">${decisions}</ul>`:'');
    };
    const pmRender=(force=false)=>{if(!pm.el)return;if(pm.ui.editing&&!force){pm.ui.dirty=true;return;}pm.ui.dirty=false;if(pm.research){window.thtLiveResearch?.updateAfter(pm.el);return;}pm.el.innerHTML=pmReplayHtml()+pmHtml(pm.state,pm.ui,{missing:pm.missing});
      const host=window.thtMeetingTasksHost?.(),actions=pm.el.querySelector?.('[data-block="actions"]');
      if(host)pm.tasksHost=host;
      if(host&&actions){host.replaceChildren(actions);pm.taskEl=actions;actions.addEventListener('click',e=>{const b=e.target?.closest?.('[data-pm]');if(b&&actions.contains(b))pmAct(b);});}else if(host){host.replaceChildren();pm.taskEl=null;}
    };
    const pmSchedule=()=>{if(pm.missing)return pmSchedule.stop();clearTimeout(pm.timer);pm.timer=0;if(pmTerminal(pm.state))return;if(Date.now()-pm.started>PM_POLL_MAX_MS){pmGiveUp();return;}pm.timer=setTimeout(pmLoad,pm.mock?PM_MOCK_MS:PM_POLL_MS);};
    pmSchedule.stop=()=>{clearTimeout(pm.timer);pm.timer=0;};
    const pmGiveUp=()=>{const s=pm.state||pmNormalize({});for(const k of PM_BLOCKS)if(!PM_TERMINAL.has(s[k].status))s[k]={...s[k],status:'failed'};pm.state=s;pmRender();};
    const pmLoad=async()=>{
      const id=pm.id,ep=pm.ep;if(!id)return;let raw=null;
      if(!pm.mock){
        let missing=false;
        try{const r=await fetch(relayBase()+PM_ENDPOINT+encodeURIComponent(id),{cache:'no-store',signal:timeoutSignal(15000)});if(r.ok)raw=await r.json();else missing=r.status===404;}catch{}
        if(pm.ep!==ep||pm.id!==id)return;
        if(missing&&!pmMockAllowed()){pm.missing=true;pm.state=null;pmRender();pmSchedule.stop();return;}
        if(raw&&raw.meetingId!=null&&String(raw.meetingId)!==id)raw=null;
        if(!raw&&pmMockAllowed())pm.mock={fresh:pm.fresh,step:pm.fresh?0:99,variant:pmMockVariant(),retried:[]};
      }else pm.mock.step++;
      if(pm.mock)raw=pmMockAt(id,pm.mock);
      if(!raw){pm.fails++;if(pm.fails>=PM_FAIL_MAX){pmGiveUp();return;}pmSchedule();return;}
      pm.fails=0;pm.missing=false;pm.state=pmNormalize(raw);pmRender();if(pm.research)void window.thtLiveResearch.load?.();pmSchedule();
    };
    // 开始 / 重试是一次性命令：不进 ui.pending（那是要补发的编辑），失败就回到可再点的状态并提示一行。
    const pmCommands=new Set();
    const pmCommand=async op=>{
      const id=pm.id,ep=pm.ep,live=()=>pm.ep===ep&&pm.id===id;let raw=null;
      const commandKey=id+':'+op.op+':'+(op.block||'');if(pmCommands.has(commandKey))return false;pmCommands.add(commandKey);
      try {
      const previous={state:pm.state,missing:pm.missing};
      if(op.op==='start'){pmSchedule.stop();pm.ui.note='';pm.missing=false;pm.state=null;pmRender(true);}
      try{const r=await fetch(relayBase()+PM_ENDPOINT+encodeURIComponent(id),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({meetingId:id,...op}),cache:'no-store',signal:timeoutSignal(15000)});if(r.ok)raw=await r.json();}catch{}
      if(!live())return false;
      if(!raw){pm.ui.note=pmT('没能开始整理，稍后再试','Could not start; try again later');
        if(op.op==='start'){pm.state=previous.state;pm.missing=previous.missing;}
        if(op.op==='retry'&&pm.state&&!pm.missing)pm.state[op.block]={...pm.state[op.block],status:'failed'};pmRender(true);pmSchedule();return false;}
      pm.ui.note='';pm.missing=false;pm.fails=0;pm.started=Date.now();pm.state=pmNormalize(raw);pmRender(true);pmSchedule();return true;
      } finally { pmCommands.delete(commandKey); }
    };
    // 写回：mock 下只记账；接口定稿前路径沿用读取路径（POST），失败不丢本地改动，只提示一行。
    // 发送时锁定会议 id / 代次 / 覆盖层实例，完成或失败只改那一份；已经离开的会不重画当前页。
    const pmPost=async(id,ep,ui,op)=>{
      const live=()=>pm.ep===ep&&pm.id===id&&pm.ui===ui;
      try{const r=await fetch(relayBase()+PM_ENDPOINT+encodeURIComponent(id),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({meetingId:id,...op}),cache:'no-store',signal:timeoutSignal(15000)});const raw=typeof r.json==='function'?await r.json():null;
        if(live()&&raw?.meetingId===id&&Number.isInteger(raw.version))pm.state=pmNormalize(raw);
        if(!r.ok)throw {conflict:r.status===409};
        const index=ui.pending.indexOf(op);
        window.thtInvalidateHomeTasks?.();ui.pending=ui.pending.filter((x,i)=>x!==op&&!(index>=0&&i<index&&op.op==='edit'&&x.op==='edit'&&x.target===op.target));if(!ui.pending.length&&ui.note)ui.note='';pmPersist(id,ui);if(live())pmRender();return true;}
      catch(e){ui.note=e?.conflict?pmT('服务器已有新版本，本地改动已保留；请核对后再保存','A newer version exists. Your local edit is kept; review before saving again'):pmT('改动先留在这里，还没同步上','Your change is kept here but not synced yet');pmPersist(id,ui);if(live())pmRender();return false;}
    };
    const pmSend=op=>{
      if(pm.mock){pm.sent.push(op);return Promise.resolve(true);}
      window.thtInvalidateHomeTasks?.();
      const id=pm.id,ui=pm.ui;ui.pending.push(op);pmPersist(id,ui);return pmPost(id,pm.ep,ui,op);
    };
    const pmFind=id=>{const s=pm.state;return [...s.actions.mine,...s.actions.possibly_you,...s.actions.all].find(i=>i.id===id)||s.drafts.items.find(d=>d.id===id)||null;};
    const pmOrig=key=>{const [kind,id]=[key.split(':')[0],key.slice(key.indexOf(':')+1)];if(kind==='summary')return pm.state.summary.text||'';const it=pmFind(id);return kind==='draft'?it?.body||'':it?.text||'';};
    const pmAct=(btn)=>{
      const ui=pm.ui,a=btn.dataset.pm,key=btn.dataset.key||'',id=btn.dataset.id||'';
      if(a==='settings'){if(typeof openSettings==='function')openSettings();return;}
      else if(a==='agree'){
        if(ui.confirming.has(id)||pm.state?.decisions.items.find(i=>i.id===id)?.status==='agreed')return;
        const sid=pm.id,ep=pm.ep;ui.confirming.add(id);ui.note='';pmRender(true);
        (async()=>{try{
          const r=await fetch(relayBase()+PM_ENDPOINT+encodeURIComponent(sid),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({meetingId:sid,op:'confirm',item:id}),cache:'no-store',signal:timeoutSignal(15000)});
          if(!r.ok)throw Error('save failed');const raw=await r.json();
          if(String(raw.meetingId)!==sid||!raw.decisions?.items?.some(i=>i.id===id&&i.status==='agreed'))throw Error('not confirmed');
          if(pm.ep===ep&&pm.id===sid&&pm.ui===ui){pm.state=pmNormalize(raw);window.thtInvalidateHomeTasks?.();}
        }catch{ui.note=pmT('没能保存同意，请重试','Could not save agreement; try again');}
        finally{ui.confirming.delete(id);if(pm.ep===ep&&pm.id===sid&&pm.ui===ui)pmRender(true);}})();return;
      }
      else if(a==='tab'){ui.tab=btn.dataset.tab;ui.undo=null;}
      else if(a==='edit'){ui.editing=key;ui.editBaseVersion=pm.state?.version;}
      else if(a==='cancel'){ui.editing='';}
      else if(a==='jump'){window.thtOpenTranscript?.(Number(btn.dataset.sec)||0);return;}
      else if(a==='save'){const box=pm.taskEl?.querySelector('textarea[data-pm-edit]')||pm.el.querySelector('textarea[data-pm-edit]');const text=String(box?.value??'').trim();ui.editing='';
        if(text&&pmSaveVersion(ui,key,pmOrig(key),text))pmSend({op:'edit',target:key,text,version:ui.versions[key].length-1,baseVersion:ui.editBaseVersion,operationId:'edit-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)});}
      else if(a==='claim'){if(!ui.claimed.includes(id))ui.claimed.push(id);ui.undo=null;pmSend({op:'claim',item:id});}
      else if(a==='dismiss'){if(!ui.dismissed.includes(id))ui.dismissed.push(id);ui.undo={id,text:pmFind(id)?.text||''};pmSend({op:'dismiss',item:id});}
      else if(a==='undo'&&ui.undo){ui.dismissed=ui.dismissed.filter(x=>x!==ui.undo.id);pmSend({op:'undismiss',item:ui.undo.id});ui.undo=null;}
      else if(a==='toggle'){ui.open.has(id)?ui.open.delete(id):ui.open.add(id);}
      else if(a==='copy'){const d=pmFind(id);navigator.clipboard?.writeText(pmCurrent(ui,'draft:'+id,d?.body||'')).catch(()=>{});ui.copied=id;}
      else if(a==='open'){const u=pmFind(id)?.url;if(/^https?:\/\//.test(String(u||'')))window.open(u,'_blank','noopener');}
      else if(a==='retry'){const k=btn.dataset.block;if(!PM_BLOCKS.includes(k)||pmCommands.has(pm.id+':retry:'+k))return;pm.state[k]={...pmNormalize({})[k],status:'running'};pm.started=Date.now();pm.fails=0;
        if(pm.mock){pm.mock.retried.push(k);pm.mock.fresh=false;pmRender(true);pmSchedule();return;}pmRender(true);pmSchedule.stop();pmCommand({op:'retry',block:k});return;}
      else if(a==='start'||a==='force'){if(pm.mock)return;pmCommand(a==='force'?{op:'start',force:true}:{op:'start'});return;}
      else return;
      pmRender(true);
    };
    const pmUnmount=()=>{if(pm.el)window.thtLiveResearch?.unmountAfter(pm.el);pm.ep++;clearTimeout(pmReplayTimer);pmReplayState=null;clearTimeout(pm.timer);pm.timer=0;pm.el?.remove();const live=pm.tasksHost?.parentElement?.querySelector('.meeting-todos');pm.tasksHost?.remove();if(live)live.hidden=!live.querySelector('li');pm.tasksHost=null;pm.taskEl?.remove();pm.taskEl=null;pm.el=null;pm.id='';pm.state=null;pm.mock=null;};
    const pmMount=(host,{id,fresh=false}={})=>{
      if(!host||!id)return;

      if(pm.id!==id){
        pmUnmount();const sid=String(id),ui=pmUiFor(sid);ui.editing='';ui.undo=null;
        Object.assign(pm,{id:sid,fresh:!!fresh,state:null,missing:false,ui,started:Date.now(),fails:0,mock:null,sent:[]});
        const el=document.createElement('section');el.className='pm-root';el.setAttribute('aria-label',pmT('会后整理','After the meeting'));
        el.addEventListener('click',e=>{const b=e.target?.closest?.('[data-pm]');if(b&&el.contains(b)){if(b.dataset.pm==='retranscribe')pmReplayLoad(true);else pmAct(b);}});
        pm.el=el;pm.research=!!window.thtLiveResearch;if(pm.research)window.thtLiveResearch.mountAfter(el,{id:sid,minutesHtml:pmResearchMinutes});pmRender();pmLoad();pmReplayLoad();
        if(!pmMockAllowed()){ui.pending=ui.pending.filter(op=>!['retry','start'].includes(op?.op));for(const op of [...ui.pending])pmPost(sid,pm.ep,ui,op);}
      }
      if(host.lastElementChild!==pm.el)host.append(pm.el);
    };
    window.thtPostmeeting={mount:pmMount,unmount:pmUnmount,relocateTasks:()=>pmRender(),_t:{normalize:pmNormalize,html:pmHtml,mockAt:pmMockAt,newUi:pmNewUi,view:pmView,saveVersion:pmSaveVersion,terminal:pmTerminal,act:pmAct,state:()=>pm,ENDPOINT:PM_ENDPOINT}};

})();
