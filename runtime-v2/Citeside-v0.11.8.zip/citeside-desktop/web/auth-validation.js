/*! Better Auth UI, MIT, cb5b4dc80fdad027eb6ef37b7a81236a4ad3069a
MIT License

Copyright (c) 2025 daveycodez

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
var CitesideAuthValidation = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // web/vendor/better-auth-ui/selected-validators.ts
  var selected_validators_exports = {};
  __export(selected_validators_exports, {
    validateEmailAddress: () => validateEmailAddress,
    validateStringLength: () => validateStringLength
  });

  // web/vendor/better-auth-ui/form-validation.ts
  function createFormFieldError(message) {
    return message ? { message } : void 0;
  }
  function validateStringLength(value, {
    maxLength,
    maxLengthMessage,
    minLength,
    minLengthMessage,
    requiredMessage,
    trim = false
  }) {
    const candidate = trim ? value.trim() : value;
    if (!candidate && requiredMessage)
      return createFormFieldError(requiredMessage);
    if (minLength !== void 0 && candidate.length < minLength)
      return createFormFieldError(minLengthMessage);
    if (maxLength !== void 0 && candidate.length > maxLength)
      return createFormFieldError(maxLengthMessage);
  }
  function validateEmailAddress(value, {
    invalidMessage,
    requiredMessage
  }) {
    const candidate = value.trim();
    if (!candidate)
      return requiredMessage ? createFormFieldError(requiredMessage) : void 0;
    const isValid = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9-]*\.)+[A-Za-z]{2,}$/.test(
      candidate
    );
    return isValid ? void 0 : createFormFieldError(invalidMessage);
  }
  return __toCommonJS(selected_validators_exports);
})();
