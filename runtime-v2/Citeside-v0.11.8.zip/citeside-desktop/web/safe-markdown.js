'use strict';
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ThtSafeMarkdown=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function inline(s){return esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/(^|\s)_([^_]+)_(?=\s|$)/g,'$1<em>$2</em>');}
// 纪要 Markdown 供纪要和研究报告共享，全部先转义，格式支持：标题、列表、表格、引用、段落。
function markdown(md){
 const out=[];let list=false,table=null;
 const close=()=>{if(list){out.push('</ul>');list=false;}if(table){out.push('<table>'+table.map((r,i)=>'<tr>'+r.map(c=>i?'<td>'+inline(c)+'</td>':'<th>'+inline(c)+'</th>').join('')+'</tr>').join('')+'</table>');table=null;}};
 for(const raw of String(md||'').split('\n')){
  const line=raw.trimEnd(),h=line.match(/^(#{1,6})\s+(.*)$/);
  if(/^\|.*\|$/.test(line)){if(list){out.push('</ul>');list=false;}const cells=line.slice(1,-1).split('|').map(c=>c.trim());if(cells.every(c=>/^:?-{3,}:?$/.test(c)))continue;(table||(table=[])).push(cells);continue;}
  if(table)close();
  if(h){close();const level=Math.min(4,h[1].length+1);out.push('<h'+level+'>'+inline(h[2])+'</h'+level+'>');}
  else if(/^[-*]\s+/.test(line)){if(!list){out.push('<ul>');list=true;}out.push('<li>'+inline(line.replace(/^[-*]\s+/,''))+'</li>');}
  else if(/^>\s?/.test(line)){close();out.push('<blockquote>'+inline(line.replace(/^>\s?/,''))+'</blockquote>');}
  else if(!line.trim()||/^-{3,}$/.test(line))close();
  else{close();out.push('<p>'+inline(line)+'</p>');}
 }
 close();return out.join('\n');
}

return {esc,inline,markdown};
});
