/* Independent local audio recovery. No credentials, uploads or automatic deletions. */
(function(root){
 'use strict';
 const request=r=>new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
 const complete=t=>new Promise((resolve,reject)=>{t.oncomplete=resolve;t.onabort=t.onerror=()=>reject(t.error||Error('Storage transaction failed'));});
 let dbPromise;
 function open(name){return new Promise((resolve,reject)=>{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{r.result.createObjectStore('recordings',{keyPath:'id'});r.result.createObjectStore('chunks',{keyPath:['id','seq']});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.onblocked=()=>reject(Error('录音存储被其他页面阻塞，请关闭旧的Citeside页面后重试。'));});}
 async function rows(db,store){return request(db.transaction(store).objectStore(store).getAll());}
 async function equal(a,b){
  if(a instanceof Blob && b instanceof Blob){if(a.size!==b.size||a.type!==b.type)return false;const x=new Uint8Array(await a.arrayBuffer()),y=new Uint8Array(await b.arrayBuffer());return x.every((v,i)=>v===y[i]);}
  if(a&&b&&typeof a==='object'&&typeof b==='object'){const keys=Object.keys(a);if(keys.length!==Object.keys(b).length)return false;for(const k of keys)if(!await equal(a[k],b[k]))return false;return true;}
  return a===b;
 }
 async function copyPrevious(db){
  if(typeof indexedDB.databases!=='function')throw Error('浏览器无法核对现有录音数据库，已保留原始备份。');
  const previous=(await indexedDB.databases()).filter(x=>x.name!=='citeside-audio-safety'&&/^[a-z][a-z0-9-]*-audio-safety$/.test(x.name));
  for(const item of previous){
   const marker='citeside-audio-safety-migrated:'+item.name;
   if(root.localStorage.getItem(marker)==='1')continue;
   const old=await open(item.name);
   try{
    if(old.objectStoreNames.length!==2||!old.objectStoreNames.contains('recordings')||!old.objectStoreNames.contains('chunks'))throw Error('现有录音数据库结构无法核对。');
    const values={recordings:await rows(old,'recordings'),chunks:await rows(old,'chunks')};
    // Check every key before writing; a collision never overwrites new recordings.
    for(const store of ['recordings','chunks'])for(const value of values[store]){const key=store==='recordings'?value.id:[value.id,value.seq],existing=await request(db.transaction(store).objectStore(store).get(key));if(existing!==undefined&&!await equal(existing,value))throw Error('录音备份冲突，原始数据已保留。');}
    const tx=db.transaction(['recordings','chunks'],'readwrite'),done=complete(tx);
    for(const store of ['recordings','chunks'])for(const value of values[store])tx.objectStore(store).put(value);
    await done;
    for(const store of ['recordings','chunks'])for(const value of values[store]){const key=store==='recordings'?value.id:[value.id,value.seq],back=await request(db.transaction(store).objectStore(store).get(key));if(!await equal(back,value))throw Error('录音备份回读不一致，原始数据已保留。');}
    for(const store of ['recordings','chunks'])if(!await equal(values[store],await rows(old,store)))throw Error('旧录音备份在迁移中发生变化，请关闭旧页面重试。');
    root.localStorage.setItem(marker,'1');
   }finally{old.close();}
  }
 }
 function database(){return dbPromise||(dbPromise=(async()=>{const db=await open('citeside-audio-safety');try{await copyPrevious(db);return db;}catch(e){db.close();dbPromise=null;throw e;}})());}
 async function put(store,value){const d=await database(),t=d.transaction(store,'readwrite'),done=complete(t);t.objectStore(store).put(value);await done;}
 async function list(){const d=await database();return request(d.transaction('recordings').objectStore('recordings').getAll());}
 async function blob(id){const d=await database();const meta=await request(d.transaction('recordings').objectStore('recordings').get(id));if(!meta)throw Error('Recording not found');const rows=await request(d.transaction('chunks').objectStore('chunks').getAll(IDBKeyRange.bound([id,0],[id,Number.MAX_SAFE_INTEGER])));return new Blob(rows.map(x=>x.blob),{type:meta.mime});}
 async function remove(id){const d=await database(),t=d.transaction(['recordings','chunks'],'readwrite'),done=complete(t);t.objectStore('recordings').delete(id);t.objectStore('chunks').delete(IDBKeyRange.bound([id,0],[id,Number.MAX_SAFE_INTEGER]));await done;}
 async function start(stream,sessionId,onStatus=()=>{}){
  if(!root.MediaRecorder)throw Error('浏览器不支持安全录音，请使用最新版 Chrome 或 Safari。');
  const mime=['audio/webm;codecs=opus','audio/mp4','audio/webm'].find(x=>MediaRecorder.isTypeSupported(x));
  const recorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);
  const meta={id:sessionId+'-'+Date.now(),sessionId,started:Date.now(),mime:recorder.mimeType,bytes:0,chunks:0,state:'recording'};
  await put('recordings',meta);let queue=Promise.resolve(),seq=0,failed=false;
  recorder.ondataavailable=e=>{if(!e.data.size)return;const n=seq++;queue=queue.then(async()=>{await put('chunks',{id:meta.id,seq:n,blob:e.data});meta.bytes+=e.data.size;meta.chunks++;await put('recordings',meta);if(!failed)onStatus('saved',meta);}).catch(err=>{failed=true;onStatus('error',err);});};
  recorder.onerror=e=>{failed=true;onStatus('error',e.error||Error('Recording failed'));};
  let resolveStopped;const stopped=new Promise(r=>resolveStopped=r);
  recorder.onstop=()=>{queue.then(async()=>{meta.state=failed?'error':'stopped';meta.ended=Date.now();await put('recordings',meta);resolveStopped(meta);}).catch(e=>{onStatus('error',e);resolveStopped({...meta,state:'error'});});};
  recorder.start(1000);
  return {id:meta.id,pause(){if(recorder.state==='recording')recorder.pause();},resume(){if(recorder.state==='paused')recorder.resume();},stop(){if(recorder.state!=='inactive')recorder.stop();return stopped;}};
 }
 root.RecordingSafety={start,list,blob,remove};
})(window);
