// Live card wording and the 5-second undo. Display-only: no model route, no gate.
// Shipped at web/live-card-format.js so the public package keeps it after web/src is removed.
// The meeting bundle injects this file at the 25cz slot. Node requires it from app/live-card-format.js.
var LiveCardFormat=(function(){
  const LEAD=/^\s*(?:动作|建议|Action|Suggestion)\s*[:：]\s*/i;
  const SOURCE=/(?:^|\n)### (?:Retrieved sources \(excerpts\)|检索来源（片段）)\s*\n/;
  function stripLead(text){
    return String(text||'').replace(LEAD,'').trim();
  }
  function isStop(text,i){
    const c=text.charAt(i);
    if(c==='。'||c==='！'||c==='？')return true;
    if(c!=='.'&&c!=='!'&&c!=='?')return false;
    const n=text.charAt(i+1);
    return !n||/\s/.test(n);
  }
  function firstSplit(text){
    const s=String(text||'');
    for(let i=0;i<s.length;i++)if(isStop(s,i))return {head:s.slice(0,i+1),rest:s.slice(i+1)};
    return {head:s,rest:''};
  }
  function sentences(text){
    const s=String(text||'').trim();
    if(!s)return [];
    const out=[];let buf='';
    for(let i=0;i<s.length;i++){
      buf+=s.charAt(i);
      if(!isStop(s,i))continue;
      out.push(buf.trim());buf='';
      while(i+1<s.length&&/\s/.test(s.charAt(i+1)))i++;
    }
    if(buf.trim())out.push(buf.trim());
    return out.length?out:[s];
  }
  function boldFirst(text){
    const raw=String(text||'');
    const nl=raw.indexOf('\n');
    // An already-formatted conclusion must not be wrapped twice or strip later emphasis.
    if(/^\*\*[^*\n]+\*\*/.test(raw))return raw;
    const line=nl<0?raw:raw.slice(0,nl);
    const tail=nl<0?'':raw.slice(nl);
    const cut=firstSplit(line);
    if(!String(cut.head||'').trim())return raw;
    return '**'+cut.head.replace(/\*/g,'')+'**'+cut.rest+tail;
  }
  function formatFinding(text,options){
    const opt=options||{};
    const raw=String(text||'').replace(/\r\n/g,'\n');
    const at=raw.search(SOURCE);
    const main=at>=0?raw.slice(0,at):raw;
    const tail=at>=0?raw.slice(at):'';
    if(opt.kind==='insight'&&(at>=0||main.trim().length>240))return raw;
    const stripped=main.split('\n').map(line=>line.replace(LEAD,'')).join('\n');
    return boldFirst(stripped)+tail;
  }
  function splitFinding(text,options){
    const body=formatFinding(text,options);
    const plain=body.split(SOURCE)[0].replace(/\*\*/g,'');
    const cut=firstSplit(plain);
    return {conclusion:cut.head.trim(),suggestion:cut.rest.trim(),body};
  }
  function shareableContextLink(url){
    const raw=String(url||'').trim().replace(/[),。，、）]+$/u,'');
    let u;
    try{u=new URL(raw);}catch{return '';}
    if(u.protocol!=='https:'||u.username||u.password)return '';
    const host=u.hostname.toLowerCase().replace(/\.$/,'');
    if(host==='localhost'||host==='127.0.0.1'||host==='0.0.0.0'||host.endsWith('.local'))return '';
    const bare=name=>host===name||host.endsWith('.'+name);
    const notion=bare('notion.so')||bare('notion.site');
    const feishu=bare('feishu.cn')||bare('larksuite.com')||bare('larkoffice.com');
    if(!notion&&!feishu)return '';
    let path=u.pathname.toLowerCase(),query=u.search.toLowerCase();
    try{path=decodeURIComponent(path);query=decodeURIComponent(query);}catch{}
    if(/minute|纪要|meeting-result/.test(path+' '+query))return '';
    if(/\/(minutes|transcript|vc)(\/|$)/.test(path)||/(^|\/)meetings?(\/|$)/.test(path)||path.includes('transcript'))return '';
    if(!notion&&!/\/(docx|wiki|docs|doc|sheets|base|file)(\/|$)/.test(path))return '';
    return u.origin+u.pathname+u.search;
  }
  function firstSentence(text){
    return firstSplit(String(text||'').trim()).head.trim();
  }
  function punctuate(text){
    const s=String(text||'').trim();
    if(!s)return '';
    return /[。！？.!?]$/.test(s)?s:s+'。';
  }
  function scrubOutbound(text){
    let s=String(text||'');
    const cut=s.search(/转写全文\s*[:：]/);
    if(cut>=0)s=s.slice(0,cut);
    s=s.replace(/\[[^\]]*\]\(\s*\)/g,'').replace(/\[\s*\]\([^)]*\)/g,'');
    s=s.replace(/\/meeting-result\b/g,'').replace(/(?:localhost|127\.0\.0\.1|0\.0\.0\.0)(?::\d{2,5})?/gi,'').replace(/[a-z0-9.-]+\.[a-z]{2,}:\d{2,5}/gi,'');
    return s.split('\n').filter(line=>{
      const t=line.trim();
      if(!t)return false;
      if(/来自会议\s*[:：]/.test(t))return false;
      if(/转写全文/.test(t))return false;
      if(/^(?:完整转写|原始转写|full transcript|transcript)(?:\s|$|[:：])/i.test(t))return false;
      if(/^\d{1,2}:\d{2}(?::\d{2})?\s+\S/.test(t))return false;
      return true;
    }).join('\n');
  }
  function dropRepeat(body,why){
    let next=String(body||'').trim();
    if(!next||!why)return next;
    if(next.startsWith(why))return next.slice(why.length).trim();
    const head=firstSplit(next).head;
    const core=head.replace(/[。！？.!?]+$/u,'').trim();
    if(core&&why.includes(core))return next.slice(head.length).replace(/^[ \t]+/,'').replace(/^\n/,'').trim();
    return next;
  }
  function outboundDescription(input){
    const src=input&&typeof input==='object'?input:{};
    const en=src.lang==='en'||src.en===true;
    let body=scrubOutbound(src.text);
    const advice=stripLead(String(src.advice||'').trim());
    if(advice&&advice!==body.trim())body=(body.trim()?body.trim()+'\n':'')+advice;
    body=body.trim();
    const whyRaw=String(src.why||'').trim();
    let why=whyRaw?punctuate(whyRaw):'';
    if(!why){
      const core=firstSentence(stripLead(body)).replace(/[。！？.!?]+$/u,'').trim()||(en?'this needs you':'这件事需要你处理');
      why=en?('This needs you: '+core+'.'):('找你是因为这件事需要你处理：'+core+'。');
    }
    body=dropRepeat(body,why);
    let description=(why+(body?'\n'+body:'')).trim();
    const found=[];
    const add=value=>{const ok=shareableContextLink(value);if(ok&&!found.includes(ok))found.push(ok);};
    for(const link of src.links||[])add(link);
    for(const link of description.match(/https?:\/\/[^\s)）]+/g)||[])add(link);
    description=description.replace(/https?:\/\/[^\s)）]+/g,'').replace(/\[[^\]]*\]\(\s*\)/g,'').replace(/\[\s*\]\([^)]*\)/g,'');
    description=description.replace(/\/meeting-result\b/g,'');
    description=description.replace(/(?:localhost|127\.0\.0\.1|0\.0\.0\.0)(?::\d{2,5})?/gi,'');
    description=description.replace(/[a-z0-9.-]+\.[a-z]{2,}:\d{2,5}/gi,'');
    description=description.replace(/[ \t]{2,}/g,' ').replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
    description=description.split('\n').filter(line=>!/来自会议\s*[:：]/.test(line)&&!/转写全文/.test(line)).join('\n').trim();
    return {description,links:found,contextLink:found[0]||''};
  }
  function blankName(name){
    const n=String(name||'').trim();
    return !n||/^(?:我|本人|自己|me|myself|i)$/i.test(n);
  }
  function agentLine(name,lang){
    const en=lang==='en';
    const n=String(name||'').trim();
    if(blankName(n))return en?'(sent by agent)':'（agent 代发送）';
    return en?'('+n+"'s agent sends)":'（'+n+' 的 agent 代发送）';
  }
  function createSendScheduler(options){
    const opt=options||{};
    const delayMs=Number.isFinite(opt.delayMs)?opt.delayMs:5000;
    const setTimer=opt.setTimer,clearTimer=opt.clearTimer,send=opt.send||function(){};
    const pending=new Map(),sent=new Set(),inflight=new Set();
    function fail(id,item,error){
      inflight.delete(id);sent.delete(id);
      if(item&&item.payload&&typeof item.payload.onFail==='function')item.payload.onFail(error);
    }
    function fire(id){
      const item=pending.get(id);
      if(!item||sent.has(id)||inflight.has(id))return;
      pending.delete(id);
      let result;
      try{result=send(id,item.payload);}catch(error){fail(id,item,error);return;}
      if(result&&typeof result.then==='function'){
        inflight.add(id);
        Promise.resolve(result).then(()=>{inflight.delete(id);sent.add(id);},error=>fail(id,item,error));
        return;
      }
      sent.add(id);
    }
    return {
      arm(id,payload){
        if(sent.has(id)||pending.has(id)||inflight.has(id))return {status:'once'};
        const timer=setTimer(()=>fire(id),delayMs);
        pending.set(id,{timer,payload});
        return {status:'armed'};
      },
      undo(id){
        if(sent.has(id)||inflight.has(id))return {status:'sent'};
        const item=pending.get(id);
        if(!item)return {status:'idle'};
        clearTimer(item.timer);
        pending.delete(id);
        if(item.payload&&typeof item.payload.onCancel==='function')item.payload.onCancel();
        return {status:'restored',sent:false};
      },
      cancelAll(){
        const ids=[...pending.keys()];
        for(const id of ids){
          const item=pending.get(id);
          clearTimer(item.timer);
          pending.delete(id);
          if(item.payload&&typeof item.payload.onCancel==='function')item.payload.onCancel();
        }
        return ids;
      },
      pendingIds(){return [...pending.keys()];}
    };
  }
  return {stripLead,sentences,formatFinding,splitFinding,shareableContextLink,outboundDescription,agentLine,createSendScheduler};
})();
if(typeof window!=='undefined')window.LiveCardFormat=LiveCardFormat;
if(typeof module==='object'&&module&&module.exports)module.exports=LiveCardFormat;
