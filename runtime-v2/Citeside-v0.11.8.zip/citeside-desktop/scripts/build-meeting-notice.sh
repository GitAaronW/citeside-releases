#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/app/native-detect/MeetingNotice}"
SDK="${THT_SWIFT_SDK:-$(xcrun --show-sdk-path)}"
if [ -d /Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk ]; then
 SDK="${THT_SWIFT_SDK:-/Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk}"
fi
BUILD_DIR="$(mktemp -d /tmp/livemate-notice.XXXXXX)"
trap 'rm -rf "$BUILD_DIR"' EXIT
for ARCH in arm64 x86_64; do
 swiftc -O -sdk "$SDK" -module-cache-path "${THT_SWIFT_MODULE_CACHE:-$BUILD_DIR/cache}" -target "$ARCH-apple-macos13.0" -framework AppKit -framework CoreAudio "$ROOT/app/native-detect/MeetingNotice.swift" -o "$BUILD_DIR/$ARCH"
done
mkdir -p "$(dirname "$OUT")"
lipo -create "$BUILD_DIR/arm64" "$BUILD_DIR/x86_64" -output "$OUT"
