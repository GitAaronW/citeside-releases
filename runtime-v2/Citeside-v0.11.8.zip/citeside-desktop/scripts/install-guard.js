#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),{execFileSync}=require('node:child_process');
const {readCommit}=require('../app/build-identity');
function compareVersions(a,b){
 const parse=s=>{const m=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/.exec(s);if(!m)throw Error('无法识别版本号：'+s);return m;};
 const x=parse(a),y=parse(b);
 for(let i=1;i<=3;i++){if(BigInt(x[i])!==BigInt(y[i]))return BigInt(x[i])>BigInt(y[i])?1:-1;}
 if(!x[4]||!y[4])return x[4]===y[4]?0:x[4]?-1:1;
 const p=x[4].split('.'),q=y[4].split('.');
 for(let i=0;i<Math.max(p.length,q.length);i++){if(p[i]===q[i])continue;if(p[i]===undefined)return -1;if(q[i]===undefined)return 1;const pn=/^\d+$/.test(p[i]),qn=/^\d+$/.test(q[i]);if(pn&&qn)return BigInt(p[i])>BigInt(q[i])?1:-1;if(pn!==qn)return pn?-1:1;return p[i]>q[i]?1:-1;}return 0;
}
function check(candidate,installed,{allowDowngrade=false,isAncestor=()=>false}={}){
 if(allowDowngrade||!installed)return true;
 const order=compareVersions(candidate.version,installed.version);
 if(order<0)throw Error('拒绝安装旧版本；显式 --allow-downgrade 可覆盖');
 if(candidate.commit&&installed.commit){if(candidate.commit!==installed.commit&&!isAncestor(installed.commit,candidate.commit))throw Error('拒绝旧提交或无法确认先后关系的构建；使用 --allow-downgrade 显式覆盖');}
 else if(order===0)throw Error('同版本缺少提交证据，拒绝覆盖；使用 --allow-downgrade 显式覆盖');
 return true;
}
function identity(root){return {version:JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).version,commit:readCommit(root)};}
function guard(root,target,allowDowngrade){const candidate=identity(root);if(!candidate.commit)throw Error('候选构建缺少提交号，拒绝安装');let installed=null;if(fs.existsSync(path.join(target,'package.json')))installed=identity(target);else if(fs.existsSync(target)&&fs.readdirSync(target).length)throw Error('已装目录缺少版本信息，拒绝覆盖');return check(candidate,installed,{allowDowngrade,isAncestor:(a,b)=>{try{execFileSync('git',['merge-base','--is-ancestor',a,b],{cwd:root,stdio:'ignore'});return true;}catch{return false;}}});}
function stampedPage(html,commit){return html.replace(/<meta name="tht-commit" content="[^"]*">/g,'').replace('<head>','<head><meta name="tht-commit" content="'+(commit||'')+'">');}
function stampPage(root,commit){
 const file=path.join(root,'web/index.html');if(fs.existsSync(file))fs.writeFileSync(file,stampedPage(fs.readFileSync(file,'utf8'),commit));
}
function verifyStamp(root,target){
 const commit=readCommit(root);
 if(!commit||readCommit(target)!==commit||fs.readFileSync(path.join(target,'web/index.html'),'utf8')!==stampedPage(fs.readFileSync(path.join(root,'web/index.html'),'utf8'),commit))throw Error('安装后的构建标记或首页内容不一致');
 return true;
}
function stamp(root,target){const commit=readCommit(root);if(!commit)throw Error('候选构建缺少提交号');fs.writeFileSync(path.join(target,'app/build-identity.json'),JSON.stringify({commit})+'\n');stampPage(target,commit);}
if(require.main===module)try{const [mode,root,target,...flags]=process.argv.slice(2);if(mode==='check')guard(root,target,flags.includes('--allow-downgrade'));else if(mode==='stamp')stamp(root,target);else if(mode==='verify-stamp')verifyStamp(root,target);else throw Error('未知命令');}catch(e){console.error(e.message);process.exitCode=1;}
module.exports={compareVersions,check,guard,stamp,stampPage,stampedPage,verifyStamp};
