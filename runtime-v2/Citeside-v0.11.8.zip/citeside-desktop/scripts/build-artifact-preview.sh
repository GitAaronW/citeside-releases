#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/app/native-capture/CitesideCapture.app/Contents/MacOS/ArtifactPreview}"
SDK="${THT_SWIFT_SDK:-$(xcrun --show-sdk-path)}"
if [ -d /Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk ]; then SDK="${THT_SWIFT_SDK:-/Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk}"; fi
TMP="$(mktemp -d /tmp/lm-preview-build.XXXXXX)"
trap 'rm -rf "$TMP"' EXIT
for ARCH in arm64 x86_64; do
 swiftc -O -sdk "$SDK" -module-cache-path "${THT_SWIFT_MODULE_CACHE:-$TMP/cache}" -target "$ARCH-apple-macos13.0" -framework AppKit -framework WebKit -framework PDFKit "$ROOT/app/native-capture/ArtifactPreview.swift" -o "$TMP/$ARCH"
done
mkdir -p "$(dirname "$OUT")"
lipo -create "$TMP/arm64" "$TMP/x86_64" -output "$OUT"
source "$ROOT/scripts/sign-identity.sh"
SIGN_ID="$(tht_sign_identity)"
SIGN_ARGS=(--force --sign "$SIGN_ID" --identifier com.citeside.artifact-preview)
if [ "$SIGN_ID" != - ]; then SIGN_ARGS+=(--options runtime --timestamp --entitlements "$ROOT/packaging/entitlements/none.plist"); fi
codesign "${SIGN_ARGS[@]}" "$OUT"
