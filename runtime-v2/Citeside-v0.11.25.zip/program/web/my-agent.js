'use strict';
(()=>{
 if(window.__thtMyAgent)return;window.__thtMyAgent=true;
 const nested=parent!==window,params=new URLSearchParams(location.search);
 // PRD §2: a written card collapses to "✓ 已写进文档 · 位置 ›"; clicking scrolls the right column to the landing block.
 function collectionLabel(receipt){
  const english=localStorage.getItem('tht-board-lang')==='en',state=receipt?.organization?.state;
  return receipt?.undone?(english?'Undone':'已撤销'):state==='done'?(english?'Added to solution':'已加入方案'):state==='pending'?(english?'Material saved · Organizing…':'原图文已保存 · 整理中…'):state==='clarify'?(english?'Material saved · Clarification needed':'原图文已保存 · 待补充方向'):(english?'Material saved · Organization incomplete':'原图文已保存 · 整理未完成');
 }
 const resultCollections=new Map(),failedRecoveries=new Map();
 window.thtCollectionChanged=item=>{updateChatCollectionReceipt(item);const result=resultCollections.get(JSON.stringify([item.meetingId,item.moduleId]));if(result&&item.moduleId==='artifact-'+result.job?.artifact?.id){result.adopted=!!item.receipt?.blockId&&!item.receipt?.undone;result.paint?.();}for(const button of document.querySelectorAll('.ma-insight-place'))if(button.dataset.directAction!=='true'&&button.dataset.meetingId===item.meetingId&&button.dataset.moduleId===item.moduleId)paintPlace(button,item.receipt);};
 window.thtCollectionUndone=item=>{updateChatCollectionReceipt({...item,receipt:{...item.receipt,undone:true}});const result=resultCollections.get(JSON.stringify([item.meetingId,item.moduleId]));if(result&&item.moduleId==='artifact-'+result.job?.artifact?.id){result.adopted=false;result.paint?.();}for(const button of document.querySelectorAll('.ma-insight-place'))if(button.dataset.directAction!=='true'&&button.dataset.meetingId===item.meetingId&&button.dataset.moduleId===item.moduleId)paintPlace(button,null);};
 if(nested){
  window.myAgentAsk=(quote,question='',meta={})=>parent.postMessage({type:'tht-agent-ask',quote,question,meta},location.origin);
  window.claudeAssistantAsk=window.myAgentAsk;
  const button=document.createElement('button');button.className='ma-selection';button.hidden=true;document.body.append(button);let quote='';
  document.addEventListener('mouseup',()=>{const selection=getSelection();quote=String(selection||'').trim().slice(0,4000);button.hidden=!quote;if(!quote)return;const r=selection.getRangeAt(0).getBoundingClientRect();button.textContent=localStorage.getItem('tht-board-lang')==='en'?'Ask MyAgent':'跟 MyAgent 说';button.style.top=Math.max(8,r.top-40)+'px';button.style.left=Math.min(r.left,innerWidth-150)+'px';});
  button.onpointerdown=e=>e.preventDefault();button.onclick=()=>{button.hidden=true;window.myAgentAsk(quote,'',{view:location.hash,page:location.pathname});};return;
 }
 const en=()=>localStorage.getItem('tht-board-lang')==='en',tr=(z,e)=>window.CitesideL10n?window.CitesideL10n.pick(z,e):(en()?e:z);
 // Recording offsets: m:ss under an hour, h:mm:ss after (never 66:31).
 const make=(tag,text='',cls='')=>{const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;};
 const auth=()=>{if(window.THT_BOOT?.relayToken)return window.THT_BOOT.relayToken;try{return JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{return '';}};
 const address=p=>p+(p.includes('?')?'&':'?')+'token='+encodeURIComponent(auth());
 function openMeeting(id,atSec=0,moduleId=''){if(!id)return false;const at=Number(atSec)>0?Number(atSec):0;if(typeof window.thtOpenMeeting==='function')window.thtOpenMeeting(id,at,moduleId);else{const url=new URL('/seatnote/',location.href);url.searchParams.set('id',id);if(moduleId)url.searchParams.set('module',moduleId);if(at)url.hash='t='+at;location.assign(url.href);}return true;}
 function errorText(error,canRetry=false,terminal=false){
  const message=String(error?.message||error||'');
  if(/rate limit|too many requests|请求限流|请求暂时受限/i.test(message))return canRetry?tr('请求暂时受限，消息已保留；稍后可以重试原请求。','The request was rate limited. Your message is kept; you can retry the original request later.'):tr('请求暂时受限，本次请求未完成；消息已保留。','The request was rate limited and did not complete. Your message is kept.');
  if(/spend cap|usage limit|quota|额度已用尽|额度不足/i.test(message))return canRetry?tr('额度受限，消息已保留；额度恢复后可以重试原请求。','The quota is unavailable. Your message is kept; you can retry the original request when quota is available.'):tr('额度受限，本次请求未完成；消息已保留。','The quota is unavailable and this request did not complete. Your message is kept.');
  if(terminal&&/timeout|timed out|任务长时间没有进展/i.test(message))return canRetry?tr('任务超时，未完成；消息已保留，可以重试原请求。','The task timed out and did not complete. Your message is kept; you can retry the original request.'):tr('任务超时，已停止；消息已保留，请先核对原结果。','The task timed out and was stopped. Your message is kept; check the original result first.');
  if(terminal&&/服务已重启，任务未完成|Service restarted; (?:retry the unfinished task|task unfinished)/i.test(message))return canRetry?tr('服务已重启，任务未完成；消息已保留，可以重试原请求。','The service restarted before the task completed. Your message is kept; you can retry the original request.'):tr('服务已重启，任务未完成；消息已保留。','The service restarted before the task completed. Your message is kept.');
  if(/Failed to fetch|Load failed|NetworkError|fetch failed|disconnected|retrying|timeout|timed out|aborted|连接暂时中断|Connection interrupted/i.test(message))return canRetry?tr('连接暂时中断；消息已保留，可以重试。','Connection interrupted. Your message is kept; you can retry.'):terminal?tr('这次连接已中断；消息已保留，请先核对原结果。','This connection ended. Your message is kept; check the original result first.'):tr('连接暂时中断，正在重新连接。','Connection interrupted. Reconnecting.');
  if(/invalid module|invalid state|null.*assigned|assigned.*null/i.test(message))return canRetry?tr('这次处理未完成；消息已保留，请重试。','This request could not be completed. Your message is kept; please retry.'):tr('这次处理未完成；消息已保留，请先核对原结果。','This request could not be completed. Your message is kept; check the original result first.');
  if(/这条任务不能停止/.test(message))return tr('这条任务已经结束，不用再停。','This task has already finished.');
  return message;
 }
 async function api(body,path='/workspace-assistant',opt){
  const ms=opt&&Number.isFinite(opt.timeoutMs)?opt.timeoutMs:20000;
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),ms);
  try{
   let r;try{r=await fetch(address(path),{signal:controller.signal,cache:'no-store',...(body?{method:'POST',headers:{'Content-Type':'application/json','x-tht-token':auth()},body:JSON.stringify(body)}:{})});}
   catch(error){
    const aborted=!!(error&&(error.name==='AbortError'||error.name==='TimeoutError'))||/aborted|timeout|timed out/i.test(String(error&&error.message||error||''));
    if(opt&&opt.unconfirmedOnTimeout&&aborted)throw Object.assign(Error(tr('状态未确认','Status unconfirmed')),{uncertain:true,transport:true});
    throw Object.assign(Error(errorText(error)),{transport:true});
   }
   const j=await r.json();if(!r.ok)throw Object.assign(Error(j.error||'HTTP '+r.status),{status:r.status,body:j,uncertain:!!j.uncertain});return j;
  }finally{clearTimeout(timeout);}
 }
 const panel=make('aside','','ma-panel'),fab=make('button','✦ MyAgent','ma-fab'),dock=make('div','','ma-dock');
 const homeReturnPill=make('button','','ma-home-return-pill');homeReturnPill.id='ma-home-return-pill';homeReturnPill.type='button';homeReturnPill.hidden=true;
 homeReturnPill.onclick=()=>open();
 const HOME_THREADS_KEY='citeside-home-threads-v1';
 let homeThreadStore={activeId:null,deletedIds:[],threads:[]};
 try{const saved=JSON.parse(localStorage.getItem(HOME_THREADS_KEY)||'null');if(saved&&Array.isArray(saved.threads))homeThreadStore={activeId:saved.activeId||null,deletedIds:Array.isArray(saved.deletedIds)?saved.deletedIds:[],threads:saved.threads};}catch{}
 let homeChatMode='fresh',homeHistoryOpen=false,homeMenuThreadId=null,homeRenamingId=null;
 const saveHomeThreads=()=>{try{localStorage.setItem(HOME_THREADS_KEY,JSON.stringify({activeId:homeThreadStore.activeId,deletedIds:homeThreadStore.deletedIds.slice(-300),threads:homeThreadStore.threads.slice(0,80)}));}catch{}};
 const activeHomeThread=()=>homeThreadStore.threads.find(t=>t.id===homeThreadStore.activeId)||null;
 const CLOCK_SVG='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>';
 const NEW_CHAT_SVG='<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
 const CHEV_DOWN_SVG='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>';
 const CLOSE_X_SVG='<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
 const homeDock=make('div','','ma-home-dock');homeDock.id='ma-home-dock';
 const homeHistoryPop=make('div','','ma-home-history-pop');homeHistoryPop.id='ma-home-history-pop';homeHistoryPop.hidden=true;
 const homeRowMenu=make('div','','ma-home-row-menu');homeRowMenu.hidden=true;document.body.append(homeRowMenu);
 const homeThinkingPill=make('div','','ma-home-thinking-pill');homeThinkingPill.hidden=true;
 const homeContinuePill=make('div','','ma-home-continue-pill');homeContinuePill.hidden=true;
 const homeExpandedHead=make('div','','ma-home-exp-head');homeExpandedHead.hidden=true;
 const freshHistoryBtn=make('button','','ma-home-hist-btn ma-home-fresh-hist');freshHistoryBtn.type='button';freshHistoryBtn.innerHTML=CLOCK_SVG;
 homeDock.append(homeHistoryPop,homeThinkingPill,homeContinuePill,homeExpandedHead);
 panel.id='myagent-panel';panel.hidden=true;panel.setAttribute('aria-label','主动智能');
 panel.innerHTML='<header class="ma-head"><div><strong class="ma-title">主动智能</strong><small class="ma-connection" hidden role="status"></small></div><div><button type="button" class="ma-close" aria-label="收起" title="收起"><svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6l4 4 4-4"/></svg></button></div></header><div class="ma-conversation" aria-live="polite" aria-relevant="additions text"></div><form class="ma-form cmp"><div class="ma-quote-wrap" hidden><blockquote class="ma-quote"></blockquote><button type="button" class="ma-clear-quote" aria-label="Clear quote">×</button></div><textarea maxlength="4000" rows="2"></textarea><div class="ma-materials"></div><input class="ma-file" type="file" accept=".txt,.md,.csv,.json,.png,.jpg,.jpeg,.webp" multiple hidden><div class="ma-controls"><div class="ma-tools"><button type="button" class="ma-add" aria-label="补充材料">＋</button><select class="ma-model" aria-label="模型"><option value="">默认模型</option></select><select class="ma-model ma-effort" aria-label="推理强度" hidden></select><button type="button" class="ma-voice" aria-label="语音输入"></button></div><button type="submit" class="ma-send" aria-label="Send">↑</button></div><div class="ma-help-row"><small class="ma-hint"></small><details class="ma-model-info"><summary></summary><p></p></details></div><small class="ma-status" role="status"></small></form>';
 const feed=make('div','','ma-feed'),insights=make('section','','ma-insights');
 const conversation=panel.querySelector('.ma-conversation');conversation.before(feed);feed.append(insights,conversation);
 const ownerCard=make('section','','ma-owner-card');ownerCard.hidden=true;panel.querySelector('.ma-conversation').before(ownerCard);
 // Keep the same conversation across closing and reopening.
 document.body.append(panel,dock);
 const resizeHandle=make('div','','ma-resizer');resizeHandle.setAttribute('role','separator');resizeHandle.setAttribute('aria-label','调整助手宽度 / Resize assistant');resizeHandle.tabIndex=0;panel.prepend(resizeHandle);
 const setWidth=w=>{const width=Math.max(300,Math.min(innerWidth*.5,w));document.documentElement.style.setProperty('--ma-width',width+'px');localStorage.setItem('tht-agent-width',String(width));};
 if(Number(localStorage.getItem('tht-agent-width')))setWidth(Number(localStorage.getItem('tht-agent-width')));
 resizeHandle.onpointerdown=e=>{resizeHandle.setPointerCapture(e.pointerId);e.preventDefault();};resizeHandle.onpointermove=e=>{if(resizeHandle.hasPointerCapture(e.pointerId))setWidth(innerWidth-e.clientX-8);};resizeHandle.onkeydown=e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();setWidth(panel.getBoundingClientRect().width+(e.key==='ArrowLeft'?20:-20));}};if(!document.getElementById('b-assistant'))document.body.append(fab);
 const sharedForm=panel.querySelector('.ma-form');
 sharedForm.querySelector('.ma-tools').append(sharedForm.querySelector('.ma-model-info'));
 sharedForm.querySelector('.ma-tools').prepend(freshHistoryBtn);
 // Model choice is an occasional setting: it lives in the ⓘ popover, not beside every message.
 {const info=sharedForm.querySelector('.ma-model-info'),text=info.querySelector('p'),pick=make('div','','ma-model-pick'),label=make('span','','ma-model-text');pick.append(...sharedForm.querySelectorAll('.ma-tools > .ma-model'));text.replaceChildren(pick,label);pick.addEventListener('change',()=>{info.open=false;});document.addEventListener('pointerdown',e=>{if(info.open&&!info.contains(e.target))info.open=false;});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&info.open&&!e.defaultPrevented){e.preventDefault();info.open=false;}});}
 const $=s=>panel.querySelector(s)||(s==='.ma-form'?sharedForm:sharedForm.querySelector(s)),input=$('textarea');
 const sharedSlot=document.getElementById('meeting-composer-slot');if(sharedSlot){sharedSlot.append(sharedForm);sharedForm.classList.add('ma-shared-form');document.body.classList.add('ma-shared-composer');}let quote='',object={},jobs=[],localJobs=[],developAllowed=false,streamController,retryTimer,connected=false,streamFailed=false,materials=[],uploading=false,pendingMaterialCounts=new Map(),recognition=null,connectionError=false;
 const homeRequests=new Set();let showHomeHistory=false,archivedHomeDraft=null;
 const drafts=Object.create(null),scopeKey=meta=>String(meta?.contextId&&meta.contextId!=='assistant:global'?meta.contextId:'home');
 let candidateTarget=null;
 let conversationVersion=0;let currentScope=scopeKey({contextId:new URLSearchParams(location.search).get('id')||''});
 const effortSelect=$('.ma-effort');
 const modelSelect=$('.ma-model');let modelCatalog=[],modelError=false,modelLoaded=false;const rememberedModel=localStorage.getItem('tht-agent-model')||'';if(rememberedModel){const option=make('option',rememberedModel);option.value=rememberedModel;modelSelect.append(option);}modelSelect.value=rememberedModel;
 try{
  const saved=JSON.parse(sessionStorage.getItem('tht-agent-composer')||'{}');
  if(saved.version===2){for(const [key,value]of Object.entries(saved.contexts||{}))drafts[key]=value;}
  else if(saved.text||saved.quote||saved.materials?.length)drafts[scopeKey(saved.object?.contextId?saved.object:{})]=saved;
  const draft=drafts[currentScope]||{};input.value=draft.text||'';quote=draft.quote||'';object=draft.object||{};materials=Array.isArray(draft.materials)?draft.materials.slice(0,5):[];
  localJobs=(saved.pending||[]).filter(j=>j.payload?.requestId&&j.composer).map(j=>({...j,id:'local-'+j.payload.requestId,state:'failed',error:tr('上次发送的结果尚未确认；可以重试查询。','Previous delivery is unconfirmed; retry to check.'),events:[]}));
 }catch{}
 // Keep older home drafts recoverable, but do not treat them as current input.
 if(drafts.home?.text||drafts.home?.quote||drafts.home?.materials?.length){
  archivedHomeDraft=structuredClone(drafts.home);
  try{sessionStorage.setItem('tht-agent-home-draft-archive',JSON.stringify(archivedHomeDraft));}catch{}
 }else{try{archivedHomeDraft=JSON.parse(sessionStorage.getItem('tht-agent-home-draft-archive')||'null');}catch{}}
 if(currentScope==='home'){input.value='';quote='';object={};materials=[];}
 drafts.home={text:'',quote:'',object:{},materials:[]};
 let ownerLoaded=false;
 async function greetOwner(){
  if(ownerLoaded)return;
  try {const state=await api(null,'/setup');ownerLoaded=true;if(!state.ownerProfile?.needsName)return;
   ownerCard.replaceChildren();ownerCard.hidden=false;const label=make('strong',tr('怎么称呼你？','What should I call you?')),name=make('input'),row=make('div');name.maxLength=80;name.placeholder=tr('你的称呼','Your name');name.setAttribute('aria-label',tr('你的称呼','Your name'));
   const save=make('button',tr('记住这个称呼','Remember my name')),skip=make('button',tr('先跳过','Skip for now')),status=make('small','','ma-owner-status');save.type=skip.type='button';status.setAttribute('role','status');status.setAttribute('aria-live','polite');row.append(save,skip);ownerCard.append(label,name,row,status);
   let saving=false;
   async function submit(value){
    if(saving)return;saving=true;name.disabled=save.disabled=skip.disabled=true;ownerCard.setAttribute('aria-busy','true');status.classList.remove('ma-owner-error');status.textContent=tr('正在保存…','Saving…');
    try{const result=await api(value,'/setup/owner');if(result.ownerProfile?.needsName!==false)throw Error(result.ownerProfile?.needsName===true?tr('请换一个称呼，或选择先跳过。','Choose another name, or Skip for now.'):tr('称呼未保存，请重试。','Your name was not saved. Please retry.'));
     status.textContent=value.skip?tr('已跳过，不影响使用。','Skipped. You can continue.'):tr('已记住，','Got it, ')+result.ownerProfile.displayName;
     ownerCard.replaceChildren(status);setTimeout(()=>{ownerCard.hidden=true;},2500);
    }catch(e){name.disabled=save.disabled=skip.disabled=false;status.classList.add('ma-owner-error');status.textContent=errorText(e);}
    finally{saving=false;ownerCard.setAttribute('aria-busy','false');}
   }
   save.onclick=()=>{if(name.value.trim())submit({displayName:name.value.trim()});else{status.classList.add('ma-owner-error');status.textContent=tr('请填写称呼，或选择先跳过。','Enter a name, or choose Skip for now.');name.focus();}};skip.onclick=()=>submit({skip:true});name.onkeydown=e=>{if(e.key==='Enter'){if(e.isComposing||e.keyCode===229)return;e.preventDefault();save.click();}};
  }catch{} // A local profile is optional; connector login is independent.
 }
 let defaultObject={page:'meeting',contextId:new URLSearchParams(location.search).get('id')||''};
 function conversationContext(meta){
  // Selection and destination metadata belong to one request, never the fallback conversation.
  return Object.fromEntries(['contextId','projectId','page','view'].filter(key=>meta[key]!==undefined).map(key=>[key,meta[key]]));
 }
 function switchConversation(meta){
  const next=scopeKey(meta);if(next===currentScope){defaultObject=conversationContext(meta);return;}
  endCandidateComment();persist();stopDictation();conversationVersion++;connectionError=false;currentScope=next;defaultObject=conversationContext(meta);
  const draft=drafts[next]||{};input.value=draft.text||'';quote=draft.quote||'';object=draft.object||{};materials=Array.isArray(draft.materials)?draft.materials.slice(0,5):[];
  $('.ma-status').textContent='';showMaterials();showQuote();resizeComposer();voiceIcon();insights.replaceChildren();persist();queueMicrotask(()=>{render();if(proactiveData?.id===currentScope){proactiveKey='';renderProactive(proactiveData);}});
 }
 const globalPrompts=window.ThtPrompts?.create(localStorage),meetingPrompts=window.ThtPrompts?.meetingDefaults?window.ThtPrompts.create(localStorage,'tht-prompt-library:meeting:v1',window.ThtPrompts.meetingDefaults):globalPrompts,promptBar=make('div','','ma-prompts');
 // r8：会议页用会议那组提示词（原型 PV.defaults），首页 / 独立助手用通用那组。
 let promptLibrary=globalPrompts;
 sharedForm.prepend(promptBar);
 // WorkBuddy 2026-11-18 UI/UX 修复 P0-1：拆出「只填入、不发送」，供明确标注填写的入口使用。
 function fillPrompt(item){
  const value=promptLibrary.instruction(item.id,en()?'en':'zh');
  const draft=input.value.trim();if(!draft.split('\n\n').includes(value))input.value=[draft,value].filter(Boolean).join('\n\n');
  if(!Object.keys(object).length)object={...defaultObject};
  promptLibrary.use(item.id);persist();resizeComposer();drawPrompts();
 }
 function selectPrompt(item){
  // 快捷词 chip 保持点一下就发（效率设计），但 title 需明示，避免名实不符。
  fillPrompt(item);
  send();
 }
 // Every saved prompt stays in the user's own order; clicking sends it. Edit mode renames, deletes and adds in place.
 let promptEditing=false;
 function finishPromptEdit(){promptBar.querySelectorAll('.ma-prompt-chip input').forEach(x=>x.dispatchEvent(new Event('change')));promptEditing=false;drawPrompts();}
 function drawPrompts(){
  promptBar.replaceChildren();if(!promptLibrary)return;promptBar.classList.toggle('editing',promptEditing);promptBar.setAttribute('role','toolbar');promptBar.setAttribute('aria-label',tr('常用提示词','Saved prompts'));
  for(const item of promptLibrary.list()){
   const label=en()?item.en:item.zh;
   if(!promptEditing){const b=make('button',label);b.type='button';const ins=promptLibrary.instruction(item.id,en()?'en':'zh');b.title=tr('点击直接发送：','Click to send: ')+ins;b.setAttribute('aria-label',b.title);b.onclick=()=>selectPrompt(item);promptBar.append(b);continue;}
   const chip=make('span','','ma-prompt-chip'),name=make('input');name.value=label;name.maxLength=80;name.setAttribute('aria-label',tr('提示词名称','Prompt name'));const fit=()=>{const w=[...name.value].reduce((n,c)=>n+(c.charCodeAt(0)>255?2:1),0);name.style.width=Math.max(4,Math.min(28,w+1))+'ch';};fit();name.addEventListener('input',fit);
   name.onkeydown=e=>{if(e.key==='Enter'&&!e.isComposing&&e.keyCode!==229){e.preventDefault();name.blur();}};
   name.onchange=()=>{const text=name.value.trim();if(!text){name.value=label;return;}const lang=en()?'en':'zh',key=lang==='en'?'promptEn':'promptZh',next={...item,[lang]:text};if(item[key]===label)next[key]=text;try{promptLibrary.put(next);}catch{name.value=label;}};
   const del=make('button','×','ma-prompt-del');del.type='button';del.title=tr('删掉','Delete');del.setAttribute('aria-label',tr('删掉','Delete')+' '+label);del.onclick=()=>{try{promptLibrary.remove(item.id);}catch{}drawPrompts();promptBar.querySelector('.ma-prompt-edit')?.focus();};
   chip.append(name,del);promptBar.append(chip);
  }
  if(promptEditing){
   const add=make('button',tr('＋ 添加','＋ Add'),'ma-prompt-add');add.type='button';add.onclick=()=>{const text=tr('新提示词','New prompt'),id=crypto.randomUUID();try{promptLibrary.put({id,zh:text,en:text,promptZh:text,promptEn:text});}catch{return;}drawPrompts();const last=[...promptBar.querySelectorAll('.ma-prompt-chip input')].pop();last?.focus();last?.select();};
   const detail=make('button',tr('完整指令…','Full instructions…'),'ma-prompt-detail');detail.type='button';detail.onclick=()=>window.thtOpenPrompts();
   promptBar.append(add,detail);
  }
  const edit=make('button',promptEditing?tr('完成','Done'):tr('编辑','Edit'),'ma-prompt-edit');edit.type='button';edit.setAttribute('aria-pressed',String(promptEditing));
  edit.onclick=()=>{if(promptEditing){finishPromptEdit();return;}promptEditing=true;drawPrompts();promptBar.querySelector('.ma-prompt-chip input')?.focus();};
  promptBar.append(edit);
 }
 window.thtOpenPrompts=()=>{
  if(!promptLibrary)return;const existing=document.querySelector('.ma-prompt-dialog');if(existing){existing.focus();return;}
  const d=make('dialog','','ma-prompt-dialog'),title=make('h2',tr('我的提示词','My prompts')),choices=make('div'),fields=make('div'),status=make('p');status.setAttribute('role','status');
  const controls={};let selected='';const extra=make('details'),extraTitle=make('summary',tr('另一种语言（选填）','Other language (optional)'));extra.append(extraTitle);
  for(const [key,zh,eng] of [['zh','中文名称','Chinese label'],['en','英文名称','English label'],['promptZh','中文指令','Chinese instruction'],['promptEn','英文指令','English instruction']]){
   const label=make('label',tr(zh,eng)),field=make(key.startsWith('prompt')?'textarea':'input');field.maxLength=key.startsWith('prompt')?4000:80;label.append(field);const other=en()?['zh','promptZh'].includes(key):['en','promptEn'].includes(key);(other?extra:fields).append(label);controls[key]=field;
  }
  fields.append(extra);
  const choose=item=>{selected=item.id;for(const key of Object.keys(controls))controls[key].value=item[key];status.textContent='';};
  function list(){choices.replaceChildren();for(const item of promptLibrary.list()){const b=make('button',en()?item.en:item.zh);b.type='button';b.onclick=()=>choose(item);choices.append(b);}}
  const save=make('button',tr('保存提示词','Save prompt')),use=make('button',tr('填入输入框','Use in composer')),add=make('button',tr('新建','New')),close=make('button',tr('关闭','Close'));
  for(const b of [save,use,add,close])b.type='button';
  function store(){try{promptLibrary.put({id:selected,...Object.fromEntries(Object.entries(controls).map(([k,v])=>[k,v.value]))});list();drawPrompts();status.textContent=tr('已保存','Saved');return true;}catch(e){status.textContent=tr('未保存：请填写名称和完整指令，并确认浏览器允许本地保存。','Not saved: enter a label and complete instruction, and allow local storage.');return false;}}
  // WorkBuddy 2026-11-18 P0-1：名为「填入输入框」就只填入，不自动发送。
  save.onclick=store;use.onclick=()=>{if(store()){fillPrompt(promptLibrary.list().find(x=>x.id===selected));d.close();}};
  add.onclick=()=>{choose({id:crypto.randomUUID(),zh:'',en:'',promptZh:'',promptEn:''});controls[en()?'en':'zh'].focus();};close.onclick=()=>d.close();
  d.append(title,choices,fields,status,add,save,use,close);d.addEventListener('close',()=>d.remove());document.body.append(d);list();choose(promptLibrary.list()[0]||{id:crypto.randomUUID(),zh:'',en:'',promptZh:'',promptEn:''});d.showModal();
 };
 window.thtMountComposer=(host,meta={})=>{if(!host)return;promptLibrary=meta.page==='meeting'||(!meta.page&&host===sharedSlot)?meetingPrompts:globalPrompts;switchConversation(meta);const isHomeHost=host.matches?.('#document-home .dh-footer');if(isHomeHost){if(homeDock.parentElement!==host)host.replaceChildren(homeDock);if(sharedForm.parentElement!==homeDock)homeDock.append(sharedForm);}else if(sharedForm.parentElement!==host||promptBar.parentElement!==host)host.replaceChildren(promptBar,sharedForm);sharedForm.classList.add('ma-shared-form');document.body.classList.add('ma-shared-composer');drawPrompts();resizeComposer();placeChatLayer();};
 const initialHome=document.querySelector('.document-home-open .dh-footer');if(initialHome)window.thtMountComposer(initialHome,{page:'meeting-home'});else if(sharedSlot)window.thtMountComposer(sharedSlot,{contextId:currentScope});
 // r8（原型 final.html）：会议页不让用户选回答档位，答多深按这句话自动定；说「再深一点 / 展开 / 再研究」就往深里答。
 function selectedEffort(){
  if(!sharedSlot)return effortSelect.hidden?'':effortSelect.value;
  const current=modelCatalog.find(m=>modelSelect.value?m.id===modelSelect.value:m.isDefault);
  return current?.provider!=='api'?autoEffort(input.value,current?.supportedReasoningEfforts):'';
 }
 // 默认 medium；这句话要「再深一点 / 展开 / 再研究 / 详细」时用 high（模型不支持就退回 medium）。
 function autoEffort(text,supported){const has=e=>Array.isArray(supported)&&supported.includes(e);const want=/深一点|深入|展开|再研究|详细|仔细|deeper|in depth|elaborate|dig in/i.test(String(text||''))?'high':'medium';return has(want)?want:has('medium')?'medium':'';}
 function composer(){const context=Object.keys(object).length?object:defaultObject;return {text:input.value.trim(),quote,object:context,materials,model:modelSelect.value,effort:selectedEffort(),develop:false};}
 function sameDraft(entry){return !candidateTarget&&JSON.stringify(composer())===JSON.stringify(entry.composer);}
 function persist(){drafts[candidateTarget?.key||currentScope]={text:input.value,quote,object,materials};sessionStorage.setItem('tht-agent-composer',JSON.stringify({version:2,contexts:drafts,pending:localJobs.map(({comment,quote,payload,composer})=>({comment,quote,payload,composer}))}));}
 function endCandidateComment(){
  if(!candidateTarget)return;persist();stopDictation();candidateTarget.state.open=false;candidateTarget.close?.();candidateTarget=null;
  const draft=drafts[currentScope]||{};input.value=draft.text||'';quote=draft.quote||'';object=draft.object||{};materials=draft.materials||[];
  showMaterials();showQuote();resizeComposer();
 }
 function beginCandidateComment(target){
  if(candidateTarget?.key===target.key){input.focus();return;}
  endCandidateComment();persist();stopDictation();candidateTarget=target;target.state.open=true;
  const draft=drafts[target.key]||{};input.value=draft.text||'';quote='';object={};materials=draft.materials||[];
  showMaterials();showQuote();resizeComposer();input.focus();
 }
 // The document column hands its follow-up questions (e.g. organization direction) to this one composer.
 // Only live conversation work in this scope can own the shared Stop button.
 const composerReleased=new Set();
 function composerBusy(j){const stamp=Date.parse(j.updated||j.started||j.created||''),now=Date.now();return !composerReleased.has(j.id)&&j.inFlight===true&&!j.finished&&!j.candidateId&&!j.taskId&&active(j)&&scopeKey({contextId:j.contextId||j.meetingId})===currentScope&&!['executing','stopping'].includes(j.state)&&Number.isFinite(stamp)&&stamp<=now&&now-stamp<10*60*1000&&(!j.expiresAt||Date.parse(j.expiresAt)>now);}
 function resizeComposer(){homeConversationLayout();const meeting=!!sharedSlot&&sharedForm.parentElement===sharedSlot,home=!!sharedForm.closest?.('body.document-home-open.citeside-home-v16 #document-home .dh-footer');input.rows=meeting||home?1:2;if(home){input.style.setProperty('height','auto','important');input.style.setProperty('height',Math.max(28,Math.min(120,input.scrollHeight))+'px','important');}else{input.style.height=meeting?'34px':'auto';input.style.height=Math.max(meeting?34:48,Math.min(meeting?120:144,input.scrollHeight))+'px';}const busy=candidateTarget?null:jobs.find(j=>composerBusy(j));const send=$('.ma-send');send.disabled=!busy&&(uploading||!!candidateTarget?.state.busy||(!input.value.trim()&&!materials.length));send.textContent=busy?'■':'↑';send.setAttribute('aria-label',busy?tr('停止','Stop'):tr('发送','Send'));send.dataset.stop=busy?.id||'';}
 function homeConversationLayout(){if(!document.body.classList.contains('document-home-open'))return;const rect=sharedForm.parentElement.getBoundingClientRect();if(rect.height){panel.style.setProperty('--home-composer-bottom',Math.max(90,Math.ceil(innerHeight-rect.top+10))+'px');panel.style.setProperty('--home-chat-left',rect.left+'px');panel.style.setProperty('--home-chat-width',rect.width+'px');}}
 new ResizeObserver(homeConversationLayout).observe(sharedForm);window.addEventListener('resize',homeConversationLayout);window.addEventListener('scroll',homeConversationLayout,{passive:true,capture:true});
 function clearComposer(){input.value='';quote='';object={};materials=[];showMaterials();showQuote();resizeComposer();persist();}
 function voiceIcon(listening=false){
  const button=$('.ma-voice');button.innerHTML=listening?'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M6 10v2a6 6 0 0 0 12 0v-2M12 18v3M9 21h6"/></svg>';
  button.setAttribute('aria-pressed',String(listening));button.setAttribute('aria-label',listening?tr('结束听写','Stop dictation'):tr('语音输入','Voice input'));button.title=listening?tr('结束听写，检查后发送','Stop dictation, review then send'):tr('语音输入','Voice input');
 }
 const effortName=e=>({none:tr('无','none'),minimal:tr('极低','minimal'),low:tr('低','low'),medium:tr('中度','medium'),high:tr('高','high'),xhigh:tr('更高','extra high'),max:tr('最高','maximum'),ultra:tr('超高','ultra')})[e]||e||tr('模型默认','model default');
 function modelName(m){return String(m?.name||m?.id||'').replace(/(GPT-[\d.]+)-/,'$1 ');}
 function modelDescription(m){const descriptions={
  'Latest workhorse model for coding and everyday work.':'适合代码开发与日常工作。',
  'Frontier intelligence for the most demanding work.':'用于要求较高的复杂工作。',
  'Previous generation workhorse model.':'上一代通用工作模型。',
  'Fast and affordable model for easier tasks.':'适合较简单的任务，侧重速度与较低用量。',
  'Older generation workhorse model.':'较早一代的通用工作模型。',
  'Older balanced model for straightforward work.':'较早一代的均衡模型，适合直接明确的任务。',
  'Older fast and efficient model.':'较早一代的快速模型。'
 };return en()?m.description||'':descriptions[m.description]||m.description||'';}
 // 诊断 #7：空值选项本来就是「用默认模型」。读取中、读取失败、目录里没标默认时都只显示「默认模型」，
 // 不再挂一个要等两轮 20 秒超时才结束的「读取中」提示。
 function sizeModel(){
  const current=modelCatalog.find(m=>modelSelect.value?m.id===modelSelect.value:m.isDefault),first=modelSelect.options[0];
  first.textContent=current&& !modelSelect.value?modelName(current)+' · '+tr('默认','default'):modelCatalog.find(m=>m.isDefault)?modelName(modelCatalog.find(m=>m.isDefault))+' · '+tr('默认','default'):tr('默认模型','Default model');
  const supported=current?.provider==='api'?[]:current?.supportedReasoningEfforts||[];
  const rememberedEffort=localStorage.getItem('tht-agent-effort:'+modelSelect.value)||'';
  effortSelect.replaceChildren();const automatic=make('option',tr('默认强度','Default effort')+(current?.reasoningEffort?' · '+effortName(current.reasoningEffort):''));automatic.value='';effortSelect.append(automatic);
  for(const effort of supported){const option=make('option',effortName(effort));option.value=effort;effortSelect.append(option);}
  effortSelect.hidden=!!sharedSlot||!supported.length;effortSelect.value=supported.includes(rememberedEffort)?rememberedEffort:'';effortSelect.setAttribute('aria-label',tr('推理强度','Reasoning effort'));
  const detail=$('.ma-model-info'),fullText=current?[!modelSelect.value?(current.provider==='api'?tr('默认使用已配置的模型 API。','Default uses your configured model API.'):tr('默认使用当前配置的对话模型。','Default uses the configured conversation model.')):'',modelName(current)+(current.provider==='api'?'':' · '+effortName(selectedEffort()||current.reasoningEffort)+tr('推理。',' reasoning.')),modelDescription(current),tr('切换用于后续消息；正在执行的任务保持原模型。','Changes apply to future messages; running tasks keep their model.'),tr('手选模型启动失败时会报错，不会悄悄换模型；默认模式的备用调用会显示在过程里。','A selected model failure is reported without substitution. Default-mode fallback is shown in Activity.')].filter(Boolean).join(' '):modelSelect.value?tr('所选模型的信息暂未确认；发送时仍使用你的选择，启动失败会报错，不会换成默认模型。','Selected model information is unconfirmed. Your selection is kept; startup failure is reported without substitution.'):tr(modelError||modelLoaded?'模型信息暂不可用；发送时会重新读取本机配置，不猜测模型。':'正在读取模型与推理配置。',modelError||modelLoaded?'Model information unavailable. Configuration is read again when sending.':'Reading model and reasoning settings.');
  const text=current?[modelDescription(current),tr('切换仅用于后续消息。','Changes apply to future messages.')].filter(Boolean).join(' '):tr('模型信息待确认；保留当前选择。','Model info pending; your selection is kept.');
  detail.querySelector('summary').textContent=current?(current.provider==='api'?'API · '+tr('说明','Info'):effortName(selectedEffort()||current.reasoningEffort)+tr('推理 · 说明',' reasoning · Info')):tr('模型说明','Model info');detail.querySelector('.ma-model-text').textContent=text;
  const selected=modelSelect.selectedOptions[0];modelSelect.style.width=Math.min(164,Math.max(84,(selected?.textContent.length||4)*7+27))+'px';modelSelect.title=fullText;modelSelect.setAttribute('aria-label',tr('选择模型：','Select model: ')+(selected?.textContent||''));
 }

 function showQuote(){const range=object.range?.length?String(object.rangeLabel||''):'',target=range||(candidateTarget?candidateTarget.label||tr('修改候选：','Revise candidate: ')+candidateTarget.title:object.targetTitle?tr('起草目标：','Draft destination: ')+object.targetTitle:'');$('.ma-quote-wrap').hidden=!quote&&!target;$('.ma-quote').textContent=range||[target,quote].filter(Boolean).join('\n');input.placeholder=range?(object.range.length>1?tr('说要怎么改这 '+object.range.length+' 处…','Say how to change these '+object.range.length+' places…'):tr('说要怎么改这段…','Say how to change this…')):tr('问点什么，或者交给我做…','Ask anything, or give me a task…');}
 function language(){drawPrompts();input.setAttribute('aria-label',tr('给 MyAgent 发消息','Message MyAgent'));input.placeholder=document.body.classList.contains('meeting-workspace')?tr('就本次会议提问，或让我去做…','Ask about this meeting, or have me do something…'):tr('问所有会议和文档，或让我去做…','Ask across meetings and docs, or have me do something…');input.title=document.body.classList.contains('meeting-workspace')?tr('问什么都行，答多深我自己判断；想更深就说「再深一点」','Ask anything — I decide how deep to go; say "go deeper" for more.'):'';$('.ma-add').setAttribute('aria-label',tr('添加材料','Add material'));$('.ma-add').title=tr('添加材料','Add material');$('.ma-hint').textContent=tr('↵ 发送 · Shift ↵ 换行','↵ Send · Shift ↵ New line');$('.ma-send').setAttribute('aria-label',tr('发送','Send'));$('.ma-close').setAttribute('aria-label',tr('收起','Close'));$('.ma-clear-quote').setAttribute('aria-label',tr('取消引用','Clear quote'));voiceIcon(!!recognition);sizeModel();$('.ma-title').textContent=tr('主动智能','Intelligence');panel.setAttribute('aria-label',tr('主动智能','Intelligence'));$('.ma-connection').hidden=!streamFailed;$('.ma-connection').textContent=streamFailed?tr('更新暂时中断，正在重连','Updates interrupted. Reconnecting.'):'';}
 const seen=new Map();try{const entries=JSON.parse(localStorage.getItem('tht-intake-seen')||'[]');if(Array.isArray(entries))for(const e of entries)if(Array.isArray(e)&&e.length===2)seen.set(e[0],e[1]);}catch{}
 const unseen=j=>j.origin&&j.finished&&seen.get(j.id)!==j.finished;
 function markSeen(){for(const j of jobs)if(j.origin&&scopeKey(j)===currentScope)seen.set(j.id,j.finished);localStorage.setItem('tht-intake-seen',JSON.stringify([...seen].slice(-100)));}
 function hideHomeRowMenu(){homeMenuThreadId=null;homeRowMenu.hidden=true;}
 function syncHomeThreads(homeScoped){
  const del=new Set(homeThreadStore.deletedIds);
  const byReq=new Map(),byJob=new Map();
  for(const t of homeThreadStore.threads){
   t.requestIds=Array.isArray(t.requestIds)?t.requestIds:[];
   t.jobIds=Array.isArray(t.jobIds)?t.jobIds:[];
   for(const r of t.requestIds)byReq.set(r,t);
   for(const id of t.jobIds)byJob.set(id,t);
  }
  let dirty=false;
  const legacyByDay=new Map();
  for(const j of homeScoped){
   const rid=j.requestId||j.payload?.requestId||'',jid=j.id||'';
   if((jid&&del.has(jid))||(rid&&del.has(rid)))continue;
   const t=(rid&&byReq.get(rid))||(jid&&byJob.get(jid));
   if(t){
    if(jid&&!t.jobIds.includes(jid)){t.jobIds.push(jid);byJob.set(jid,t);dirty=true;}
    if(rid&&!t.requestIds.includes(rid)){t.requestIds.push(rid);byReq.set(rid,t);dirty=true;}
    const ts=Date.parse(j.updated||j.created||'')||Date.now();
    if(ts>(t.updatedAt||0)){t.updatedAt=ts;dirty=true;}
    continue;
   }
   const ts=Date.parse(j.created||j.updated||'')||Date.now();
   const day=new Date(ts).toISOString().slice(0,10);
   if(!legacyByDay.has(day))legacyByDay.set(day,[]);
   legacyByDay.get(day).push({j,rid,jid,ts});
  }
  for(const [day,items] of legacyByDay.entries()){
   const first=items[0].j,last=items[items.length-1];
   const title=String(first.comment||first.payload?.comment||tr('历史对话','Past chat')).replace(/\s+/g,' ').trim().slice(0,22)||day;
   const t={id:'ht-legacy-'+day,title,pinned:false,createdAt:items[0].ts,updatedAt:last.ts,requestIds:items.map(x=>x.rid).filter(Boolean),jobIds:items.map(x=>x.jid).filter(Boolean)};
   homeThreadStore.threads.push(t);dirty=true;
  }
  if(dirty){homeThreadStore.threads.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));saveHomeThreads();}
 }
 function homeJobsForThread(t,homeScoped){
  if(!t)return [];
  const rSet=new Set(t.requestIds||[]),jSet=new Set(t.jobIds||[]);
  return homeScoped.filter(j=>jSet.has(j.id)||rSet.has(j.requestId||j.payload?.requestId||''));
 }
 function openHomeRowMenu(thread,anchor){
  homeMenuThreadId=thread.id;
  const r=anchor.getBoundingClientRect();
  homeRowMenu.style.left=Math.min(innerWidth-148,Math.max(8,r.right-20))+'px';
  homeRowMenu.style.top=Math.min(innerHeight-132,Math.max(8,r.bottom+4))+'px';
  homeRowMenu.replaceChildren();
  const pinB=make('button',(thread.pinned?'📌 ':'📌 ')+(thread.pinned?tr('取消置顶','Unpin'):tr('置顶','Pin')));pinB.type='button';
  pinB.onclick=e=>{e.stopPropagation();thread.pinned=!thread.pinned;saveHomeThreads();hideHomeRowMenu();render();};
  const renB=make('button','✏️ '+tr('重命名','Rename'));renB.type='button';
  renB.onclick=e=>{e.stopPropagation();homeRenamingId=thread.id;hideHomeRowMenu();render();};
  const delB=make('button','🗑️ '+tr('删除','Delete'),'danger');delB.type='button';
  delB.onclick=e=>{
   e.stopPropagation();
   homeThreadStore.deletedIds.push(...(thread.jobIds||[]),...(thread.requestIds||[]));
   homeThreadStore.threads=homeThreadStore.threads.filter(x=>x.id!==thread.id);
   if(homeThreadStore.activeId===thread.id){homeThreadStore.activeId=null;homeChatMode='fresh';}
   saveHomeThreads();hideHomeRowMenu();render();
  };
  homeRowMenu.append(pinB,renB,delB);homeRowMenu.hidden=false;
  renderHomeHistoryPop();
 }
 function renderHomeHistoryPop(){
  homeHistoryPop.hidden=!homeHistoryOpen;
  if(!homeHistoryOpen){hideHomeRowMenu();return;}
  homeHistoryPop.replaceChildren();
  const todayStr=new Date().toISOString().slice(0,10);
  const pinned=homeThreadStore.threads.filter(t=>t.pinned);
  const today=homeThreadStore.threads.filter(t=>!t.pinned&&new Date(t.updatedAt||t.createdAt||Date.now()).toISOString().slice(0,10)===todayStr);
  const earlier=homeThreadStore.threads.filter(t=>!t.pinned&&new Date(t.updatedAt||t.createdAt||Date.now()).toISOString().slice(0,10)!==todayStr);
  const groups=[
   {label:tr('置顶','Pinned'),items:pinned},
   {label:tr('今天','Today'),items:today},
   {label:tr('更早','Earlier'),items:earlier},
  ];
  let any=false;
  for(const g of groups){
   if(!g.items.length)continue;
   any=true;
   homeHistoryPop.append(make('div',g.label,'ma-home-hist-lbl'));
   for(const t of g.items){
    const rowEl=make('div','','ma-home-hist-row'+(t.id===homeThreadStore.activeId?' is-active':'')+(t.id===homeMenuThreadId?' menu-open':''));
    if(homeRenamingId===t.id){
     const inp=document.createElement('input');inp.className='ma-home-rename-in';inp.value=t.title||'';
     inp.onclick=e=>e.stopPropagation();
     const done=()=>{const v=inp.value.trim();if(v){t.title=v;saveHomeThreads();}homeRenamingId=null;render();};
     inp.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();done();}else if(e.key==='Escape'){e.preventDefault();homeRenamingId=null;render();}};
     inp.onblur=done;
     rowEl.append(inp);homeHistoryPop.append(rowEl);
     setTimeout(()=>{inp.focus();inp.select();},0);
     continue;
    }
    const titleWrap=make('div','','ma-home-hist-title');
    if(t.pinned)titleWrap.append(make('span','📌','ma-home-pin-ico'));
    titleWrap.append(make('span',t.title||tr('未命名对话','Untitled')));
    const more=make('button','⋯','ma-home-more-btn');more.type='button';more.setAttribute('aria-label',tr('更多操作','More actions'));
    more.onclick=e=>{e.stopPropagation();openHomeRowMenu(t,more);};
    rowEl.onclick=()=>{homeThreadStore.activeId=t.id;homeChatMode='expanded';homeHistoryOpen=false;hideHomeRowMenu();saveHomeThreads();render();};
    rowEl.append(titleWrap,more);homeHistoryPop.append(rowEl);
   }
  }
  if(!any)homeHistoryPop.append(make('div',tr('暂无历史会话','No past conversations'),'ma-home-hist-empty'));
 }
 function startNewHomeChat(){
  homeThreadStore.activeId=null;homeChatMode='fresh';homeHistoryOpen=false;hideHomeRowMenu();saveHomeThreads();render();input.focus();
 }
 freshHistoryBtn.title=tr('历史会话','Chat history');
 freshHistoryBtn.setAttribute('aria-label',tr('历史会话','Chat history'));
 freshHistoryBtn.onclick=e=>{e.stopPropagation();homeHistoryOpen=!homeHistoryOpen;hideHomeRowMenu();renderHomeHistoryPop();};
 function paintHomeReturnPill(all=[]){
  const onHome=document.body.classList.contains('document-home-open');
  homeReturnPill.hidden=true;
  if(!onHome){homeDock.classList.remove('is-expanded','is-pill');freshHistoryBtn.hidden=true;homeHistoryOpen=false;hideHomeRowMenu();return;}
  panel.hidden=true;
  const t=activeHomeThread();
  const last=all[all.length-1],running=!!(last&&active(last));
  if(homeChatMode==='thinking'&&!running)homeChatMode=all.length?'continue':'fresh';
  if(homeChatMode==='continue'&&!all.length)homeChatMode='fresh';
  const isExpanded=homeChatMode==='expanded',isThinking=homeChatMode==='thinking',isContinue=homeChatMode==='continue',isFresh=homeChatMode==='fresh';
  homeDock.classList.toggle('is-expanded',isExpanded);
  homeDock.classList.toggle('is-pill',isThinking||isContinue);
  homeThinkingPill.hidden=!isThinking;
  homeContinuePill.hidden=!isContinue;
  homeExpandedHead.hidden=!isExpanded;
  conversation.hidden=!isExpanded;
  sharedForm.hidden=isThinking||isContinue;
  freshHistoryBtn.hidden=!isFresh;
  if(isThinking){
   homeThinkingPill.replaceChildren();
   const lbl=make('div','','ma-home-thinking-lbl');lbl.append(make('span',tr('Thinking…','Thinking…'),'ma-home-shimmer'));
   const acts=make('div','','ma-home-pill-acts');
   const expB=make('button',tr('展开','Expand'),'ma-home-pill-btn');expB.type='button';expB.onclick=e=>{e.stopPropagation();homeChatMode='expanded';render();};
   const stopB=make('button',tr('停止','Stop'),'ma-home-pill-btn stop');stopB.type='button';
   stopB.onclick=e=>{e.stopPropagation();if(last&&!last.id.startsWith('local-'))api({action:'cancel',jobId:last.id}).then(r=>upsert(r.job)).catch(()=>{});homeChatMode='continue';render();};
   acts.append(expB,stopB);homeThinkingPill.append(lbl,acts);
   homeThinkingPill.onclick=e=>{if(!e.target.closest('button')){homeChatMode='expanded';render();}};
  }
  if(isContinue&&t){
   homeContinuePill.replaceChildren();
   const hBtn=make('button','','ma-home-hist-btn');hBtn.type='button';hBtn.innerHTML=CLOCK_SVG;hBtn.title=tr('历史会话','Chat history');
   hBtn.onclick=e=>{e.stopPropagation();homeHistoryOpen=!homeHistoryOpen;hideHomeRowMenu();renderHomeHistoryPop();};
   const mainB=make('button','','ma-home-continue-main');mainB.type='button';
   mainB.append(make('span',tr('Continue','Continue'),'ma-home-continue-badge'),make('span',t.title||'','ma-home-continue-title'),make('span',String(last?.reply||last?.comment||'').replace(/[#*_`>\n]/g,' ').trim().slice(0,60),'ma-home-continue-prev'));
   mainB.onclick=()=>{homeChatMode='expanded';homeHistoryOpen=false;render();};
   const acts=make('div','','ma-home-pill-acts');
   const newB=make('button','','ma-home-icon-btn');newB.type='button';newB.innerHTML=NEW_CHAT_SVG;newB.title=tr('新建对话','New chat');newB.onclick=e=>{e.stopPropagation();startNewHomeChat();};
   const clsB=make('button','','ma-home-icon-btn');clsB.type='button';clsB.innerHTML=CLOSE_X_SVG;clsB.title=tr('关闭回到空白输入框','Close to new input');clsB.onclick=e=>{e.stopPropagation();startNewHomeChat();};
   acts.append(newB,clsB);
   homeContinuePill.append(hBtn,mainB,acts);
  }
  if(isExpanded){
   homeExpandedHead.replaceChildren();
   const left=make('div','','ma-home-exp-left');
   const hBtn=make('button','','ma-home-hist-btn');hBtn.type='button';hBtn.innerHTML=CLOCK_SVG+'<span class="ma-home-caret">▾</span>';hBtn.title=tr('历史会话','Chat history');
   hBtn.onclick=e=>{e.stopPropagation();homeHistoryOpen=!homeHistoryOpen;hideHomeRowMenu();renderHomeHistoryPop();};
   left.append(hBtn,make('span',t?.title||tr('新对话','New chat'),'ma-home-exp-title'));
   const right=make('div','','ma-home-pill-acts');
   const newB=make('button','','ma-home-icon-btn');newB.type='button';newB.innerHTML=NEW_CHAT_SVG;newB.title=tr('新建对话','New chat');newB.onclick=e=>{e.stopPropagation();startNewHomeChat();};
   const foldB=make('button','','ma-home-icon-btn');foldB.type='button';foldB.innerHTML=CHEV_DOWN_SVG;foldB.title=tr('收起','Collapse');foldB.onclick=e=>{e.stopPropagation();close();};
   right.append(newB,foldB);
   homeExpandedHead.append(left,right);
  }
  renderHomeHistoryPop();
 }
 function open(){if(modelError){modelRetries=0;loadModels();}if(document.body.classList.contains('meeting-workspace'))setMeetingChatFolded(false);if(document.body.classList.contains('document-home-open')){homeChatMode='expanded';homeHistoryOpen=false;hideHomeRowMenu();render();input.focus();refresh();return;}panel.classList.remove('ma-collapsed');greetOwner();markSeen();panel.hidden=false;document.body.classList.add('myagent-open');fab.hidden=true;dock.hidden=true;homeReturnPill.hidden=true;sessionStorage.setItem('tht-agent-open','1');document.getElementById('b-assistant')?.setAttribute('aria-expanded','true');language();showQuote();resizeComposer();input.focus();refresh();}
 function close(){if(document.body.classList.contains('meeting-workspace')){setMeetingChatFolded(true);return;}if(document.body.classList.contains('document-home-open')){homeHistoryOpen=false;hideHomeRowMenu();const last=meetingChatJobs[meetingChatJobs.length-1];homeChatMode=last&&active(last)?'thinking':(meetingChatJobs.length?'continue':'fresh');render();return;}panel.hidden=true;document.body.classList.remove('myagent-open');fab.hidden=false;dock.hidden=false;sessionStorage.setItem('tht-agent-open','0');document.getElementById('b-assistant')?.setAttribute('aria-expanded','false');paintHomeReturnPill(meetingChatJobs);}
 window.myAgentOpen=open;
 window.myAgentClose=close;
 window.myAgentToggle=()=>{if(panel.hidden||panel.classList.contains('ma-collapsed'))open();else close();};
 window.myAgentAsk=(selected,question='',meta={})=>{meta={...defaultObject,...meta};switchConversation(meta);endCandidateComment();quote=String(selected||'').slice(0,4000);object=meta;persist();open();if(question){input.value=question;send();}};
 window.claudeAssistantAsk=window.myAgentAsk;
 input.oninput=()=>{if(recognition){stopDictation();$('.ma-status').textContent=tr('已保留你的修改；听写已停止，检查后发送。','Your edits are kept. Dictation stopped; review, then send.');}if(input.value.trim()&&!Object.keys(object).length)object={...defaultObject};resizeComposer();persist();};
 $('.ma-close').onclick=close;fab.onclick=open;
 // Meeting and home floating conversations both fold on blank outside clicks.
 document.addEventListener('pointerdown',event=>{
  if(meetingWorkspace()){
   if(chatFolds.get(currentScope)||!meetingChatJobs.length)return;
   if(event.target.closest?.('.mw-chat-layer')||meetingChatOutsideBlocked(event.target))return;
   setMeetingChatFolded(true);
   return;
  }
  if(document.body.classList.contains('document-home-open')){
   if(!event.target.closest?.('.ma-home-row-menu,.ma-home-more-btn'))hideHomeRowMenu();
   if(homeHistoryOpen&&!event.target.closest?.('.ma-home-history-pop,.ma-home-hist-btn,.ma-home-row-menu')){homeHistoryOpen=false;renderHomeHistoryPop();}
   if(homeChatMode==='expanded'&&!event.target.closest?.('#ma-home-dock,.dh-footer,.ma-add-menu,.ma-home-row-menu,dialog[open]')){close();}
   return;
  }
  if(!panel.hidden&&document.body.classList.contains('document-home-open')){
   if(event.target.closest?.('#myagent-panel,.dh-footer,.ma-add-menu,dialog[open]'))return;
   close();
  }
 },true);
 function closeAllStreamSources(exceptDrawer){
  if(!panel)return false;
  let closed=false;
  for(const d of panel.querySelectorAll('.ma-insight-sources[data-stream-drawer="1"][open]')){
   if(exceptDrawer&&d===exceptDrawer)continue;
   d.open=false;closed=true;
   const cardEl=d.closest('.mw-stream-item');
   const btnEl=cardEl?.querySelector('.mw-src-chip');
   if(btnEl)btnEl.setAttribute('aria-expanded','false');
  }
  return closed;
 }
 document.addEventListener('keydown',e=>{if(e.key!=='Escape'||e.defaultPrevented)return;if(promptEditing){e.preventDefault();finishPromptEdit();return;}if($('.ma-options')?.open){e.preventDefault();$('.ma-options').open=false;return;}if(closeAllStreamSources()){e.preventDefault();return;}if(!panel.hidden&&document.body.classList.contains('document-home-open')&&!document.querySelector('dialog[open]')){e.preventDefault();close();}});
 document.addEventListener('pointerdown',e=>{if(promptEditing&&!promptBar.contains(e.target))finishPromptEdit();if($('.ma-options')?.open&&!$('.ma-options').contains(e.target))$('.ma-options').open=false;if(panel){for(const d of panel.querySelectorAll('.ma-insight-sources[data-stream-drawer="1"][open]')){const cardEl=d.closest('.mw-stream-item');if(!cardEl||!cardEl.contains(e.target)){d.open=false;const btnEl=cardEl?.querySelector('.mw-src-chip');if(btnEl)btnEl.setAttribute('aria-expanded','false');}}if(!e.target?.closest?.('.ctv2-chip')){for(const c of panel.querySelectorAll('.ctv2-chip.open'))c.classList.remove('open');}}});
 const candidateEditors=new Map();
 let proactiveKey='',proactiveData=null,pendingStaged=new Set(),pendingResearchCards=new Set();
 const STREAM_BADGE_MAP={fact_check:['事实核查','Fact Check','事実確認'],blind_spot:['关键盲区','Blind Spot','重要な盲点'],external_case:['外部案例','External Case','外部事例'],memory_conflict:['历史踩坑','Past Pitfall','過去の教訓'],external:['事实核查','Fact Check','事実確認'],best_practice:['方案对比','Trade-off','案の比較'],gap:['逻辑缺口','Logic Gap','論理の抜け']};
 const BOOKMARKS_KEY='citeside-meeting-bookmarks-v1';
 function semanticBadgeOf(m){const lang=document.documentElement?.lang||(en()?'en':'zh');if(window.ThtProactiveContract?.semanticBadgeOf)return window.ThtProactiveContract.semanticBadgeOf(m,lang);const b=m?.semanticBadge,isObj=!!(b&&typeof b==='object'),kind=(isObj&&b.kind)||m?.cardKind||'';if(!kind||!STREAM_BADGE_MAP[kind])return null;const pair=STREAM_BADGE_MAP[kind];const l=String(lang).toLowerCase();return {kind,label:l.startsWith('en')?((isObj&&b.labelEn)||pair[1]):l.startsWith('ja')?((isObj&&b.labelJa)||pair[2]):((isObj&&b.labelZh)||pair[0])};}
 function readBookmarks(mid){if(!mid)return [];try{const all=JSON.parse(localStorage.getItem(BOOKMARKS_KEY)||'{}');return Array.isArray(all[mid])?all[mid]:[];}catch{return [];}}
 function toggleBookmark(mid,entry){if(!mid||!entry?.id)return false;try{const all=JSON.parse(localStorage.getItem(BOOKMARKS_KEY)||'{}');const cur=Array.isArray(all[mid])?all[mid]:[];const idx=cur.findIndex(x=>x.id===entry.id);let on=false;if(idx>=0){cur.splice(idx,1);}else{cur.unshift({...entry,savedAt:Date.now()});on=true;}all[mid]=cur;localStorage.setItem(BOOKMARKS_KEY,JSON.stringify(all));if(typeof CustomEvent==='function')window.dispatchEvent?.(new CustomEvent('tht-bookmarks-updated',{detail:{meetingId:mid,items:cur}}));return on;}catch{return false;}}
 function researchItemForCard(m){try{const items=window.thtLiveResearch?.data?.()?.items;if(!Array.isArray(items)||!items.length)return null;const norm=s=>String(s||'').replace(/\s+/g,' ').trim().slice(0,48).toLowerCase();const mt=norm(m.title||m.body),mb=norm(m.body);return items.find(i=>{if(i.cardId===m.id||i.sourceCardId===m.id)return true;const it=norm(i.title);if(!it)return false;return (mt&&(it===mt||it.includes(mt.slice(0,18))||mt.includes(it.slice(0,18))))||(mb&&mb.length>=12&&(it.includes(mb.slice(0,18))||mb.includes(it.slice(0,18))));})||null;}catch{return null;}}
 if(typeof window!=='undefined'&&typeof window.addEventListener==='function'){window.addEventListener('tht-live-research-updated',()=>{if(proactiveData){proactiveKey='';renderProactive(proactiveData);}});window.addEventListener('tht-bookmarks-updated',()=>{if(proactiveData){proactiveKey='';renderProactive(proactiveData);}});}
 function meetingStream(){return typeof document!=='undefined'&&document.body?.classList?.contains('meeting-workspace');}
 function streamPlain(text){
  return String(text||'').split('\n').map(line=>line.replace(/^\s*(?:[-*+•]\s+|\d+[.)、]\s*)?/,'').replace(/^\s*#{1,6}\s*/,'').replace(/^(?:会上|动作|建议|Action|Suggestion)\s*[:：]\s*/i,'').replace(/\*\*|__|`/g,'').trim()).filter(Boolean).join(' ');
 }
 function streamText(m){
  const body=streamPlain(m.body),title=streamPlain(m.title);
  if(body&&body.length>=10)return body;
  const norm=t=>t.replace(/[\s，。！？、,.!?:：;；]/g,'').toLowerCase();
  return title&&body&&!norm(body).includes(norm(title))?title.replace(/[。.!?！？:：]+$/,'')+'。'+body:body||title;
 }
 function displayBody(m){
  if(meetingStream())return streamText(m);
  const fmt=window.LiveCardFormat,raw=String(m.body||'');
  if(!fmt)return raw;
  if(['insight','background','verification'].includes(m.kind)&&fmt.formatFinding)return fmt.formatFinding(raw,{kind:m.kind});
  return raw.split('\n').map(line=>line.replace(/^\s*(?:动作|建议|Action|Suggestion)\s*[:：]\s*/i,'')).join('\n');
 }
 function outboundOf(m){
  const d=m&&m.draft&&typeof m.draft==='object'&&!Array.isArray(m.draft)?m.draft:(m&&m.sendDraft&&typeof m.sendDraft==='object'&&!Array.isArray(m.sendDraft)?m.sendDraft:null);
  if(!d||!String(d.description||d.text||'').trim()&&!String(d.assignee||'').trim())return null;
  return d;
 }
 function sendTitle(m,d){
  const title=String(m.title||d.title||'').trim(),who=String(d.assignee||m.recipient||'').trim();
  if(en()){
   if(who&&title&&!title.includes(who))return 'To '+who+': '+title;
   if(who&&!title)return 'To '+who;
   return title||String(m.body||'').split('\n')[0].slice(0,48);
  }
  if(who&&title&&!title.includes(who))return '给「'+who+'」'+title;
  if(who&&!title)return '给「'+who+'」';
  return title||String(m.body||'').split('\n')[0].slice(0,48);
 }
 function senderName(){const n=window.THT_BOOT?.ownerProfile?.displayName;return typeof n==='string'?n.trim():'';}
 const liveSend=(()=>{
  const phase=new Map(),reasons=new Map();let sched=null,painting=false;
  function ensure(){if(sched||!window.LiveCardFormat)return sched;sched=window.LiveCardFormat.createSendScheduler({setTimer:(fn,ms)=>setTimeout(fn,ms),clearTimer:t=>clearTimeout(t),send:(id,payload)=>{
   const result=payload.send?.();
   const ok=()=>{reasons.delete(id);phase.set(id,'sent');paint();};
   if(result&&typeof result.then==='function'){phase.set(id,'inflight');paint();return Promise.resolve(result).then(ok);}
   ok();
  }});return sched;}
  function paint(){if(painting||!proactiveData)return;painting=true;try{proactiveKey='';renderProactive(proactiveData);}finally{painting=false;}}
  function cancelQuiet(){const s=ensure();if(!s)return [];const ids=s.cancelAll();for(const id of ids)phase.delete(id);return ids;}
  function cancelAll(){const ids=cancelQuiet();if(ids.length)paint();return ids;}
  window.addEventListener?.('pagehide',()=>cancelQuiet());
  window.addEventListener?.('beforeunload',()=>cancelQuiet());
  if(typeof document!=='undefined'&&document.addEventListener)document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelQuiet();});
  return {phase,reasons,arm(id,payload){const s=ensure();if(!s)return {status:'idle'};const result=s.arm(id,{...payload,onCancel:()=>{phase.delete(id);payload.onCancel?.();paint();},onFail:(error)=>{phase.delete(id);const msg=String(error&&error.message||'');const unconfirmed=!!(error&&error.uncertain)||/状态未确认/.test(msg);reasons.set(id,error&&error.status===409?(msg||'正在发送，请勿重复点击'):unconfirmed?(msg||'状态未确认'):(msg||'没发出去'));payload.onFail?.(error);paint();}});if(result.status==='armed'&&phase.get(id)!=='sent'&&phase.get(id)!=='inflight'){reasons.delete(id);phase.set(id,'pending');}return result;},undo(id){return ensure()?.undo(id)||{status:'idle'};},cancelAll,cancelQuiet,pendingIds(){return ensure()?.pendingIds()||[];}};
 })();
 window.thtLiveSend=liveSend;
 if(typeof window!=='undefined'&&window.addEventListener)window.addEventListener('message',e=>{
  const d=e&&e.data;
  if(!d||d.type!=='tht-live-send'||!e.source||typeof e.source.postMessage!=='function')return;
  let child=false;try{child=e.source.parent===window;}catch{child=true;}
  if(!child)return;
  let origin='*';
  try{if(location.origin&&e.origin===location.origin)origin=location.origin;}catch{}
  const send=window.thtLiveSend;if(!send||typeof send.arm!=='function')return;
  const reply=msg=>{try{e.source.postMessage(msg,origin);}catch{}};
  if(d.op==='arm'){
   const status=send.arm(d.id,{
    send:()=>new Promise((resolve,reject)=>{
     const timer=setTimeout(()=>reject(Object.assign(Error('状态未确认'),{uncertain:true})),130000);
     const onResult=ev=>{
      const r=ev&&ev.data;
      if(!r||r.type!=='tht-live-send-result'||r.token!==d.token)return;
      clearTimeout(timer);window.removeEventListener('message',onResult);
      if(r.ok)resolve();
      else reject(Object.assign(Error(r.error||'状态未确认'),{status:r.status||0,uncertain:!!r.uncertain||/状态未确认/.test(String(r.error||''))}));
     };
     window.addEventListener('message',onResult);
     reply({type:'tht-live-send',op:'fire',id:d.id,token:d.token});
    }),
    onCancel:()=>reply({type:'tht-live-send',op:'cancel',id:d.id,token:d.token}),
    onFail:error=>reply({type:'tht-live-send',op:'fail',id:d.id,token:d.token,error:error&&error.message||'',status:error&&error.status||0,uncertain:!!(error&&error.uncertain)})
   });
   reply({type:'tht-live-send',op:'armed',id:d.id,token:d.token,status:status&&status.status||'idle'});
  }else if(d.op==='undo'){
   const r=send.undo(d.id);
   reply({type:'tht-live-send',op:r&&r.status==='cancelled'?'cancel':'fail',id:d.id,status:r&&r.status});
  }else if(d.op==='cancelAll'&&typeof send.cancelAll==='function')send.cancelAll();
 });
 const sendUncertain=new Set();
 async function postSend(d,m,draft){
  const cardId=m.cardId||(draft&&draft.cardId)||(/^c-[0-9a-f]{12}$/.test(String(m&&m.id||''))?m.id:'');
  if(!cardId)throw Object.assign(Error(tr('没有卡片编号，没有发出','This card has no id, so it was not sent')),{definite:true});
  draft=draft&&typeof draft==='object'?draft:{};
  const key=d.id+':'+cardId;
  let retry=false;
  if(sendUncertain.has(key)){
   const ask=typeof confirm==='function'?confirm:null;
   if(!ask||!ask(tr('上次没确认发没发出去，确定再发？','The last attempt may already have gone out. Send again?')))
    throw Object.assign(Error(tr('未确认，没有重发','Not sent again')),{uncertain:true,status:409});
   retry=true;
  }
  const links=(Array.isArray(draft.links)?draft.links:[]).filter(Boolean);
  const assigneeId=/^(?:ou_|cli_)[A-Za-z0-9]{1,64}$/.test(String(draft.assigneeId||''))?String(draft.assigneeId):'';
  try{
   await api({id:d.id,cardId,do:'send',confirmed:true,...(retry?{retryConfirmed:true}:{}),draft:{assignee:draft.assignee||'',...(assigneeId?{assigneeId}:{}),due:/^\d{4}-\d{2}-\d{2}$/.test(String(draft.due||''))?String(draft.due):'',description:String(draft.description||draft.text||''),links}},'/meeting-action',{timeoutMs:120000,unconfirmedOnTimeout:true});
   sendUncertain.delete(key);
  }catch(e){
   const aborted=/aborted|timeout|timed out|AbortError|TimeoutError/i.test(String(e&&(e.name||'')+' '+(e.message||'')))||!!(e&&(e.name==='AbortError'||e.name==='TimeoutError'));
   if(e&&(e.uncertain||aborted)){
    sendUncertain.add(key);
    if(aborted&&!/上次发送结果还没确认|核对|状态未确认/.test(String(e.message||'')))e=Object.assign(Error(tr('状态未确认','Status unconfirmed')),{uncertain:true,status:e.status||0});
   }
   throw e;
  }
 }
 function proactiveBody(text,key){
  const box=make('div'),parts=String(text||'').split(/\n### (?:Retrieved sources \(excerpts\)|检索来源（片段）)\s*\n/);
  // The timeline retains the complete published explanation, including long entries.
  box.append(rich(parts[0]));
  if(parts.length>1){const sources=make('details');sources.dataset.key=key+':retrieved';sources.append(make('summary',tr('检索来源','Retrieved sources')),rich(parts.slice(1).join('\n')));box.append(sources);}
  return box;
 }
 function streamBody(text,key,fullText){
  const detail=make('details','','mw-stream-body');detail.dataset.key=key;
  detail.append(make('summary',text,'mw-stream-text'));
  const norm=s=>String(s||'').replace(/[\s#*_`>]/g,'');
  let extra=String(fullText||'').trim();
  if(extra&&text){
   const plainLead=String(text||'').replace(/\*\*|__|`/g,'').trim();
   const stripped=extra.replace(/\*\*|__|`/g,'').trim();
   if(plainLead&&stripped.startsWith(plainLead)){
    extra=stripped.slice(plainLead.length).replace(/^[\s，。！？、,.!?:：;；\-—]+/,'').trim();
   }
  }
  const nt=norm(text),nf=norm(extra);
  if(extra&&nf&&nf!==nt&&!nt.includes(nf))detail.append(rich(extra));
  return detail;
 }
 function nativeCandidateId(n){if(n.id)return 'native:'+n.id;let a=2166136261,b=5381;for(const c of JSON.stringify([n.details||n.text,n.sourceRefs||n.sourceIds||[]])){a=Math.imul(a^c.charCodeAt(0),16777619);b=Math.imul(b,33)^c.charCodeAt(0);}return 'native:'+(a>>>0).toString(16)+(b>>>0).toString(16);}
 function proactiveReference(ref,d){
  const id=typeof ref==='string'?ref:ref?.segId;
  const row=[...(d.session?.transcript||[]),...(d.session?.fullTranscript||[])].find(x=>{const segmentId=x.segId||x.id;return segmentId&&(segmentId===id||d.id+':'+segmentId===id||d.source?.id+':'+segmentId===id);});
  return row||(ref&&typeof ref==='object'&&typeof ref.text==='string'?ref:null);
 }
 // Only transcript rows actually used by cards can change their visible evidence/chart.
 function proactiveEvidence(d){
  const refs=new Set();
  const visit=value=>{if(!value||typeof value!=='object')return;for(const [key,item] of Object.entries(value)){if(['sourceRefs','sourceIds'].includes(key)&&Array.isArray(item))for(const ref of item){const id=typeof ref==='string'?ref:ref?.segId||ref?.id;if(id)refs.add(id);}else if(key==='sourceId'&&typeof item==='string')refs.add(item);else if(item&&typeof item==='object')visit(item);}};
  visit(d.modules);visit(d.session?.nativeInsights);visit(d.session?.factchecks);visit(d.source?.candidateRevisions);visit(d.actionCards);visit(d.session?.actionCards);visit(d.actions?.cards);
  return [...refs].sort().map(id=>[id,proactiveReference(id,d)]);
 }
 function proactivePublished(m){
  const value=m.publishedAt??m.createdAt;
  if(value===null||value===undefined||value==='')return NaN;
  const n=typeof value==='number'?value:Date.parse(value);
  // Publication timestamps are absolute milliseconds, never source offsets.
  return Number.isFinite(n)&&n>1e11?n:NaN;
 }
 function proactiveMoment(m,d){
  const time=window.ThtMeetingTime,start=d.session?.start??d.session?.startTs,base=time?.meetingTimestamp(0,start),published=proactivePublished(m);
  if(Number.isFinite(published)&&Number.isFinite(base))return (published-base)/1000;
  const times=(m.sourceRefs||[]).map(ref=>{
   const row=proactiveReference(ref,d),value=row?.at??row?.atSec??row?.t;
   if(value===null||value===undefined||value==='')return NaN;
   const at=time?.meetingTimestamp(value,start);
   if(Number.isFinite(at)&&Number.isFinite(base))return (at-base)/1000;
   return typeof value==='number'&&value>=0&&value<1e11?value:NaN;
  }).filter(t=>Number.isFinite(t)&&t>=0);
  return times.length?Math.max(...times):null;
 }
 function receiveCandidateRun(job){
  if(!job?.candidateId)return;
  for(const [key,state] of candidateEditors){if(!key.startsWith('run:')||!state.hash||state.hash!==job.candidateHash||state.candidateId!==job.candidateId||!state.contexts.includes(job.contextId))continue;
   if(state.job?.id!==job.id&&state.job?.created&&job.created&&new Date(job.created)<new Date(state.job.created))continue;
   if(state.job?.id===job.id&&['completed','failed','cancelled','interrupted'].includes(state.job.state)&&['queued','running'].includes(job.state))continue;
   state.received=(state.received||0)+1;
   state.job=job;state.error='';state.paint?.();
  }
 }
 function actionCard(card,heading,body,place,m,d,options={}){
  const key='run:'+d.id+':'+m.id,signature=JSON.stringify([m.title,m.body,m.sourceRefs]),previousState=candidateEditors.get(key),state=previousState?.signature===signature?previousState:{signature,candidateId:m.id,contexts:[d.id,d.source?.id].filter(Boolean),loading:true,busy:false,job:null,error:'',hash:null};candidateEditors.set(key,state);
  const trigger=make('button','','ma-action-trigger'),label=make('span'),status=make('small','','ma-action-status'),preview=make('div','','ma-action-preview');
  trigger.type='button';status.setAttribute('role','status');preview.hidden=true;
  if(options.actions){if(options.stream){trigger.append(label);options.actions.prepend?options.actions.prepend(trigger):options.actions.append(trigger);}body.append(status,preview,place);}else{trigger.append(label,status);body.append(trigger,preview);}
  const terminal=['failed','cancelled','interrupted'];let previewId='';
  function paint(){
   const job=state.job,done=job?.state==='completed'&&!!job.artifact?.id;
   if(done){const item={meetingId:d.id,moduleId:'artifact-'+job.artifact.id},receipt=window.thtMeetingCollection?.(item);if(receipt!==undefined)state.adopted=!!receipt?.blockId&&!receipt.undone;resultCollections.set(JSON.stringify([item.meetingId,item.moduleId]),state);}
   card.dataset.runState=done?'completed':job?.state||'ready';trigger.disabled=state.loading||state.busy||state.loaded&&!state.hash||!!job&& !done&&!terminal.includes(job.state);
   label.textContent=options.actions?(done?tr('查看成果','View result'):terminal.includes(job?.state)||state.error?tr('重试生成','Retry generation'):state.busy||job?tr('生成中…','Generating…'):options.stream?tr('替我做','Do it for me'):tr('交给我','Hand to me')):m.title||tr('准备成果','Prepare result');status.textContent=state.error|| (state.loading?tr('正在读取状态…','Loading status…'):done?tr('已完成 · 查看成果','Completed · View result'):terminal.includes(job?.state)?(job.error||tr('未完成','Not completed'))+' · '+tr('点击重试','Retry'):job?job.events?.at(-1)?.message||tr('正在生成…','Generating…'):state.busy?tr('正在提交…','Submitting…'):tr('点击生成','Generate'));
   trigger.setAttribute('aria-expanded',String(!!state.expanded&&done));preview.hidden=!state.expanded||!done;
   if(done&&previewId!==job.artifact.id){preview.replaceChildren();const frame=make('iframe');frame.title=tr('成果预览','Result preview');frame.setAttribute('sandbox','');frame.src=address('/workspace-assistant/artifact')+'&id='+encodeURIComponent(job.artifact.id)+'&format=html';preview.append(frame);previewId=job.artifact.id;}
   place.dataset.candidateId=String(m.id||'');
   place.dataset.meetingId=String(d.id||'');
   const marks=new Set(String(place.className||'').split(/\s+/).filter(Boolean));
   marks.add('ma-insight-place');
   if(state.adopted)marks.add('ma-landed');else marks.delete('ma-landed');
   const className=[...marks].join(' ');if(place.className!==className)place.className=className;
   place.disabled=!!(!done||state.loading||state.busy||state.adopting||state.adopted);
   if(options.actions){body.hidden=!state.job&&!state.error&&!state.busy;place.hidden=!done;place.textContent=state.adopting?tr('正在采纳…','Adding…'):state.adopted?tr('已采纳成果','Result added'):tr('采纳成果','Add result');}
  }
  state.paint=paint;
  trigger.onclick=async()=>{
   if(trigger.disabled)return;
   if(state.job?.state==='completed'&&state.job.artifact?.id){state.expanded=!state.expanded;paint();return;}
   state.busy=true;state.error='';paint();
   try{if(!state.hash){await restore();return;}const result=await api({action:'candidate-run',contextId:d.id,candidateId:m.id,candidateHash:state.hash,model:modelSelect.value,effort:selectedEffort(),lang:en()?'en':'zh',...(terminal.includes(state.job?.state)?{retry:true}:{})});if(!result.job?.id||result.job.candidateHash!==state.hash)throw Error(tr('未收到当前卡片的任务回执，请重试。','No matching card receipt. Please retry.'));state.job=result.job;cardSignal(d.id,m,'dispatch');}
   catch(error){state.error=errorText(error,true);if(error.status===409){state.loaded=false;await restore();}}finally{state.busy=false;paint();}
  };
  const originalPlace=place.onclick;place.onclick=async()=>{
   if(!state.job)return originalPlace?.();if(state.job.state!=='completed'||!state.job.artifact?.id||state.adopting||state.adopted)return;
   state.adopting=true;state.error='';paint();try{const receipt=await window.thtCollectMeetingModule?.({meetingId:d.id,moduleId:'artifact-'+state.job.artifact.id,artifactSelection:{jobId:state.job.id,artifactId:state.job.artifact.id}});if(!receipt?.blockId||receipt.undone)throw Error(tr('未收到保存回执，请打开对应会议后重试。','No saved receipt. Open the matching meeting and retry.'));state.adopted=true;cardSignal(d.id,m,'adopt');resultCollections.set(JSON.stringify([d.id,'artifact-'+state.job.artifact.id]),state);}catch(error){state.error=errorText(error,true);}finally{state.adopting=false;paint();}
  };
  // Restore the durable card binding even when it fell outside recent chat history.
  function restore(){const received=state.received||0;state.fetching=true;state.loading=true;return api(null,'/workspace-assistant?contextId='+encodeURIComponent(d.id)+'&candidateId='+encodeURIComponent(m.id)).then(result=>{state.hash=result.currentCandidateHash||null;if(!state.hash||state.job?.candidateHash!==state.hash||(state.received||0)===received)state.job=result.jobs?.filter(job=>state.hash&&job.candidateHash===state.hash).at(-1)||null;state.loaded=true;state.error=state.hash?'':tr('卡片已更新或不可执行，请刷新会议。','Card changed or unavailable. Refresh the meeting.');}).catch(error=>{state.error=errorText(error,true);}).finally(()=>{state.loading=false;state.fetching=false;state.paint?.();});}
  if(!state.loaded&&!state.fetching)restore();
  paint();
 }
 function proactiveHeading(m,directAction){
  if(directAction&&m.actionText?.trim())return m.actionText.trim();
  const title=String(m.title||'').trim(),body=String(m.body||'').trim();
  const normalized=value=>value.replace(/[\s#*_`>，。！？、,.!?:：;；]/g,'').toLowerCase();
  const t=normalized(title),b=normalized(body);
  // A heading is a scan label, not a second copy of the paragraph. Keep the
  // complete body and evidence untouched, including older persisted cards.
  if(title&&[...title].length<=48&&!(t&&b&&(b.startsWith(t)||t===b)))return title;
  return '';
 }
 // PRD 3.1: a selection edit lands by itself (reversible beside the change); the chat keeps one receipt.
 function rangeReceipt(job){
  const line=make('div','','ma-range-receipt'),frame=document.getElementById('workspace-frame')?.contentWindow||window,key='tht-range-applied',n=job.motherRange.segments?.length||0;
  let applied={};try{applied=JSON.parse(localStorage.getItem(key)||'{}')||{};}catch{}
  const done=r=>{line.append(make('span',n>1?tr('✓ 只改了选中这 '+n+' 处 · ','✓ Edited only these '+n+' places · '):tr('✓ 只改了选中这段 · ','✓ Edited only the selection · ')));const look=make('button',tr('查看','View'));look.type='button';look.onclick=()=>frame.thtRevealBlock?.(r.blockId||job.motherRange.segments?.[0]?.blockId||'');line.append(look);};
  const save=()=>{try{localStorage.setItem(key,JSON.stringify(Object.fromEntries(Object.entries(applied).slice(-50))));}catch{}};
  // Each edit lands once. Whether it already landed is read from the document, not the job's age:
  // a job still pending after a reload applies when its document is open; text that changed meanwhile fails explicitly.
  if(applied[job.id]?.error){line.append(make('span',applied[job.id].error,'ma-muted'));return line;}
  if(applied[job.id]?.undone){rangeUndone(line);return line;}
  if(applied[job.id]){if(applied[job.id].editId)rangeLines.set(applied[job.id].editId,line);done(applied[job.id]);return line;}
   try{const r=frame.thtApplyRangeEdit?.(job.motherRange);if(!r)throw Error(tr('请先打开对应会议文档','Open the matching meeting document first'));applied[job.id]={blockId:r.blockId,...(r.id?{editId:r.id}:{})};save();if(r.id)rangeLines.set(r.id,line);done(r);}
  catch(e){if(frame.thtApplyRangeEdit&&!/打开对应|Open the matching/.test(e.message)){applied[job.id]={error:e.message};save();}line.append(make('span',e.message,'ma-muted'));}
  return line;
 }
 // Undo happens beside the edit in the document; the editor announces it so the receipt stops claiming the edit is there.
 const rangeLines=new Map();
 function rangeUndone(line){line.replaceChildren(make('span',tr('↺ 已撤销，原文已恢复','↺ Undone; original text restored'),'ma-muted'));}
 globalThis.window?.addEventListener?.('tht-range-undone',e=>{
  const id=e.detail?.id,key='tht-range-applied';if(!id)return;let applied={};try{applied=JSON.parse(localStorage.getItem(key)||'{}')||{};}catch{}
  for(const v of Object.values(applied))if(v&&v.editId===id)v.undone=true;try{localStorage.setItem(key,JSON.stringify(applied));}catch{}
  const line=rangeLines.get(id);rangeLines.delete(id);if(line)rangeUndone(line);
 });
 // A whole-block edit the user asked for is reversible, so it lands once without a second confirmation;
 // the receipt then says it is in the document and offers the one-step undo.
 const applyingEdits=new Set();
 function editReceipt(job){
  const line=make('div','','ma-range-receipt'),frame=document.getElementById('workspace-frame')?.contentWindow||window,key='tht-doc-edit-applied';
  let applied={};try{applied=JSON.parse(localStorage.getItem(key)||'{}')||{};}catch{}
  const save=()=>{try{localStorage.setItem(key,JSON.stringify(Object.fromEntries(Object.entries(applied).slice(-50))));}catch{}};
  const show=()=>{const a=applied[job.id];line.replaceChildren();
   if(a?.error){line.append(make('span',a.error,'ma-muted'));return;}
   if(a?.undone){line.append(make('span',tr('↺ 已撤销，原文已恢复','↺ Undone; original text restored'),'ma-muted'));return;}
   const where=job.motherEdit?.placement;line.append(make('span',where==='after'?tr('✓ 已插到选中内容下方 · ','✓ Inserted below selection · '):where==='before'?tr('✓ 已插到选中内容上方 · ','✓ Inserted above selection · '):tr('✓ 已写进文档 · ','✓ Written to document · ')));const undo=make('button',tr('撤销','Undo'));undo.type='button';
   undo.onclick=async()=>{undo.disabled=true;try{if(!await frame.thtUndoDocumentEdit?.(a.revision))throw Error(tr('这处修改已无法撤销，可从版本历史找回','This edit can no longer be undone; use version history'));applied[job.id]={...a,undone:true};save();show();}catch(e){undo.disabled=false;line.append(make('span',' '+e.message,'ma-muted'));}};line.append(undo);};
  if(applied[job.id]){show();return line;}
  if(applyingEdits.has(job.id)){line.append(make('span',tr('正在写进文档…','Writing to document…'),'ma-muted'));return line;}
  if(typeof frame.thtApplyDocumentEdit!=='function'){line.append(make('span',tr('请先打开对应会议文档','Open the matching meeting document first'),'ma-muted'));return line;}
  applyingEdits.add(job.id);line.append(make('span',tr('正在写进文档…','Writing to document…'),'ma-muted'));
  Promise.resolve().then(()=>frame.thtApplyDocumentEdit(job.motherEdit)).then(r=>{applied[job.id]={revision:r?.revision};save();show();},e=>{
   // A different open document or unsaved edits are retried on a later render; anything else is final.
   const message=/Proposal expired/.test(e.message)?tr('这条修改已过期，没有写入；需要的话再让 AI 改一次','This edit expired and was not written; ask again if needed'):e.message;
   if(!/打开|Open|尚未保存|unsaved/.test(e.message)){applied[job.id]={error:message};save();}line.replaceChildren(make('span',message,'ma-muted'));
  }).finally(()=>applyingEdits.delete(job.id));
  return line;
 }
 function distinctProactiveItems(items,revisions={}){
  const result=[],seen=new Map();
  for(const item of new Map(items.map(m=>[m.id,m])).values()){
   if(!item.body&&!item.title)continue;
   // Only identical, unedited observations with identical evidence coalesce.
   // Keep durable modules, actions, diagrams and local revisions independent.
   const refs=(item.sourceRefs||[]).map(r=>typeof r==='string'?r:r?.segId||'');
   const stripAiPrefix=s=>String(s||'').replace(/^(?:AI\s*解读|AI\s*interpretation)[：:]\s*/i,'').trim();
   const eligible=['insight','background','verification'].includes(item.kind)&&!!item.body?.trim()&&!item.edited&&!item.objectId&&!revisions[item.id]&&!item.actionText&&!item.nodes&&!item.thinkingMethod;
   const key=eligible?JSON.stringify([stripAiPrefix(item.details||item.body||''),[...new Set(refs.filter(Boolean))].sort()]):null;
   const previous=key&&seen.get(key);
   if(previous){
    const prevPrefixed=/^(?:AI\s*解读|AI\s*interpretation)[：:]/i.test(String(previous.body||'').trim());
    const curPrefixed=/^(?:AI\s*解读|AI\s*interpretation)[：:]/i.test(String(item.body||'').trim());
    if(prevPrefixed&&!curPrefixed){previous.body=item.body;if(item.title)previous.title=item.title;if(item.details)previous.details=item.details;}
    previous.links=[...new Map([...(previous.links||[]),...(item.links||[])].map(link=>[link.url,link])).values()];
    previous.sources=[...new Map([...(previous.sources||[]),...(item.sources||[])].filter(s=>s&&s.url).map(s=>[s.url,s])).values()];
    continue;
   }
   const copy={...item};result.push(copy);if(key)seen.set(key,copy);
  }
  return result;
 }
 function paintPlace(button,receipt){
  // A valid landing block wins; organization state only adds a hint, never hides the location.
  const done=!!receipt&&!receipt.undone&&(receipt.organization?.state==='done'||!!receipt.blockId);
  if(!done){delete button.dataset.landed;button.classList?.remove('ma-landed');const skip=button.parentElement?.querySelector('.ma-skip');if(skip)skip.hidden=false;button.textContent=receipt?collectionLabel(receipt):tr('写进文档','Write to document');return;}
  button.dataset.landed='true';button.dataset.blockId=receipt.blockId||'';button.classList?.add('ma-landed');const skip=button.parentElement?.querySelector('.ma-skip');if(skip)skip.hidden=true;button.textContent=tr('✓ 已写进文档 · 位置 ›','✓ Written to document · Location ›');
 }
 function revealLanding(meetingId,blockId,candidateId){window.thtRevealDocumentBlock?.({meetingId,blockId,candidateId});}
 function dismissedCandidates(id){try{return new Set(JSON.parse(localStorage.getItem('tht-dismissed:'+id)||'[]'));}catch{return new Set();}}
 // M1-IMPLICIT-SIGNAL：候选卡上的「写进文档 / 复制 / 不用」每点一次记一条事件（app/card-signals.js），不等人点评价。
 function cardSignal(meetingId,m,action){try{api({sessionId:meetingId,cardId:m.id,key:m.key||'',action,source:'workspace',kind:m.kind||'',text:String(m.title||m.body||'').slice(0,120)},'/card-signal').catch(()=>{});}catch{}}
 // 会后问题单（10-24）：卡片在可视区停留 ≥1 秒记一次 shown（采纳率的分母）；同一场同一张卡本页只记一次，重渲染不重复记
 const hiddenTasks=new Set();
 const shownSent=new Set(),shownTimers=new WeakMap();let shownObserver=null;
 function watchShown(card,meetingId,m){if(!card||!meetingId||!m?.id||typeof IntersectionObserver!=='function')return;const k=meetingId+'|'+m.id;if(shownSent.has(k))return;card.dataset.shownKey=k;card._shown={meetingId,m};if(!shownObserver)shownObserver=new IntersectionObserver(es=>{for(const e of es){const el=e.target;if(e.isIntersecting&&e.intersectionRatio>=0.5){if(!shownTimers.has(el))shownTimers.set(el,setTimeout(()=>{shownTimers.delete(el);const key=el.dataset.shownKey;if(!key||shownSent.has(key)||!el.isConnected)return;shownSent.add(key);shownObserver.unobserve(el);cardSignal(el._shown.meetingId,el._shown.m,'shown');},1000));}else{clearTimeout(shownTimers.get(el));shownTimers.delete(el);}}},{threshold:[0,0.5]});shownObserver.observe(card);}
 // 展开只算一次：重渲染恢复 details 也会触发 toggle，靠这里去重。
 const expandSent=new Set();
 function expandSignal(meetingId,m){const k=meetingId+'|'+m.id;if(expandSent.has(k))return;expandSent.add(k);cardSignal(meetingId,m,'expand');}
 function dismissCandidate(id,candidateId,on){const set=dismissedCandidates(id);if(on)set.add(candidateId);else set.delete(candidateId);try{localStorage.setItem('tht-dismissed:'+id,JSON.stringify([...set].slice(-500)));}catch{}}
 // 外部卡的来源行：正文里拼的那行给小窗看，这里换成可点的链接。
 function visibleText(n){return n.foot?String(n.text||'').replace('\n'+n.foot,''):n.text;}
 function sourceLine(m){const urls=(Array.isArray(m.sources)?m.sources:[]).filter(s=>/^https?:\/\//.test(String(s?.url||'')));if(!urls.length)return [];const line=make('p','','ma-card-sources');for(const s of urls){const a=make('a',String(s.name||s.url).slice(0,80));a.href=s.url;a.target='_blank';a.rel='noopener';line.append(a);}const rest=String(m.foot||'').split(' · ').slice(1).join(' · ');if(rest)line.append(make('span',rest));return [line];}
 function maybeStageExternal(d,m){
  if(!d?.id||!m?.id)return;
  if(d.session?.end||d.session?.finalized)return;
  if(m.kind!=='task'&&dismissedCandidates(d.id).has(m.id))return;
  if(!['background','verification','insight','external','plan','map'].includes(m.kind))return;
  if(/名词解释|\bGlossary\b/i.test(String(m.title||'')+' '+String(m.category||'')))return;
  const key=d.id+'\n'+m.id;if(pendingStaged.has(key)||typeof window.thtStagePendingExternal!=='function')return;
  pendingStaged.add(key);
  const actionText=String(m.actionText||'').trim().slice(0,500);
  Promise.resolve(window.thtStagePendingExternal({meetingId:d.id,item:{id:String(m.id).slice(0,200),kind:m.kind,title:String(m.title||'').slice(0,200),body:String(m.body||m.title||'').slice(0,4000),category:String(m.category||'').slice(0,80),sourceLayer:m.sourceLayer||'',...(actionText?{actionText}:{})}})).then(r=>{const reason=r&&r.reason;if(r&&r.staged!==true&&reason!=='exists'&&reason!=='not-external'&&reason!=='deleted'&&reason!=='rejected'&&reason!=='ended'&&reason!=='already-staged')pendingStaged.delete(key);},()=>pendingStaged.delete(key));
 }
 const actionsRead=new Set(),sawLive=new Set(),endedCancel=new Set(),savedActions=new Map(),actionsInflight=new Set(),actionsWanted=new Set(),actionsGen=new Map();
 function dropMeetingActions(id){
  if(!id)return;
  savedActions.delete(id);actionsRead.delete(id);actionsWanted.delete(id);actionsInflight.delete(id);
  actionsGen.set(id,(actionsGen.get(id)||0)+1);
 }
 function scheduleActionsRead(d,endedNow){
  if(!d||!d.id||typeof api!=='function')return;
  if(d.actions||d.actionCards||d.session&&d.session.actionCards)return;
  const ended=endedNow!==undefined?!!endedNow:!!(d.session?.end||d.session?.finalized);
  if(ended&&actionsRead.has(d.id))return;
  if(actionsInflight.has(d.id)){if(!ended)actionsWanted.add(d.id);return;}
  if(ended)actionsRead.add(d.id);
  actionsInflight.add(d.id);
  const id=d.id,gen=actionsGen.get(id)||0;
  Promise.resolve(api(null,'/meeting-actions?id='+encodeURIComponent(id)+'&read=1')).then(j=>{
   if((actionsGen.get(id)||0)!==gen)return;
   actionsInflight.delete(id);
   const follow=!ended&&actionsWanted.delete(id);
   if(j&&j.actions){
    const same=JSON.stringify(savedActions.get(id)??null)===JSON.stringify(j.actions);
    savedActions.set(id,j.actions);
    if(!same&&proactiveData&&proactiveData.id===id){proactiveKey='';renderProactive(Object.assign({},proactiveData,{actions:j.actions}),true);}
   }
   if(follow&&proactiveData&&proactiveData.id===id)scheduleActionsRead({id,session:proactiveData.session},false);
  }).catch(()=>{if((actionsGen.get(id)||0)!==gen)return;actionsInflight.delete(id);actionsRead.delete(id);const follow=actionsWanted.delete(id);if(follow&&proactiveData&&proactiveData.id===id)scheduleActionsRead({id,session:proactiveData.session},false);});
 }
 function renderProactive(d,fromRead){
  if(!d||scopeKey({contextId:d.id})!==currentScope||d.session?.id&&d.session.id!==d.id)return;
  const stream=meetingStream();
  const source=d,incomingActions=!!(d.actions||d.actionCards||d.session&&d.session.actionCards);
  const endedNow=!!(d.session?.end||d.session?.finalized);
  if(proactiveData&&proactiveData.id!==d.id){dropMeetingActions(proactiveData.id);dropMeetingActions(d.id);liveSend.phase.clear();liveSend.reasons.clear();}
  if(d.actions)savedActions.set(d.id,d.actions);
  d=incomingActions||!d.id||!savedActions.has(d.id)?d:Object.assign({},d,{actions:savedActions.get(d.id)});
  proactiveData=d;
  // 只在「本场刚从进行中变成结束」取消一次。取消会同步重绘，必须先换上这场的数据，否则重绘仍看成进行中，把 id 加回 sawLive，会后的发出会被自己取消。
  if(!endedNow)sawLive.add(d.id);
  else if(sawLive.has(d.id)&&!endedCancel.has(d.id)){endedCancel.add(d.id);sawLive.delete(d.id);liveSend.cancelQuiet();}
  if(!fromRead)scheduleActionsRead(source,endedNow);
  const actionStamp=[d.actionCards,d.session&&d.session.actionCards,d.actions&&d.actions.cards].flat().filter(Boolean).map(c=>String(c.id||'')+':'+(c.state||'')).join('|');const key=JSON.stringify([d.id,d.modules,d.session?.nativeInsights,d.session?.factchecks,proactiveEvidence(d),d.session?.start,d.session?.end,d.source?.candidateRevisions,en(),actionStamp,[...liveSend.phase],[...liveSend.reasons]]);if(key===proactiveKey)return;proactiveKey=key;
  const expanded=new Set([...insights.querySelectorAll('details[open]')].map(x=>x.dataset.key));const viewport=window.thtTimeline;viewport?.beforeRender?.();const scroll=feed.scrollTop;insights.replaceChildren();
  const meetingLive=!!(d.session?.start&&!endedNow);
  const items=(d.modules||[]).filter(m=>(['insight','action','task','plan','map'].includes(m.kind)||(m.kind==='note'&&m.edited===false&&m.sourceRefs?.length&&/^AI[ ·草]/.test(m.context||'')))).map(m=>({...m,objectId:m.id}));
  const isGenericTranscriptEcho=n=>stream&&(window.ThtProactiveContract?!window.ThtProactiveContract.shouldShowProactiveCard(n):(!n?.cardKind&&!n?.semanticBadge&&!(Array.isArray(n?.sources)&&n.sources.some(s=>s&&/^https?:\/\//.test(String(s.url||''))))));
  for(const [kind,rows] of [['suggestion',[d.session?.nativeInsights?.suggestion]],['insight',d.session?.nativeInsights?.insights||[]]])for(const n of rows.filter(Boolean)){if(isGenericTranscriptEcho(n))continue;items.push({id:nativeCandidateId(n),key:n.key||'',kind,title:n.title,body:visibleText(n),details:n.details,sources:n.sources,foot:n.foot,cardKind:n.cardKind,semanticBadge:n.semanticBadge,credibility:n.credibility,sourceLayer:n.sourceLayer,createdAt:n.createdAt,publishedAt:n.publishedAt,sourceRefs:n.sourceRefs||n.sourceIds});}
  for(const n of d.session?.nativeInsights?.history||[]){if(isGenericTranscriptEcho(n))continue;items.push({id:nativeCandidateId(n),key:n.key||'',kind:n.kind==='judgment'?'insight':n.kind||'insight',title:n.title,body:visibleText(n),details:n.details,sources:n.sources,foot:n.foot,cardKind:n.cardKind,semanticBadge:n.semanticBadge,credibility:n.credibility,sourceLayer:n.sourceLayer,createdAt:n.createdAt,publishedAt:n.publishedAt,sourceRefs:n.sourceRefs||n.sourceIds});}
  for(const n of (d.session?.factchecks||[]).filter(x=>window.ThtProactiveContract?.shouldShowFactcheck?window.ThtProactiveContract.shouldShowFactcheck(x,stream):((!x.lookupState||x.lookupState==='ready')&&!(stream&&x.channel==='judgment'&&!(x.verify?.sources?.length)))))items.push({id:'fact:'+n.id,title:[n.stale?tr('转写已修订','Transcript revised'):'',n.channel==='judgment'?(n.supersededBy?tr('此前判断（已有更新）','Earlier judgement (updated)'):tr('当前判断','Current judgement')):n.channel==='verification'?tr('事实核查','Fact check'):tr('背景补充','Background'),n.title||n.entity||n.topic].filter(Boolean).join(' · '),kind:n.channel==='verification'?'verification':n.channel==='background'?'background':'insight',details:n.details,body:n.point||n.md||(n.verify?[n.verify.verdict,n.verify.note].filter(Boolean).join(' · '):n.claim),links:n.verify?.sources,sourceRefs:n.sourceRefs,thinkingMethod:n.thinkingMethod,createdAt:n.createdAt,publishedAt:n.publishedAt});
  const seenDelegate=new Set(items.map(m=>m.id));
  for(const c of [d.actionCards,d.session&&d.session.actionCards,d.actions&&d.actions.cards].flat().filter(Boolean)){
   if(!c||seenDelegate.has(c.id)||c.kind!=='delegate'||!/^c-[0-9a-f]{12}$/.test(String(c.id||'')))continue;
   const description=String(c.draft&&(c.draft.description||c.draft.text)||'').trim();if(!description)continue;
   seenDelegate.add(c.id);items.push({id:c.id,cardId:c.id,kind:'task',title:String(c.text||'').trim(),body:description,draft:c.draft,state:c.state});
  }
  // To-dos stay in their source collections and report; never publish them in the feed.
  const feedTodo=m=>m.kind==='task'||stream&&(['action','suggestion'].includes(m.kind)||!!outboundOf(m));
  const streamItems=items.filter(m=>!feedTodo(m));
  const unique=distinctProactiveItems(streamItems,d.source?.candidateRevisions);unique.sort((a,b)=>{const at=proactiveMoment(a,d),bt=proactiveMoment(b,d);return at===null?(bt===null?0:1):bt===null?-1:at-bt||String(a.id||'').localeCompare(String(b.id||''));});
  for(const original of unique){
   const saved=d.source?.candidateRevisions?.[original.id],m=window.MeetingGraph.effectiveCandidate(original,d.source?.candidateRevisions,d.session?.transcript||[]);
   if(feedTodo(m))continue;
   // 11-02 Aaron：文档板内容会中只进文档待处理，不弹卡；当场只弹核实过的外部卡。
   if(meetingLive&&original.objectId){maybeStageExternal(d,m);continue;}
   if(!m.body&&!m.title)continue;const directAction=!!m.objectId&&(['action','task'].includes(m.kind)||!!m.actionText?.trim());const draft=outboundOf(m);const cardId=m.cardId||draft&&draft.cardId||(/^c-[0-9a-f]{12}$/.test(String(m.id||''))?m.id:'');const phaseKey=d.id+':'+(cardId||m.id);if(!liveSend.phase.has(phaseKey)){if(m.state==='sent'||m.state==='claimed')liveSend.phase.set(phaseKey,'sent');else if(m.state==='dismissed')liveSend.phase.set(phaseKey,'dismissed');}const phaseNow=liveSend.phase.get(phaseKey)||'';const longReport=m.kind==='insight'&&(/\n### (?:Retrieved sources|检索来源)/.test(String(m.body||''))||String(m.body||'').trim().length>240);const headText=proactiveHeading(m,directAction),shownBody=displayBody(m),normHead=s=>String(s||'').replace(/[\s#*_`>，。！？、,.!?:：;；]/g,'').toLowerCase(),titleInBody=!!normHead(m.title)&&normHead(shownBody).includes(normHead(m.title)),headInBody=!!normHead(headText)&&normHead(shownBody).includes(normHead(headText)),blankFinding=!!draft||m.kind==='task'||(m.kind==='insight'&&!String(m.id||'').startsWith('fact:')&&!directAction&&!longReport&&!!normHead(shownBody)&&(titleInBody||headInBody));const card=make('article','','ma-insight'),heading=make('strong',stream||blankFinding?'':headText),body=make('div');card.dataset.candidateId=String(m.id||'');body.dataset.key=m.id;if(stream){card.classList?.add('mw-stream-item');card.setAttribute('tabindex','0');}
   const originalBody=stream?streamBody(shownBody,m.id,m.details):proactiveBody(displayBody(m),m.id);originalBody.hidden=!!draft;body.append(originalBody);
   if(!stream&&m.thinkingMethod?.tool==='six-hats'&&m.thinkingMethod.contribution){const method=make('details','','ma-thinking-method');method.dataset.key=m.id+':method';method.append(make('summary',en()?m.thinkingMethod.labelEn:m.thinkingMethod.label),make('p',m.thinkingMethod.object),make('p',m.thinkingMethod.contribution));body.append(method);}
   const category=m.kind==='action'?['action','建议行动','Suggested action','M13 2 4 14h7l-1 8 10-13h-7z']:m.kind==='task'?['task','建议行动','Suggested action','M5 4h14v16H5z M8 12l3 3 5-6']:m.kind==='verification'?['verification','事实核查','Fact check','M9 11l2 2 4-4 M12 2l8 4v6c0 5-8 10-8 10S4 17 4 12V6z']:m.kind==='background'?['background','背景补充','Background','M12 11v6 M12 7h.01 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0']:m.kind==='insight'?['insight','发现','Finding','M9 18h6 M10 21h4 M8 14a7 7 0 1 1 8 0l-1 3H9z']:m.kind==='suggestion'?['suggestion','建议行动','Suggested action','M12 3v12 M7 10l5 5 5-5 M5 21h14']:['note','会议提示','Meeting note','M5 3h14v18H5z M8 8h8 M8 12h8'];
   if(stream&&['insight','background','verification'].includes(m.kind)){category[1]='发现';category[2]='Finding';}
   if(draft||['action','task','suggestion'].includes(m.kind)){category[1]='待办';category[2]='To-do';}
   if(directAction)category[3]='M13 2 4 14h7l-1 8 10-13h-7z';
   card.dataset.kind=category[0];{const at=proactiveMoment(m,d),published=proactivePublished(m),start=d.session?.start??d.session?.startTs;
    if(at!==null)card.dataset.t=String(at);
    const clock=Number.isFinite(published)?window.ThtMeetingTime.clockTime(published):at!==null?window.ThtMeetingTime.meetingClock(at,start):'';
    if(clock){const stamp=make('time',clock,'ma-insight-time');
    stamp.setAttribute('aria-label',Number.isFinite(published)?tr('发布时间','Published time'):tr('来源时间','Source time'));
    if(Number.isFinite(published)){stamp.setAttribute('datetime',new Date(published).toISOString());card.dataset.publishedAt=String(published);}
    heading.append(stamp);}
   }watchShown(card,d.id,m);const icon=make('span','','ma-insight-icon');icon.setAttribute('aria-hidden','true');const shownClock=[...(heading.children||[])].map(n=>String(n.textContent||n.text||'')).find(t=>/^(\d{1,2}:\d{2})/.test(t))||'',typeClock=/^(\d{1,2}:\d{2})/.exec(shownClock),type=make('span',tr(category[1],category[2]),'ma-insight-type'),mark=draft&&!stream?'bolt':['insight','background','verification'].includes(category[0])?'find':['action','task','suggestion'].includes(category[0])?'check':'';if(mark&&type.dataset)type.dataset.mark=mark;icon.innerHTML=mark==='find'?'<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M12 3l1.9 5.6L19.5 11l-5.6 2.4L12 19l-1.9-5.6L4.5 11l5.6-2.4z"/></svg>':mark==='bolt'?'<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M13.4 2.5 5 13.6c-.3.4 0 1 .5 1H11l-1.2 6.6c-.1.6.7 1 1.1.5L19 10.4c.3-.4 0-1-.5-1H13l1.5-6.3c.2-.6-.7-1-1.1-.6z"/></svg>':mark==='check'?'<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 12.3l2.8 2.8L16 9.6"/></svg>':'<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="'+category[3]+'"/></svg>';if(!stream&&typeClock&&typeof type.append==='function')type.append(make('span',' · '+typeClock[1],'mw-type-clock'));const sem=semanticBadgeOf(m);const semTag=sem?make('span',sem.label,'mw-sem-badge'):null;if(semTag&&semTag.dataset)semTag.dataset.cardKind=sem.kind;const toneText=String(shownBody||'').replace(/^\s*(?:AI\s*解读|AI\s*interpretation)\s*[：:]\s*/i,'').trim();const semTone=window.ThtProactiveContract?.semanticToneOf?window.ThtProactiveContract.semanticToneOf(sem,toneText):(/^(?:核实一致|已核实)[：:]/.test(toneText)?'ok':(sem?.kind==='gap'||sem?.kind==='fact_check'||sem?.kind==='blind_spot'||/^(?:纠偏[：:]|实际是)|而非会上说的/.test(toneText))?'fix':(sem?.kind==='best_practice'||sem?.kind==='external_case'||sem?.kind==='memory_conflict')?'cmp':'add');if(card.dataset)card.dataset.semTone=semTone;if(semTag&&semTag.dataset)semTag.dataset.semTone=semTone;const leadEls=semTag?[icon,semTag]:[icon,type];heading.prepend?heading.prepend(...leadEls):heading.append(...leadEls);
   let hasTopRightSource=false;
   if(stream){
    let diffSaid=typeof m.said==='string'?m.said.trim():'',diffFact=typeof m.fact==='string'?m.fact.trim():'';
    if((!diffSaid||!diffFact)&&semTone==='fix'){
     const rx=/实际[是为][^，。；]{0,28}?(\d+(?:\.\d+)?(?:\s*\/\s*\d+(?:\.\d+)?)?\s*(?:%|亿|万|倍|年|元)?)[^。；]{0,24}?而非(?:会上说的)?[^，。；]{0,24}?(\d+(?:\.\d+)?(?:\s*\/\s*\d+(?:\.\d+)?)?\s*(?:%|亿|万|倍|年|元)?)/;
     const mt=rx.exec(toneText);
     if(mt&&mt[1]!==mt[2]){
      const fVal=mt[1].trim(),sVal=mt[2].trim();
      const isYr=v=>/年$/.test(v)||/^(?:19|20)\d{2}$/.test(v);
      const unitOf=v=>(v.match(/(%|亿|万|倍|年|元|\/)/)||[''])[0];
      // Never compare incompatible units like a percentage/ratio "70" vs a year "2016年"
      if(isYr(fVal)===isYr(sVal)&&(!unitOf(fVal)||!unitOf(sVal)||unitOf(fVal)===unitOf(sVal))){
       diffFact=fVal;diffSaid=sVal;
      }
     }
    }
    if(diffSaid&&diffFact){
     const diffEl=make('div','','ctv2-diff');
     diffEl.append(make('s',diffSaid),make('i','→'),make('em',diffFact));
     body.prepend(diffEl);
    }
    const firstSrc=[...(Array.isArray(m.sources)?m.sources:[]),...(Array.isArray(m.links)?m.links:[])].find(s=>s&&s.url);
    const evRaw=String(m.evidence||m.evidenceTier||'').toLowerCase();
    const evDot=evRaw==='quoted'?'full':(evRaw==='sourced'||evRaw==='source'||evRaw==='memory'||firstSrc)?'half':evRaw==='model'?'none':'';
    const evDesc=evRaw==='quoted'?tr('有原文 · 引文已逐字核对','Quoted · verbatim verified'):evRaw==='memory'?tr('来自你的会议记忆','From your meeting memory'):evDot==='half'?tr('有来源 · 未逐字核对','Sourced · not verbatim'):evRaw==='model'?tr('模型判断 · 未联网核实','Model estimate · unverified'):'';
    let srcLabel='';
    if(firstSrc){try{
     const u=new URL(firstSrc.url),host=u.hostname.replace(/^www\./,'').toLowerCase();
     const rawName=String(firstSrc.name||firstSrc.title||host).split(/\s*[-–|·]\s*/)[0].trim();
     const plat=host.includes('wikipedia.org')?tr('维基百科','Wikipedia')
      :host.includes('baike.baidu.com')?tr('百度百科','Baidu Baike')
      :host.includes('zhihu.com')?tr('知乎','Zhihu')
      :'';
     if(plat){
      srcLabel=(rawName&&!rawName.includes(plat)?(plat+' · '+rawName):plat).slice(0,22);
     }else{
      srcLabel=(rawName||host).slice(0,18);
     }
    }catch{}}
     const topicLabel=String(m.topic||srcLabel||'').slice(0,22);
     if(topicLabel||srcLabel){
      const chip=make('span','','ctv2-chip');
      const btn=make('button','','');btn.type='button';
      if(evDot)btn.append(make('span','','ctv2-ed '+evDot));
      if(topicLabel)btn.append(document.createTextNode(topicLabel));
      if(topicLabel&&srcLabel&&srcLabel!==topicLabel){btn.append(make('span','·','ctv2-sep'),make('span',srcLabel,'ctv2-sr'));}
      if(srcLabel)hasTopRightSource=true;
      btn.onclick=ev=>{ev.stopPropagation();const srcToggle=card.querySelector('.mw-src-chip');if(srcToggle)srcToggle.click();};
      chip.append(btn);
      heading.append(chip);
     }
    }
    if(stream)icon.innerHTML=mark==='find'?'<svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 2l1.8 6.2L18 10l-6.2 1.8L10 18l-1.8-6.2L2 10l6.2-1.8z"/></svg>':'<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="10" cy="10" r="7.5"/><path d="M6.8 10.2l2.2 2.2 4.2-4.4"/></svg>';
    if(!stream&&m.chart&&window.MeetingGraph){try{body.append(window.MeetingGraph.renderChart(m.chart,document));}catch{}}
    // Relationship data may remain in the draft; live cards show the explanation only.
    const sources=make('details','','ma-insight-sources');sources.dataset.key=m.id+':sources';if(stream&&sources.dataset)sources.dataset.streamDrawer='1';sources.append(make('summary',tr('来源','Sources')));let sourceCount=0;
    if(stream){
     const drawerHead=make('div','','mw-src-drawer-head');
     drawerHead.append(make('span',tr('来源引用','Sources'),'mw-src-drawer-title'));
     const collapseBtn=make('button',tr('收起','Collapse'),'mw-src-collapse');collapseBtn.type='button';
     collapseBtn.onclick=ev=>{ev.stopPropagation();sources.open=false;const chipBtn=card.querySelector('.mw-src-chip');if(chipBtn)chipBtn.setAttribute('aria-expanded','false');};
     drawerHead.append(collapseBtn);
     sources.append(drawerHead);
    }
    if(m.credibility?.level){const cred=make('div','','mw-cred-row');const badge=make('span',(m.credibility.level==='verified'||m.credibility.level==='证实'?tr('可信度：证实','Verified'):tr('可信度：','Confidence: ')+m.credibility.level),'mw-cred-pill');if(badge.dataset)badge.dataset.level=m.credibility.level==='verified'||m.credibility.level==='证实'?'ok':'mid';cred.append(badge);if(m.credibility.note)cred.append(make('span',String(m.credibility.note),'mw-cred-note'));sources.append(cred);}
    const seenSourceUrls=new Set();
    for(const source of [...(Array.isArray(m.sources)?m.sources:[]),...(Array.isArray(m.links)?m.links:[])]){if(!source?.url)continue;try{const url=new URL(source.url);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||seenSourceUrls.has(url.href))continue;seenSourceUrls.add(url.href);const a=make('a',(source.title||source.name||url.hostname)+(stream?' ↗':''),'mw-source-link');a.href=url.href;a.target='_blank';a.rel='noopener noreferrer';sources.append(a);const host=make('span',url.hostname.replace(/^www\./,''),'mw-source-host');sources.append(host);if(source.quote){sources.append(make('blockquote','「'+String(source.quote).slice(0,240)+'」','mw-source-quote'));}sourceCount++;}catch{}}
    if(!seenSourceUrls.size){
     for(const ref of m.sourceRefs||[]){const segment=proactiveReference(ref,d),t=segment?.at??segment?.atSec??segment?.t,start=d.session?.start??d.session?.startTs,time=segment?window.ThtMeetingTime.meetingClock(t,start):'',p=make('p',segment?[time,segment.speaker,segment.text].filter(Boolean).join(' · '):tr('引用原文暂未载入：','Source excerpt not loaded: '));
      // Keep the original source position separate from the wall-clock presentation.
      const at=(typeof t==='number'||typeof t==='string'&&t.trim())?(window.ThtMeetingTime.meetingTimestamp(t,start)-window.ThtMeetingTime.meetingTimestamp(0,start))/1000:NaN;
      if(Number.isFinite(at)&&at>=0)p.dataset.sourceAt=String(at);sources.append(p);sourceCount++;
     }
    }
    if(sourceCount&&!stream)body.append(sources);
   if(draft&&['pending','inflight','sent','dismissed'].includes(phaseNow)){
    const gone=phaseNow==='dismissed',complete=phaseNow==='pending'||phaseNow==='sent',row=make('div','','mw-gist'+(complete||gone?' mw-done-line':'')+(gone?' mw-unused':''));
    row.dataset.candidateId=String(m.id||'');if(card.dataset.t!==undefined)row.dataset.t=card.dataset.t;
    const mark=make('span',complete?'✓':'',complete?'mw-done-mark':'mw-send-pending');
    row.append(mark,make('span',gone?sendTitle(m,draft)+tr(' · 不用了',' · Not needed'):(complete?tr('已完成 · ','Done · '):tr('正在发出 · ','Sending · '))+sendTitle(m,draft),'mw-done-title'));
    if(phaseNow==='pending'||gone){const undo=make('button',gone?tr('恢复','Restore'):tr('撤销','Undo'),'mw-undo-send');undo.type='button';undo.onclick=async()=>{
     if(!gone){liveSend.undo(phaseKey);return;}
     undo.disabled=true;try{
      if(cardId){const r=await api({id:d.id,cardId,do:'restore'},'/meeting-action');if(r?.ok===false)throw Error(r.error||'restore');}
      liveSend.phase.set(phaseKey,'');dismissCandidate(d.id,m.id,false);m.state='';original.state='';proactiveKey='';renderProactive(proactiveData);
     }catch(error){row.append(make('small',errorText(error,true),'mw-send-reason'));}finally{undo.disabled=false;}
    };row.append(undo);}
    insights.append(row);continue;
   }
   if(draft&&phaseNow!=='sent'){
    const title=sendTitle(m,draft),head=make('div','','mw-send-head'),h=make(stream?'p':'h4',title,'mw-send-title'),bar=make('span','','mw-send-actions');
    if(phaseNow==='pending'){const undo=make('button',tr('撤销','Undo'),'mw-undo-send');undo.type='button';undo.onclick=()=>liveSend.undo(phaseKey);bar.append(undo);}
    else if(phaseNow!=='inflight'){
     const drop=make('button',tr('不用','Skip'),'mw-drop');drop.type='button';drop.onclick=async()=>{drop.disabled=true;try{if(cardId){const r=await api({id:d.id,cardId,do:'dismiss'},'/meeting-action');if(r?.ok===false)throw Error(r.error||'dismiss');}liveSend.phase.set(phaseKey,'dismissed');proactiveKey='';renderProactive(proactiveData);}catch(error){card.append(make('small',errorText(error,true),'mw-send-reason'));}finally{drop.disabled=false;}};
     bar.append(drop);
     if(cardId){const go=make('button',tr('发出','Send'),'mw-send');go.type='button';go.onclick=()=>{if(liveSend.phase.get(phaseKey))return;liveSend.arm(phaseKey,{send:()=>postSend(d,m,draft)});proactiveKey='';renderProactive(proactiveData);};bar.append(go);}
    }
    head.append(h,bar);
    const line=make('p','','mw-draft-line'),desc=(window.LiveCardFormat?.stripLead(String(draft.description||draft.text||''))||String(draft.description||draft.text||'')).trim();
    const textNode=s=>typeof document!=='undefined'&&document.createTextNode?document.createTextNode(s):make('span',s);
    line.append(textNode(tr('原文：','Original: ')+desc+(desc?' ':'') ));
    const link=window.LiveCardFormat?.shareableContextLink(draft.contextLink)||window.LiveCardFormat?.shareableContextLink((Array.isArray(draft.links)?draft.links:[])[0])||'';
    if(link){const a=make('a',tr('上下文背景','Context'),'mw-context');a.href=link;a.target='_blank';a.rel='noopener noreferrer';if(stream)bar.append(a);else{line.append(a);line.append(textNode(' '));}}
    line.append(textNode(window.LiveCardFormat?.agentLine(senderName(),en()?'en':undefined)||(en()?'(sent by agent)':'（agent 代发送）')));
    if(stream){h.textContent=streamText({title,body:desc});h.className='mw-send-title mw-stream-text';line.hidden=true;}
    body.append(head,line);
    const reason=liveSend.reasons.get(phaseKey);if(reason)body.append(make('p',String(reason),'mw-send-reason'));
   }
   const editorKey='candidate:'+d.id+':'+m.id,state=candidateEditors.get(editorKey)||{comment:'',open:false,busy:false,error:''};candidateEditors.set(editorKey,state);
   const editor=make('div','','ma-candidate-editor');editor.hidden=!state.open;

   const notice=make('small',state.error|| (saved?.stale?tr('基稿已更新，显示新内容；之前的修订保留在下方。','Source draft updated; showing current content. Previous revisions remain below.'):state.busy?tr('正在修订，原稿保留中…','Revising; original preserved…'):tr('仅修改这份候选，选入前不改文档。','Only this candidate changes; your document stays intact.')),'ma-muted');notice.setAttribute('role','status');
   const submit=make('button',tr('修订候选','Revise candidate'));submit.type='button';submit.disabled=state.busy;
   const cancel=make('button',state.busy?tr('停止','Stop'):tr('收起','Collapse'));cancel.type='button';
   cancel.onclick=()=>{if(state.busy){state.cancelRequested=true;if(state.jobId)api({id:d.id,action:'cancel',jobId:state.jobId},'/meeting-board').catch(e=>{notice.textContent=e.message;});}else {if(candidateTarget?.key===editorKey)endCandidateComment();state.open=false;editor.hidden=true;}};
   submit.onclick=async()=>{
    if(state.busy||candidateTarget?.key!==editorKey||uploading||!input.value.trim())return;const snapshot=JSON.parse(JSON.stringify(composer()));state.comment=snapshot.text;persist();state.cancelRequested=false;state.busy=true;resizeComposer();state.error='';submit.disabled=true;notice.textContent=tr('正在修订，原稿保留中…','Revising; original preserved…');cancel.textContent=tr('停止','Stop');
    try{
     const result=await api({id:d.id,action:'candidate-comment',candidateId:m.id,candidateRevision:saved?.revision||0,candidateBody:m.body||'',comment:snapshot.text,nodeId:state.nodeId||'',model:snapshot.model,effort:snapshot.effort,materialIds:snapshot.materials.map(m=>m.id),lang:en()?'en':'zh',requestId:crypto.randomUUID()},'/meeting-board');state.jobId=result.job.id;if(state.cancelRequested)await api({id:d.id,action:'cancel',jobId:state.jobId},'/meeting-board');
     for(let i=0;i<200;i++){
      const response=await fetch(address('/meeting-board')+'&id='+encodeURIComponent(d.id),{headers:{'x-tht-token':auth()}});if(!response.ok)throw Error(tr('无法读取修订进度，原稿已保留。','Unable to read revision status; original preserved.'));const next=await response.json(),job=(next.jobs||[]).find(j=>j.id===state.jobId);
      if(job?.state==='completed'){state.comment='';state.open=false;state.busy=false;if(candidateTarget?.key===editorKey&&JSON.stringify(composer())===JSON.stringify(snapshot)){endCandidateComment();delete drafts[editorKey];persist();}else if(candidateTarget?.key===editorKey){state.open=true;persist();}if(proactiveData?.id===d.id){proactiveKey='';renderProactive({...proactiveData,source:next.source});}return;}
      if(job&&['failed','cancelled','interrupted'].includes(job.state))throw Error(job.error||tr('已停止，原稿已保留。','Stopped; original preserved.'));
      await new Promise(resolve=>setTimeout(resolve,1000));
     }
     throw Error(tr('修订仍在后台进行，可稍后查看。','Revision is still running; check back shortly.'));
    }catch(e){state.error=e.message;notice.textContent=e.message;}finally{state.busy=false;submit.disabled=false;cancel.textContent=tr('收起','Collapse');if(candidateTarget?.key===editorKey)resizeComposer();}
   };
   if(candidateTarget?.key===editorKey){candidateTarget.close=()=>{editor.hidden=true;};candidateTarget.submit=()=>submit.onclick();}
   if(m.nodes?.length){const scope=make('select');scope.setAttribute('aria-label',tr('修改范围','Edit scope'));scope.disabled=state.busy;const all=make('option',tr('整份候选','Whole candidate'));all.value='';scope.append(all);for(const node of m.nodes){const option=make('option',tr('仅节点：','Only node: ')+node.label);option.value=node.id;scope.append(option);}scope.value=state.nodeId||'';scope.onchange=()=>{state.nodeId=scope.value;};editor.append(scope);}
   editor.append(cancel,notice);
   if(saved?.comments?.length){const history=make('details');history.append(make('summary',tr('修改意见与原稿','Comments and original')));for(const c of saved.comments)history.append(make('p',c.text));for(const version of [...(saved.versions||[])].reverse()){
     history.append(make('strong',tr('版本 ','Revision ')+version.revision),rich(version.body));if(version.chart){try{history.append(window.MeetingGraph.renderChart(version.chart,document));}catch{}}if(version.nodes?.length){try{history.append(window.MeetingGraph.render({nodes:version.nodes,edges:version.edges||[]},document));}catch{}}const restore=make('button',tr('恢复这个版本','Restore this version'));restore.type='button';restore.disabled=state.busy||saved.stale;
     restore.onclick=async()=>{if(state.busy)return;state.busy=true;restore.disabled=true;try{await api({id:d.id,action:'candidate-restore',candidateId:m.id,candidateRevision:saved.revision,candidateBody:m.body||'',targetRevision:version.revision},'/meeting-board');const response=await fetch(address('/meeting-board')+'&id='+encodeURIComponent(d.id),{headers:{'x-tht-token':auth()}});if(!response.ok)throw Error(tr('无法读取恢复结果','Unable to read restored version'));const next=await response.json();state.busy=false;state.error='';if(proactiveData?.id===d.id){proactiveKey='';renderProactive({...proactiveData,source:next.source});}}catch(e){state.error=e.message;notice.textContent=e.message;}finally{state.busy=false;restore.disabled=false;}};history.append(restore);
    }editor.append(history);}
   const ask=make('button',tr('修改这份候选','Revise this candidate'));ask.type='button';ask.onclick=()=>{beginCandidateComment({key:editorKey,title:m.title||tr('本条候选','This candidate'),state,close:()=>{editor.hidden=true;},submit:()=>submit.onclick()});editor.hidden=false;};
   const see=make('button',m.nodes?.length?tr('查看并修改图稿','View and edit diagram'):tr('查看会议','Open meeting'));see.type='button';see.onclick=()=>openMeeting(d.id,0,m.objectId||(m.nodes?.length?m.id:''));const actions=make('div','','ma-insight-actions');const skip=make('button',tr('不记这条','Dismiss'),'ma-skip');skip.type='button';skip.onclick=async()=>{if(m.kind==='task'){hiddenTasks.add(d.id+':'+m.id);cardSignal(d.id,m,'dismiss');proactiveKey='';renderProactive(proactiveData);return;}const once=()=>Promise.resolve(typeof window.thtRejectPendingExternal==='function'?window.thtRejectPendingExternal({meetingId:d.id,candidateId:m.id}):{rejected:false});let result=null;try{result=await once();}catch{result=null;}if(!result||result.rejected!==true){try{result=await once();}catch{result=null;}}if(!result||result.rejected!==true){card.append(make('p',tr('没能标成不采纳，请再试。','Could not dismiss this. Try again.'),'ma-dismiss-error'));return;}cardSignal(d.id,m,'dismiss');dismissCandidate(d.id,m.id,true);proactiveKey='';renderProactive(proactiveData);};const copy=make('button',tr('复制','Copy'));copy.type='button';copy.onclick=async()=>{cardSignal(d.id,m,'copy');try{await navigator.clipboard.writeText(m.body||m.title||'');copy.textContent=tr('已复制','Copied');}catch{copy.textContent=tr('复制失败','Copy failed');}};
   if(stream&&sourceCount>0){
    const srcBtn=make('button','','mw-src-chip');srcBtn.type='button';srcBtn.innerHTML='<span class="mw-src-dot" aria-hidden="true"></span><span class="mw-src-text">'+tr(sourceCount+' 个来源',sourceCount+' sources')+'</span><span class="mw-src-chev" aria-hidden="true">▾</span>';
    srcBtn.setAttribute('aria-expanded','false');
    srcBtn.onclick=ev=>{ev.stopPropagation();const willOpen=!sources.open;closeAllStreamSources(willOpen?sources:null);sources.open=willOpen;srcBtn.setAttribute('aria-expanded',String(willOpen));};
    actions.append(srcBtn);
   }
   if(!draft&&(!stream||category[1]==='待办'))actions.append(skip);
   if(stream&&['insight','background','verification'].includes(m.kind)){
    const matchedLr=researchItemForCard(m);
    const pendingKey=d.id+':'+m.id;
    if(matchedLr)pendingResearchCards.delete(pendingKey);
    const isPending=pendingResearchCards.has(pendingKey);
    const isRun=isPending||(matchedLr&&['running','queued'].includes(matchedLr.state));
    const isDone=!isPending&&matchedLr&&matchedLr.state==='done'&&(matchedLr.conclusion||matchedLr.subs?.some(s=>s.section));
    const isInterrupted=!isPending&&matchedLr&&matchedLr.state==='interrupted';
    const isFailed=!isPending&&matchedLr&&(matchedLr.state==='failed'||matchedLr.state==='interrupted'||(matchedLr.state==='partial'&&!(matchedLr.conclusion||matchedLr.subs?.some(s=>s.section))));
    const postCardFeedback=(action)=>{
     try{
      const tok=auth();
      fetch(address('/card-feedback'),{method:'POST',headers:{'Content-Type':'application/json',...(tok?{'x-tht-token':tok}:{})},body:JSON.stringify({sessionId:d.id,cardId:m.id||'',cardKind:semanticBadgeOf(m)?.kind||m.cardKind||'unknown',uiLang:(document.documentElement.lang||'zh').slice(0,2),title:m.title||'',text:shownBody.slice(0,280),action})}).catch(()=>{});
     }catch{}
    };
    const semKind=semanticBadgeOf(m)?.kind||m.cardKind||'';
    const contract=window.ThtProactiveContract;
    const isPro=contract?.isResearchProAccount?contract.isResearchProAccount(window.THT_BOOT||{}):true;
    const uiLangNow=String(document.documentElement.lang||'zh').slice(0,2);
    const verifiedCount=(Array.isArray(d?.items)?d.items:[]).filter(x=>x&&(x.cardKind==='fact_check'||semanticBadgeOf(x)?.kind==='fact_check'||(Array.isArray(x.sources)&&x.sources.length>0))).length;
    const showPaywall=(hostCard)=>{
     if(!hostCard)return;
     const existing=hostCard.querySelector('.mw-pro-paywall');if(existing){existing.remove();return;}
     const masBuild=!!(window.CITESIDE_MAS||window.THT_BOOT?.masBuild);
     const spec=contract?.researchPaywallSpec
      ? contract.researchPaywallSpec({langOrEn:uiLangNow,verifiedCount,masBuild})
      : {valueLine:tr('本场已为你核实 '+verifiedCount+' 处','Verified '+verifiedCount+' items this meeting'),reassureLine:contract?.paywallReassureText?.(uiLangNow)||tr('你的历史会议纪要与笔记永远可读、可随时导出。','Your past meeting notes always stay readable and exportable.'),masOnly:masBuild,masHint:tr('在 citeside.com 管理账号','Manage account at citeside.com'),ctaLabel:tr('升级 Pro','Upgrade to Pro'),upgradeHref:'account.html?view=plans'};
     const openPlans=()=>{fetch('/account/open-plans',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).then(r=>{if(!r.ok)window.open(spec.upgradeHref,'_blank','noopener,noreferrer');}).catch(()=>window.open(spec.upgradeHref,'_blank','noopener,noreferrer'));};
     let box;
     if(contract?.buildBorderlessPaywall){
      box=contract.buildBorderlessPaywall(document,spec,{onUpgrade:openPlans});
     }else{
      box=make('div','','mw-pro-paywall');box.setAttribute('role','region');
      box.append(make('div',spec.valueLine,'mw-pro-paywall-val'));
      const reassure=make('div','','mw-pro-paywall-reassure'),dot=make('span','','mw-pro-paywall-reassure-dot');dot.setAttribute('aria-hidden','true');
      reassure.append(dot,make('span',spec.reassureLine||''));box.append(reassure);
      if(spec.masOnly){
       box.append(make('span',spec.masHint,'mw-pro-paywall-mas'));
      }else{
       const cta=document.createElement('a');cta.className='mw-pro-paywall-cta';cta.href=spec.upgradeHref;cta.target='_blank';cta.rel='noopener noreferrer';cta.textContent=spec.ctaLabel;
       cta.onclick=(ev)=>{ev.preventDefault();openPlans();};
       box.append(cta);
      }
     }
     hostCard.append(box);
    };
    const showDeepBtn=isRun||isDone||isFailed||(contract?.shouldShowDeepResearch?contract.shouldShowDeepResearch(semKind,sourceCount>0):['blind_spot','external_case','memory_conflict','best_practice','gap'].includes(semKind));
    if(showDeepBtn){
     const btnState=isPending?'pending':isRun?'running':isDone?'done':isInterrupted?'interrupted':isFailed?'failed':'idle';
     const stageTextOf=(lrItem)=>{
      const subs=Array.isArray(lrItem?.subs)?lrItem.subs:[];
      const doneCnt=subs.filter(s=>s&&s.state==='done').length;
      const base=lrItem?.stageLabel?String(lrItem.stageLabel):(subs.length?tr('检索来源 '+doneCnt+'/'+subs.length,'Sources '+doneCnt+'/'+subs.length):tr('深度研究中…','Researching…'));
      const started=Number(lrItem?.startedAt||lrItem?.createdAt);
      const sec=Number.isFinite(started)&&started>0?Math.max(1,Math.round((Date.now()-started)/1000)):0;
      return sec?base+' · '+sec+'s':base;
     };
     const activeStageLabel=(isPending||isRun)?stageTextOf(matchedLr):'';
     const btnLabel=(isPending||isRun)?activeStageLabel:isInterrupted?tr('已中断 · 重试','Interrupted · Retry'):isFailed?tr('研究失败 · 重试','Research failed · Retry'):(contract?.researchButtonLabel?contract.researchButtonLabel({langOrEn:uiLangNow,isPro,state:btnState}):(isDone?tr('查看报告 ↗','View report ↗'):isPro?tr('✦ 深度研究','✦ Deep research'):tr('✦ 深度研究 · Pro','✦ Deep research · Pro')));
     const setResearchBtn=(btn,st,lbl)=>{
      if(st==='pending'||st==='running'){
       btn.replaceChildren();
       const sp=make('span','','mw-research-spinner');sp.setAttribute('aria-hidden','true');
       const tx=make('span',lbl,'mw-research-label');
       btn.append(sp,tx);
      }else{
       btn.textContent=lbl;
      }
     };
     const research=make('button','','mw-stream-research');research.type='button';
     setResearchBtn(research,btnState,btnLabel);
     if(!isPro&&btnState==='idle')research.dataset.proGate='1';
     if(research.dataset)research.dataset.lrState=btnState;
     const bindCancelHover=(btn,activeLabel)=>{
      btn.title=tr('取消研究','Cancel research');
      btn.onmouseenter=()=>{if(['pending','running'].includes(btn.dataset.lrState)){const lb=btn.querySelector('.mw-research-label');if(lb)lb.textContent=tr('取消研究','Cancel research');else btn.textContent=tr('取消研究','Cancel research');}};
      btn.onmouseleave=()=>{if(['pending','running'].includes(btn.dataset.lrState)){const lb=btn.querySelector('.mw-research-label');if(lb)lb.textContent=activeLabel;else btn.textContent=activeLabel;}};
     };
     if(isPending||isRun)bindCancelHover(research,btnLabel);
     research.onclick=async()=>{
      if(!isPro&&!isRun&&!isDone&&!isFailed){showPaywall(card);return;}
      if(isPending||isRun||pendingResearchCards.has(pendingKey)||['pending','running'].includes(research.dataset.lrState)){
       pendingResearchCards.delete(pendingKey);
       research.dataset.lrState='idle';research.title='';research.onmouseenter=null;research.onmouseleave=null;
       setResearchBtn(research,'idle',contract?.researchButtonLabel?contract.researchButtonLabel({langOrEn:uiLangNow,isPro,state:'idle'}):tr('✦ 深度研究','✦ Deep research'));
       try{await window.thtLiveResearch?.post?.({id:d.id,action:'stop',...(matchedLr?.id?{itemId:matchedLr.id}:{}),cardId:m.id});}catch{}
       return;
      }
      if(isDone&&matchedLr){if(typeof window.thtOpenResearchReport==='function')window.thtOpenResearchReport(matchedLr.id);else window.thtLiveResearch?.openReport?.(matchedLr.id);return;}
      if(isFailed&&matchedLr){
       pendingResearchCards.add(pendingKey);
       research.disabled=false;if(research.dataset)research.dataset.lrState='pending';
       const retryLabel=tr('深度研究中…','Researching…');
       setResearchBtn(research,'pending',retryLabel);
       bindCancelHover(research,retryLabel);
       try{
        await window.thtLiveResearch?.post?.({id:d.id,action:'resume',itemId:matchedLr.id});
        setTimeout(()=>{pendingResearchCards.delete(pendingKey);},15000);
       }catch(error){
        pendingResearchCards.delete(pendingKey);if(research.dataset)research.dataset.lrState=btnState;
        research.onmouseenter=null;research.onmouseleave=null;setResearchBtn(research,btnState,btnLabel);research.title=error.message||'';
       }
       return;
      }
      postCardFeedback('deep_research');
      pendingResearchCards.add(pendingKey);
      research.disabled=false;if(research.dataset)research.dataset.lrState='pending';
      const pendingLabel=tr('深度研究中…','Researching…');
      setResearchBtn(research,'pending',pendingLabel);
      bindCancelHover(research,pendingLabel);
      try{
       const queryText=shownBody.slice(0,500);
       let result;
       if(typeof window.thtLiveResearch?.post==='function'){
        result=await window.thtLiveResearch.post({id:d.id,action:'open',cardId:m.id,cardKind:m.kind||'',uiLang:document.documentElement.lang==='en'?'en':'zh',fast:true,text:queryText,effort:'deep'});
       }else if(typeof window.thtResearchCard==='function'){
        result=await window.thtResearchCard({meetingId:d.id,cardId:m.id,text:shownBody.slice(0,600)});
       }else{
        throw Error(tr('研究暂不可用','Research unavailable'));
       }
       if(result?.ok===false||result?.error){
        const errCode=String(result?.code||result?.error||'');
        if(contract?.isResearchEntitlementError?.(errCode)){
         pendingResearchCards.delete(pendingKey);research.disabled=false;if(research.dataset)research.dataset.lrState='idle';
         research.title='';research.onmouseenter=null;research.onmouseleave=null;
         setResearchBtn(research,'idle',contract.researchButtonLabel({langOrEn:uiLangNow,isPro:false,state:'idle'}));
         showPaywall(card);return;
        }
        throw Error(result.error||tr('研究启动失败','Research failed'));
       }
       setResearchBtn(research,'pending',pendingLabel);
       setTimeout(()=>{pendingResearchCards.delete(pendingKey);},15000);
      }catch(error){
       pendingResearchCards.delete(pendingKey);research.disabled=false;if(research.dataset)research.dataset.lrState='idle';
       research.onmouseenter=null;research.onmouseleave=null;research.title='';
       const errCode=String(error?.code||error?.message||'');
       if(contract?.isResearchEntitlementError?.(errCode)){
        setResearchBtn(research,'idle',contract.researchButtonLabel({langOrEn:uiLangNow,isPro:false,state:'idle'}));
        showPaywall(card);return;
       }
       setResearchBtn(research,'idle',btnLabel);research.title=error.message;card.append(make('small',error.message,'mw-send-reason'));
      }
     };actions.append(research);
    }
    const savedBm=readBookmarks(d.id).some(x=>x.id===m.id);
    const bm=make('button',savedBm?tr('已收藏','Saved'):tr('收藏','Save'),'mw-act-pill mw-bookmark');bm.type='button';bm.setAttribute('aria-pressed',String(savedBm));bm.title=tr('收藏到产出内容','Bookmark to outputs');
    bm.onclick=()=>{const on=toggleBookmark(d.id,{id:m.id,title:m.title||streamPlain(m.body).slice(0,40),text:shownBody,semanticBadge:semanticBadgeOf(m),sources:[...(Array.isArray(m.sources)?m.sources:[]),...(Array.isArray(m.links)?m.links:[])].slice(0,8)});bm.setAttribute('aria-pressed',String(on));bm.textContent=on?tr('已收藏','Saved'):tr('收藏','Save');if(on)postCardFeedback('bookmark');};
    actions.append(bm);
    const downKey='tht-card-down:'+d.id+':'+(m.id||'');
    let isDown=false;try{isDown=localStorage.getItem(downKey)==='1';}catch{}
    const td=make('button','','mw-act-pill mw-thumb-down');td.type='button';td.setAttribute('aria-pressed',String(isDown));td.setAttribute('aria-label',tr('这条不太有帮助','Not helpful'));td.title=tr('这条不太有帮助','Not helpful');
    td.innerHTML='<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.5 10.5V13a1.5 1.5 0 0 1-1.5 1.5l-2.2-4.7V3.5h6.1a1.5 1.5 0 0 1 1.48 1.25l.65 4a1.5 1.5 0 0 1-1.48 1.75H9.5z"/><path d="M5.8 3.5H3.5a1 1 0 0 0-1 1v4.3a1 1 0 0 0 1 1h2.3"/></svg>';
    td.onclick=()=>{
     isDown=!isDown;td.setAttribute('aria-pressed',String(isDown));
     try{if(isDown)localStorage.setItem(downKey,'1');else localStorage.removeItem(downKey);}catch{}
     postCardFeedback(isDown?'thumbs_down':'retract_thumbs_down');
    };
    actions.append(td);
   }
   if(stream&&!draft&&['task','suggestion'].includes(m.kind)){
    const prepare=make('button',tr('替我做','Do it for me'),'mw-stream-prepare');prepare.type='button';prepare.onclick=()=>{
     const ok=window.thtDraftMeetingItem?.({meetingId:d.id,candidateId:m.streamParentId||m.id,objectId:m.objectId,text:shownBody,sourceRefs:m.sourceRefs||[]});
     if(!ok)card.append(make('small',tr('请先打开对应会议文档','Open the matching meeting document first'),'mw-send-reason'));
    };actions.prepend?actions.prepend(prepare):actions.append(prepare);
   }
   actions.append(copy,ask,see);copy.hidden=ask.hidden=see.hidden=true;
   if(directAction)card.dataset.directAction='true';
   if(m.kind!=='task'&&dismissedCandidates(d.id).has(m.id)){const line=make('div','','ma-insight-skipped'),undo=make('button',tr('撤销','Undo'));undo.type='button';undo.onclick=async()=>{undo.disabled=true;try{const result=await window.thtClearPendingRejection?.({meetingId:d.id,candidateId:m.id});if(!result?.cleared)throw Error('undo');dismissCandidate(d.id,m.id,false);pendingStaged.delete(d.id+'\n'+m.id);proactiveKey='';renderProactive(proactiveData);}catch{line.append(make('span',tr('没能撤销，请再试。','Could not undo. Try again.')));}finally{undo.disabled=false;}};line.append(make('span',(m.title||m.body||'').slice(0,24)+'… '+tr('不用了','not needed')),undo);card.classList.add('ma-dismissed');card.append(line);insights.append(card);continue;}
   maybeStageExternal(d,m);
   card.addEventListener?.('toggle',e=>{if(e.target?.open)expandSignal(d.id,m);},true);
   card.append(heading,body,...(stream?[]:sourceLine(m)),actions,...(stream&&sourceCount?[sources]:[]),editor);insights.append(card);
   if(draft&&phaseNow==='sent'){
    card.classList?.add('mw-done-action');
    const row=make('div','','mw-gist mw-done-line');
    row.append(make('span','✓','mw-done-mark'),make('span',(complete?tr('已完成 · ','Done · '):tr('正在发出 · ','Sending · '))+sendTitle(m,draft)));
    if(typeof card.after==='function')card.after(row);else insights.append(row);
   }
   // r9：会中卡片不再放「写进文档」。外部信息进文档待定段，只在文档里采纳或深度研究。
   // Explicit user intent, not title heuristics: recording an action stays independent
   // from generating its deliverable. Only backend-supported kinds expose this control.
   if(!draft&&m.objectId&&m.kind==='action'){
    const result=make('div','','ma-action-result'),adoptResult=make('button',tr('采纳成果','Add result'),'ma-result-place');adoptResult.type='button';card.append(result);
    actionCard(card,heading,result,adoptResult,m,d,{actions,stream});
   }
  }
  renderDocumentProposals(d);
  let restoredStreamDrawer=false;
  for(const detail of insights.querySelectorAll('details')){
   if(detail.dataset.key&&expanded.has(detail.dataset.key)){
    if(detail.dataset.streamDrawer==='1'){
     if(restoredStreamDrawer)continue;
     restoredStreamDrawer=true;
     detail.open=true;
     const btnEl=detail.closest('.mw-stream-item')?.querySelector('.mw-src-chip');
     if(btnEl)btnEl.setAttribute('aria-expanded','true');
    }else{
     detail.open=true;
    }
   }
  }
  window.thtLiveResearch?.mountFeed(insights);
  if(stream){
   const streamCards=[...insights.querySelectorAll(':scope > .mw-stream-item')];
   for(const sc of streamCards)sc.classList?.remove('ctv2-new');
   if(streamCards.length)streamCards[streamCards.length-1].classList?.add('ctv2-new');
  }
  insights.hidden=!insights.children.length;if(viewport?.afterRender)viewport.afterRender();else feed.scrollTop=scroll;
 }
 // Pending AI revisions to blocks the person edited. Decided here; the right column only shows them.
 let documentProposals={meetingId:'',items:[]};const proposalErrors=new Map();
 window.thtDocumentProposals=data=>{documentProposals={meetingId:String(data?.meetingId||''),documentId:String(data?.documentId||''),items:Array.isArray(data?.items)?data.items.map(x=>({...x})):[]};proactiveKey='';if(proactiveData)renderProactive(proactiveData);};
 function renderDocumentProposals(d){
  if(documentProposals.meetingId!==d.id)return;
  for(const p of documentProposals.items){
   const card=make('article','','ma-insight ma-revision'),heading=make('strong',p.state==='accepted'?tr('已写进文档 · AI 修订','Written · AI revision'):tr('AI 想更新你改过的段落','AI wants to update a block you edited')),body=make('div');card.dataset.kind='revision';card.dataset.proposalId=p.id;
   body.append(make('p',tr('你的版本保留着，AI 的版本没覆盖。','Your version is kept; the AI version did not overwrite it.'),'ma-muted'));
   if(p.after){const after=make('blockquote',p.after.slice(0,600));body.append(after);}
   const actions=make('div','','ma-insight-actions'),status=make('small',proposalErrors.get(p.id)||'','ma-muted');status.setAttribute('role','status');
   const go=async decision=>{for(const b of actions.querySelectorAll('button'))b.disabled=true;proposalErrors.delete(p.id);try{await window.thtResolveDocumentProposal?.({meetingId:d.id,proposalId:p.id,decision});}catch(e){proposalErrors.set(p.id,e.message);status.textContent=e.message;for(const b of actions.querySelectorAll('button'))b.disabled=false;}};
   if(p.state==='accepted'){const where=make('button',tr('✓ 已写进文档 · 位置 ›','✓ Written to document · Location ›'),'ma-insight-place ma-landed');where.type='button';where.onclick=()=>revealLanding(d.id,p.targetId,'');const undo=make('button',tr('撤销','Undo'));undo.type='button';undo.onclick=()=>go('undo');actions.append(where,undo);}
   else{const accept=make('button',tr('写进文档','Write to document'),'ma-insight-place ma-primary'),reject=make('button',tr('不采纳','Dismiss'),'ma-skip');accept.type=reject.type='button';accept.onclick=()=>go('accept');reject.onclick=()=>go('reject');actions.append(accept,reject);}
   card.append(heading,body,actions,status);insights.prepend(card);
  }
 }
 window.addEventListener('tht-proactive-data',e=>renderProactive(e.detail));if(window.__thtProactiveData)renderProactive(window.__thtProactiveData);
 window.addEventListener('tht-meeting-navigating',e=>{dropMeetingActions(proactiveData&&proactiveData.id);dropMeetingActions(e.detail&&e.detail.id);sawLive.delete(e.detail&&e.detail.id);endedCancel.delete(e.detail&&e.detail.id);liveSend.cancelAll();liveSend.phase.clear();liveSend.reasons.clear();switchConversation({page:'meeting',contextId:e.detail.id});proactiveData=null;window.__thtProactiveData=null;proactiveKey='';insights.replaceChildren();});
 $('.ma-clear-quote').onclick=()=>{if(candidateTarget){endCandidateComment();return;}quote='';object={};showQuote();persist();};
 const active=j=>['queued','running','retrieving','syncing','thinking','planning','stopping','executing'].includes(j.state);
 window.thtAgentBusy=()=>!!(uploading||recognition||input.value.trim()||quote||materials.length||localJobs.length||jobs.some(j=>active(j)||(['awaiting_confirmation','uncertain'].includes(j.state)&&!(typeof j.finished==='string'&&Number.isFinite(Date.parse(j.finished))))));
 window.thtComposeTarget=({key,label,submit})=>{const state={open:false,busy:false};const target={key,label,title:label,state,submit:async()=>{const text=input.value.trim();if(!text||state.busy||candidateTarget!==target)return;const snapshot=JSON.stringify(composer()),raw=input.value;state.busy=true;resizeComposer();try{await submit(text);if(candidateTarget===target&&input.value===raw&&JSON.stringify(composer())===snapshot){input.value='';endCandidateComment();}}finally{state.busy=false;resizeComposer();}}};beginCandidateComment(target);};
 const status=j=>j.state==='queued'?tr(j.id.startsWith('local-')?'提交中…':'已收到',j.id.startsWith('local-')?'Sending…':'Received'):j.state==='stopping'?tr('正在停止…','Stopping…'):j.events?.at(-1)?.message||tr('正在处理…','Working…');
 // Old transport envelopes remain readable without changing saved history.
 function answerBody(text){
  const raw=String(text||''),json=raw.trim().replace(/^```(?:json)?\s*\n([\s\S]*?)\n```$/,'$1');
  try{const value=JSON.parse(json);if(value&&typeof value.reply==='string'&&Object.keys(value).every(k=>['reply','action'].includes(k)))return value.reply;}catch{}
  return raw;
 }
 function rich(text){
  const box=make('div','','ma-answer'),lines=answerBody(text).split('\n');let list=null;
  function inline(n,line){
   let at=0;
   for(const m of line.matchAll(/\[([^\]]+)\]\(([^\s)]+)\)|\*\*([^*]+)\*\*|`([^`]+)`/g)){
    n.append(document.createTextNode(line.slice(at,m.index)));
    if(m[1]){let url;try{url=new URL(m[2],location.href);}catch{}if(url&&['http:','https:','codex:'].includes(url.protocol)&&!url.username&&!url.password){const a=make('a',m[1]);a.href=url.href;a.rel='noopener noreferrer';a.onclick=e=>{if(url.origin===location.origin&&url.searchParams.has('id')&&/\/seatnote\/(?:index\.html|meeting-board\.html)?$/.test(url.pathname)&&openMeeting(url.searchParams.get('id'),Number((url.hash.match(/t=([\d.]+)/)||[])[1]||0),url.searchParams.get('module')||'')){e.preventDefault();}};n.append(a);}else n.append(document.createTextNode(m[0]));}
    else n.append(make(m[3]?'strong':'code',m[3]||m[4]));at=m.index+m[0].length;
   }n.append(document.createTextNode(line.slice(at)));
  }
  const cells=line=>line.trim().replace(/^\||(?<!\\)\|$/g,'').split(/(?<!\\)\|/).map(x=>x.trim().replace(/\\\|/g,'|'));
  for(let i=0;i<lines.length;i++){
   const raw=lines[i];if(!raw.trim()){list=null;continue;}
   const fence=/^\s*(`{3,}|~{3,})([\w+-]*)\s*$/.exec(raw);
   if(fence){list=null;const code=[];while(++i<lines.length&&!new RegExp('^\\s*'+fence[1][0]+'{'+fence[1].length+',}\\s*$').test(lines[i]))code.push(lines[i]);const pre=make('pre');pre.append(make('code',code.join('\n')));box.append(pre);continue;}
   const header=cells(raw),divider=cells(lines[i+1]||'');
   if(raw.includes('|')&&header.length>1&&divider.length===header.length&&divider.every(x=>/^:?-{3,}:?$/.test(x))){
    list=null;const wrap=make('div','','ma-table'),table=make('table'),head=make('thead'),row=make('tr'),body=make('tbody');
    for(const value of header){const cell=make('th');inline(cell,value);row.append(cell);}head.append(row);table.append(head,body);i++;
    while(i+1<lines.length&&lines[i+1].trim()&&lines[i+1].includes('|')){const row=make('tr'),values=cells(lines[++i]);for(let c=0;c<header.length;c++){const cell=make('td');inline(cell,values[c]||'');row.append(cell);}body.append(row);}wrap.append(table);box.append(wrap);continue;
   }
   const bullet=/^\s*[-*+] (.*)$/.exec(raw),ordered=/^\s*(\d+)[.)] (.*)$/.exec(raw),heading=/^(#{1,6}) (.*)$/.exec(raw),quoted=/^>\s?(.*)$/.exec(raw);
   if(bullet||ordered){const type=ordered?'ol':'ul';if(!list||list.tagName.toLowerCase()!==type){list=make(type);if(ordered)list.start=Number(ordered[1]);box.append(list);}const n=make('li');inline(n,ordered?ordered[2]:bullet[1]);list.append(n);}
   else{list=null;const n=make(heading?'h'+Math.min(heading[1].length+1,4):quoted?'blockquote':'p');inline(n,heading?heading[2]:quoted?quoted[1]:raw);box.append(n);}
  }return box;
 }
 async function command(job,action){if(action==='cancel'){if(composerBusy(job))for(const current of jobs)if(composerBusy(current))composerReleased.add(current.id);composerReleased.add(job.id);resizeComposer();}try{const body={action,jobId:job.id,...(action==='confirm'?{confirmed:true}:{})};const path=job.meetingId&&job.meetingId!=='assistant:global'?'/meeting-board':'/workspace-assistant';if(path==='/meeting-board')body.id=job.meetingId;const result=await api(body,path);upsert(result.job);}catch(e){$('.ma-status').textContent=e.message;}}
 function artifactPreview(artifact){
  const d=make('details','','ma-reference ma-artifact'),base=address('/workspace-assistant/artifact')+'&id='+encodeURIComponent(artifact.id);
  d.append(make('summary',tr('成果预览 · 本机草稿','Result preview · local draft')));
  const imageURL=base+'&format=png';let receipt=null;let selected=0;
  const pageURL=i=>imageURL+'&page='+i;
  const zoom=()=>{
   const modal=document.createElement('dialog');modal.className='ma-artifact-dialog';modal.setAttribute('aria-label',tr('成果图片预览','Result image preview'));
   const close=make('button',tr('关闭','Close'),'ma-result');close.onclick=()=>modal.close();
   const scroll=make('div','','ma-artifact-scroll'),image=document.createElement('img');image.alt=tr('当前草稿的实际渲染图片','Rendered image of the current draft');image.referrerPolicy='no-referrer';
   const nav=make('div','','ma-artifact-pages'),previous=make('button',tr('上一页','Previous'),'ma-result'),next=make('button',tr('下一页','Next'),'ma-result'),label=make('span');
   const show=()=>{const count=receipt?.pages?.length||1;image.src=pageURL(selected);label.textContent=(selected+1)+' / '+count;previous.disabled=selected===0;next.disabled=selected+1>=count;scroll.scrollTop=0;};
   previous.onclick=()=>{selected--;show();};next.onclick=()=>{selected++;show();};nav.append(previous,label,next);scroll.append(image);modal.append(close,nav,scroll);show();
   modal.addEventListener('keydown',e=>{if(e.key==='Escape')e.stopPropagation();});modal.addEventListener('close',()=>modal.remove());document.body.append(modal);modal.showModal();
  };
  let pending=false,ready=false,status,thumb,image,retry,pages;
  const unavailable=()=>{pending=false;ready=false;thumb.hidden=true;retry.hidden=false;retry.disabled=false;status.textContent=tr('图片预览暂不可用，全文与原件仍可打开。','Image preview is unavailable; full text and original are still available.');};
  const render=()=>{
   if(pending||ready)return;
   if(!status){
    status=make('small','','ma-muted');status.setAttribute('role','status');
    thumb=make('button','','ma-artifact-thumb');thumb.type='button';thumb.setAttribute('aria-label',tr('放大成果图片','Expand result image'));thumb.onclick=zoom;
    image=document.createElement('img');image.alt=tr('当前草稿预览，点击放大','Current draft preview; click to expand');image.referrerPolicy='no-referrer';
    retry=make('button',tr('重试图片预览','Retry image preview'),'ma-result');retry.type='button';retry.onclick=render;
    image.onload=()=>{pending=false;ready=true;thumb.hidden=false;retry.hidden=true;status.textContent=tr('点击图片放大','Click image to expand')+(receipt?.pages?.length>1?' · '+receipt.pages.length+tr(' 页',' pages'):'');};
    image.onerror=unavailable;thumb.append(image);d.append(status,thumb,retry);
   }
   pending=true;retry.hidden=true;retry.disabled=true;thumb.hidden=true;pages?.remove();status.textContent=tr('正在生成图片预览…','Rendering image preview…');
   fetch(imageURL,{method:'POST',referrerPolicy:'no-referrer'}).then(r=>{if(!r.ok)throw Error('preview');return r.json();}).then(r=>{receipt=r;selected=0;image.src=pageURL(0);if(r.pages?.length>1){pages=make('div','','ma-artifact-pages');r.pages.forEach((p,i)=>{const b=make('button',String(i+1),'ma-result');b.type='button';b.setAttribute('aria-label',tr('查看第 ','View page ')+(i+1)+tr(' 页',''));b.onclick=()=>{selected=i;zoom();};pages.append(b);});d.append(pages);}}).catch(unavailable);
  };
  d.addEventListener('toggle',()=>{if(d.open)render();});
  const text=make('a',tr('打开全文','Open full text'),'ma-result');text.href=base+'&format=html';text.target='_blank';text.rel='noopener noreferrer';
  const download=make('a',tr('下载可编辑草稿','Download editable draft'),'ma-result');download.href=base+'&format=md';download.referrerPolicy='no-referrer';download.download='draft.md';
  d.append(text,download,make('small',tr('草稿已保存，未提交到外部文档。','Draft saved; not submitted to external documents.'),'ma-muted'));return d;
 }
 // Whole replies and quoted excerpts have independent deterministic collection receipts.
 const chatCollections=new Map();
 const meetingWorkspace=()=>document.body.classList.contains('meeting-workspace');
 function chatCollectionKey(job,quote=''){return JSON.stringify([job.contextId,job.id,job.reply,quote]);}
 function rememberChatError(state,message){state.error=message;state.errorOp='collect';try{sessionStorage.setItem('tht-chat-collection:'+state.item.moduleId,message);}catch{}}
 function updateChatCollectionReceipt(item){
  for(const state of chatCollections.values())if(state.job.contextId===item.meetingId&&state.item?.moduleId===item.moduleId){state.receipt=item.receipt;state.error='';paintChatCollection(state);}
 }
 function paintChatCollection(state){for(const paint of state.painters)if(paint()===false)state.painters.delete(paint);}
 async function readChatReceipt(state){
  if(!state.item||typeof window.thtMeetingCollection!=='function')return undefined;
  const receipt=await window.thtMeetingCollection({meetingId:state.job.contextId,moduleId:state.item.moduleId});
  if(receipt){state.receipt=receipt;if(state.errorOp!=='undo'){state.error='';try{sessionStorage.removeItem('tht-chat-collection:'+state.item.moduleId);}catch{}}}
  return receipt;
 }
 async function collectChatReply(state,manual=false){
  if(state.busy||state.error&&!manual||!meetingWorkspace()||state.job.contextId!==currentScope)return;
  state.busy=true;paintChatCollection(state);
  try{
   if(!state.item){state.item=await window.ChatDocumentSelection.selection(state.job,state.quote);try{state.error=sessionStorage.getItem('tht-chat-collection:'+state.item.moduleId)||'';}catch{}}
   if(!meetingWorkspace()||state.job.contextId!==currentScope)return;
   const receipt=await readChatReceipt(state);
   if(!meetingWorkspace()||state.job.contextId!==currentScope)return;
   if(receipt&&!receipt.undone||receipt?.undone&&!manual||state.error&&!manual)return;
   // Undefined means the matching document has not loaded; absence is only null.
   if(receipt===undefined)return;
   state.error='';
   try{
    state.receipt=await window.thtCollectMeetingModule({meetingId:state.job.contextId,...state.item});
    if(!state.receipt?.blockId)throw Error(tr('保存回执尚未确认，请重试查询。','Save receipt is unconfirmed. Retry to check.'));
    try{sessionStorage.removeItem('tht-chat-collection:'+state.item.moduleId);}catch{}
   }catch(error){
    // A lost POST response may already have a durable document receipt.
    let recovered;try{recovered=await readChatReceipt(state);}catch{}
    if(!recovered||recovered.undone)rememberChatError(state,error.message||String(error));
   }
  }catch(error){if(state.item)rememberChatError(state,error.message||String(error));else state.error=error.message||String(error);}
  finally{state.busy=false;paintChatCollection(state);}
 }
 function chatCollectionState(job,quote=''){
  const key=chatCollectionKey(job,quote);let state=chatCollections.get(key);
  if(!state){state={job,quote,item:null,receipt:null,error:'',busy:false,painters:new Set()};chatCollections.set(key,state);}
  return state;
 }
 function chatReceiptLine(job,quote=''){
  const state=chatCollectionState(job,quote),line=make('div','','ma-chat-receipt'),label=make('span'),location=make('button','','ma-result'),action=make('button','','ma-result');location.type=action.type='button';line.append(label,location,action);
  const paint=()=>{
   const receipt=state.receipt;label.textContent=state.error?(state.errorOp==='undo'?tr('未能撤销：','Could not undo: '):tr('未能写进方案：','Could not save to solution: '))+state.error:receipt?.undone?tr('已撤销','Undone'):receipt?tr('已写进方案 ·','Saved to solution ·'):tr('正在写进方案…','Saving to solution…');
   const landing=receipt?.organization?.inserted?.[0]||{},blockId=landing.id||receipt?.blockId;
   location.hidden=!blockId||!!receipt?.undone;location.textContent=(landing.title||receipt?.chapterTitle||tr('查看位置','View location'))+' ›';location.onclick=()=>revealLanding(job.contextId,blockId,'');
   action.hidden=!state.error&&!receipt;action.disabled=state.busy;action.textContent=state.error?tr('重试','Retry'):receipt?.undone?tr('重新写进方案','Save to solution again'):tr('撤销','Undo');
  };
  action.onclick=async()=>{
   if(state.busy)return;
   if(state.error&&state.errorOp!=='undo'||state.receipt?.undone){await collectChatReply(state,true);return;}
   state.busy=true;paintChatCollection(state);
   try{state.receipt=await window.thtCollectMeetingModule({meetingId:job.contextId,moduleId:state.item.moduleId,op:'undo'});state.error='';}
   catch(error){let recovered;try{recovered=await readChatReceipt(state);}catch{}if(recovered?.undone)state.error='';else{state.error=error.message||String(error);state.errorOp='undo';}}
   finally{state.busy=false;paintChatCollection(state);}
  };
  let mounted=false;state.painters.add(()=>{if(!line.isConnected)return !mounted;mounted=true;paint();return true;});paint();return line;
 }
 function chatSelectionsKey(job){return 'tht-chat-selections:'+JSON.stringify([job.contextId,job.id]);}
 function rememberChatSelection(job,quote){
  try{const saved=JSON.parse(localStorage.getItem(chatSelectionsKey(job))||'{}'),quotes=saved.reply===job.reply?saved.quotes||[]:[];if(!quotes.includes(quote))quotes.push(quote);localStorage.setItem(chatSelectionsKey(job),JSON.stringify({reply:job.reply,quotes}));}catch{}
 }
 function restoreChatSelections(job){
  try{const saved=JSON.parse(localStorage.getItem(chatSelectionsKey(job))||'{}');if(saved.reply!==job.reply)return;for(const quote of saved.quotes||[]){const state=chatCollectionState(job,quote);if(!state.item&&!state.busy){state.busy=true;void window.ChatDocumentSelection.selection(job,quote).then(item=>{state.item=item;return readChatReceipt(state).then(receipt=>{if(receipt===null){state.error=sessionStorage.getItem('tht-chat-collection:'+item.moduleId)||tr('保存回执尚未确认，请重试查询。','Save receipt is unconfirmed. Retry to check.');state.errorOp='collect';}});}).catch(error=>{state.error=error.message;}).finally(()=>{state.busy=false;paintChatCollection(state);});}}}catch{}
 }
 function meetingReplyCollection(job,reply,article){

  restoreChatSelections(job);
  let quote='';const selected=make('button',tr('加入选中文字','Add selected text'),'ma-chat-selection ma-insight-place');selected.type='button';selected.hidden=true;
  const capture=()=>{const selection=window.getSelection();quote=selection&&reply.contains(selection.anchorNode)&&reply.contains(selection.focusNode)?window.ChatDocumentSelection.normalize(selection.toString()):'';selected.hidden=!quote;};
  reply.addEventListener('mouseup',capture);reply.addEventListener('keyup',capture);selected.onpointerdown=e=>{capture();e.preventDefault();};
  selected.onclick=async()=>{if(!quote)return;rememberChatSelection(job,quote);const state=chatCollectionState(job,quote);if(!article.querySelector('[data-chat-quote="'+CSS.escape(quote)+'"]')){const line=chatReceiptLine(job,quote);line.dataset.chatQuote=quote;article.append(line);}await collectChatReply(state,true);};
  article.append(selected);
  // Recreate independent excerpt receipts when the reply node is redrawn.
  for(const state of chatCollections.values())if(state.quote&&chatCollectionKey(state.job)===chatCollectionKey(job)){const line=chatReceiptLine(job,state.quote);line.dataset.chatQuote=state.quote;article.append(line);}
 }
 function row(job){
  const article=make('article','','ma-job');article.dataset.job=job.id;
  if(job.origin){const label=make('small',(job.error?tr('任务来源 · ','Assignment · '):tr('已准备 · ','Prepared · '))+(job.origin.provider==='lark'?tr('飞书','Lark'):'Slack'),'ma-muted');article.append(label);if(job.origin.url){const a=make('a',tr('任务原消息 ↗','Original assignment ↗'),'ma-result');let url;try{url=new URL(job.origin.url);}catch{}if(url&&url.protocol==='https:'&&!url.username&&!url.password){a.href=url.href;a.target='_blank';a.rel='noopener noreferrer';article.append(a);}}}
  if(job.assignmentSourceId){const b=make('button',tr('打开草稿','Open draft'),'ma-result');b.onclick=()=>{if(window.thtOpenWorkbench)window.thtOpenWorkbench('sources',false,job.assignmentSourceId);else location.href='./work.html#sources&source='+encodeURIComponent(job.assignmentSourceId);close();};article.append(b);if(job.error){const retry=make('button',tr('重新准备','Retry draft'),'ma-result');retry.onclick=()=>api({action:'retry',sourceId:job.assignmentSourceId},'/assigned-work').then(()=>refresh()).catch(e=>{$('.ma-status').textContent=e.message;});article.append(retry);}}
  const mats=Array.isArray(job.materials)&&job.materials.length?job.materials:Array.isArray(job.materialIds)&&job.materialIds.length?job.materialIds.map(id=>({id,name:'',type:'image/png'})):[];
  if(mats.length){
   const wrap=make('div','','ma-user-materials');
   for(const m of mats){
    const preview=materialPreviews.get(m.id);
    if(String(m.type||'').startsWith('image/')||preview?.url){
     const img=document.createElement('img');img.className='ma-user-thumb';img.loading='lazy';
     img.src=preview?.url||('/workspace-assistant/materials?id='+encodeURIComponent(m.id));
     img.alt=m.name||tr('截图附件','Screenshot attachment');
     img.onerror=()=>{img.remove();};
     wrap.append(img);
    }else if(m.name){
     wrap.append(make('span','📎 '+m.name,'ma-user-file'));
    }
   }
   if(wrap.childNodes.length)article.append(wrap);
  }
  if(job.comment)article.append(make('p',job.comment,'ma-user'));
  if(job.quote){const reference=make('details','','ma-reference');reference.append(make('summary',tr('引用的内容','Quoted context')),make('blockquote',job.quote));article.append(reference);}
  if(job.reply){
   const unparsed=job.state==='failed'&&job.replyFormat==='unparsed',reply=unparsed?make('div','','ma-answer'):rich(job.reply);if(unparsed){reply.append(make('p',tr('这次没能生成完整结果，原始输出已保留。','Could not generate a complete result. The raw output has been preserved.')));const det=make('details','','ma-reference');det.append(make('summary',tr('查看原始输出','View raw output')),make('pre',job.reply));reply.append(det);}article.append(reply);
   // A range rewrite already landed in the document; offering to add the reply again would duplicate it.
   if(['completed','planned'].includes(job.state)&&!job.motherRange&&job.contextId===currentScope&&window.ChatDocumentSelection){
    if(meetingWorkspace())meetingReplyCollection(job,reply,article);else{
    let quote='';const place=make('button',tr('加入方案','Add to solution'),'ma-insight-place'),notice=make('small','','ma-muted');
    place.type='button';place.dataset.meetingId=job.contextId;
    const capture=()=>{const selected=window.getSelection();quote=selected&&reply.contains(selected.anchorNode)&&reply.contains(selected.focusNode)?window.ChatDocumentSelection.normalize(selected.toString()):'';place.textContent=quote?tr('加入选中文字','Add selected text'):tr('加入方案','Add to solution');};reply.addEventListener('mouseup',capture);reply.addEventListener('keyup',capture);
    place.addEventListener('pointerdown',e=>{capture();e.preventDefault();});
    place.onclick=async()=>{capture();place.disabled=true;notice.textContent='';place.textContent=tr('正在加入…','Adding…');
     try{const item=await window.ChatDocumentSelection.selection(job,quote);place.dataset.moduleId=item.moduleId;const receipt=await window.thtCollectMeetingModule({meetingId:job.contextId,...item});place.textContent=collectionLabel(receipt);}
     catch(e){place.textContent=tr('重试加入方案','Retry adding');notice.textContent=e.message;}
     finally{place.disabled=false;}
    };article.append(place,notice);
    }
   }
  }
  if(job.artifact)article.append(artifactPreview(job.artifact));
  if(job.motherEdit){
   const d=make('details','','ma-reference');d.append(make('summary',tr('查看文档修改','Review document edit')));
   for(const block of job.motherEdit.blocks||[])if(block.type==='meetingGraph'&&window.MeetingGraph){try{d.append(window.MeetingGraph.render(block.attrs.graph,document));}catch{}}
   d.append(rich(job.motherEdit.preview));
   article.append(d,editReceipt(job));
  }
  if(job.motherRange)article.append(rangeReceipt(job));
  if(job.state==='cancelled')article.append(make('small',tr('已停止','Stopped'),'ma-muted'));
  if(job.state==='preview')article.append(make('small',tr('预览已生成，等待测试与审核','Preview ready, awaiting tests and review'),'ma-muted'));
  if(job.action==='draft'&&['failed','interrupted'].includes(job.state)){const b=make('button',tr('重试草稿','Retry draft'),'ma-result');b.onclick=()=>api({id:job.meetingId,action:'draft-retry',jobId:job.id},'/meeting-board').then(()=>refresh()).catch(e=>{$('.ma-status').textContent=e.message;});article.append(b);}
  if(job.action==='project-draft'&&['failed','interrupted'].includes(job.state)){const b=make('button',tr('重试成果','Retry draft'),'ma-result');b.onclick=()=>api({id:job.meetingId,action:'artifact-retry',jobId:job.id},'/meeting-board').then(()=>refresh()).catch(e=>{$('.ma-status').textContent=e.message;});article.append(b);}
  if(job.error){const error=make('div','','ma-error');error.append(make('span',errorText(job.error,!!job.payload||job.retryable===true,true)));if(job.payload&&job.state==='failed'){const retry=make('button',tr('重试发送','Retry'),'ma-retry');retry.type='button';retry.onclick=()=>submit(job);error.append(retry);}else if(job.retryable===true){
   const retry=make('button','','ma-retry'),notice=make('small','','ma-muted'),state=failedRecoveries.get(job.id)||{busy:false,error:''};failedRecoveries.set(job.id,state);retry.type='button';notice.setAttribute('role','status');
   state.paint=()=>{retry.disabled=state.busy;retry.textContent=state.busy?tr('正在重试…','Retrying…'):tr('重试','Retry');notice.textContent=state.error;notice.hidden=!state.error;};
   retry.onclick=async()=>{if(state.busy)return;state.busy=true;state.error='';state.paint();try{const result=await api({action:'retry',jobId:job.id});if(!result.job?.id||result.job.retryOf!==job.id||result.job.contextId!==job.contextId)throw Error(tr('重试回执尚未确认；原消息已保留，请重试查询。','Retry receipt is unconfirmed. Your message is kept; retry to check.'));upsert(result.job);}catch(e){state.error=errorText(e,true);}finally{state.busy=false;state.paint();}};
   error.append(retry,notice);state.paint();
  }article.append(error);}
  if(job.codexSyncError)article.append(make('small',errorText(job.codexSyncError),'ma-muted'));
  if(job.resultIds?.length&&(job.contextId||job.meetingId)){const b=make('button',tr('查看成果 ↗','Open result ↗'),'ma-result');b.onclick=()=>openMeeting(job.resultContextId||job.contextId||job.meetingId,0,job.resultIds[0]);article.append(b);}
  if(job.state==='awaiting_confirmation'){
   article.append(make('p',String(job.proposal?.args?.text||job.proposal?.args?.body||job.proposal?.description||job.proposal?.name||''),'ma-proposal'));
   for(const [action,label]of [['confirm',tr('确认执行','Confirm')],['cancel',tr('取消','Cancel')]]){const b=make('button',label);b.onclick=()=>command(job,action);article.append(b);}
  }return article;
 }
 // Folding changes visibility only; the job and its Stop control keep their ownership.
 const chatFolds=new Map(),chatDismissed=new Map();let meetingChatJobs=[];
 try{const saved=JSON.parse(sessionStorage.getItem('citeside-meeting-view-v1')||'null');if(saved?.version===1&&saved.sessionId===currentScope){if(typeof saved.draft==='string')input.value=saved.draft;if(typeof saved.chatFolded==='boolean')chatFolds.set(currentScope,saved.chatFolded);}}catch{}
 window.thtCaptureMeetingChatState=()=>{persist();return {draft:input.value,chatFolded:!!chatFolds.get(currentScope),expandedIds:[window.thtLiveResearch?.state?.().expanded].filter(Boolean)};};
 function setMeetingChatFolded(folded){chatFolds.set(currentScope,!!folded);if(folded&&document.activeElement===input)input.blur?.();paintMeetingChat();}
 function meetingChatOutsideBlocked(target){
  if(String(window.getSelection?.()||'').trim()||promptEditing)return true;
  if(target?.closest?.('button,a,input,textarea,select,label,summary,[role="button"],[role="menuitem"],[contenteditable]:not([contenteditable="false"])'))return true;
  const focused=document.activeElement;
  if(focused?.matches?.('[contenteditable]:not([contenteditable="false"]),input')||focused?.matches?.('textarea')&&focused.value.trim())return true;
  return [...document.querySelectorAll('details[open]:not(.ma-reference),dialog[open],[role="menu"],[popover]:popover-open,[aria-expanded="true"][aria-haspopup="menu"]')].some(n=>!n.hidden&&n.getClientRects().length);
 }
 function paintMeetingChat(){
  const layer=document.querySelector('.mw-chat-layer');if(!layer||!meetingWorkspace())return;
  const latest=meetingChatJobs.at(-1),folded=!!chatFolds.get(currentScope),running=[...meetingChatJobs].reverse().find(active),shown=running||latest;
  let head=layer.querySelector('.ma-chat-head'),strip=layer.querySelector('.ma-chat-strip');
  if(!head){head=make('div','','ma-chat-head');const label=make('span'),collapse=make('button','','ma-chat-collapse');collapse.type='button';collapse.innerHTML='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';collapse.onclick=()=>setMeetingChatFolded(true);head.append(label,collapse);layer.insertBefore(head,conversation);}
  if(!strip){strip=make('div','','ma-chat-strip');const reopen=make('button','','ma-chat-reopen'),dismiss=make('button','×','ma-chat-dismiss');reopen.type=dismiss.type='button';reopen.onclick=()=>setMeetingChatFolded(false);dismiss.onclick=()=>{chatDismissed.set(currentScope,meetingChatJobs.at(-1)?.id);paintMeetingChat();};strip.append(reopen,dismiss);layer.insertBefore(strip,conversation);}
  layer.classList.toggle('mw-chat-folded',folded);head.hidden=folded||!latest;
  head.firstChild.textContent=tr('对话','Conversation');head.querySelector('button').setAttribute('aria-label',tr('收起对话','Collapse conversation'));
  const complete=latest&&['completed','planned'].includes(latest.state)&&latest.reply;
  strip.hidden=!folded||!shown||!running&&(!complete||chatDismissed.get(currentScope)===latest.id);
  strip.dataset.state=running?'processing':'completed';
  if(!strip.hidden){
   const title=String(shown.comment||shown.payload?.comment||tr('正在处理','Processing')).replace(/\s+/g,' ').trim(),button=strip.querySelector('.ma-chat-reopen');button.replaceChildren();
   button.append(make('span',running?'◌':'✓',running?'ma-orbit':''),make('span',title,'ma-chat-strip-title'));
   if(running){const value=shown.started||shown.created||shown.updated||'',stamp=typeof value==='number'?value:Date.parse(value);const seconds=Number.isFinite(stamp)?Math.max(0,Math.floor((Date.now()-stamp)/1000)):0;button.append(make('span',tr('已处理 '+seconds+' 秒','Processing for '+seconds+' seconds'),'ma-chat-elapsed'));}
   else button.append(make('span',String(shown.reply).replace(/[#*_`>]/g,'').replace(/\s+/g,' ').trim().slice(0,160),'ma-chat-summary'));
   strip.querySelector('.ma-chat-dismiss').hidden=!!running;strip.querySelector('.ma-chat-dismiss').setAttribute('aria-label',tr('关闭完成提示','Dismiss completion notice'));
  }
 }
 function syncChatCollections(){
  if(!meetingWorkspace())return;
  for(const state of chatCollections.values())if(state.job.contextId===currentScope){
   if(state.quote){if(state.item&&!state.busy&&!state.error)void readChatReceipt(state).then(()=>paintChatCollection(state)).catch(()=>{});}

  }
 }
 function placeChatLayer(){
  const meeting=document.body.classList.contains('meeting-workspace');
  const onHome=document.body.classList.contains('document-home-open');
  let layer=document.querySelector('.mw-chat-layer');
  const slot=document.getElementById('meeting-composer-slot');
  const dock=document.querySelector('.meeting-dock');
  if(meeting){
   if(!layer){layer=make('aside','','mw-chat-layer');document.body.append(layer);}
   conversation.hidden=false;sharedForm.hidden=false;
   conversation.classList.add('ma-meeting-chat');if(conversation.parentElement!==layer)layer.append(conversation);
   if(slot&&slot.parentElement!==layer)layer.append(slot);
  }else if(onHome){
   layer?.querySelectorAll('.ma-chat-head,.ma-chat-strip').forEach(node=>node.remove());
   layer?.classList.remove('mw-chat-folded');
   conversation.classList.remove('ma-meeting-chat');
   const footer=document.querySelector('#document-home .dh-footer');
   if(footer&&homeDock.parentElement!==footer)footer.replaceChildren(homeDock);
   if(conversation.parentElement!==homeDock)homeExpandedHead.after(conversation);
   if(sharedForm.parentElement!==homeDock)homeDock.append(sharedForm);
   if(slot&&dock&&slot.parentElement!==dock)dock.append(slot);
  }else{
   layer?.querySelectorAll('.ma-chat-head,.ma-chat-strip').forEach(node=>node.remove());
   layer?.classList.remove('mw-chat-folded');
   conversation.hidden=false;sharedForm.hidden=false;
   if(conversation.parentElement!==feed)feed.append(conversation);
   if(slot&&dock&&slot.parentElement!==dock)dock.append(slot);
  }
 }
 if(typeof MutationObserver==='function'&&document.body&&document.body.nodeType===1)new MutationObserver(()=>placeChatLayer()).observe(document.body,{attributes:true,attributeFilter:['class']});
 function render(){
  jobs.forEach(receiveCandidateRun);
  placeChatLayer();
  const conv=conversation,scrollHost=conv.parentElement===homeDock?conv:feed,bottom=scrollHost.clientHeight>0&&scrollHost.scrollHeight-scrollHost.scrollTop-scrollHost.clientHeight<70,top=scrollHost.scrollTop,scoped=[...jobs,...localJobs].filter(j=>!j.candidateId&&scopeKey({contextId:j.contextId||j.payload?.contextId||j.composer?.object?.contextId||''})===currentScope);
  if(currentScope==='home')syncHomeThreads(scoped);
  const all=currentScope==='home'?homeJobsForThread(activeHomeThread(),scoped):scoped;
  meetingChatJobs=all;paintMeetingChat();paintHomeReturnPill(all);
  const previous=new Map([...conv.querySelectorAll('.ma-job')].map(n=>[n.dataset.job,n]));
  if(!all.length){if(insights.children.length)conv.replaceChildren();else conv.replaceChildren(make('div',tr('我在听这场会。可以问「到现在定了什么」，也可以让我去查数据、写草稿。','I’m listening to this meeting. Ask “what’s been decided so far”, or have me look up data or draft something.'),'ma-empty'));}
  else{conv.querySelector('.ma-empty')?.remove();for(const j of all){const old=previous.get(j.id),signature=JSON.stringify({...j,payload:undefined,composer:undefined});if(old?.dataset.signature===signature){previous.delete(j.id);continue;}const fresh=row(j);fresh.dataset.signature=signature;for(const cls of ['.ma-reference'])if(old?.querySelector(cls)?.open&&fresh.querySelector(cls))fresh.querySelector(cls).open=true;if(old)old.replaceWith(fresh);else conv.append(fresh);previous.delete(j.id);}for(const n of previous.values())n.remove();}
  // In a meeting the conversation lives in the chat layer; on Home it scrolls inside the unified dock.
  if(conv.parentElement===feed||conv.parentElement===homeDock)scrollHost.scrollTop=bottom?scrollHost.scrollHeight:top;
  dock.replaceChildren();for(const j of all.filter(j=>active(j)||unseen(j)).slice(-3)){const b=make('button','','ma-task');b.append(make('span','◌','ma-orbit'),make('span',(j.comment||j.reply||tr('正在准备成果','Preparing a draft')).slice(0,24)));b.title=status(j);b.onclick=()=>{open();panel.querySelector('[data-job="'+CSS.escape(j.id)+'"]')?.scrollIntoView({block:'center'});};dock.append(b);}dock.hidden=!panel.hidden;
  syncChatCollections();resizeComposer();
  const count=all.filter(j=>active(j)||unseen(j)).length;fab.textContent='✦ MyAgent'+(count?' · '+count:'');
 }
 function matchesReceipt(job,entry){return !!(job?.id&&job.requestId&&job.requestId===entry.payload?.requestId&&scopeKey({contextId:job.contextId})===scopeKey({contextId:entry.payload.contextId}));}
 function reconcile(job){
  if(!job?.id||!job.requestId)return;
  const entry=localJobs.find(j=>matchesReceipt(job,j));if(!entry)return;
  localJobs=localJobs.filter(j=>j!==entry);if(sameDraft(entry))clearComposer();else persist();
 }
 // Replace the collection so in-flight GETs can detect a newer POST/stream receipt.
 function upsert(job){if(!job)return;reconcile(job);const index=jobs.findIndex(j=>j.id===job.id);jobs=index<0?[...jobs,job]:jobs.map((old,i)=>i===index?job:old);if(!panel.hidden)markSeen();render();}
 function recovered(){if(connectionError){$('.ma-status').textContent='';connectionError=false;}}
  async function refresh(){const requestedVersion=conversationVersion,requestedJobs=jobs,seq=refresh.sequence=(refresh.sequence||0)+1;try{const snapshot=await api();if(seq!==refresh.sequence||jobs!==requestedJobs)return;jobs=snapshot.jobs||[];jobs.forEach(reconcile);if(!panel.hidden)markSeen();if(conversationVersion===requestedVersion)recovered();render();}catch(error){if(seq!==refresh.sequence||jobs!==requestedJobs||conversationVersion!==requestedVersion)return;if(!$('.ma-status').textContent||connectionError){connectionError=true;$('.ma-status').textContent=errorText(error);}}}
 async function submit(entry){
  if(entry.submitting)return;entry.submitting=true;entry.state='queued';delete entry.error;
  if(sameDraft(entry))clearComposer();persist();render();$('.ma-status').textContent='';
  try{const result=await api(entry.payload);if(!matchesReceipt(result?.job,entry))throw Error(tr('发送结果尚未确认；消息已保留，可以重试查询。','Delivery is not confirmed. Your message is kept; retry to check.'));localJobs=localJobs.filter(j=>j!==entry);persist();upsert(result.job);}
  catch(error){
   // The stream may have delivered the receipt before the POST response was lost.
   if(jobs.some(j=>matchesReceipt(j,entry)))return;
   entry.state='failed';entry.error=errorText(error,true);
   if(!candidateTarget&&scopeKey({contextId:entry.payload.contextId})===currentScope&&!input.value.trim()&&!quote&&!materials.length){const saved=entry.composer;input.value=saved.text;quote=saved.quote;object=saved.object;materials=saved.materials;showMaterials();showQuote();sizeModel();resizeComposer();}
   if(candidateTarget||scopeKey({contextId:entry.payload.contextId})!==currentScope){const key=scopeKey({contextId:entry.payload.contextId}),draft=drafts[key];if(!draft?.text&&!draft?.quote&&!draft?.materials?.length){const saved=entry.composer;drafts[key]={text:saved.text,quote:saved.quote,object:saved.object,materials:saved.materials};}}
   persist();render();
  }finally{entry.submitting=false;}
 }
 async function send(){
  if(candidateTarget){stopDictation();await candidateTarget.submit();return;}
  const rawText=input.value.trim();if((!rawText&&!materials.length)||uploading)return;stopDictation();
  const text=rawText||tr('请查看并分析这些截图或附件。','Please inspect and analyze these screenshots or attachments.');
  if(document.body.classList.contains('document-home-open'))open();
  const previous=localJobs.find(j=>j.state==='failed'&&sameDraft(j));if(previous){await submit(previous);return;}
  const snapshot=JSON.parse(JSON.stringify(composer())),scopedObject=snapshot.object;
  const requestId=crypto.randomUUID(),contextId=scopedObject.contextId||(scopedObject.page==='meeting'?sessionStorage.getItem('tht-selected-meeting')||'':'');
  const pageContext={motherDocumentId:scopedObject.motherDocumentId||'',blockIds:scopedObject.blockIds||[],placement:scopedObject.placement||'replace',page:scopedObject.page||location.pathname,view:scopedObject.view||location.hash,projectId:scopedObject.projectId||'',objectId:scopedObject.objectId||'',sourceIds:scopedObject.sourceIds||[],targetSourceIds:scopedObject.targetSourceIds||[],quote,...(scopedObject.range?.length?{range:scopedObject.range}:{})};
  const payload={action:snapshot.develop?'develop':snapshot.object.targetSourceIds?.length?'run':'auto',comment:text,requestId,contextId,pageContext,lang:en()?'en':'zh',model:snapshot.model,effort:snapshot.effort,materialIds:snapshot.materials.map(m=>m.id)};
  if(currentScope==='home'){
   homeRequests.add(requestId);
   let t=activeHomeThread();
   if(!t||homeChatMode==='fresh'){
    const title=(rawText||(materials.length?tr('截图分析','Screenshot analysis'):tr('新对话','New chat'))).replace(/\s+/g,' ').trim().slice(0,22);
    t={id:'ht-'+crypto.randomUUID(),title,pinned:false,createdAt:Date.now(),updatedAt:Date.now(),requestIds:[requestId],jobIds:[]};
    homeThreadStore.threads.unshift(t);homeThreadStore.activeId=t.id;
   }else{
    t.requestIds.push(requestId);t.updatedAt=Date.now();
   }
   homeChatMode='expanded';homeHistoryOpen=false;hideHomeRowMenu();saveHomeThreads();
  }
  const entry={id:'local-'+requestId,contextId,created:new Date().toISOString(),comment:text,quote,materials:snapshot.materials||[],state:'queued',events:[],payload,composer:snapshot};if(document.body.classList.contains('meeting-workspace'))chatFolds.set(currentScope,false);localJobs.push(entry);render();if(conversation.parentElement===feed)feed.scrollTop=feed.scrollHeight;await submit(entry);
 }
 const materialPreviews=new Map();
 function showMaterials(){
  const host=$('.ma-materials');host.replaceChildren();
  for(const item of materials){
   const preview=materialPreviews.get(item.id),b=make('button',(preview?.app?.name||item.name)+' ×');b.type='button';
   const thumbUrl=preview?.url||(String(item.type||'').startsWith('image/')&&item.id?'/workspace-assistant/materials?id='+encodeURIComponent(item.id):'');
   if(thumbUrl){
    const img=make('img');img.src=thumbUrl;img.alt='';img.className='ma-material-preview';img.onerror=()=>{img.remove();};b.prepend(img);
    if(/^data:image\/png;base64,/.test(preview?.app?.icon||'')){const icon=make('img');icon.src=preview.app.icon;icon.alt='';icon.className='ma-material-app-icon';img.after(icon);}
   }
   b.setAttribute('aria-label',tr('移除 ','Remove ')+(preview?.app?.name||item.name));b.onclick=()=>{materialPreviews.delete(item.id);materials=materials.filter(m=>m!==item);showMaterials();persist();};host.append(b);
  }
  resizeComposer();
 }

 // ＋ menu: one entry, keyboard-complete (arrows/Home/End move, Esc returns focus to ＋), ARIA state on the button.
 {const add0=$('.ma-add');add0.setAttribute('aria-haspopup','menu');add0.setAttribute('aria-expanded','false');}
 // r7 capture actions share the canonical draft/material handlers; no bottom tabs.
 const captureScreen=async()=>{
  const scope=currentScope,target=candidateTarget?.key;let stream;
  try{
   if(!navigator.mediaDevices?.getDisplayMedia)throw Error(tr('请用系统截屏后，从「添加文件或照片」选择图片。','Take a system screenshot, then choose Add file or photo.'));
   stream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});
   const video=document.createElement('video');video.srcObject=stream;await video.play();
   const canvas=document.createElement('canvas');canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext('2d').drawImage(video,0,0);
   const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error(tr('截屏未完成，请重试。','Screenshot incomplete. Please retry.'));
   if(scope!==currentScope||target!==candidateTarget?.key)return;
   stream.getTracks().forEach(track=>track.stop());
   await uploadMaterials([new File([blob],'screenshot-'+Date.now()+'.png',{type:'image/png'})]);
  }catch(error){if(error.name!=='NotAllowedError')$('.ma-status').textContent=errorText(error);}
  finally{stream?.getTracks().forEach(track=>track.stop());}
 };
 function captureBridge(){return window.webkit?.messageHandlers?.liveMateWindow||null;}
 function captureError(error){
  const message=String(error?.error||error?.message||error);
  $('.ma-status').textContent=message.includes('SCREEN_RECORDING_PERMISSION_DENIED')?tr('请前往系统设置，开启Citeside的屏幕录制权限。','Enable screen recording for Citeside in System Settings.'):errorText(Error(message));
 }
 async function captureApplication(app){
  const scope=currentScope,target=candidateTarget?.key;
  try{
   const result=await captureBridge().postMessage({action:'captureApp',pid:app.pid});
   if(result?.error)throw Error(result.error);
   if(!/^data:image\/png;base64,/.test(result?.dataUrl||''))throw Error(tr('截屏未完成，请重试。','Screenshot incomplete. Please retry.'));
   const blob=new Blob([Uint8Array.from(atob(result.dataUrl.split(',')[1]),c=>c.charCodeAt(0))],{type:'image/png'});
   if(scope!==currentScope||target!==candidateTarget?.key)return;
   await uploadMaterials([new File([blob],app.name+'-'+Date.now()+'.png',{type:'image/png'})],app);
  }catch(error){if(scope===currentScope&&target===candidateTarget?.key)captureError(error);}
 }
 window.thtAddMenuItems=()=>[
  ...(currentScope==='home'?[[tr('查看历史对话','View conversation history'),()=>{showHomeHistory=true;render();open();},'history']]:[]),
  ...(currentScope==='home'&&archivedHomeDraft?[[tr('恢复上次草稿','Restore previous draft'),()=>{if(input.value.trim()||quote||materials.length){$('.ma-status').textContent=tr('请先发送或保存当前输入，再恢复上次草稿。','Send or save the current input before restoring the previous draft.');return;}const d=archivedHomeDraft;input.value=d.text||'';quote=d.quote||'';object=d.object||{};materials=d.materials||[];persist();showQuote();showMaterials();resizeComposer();input.focus();},'draft']]:[]),
  [tr('添加文件或照片','Add file or photo'),()=>$('.ma-file').click(),'file'],
  ...(window.thtTimeAnchors?.available()?[[tr('标记此刻','Mark this moment'),()=>window.thtTimeAnchors.add(),'mark']]:[])
 ];
 const addMenuIcons={
  file:'<path d="M16 9.5l-6 6a4 4 0 0 1-5.7-5.7l7-7a2.7 2.7 0 0 1 3.8 3.8l-7 7a1.3 1.3 0 0 1-1.8-1.8L12 6.5"/>',
  mark:'<path d="M5.5 2.5h9a1 1 0 0 1 1 1V17L10 13.8 4.5 17V3.5a1 1 0 0 1 1-1z" fill="currentColor" stroke="none"/>',
  shot:'<rect x="2.5" y="4" width="15" height="11" rx="2"/><path d="M7 18h6M10 15v3"/>',
  history:'<path d="M3 5v4h4M3.5 9a6.5 6.5 0 1 1 1 5M10 6v4l3 2"/>',
  draft:'<path d="M5 2.5h7l3 3V17H5zM8 9h4M8 12h4"/>'
 };
 // Keep pointer focus from expanding/repositioning the composer before click.
 $('.ma-add').onpointerdown=e=>{if(e.button===0)e.preventDefault();};
 $('.ma-add').onclick=e=>{
  e.stopPropagation();const add=$('.ma-add');let menu=document.querySelector('.ma-add-menu');
  if(menu){menu.__close?.();return;}
  menu=make('div','','ma-add-menu');menu.setAttribute('role','menu');
  let closed=false;
  const outside=ev=>{if(!menu.contains(ev.target)&&!add.contains(ev.target))close();};
  const close=(refocus)=>{closed=true;menu.remove();add.setAttribute('aria-expanded','false');document.removeEventListener('click',outside,true);document.removeEventListener('keydown',keys,true);if(refocus===true)add.focus();};
  const keys=k=>{const list=[...menu.querySelectorAll('[role=menuitem]')],i=list.indexOf(document.activeElement);if(k.key==='Escape'){k.preventDefault();k.stopPropagation();close(true);return;}const next={ArrowDown:(i+1)%list.length,ArrowUp:(i-1+list.length)%list.length,Home:0,End:list.length-1}[k.key];if(next!==undefined&&list.length){k.preventDefault();k.stopPropagation();list[next].focus();list[next].scrollIntoView({block:'nearest'});}else if(k.key==='Tab')close();};
  const row=([label,run,icon],app)=>{
   const b=make('button','','ma-add-row'),pic=make('span','','ma-add-icon '+(app?'ma-add-app-icon':'ma-add-'+icon));b.type='button';b.setAttribute('role','menuitem');pic.setAttribute('aria-hidden','true');
   if(app){const img=make('img');img.src=/^data:image\/png;base64,/.test(app.icon||'')?app.icon:'';img.alt='';pic.append(img);}
   else pic.innerHTML='<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'+addMenuIcons[icon]+'</svg>';
   b.append(pic,make('b',label));b.onclick=ev=>{ev.stopPropagation();close();run();};return b;
  };
  menu.__close=()=>close(true);
  const items=window.thtAddMenuItems();items.filter(i=>['history','draft'].includes(i[2])).forEach(i=>menu.append(row(i)));
  menu.append(make('div',tr('截取应用','Capture an app'),'ma-add-label'));
  const apps=make('div','','ma-capture-apps'),bridge=captureBridge();
  // Reserve the five-row slot before the reply: lower actions and menu bounds stay fixed.
  if(bridge)apps.classList.add('ma-capture-native');
  const fallback=()=>apps.replaceChildren(row([tr('截一张屏','Take a screenshot'),captureScreen,'shot']));
  if(!bridge)fallback();
  menu.append(apps,make('div','','ma-add-separator'));items.filter(i=>!['history','draft'].includes(i[2])).forEach(i=>menu.append(row(i)));
  (document.body||add.parentNode).append(menu);add.setAttribute('aria-expanded','true');
  const r=add.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(r.left,innerWidth-menu.offsetWidth-8))+'px';menu.style.bottom=Math.max(8,innerHeight-r.top+6)+'px';
  document.addEventListener('click',outside,true);document.addEventListener('keydown',keys,true);
  menu.querySelector('button')?.focus();
  const opening=document.activeElement,keepFocus=()=>{if(document.activeElement===opening||!menu.contains(document.activeElement))apps.querySelector('button')?.focus();};
  if(bridge)Promise.resolve().then(()=>bridge.postMessage({action:'listCaptureApps'})).then(result=>{
   if(closed)return;if(result?.error)throw Error(result.error);
   const list=Array.isArray(result?.apps)?result.apps:[];
   apps.replaceChildren();if(!list.length)fallback();else list.forEach(app=>apps.append(row([app.name,()=>captureApplication(app)],app)));keepFocus();
  }).catch(error=>{if(!closed){fallback();keepFocus();captureError(error);}});
 };
 $('.ma-file').onchange=()=>{const files=[...$('.ma-file').files];$('.ma-file').value='';return uploadMaterials(files);};
 async function uploadMaterials(files,captureAppInfo){const uploadKey=candidateTarget?.key||currentScope;if(materials.length+(pendingMaterialCounts.get(uploadKey)||0)+files.length>5){$('.ma-status').textContent=tr('一次最多 5 份材料','Up to 5 attachments');return;}let reserved=files.length;pendingMaterialCounts.set(uploadKey,(pendingMaterialCounts.get(uploadKey)||0)+reserved);uploading=pendingMaterialCounts.size>0;resizeComposer();$('.ma-status').textContent=tr('正在补充材料…','Adding attachments…');const release=count=>{const left=(pendingMaterialCounts.get(uploadKey)||0)-count;if(left>0)pendingMaterialCounts.set(uploadKey,left);else pendingMaterialCounts.delete(uploadKey);reserved-=count;uploading=pendingMaterialCounts.size>0;};try{for(const file of files){if(file.size>5*1024*1024)throw Error(tr('材料超过 5 MB','Attachment exceeds 5 MB'));const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('读取失败'));reader.readAsDataURL(file);});const result=await api({name:file.name,base64},'/workspace-assistant/materials');if(file.type.startsWith('image/'))materialPreviews.set(result.material.id,{url:'data:'+file.type+';base64,'+base64,app:captureAppInfo});if((candidateTarget?.key||currentScope)===uploadKey){materials.push(result.material);showMaterials();}else{const draft=drafts[uploadKey]||(drafts[uploadKey]={text:'',quote:'',object:{},materials:[]});draft.materials=[...(draft.materials||[]),result.material];}release(1);persist();}if((candidateTarget?.key||currentScope)===uploadKey&&!uploading)$('.ma-status').textContent='';}catch(e){if((candidateTarget?.key||currentScope)===uploadKey)$('.ma-status').textContent=e.message;}finally{release(reserved);resizeComposer();}};
 effortSelect.onchange=()=>{localStorage.setItem('tht-agent-effort:'+modelSelect.value,effortSelect.value);sizeModel();persist();};
 modelSelect.onchange=()=>{localStorage.setItem('tht-agent-model',modelSelect.value);sizeModel();persist();};
 let modelLoad=null,modelRetries=0;
 function loadModels(){if(modelLoad)return modelLoad;modelLoad=api(null,'/workspace-assistant/models').then(j=>{modelError=false;modelLoaded=true;modelRetries=0;const selected=localStorage.getItem('tht-agent-model')||'';modelCatalog=j.models||[];while(modelSelect.options.length>1)modelSelect.remove(1);for(const m of modelCatalog){if(!m.id)continue;const option=make('option',modelName(m));option.value=m.id;option.title=modelDescription(m);modelSelect.append(option);}if(selected&&!modelCatalog.some(m=>m.id===selected)){const option=make('option',selected+' · '+tr('待确认','unconfirmed'));option.value=selected;modelSelect.append(option);}modelSelect.value=selected;sizeModel();}).catch(()=>{modelError=true;sizeModel();if(modelRetries<1){modelRetries++;setTimeout(()=>{if(modelError)loadModels();},3000);}}).finally(()=>{modelLoad=null;});return modelLoad;}
 window.addEventListener('online',()=>{if(modelError){modelRetries=0;loadModels();}});
 loadModels();
 const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 // Native fallback uses a separate, local-only composer stream, never meeting audio.
 const dictationBridge=window.liveMateNativeWindow&&window.webkit?.messageHandlers?.liveMateWindow;
 class NativeDictation {
  constructor(){this.token=window.crypto.randomUUID();this.closed=false;this.timer=null;}
  request(action){return Promise.resolve().then(()=>dictationBridge.postMessage({action,token:this.token,lang:this.lang}));}
  accept(value){if(this.closed||value?.token!==this.token)return;if(value.error)throw Error(value.error);if(typeof value.text==='string')this.onresult?.({results:[[{transcript:value.text}]]});if(value.done){this.closed=true;clearTimeout(this.timer);this.onend?.();}}
  fail(error){if(this.closed)return;this.onerror?.({error:error.message||String(error)});}
  poll(){if(this.closed)return;this.request('dictationPoll').then(value=>{this.accept(value);if(!this.closed)this.timer=setTimeout(()=>this.poll(),200);}).catch(error=>this.fail(error));}
  start(){this.request('dictationStart').then(value=>{this.accept(value);if(!this.closed)this.poll();}).catch(error=>this.fail(error));}
  stop(){clearTimeout(this.timer);this.request('dictationStop').then(value=>this.accept(value)).catch(error=>this.fail(error));}
  abort(){if(this.closed)return;this.closed=true;clearTimeout(this.timer);this.request('dictationCancel').catch(()=>{});}
 }
 let dictationAttempt=0;
 function stopDictation(){dictationAttempt++;const previous=recognition;recognition=null;if(previous){try{previous.abort();}catch{}voiceIcon();}}
 // Keep both browser and native recognition on this Mac; otherwise offer macOS Dictation.
 let localSpeechReady=null;
 async function localSpeech(lang,install=false){
  if(!Speech)return false;
  try{
   if(typeof Speech.available==='function'){let state=await Speech.available({langs:[lang],processLocally:true});if(install&&(state==='downloadable'||state==='downloading')){$('.ma-status').textContent=tr('正在准备本机语音识别…','Preparing on-device speech recognition…');state=await Speech.install({langs:[lang],processLocally:true})?'available':state;}return state==='available';}
   if(typeof Speech.availableOnDevice==='function'){let state=await Speech.availableOnDevice(lang);if(install&&(state==='downloadable'||state==='downloading'))state=await Speech.installOnDevice(lang)?'available':state;return state==='available';}
  }catch{}
  return false;
 }
 const speechLang=()=>en()?'en-US':'zh-CN';
 localSpeech(speechLang()).then(ok=>{localSpeechReady=ok;});
 function startDictation(native=false){
  const r=native?new NativeDictation():new Speech();recognition=r;r.lang=speechLang();r.processLocally=true;r.interimResults=true;const original=input.value,voiceScope=currentScope;let lastValue=original,failed=false;
  const current=()=>recognition===r&&currentScope===voiceScope;
  r.onresult=e=>{if(!current())return;if(input.value!==lastValue){stopDictation();$('.ma-status').textContent=tr('已保留你的修改；听写已停止，检查后发送。','Your edits are kept. Dictation stopped; review, then send.');return;}lastValue=original+Array.from(e.results).map(x=>x[0].transcript).join('');input.value=lastValue;resizeComposer();persist();};
  r.onerror=e=>{if(!current())return;failed=true;stopDictation();$('.ma-status').textContent=tr('语音输入未成功，草稿已保留；可以重试：','Voice input failed. Draft kept; you can retry: ')+e.error;};
  r.onend=()=>{if(!current())return;recognition=null;voiceIcon();if(!failed)$('.ma-status').textContent=input.value.trim()?tr('听写结束，检查后发送。','Dictation finished. Review, then send.'):'';};
  try{r.start();voiceIcon(true);$('.ma-status').textContent=tr('正在听写 · 本机识别，再点一下停止','Dictating on this Mac · click again to stop');}catch(e){if(current()){recognition=null;voiceIcon();$('.ma-status').textContent=e.message;}}
 }
 $('.ma-voice').onclick=()=>{if(recognition){try{recognition.stop();}catch(e){stopDictation();$('.ma-status').textContent=tr('听写已停止，草稿已保留；可以重试。','Dictation stopped. Draft kept; you can retry.');}return;}
  if(localSpeechReady)return startDictation();
  const unavailable=()=>{$('.ma-status').textContent=tr('本机语音识别不可用。可连按两下 Fn 用 macOS 听写，文字会直接进输入框。','On-device speech recognition is unavailable. Press Fn twice to use macOS Dictation in the composer.');input.focus?.();};
  if(!Speech)return dictationBridge?startDictation(true):unavailable();
  const attempt=++dictationAttempt,scope=currentScope;return localSpeech(speechLang(),true).then(ok=>{if(attempt!==dictationAttempt||scope!==currentScope)return;localSpeechReady=ok;ok?startDictation():dictationBridge?startDictation(true):unavailable();});
 };
 $('.ma-form').onsubmit=e=>{e.preventDefault();const id=$('.ma-send').dataset.stop;if(id){const job=jobs.find(j=>j.id===id);if(job)command(job,'cancel');else resizeComposer();return;}send();};
 // Enter sends (matches the hint and Claude's composer); Shift+Enter inserts a newline; never send mid-IME composition.
 input.onkeydown=e=>{if(e.key!=='Enter'||e.shiftKey||e.isComposing||e.keyCode===229)return;e.preventDefault();$('.ma-form').requestSubmit?.();};
 api(null,'/workspace-assistant/preferences').then(j=>{developAllowed=!!j?.developerPreviewEnabled;}).catch(()=>{});
 async function connect(){
  clearTimeout(retryTimer);streamController?.abort();const controller=new AbortController();streamController=controller;
  try{const response=await fetch(address('/workspace-assistant/events'),{signal:controller.signal,cache:'no-store'});if(!response.ok)throw Error('HTTP '+response.status);
   connected=true;streamFailed=false;recovered();language();
   const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='';
   while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});let end;
    while((end=buffer.indexOf('\n\n'))>=0){const packet=buffer.slice(0,end);buffer=buffer.slice(end+2);if(!packet.startsWith('data: '))continue;const data=JSON.parse(packet.slice(6));if(data.jobs){jobs=data.jobs;jobs.forEach(reconcile);if(!panel.hidden)markSeen();render();}if(data.job)upsert(data.job);}
   }throw Error('disconnected');
  }catch(e){if(controller.signal.aborted)return;connected=false;streamFailed=true;language();refresh();retryTimer=setTimeout(connect,3000);}
 }
 // In the meeting workspace the panel is a fixed column, not a drawer: Escape never hides it
 // Escape that belongs to a dialog or menu is left alone.
 const pinnedColumn=()=>document.body.classList.contains('meeting-workspace');
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden&&!e.defaultPrevented&&!pinnedColumn()&&!document.querySelector('dialog[open]')&&!e.target?.closest?.('dialog,details[open]'))close();});
 window.addEventListener('beforeunload',()=>{persist();streamController?.abort();clearTimeout(retryTimer);clearInterval(composerWatch);clearInterval(composerReconcile);});
 window.addEventListener('tht-language-change',()=>{language();for(const n of panel.querySelectorAll('[data-signature]'))delete n.dataset.signature;render();});
 // Poll even with an open SSE connection: a missed terminal packet must not hold Stop.
 const composerReconcile=setInterval(refresh,30000);
 const composerWatch=setInterval(()=>{resizeComposer();paintMeetingChat();syncChatCollections();},1000);
 // Restore content, never an overlay. History and unsent drafts stay available
 // through the existing explicit conversation entry and shared composer.
 language();showMaterials();showQuote();resizeComposer();render();connect();
})();
