'use strict';
// 首次引导 v5（事中诸葛亮价值首屏 + 单卡日历 + 权限合页 + 三语 EN/ZH/JA + 有界漏斗埋点）。
// 权限状态不存，页面每次实时读 /native/permissions；?step=ai 保持设置页入口直达兼容。
(function(){
function detectLang(){
  let stored='';
  try{stored=localStorage.getItem('tht-ui')||localStorage.getItem('tht-board-lang')||'';}catch{}
  const raw=String(window.liveMateSystemLanguage||stored||(navigator.languages&&navigator.languages[0])||navigator.language||'en').toLowerCase();
  if(raw.startsWith('ja'))return 'ja';
  if(raw.startsWith('zh'))return 'zh';
  return 'en';
}
const LANG=detectLang();
document.documentElement.lang=LANG==='en'?'en':LANG==='ja'?'ja':'zh-CN';

const T={
zh:{
  title:'Citeside',later:'稍后再说',back:'返回',next:'继续',finish:'完成',
  w_t:'不做事后诸葛亮',w_l:'做你开会时的事中诸葛亮',
  w_vals:['开会当下，实时递上核查与好想法','不派机器人进会，会后自动写好纪要','越开会越懂你的项目，随时接得上话'],
  w_trial:'首次登录享 7 天 / 7 小时免费试用',w_go:'开始体验',w_time:'大约 1 分钟',
  c_t:'连接 Google 日历',c_l:'同步本周日程，会前提醒、一键入会开启事中参谋。',
  c_card_name:'Google 日历',c_card_desc:'仅读取你选择的日历与日程，不会读取邮箱。',
  c_sub:'Notion、Drive 与你的 AI（MCP）可随时在「设置」中按需连接。',
  c_unconfigured:'日历连接服务尚未配置，请稍后重试。',c_retry:'重试连接服务',
  c_go:'连接 Google 日历',c_skip:'先跳过，之后再连',c_ok_t:'已连接日历',c_today:'今天的会',c_go2:'继续',
  c_bl_t:'日历授权未完成',c_bl_n:'授权被取消或受到 Google / Workspace 限制。请核对官方页面的提示；不要绕过未验证应用或组织限制。',c_other:'换一个账号',
  g_wait_t:'在浏览器里完成授权',g_wait_l:'浏览器已打开 Google 授权页。',g_wait_w:'完成后自动回到这里',g_c:['选择账号','确认只读权限','返回 Citeside'],g_cancel:'取消',g_again:'没看到页面？重新打开',
  p_t:'开启录音权限，随时开第一场会',p_l:'一页完成核心权限；两项均已开启时会自动跳过。',
  m_t:'麦克风权限',m_l:'用于记录你的发言与线下当面讨论。',m_path:'隐私与安全性 › 麦克风 › Citeside',m_live:'麦克风已就绪',
  s_t:'线上会议声音与画面',s_l:'记录对方发言与共享内容，仅需勾选一项。',s_path:'屏幕与系统录音 › CitesideCapture',s_live:'线上会议音频已就绪',
  p_allow:'允许',p_open_set:'打开系统设置',p_waiting:'等待系统设置授权…',p_allowed:'已允许',
  p_note:'仅在你开始记录后使用麦克风与系统声音，结束记录后立即停止。请获得会上其他人的同意后再录音。',
  p_enter:'进入 Citeside',
  ai_t:'让熟悉你的 AI 介绍你',ai_l:'使用这台 Mac 上支持 MCP 的 AI 客户端。云端 AI 是否能连接取决于客户端能力。',
  ai_prompt:"请使用你已知且可靠的长期记忆，以及我已授权的资料，整理我的身份与职责、项目目标与阶段、伙伴与术语、决策约束、会议偏好；每组注明来源与最近确认时间，未知就写未知。不要从当前目录、仓库、AGENTS 或通用 AI 规则推断我的职业或项目事实，不编造，不自行翻邮箱补资料。资料不足时先同步明确已知，只问一个最关键的问题。建议交给熟悉我工作的 AI；新的聊天未必拥有长期记忆。通过已有的 Citeside MCP 连接调用 profile_sync，不重建或撤销当前授权。",
  ai_copy:'复制连接配置',ai_prompt_copy:'复制背景说明',ai_insufficient:'已收到资料 · 内容仍不足',ai_missing:'尚缺：',ai_config:'MCP 连接配置',ai_copied:'已复制',ai_n:'接收 AI 同步的个人背景；授权你的 AI 读取这台 Mac 上的会议纪要与研究报告。',
  ai_schedule:'你的 AI 支持定时任务时，可设置定期同步；也可随时在对话中要求同步。',ai_status:'连接状态',ai_connected:'已连接',ai_disconnected:'已断开，后续读取与同步已撤销。',ai_not_connected:'未连接',
  ai_waiting:'等待你的 AI 连接。请重启本机 MCP 客户端使已写入的配置生效。',ai_add:'在本机支持 MCP 的 AI 客户端中添加 Citeside。',ai_pending:'尚未收到个人背景。请在你的 AI 中发送同步指令。',ai_received:'已收到个人背景',
  ai_background:'来自你的 AI · 个人背景',ai_last_sync:'最近同步：',ai_retained:'已收到的背景保留在这台 Mac 上。',ai_revoke:'断开连接将撤销后续读写权限。',ai_disconnect:'断开连接',
  ai_fail:'连接状态暂时无法读取，请稍后重试。',ai_connect_fail:'连接配置未生成，请重试。',ai_copy_fail:'未能复制。下方配置已保留，可选中文字后按 ⌘C，或再点一次复制。',ai_disconnect_fail:'未能断开，后续读写权限尚未撤销，请重试。',
  t_sf_t:'试听还没停下来',t_sf_n:'停止请求没有成功，麦克风可能还在听。点「再停一次」重试，停下后才会离开这一页。',t_sf_go:'再停一次',
  recovery_t:'先结束上次的试听',recovery_n:'上次的试听尚未确认结束。请先停止，再继续设置。',recovery_unknown:'无法确认上次的录音状态，请重试检查。',recovery_check:'重试检查',recovery_busy:'正在确认停止…',
  save_fail:'进度没保存上，下次打开可能要从这一步重来。',save_retry:'重试保存',save_leave:'不保存，直接离开',
  ai_manual_entry:'手动补充称呼和岗位',ai_names_ph:'全名、常用名、英文名',ai_roles_ph:'岗位或职能关键词',ai_owner_save:'保存称呼和岗位',ai_owner_fail:'称呼或岗位没保存上，请检查后再试。'
},
en:{
  title:'Citeside',later:'Not now',back:'Back',next:'Continue',finish:'Done',
  w_t:'Insight during the call, not after.',w_l:'Your real-time in-meeting strategist.',
  w_vals:['Live fact-checks and ideas while you talk','No bot in your call. Notes write themselves.','Remembers your projects across meetings'],
  w_trial:'7-day / 7-hour free trial · No card needed',w_go:'Get started',w_time:'About 1 minute',
  c_t:'Connect Google Calendar',c_l:'One click to join meetings and start your in-meeting strategist.',
  c_card_name:'Google Calendar',c_card_desc:'Read-only access to chosen calendars. Email is never read.',
  c_sub:'Notion, Drive, and your AI (MCP) can be connected anytime in Settings.',
  c_unconfigured:'Calendar connection is not configured. Try again later.',c_retry:'Retry connection service',
  c_go:'Connect Google Calendar',c_skip:'Skip for now',c_ok_t:'Calendar connected',c_today:'Today',c_go2:'Continue',
  c_bl_t:'Calendar authorization incomplete',c_bl_n:'Authorization was cancelled or restricted by Google or Workspace. Review the official page. Do not bypass unverified-app or organization restrictions.',c_other:'Use another account',
  g_wait_t:'Finish in your browser',g_wait_l:'Google’s sign-in page is open in your browser.',g_wait_w:'We’ll continue automatically when you’re done',g_c:['Choose account','Approve read-only access','Return to Citeside'],g_cancel:'Cancel',g_again:'Don’t see it? Open again',
  p_t:'Allow audio access',p_l:'One quick step for your first meeting. Auto-skips if already enabled.',
  m_t:'Microphone',m_l:'Captures your voice and in-person discussions.',m_path:'Privacy & Security › Microphone › Citeside',m_live:'Microphone ready',
  s_t:'Online meeting audio & screen',s_l:'Captures remote speakers & shared slides — only one toggle needed.',s_path:'Screen & System Audio › CitesideCapture',s_live:'Meeting audio ready',
  p_allow:'Allow',p_open_set:'Open Settings',p_waiting:'Waiting for System Settings…',p_allowed:'Allowed',
  p_note:'Used only after you start recording and stops when you finish. Obtain participants’ consent before recording.',
  p_enter:'Enter Citeside',
  ai_t:'Let an AI familiar with you introduce you',ai_l:'Use a local AI client on this Mac that supports MCP. Cloud AI access depends on client capabilities.',
  ai_prompt:"Use only reliable long-term memory you already have and materials I authorized. Summarize my identity and responsibilities, project goals and stage, partners and terminology, decision constraints, and meeting preferences. State sources and last confirmation dates; mark unknowns. Never infer my profession or project facts from the working directory, repository, AGENTS or general AI rules. Do not invent facts or search email on your own. Sync explicitly known facts first, then ask only the most important question. Send this to an AI familiar with my work; a fresh chat may have no long-term memory. Call profile_sync through the existing Citeside MCP connection without recreating or revoking its grant.",
  ai_copy:'Copy connection configuration',ai_prompt_copy:'Copy background instructions',ai_insufficient:'Material received · More background needed',ai_missing:'Still missing: ',ai_config:'MCP connection configuration',ai_copied:'Copied',ai_n:'Receive personal background from your AI and allow it to read meeting notes and research reports on this Mac.',
  ai_schedule:'If your AI supports scheduled tasks, you can set up recurring sync or ask it to sync anytime.',ai_status:'Connection status',ai_connected:'Connected',ai_disconnected:'Disconnected. Further reading and syncing are revoked.',ai_not_connected:'Not connected',
  ai_waiting:'Waiting for your AI to connect. Restart your local MCP client to apply the written config.',ai_add:'Add Citeside in the MCP settings of a local MCP client.',ai_pending:'No personal background received yet. Ask your AI to sync it.',ai_received:'Personal background received',
  ai_background:'Personal background from your AI',ai_last_sync:'Last sync: ',ai_retained:'Previously received background stays on this Mac.',ai_revoke:'Disconnecting revokes further read and write access.',ai_disconnect:'Disconnect',
  ai_fail:'Connection status is unavailable. Try again shortly.',ai_connect_fail:'Could not generate the connection configuration. Try again.',ai_copy_fail:'Could not copy. The configuration is kept below: select it and press ⌘C, or copy again.',ai_disconnect_fail:'Could not disconnect. Further read and write access has not been revoked. Try again.',
  t_sf_t:'The trial hasn’t stopped',t_sf_n:'The stop request failed, so the microphone may still be listening. Press “Stop again”; this page stays open until it stops.',t_sf_go:'Stop again',
  recovery_t:'Finish the previous trial first',recovery_n:'The previous trial has not been confirmed stopped. Stop it before continuing setup.',recovery_unknown:'Unable to confirm the previous recording state. Check again.',recovery_check:'Check again',recovery_busy:'Confirming stop…',
  save_fail:'Your progress wasn’t saved. Next time you may start from this step again.',save_retry:'Retry',save_leave:'Leave without saving',
  ai_manual_entry:'Add your names and role yourself',ai_names_ph:'Full name, nickname, English name',ai_roles_ph:'Role or function',ai_owner_save:'Save names and role',ai_owner_fail:'Names or role were not saved. Check them and try again.'
},
ja:{
  title:'Citeside',later:'あとで',back:'戻る',next:'次へ',finish:'完了',
  w_t:'会議の「いま」を助ける参謀',w_l:'終わった後ではなく、話しているその場で支えます',
  w_vals:['会話に合わせて事実確認とヒントを即時提示','ボット参加なしで、議事録とToDoを自動作成','プロジェクトの文脈を記憶し、使うほど賢く'],
  w_trial:'7日間 / 7時間 無料トライアル・カード不要',w_go:'はじめる',w_time:'約1分で完了',
  c_t:'Google カレンダーを接続',c_l:'予定からワンクリックで参加し、リアルタイム参謀を開始できます。',
  c_card_name:'Google カレンダー',c_card_desc:'選択したカレンダーのみ読み取り専用で同期します。メールは読みません。',
  c_sub:'Notion・Drive・AI連携（MCP）は設定からいつでも追加できます。',
  c_unconfigured:'カレンダー連携サービスが未設定です。後ほどお試しください。',c_retry:'再試行',
  c_go:'Google カレンダーを接続',c_skip:'今はスキップ',c_ok_t:'カレンダーを接続しました',c_today:'今日の予定',c_go2:'次へ',
  c_bl_t:'カレンダー認証が完了しませんでした',c_bl_n:'認証がキャンセルされたか、組織の制限によりブロックされました。公式画面の案内をご確認ください。',c_other:'別のアカウントを使う',
  g_wait_t:'ブラウザで認証を完了',g_wait_l:'ブラウザで Google 認証ページを開きました。',g_wait_w:'完了すると自動で戻ります',g_c:['アカウント選択','読み取り権限を許可','Citesideへ戻る'],g_cancel:'キャンセル',g_again:'開かない場合は再度開く',
  p_t:'録音権限を許可',p_l:'1画面で準備完了。許可済みの場合は自動でスキップします。',
  m_t:'マイク権限',m_l:'あなたの声や対面会議の音声を記録します。',m_path:'プライバシーとセキュリティ › マイク › Citeside',m_live:'マイク準備完了',
  s_t:'オンライン会議の音声と画面',s_l:'相手側の音声と共有画面を記録します（1項目のみ有効化）。',s_path:'画面とシステムオーディオ › CitesideCapture',s_live:'会議音声の準備完了',
  p_allow:'許可する',p_open_set:'システム設定を開く',p_waiting:'システム設定の確認を待機中…',p_allowed:'許可済み',
  p_note:'録音開始を押した時のみ動作し、終了と同時に停止します。録音前に参加者の同意を得てください。',
  p_enter:'Citesideをはじめる',
  ai_t:'あなたのAIに自己紹介してもらう',ai_l:'このMac上のMCP対応AIクライアントを使用します。',
  ai_prompt:"信頼できる長期記憶と許可済みの資料のみを使って、私の役割・プロジェクト目標・関係者・制約・会議の好みを整理し、既存のCiteside MCP接続で profile_sync を呼び出してください。",
  ai_copy:'接続設定をコピー',ai_prompt_copy:'指示文をコピー',ai_insufficient:'受信済み・情報不足',ai_missing:'不足：',ai_config:'MCP 接続設定',ai_copied:'コピーしました',ai_n:'AIから背景情報を受け取り、このMac上の議事録やリサーチの参照を許可します。',
  ai_schedule:'定期同期に対応したAIではスケジュール実行も可能です。',ai_status:'接続状態',ai_connected:'接続済み',ai_disconnected:'切断しました。今後のアクセスは無効化されました。',ai_not_connected:'未接続',
  ai_waiting:'接続待機中。設定を反映するためAIクライアントを再起動してください。',ai_add:'MCP対応AIクライアントにCitesideを追加してください。',ai_pending:'まだ背景情報を受信していません。',ai_received:'背景情報を受信しました',
  ai_background:'AIからの個人背景',ai_last_sync:'最終同期：',ai_retained:'受信済みの背景はこのMacに保存されます。',ai_revoke:'切断すると以降の読み書き権限が取り消されます。',ai_disconnect:'切断',
  ai_fail:'接続状態を読み取れませんでした。',ai_connect_fail:'設定を生成できませんでした。再試行してください。',ai_copy_fail:'コピーできませんでした。下の設定を選択して ⌘C でコピーしてください。',ai_disconnect_fail:'切断できませんでした。再試行してください。',
  t_sf_t:'テスト録音が停止していません',t_sf_n:'停止に失敗しました。「もう一度停止」を押してください。',t_sf_go:'もう一度停止',
  recovery_t:'前回のテスト録音を終了してください',recovery_n:'前回の録音の停止が確認できていません。停止してから続行してください。',recovery_unknown:'録音状態を確認できませんでした。再確認してください。',recovery_check:'再確認',recovery_busy:'停止を確認中…',
  save_fail:'進捗を保存できませんでした。次回ここから再開する場合があります。',save_retry:'再保存',save_leave:'保存せず進む',
  ai_manual_entry:'名前と役割を手動で入力',ai_names_ph:'氏名・呼び名・英語名',ai_roles_ph:'役職や担当',ai_owner_save:'保存',ai_owner_fail:'保存できませんでした。確認して再試行してください。'
}}[LANG];
document.title=T.title;

const IC={
  calbig:'<svg viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="17" rx="3.5" fill="#EEF4FF" stroke="#3B82F6" stroke-width="1.8"/><path d="M3 9h18" stroke="#3B82F6" stroke-width="1.8"/><path d="M8 2.5v3M16 2.5v3" stroke="#3B82F6" stroke-width="1.8" stroke-linecap="round"/><text x="12" y="17.5" text-anchor="middle" font-size="8.5" font-weight="700" fill="#1D4ED8">24</text></svg>',
  back:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3 5 8l5 5"/></svg>',
  logo:'<svg class="brand-hero-logo" viewBox="0 0 64 64" fill="none" aria-hidden="true"><defs><linearGradient id="cg-onb" x1="4" y1="4" x2="60" y2="60" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#98A8FF"/><stop offset="52%" stop-color="#7B6BFF"/><stop offset="100%" stop-color="#5845E0"/></linearGradient></defs><rect width="64" height="64" rx="16" fill="url(#cg-onb)"/><path d="M44.5 18.5C40.7 14.9 35.6 12.8 30 12.8C18.8 12.8 10 21.4 10 32C10 42.6 18.8 51.2 30 51.2C35.6 51.2 40.7 49.1 44.5 45.5" stroke="#FFFFFF" stroke-width="7.2" stroke-linecap="round"/><path d="M47 21.5L49.3 28.7L56.5 31L49.3 33.3L47 40.5L44.7 33.3L37.5 31L44.7 28.7L47 21.5Z" fill="#FFFFFF"/></svg>',
  mic:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
  sys:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2.5"/><path d="M8 20h8M12 16v4M9.5 9v2M12 7.5v5M14.5 9v2"/></svg>',
  spark:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.1 6.4L20.5 10.5l-6.4 2.1L12 19l-2.1-6.4-6.4-2.1 6.4-2.1z"/></svg>',
  shield:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v5c0 5-3.4 8.6-7 10-3.6-1.4-7-5-7-10V6l7-3z"/><path d="m9 12 2 2 4-4"/></svg>',
  layers:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 9 4.5-9 4.5-9-4.5L12 3z"/><path d="m3 12 9 4.5 9-4.5"/><path d="m3 16.5 9 4.5 9-4.5"/></svg>',
  check:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3.5 8.5 3 3 6-7"/></svg>',
  excl:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 4v5M8 12v.01"/></svg>',
  lock:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="7" width="9" height="6.5" rx="1.5"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/></svg>',
  info:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 7v4M8 5v.01"/></svg>'
};

const STEPS=['welcome','cal','perms','done'],DONE=STEPS.indexOf('done');
const KIND={mic:'microphone',sys:'screen'};
const boot=window.THT_BOOT||{};
const saved=boot.onboarding||{};
const qp=new URLSearchParams(location.search||'');
const directIntro=qp.get('step')==='ai';
const savedStep=Number.isInteger(saved.step)?Math.max(0,saved.step):0;
const resumeStep=saved.version>=5?(saved.finished?savedStep:Math.min(savedStep,DONE-1))
  :saved.version===4?[0,1,2,2,3][Math.min(4,savedStep)]
  :saved.version===3?[0,1,2,2,2,3][Math.min(5,savedStep)]
  :saved.version===2?[0,1,2,2,2,2,3][Math.min(6,savedStep)]
  :[0,2,2,2,2,3][Math.min(5,savedStep)];
const fromAuth=qp.get('from')==='auth'&&boot.cloudTrial?.status==='signed_in';
const initialStep=fromAuth&&resumeStep===0?1:Math.min(resumeStep,DONE-1);
const S={step:initialStep,cal:'idle',calConfigured:true,calEmail:'',calEvents:[],calEventsLoaded:false,mic:'idle',sys:saved.sys==='skipped'?'skipped':'idle',
  ask:{mic:false,sys:false,mainScreen:false,helperScreen:false},mainScreen:'unknown',helperScreen:'unknown',known:false,recovery:'checking',pendingLeave:null,
  ai:{items:[],msg:'',copied:false,loaded:false,busy:false,state:null,install:null,requestId:null,copyText:'',copyFailed:false,copying:false}};
const curKey=()=>directIntro?'ai':STEPS[S.step];
const app=document.getElementById('app');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let timers=[],leaving=false;
const clearT=()=>{timers.forEach(clearTimeout);timers=[];};

function trackFunnel(event,meta={}){
  try{
    fetch('/setup/funnel',{method:'POST',headers:{'content-type':'application/json','x-tht-token':boot.relayToken||''},body:JSON.stringify({event,lang:LANG,...meta}),keepalive:true}).catch(()=>{});
  }catch{}
}

let unsaved=null,saveFail=null;
async function persist(patch){
  if(directIntro)return true;
  const body={...(unsaved||{}),...patch};
  let ok=false;
  try{const r=await fetch('/setup/onboarding',{method:'POST',headers:{'content-type':'application/json','x-tht-token':boot.relayToken||''},body:JSON.stringify(body)});ok=r.ok;}catch(e){}
  unsaved=ok?null:body;return ok;
}
let trialLive=false,stopP=null;
const STOP_POLLS=30,sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function trialState(){try{const r=await fetch('/native/trial/state',{cache:'no-store'});return r.ok?await r.json():null;}catch(e){return null}}
async function stopOnce(){
  let j=null;
  try{const r=await fetch('/native/trial/stop',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});const b=await r.json().catch(()=>({}));j=r.ok&&b.ok!==false?b:null;}catch(e){}
  for(let i=0;j&&j.state!=='done'&&j.state!=='failed'&&i<STOP_POLLS;i++){await sleep(500);j=await trialState()||j;}
  if(j?.state==='done'){trialLive=false;return true;}
  return false;
}
function stopRemote(){return stopP||(stopP=stopOnce().finally(()=>{stopP=null}));}
async function recoverTrial(){
  if(S.recovery==='stopping')return;
  S.recovery='stopping';render();
  if(!await stopRemote()){S.recovery='failed';render();return;}
  S.recovery=null;
  if(S.pendingLeave){const patch=S.pendingLeave;S.pendingLeave=null;return leave(patch);}
  if(saved.finished&&!directIntro){location.replace('index.html');return;}
  resumeOnboarding();
}
async function checkLegacyTrial(){
  S.recovery='checking';render();
  const j=await trialState();
  if(j?.state==='done'){trialLive=false;S.recovery=null;}
  else if(j&&['live','starting','stopping','failed'].includes(j.state)){trialLive=true;S.recovery=j.state==='failed'?'failed':'active';}
  else S.recovery='unknown';
  if(S.recovery)render();return !S.recovery;
}
async function leave(patch,{force=false}={}){
  if(leaving||S.recovery==='checking'||S.recovery==='unknown')return;
  if(trialLive){S.pendingLeave=patch;return recoverTrial();}
  leaving=true;stopCalendar();stopAi();
  if(!await persist(patch)&&!force){leaving=false;saveFail={patch,leave:true};render();return;}
  if(patch.finished)trackFunnel('onboarding_done');
  location.replace('index.html');
}
function recoveryStep(){
  const waiting=S.recovery==='checking'||S.recovery==='stopping',unknown=S.recovery==='unknown';
  return hero(IC.mic)+`<h1 id="h">${T.recovery_t}</h1><p class="lead">${unknown?T.recovery_unknown:S.recovery==='failed'?T.t_sf_n:T.recovery_n}</p><div class="spacer"></div><div class="acts">${waiting?`<span class="wait" role="status"><span class="spin"></span>${T.recovery_busy}</span>`:`<button class="btn lg pri" data-act="${unknown?'checktrial':'retrystop'}">${unknown?T.recovery_check:T.t_sf_go}</button>`}</div>`;
}

const visibleSteps=()=>STEPS;
function dots(){if(directIntro)return '';const visible=visibleSteps(),index=visible.indexOf(curKey());return `<div class="dots" aria-label="${index+1} / ${visible.length}">${visible.map((_,i)=>`<i class="${i===index?'on':i<index?'done':''}"${i===index?' aria-current="step"':''}></i>`).join('')}</div>`}
function shell(inner){
  const back=!S.recovery&&!directIntro&&S.step>0&&S.step<DONE?`<button class="ib" data-act="back" aria-label="${T.back}">${IC.back}${T.back}</button>`:'<span></span>';
  const later=!S.recovery&&(directIntro||S.step<DONE)?`<button class="ib" data-act="later">${T.later}</button>`:'<span></span>';
  return `<div class="stage"><section class="win" role="dialog" aria-modal="true" aria-labelledby="h"><div class="whead"><span class="l">${back}</span>${dots()}<span class="r">${later}</span></div><div class="wbody">${saveFail?saveNote():''}${inner}</div></section></div>`;
}
const saveNote=()=>`<div class="note warn" role="alert">${IC.info}<span>${T.save_fail} <button class="btn link" data-act="retrysave">${T.save_retry}</button>${saveFail.leave?`<button class="btn link" data-act="leaveunsaved">${T.save_leave}</button>`:''}</span></div>`;
const hero=(ic,badge)=>`<div class="hero">${ic}${badge==='ok'?`<span class="badge ok">${IC.check}</span>`:badge==='no'?`<span class="badge no">${IC.excl}</span>`:''}</div>`;

let calIv=null,calEpoch=0,calBusy=false;
function stopCalendar(){calEpoch++;if(calIv){clearInterval(calIv);calIv=null;}}
const calendarHeaders=()=>({'content-type':'application/json','x-tht-token':boot.relayToken||''});
const calendarBlocked=j=>/access_denied|test_user|testing|org_internal|admin_policy_enforced/i.test(j.authError||j.error||'');
async function calendarStatus(){
  try{const r=await fetch('/google/calendar',{cache:'no-store',headers:calendarHeaders()});return r.ok?await r.json():null;}catch(e){return null;}
}
async function calendarEvents(epoch){
  S.calEventsLoaded=true;
  try{
    const r=await fetch('/meeting-board?calendar=1&refresh=authorization',{cache:'no-store',headers:calendarHeaders()});
    if(!r.ok)return;const j=await r.json();
    if(epoch!==calEpoch||j.error)return;
    const today=new Date().toDateString();
    S.calEvents=(Array.isArray(j.events)?j.events:[]).filter(e=>new Date(e.start).toDateString()===today).sort((a,b)=>new Date(a.start)-new Date(b.start));
    if(curKey()==='cal')render();
  }catch(e){}
}
function applyCalendar(j){
  if(!j)return;
  S.calConfigured=j.configured!==false;S.calEmail=j.email||'';
  S.cal=j.pending?'waiting':calendarBlocked(j)?'blocked':j.connected?'granted':'idle';
}
function watchCalendar(){
  if(calIv)return;
  const epoch=calEpoch;let reading=false;
  calIv=setInterval(async()=>{
    if(reading||epoch!==calEpoch)return;reading=true;
    const j=await calendarStatus();reading=false;
    if(epoch!==calEpoch||curKey()!=='cal'||!j)return;
    applyCalendar(j);
    if(!S.calConfigured){stopCalendar();render();return;}
    if(!j.pending){stopCalendar();if(S.cal==='granted'){trackFunnel('cal_connect');calendarEvents(calEpoch);}}
    render();
  },2000);
}
async function calendarConnect(){
  if(calBusy)return;calBusy=true;stopCalendar();const epoch=calEpoch;
  S.cal='waiting';S.calEvents=[];S.calEventsLoaded=false;render();
  try{
    const r=await fetch('/google/calendar/connect',{method:'POST',headers:calendarHeaders(),body:JSON.stringify({lang:LANG})});
    const j=await r.json();
    if(epoch!==calEpoch)return;
    if(!r.ok||j.ok===false){S.cal=calendarBlocked(j)?'blocked':'idle';render();return;}
    watchCalendar();
  }catch(e){if(epoch===calEpoch){S.cal='idle';render();}}
  finally{calBusy=false;}
}
function calendarMeetings(){
  return S.calEvents.map(e=>`<div class="m"><time>${esc(new Date(e.start).toLocaleTimeString(LANG,{hour:'2-digit',minute:'2-digit',hour12:false}))}</time><b>${esc(e.title||'')}</b></div>`).join('');
}

function calStep(){
  if(!S.calConfigured)return hero(IC.logo)+`<h1 id="h">${T.c_t}</h1><p class="lead">${T.c_unconfigured}</p><div class="spacer"></div><div class="acts"><button class="btn sec" data-act="calretry">${T.c_retry}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
  if(S.cal==='granted')return hero(IC.logo,'ok')+`<h1 id="h">${T.c_ok_t}</h1><span class="acct">${esc(S.calEmail)}</span><div class="mlist">${calendarMeetings()}</div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="next">${T.c_go2}</button></div>`;
  if(S.cal==='blocked')return hero(IC.logo,'no')+`<h1 id="h">${T.c_bl_t}</h1><div class="note warn">${IC.info}<span>${T.c_bl_n}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="calgo">${T.c_other}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
  if(S.cal==='waiting')return hero(IC.logo)+`<h1 id="h">${T.g_wait_t}</h1><p class="lead">${T.g_wait_l}</p><div class="gchain">${T.g_c.map((c,i)=>`${i?'<span>›</span>':''}<b>${c}</b>`).join('')}</div><span class="wait" style="margin-top:20px"><span class="spin"></span>${T.g_wait_w}</span><div class="spacer"></div><div class="acts"><button class="btn link" data-act="gagain">${T.g_again}</button><button class="btn ghost" data-act="calcancel">${T.g_cancel}</button></div>`;
  return hero(IC.logo)+`<h1 id="h">${T.c_t}</h1><p class="lead">${T.c_l}</p><div class="cal-single"><div class="cal-single-top"><div class="cal-icon">${IC.calbig}</div><div class="cal-single-meta"><div class="cal-single-name">${T.c_card_name}</div><p class="cal-single-desc">${T.c_card_desc}</p></div></div></div><p class="cal-single-sub">${T.c_sub}</p><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="calgo">${T.c_go}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
}

function permsStep(){
  const row=(kind,ic,title,desc,appName,path,liveText)=>{
    const st=S[kind],ok=st==='granted',denied=st==='denied',waiting=st==='waiting';
    const act=denied||waiting?'openset':'ask';
    const btnCls=ok?'btn ok-pill':'btn pri';
    const btnLabel=ok?`${IC.check}${T.p_allowed}`:denied?T.p_open_set:waiting?`<span class="spin"></span>${T.p_waiting}`:T.p_allow;
    return `<div class="perm-row${ok?' is-ok':''}"><div class="perm-head"><div class="value-ic${ok?' emerald':''}">${ic}</div><div class="perm-info"><strong>${title}</strong><span>${desc}</span></div><button type="button" class="${btnCls}" data-act="${act}" data-k="${kind}"${ok?' disabled':''}>${btnLabel}</button></div><div class="mac-guide" aria-hidden="true"><span class="mac-guide-app"><span class="mac-guide-dot">C</span>${appName}</span>${ok?`<span class="meter-bar"><span class="meter-bars"><i></i><i></i><i></i><i></i></span>${liveText}</span>`:`<span>${path}</span>`}<span class="mac-toggle"></span></div></div>`;
  };
  return hero(IC.logo,S.mic==='granted'&&S.sys==='granted'?'ok':'')+`<h1 id="h">${T.p_t}</h1><p class="lead">${T.p_l}</p><div class="perm-list">${row('mic',IC.mic,T.m_t,T.m_l,'Citeside',T.m_path,T.m_live)}${row('sys',IC.sys,T.s_t,T.s_l,'CitesideCapture',T.s_path,T.s_live)}</div><div class="note">${IC.lock}<span>${T.p_note}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="finishperms">${T.p_enter}</button></div>`;
}

let aiIv=null,aiEpoch=0,aiReading=false,aiRevision=0;
const aiHeaders=()=>({'content-type':'application/json','x-tht-token':boot.relayToken||''});
const connected=st=>st?.status==='connected'||st?.status==='profile_received';
function aiStep(){
  const a=S.ai,st=a.state,isConnected=connected(st),received=!!st?.profileReceivedAt||st?.profileItemCount>0;
  const canDisconnect=!!st?.connectionId&&(isConnected||st.awaitingClient===true);
  const status=isConnected?T.ai_connected:T.ai_not_connected;
  const description=st?.status==='disconnected'?T.ai_disconnected:isConnected?(received?(st?.profileCoverage?.status==='received'?T.ai_received:T.ai_insufficient):T.ai_pending):st?.awaitingClient?T.ai_waiting:T.ai_add;
  const detected=(Array.isArray(st?.clients)?st.clients:[]).filter(c=>c&&c.detected);
  const auto=detected.map(c=>`<button class="btn sec" data-act="aiautoconnect" data-client="${esc(c.id)}"${a.busy?' disabled':''}>${esc(c.label||c.id)}</button>`).join('');
  const idNames=Array.isArray(st?.identity?.names)?st.identity.names:[];
  const idRoles=Array.isArray(st?.identity?.roleKeywords)?st.identity.roleKeywords:[];
  const identityLine=(idNames.length||idRoles.length)?`<p class="cap">${esc(idNames.concat(idRoles).join('、'))}</p>`:'';
  const follow=received&&st?.followUpQuestion?`<div class="note warn">${IC.info}<span>${esc(st.followUpQuestion)}</span></div>`:'';
  const manual=`<details><summary>${esc(T.ai_manual_entry)}</summary><input id="owner-names-in" type="text" maxlength="400" autocomplete="off"><input id="owner-roles-in" type="text" maxlength="400" autocomplete="off"><button class="btn sec" data-act="aisaveowner"${a.busy?' disabled':''}>${esc(T.ai_owner_save)}</button></details>`;
  return `<h1 id="h" style="margin-top:12px">${T.ai_t}</h1><p class="lead">${T.ai_l}</p>`+
    (auto?`<div class="acts">${auto}</div>`:'')+
    `<div class="aibox"><pre class="aiprompt" id="aiprompt">${esc(a.copyFailed?a.copyText:T.ai_prompt)}</pre><button class="btn sec" data-act="aipromptcopy"${a.busy?' disabled':''}>${a.copied?T.ai_copied:T.ai_prompt_copy}</button></div>`+(!isConnected?`<div class="aibox"><p class="cap">${T.ai_config}</p><button class="btn sec" data-act="aicopy"${a.busy?' disabled':''}>${T.ai_copy}</button></div>`:'')+
    `<div class="note">${IC.lock}<span>${T.ai_n}</span></div><p class="cap">${T.ai_schedule}</p>`+
    (a.msg?`<p class="cap" role="status">${esc(a.msg)}</p>`:'')+
    `<div class="airead" aria-live="polite"><div class="lab">${T.ai_status}</div><p class="${isConnected?'state':'cap'}">${isConnected?IC.check:''}${status}</p><p class="cap">${description}</p>`+
    identityLine+
    (a.items.length?`<div class="lab">${T.ai_background}</div><ul>${a.items.map(i=>`<li><span>${esc(i.text)}</span></li>`).join('')}</ul>`:'')+
    (received&&st?.profileCoverage?.missing?.length?`<p class="cap">${T.ai_missing}${esc(st.profileCoverage.missing.map(k=>({identity:LANG==='zh'?'身份与职责':'identity and responsibilities',project:LANG==='zh'?'项目目标与阶段':'project goals and stage',partner:LANG==='zh'?'伙伴与术语':'partners and terminology',constraint:LANG==='zh'?'决策约束':'decision constraints',meeting:LANG==='zh'?'会议偏好':'meeting preferences',provenance:LANG==='zh'?'来源与确认时间':'sources and confirmation dates'}[k]||k)).join('、'))}</p>`:'')+(st?.profileReceivedAt?`<p class="cap">${T.ai_last_sync}${esc(new Date(st.profileReceivedAt).toLocaleString(LANG))}</p>`:'')+follow+`</div>`+
    manual+
    `<p class="cap">${received?T.ai_retained:''}${canDisconnect?T.ai_revoke:''}</p><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="next">${T.finish}</button>`+
    (canDisconnect?`<button class="btn link" data-act="aidisconnect"${a.busy&&!a.copying?' disabled':''}>${T.ai_disconnect}</button>`:'')+`</div>`;
}
function stopAi(){if(aiIv){clearInterval(aiIv);aiIv=null;}aiEpoch++;}
function watchAi(){if(aiIv||document.hidden)return;aiIv=setInterval(()=>{if(!document.hidden&&curKey()==='ai')aiLoad();},2000);}
async function aiLoad(){
  if(aiReading||S.ai.busy)return;
  aiReading=true;S.ai.loaded=true;
  const epoch=aiEpoch,revision=aiRevision;
  try{
    const r=await fetch('/setup/mcp-connection',{cache:'no-store',headers:aiHeaders()});
    const j=r.ok?await r.json():null;
    if(epoch!==aiEpoch||revision!==aiRevision)return;
    if(j&&['not_connected','connected','profile_received','disconnected'].includes(j.status)){
      S.ai.state=j;S.ai.items=Array.isArray(j.profileItems)?j.profileItems:[];
      if(S.ai.msg===T.ai_fail)S.ai.msg='';
    }else S.ai.msg=T.ai_fail;
  }catch(e){if(epoch===aiEpoch&&revision===aiRevision)S.ai.msg=T.ai_fail;}
  finally{aiReading=false;if(epoch===aiEpoch&&curKey()==='ai')render();}
}
async function aiAction(body){
  try{const r=await fetch('/setup/mcp-connection',{method:'POST',headers:aiHeaders(),body:JSON.stringify(body)});const j=await r.json();return r.ok&&j.ok!==false?j:null;}catch(e){return null;}
}
async function aiCopy(mode='config'){
  const a=S.ai;if(a.busy)return;const revision=++aiRevision;a.busy=true;a.msg='';render();
  const promptOnly=mode==='prompt'||connected(a.state);
  if(!promptOnly&&!a.install){
    if(a.state?.connectionId&&a.state?.awaitingClient){a.busy=false;a.msg=LANG==='zh'?'已有待连接授权；请使用之前复制的配置，或先断开后再生成。':'A pending grant already exists. Use its copied configuration, or disconnect before generating a new one.';render();return;}
    a.requestId=a.requestId||crypto.randomUUID();
    const j=await aiAction({action:'connect',client:'mcp-client',requestId:a.requestId,scope:{meetings:'all'}});
    if(revision!==aiRevision)return;
    if(!j||!(j.install?.config||j.config)){a.busy=false;a.msg=T.ai_connect_fail;render();return;}
    a.state=j;a.install=j.install||{config:j.config};
  }
  const text=promptOnly?(a.install?.oneShotPrompt||T.ai_prompt):JSON.stringify(a.install.config,null,2);
  a.copyText=text;a.copying=true;render();
  try{await navigator.clipboard.writeText(text);if(revision!==aiRevision)return;a.copied=true;a.copyFailed=false;}
  catch(e){if(revision!==aiRevision)return;a.copied=false;a.copyFailed=true;a.msg=T.ai_copy_fail;}
  a.busy=false;a.copying=false;render();
  if(a.copyFailed){try{const el=document.getElementById('aiprompt');if(el)getSelection().selectAllChildren(el);}catch(e){}}
}
async function aiDisconnect(){
  const a=S.ai;if((a.busy&&!a.copying)||!a.state?.connectionId)return;
  aiRevision++;a.copying=false;a.busy=true;a.msg='';render();
  const j=await aiAction({action:'disconnect',connectionId:a.state.connectionId});a.busy=false;
  if(j?.status==='disconnected'){a.state=j;a.install=null;a.requestId=null;a.copied=false;a.copyText='';a.copyFailed=false;}
  else a.msg=T.ai_disconnect_fail;
  render();
}
async function aiAutoconnect(clientId){
  const a=S.ai;if(a.busy||!clientId)return;const revision=++aiRevision;a.busy=true;a.msg='';render();
  const j=await aiAction({action:'autoconnect',clientId});
  if(revision!==aiRevision)return;
  if(!j){a.busy=false;a.msg=T.ai_connect_fail;render();return;}
  a.state=j;a.install=j.install||(j.config?{config:j.config,oneShotPrompt:j.oneShotPrompt}:null);
  const text=j.oneShotPrompt||j.install?.oneShotPrompt||T.ai_prompt;
  a.copyText=text;a.copying=true;render();
  try{await navigator.clipboard.writeText(text);if(revision!==aiRevision)return;a.copied=true;a.copyFailed=false;a.msg=T.ai_copied;}
  catch(e){if(revision!==aiRevision)return;a.copied=false;a.copyFailed=true;a.msg=T.ai_copy_fail;}
  a.busy=false;a.copying=false;render();
}
async function aiSaveOwner(){
  const a=S.ai;if(a.busy)return;
  const split=v=>String(v==null?'':v).split(/[,，、/;|；]+/).map(s=>s.trim()).filter(Boolean);
  const namesEl=document.getElementById('owner-names-in'),rolesEl=document.getElementById('owner-roles-in');
  const names=split(namesEl&&namesEl.value),roleKeywords=split(rolesEl&&rolesEl.value);
  const body={};if(names.length)body.names=names;if(roleKeywords.length)body.roleKeywords=roleKeywords;
  a.busy=true;a.msg='';render();
  let ok=false;
  try{const r=await fetch('/setup/owner',{method:'POST',headers:aiHeaders(),body:JSON.stringify(body)});const j=await r.json().catch(()=>null);ok=!!(r.ok&&j);}catch(e){}
  a.busy=false;if(!ok){a.msg=T.ai_owner_fail;render();return;}
  await aiLoad();
}

function welcome(){
  const iconClasses=['','emerald','amber'],icons=[IC.spark,IC.shield,IC.layers];
  const rows=T.w_vals.map((text,i)=>`<div class="value-row"><div class="value-ic ${iconClasses[i]}">${icons[i]}</div><div class="value-copy"><strong>${esc(text)}</strong></div></div>`).join('');
  return hero(IC.logo)+`<h1 id="h">${T.w_t}</h1><p class="lead">${T.w_l}</p><div class="value-list">${rows}</div><div class="gift-pill">${T.w_trial}</div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="welcomenext">${T.w_go}</button><span class="cap" style="margin-top:4px">${T.w_time}</span></div>`;
}
function render(){
  clearT();
  const k=curKey();
  app.innerHTML=shell(S.recovery?recoveryStep():k==='welcome'?welcome():k==='cal'?calStep():k==='perms'?permsStep():aiStep());
  if(!S.recovery&&k==='cal'&&S.cal==='waiting'&&!calBusy)watchCalendar();
  if(!S.recovery&&k==='cal'&&S.cal==='granted'&&!S.calEventsLoaded)calendarEvents(calEpoch);
  if(!S.recovery&&k==='ai'){if(!S.ai.loaded)aiLoad();watchAi();}else stopAi();
}

function go(n){
  stopCalendar();stopAi();
  S.step=Math.max(0,Math.min(STEPS.length-1,n));
  trackFunnel('onboarding_step',{step:curKey()});
  if(curKey()==='done')return leave({step:DONE,finished:true,sys:S.sys==='granted'?'granted':S.sys==='skipped'?'skipped':'idle'});
  const patch={step:S.step,sys:S.sys==='skipped'?'skipped':S.sys==='granted'?'granted':'idle'};
  persist(patch).then(ok=>{const was=!!saveFail;saveFail=ok?null:{patch};if(was!==!!saveFail)render();});
  render();
}

const map=v=>v==='authorized'?'granted':v==='denied'||v==='restricted'?'denied':'idle';
async function readPerms(){
  try{
    const r=await fetch('/native/permissions',{cache:'no-store'});
    const p=r.ok?await r.json():null;
    if(!p)return {known:false,microphone:'unknown',screen:'unknown'};
    S.helperScreen=p.known?p.screen:'unknown';
    return {known:!!p.known,microphone:p.known?p.microphone:'unknown',screen:p.known?p.screen:'unknown'};
  }catch(e){return {known:false,microphone:'unknown',screen:'unknown'};}
}
function applyPerms(p,initial){
  if(!p)return;S.known=!!p.known;
  let changed=false;
  for(const k of ['mic','sys']){
    const sysState=map(p[KIND[k]]);
    let next=S[k];
    if(sysState==='granted')next='granted';
    else if(k==='sys'&&S.sys==='skipped')next='skipped';
    else if(sysState==='denied')next=S[k]==='waiting'?'waiting':'denied';
    else if(S[k]==='granted')next='idle';
    if(next!==S[k]){
      if(next==='granted'&&!initial)trackFunnel(k==='mic'?'mic_ok':'sysaudio_ok');
      S[k]=next;changed=true;
    }
  }
  if(changed&&!initial&&curKey()==='perms')render();
}
async function poll(){applyPerms(await readPerms())}
let requestingPermission=false;
async function request(k,openSettings=false){
  if(requestingPermission)return;
  requestingPermission=true;
  try{
    const body={kind:KIND[k]};
    if(k==='sys'){
      S.ask.helperScreen=true;lastPermissionRefresh.helper=0;S.sys='waiting';render();body.openSettings=!!openSettings;
    }
    const r=await fetch('/native/permissions/request',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
    const j=await r.json().catch(()=>({}));
    if(j.via==='settings'&&S[k]!=='granted'){S[k]='waiting';render();}
  }catch(e){}
  finally{requestingPermission=false;poll();}
}

app.addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');if(!b)return;const a=b.dataset.act,k=b.dataset.k;
  if(S.recovery){if(a==='retrystop')recoverTrial();else if(a==='checktrial')checkLegacyTrial().then(ok=>{if(ok)resumeOnboarding();});return;}
  if(a==='welcomenext'){
    if(boot.cloudTrial?.enabled&&boot.cloudTrial?.status!=='signed_in'){
      trackFunnel('login_start',{source:'onboarding_welcome'});
      location.assign('account.html?view=applogin&from=onboarding&lang='+LANG);
      return;
    }
    go(S.step+1);
  }
  else if(a==='next'){if(curKey()==='ai')leave({});else go(S.step+1);}
  else if(a==='finishperms'){if(S.sys!=='granted')S.sys='skipped';go(DONE);}
  else if(a==='back')go(S.step-1);
  else if(a==='calgo'||a==='gagain')calendarConnect();
  else if(a==='calcancel'){stopCalendar();const cancelledAt=calEpoch;fetch('/google/calendar/cancel',{method:'POST',headers:calendarHeaders(),body:'{}'}).then(r=>r.json()).then(j=>{if(cancelledAt===calEpoch){applyCalendar(j);render();}}).catch(()=>{});S.cal='idle';render();}
  else if(a==='calretry'){calendarStatus().then(j=>{applyCalendar(j);render();});}
  else if(a==='calskip'){trackFunnel('cal_skip');go(S.step+1);}
  else if(a==='later')leave({step:S.step});
  else if(a==='ask'){S.ask[k]=true;request(k,false);}
  else if(a==='openset'){S.ask[k]=true;request(k,true);}
  else if(a==='retrysave'){const f=saveFail;if(!f)return;saveFail=null;if(f.leave)leave(f.patch);else persist(f.patch).then(ok=>{if(!ok){saveFail=f;}render();});}
  else if(a==='leaveunsaved'){const f=saveFail;saveFail=null;leave(f?.patch||{step:S.step},{force:true});}
  else if(a==='aicopy')aiCopy();
  else if(a==='aipromptcopy')aiCopy('prompt');
  else if(a==='aidisconnect')aiDisconnect();
  else if(a==='aiautoconnect')aiAutoconnect(b.dataset.client);
  else if(a==='aisaveowner')aiSaveOwner();
});
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&!e.isComposing&&e.keyCode!==229&&!e.target.isContentEditable&&e.target.tagName!=='TEXTAREA'&&e.target.tagName!=='INPUT'&&!(e.target.closest&&e.target.closest('button'))){const p=app.querySelector('.btn.pri');if(p){e.preventDefault();p.click()}}
  if(e.key==='Escape'&&S.step<DONE)leave({step:S.step});
});
window.addEventListener('pagehide',()=>{
  stopCalendar();stopAi();
  if(!trialLive)return;
  const body=new Blob(['{}'],{type:'application/json'});let sent=false;
  try{sent=!!navigator.sendBeacon?.('/native/trial/stop',body)}catch(e){}
  if(!sent){try{fetch('/native/trial/stop',{method:'POST',headers:{'content-type':'application/json'},body:'{}',keepalive:true})}catch(e){}}
});
let refreshingPermission=false;
const lastPermissionRefresh={main:0,helper:0};
async function refreshOnReturn(){
  if(S.ask.sys&&!refreshingPermission&&S.sys!=='granted'){
    refreshingPermission=true;
    try{
      const now=Date.now();
      if(S.ask.helperScreen&&now-lastPermissionRefresh.helper>=5000){
        lastPermissionRefresh.helper=now;
        await fetch('/native/permissions/refresh',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:'screen'})});
      }
    }catch(e){}
    finally{refreshingPermission=false;}
  }
  poll();
  if(!S.recovery&&curKey()==='ai'){aiLoad();watchAi();}
}
window.addEventListener('focus',refreshOnReturn);
window.addEventListener('citeside-native-active',refreshOnReturn);
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAi();else refreshOnReturn();});

let initialized=false;
async function resumeOnboarding(){
  if(initialized){render();return;}initialized=true;
  if(saved.finished===true&&!directIntro){location.replace('index.html');return;}
  if(!directIntro)trackFunnel('first_launch',{step:curKey()});
  const [p,calendar]=await Promise.all([readPerms(),calendarStatus()]);applyPerms(p,true);applyCalendar(calendar);
  if(S.known&&curKey()==='perms'&&S.mic==='granted'&&(S.sys==='granted'||S.sys==='skipped'))return go(DONE);
  render();
  setInterval(()=>{if(!document.hidden&&curKey()==='perms')poll()},1000);
}
checkLegacyTrial().then(ok=>{if(ok)resumeOnboarding();});
})();
