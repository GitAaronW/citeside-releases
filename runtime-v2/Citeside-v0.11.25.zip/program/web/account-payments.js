'use strict';
window.CitesidePayments={create({$,text,language,getAccount,getModal,escape,request,message,openModal,closeModal,login,refreshAccount}){
  // Monthly membership: catalog, billing, and entitlement state are server-owned.
  let paymentState={catalog:null,subscription:null,orders:[],nextBefore:null,error:'',tab:'plans',seq:0},paymentPoll=null;
  const paymentText=text;
  const paymentMoney=p=>{try{const f=new Intl.NumberFormat(language()==='en'?'en-US':'zh-CN',{style:'currency',currency:p.currency});return f.format(Number(p.amount)/10**f.resolvedOptions().maximumFractionDigits);}catch{return p.currency+' '+p.amount+' '+paymentText('最小货币单位','minor units');}};
  const paymentDate=n=>Number.isFinite(n)&&n>0?new Date(n).toLocaleString(language()==='en'?'en-US':'zh-CN'):'—';
  const paymentStatus=s=>({active:paymentText('生效中','Active'),pending:paymentText('待确认到账','Awaiting confirmation'),paid:paymentText('已付款','Paid'),canceled:paymentText('已取消','Canceled'),past_due:paymentText('续费待付款','Payment overdue'),paused:paymentText('已暂停','Paused'),refunded:paymentText('已退款','Refunded'),refund_manual:paymentText('退款待核对','Refund review'),refunded_used_manual:paymentText('已全额退款 · 已用额度待核对','Full refund completed · usage review'),creating:paymentText('创建中','Creating'),checkout_failed:paymentText('收银台创建失败','Checkout failed')}[s]||s||'—');
  const paymentFailure=e=>({subscriptions_not_configured:paymentText('月付会员尚未开通，当前不会发起付款。','Monthly memberships are not available. No payment will be started.'),subscription_already_exists:paymentText('已有订阅，请先管理当前订阅。','You already have a subscription. Manage it first.'),subscription_checkout_pending:paymentText('已有待确认订单，请在账单查看。','An order is pending. Check Billing.'),checkout_open_failed:paymentText('无法打开系统浏览器，请重试同一方案。','Could not open your browser. Retry the same plan.'),unauthorized:paymentText('请重新登录后查看。','Sign in again to continue.')}[e.code]||paymentText('暂时无法读取或更新，请重试。','Unable to read or update this now. Please retry.'));
  const planMeta=sku=>{
    const key=String(sku||'').toLowerCase(),t=paymentText;
    if(/^plus(?:[_-]|$)/.test(key))return {name:'Plus',badge:'',tagline:t('日常周会与清晰纪要','Regular weekly meetings & crisp recaps'),highlights:[t('+ 24 小时限时分享链，随时撤回','+ 24h expiring share links, revocable anytime'),t('+ Notion 导出与日历提醒','+ Notion export & Calendar reminders')]};
    if(/^pro(?:[_-]|$)/.test(key))return {name:'Pro',badge:t('最受欢迎','Popular'),featured:true,tagline:t('高频开会与会中直接出成果','Heavy meetings & live deliverables'),highlights:[t('+ MCP 一键交接给 AI 工具','+ Direct MCP handoff to AI tools'),t('+ 会中自动写草稿与历史冲突预警','+ Live follow-up drafts & past conflict alerts')]};
    if(/^max(?:[_-]|$)/.test(key))return {name:'Max',badge:t('终极隐私','Privacy+'),privacy:true,tagline:t('高管与敏感会议专属','For execs & sensitive calls'),highlights:[t('✦ 零留存专线（Vertex）或 100% 本地 / 自有 API','✦ Zero-retention route (Vertex) or 100% local / own APIs'),t('✦ 绝密会议、1 小时短链与防分享锁','✦ Private calls, 1h links & no-share lock')]};
    return {name:sku||'',badge:'',tagline:'',highlights:[]};
  };
  function openAccountUpgrade(){if(getAccount()?.status!=='signed_in')return login(openAccountUpgrade);paymentState.tab='plans';drawAccountPayments();$('#s-account-payments')?.scrollIntoView({block:'nearest'});}
  async function loadAccountPayments(){
    const seq=++paymentState.seq;
    if(getAccount()?.status!=='signed_in'){paymentState.catalog=null;paymentState.subscription=null;paymentState.orders=[];drawAccountPayments();return;}
    paymentState.error='';
    try{
      const catalog=await request('/account/payments/catalog');if(seq!==paymentState.seq)return;paymentState.catalog=catalog;
      // New-sales availability must never remove an existing customer's cancel/billing path.
      const [subscription,orders]=await Promise.allSettled([request('/account/payments/subscription'),request('/account/payments/orders')]);if(seq!==paymentState.seq)return;
      for(const result of [subscription,orders])if(result.status==='rejected'&&(catalog.configured||result.reason?.code!=='subscriptions_not_configured'))throw result.reason;
      paymentState.subscription=subscription.status==='fulfilled'?subscription.value.subscription:null;
      paymentState.orders=orders.status==='fulfilled'?orders.value.orders||[]:[];paymentState.nextBefore=orders.status==='fulfilled'?orders.value.nextBefore:null;
    }catch(e){if(seq!==paymentState.seq)return;paymentState.catalog=null;paymentState.subscription=null;paymentState.orders=[];paymentState.error=paymentFailure(e);}
    drawAccountPayments();
  }
  let quotaWatch=null;
  function quotaEl(id){
    if(typeof document==='undefined'||typeof document.getElementById!=='function')return null;
    return document.getElementById(id);
  }
  function setMeter(meterId,fillId,captionId,used,limit,caption){
    const meter=quotaEl(meterId),fill=quotaEl(fillId),cap=quotaEl(captionId);
    const finite=Number.isFinite(used)&&Number.isFinite(limit)&&limit>0;
    const ratio=finite?Math.max(0,Math.min(1,used/limit)):0;
    if(meter){
      meter.setAttribute('aria-valuemin','0');
      meter.setAttribute('aria-valuemax','100');
      meter.setAttribute('aria-valuenow',String(Math.round(ratio*100)));
      if(caption)meter.setAttribute('aria-label',caption);
    }
    if(fill){
      const width=(ratio*100).toFixed(1)+'%';
      if(fill.style)fill.style.width=width;else fill.setAttribute('style','width:'+width);
    }
    if(cap&&caption)cap.textContent=caption;
  }
  function paintQuotaMeters(){
    if(!quotaEl('s-account-hours-caption')&&!quotaEl('s-account-research-caption'))return;
    const a=getAccount?.()||{},en=language()==='en',zhEn=(zh,enText)=>en?enText:zh;
    const hoursUsed=Number(a.aiHoursUsed),hoursLimit=Number(a.aiHoursLimit);
    const hoursOk=Number.isFinite(hoursUsed)&&Number.isFinite(hoursLimit)&&hoursLimit>0;
    const hoursLeft=hoursOk?Math.max(0,Math.round((1-Math.min(1,hoursUsed/hoursLimit))*100)):0;
    let hoursCaption;
    if(hoursOk)hoursCaption=zhEn('已用 '+hoursUsed.toFixed(1)+' 小时 / 共 '+hoursLimit.toFixed(1)+' 小时 · 剩余 '+hoursLeft+'%','Used '+hoursUsed.toFixed(1)+' h / '+hoursLimit.toFixed(1)+' h · '+hoursLeft+'% left');
    else{
      const legacy=String(quotaEl('s-account-usage')?.textContent||'');
      hoursCaption=!legacy||/秒|\bsec\b|待核实/.test(legacy)?zhEn('登录后查看用量','Sign in to see usage'):legacy;
    }
    setMeter('s-account-hours-meter','s-account-hours-fill','s-account-hours-caption',hoursUsed,hoursLimit,hoursCaption);
    const researchUsed=Number(a.researchUsed),researchLimit=Number(a.researchLimit);
    const researchOk=Number.isFinite(researchUsed)&&Number.isFinite(researchLimit)&&researchLimit>0;
    const researchLeft=researchOk?Math.max(0,Math.round((1-Math.min(1,researchUsed/researchLimit))*100)):0;
    const researchCaption=researchOk?zhEn('已用 '+researchUsed+' 次 / 共 '+researchLimit+' 次 · 剩余 '+researchLeft+'%','Used '+researchUsed+' / '+researchLimit+' · '+researchLeft+'% left'):zhEn('登录后查看用量','Sign in to see usage');
    setMeter('s-account-research-meter','s-account-research-fill','s-account-research-caption',researchUsed,researchLimit,researchCaption);
  }
  function watchQuotaMeters(){
    try{paintQuotaMeters();}catch{}
    if(quotaWatch||typeof MutationObserver!=='function')return;
    const usage=quotaEl('s-account-usage');if(!usage)return;
    try{
      quotaWatch=new MutationObserver(()=>{try{paintQuotaMeters();}catch{}});
      quotaWatch.observe(usage,{childList:true,characterData:true,subtree:true});
    }catch{}
  }
  function drawAccountPayments(){
    try{paintQuotaMeters();}catch{}
    const host=$('#s-account-payments');if(!host)return;host.replaceChildren();if(getAccount()?.status!=='signed_in')return;
    const a=getAccount(),s=paymentState.subscription,c=paymentState.catalog,esc=escape,t=paymentText;
    const weighted=a.aiCredits!=null,credit=a.aiCredits;
    const validCredit=credit?.version==='weighted-v1'&&credit.unit==='points'&&credit.tokensPerPoint===1000&&['limit','used','held','remaining'].every(k=>typeof credit[k]==='number'&&Number.isFinite(credit[k])&&credit[k]>=0)&&credit.used+credit.held+credit.remaining<=credit.limit+1e-7;
    const creditNumber=n=>new Intl.NumberFormat(language()==='en'?'en-US':'zh-CN',{maximumFractionDigits:4}).format(n);
    const node=(tag,text,cls)=>{const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;};
    const usageMeter=(label,caption,ratio)=>{
      const wrap=node('div','','payment-usage');
      wrap.append(node('div',label,'payment-usage-label'));
      const bar=node('div','','payment-usage-bar'),pct=Math.max(0,Math.min(100,Number.isFinite(ratio)?ratio*100:0));
      bar.setAttribute('role','progressbar');bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');bar.setAttribute('aria-valuenow',String(Math.round(pct)));bar.setAttribute('aria-label',caption);
      const fill=node('span','','payment-usage-fill');fill.setAttribute('style','width:'+pct.toFixed(1)+'%');bar.append(fill);
      wrap.append(bar,node('div',caption,'payment-usage-caption'));return wrap;
    };
    const button=(label,fn,primary=false)=>{const b=node('button',label,'btn'+(primary?' primary':''));b.type='button';b.onclick=()=>fn(b);return b;};
    const paid=a.paidAllowance||{},giftHours=Math.max(0,Number(a.aiHoursLimit||0)-Number(a.aiHoursUsed||0)-Number(paid.seconds||0)/3600),giftResearch=Math.max(0,Number(a.researchLimit||0)-Number(a.researchUsed||0)-Number(paid.research||0));
    const hasPeriods=Array.isArray(s?.periods)&&s.periods.length>0;
    const hasActivePaidPeriod=!!s&&(hasPeriods?s.periods.some(p=>p&&p.active===true&&!p.refunded):['active','trialing'].includes(s.status));
    const hasRefundedPeriod=!!s&&hasPeriods&&s.periods.some(p=>p&&p.refunded===true);
    const planHeading=$('#s-member-plan'),planStatus=$('#s-member-status');
    const fallbackPlanLabel=()=>{const r=String(a.tier||a.plan||'').toLowerCase();return r==='max'?'Max':r==='pro'?'Pro':r==='plus'?'Plus':r==='trial'?t('试用版','Trial'):t('免费版','Free');};
    if(s&&['active','trialing','past_due'].includes(s.status)){
      if(a&&typeof a==='object')a.subscription=s;
    } else if(a&&typeof a==='object'&&a.subscription&&!['active','trialing','past_due'].includes(String(a.subscription.status||''))){
      delete a.subscription;
    }
    if(hasActivePaidPeriod){
      if(planHeading)planHeading.textContent=planMeta(s.sku).name;
      if(planStatus)planStatus.textContent=paymentStatus('active')+' · '+(s.scheduledChange?.action==='cancel'?t('到期取消：','Cancels: '):t('下次续费：','Renews: '))+paymentDate(s.scheduledChange?.effectiveAt||s.renewalDate||s.paidThrough);
    }else if(s){
      if(planHeading)planHeading.textContent=fallbackPlanLabel();
      if(planStatus)planStatus.textContent=hasRefundedPeriod?t('免费体验 · 上期订单已退款','Free Trial · Previous order refunded'):t('当前无生效付费期','No active paid period');
    }
    if(typeof window.CitesideTier?.refresh==='function')window.CitesideTier.refresh();
    if(s&&hasActivePaidPeriod){
      const subBar=node('div','','payment-sub-bar');
      subBar.append(node('span',(s.scheduledChange?.action==='cancel'?t('已设到期取消：','Cancels at period end: '):t('下次续费：','Next renewal: '))+paymentDate(s.scheduledChange?.effectiveAt||s.renewalDate||s.paidThrough),'hint'),button(t('管理订阅','Manage subscription'),manageAccountSubscription));
      host.append(subBar);
    }
    const nav=node('nav','','payment-tabs');nav.setAttribute('aria-label',t('个人账单分类','Membership sections'));
    for(const[key,label]of [['plans',t('会员方案','Plans')],['usage',t('用量','Usage')],['bills',t('账单','Billing')]]){const b=button(label,()=>{paymentState.tab=key;drawAccountPayments();});b.setAttribute('aria-pressed',String(paymentState.tab===key));nav.append(b);}host.append(nav);
    if(paymentState.error){host.append(node('p',paymentState.error,'hint'),button(t('重试','Retry'),loadAccountPayments));return;}
    if(paymentState.tab==='plans'){
      if(!c){host.append(node('p',t('正在读取会员方案…','Loading plans…'),'hint'));return;}
      if(!c.configured){host.append(node('p',t('月付会员尚未开通，当前不会发起付款。价格与权益将在正式开放后显示。','Monthly memberships are not available. Prices and benefits will appear when payments are enabled.'),'hint'));return;}
      const plans=weighted?(c.catalog||[]).filter(p=>p.aiBilling?.version==='weighted-v1'):(c.catalog||[]);
      if(weighted&&!plans.length){host.append(node('p',t('积分会员方案尚未开放；当前不会发起付款。既有订阅可继续在账单中查看和管理。','Credit membership plans are not available yet. Existing subscriptions can still be viewed and managed.'),'hint'));return;}
      const grid=node('div','','payment-plans');
      for(const p of plans){
        const meta=planMeta(p.sku),card=node('article','','payment-plan'+(meta.featured?' is-featured':meta.privacy?' is-privacy':''));
        const head=node('div','','payment-head');head.append(node('h3',meta.name));if(meta.badge)head.append(node('span',meta.badge,'payment-badge'));
        card.append(head);if(meta.tagline)card.append(node('p',meta.tagline,'hint'));
        card.append(node('strong',paymentMoney(p)+t(' /月',' /month'),'payment-price'),node('p',t('按月自动续费 · 税费以收银台为准','Renews monthly · taxes shown at checkout'),'hint'),node('p',Number(p.allowances?.seconds||0)/3600+t(' 小时会议 / 月',' meeting hours / month')));
        if(p.aiBilling?.version==='weighted-v1')card.append(node('p',Number(p.aiBilling.points||0).toLocaleString(language()==='en'?'en-US':'zh-CN')+t(' AI 积分 / 月（普通分析与深度分析共用）',' AI credits / month (shared by normal and deep analysis)')));
        else card.append(node('p',Number(p.allowances?.research||0)+t(' 次深度研究 / 月',' deep research runs / month')),node('p',Number(p.allowances?.llm||0).toLocaleString(language()==='en'?'en-US':'zh-CN')+t(' AI 加权 token 单位 / 月（分析与深研共用）',' weighted AI token units / month (shared by analysis and research)')));
        for(const perk of meta.highlights)card.append(node('p',perk,'payment-perk'));
        const isCurrentActive=!!hasActivePaidPeriod&&s.sku===p.sku;
        const buy=button(isCurrentActive?t('当前方案','Current plan'):t('订阅','Subscribe'),()=>confirmAccountCheckout(p),!isCurrentActive);buy.disabled=isCurrentActive;card.append(buy);grid.append(card);
      }host.append(grid);
      host.append(node('p',t('会员每期权益当期有效，不结转；优先扣减本期会员权益，用完再扣赠送及既有权益。可设置到期取消。关闭收银台或返回 App 不代表付款成功。','Membership benefits expire each period without rollover. Current membership benefits are used first, then gifts and existing benefits. Cancel at period end anytime. Returning from checkout does not confirm payment.'),'hint'));
    }else if(paymentState.tab==='usage'){
      host.append(node('p',t('仅本人云端计量；本机及 BYOK 不计入云端账单。','Your cloud usage only. Local and BYOK usage are excluded.'),'hint'));
      const hoursUsed=Number(a.aiHoursUsed||0),hoursLimit=Number(a.aiHoursLimit||0),hoursOk=hoursLimit>0,hoursLeft=hoursOk?Math.max(0,Math.round((1-Math.min(1,hoursUsed/hoursLimit))*100)):0;
      host.append(usageMeter(t('会议时长','Meeting time'),hoursOk?t('已用 '+hoursUsed.toFixed(1)+' 小时 / 共 '+hoursLimit.toFixed(1)+' 小时 · 剩余 '+hoursLeft+'%','Used '+hoursUsed.toFixed(1)+' h / '+hoursLimit.toFixed(1)+' h · '+hoursLeft+'% left'):t('登录后查看用量','Sign in to see usage'),hoursOk?hoursUsed/hoursLimit:0));
      if(weighted)host.append(node('p',validCredit?t('AI 积分已用：','AI credits used: ')+creditNumber(credit.used)+' / '+creditNumber(credit.limit):t('AI 积分暂无法核对','AI credits unavailable')));
      else{
        const researchUsed=Number(a.researchUsed||0),researchLimit=Number(a.researchLimit||0),researchOk=researchLimit>0,researchLeft=researchOk?Math.max(0,Math.round((1-Math.min(1,researchUsed/researchLimit))*100)):0;
        host.append(usageMeter(t('深度研究','Deep research'),researchOk?t('已用 '+researchUsed+' 次 / 共 '+researchLimit+' 次 · 剩余 '+researchLeft+'%','Used '+researchUsed+' / '+researchLimit+' · '+researchLeft+'% left'):t('登录后查看用量','Sign in to see usage'),researchOk?researchUsed/researchLimit:0));
      }
      for(const period of s?.periods||[]){const card=node('div','','payment-gift');card.append(node('h3',paymentDate(period.startsAt)+' – '+paymentDate(period.endsAt)),node('p',period.active?t('本期有效 · 未用完不结转','Current period · no rollover'):period.refunded?t('已退款','Refunded'):t('已到期或尚未开始','Expired or upcoming'),'hint'));for(const b of period.allowances||[]){if(!['seconds','research'].includes(b.resource))continue;if(period.aiCredits&&b.resource==='research'&&b.granted===0)continue;const divisor=b.resource==='seconds'?3600:1,unit=b.resource==='seconds'?t(' 小时会议',' meeting hours'):t(' 次深研',' research runs');card.append(node('p',t('剩余可用 ','Available ')+(b.available/divisor).toFixed(b.resource==='seconds'?2:0)+' / '+b.granted/divisor+unit+t(' · 已用 ',' · consumed ')+(b.consumed/divisor).toFixed(b.resource==='seconds'?2:0)));}if(period.aiCredits)card.append(node('p',t('剩余可用 ','Available ')+creditNumber(period.aiCredits.available)+' / '+creditNumber(period.aiCredits.granted)+t(' 点 AI 积分 · 已用 ',' AI credits · consumed ')+creditNumber(period.aiCredits.used)));host.append(card);}
      host.append(node('p',t('逐会议明细暂未提供；以上为服务端累计用量及会员权益账本。','Per-meeting details are not available yet. These are server usage totals and membership balances.'),'hint'));
    }else{
      host.append(node('p',t('订单状态以服务器确认平台事件为准。金额为税前金额，最终税费以收银台为准。','Order status follows server-confirmed provider events. Amounts exclude tax; final tax is shown at checkout.'),'hint'));
      if(!paymentState.orders.length)host.append(node('p',c?.configured?t('暂无账单','No billing records'):t('账单服务尚未开通，暂无可读取的账单。','Billing is not available yet. No billing records can be retrieved.'),'hint'));
      for(const order of paymentState.orders){const row=node('div','','settings-account-row');const words=node('div','');words.append(node('strong',planMeta(order.sku).name+' · '+paymentMoney(order)),node('p',order.id+' · '+paymentDate(order.createdAt),'hint'));row.append(words,button(paymentStatus(order.status),()=>showAccountOrder(order.id)));host.append(row);}
      if(paymentState.nextBefore)host.append(button(t('加载更早账单','Load older bills'),async b=>{b.disabled=true;try{const r=await request('/account/payments/orders?before='+encodeURIComponent(paymentState.nextBefore));paymentState.orders.push(...r.orders);paymentState.nextBefore=r.nextBefore;drawAccountPayments();}catch(e){b.disabled=false;b.textContent=paymentFailure(e);}}));
    }
  }
  function confirmAccountCheckout(p){
    openModal(paymentText('确认月付订阅','Confirm monthly subscription'),'<p class="member">'+escape(planMeta(p.sku).name+' · '+paymentMoney(p))+paymentText(' /月',' /month')+'</p><p>'+paymentText('每月自动续费；每期权益不结转。税费及付款方式以系统浏览器中的托管收银台为准。','Renews monthly; unused benefits do not roll over. Taxes and payment methods are shown in hosted checkout in your system browser.')+'</p>',[[paymentText('取消','Cancel'),closeModal],[paymentText('前往收银台','Open checkout'),async b=>{b.disabled=true;try{const r=await request('/account/payments/checkout',{sku:p.sku});if(!r.opened||!r.order?.id)throw Error('unconfirmed');showAccountOrder(r.order.id);}catch(e){message(paymentFailure(e));b.disabled=false;}},true]]);
  }
  async function showAccountOrder(id){
    clearTimeout(paymentPoll);const marker=Symbol();paymentState.orderMarker=marker;let attempts=0;
    openModal(paymentText('订单详情','Order details'),'<div class="payment-progress"><span class="payment-spinner" aria-hidden="true"></span><span>'+paymentText('正在查询服务器…','Checking payment status…')+'</span></div>',[[paymentText('关闭','Close'),()=>{paymentState.orderMarker=null;clearTimeout(paymentPoll);closeModal();}]]);
    const refresh=async()=>{if(!getModal()?.open||paymentState.orderMarker!==marker)return;try{const r=await request('/account/payments/orders/'+encodeURIComponent(id));if(!getModal()?.open||paymentState.orderMarker!==marker)return;const o=r.order;const waiting=['pending','creating'].includes(o.status);const statusRow=waiting?'<div class="payment-progress"><span class="payment-spinner" aria-hidden="true"></span><span>'+escape(paymentStatus(o.status))+'</span></div>':'<p class="payment-done">'+escape(paymentStatus(o.status))+'</p>';$('#settings-account-modal-body').innerHTML=statusRow+'<p>'+escape(planMeta(o.sku).name+' · '+paymentMoney(o))+'</p><p class="sub">'+escape(o.id)+'</p><p class="sub">'+paymentText('返回 App 不代表付款成功；会员权益以服务器账本为准。','Returning to the app does not confirm payment. Benefits follow the server ledger.')+'</p>';if(waiting){if(++attempts<60)paymentPoll=setTimeout(refresh,5000);else message(paymentText('仍待服务器确认，请稍后从账单重新查看。','Still awaiting server confirmation. Reopen this order from Billing later.'));}else{await refreshAccount();await loadAccountPayments();}}catch(e){message(paymentFailure(e));}};refresh();
  }
  function manageAccountSubscription(){
    const s=paymentState.subscription;if(!s)return;
    openModal(paymentText('管理订阅','Manage subscription'),'<p>'+escape(planMeta(s.sku).name+' · '+paymentStatus(s.status))+'</p><p>'+paymentText('到期取消后，已付款的本期权益保留至 ','If canceled, paid benefits remain until ')+escape(paymentDate(s.paidThrough))+'</p>',[[paymentText('返回','Back'),closeModal],...(!s.scheduledChange&&s.status!=='canceled'?[[paymentText('设为到期取消','Cancel at period end'),async b=>{b.disabled=true;try{const r=await request('/account/payments/subscription/cancel',{});if(r.confirmed!==true)throw Error('unconfirmed');closeModal();await loadAccountPayments();}catch(e){message(paymentFailure(e));b.disabled=false;}}]]:[])]);
  }

try{watchQuotaMeters();}catch{}
return {load:loadAccountPayments,open:openAccountUpgrade,dispose(){clearTimeout(paymentPoll);paymentState.orderMarker=null;try{quotaWatch?.disconnect();}catch{}quotaWatch=null;}};
}};
