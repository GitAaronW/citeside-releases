(function (root) {
  'use strict';

  function hasRealUrl(list) {
    return Array.isArray(list) && list.some(s => s && /^https?:\/\//i.test(String(s.url || '').trim()));
  }

  // Single source of truth for Main Window (my-agent.js) and Lite Window (lite.js).
  // Both windows MUST render the exact same proactive cards; generic un-badged transcript
  // echoes are filtered out uniformly in BOTH windows.
  function shouldShowProactiveCard(item) {
    if (!item || typeof item !== 'object') return false;
    if (item.cardKind || item.semanticBadge) return true;
    if (hasRealUrl(item.sources) || hasRealUrl(item.verify && item.verify.sources)) return true;
    return false;
  }

  // Single source of truth for the latest discussion-summary timeline label in BOTH windows.
  // Never show "正在发生 / Happening now" once a meeting has ended.
  function meetingTimelineLabel({ ended = false, paused = false, isLatest = true, en = false } = {}) {
    if (!isLatest) return en ? 'Earlier' : '稍早';
    if (ended) return en ? 'Final recap' : '讨论收尾';
    if (paused) return en ? 'Paused' : '已暂停';
    return en ? 'Happening now' : '正在发生';
  }

  // Single source of truth for ended/paused control bar presentation in BOTH windows.
  function meetingControlBarState({ active = false, paused = false, ended = false, captureEnding = false, en = false } = {}) {
    const isEnded = !active && !paused && !!ended;
    return {
      state: captureEnding ? 'saving' : paused ? 'paused' : isEnded ? 'ended' : active ? 'recording' : 'idle',
      badgeLabel: captureEnding
        ? (en ? 'Saving stopped recording' : '录音已停止，正在保存')
        : paused
          ? (en ? 'Paused' : '已暂停')
          : isEnded
            ? (en ? 'Ended' : '已结束')
            : '',
      resumeLabel: en ? 'Resume' : '继续录制',
      showWave: !!active && !paused && !isEnded,
      showMic: !isEnded,
      suppressAudioError: !!captureEnding || isEnded || (!active && !paused)
    };
  }

  // Single source of truth for A1 semantic badge labels & color tones across Main & Lite windows.
  // Supports zh, en, and ja UI languages for both Single-Brain v3 kinds and legacy kinds.
  const SEMANTIC_BADGE_MAP = {
    fact_check: { zh: '事实核查', en: 'Fact Check', ja: '事実確認' },
    blind_spot: { zh: '关键盲区', en: 'Blind Spot', ja: '重要な盲点' },
    external_case: { zh: '外部案例', en: 'External Case', ja: '外部事例' },
    memory_conflict: { zh: '历史踩坑', en: 'Past Pitfall', ja: '過去の教訓' },
    external: { zh: '事实核查', en: 'Fact Check', ja: '事実確認' },
    best_practice: { zh: '方案对比', en: 'Trade-off', ja: '案の比較' },
    gap: { zh: '逻辑缺口', en: 'Logic Gap', ja: '論理の抜け' }
  };

  function normUiLang(langOrEn) {
    if (langOrEn === true) return 'en';
    if (langOrEn === false || !langOrEn) return 'zh';
    const raw = String(langOrEn).toLowerCase();
    if (raw.startsWith('en')) return 'en';
    if (raw.startsWith('ja')) return 'ja';
    return 'zh';
  }

  function semanticBadgeOf(item, langOrEn = false) {
    const b = item && item.semanticBadge;
    const isObj = !!(b && typeof b === 'object');
    const kind = (isObj && b.kind) || (item && item.cardKind) || '';
    if (!kind || !SEMANTIC_BADGE_MAP[kind]) return null;
    const entry = SEMANTIC_BADGE_MAP[kind];
    const lang = normUiLang(langOrEn);
    const label = lang === 'en'
      ? ((isObj && b.labelEn) || entry.en)
      : lang === 'ja'
        ? ((isObj && b.labelJa) || entry.ja)
        : ((isObj && b.labelZh) || entry.zh);
    return { kind, label };
  }

  function semanticToneOf(sem, toneText = '') {
    const k = sem && sem.kind;
    const t = String(toneText || '').replace(/^\s*(?:AI\s*解读|AI\s*interpretation)\s*[：:]\s*/i, '').trim();
    if (/^(?:核实一致|已核实)[：:]/.test(t)) return 'ok';
    if (k === 'fact_check' || /^(?:纠偏[：:]|实际是)|而非会上说的/.test(t)) return 'fix';
    if (k === 'blind_spot' || k === 'gap') return 'blind';
    if (k === 'external_case' || k === 'best_practice' || k === 'memory_conflict') return 'cmp';
    return 'add';
  }

  function shouldShowFactcheck(item, stream = true) {
    if (!item || typeof item !== 'object') return false;
    if (item.lookupState && item.lookupState !== 'ready') return false;
    if (stream && item.channel === 'judgment' && !(item.verify && Array.isArray(item.verify.sources) && item.verify.sources.length)) return false;
    return true;
  }

  // Settled fact_check cards NEVER show Deep Research; only open/research-worthy kinds do.
  const DEEP_RESEARCH_KINDS = new Set(['blind_spot', 'external_case', 'memory_conflict', 'best_practice', 'gap']);

  function shouldShowDeepResearch(sem, hasSources = false) {
    const k = typeof sem === 'string' ? sem : (sem && sem.kind) || '';
    if (k === 'fact_check' || k === 'external') return false;
    if (DEEP_RESEARCH_KINDS.has(k)) return true;
    if (!k && !hasSources) return true;
    return false;
  }

  const RESEARCH_ENTITLEMENT_CODES = new Set([
    'entitlement_required',
    'quota_exhausted',
    'research_quota_exhausted',
    'ai_credits_exhausted',
    'account_login_required'
  ]);

  function isResearchEntitlementError(code) {
    return RESEARCH_ENTITLEMENT_CODES.has(String(code || '').trim());
  }

  function isResearchProAccount(account, now = Date.now()) {
    if (!account || typeof account !== 'object') return false;
    if (account.entitlement && typeof account.entitlement === 'object' && typeof account.entitlement.canResearch === 'boolean') {
      return account.entitlement.canResearch;
    }
    if (account.cloudTrial && typeof account.cloudTrial === 'object') {
      if (!account.cloudTrial.enabled) return true;
      if (typeof account.cloudTrial.canResearch === 'boolean') return account.cloudTrial.canResearch;
      const p = String(account.cloudTrial.plan || '').toLowerCase();
      if (['plus', 'pro', 'max'].includes(p)) {
        return account.cloudTrial.planUntil == null || Number(account.cloudTrial.planUntil) > now;
      }
      return false;
    }
    if (account.enabled === false) return true;
    if (account.ok === false || (account.status && account.status !== 'signed_in')) return false;
    const plan = String(account.plan || account.tier || '').toLowerCase();
    const isPaidPlan = ['plus', 'pro', 'max'].includes(plan);
    if (!isPaidPlan) return false;
    if (account.planUntil != null && Number.isFinite(Number(account.planUntil))) {
      return Number(account.planUntil) > now;
    }
    return true;
  }

  function researchButtonLabel({ langOrEn = 'zh', isPro = true, state = 'idle' } = {}) {
    const lang = normUiLang(langOrEn);
    if (state === 'pending') return lang === 'en' ? 'Researching…' : lang === 'ja' ? '調査中…' : '深度研究中…';
    if (state === 'running') return lang === 'en' ? 'Researching · Stop' : lang === 'ja' ? '調査中 · 停止' : '深度研究中 · 停止';
    if (state === 'done') return lang === 'en' ? 'View report ↗' : lang === 'ja' ? 'レポートを見る ↗' : '查看报告 ↗';
    if (!isPro) return lang === 'en' ? '✦ Deep research · Plus+' : lang === 'ja' ? '✦ 深掘り調査 · Plus+' : '✦ 深度研究 · 会员';
    return lang === 'en' ? '✦ Deep research' : lang === 'ja' ? '✦ 深掘り調査' : '✦ 深度研究';
  }

  // Single source of truth for the paywall reassurance line in BOTH windows and
  // the account redeem page. History always stays readable/exportable.
  function paywallReassureText(langOrEn) {
    const lang = normUiLang(langOrEn);
    return lang === 'en'
      ? 'Your past meeting notes always stay readable and exportable.'
      : lang === 'ja'
        ? '過去の会議メモはいつでも閲覧・エクスポートできます。'
        : '你的历史会议纪要与笔记永远可读、可随时导出。';
  }

  function researchPaywallSpec({ langOrEn = 'zh', verifiedCount = 0, masBuild = false } = {}) {
    const lang = normUiLang(langOrEn);
    const n = Math.max(0, Number(verifiedCount) || 0);
    const valueLine = lang === 'en'
      ? `Verified ${n} items this meeting`
      : lang === 'ja'
        ? `この会議で ${n} 件を確認済み`
        : `本场已为你核实 ${n} 处`;
    const reassureLine = paywallReassureText(lang);
    if (masBuild) {
      return {
        valueLine,
        reassureLine,
        masOnly: true,
        masHint: lang === 'en'
          ? 'Manage account at citeside.com'
          : lang === 'ja'
            ? 'citeside.com でアカウント管理'
            : '在 citeside.com 管理账号',
        ctaLabel: '',
        upgradeHref: ''
      };
    }
    return {
      valueLine,
      reassureLine,
      masOnly: false,
      masHint: '',
      // Length caps: zh <= 12 chars, ja <= 16 chars, en <= 32 chars
      ctaLabel: lang === 'en' ? 'Upgrade plan' : lang === 'ja' ? 'プランをアップグレード' : '升级会员',
      upgradeHref: 'account.html?view=plans'
    };
  }

  // Single source of truth for the borderless `.mw-pro-paywall` DOM in BOTH
  // windows: value line, green-dot reassurance, then EITHER plain-text MAS hint
  // (no external purchase link, no <a>) OR one upgrade CTA.
  function buildBorderlessPaywall(doc, spec, { onUpgrade } = {}) {
    const s = spec && typeof spec === 'object' ? spec : researchPaywallSpec({});
    const box = doc.createElement('div');
    box.className = 'mw-pro-paywall';
    box.setAttribute('role', 'region');
    const val = doc.createElement('div');
    val.className = 'mw-pro-paywall-val';
    val.textContent = String(s.valueLine || '');
    box.append(val);
    const reassure = doc.createElement('div');
    reassure.className = 'mw-pro-paywall-reassure';
    const dot = doc.createElement('span');
    dot.className = 'mw-pro-paywall-reassure-dot';
    dot.setAttribute('aria-hidden', 'true');
    reassure.append(dot);
    const reassureLine = doc.createElement('span');
    reassureLine.textContent = String(s.reassureLine || '');
    reassure.append(reassureLine);
    box.append(reassure);
    if (s.masOnly) {
      const mas = doc.createElement('span');
      mas.className = 'mw-pro-paywall-mas';
      mas.textContent = String(s.masHint || '');
      box.append(mas);
      return box;
    }
    const cta = doc.createElement('a');
    cta.className = 'mw-pro-paywall-cta';
    cta.href = String(s.upgradeHref || '#');
    cta.target = '_blank';
    cta.rel = 'noopener noreferrer';
    cta.textContent = String(s.ctaLabel || '');
    cta.addEventListener('click', (ev) => {
      if (ev && typeof ev.preventDefault === 'function') ev.preventDefault();
      if (typeof onUpgrade === 'function') { onUpgrade(ev); return; }
      try {
        fetch('/account/open-plans', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
          .then((r) => { if (!r.ok) window.open(s.upgradeHref, '_blank', 'noopener,noreferrer'); })
          .catch(() => window.open(s.upgradeHref, '_blank', 'noopener,noreferrer'));
      } catch {}
    });
    box.append(cta);
    return box;
  }

  const api = {
    SEMANTIC_BADGE_MAP,
    RESEARCH_ENTITLEMENT_CODES,
    semanticBadgeOf,
    semanticToneOf,
    shouldShowProactiveCard,
    shouldShowFactcheck,
    shouldShowDeepResearch,
    isResearchEntitlementError,
    isResearchProAccount,
    researchButtonLabel,
    researchPaywallSpec,
    paywallReassureText,
    buildBorderlessPaywall,
    meetingTimelineLabel,
    meetingControlBarState
  };

  if (typeof module === 'object' && module && module.exports) {
    module.exports = api;
  }
  if (root && typeof root === 'object') {
    root.ThtProactiveContract = api;
  }
})(typeof window !== 'undefined' ? window : globalThis);
