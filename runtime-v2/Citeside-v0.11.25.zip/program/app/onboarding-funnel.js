'use strict';
// 有界漏斗埋点日志（dataDir/onboarding-funnel.jsonl）：单文件上限 4MB 自动轮转，绝不无界增长。
const fs = require('fs');
const path = require('path');

const MAX_BYTES = 4 * 1024 * 1024;
const ALLOWED_EVENTS = new Set([
  'first_launch',
  'onboarding_step',
  'login_start',
  'login_done',
  'cal_connect',
  'cal_skip',
  'mic_ok',
  'sysaudio_ok',
  'onboarding_done',
  'home_greet_saved',
  'home_greet_skipped',
  'first_card',
  'paid',
]);

function funnelPath(dataDir) {
  return path.join(dataDir, 'onboarding-funnel.jsonl');
}

function cleanMeta(meta) {
  if (!meta || typeof meta !== 'object' || Array.isArray(meta)) return {};
  const out = {};
  for (const key of ['step', 'lang', 'source', 'via']) {
    const v = meta[key];
    if (typeof v === 'string' && v.length <= 64 && !/[\r\n\x00-\x1f]/.test(v)) out[key] = v;
    else if (typeof v === 'number' && Number.isFinite(v)) out[key] = v;
  }
  return out;
}

function record(dataDir, payload) {
  if (!dataDir || !payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw Error('invalid funnel event');
  }
  const event = String(payload.event || '').trim();
  if (!ALLOWED_EVENTS.has(event)) throw Error('invalid funnel event');
  const entry = {
    ts: Date.now(),
    event,
    ...cleanMeta(payload.meta || payload),
  };
  const file = funnelPath(dataDir);
  fs.mkdirSync(dataDir, { recursive: true });
  try {
    const stat = fs.statSync(file);
    if (stat.size >= MAX_BYTES) {
      fs.renameSync(file, file + '.prev');
    }
  } catch (e) {
    if (e.code !== 'ENOENT') throw e;
  }
  fs.appendFileSync(file, JSON.stringify(entry) + '\n', { mode: 0o600 });
  return entry;
}

function summarize(dataDir) {
  const counts = {};
  const file = funnelPath(dataDir);
  let text = '';
  try {
    const stat = fs.statSync(file);
    if (stat.size > MAX_BYTES) {
      const fd = fs.openSync(file, 'r');
      const buf = Buffer.alloc(65536);
      const read = fs.readSync(fd, buf, 0, buf.length, stat.size - buf.length);
      fs.closeSync(fd);
      text = buf.toString('utf8', 0, read);
      const nl = text.indexOf('\n');
      if (nl >= 0) text = text.slice(nl + 1);
    } else {
      text = fs.readFileSync(file, 'utf8');
    }
  } catch {
    return { counts, total: 0 };
  }
  let total = 0;
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      const row = JSON.parse(line);
      if (row && typeof row.event === 'string') {
        counts[row.event] = (counts[row.event] || 0) + 1;
        total++;
      }
    } catch {}
  }
  return { counts, total };
}

module.exports = { record, summarize, ALLOWED_EVENTS, MAX_BYTES };
