'use strict';
const {meetingClock}=require('./meeting-time');
// MINUTES-LINK（Aaron 10-23）：开完会，方案文档最底部「会议纪要」小节多一行这场会的链接，
// 点开是本机的单场纪要页（总结 / 待办 / 转写）。页面现读归档与处理台的数据，不另存副本；
// 方案文档正文里只有标题、日期和链接，不放纪要正文或转写原文。只走本机，不外传。
const crypto=require('crypto');
const MEETING_ID=/^[A-Za-z0-9_-]{1,80}$/; // 与 server.js loadSession 同一条规则，链接打得开才写
const SECTION='meeting-minutes',ROW=SECTION+':',PATH='/asr-relay/meeting-minutes';
const text=node=>(node.text||'')+(node.content||[]).map(text).join('');
const pad=n=>String(n).padStart(2,'0');
const day=value=>{const d=new Date(value);return Number.isNaN(d.getTime())?'':d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
const href=meetingId=>PATH+'?id='+encodeURIComponent(meetingId);
const blockId=()=>'b-'+crypto.randomBytes(8).toString('hex');
const rowOf=node=>typeof node?.attrs?.sourceRef==='string'&&node.attrs.sourceRef.startsWith(ROW)?node.attrs.sourceRef.slice(ROW.length):'';
const time=value=>{const t=new Date(value||0).getTime();return Number.isFinite(t)?t:0;};

function summaryBlocks(summary,meetingId){
 const raw=String(summary||'').trim();
 if(!raw)return [];
 const out=[],ref=ROW+meetingId;
 let bullets=[];
 const flushBullets=()=>{
  if(!bullets.length)return;
  out.push({type:'bulletList',attrs:{blockId:blockId(),sourceRef:ref},content:bullets.map(t=>({type:'listItem',content:[{type:'paragraph',attrs:{blockId:blockId(),sourceRef:ref},content:[{type:'text',text:t}]}]}))});
  bullets=[];
 };
 for(const rawLine of raw.split(/\r?\n/)){
  const line=rawLine.trim();
  if(!line){flushBullets();continue;}
  const h=line.match(/^#{1,4}\s+(.+)$/);
  if(h){flushBullets();out.push({type:'heading',attrs:{level:3,blockId:blockId(),sourceRef:ref},content:[{type:'text',text:h[1].replace(/\*\*/g,'').trim()}]});continue;}
  const b=line.match(/^(?:[-*•]|\d+[.)])\s+(.+)$/);
  if(b){bullets.push(b[1].replace(/\*\*/g,'').trim());continue;}
  flushBullets();
  out.push({type:'paragraph',attrs:{blockId:blockId(),sourceRef:ref},content:[{type:'text',text:line.replace(/\*\*/g,'')}]});
 }
 flushBullets();
 return out;
}
// 只动文档末尾那个「会议纪要」小节：没有才新建；已有就只在它的链接行之间插一行。
// 其余节点（包括这一节里他自己写的字）原样不动。返回 null = 这场已经链过，不改。
function placeLink(content,{meetingId,title,at,summary},known={}){
 const nodes=content.content||(content.content=[]);
 if(!meetingId||nodes.some(n=>rowOf(n)===meetingId))return null;
 let head=nodes.findIndex(n=>n.type==='heading'&&n.attrs?.sourceRef===SECTION);
 if(head<0){nodes.push({type:'heading',attrs:{level:2,blockId:blockId(),sourceRef:SECTION},content:[{type:'text',text:'会议纪要'}]});head=nodes.length-1;}
 let end=head+1;while(end<nodes.length&&nodes[end].type!=='heading')end++;
 const mine=time(at);let place=head+1;
 for(let i=head+1;i<end;i++){const id=rowOf(nodes[i]);if(!id)continue;if(time(known[id]?.at)>mine){place=i;break;}place=i+1;}
 const label=String(title||'').trim().slice(0,160)||'未命名会议',date=day(at);
 const row={type:'paragraph',attrs:{blockId:blockId(),sourceRef:ROW+meetingId},content:[{type:'text',text:label,marks:[{type:'link',attrs:{href:href(meetingId),target:'_blank',rel:'noopener noreferrer'}}]},...(date?[{type:'text',text:' · '+date}]:[])]};
 const extra=summaryBlocks(summary,meetingId);
 nodes.splice(place,0,row,...extra);return content;
}

// 会后（归档跑完）由服务端调用。没绑方案文档的会不动；同一场整理多次只记一次，
// 他删掉那一行后也不会被下一次整理加回来（收据在 record.minutesLinks）。
function linkMeeting(store,{documentId,meetingId,title,at,summary=''}){
 if(!documentId||!meetingId)return {changed:false,why:'unbound'};
 if(!MEETING_ID.test(String(meetingId)))return {changed:false,why:'bad-id'};
 const entry=store.read(documentId),record=entry.record,known=record.minutesLinks||{};
 if(!(record.meetings||[]).includes(meetingId))return {changed:false,why:'not-in-document'};
 if(known[meetingId])return {changed:false,why:'already-linked'};
 return store.addMinutesLink(documentId,{meetingId,title,at:at||'',summary:String(summary||'')},placeLink);
}

const {esc,markdown}=require('../web/safe-markdown');
// 新旧两种纪要都有一个标题带「待办」的小节（「## 3. 待办」/「## 核心待办」），拆出来单独成块。
function splitNote(note){
 const lines=String(note||'').split('\n'),summary=[],todos=[];let inTodo=false,level=0;
 for(const line of lines){
  const h=line.match(/^(#{1,4})\s+(.*)$/);
  const boldH=!h&&line.match(/^\s*\*\*(.{1,40})\*\*\s*[：:]?\s*$/);
  if(h&&/待办|To-?dos?|Action items|アクション/i.test(h[2])){inTodo=true;level=h[1].length;continue;}
  if(boldH&&/待办|To-?dos?|Action items|アクション/i.test(boldH[1])){inTodo=true;level=4;continue;}
  if(h&&inTodo&&h[1].length<=level)inTodo=false;
  (inTodo?todos:summary).push(line);
 }
 return {summary:summary.join('\n').trim(),todos:todos.join('\n').trim()};
}
// The full note and transcript stay available in a separate view; the main
// screen is the approved #note prototype, without the old layered sections.
function page(session,note,{who},research){
 if(research){const minutes=require('./live-research').meetingMinutes(session,note);minutes.todos=minutes.todos.map(t=>({...t,id:research.minutes?.todos?.find(a=>a.text===t.text)?.id||t.id}));return require('./live-research-http').afterPage(session,{...research,minutes});}
 const content=require('./minutes-content'),v=content.view(session,note),rows=Array.isArray(session.transcript)?session.transcript:[];
 let last=null;const transcript=rows.map(r=>{const name=who(session,r.speaker);const head=name&&name!==last?'<p class="who">'+esc(name)+'</p>':'';if(name)last=name;return head+'<p class="line"><span class="t">'+esc(meetingClock(r.at??r.atSec??r.t,session.start??session.startTs))+'</span>'+esc(String(r.text||'').replace(/\n+/g,' ').trim())+'</p>';}).join('\n');
 const colors=['#5B8DEF','#E0822A','#2C8C5F'];
 return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>'+esc(v.title)+' · 会议纪要</title><style>'+
 ':root{--bg:#F3F4F8;--paper:#FBFBFD;--card:#FFFFFF;--line:rgba(28,36,64,.09);--text:#1D1D1F;--sub:#6E6E73;--faint:#8A8A8F;--link:#0A74E0;--ok:#2C8C5F;--fd:#5B57D6;--hover:rgba(28,36,64,.06)}'+
 '@media(prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#111;--paper:#1a1a1a;--card:#232323;--line:#2f2f2d;--text:#ececea;--sub:#a0a09b;--faint:#858581;--link:#6CB2FF;--ok:#4CC38A;--fd:#A9A6FF;--hover:rgba(255,255,255,.07);color-scheme:dark}}'+
 ':root[data-theme="dark"]{--bg:#111;--paper:#1a1a1a;--card:#232323;--line:#2f2f2d;--text:#ececea;--sub:#a0a09b;--faint:#858581;--link:#6CB2FF;--ok:#4CC38A;--fd:#A9A6FF;--hover:rgba(255,255,255,.07);color-scheme:dark}'+
 '*{box-sizing:border-box}[hidden]{display:none!important}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.6 -apple-system,BlinkMacSystemFont,"PingFang SC","Helvetica Neue",sans-serif;padding:32px 16px 56px}'+
 'main,.full-record{max-width:766px;margin:0 auto;background:transparent;border:0;border-radius:0;box-shadow:none;min-width:0;overflow:hidden}.note{padding:26px 30px 24px;display:grid;gap:18px}'+
 'h1{font-size:21px;line-height:1.35;margin:0}.meta{color:var(--sub);font-size:13px;margin-top:2px}.bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center}'+
 'button,a{font:inherit;color:inherit}button{background:none;border:0;padding:0;cursor:pointer}button:disabled{cursor:default}button:focus-visible,a:focus-visible{outline:2px solid var(--link);outline-offset:2px;border-radius:6px}'+
 '.pill{display:inline-flex;gap:6px;align-items:center;border:1px solid var(--line);border-radius:999px;padding:5px 12px;font-size:13px;background:var(--card);text-decoration:none}.pill.on{color:var(--ok)}'+
 '.sec{font-size:13px;color:var(--faint);margin:0 0 6px}.topic{margin:0 0 12px}.topic b{font-weight:600;display:block}.topic p{margin:2px 0 0;color:var(--sub);font-size:14.5px}'+
 '.todo{display:flex;gap:10px;align-items:baseline;padding:4px 0;font-size:14.5px}.todo input{margin:0;flex:none}.todo span{color:var(--faint);font-size:13px;white-space:nowrap;margin-left:auto}.more{color:var(--link);font-size:14px;text-decoration:none;justify-self:start}'+
 '.people{display:inline-flex;vertical-align:middle;margin-right:8px}.people i{display:grid;place-items:center;width:22px;height:22px;border-radius:50%;border:2px solid var(--paper);margin-left:-5px;font-size:10px;font-style:normal;color:white}.people i:first-child{margin-left:0}'+
 '.empty{color:var(--sub);font-size:14px;margin:0}.full-record{padding:26px 0}.full-record h2{font-size:18px}.full-record h3{font-size:15px}.who{font-weight:600;margin:12px 0 2px}.line{margin:2px 0;overflow-wrap:anywhere}.t{color:var(--sub);font:12px ui-monospace,Menlo,monospace;margin-right:8px}table{border-collapse:collapse}td,th{border:1px solid var(--line);padding:6px;text-align:left}'+
 // Final approved prototype overrides; flat: no boxed blocks, hierarchy from type, space and hairlines.
 '.note{gap:22px;padding:30px 0 26px}.note h1{font-size:23px;letter-spacing:-.01em}.people{vertical-align:-5px;margin-right:6px}.people i{width:20px;height:20px;border:0;font:600 10px/1 -apple-system,"PingFang SC",sans-serif;box-shadow:0 0 0 2px var(--paper)}'+
 '.pill{padding:6px 13px;box-shadow:0 1px 2px rgba(28,36,64,.05)}.pill:hover{background:var(--hover)}.sec{font-weight:500;letter-spacing:.02em}.block{background:none;border:0;border-radius:0;padding:0}'+
 '.topic{display:grid;grid-template-columns:7px minmax(0,1fr);column-gap:10px}.topic::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--link);margin-top:9px}.topic:nth-of-type(2)::before{background:var(--fd)}.topic:nth-of-type(3)::before{background:var(--ok)}.topic p{grid-column:2}'+
 '.todo{padding:6px 0}.todo input{appearance:none;-webkit-appearance:none;width:17px;height:17px;border-radius:50%;border:1.5px solid var(--faint);align-self:center;cursor:pointer;background:none}.todo input:checked{background:var(--ok);border-color:var(--ok);box-shadow:inset 0 0 0 3px var(--card)}.todo:has(input:checked){color:var(--faint);text-decoration:line-through}'+
 '</style></head><body><main id="minutes-note" data-meeting-id="'+esc(session.id)+'"><div class="note">'+
 '<div><h1>'+esc(v.title)+'</h1><div class="meta"><span class="people">'+v.meta.participants.slice(0,3).map((n,i)=>'<i style="background:'+colors[i]+'">'+esc(n.slice(0,1))+'</i>').join('')+'</span>'+esc(v.meta.text)+'</div></div>'+
 '<div class="bar" id="minutes-share" aria-live="polite"><button type="button" class="pill" data-minutes-send>发到 Notion</button></div>'+
 '<section id="minutes-summary" class="block"><p class="sec">总结</p>'+(v.topics.length?v.topics.map(t=>'<div class="topic"><b>'+esc(t.conclusion)+'</b>'+(t.detail?'<p>'+esc(t.detail)+'</p>':'')+'</div>').join(''):'<p class="empty">这一场还没有整理好的总结。</p>')+'</section>'+
 '<section id="minutes-todos" class="block"><p class="sec">待办</p>'+(v.todos.length?v.todos.map((t,i)=>'<label class="todo"><input type="checkbox" data-minutes-todo="'+i+'">'+esc(t.text)+'<span>'+esc(t.owner||'未指定')+' · '+esc(t.due||'未定日期')+'</span></label>').join(''):'<p class="empty">这一场没有记录待办。</p>')+'</section>'+
 '<a class="more" href="#minutes-transcript" data-minutes-transcript>查看完整转写</a></div></main>'+
 '<section class="full-record" id="minutes-transcript" hidden><button type="button" class="more" data-minutes-back>‹ 会后纪要</button><h2>完整转写（'+rows.length+' 条）</h2>'+(transcript||'<p class="empty">这一场没有录到转写。</p>')+
 '<details><summary>产出内容</summary>'+markdown(note)+'</details></section>'+
 '<script src="/asr-relay/meeting-board/minutes-client.js"></script></body></html>';
}
module.exports={SECTION,PATH,href,placeLink,linkMeeting,splitNote,markdown,page};
