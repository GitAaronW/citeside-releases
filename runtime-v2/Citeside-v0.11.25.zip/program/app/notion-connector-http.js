'use strict';
const connector=require('./notion-connector');
const LOOPBACK=new Set(['127.0.0.1','::1','::ffff:127.0.0.1']);
async function route(req,res,url,ctx){
 const p=url.pathname.replace(/^\/asr-relay/,'');if(!['/connectors/notion','/connectors/notion/callback'].includes(p))return false;
 const json=(status,body)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','Referrer-Policy':'no-referrer'});res.end(JSON.stringify(body));return true;};
 const local=LOOPBACK.has(req.socket?.remoteAddress)&&!Object.keys(req.headers||{}).some(h=>h==='forwarded'||h.startsWith('x-forwarded-')||h==='tailscale-funnel-request');
 if(p.endsWith('/callback')){
  if(req.method!=='GET'||!local)return json(403,{ok:false,errorCode:'local_callback_required'});
  try{const outcome=await connector.callback(ctx.dataDir,Object.fromEntries(['code','state','error','iss'].map(k=>[k,url.searchParams.get(k)])),ctx);try{await (ctx.returnToApp||require('./desktop-open').returnToNative)();}catch{}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Referrer-Policy':'no-referrer'});res.end(require('./oauth-callback-page').renderOAuthCallbackPage({service:'notion',status:outcome.cancelled?'cancelled':'success',lang:url.searchParams.get('lang')||'',acceptLanguage:req.headers['accept-language']||''}));return true;}catch(error){return json(400,{ok:false,errorCode:error.message});}
 }
 if(!ctx.authed)return json(401,{ok:false,errorCode:'authentication_required'});
 try{
  if(req.method==='GET')return json(200,{ok:true,status:await connector.status(ctx.dataDir,ctx)});
  if(req.method!=='POST')return json(405,{ok:false,errorCode:'method_not_allowed'});
  if(!ctx.owner||!local)return json(403,{ok:false,errorCode:'owner_local_required'});
  let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>16000)return json(413,{ok:false,errorCode:'request_too_large'});}let body;try{body=JSON.parse(raw||'{}');}catch{return json(400,{ok:false,errorCode:'invalid_json'});}
  if(body.action==='connect')return json(200,{ok:true,...await connector.connect(ctx.dataDir,ctx)});
  if(body.action==='select')return json(200,{ok:true,status:await connector.select(ctx.dataDir,body.ids)});
  if(body.action==='refresh')return json(200,{ok:true,status:await connector.refresh(ctx.dataDir,ctx)});
  if(body.action==='cancel')return json(200,{ok:true,status:await connector.cancel(ctx.dataDir,ctx)});
  if(body.action==='disconnect')return json(200,{ok:true,status:connector.disconnect(ctx.dataDir,ctx)});
  return json(400,{ok:false,errorCode:'invalid_action'});
 }catch(error){const code=/^[a-z_]{1,60}$/.test(error.message)?error.message:'connector_failed';return json(400,{ok:false,errorCode:code});}
}
module.exports={route};
