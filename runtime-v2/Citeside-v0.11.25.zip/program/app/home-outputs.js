'use strict';
// Home-rail recent outputs: deep research reports only.
// Meeting notes stay in 会议记录. Scheme documents and drafts stay in the meeting.
// Titles only. Ordinary meeting markdown is not an output.
// Not a new library. Outline (BSL) and AppFlowy (AGPL) are not vendored.
const fs = require('fs');
const path = require('path');

const clip = (s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);
const {researchOf,snapshot,sidOk}=require('./saved-research');

function meetingName(sid, titles, sources) {
  const titled = titles && titles[sid] && titles[sid].topicTitle;
  const source = (sources || []).find(s => s && s.sessionId === sid);
  return clip(titled || (source && source.title) || '', 80);
}

function list({ dataDir = '', sources = [], titles = {}, limit = 8, all = false, deletedIds = [] } = {}) {
  const cap = all===true?Infinity:Math.max(1, Math.min(20, Number(limit) || 8)),gone=new Set(deletedIds.map(String));
  const items = [];
  let files = [];
  try { const dir=path.join(dataDir,'live-reports');if(fs.lstatSync(dir).isSymbolicLink())return [];files = fs.readdirSync(dir).filter(f => f.endsWith('.json') && !f.startsWith('.')); }
  catch (e) {}
  for (const file of files) {
    const sid = file.slice(0, -5);
    if (!sidOk(sid)||gone.has(sid)) continue;
    let report;try{report=snapshot(dataDir,sid);}catch{continue;}
    if (!report || typeof report !== 'object' || Array.isArray(report)) continue;
    const meeting = meetingName(sid, titles, sources);
    const atReport = report.updatedAt || '';
    for (const row of researchOf(report)) {
      items.push({ id: 'research:' + sid + ':' + row.id, sessionId: sid, kind: 'research', title: row.title, meeting, at: row.at || atReport });
    }
  }
  let lrFiles = [];
  try {
    const lrDir = path.join(dataDir, 'live-research');
    if (!fs.lstatSync(lrDir).isSymbolicLink()) {
      lrFiles = fs.readdirSync(lrDir).filter(f => f.endsWith('.json') && !f.startsWith('.'));
    }
  } catch (e) {}
  for (const file of lrFiles) {
    const sid = file.slice(0, -5);
    if (!sidOk(sid) || gone.has(sid)) continue;
    let lr;
    try {
      const full = path.join(dataDir, 'live-research', file);
      if (fs.lstatSync(full).isSymbolicLink() || !fs.statSync(full).isFile()) continue;
      lr = JSON.parse(fs.readFileSync(full, 'utf8'));
    } catch { continue; }
    if (!lr || typeof lr !== 'object' || !Array.isArray(lr.items)) continue;
    const meeting = meetingName(sid, titles, sources) || clip(lr.title || '', 80);
    for (const row of lr.items) {
      if (!row || !(['done','stopped','partial'].includes(row.state) || !!row.pause) || !row.id) continue;
      const title = clip(row.title || row.conclusion || '', 80);
      if (!title) continue;
      const ts = row.completedAt || row.deepStartedAt || row.openedAt;
      const at = typeof ts === 'number' && Number.isFinite(ts) ? new Date(ts).toISOString() : (typeof ts === 'string' ? ts : (lr.updatedAt || ''));
      items.push({ id: 'lr:' + sid + ':' + String(row.id).slice(0, 80), sessionId: sid, kind: 'research', title, meeting, at, state: (row.state === 'stopped' || row.pause) ? 'stopped' : row.state, itemId: String(row.id).slice(0, 80) });
    }
  }
  items.sort((a, b) => (Date.parse(b.at) || 0) - (Date.parse(a.at) || 0));
  return items.slice(0, cap).map(({ id, sessionId, kind, title, meeting, at, state, itemId }) => ({ id, sessionId, kind, title, meeting, at, ...(state ? { state } : {}), ...(itemId ? { itemId } : {}) }));
}

module.exports = { list };
