'use strict';

// Single-Brain Proactive Intelligence Engine (v3)
// Replaces 4 competing live-meeting LLM loops with ONE unified 2-stage brain:
//   Stage 1 (1 fast LLM call): unified triage + working memory update across all 4 core card types
//     - blind_spot & memory_conflict emit immediately (~2s, 0 search wait)
//     - fact_check & external_case enqueue up to 2 search targets
//   Stage 2 (parallel search + 1 verify-and-write LLM call):
//     - Hard Red Line: 0 fabricated URLs (every URL must belong to real opened search results)
//     - Honest Grading: quoted (exact quote + numbersSupported) vs source (real https:// page + numbersConsistent)
//     - Structured funnel diagnostics (0 black-box drops)

const numNorm = require('./number-normalize');
const scenarioMod = require('./meeting-scenario');
const dedupe = require('./grounded-card-dedupe');

const BADGE_MAP = {
  fact_check: { zh: '事实核查', en: 'Fact check', ja: '事実確認' },
  blind_spot: { zh: '关键盲区', en: 'Blind spot', ja: '重要な盲点' },
  external_case: { zh: '外部案例', en: 'External case', ja: '外部事例' },
  memory_conflict: { zh: '历史踩坑', en: 'Memory conflict', ja: '過去の教訓' }
};

const UI_STRINGS = {
  zh: { needsVerify: '待核实', verified: '权威来源', publicSource: '公开来源', pastMemory: '跨会记忆' },
  en: { needsVerify: 'Needs verification', verified: 'Verified', publicSource: 'Public source', pastMemory: 'Past meeting memory' },
  ja: { needsVerify: '要確認', verified: '権威ソース', publicSource: '公開ソース', pastMemory: '過去の会議記憶' }
};

const MODEL_LIMIT = 900;
const MAX_SEARCH_CANDIDATES_PER_WAKE = 2;
const DEFAULT_BASE_SEARCHES = 15;
const DEFAULT_MAX_SEARCHES_CAP = 45;
const CONSISTENT_WASTE_RE = /^(?:(?:经核实|公开资料显示|核实一致|与公开资料一致)|.*?(?:与公开资料一致|与事实一致|与事实相符|说法正确|表述准确|基本准确|基本正确|基本属实|完全属实))(?![^。]*?(?:但|不过|并非|实际|而是|误|错|高估|低估))/;

function canonicalUrl(raw) {
  try {
    const u = new URL(String(raw || '').trim());
    u.hash = '';
    return u.toString().replace(/\/$/, '');
  } catch {
    return String(raw || '').trim();
  }
}

function extractRelevantExcerpt(rawText, queries, maxLen = 2800) {
  const text = String(rawText || '').replace(/\s+/g, ' ').trim();
  if (text.length <= maxLen) return text;
  const tokens = String((queries || []).join(' '))
    .toLowerCase()
    .split(/[\s,，。、/|]+/)
    .map(t => t.trim())
    .filter(t => t.length >= 2);
  if (!tokens.length) return text.slice(0, maxLen);
  const low = text.toLowerCase();
  let bestPos = 0;
  let bestScore = -1;
  const step = 400;
  for (let pos = 0; pos < text.length; pos += step) {
    const win = low.slice(pos, pos + maxLen);
    let score = 0;
    for (const tk of tokens) {
      if (win.includes(tk)) score++;
    }
    if (score > bestScore) {
      bestScore = score;
      bestPos = pos;
    }
    if (pos + maxLen >= text.length) break;
  }
  if (bestScore <= 0) return text.slice(0, maxLen);
  const start = Math.max(0, bestPos - 200);
  return text.slice(start, start + maxLen);
}

function parseJsonObject(raw) {
  const s = String(raw || '').trim();
  if (!s) return null;
  let pos = 0;
  let fallback = null;
  while (pos < s.length) {
    const start = s.indexOf('{', pos);
    if (start < 0) break;
    let depth = 0, inStr = false, esc = false, end = -1;
    for (let i = start; i < s.length; i++) {
      const ch = s[i];
      if (inStr) {
        if (esc) { esc = false; continue; }
        if (ch === '\\') { esc = true; continue; }
        if (ch === '"') inStr = false;
        continue;
      }
      if (ch === '"') { inStr = true; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) { end = i; break; }
      }
    }
    if (end < 0) break;
    try {
      const obj = JSON.parse(s.slice(start, end + 1));
      if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
        if ('insight' in obj || 'probes' in obj || 'cards' in obj || 'verdict' in obj || 'meetingModel' in obj) return obj;
        if (!fallback) fallback = obj;
      }
      pos = end + 1;
    } catch {
      pos = start + 1;
    }
  }
  return fallback;
}

function normText(s) {
  return String(s || '').replace(/[\s\p{P}\p{S}]+/gu, '').toLowerCase();
}

function groundQuote(excerpt, quote) {
  const ex = String(excerpt || '').replace(/\s+/g, ' ').trim();
  const q = String(quote || '').replace(/\s+/g, ' ').trim();
  if (!ex || q.length < 12) return '';
  if (ex.includes(q)) return q;
  const exLow = ex.toLowerCase(), qLow = q.toLowerCase();
  const idx = exLow.indexOf(qLow);
  if (idx >= 0) return ex.slice(idx, idx + q.length);
  return '';
}

function withBadge(kind, card, langOrEn) {
  const safeKind = BADGE_MAP[kind] ? kind : 'blind_spot';
  const lang = langOrEn === true ? 'en' : (langOrEn === false || !langOrEn ? 'zh' : (String(langOrEn).toLowerCase().startsWith('en') ? 'en' : String(langOrEn).toLowerCase().startsWith('ja') ? 'ja' : 'zh'));
  return {
    ...card,
    cardKind: safeKind,
    semanticBadge: BADGE_MAP[safeKind][lang] || BADGE_MAP[safeKind].zh
  };
}

function targetUiLang(session) {
  const raw = String(session?.uiLang || 'zh').toLowerCase();
  if (raw.startsWith('en')) return { code: 'en', name: 'English' };
  if (raw.startsWith('ja')) return { code: 'ja', name: 'Japanese (日本語)' };
  return { code: 'zh', name: 'Simplified Chinese (简体中文)' };
}

function buildTriageSystemPrompt(session, scenario) {
  const lang = targetUiLang(session);
  const en = lang.code === 'en' || lang.code === 'ja';
  const hardOnly = !!scenario?.hardEvidenceOnly;
  const minGain = hardOnly ? 4 : 3;
  if (en) {
    return [
      'You are an expert domain copilot sitting beside the user. Cards are private to the user.',
      `STRICT OUTPUT LANGUAGE: You MUST write "title", "text", "details", and "meetingModel" strictly in ${lang.name}, EVEN IF the transcript is in Chinese or another language. Keep "claim" and "basis" verbatim in the original transcript/memory language (do NOT translate claim or basis).`,
      `Current scenario: ${scenario?.label || 'Active mode'} (${scenario?.goal || ''}). Target ONLY rows with isNew:true (older rows are context only).`,
      'Output TWO INDEPENDENT channels in one JSON response:',
      'CHANNEL 1 — "insight" (emitted immediately ~2s, zero search wait): either null OR ONE high-signal blind_spot / memory_conflict with an explicit integer "gain" score (1-5):',
      '  - gain 5: changes a decision, exposes a major compliance/financial trap, or directly contradicts past memoryHints (for memory_conflict, copy >=12 verbatim chars into "basis").',
      '  - gain 3: exposes a SPECIFIC omitted premise, hidden cost, perverse incentive, or concrete risk AND states why it matters to the listener (what breaks or what to ask).',
      '  - gain 1 (MUST return insight: null): flat background trivia/textbook facts that do not name a missing risk or impact, restating what the speaker said, common knowledge, or speaker-style commentary.',
      hardOnly
        ? '  Low-interruption mode: set insight ONLY for direct memory_conflict (gain >= 4); otherwise insight: null.'
        : `  Active mode (Information-Gain First): emit insight ONLY when it delivers genuine NEW, useful incremental value (gain >= ${minGain}, NOT in shownCards) that changes how the listener understands or acts. If the speaker already explained the point cleanly, return insight: null — never manufacture a textbook trivia card just to fill space.`,
      'CHANNEL 2 — "probes" (0 to 2 silent background web-verification probes; skip if searchAvailable:false):',
      '  - Add a probe ONLY for concrete verifiable claims (specific numbers, years, percentages, order of magnitude, policy scope, or external best-practice benchmarks) that may be wrong, outdated, missing a key caveat, OR worth contrasting with a concrete cross-country/cross-company precedent.',
      '  - For relative time ("this year"/"last year"/"next year"/"recent"/"latest"), convert using payload "today" into explicit calendar years (e.g. today=2026-11-25 -> this year=2026, last year=2025, next year=2027) BEFORE constructing queries.',
      '  - Probes run silently in the background and NEVER block or delay Channel 1 ("insight").',
      '4 MUST_SILENT rules: (a) metaphors/rhetoric/slang; (b) subjective opinions/speaker style; (c) confirming the speaker is right with zero new data; (d) repeating any point already in shownCards.',
      'Style: sharp note from a smart colleague — 1 crisp sentence (<=30 words), zero preamble. For sourceIds, ONLY copy real row "id" values from recentTranscript.',
      'Return strict JSON only: {"meetingModel":"<=700 char running thread + key numbers","insight":{"kind":"blind_spot|memory_conflict","gain":4,"title":"<=10 words","text":"1 crisp sentence","basis":"verbatim memory quote if memory_conflict","sourceIds":["real_row_id"]}|null,"probes":[{"claim":"verbatim claim","queries":["query1","query2"],"sourceIds":["real_row_id"]}]}'
    ].join('\n');
  }
  return [
    '你是坐在用户旁边的顶级行业专家副驾，卡片只给用户本人看。',
    '严格输出语言：无论转写是中文、英文还是日文，title、text、details 和 meetingModel 必须严格使用简体中文；claim 与 basis 必须保持原转写/记忆原文（不要翻译）。',
    `当前场景：${scenario?.label || '积极模式'}（${scenario?.goal || ''}）。只针对 isNew:true 的新转写句触发（旧句仅作背景理解）。`,
    '每次返回相互独立的两个通道（互不挤占、互不阻塞）：',
    '通道 1 — "insight"（约 2 秒立即弹出，完全不等联网搜索）：返回 null 或 1 条高价值 blind_spot / memory_conflict，并给出 1~5 整数价值分 "gain"：',
    '  - gain 5：会直接改变决策、拆穿重大合规/财务陷阱，或与 memoryHints 跨会决定直接冲突（memory_conflict 须在 basis 原样摘录 >=12 字）。',
    '  - gain 3：明确点出「讲者漏掉了什么前提/风险/隐含成本」+「对当前判断或决策的实际影响/该追问什么」（例：只谈减税率忽略社保统筹征管趋严，企业实际综合负担未必同步下降）。',
    '  - gain 1（必须填 null）：纯背景科普/教科书式陈述（如「计划经济下企业利润全额上缴，税收占比极低」这类看不出盲区也无决策价值的废卡）、复述原话、常识废话或点评讲者风格。',
    hardOnly
      ? '  低打扰模式：仅当出现明确 memory_conflict（gain >= 4）时填 insight，其余填 null。'
      : `  积极模式（增量信息第一原则）：宁缺毋滥——只有当卡片能提供讲者未说破的「高增量有用信息」（gain >= ${minGain} 且不与 shownCards 重复，能直接改变听众理解、指出实操风险或值得追问）时才填 insight；如果讲者已经讲清楚了，直接填 null，绝不为凑数硬编教科书式背景卡。`,
    '通道 2 — "probes"（0~2 条后台静默核查探针；若 searchAvailable:false 返回 []）：',
    '  - 仅针对具体可核查的客观硬事实（数字、年份、比例、数量级、政策边界）或值得对照跨国/跨公司最佳实践的议题发出探针；绝不对主观观点、历史动因归纳或口语比喻发探针。',
    '  - 凡涉及「今年/去年/明年/近期/最新」等相对时间，必须先按 payload 中的 today 换算为绝对年份（如 today=2026-11-25 → 今年=2026、去年=2025、明年=2027）再构造搜索词。',
    '  - probes 在后台静默核验，绝不阻塞通道 1 的 insight 弹出。',
    '4条严禁红线（MUST_SILENT）：① 吐槽口语比喻/反讽/网梗；② 点评主观政治观点或讲者风格；③ 讲者已讲准且无新标尺的复述确认；④ 与 shownCards 重复或同义的旧话题。',
    '说话风格：像懂行老同事递纸条——直接 1 句核心结论（<=50字），零铺垫。sourceIds 只允许填 recentTranscript 中真实存在的行 id。',
    '只返回严格 JSON：{"meetingModel":"<=700字主线+关键数字口径","insight":{"kind":"blind_spot|memory_conflict","gain":4,"title":"<=16字结论","text":"1句<=50字结论","basis":"记忆原句","sourceIds":["真实行id"]}|null,"probes":[{"claim":"待核查原话","queries":["检索词"],"sourceIds":["真实行id"]}]}'
  ].join('\n');
}

function buildVerifyWriteSystemPrompt(session) {
  const lang = targetUiLang(session);
  const en = lang.code === 'en' || lang.code === 'ja';
  if (en) {
    return [
      'You are verifying a meeting probe against opened web pages and deciding whether to emit ONE concise private card.',
      `STRICT OUTPUT LANGUAGE: You MUST write "title", "text", "details", and "caveat" strictly in ${lang.name}, EVEN IF the transcript or opened web excerpts are in Chinese or another language. Keep "quote" verbatim in the original webpage language so substring verification succeeds.`,
      'Return one of three verdicts:',
      '- verdict="correction": when the speaker stated a wrong/misleading number, year, ratio, order of magnitude, or fact, OR omitted a critical legal/policy caveat that would mislead the user. MUST use explicit contrast phrasing "Meeting said X → Actually Y" (never output standalone background trivia detached from the speaker\'s claim; if a number may be an ASR mishear, phrase as "If X was said → public data shows Y").',
      '- verdict="external_contrast": when the opened page adds concrete external value the speaker did NOT mention — either a cross-country/cross-company benchmark/precedent OR a key official statistic, scope detail, or historical figure that materially sharpens the decision. NEVER use external_contrast just to confirm or repeat what the speaker already got right.',
      '- verdict="skip": when the speaker is basically accurate and the page adds no new external number, caveat, or precedent.',
      'HARD RULE: Every source URL MUST be copied verbatim from the provided opened pages. Never invent a URL. Convert relative time ("this year"/"last year"/"next year"/"recent"/"latest") using payload "today" into explicit calendar years. NEVER use sources older than the period discussed or reports >1 year older than payload "today" to refute or "correct" newer data or current ("this year") status.',
      'Return strict JSON only: {"verdict":"correction|external_contrast|skip","title":"<=10 words","text":"1 concise sentence (<=30 words; for correction use contrast \'Meeting said X → Actually Y\')","details":"optional detail","caveat":"optional caveat","credibility":"Verified|Public source","sources":[{"name":"source name","url":"https://...","quote":"verbatim quote >=12 chars from excerpt"}]}'
    ].join('\n');
  }
  return [
    '你正在根据程序已打开的公开网页正文，对会议探针做客观核验并决定是否输出 1 张极简卡片。',
    '严格输出语言：无论转写或网页是何种语言，title 与 text 必须严格使用简体中文；quote 必须原样摘录网页原文（不要翻译）。',
    '从以下 3 种结论中严格选一：',
    '- verdict="correction"：当发言讲错数字/年份/比例/数量级/事实，或漏掉关键免税/政策边界导致结论误用时使用（绝不对正确陈述发确认废卡）。强制采用对比句式「会上说 X → 实际是 Y」，明确对照发言原话与核查事实，严禁只输出脱离原话的科普。',
    '- verdict="external_contrast"：当网页提供了讲者未提及的硬核外部增量——包括跨国/跨公司/跨行业标尺先例，或能明显补齐盲区的官方统计数字、政策适用范围、关键时间线细节；严禁仅用来复述或证实讲者刚说对的内容。',
    '- verdict="skip"：仅当发言基本准确且网页未提供任何新的外部数字、边界条件或跨主体参照时返回 skip。',
    '硬红线：sources 里的 url 必须原样来自提供的 opened 网页列表，严禁编造网址；text 严格 1 句话（<= 60字），直给结论，零铺垫；凡涉及「今年/去年/明年/近期/最新」须先按 payload 中的 today 换算为绝对年份，来源日期早于会议所述期间或早于当前年份 1 年以上的往年旧报告/旧词条，严禁用来反驳或纠错较新数据及讲话者提到的“今年/当前”事实。',
    '只返回严格 JSON：{"verdict":"correction|external_contrast|skip","title":"<=18字结论","text":"1句话<=60字结论（correction 必须用「会上说 X → 实际是 Y」对比句式）","credibility":"权威来源|公开来源","sources":[{"name":"来源名","url":"https://...","quote":"从正文原样摘录>=12字引文"}]}'
  ].join('\n');
}

function create({
  session,
  ask,
  search,
  pageFetch,
  dataDir = '',
  env = () => ({}),
  log = () => {},
  now = Date.now,
  contextVersion = () => '',
  active = () => true,
  onStatus = () => {},
  onCard = () => true,
  onPending = () => {}
} = {}) {
  const getEnv = typeof env === 'function' ? env : () => env || {};
  const explicitMaxSearches = Number(getEnv().LIVE_EXPERT_MAX_SEARCHES) || 0;
  const startedSessionAt = now();
  function currentMaxSearches() {
    if (explicitMaxSearches > 0) return explicitMaxSearches;
    const elapsedMins = Math.max(0, (now() - startedSessionAt) / 60000);
    return Math.min(DEFAULT_MAX_SEARCHES_CAP, DEFAULT_BASE_SEARCHES + Math.floor(elapsedMins / 5) * 8);
  }
  const searchCache = new Map();
  const shownNorms = new Set();
  const shownCardsList = [];
  const shownUrls = new Map();
  const seenRowKeys = new Set();
  const emitTimestamps = [];
  let closed = false;
  let running = false;
  let waiting = null;
  let generation = 0;
  let wakeSeq = 0;
  let searchCount = 0;

  const stats = {
    engine: 'single-brain-v3',
    wakes: 0,
    triageCalls: 0,
    verifyCalls: 0,
    searchCalls: 0,
    searchCacheHits: 0,
    published: 0,
    emittedByKind: { fact_check: 0, blind_spot: 0, external_case: 0, memory_conflict: 0 },
    emittedByEvidence: { quoted: 0, source: 0, meeting: 0, memory: 0 },
    fabricatedUrlBlocked: 0,
    dropsByReason: {},
    recentDrops: []
  };

  function recordDrop(reason, detail) {
    stats.dropsByReason[reason] = (stats.dropsByReason[reason] || 0) + 1;
    stats.recentDrops.push({ at: now(), reason, ...detail });
    if (stats.recentDrops.length > 25) stats.recentDrops.shift();
  }

  function isDuplicate(title, text, urls = [], sourceIds = []) {
    const nt = normText(title);
    const nb = normText(text);
    if (nt && shownNorms.has('t:' + nt)) return true;
    if (nb && shownNorms.has('b:' + nb)) return true;
    const canonUrls = urls.map(canonicalUrl).filter(Boolean);
    for (const u of canonUrls) {
      if (shownUrls.has(u)) return true;
    }
    const cand = { text: `${title} ${text}`.trim(), urls: canonUrls, sourceIds: Array.isArray(sourceIds) ? sourceIds : [] };
    for (const prev of shownCardsList.slice(-15)) {
      if (dedupe.similar(cand, prev)) return true;
    }
    return false;
  }

  function rememberShown(kind, title, text, urls = [], sourceIds = []) {
    const nt = normText(title);
    const nb = normText(text);
    if (nt) shownNorms.add('t:' + nt);
    if (nb) shownNorms.add('b:' + nb);
    const canonUrls = urls.map(canonicalUrl).filter(Boolean);
    for (const u of canonUrls) shownUrls.set(u, { title, at: now() });
    shownCardsList.push({
      kind,
      title: String(title || '').slice(0, 60),
      text: String(text || '').slice(0, 120),
      urls: canonUrls,
      sourceIds: Array.isArray(sourceIds) ? sourceIds : []
    });
    if (shownCardsList.length > 25) shownCardsList.shift();
    emitTimestamps.push(now());
    while (emitTimestamps.length > 30) emitTimestamps.shift();
  }

  function recentCards5mCount() {
    const cutoff = now() - 5 * 60 * 1000;
    let c = 0;
    for (let i = emitTimestamps.length - 1; i >= 0; i--) {
      if (emitTimestamps[i] >= cutoff) c++;
      else break;
    }
    return c;
  }

  function live() {
    return !closed && !!active();
  }

  function defaultSearch(q) {
    const webTool = require('./tools/web');
    return webTool.search(q, 3, { dataDir, env: getEnv() });
  }

  function defaultFetch(url) {
    return require('./public-page-fetch').fetch(url, { timeoutMs: 8000 });
  }

  async function runSearch(query) {
    const key = String(query || '').trim().toLowerCase();
    if (!key) return [];
    if (searchCache.has(key)) {
      stats.searchCacheHits++;
      return searchCache.get(key);
    }
    if (searchCount >= currentMaxSearches()) {
      recordDrop('search_budget_exhausted', { query });
      return [];
    }
    searchCount++;
    stats.searchCalls++;
    const fn = search || defaultSearch;
    try {
      const res = await fn(query);
      const list = Array.isArray(res) ? res : (Array.isArray(res?.results) ? res.results : []);
      searchCache.set(key, list);
      return list;
    } catch (e) {
      log('proactive-brain search error: ' + (e && e.message || e));
      return [];
    }
  }

  async function openPages(queries) {
    const opened = new Map();
    const fetchFn = pageFetch || defaultFetch;
    for (const q of (queries || []).slice(0, 2)) {
      if (opened.size >= 2) break;
      const hits = await runSearch(q);
      // Prefer fresh URLs not already cited in earlier cards
      const freshHits = hits.filter(h => !shownUrls.has(canonicalUrl(h?.url)));
      const orderedHits = freshHits.length ? freshHits : hits;
      for (const h of orderedHits.slice(0, 3)) {
        if (opened.size >= 2) break;
        const url = String(h?.url || '').trim();
        if (!/^https:\/\//.test(url) || opened.has(url) || shownUrls.has(canonicalUrl(url))) continue;
        let excerpt = String(h?.excerpt || h?.content || h?.snippet || '').replace(/\s+/g, ' ').trim();
        if (excerpt.length < 160) {
          try {
            const page = await fetchFn(url);
            if (page?.excerpt && String(page.excerpt).trim().length > excerpt.length) {
              excerpt = String(page.excerpt).replace(/\s+/g, ' ').trim();
            }
          } catch {}
        }
        if (excerpt.length >= 20) {
          opened.set(url, {
            name: String(h?.name || h?.title || ''),
            url,
            excerpt: extractRelevantExcerpt(excerpt, queries, 2800),
            publishedAt: String(h?.publishedAt || h?.published_date || 'unknown')
          });
        }
      }
    }
    return opened;
  }

  async function emitCard(kind, card, evidenceLevel, startedAt, wakeGen) {
    const langCode = targetUiLang(session).code;
    const title = String(card.title || '').trim();
    const text = String(card.text || '').trim();
    if (!title && !text) return false;
    const urls = (Array.isArray(card.sources) ? card.sources : []).map(s => s?.url).filter(Boolean);
    const sourceIds = Array.isArray(card.sourceIds) ? card.sourceIds : [];
    if (isDuplicate(title, text, urls, sourceIds)) {
      recordDrop('duplicate', { kind, title });
      return false;
    }
    const payload = withBadge(kind, {
      title,
      text,
      ...(card.details ? { details: String(card.details).trim() } : {}),
      caveat: String(card.caveat || '').trim(),
      sources: Array.isArray(card.sources) ? card.sources : [],
      credibility: String(card.credibility || ''),
      evidenceLevel,
      sourceIds,
      sourceLayer: card.sourceLayer || (evidenceLevel === 'meeting' ? 'meeting' : evidenceLevel === 'memory' ? 'memory' : 'external'),
      latencyMs: Math.max(0, now() - startedAt),
      isCurrent: () => live() && (wakeGen === undefined || wakeGen === generation)
    }, langCode);
    const accepted = await onCard(payload);
    if (accepted !== false) {
      rememberShown(payload.cardKind, title, text, urls, sourceIds);
      stats.published++;
      stats.emittedByKind[payload.cardKind] = (stats.emittedByKind[payload.cardKind] || 0) + 1;
      stats.emittedByEvidence[evidenceLevel] = (stats.emittedByEvidence[evidenceLevel] || 0) + 1;
      // Opus P0: record impression denominator so sparse positive clicks never permanently suppress a cardKind
      try {
        if (dataDir) {
          require('./card-feedback').record(dataDir, {
            sessionId: session?.id || '',
            cardId: payload.id || '',
            cardKind: payload.cardKind,
            uiLang: targetUiLang(session).code,
            title,
            text: '',
            action: 'impression'
          });
        }
      } catch {}
      return true;
    }
    recordDrop('rejected_by_consumer', { kind, title });
    return false;
  }

  async function verifyAndEmit(candidate, rows, startedAt, wakeGen) {
    const langCode = targetUiLang(session).code;
    const uiStr = UI_STRINGS[langCode] || UI_STRINGS.zh;
    const fallbackKind = candidate.kind === 'external_case' ? 'external_case' : 'fact_check';
    const queries = Array.isArray(candidate.queries) ? candidate.queries.filter(q => typeof q === 'string' && q.trim()).slice(0, 2) : [];
    const claim = String(candidate.claim || candidate.text || candidate.title || '').trim();
    if (!queries.length || !claim) {
      recordDrop('missing_query_or_claim', { kind: fallbackKind, claim });
      return false;
    }
    const opened = await openPages(queries);
    if (!live() || wakeGen !== generation) return false;
    if (!opened.size) {
      recordDrop('no_page', { kind: fallbackKind, claim, queries });
      onPending({
        id: `${session?.id || 'sess'}:brain:${wakeSeq}:${fallbackKind}`,
        kind: 'insight',
        title: uiStr.needsVerify,
        body: claim,
        sourceIds: Array.isArray(candidate.sourceIds) ? candidate.sourceIds : [],
        sourceLayer: 'external',
        reason: 'no_page'
      });
      return false;
    }

    const today = new Date(now()).toISOString().slice(0, 10);
    const payload = {
      today,
      claim,
      transcriptTail: rows.slice(-4).map(r => `[${r.t || ''}] ${r.text || ''}`),
      opened: [...opened.values()]
    };
    stats.verifyCalls++;
    const verifyTrace = {
      sessionId: session?.id || '',
      purpose: 'live-expert-check',
      tier: 'verify',
      kind: 'verify',
      json: true,
      thinkGuide: false,
      maxTokens: 900,
      timeoutMs: 35000
    };
    const raw = await ask(buildVerifyWriteSystemPrompt(session), JSON.stringify(payload), verifyTrace);
    if (!live() || wakeGen !== generation) return false;
    const v = parseJsonObject(raw);
    const verdict = String(v?.verdict || '').trim();
    if (!v || !verdict) {
      recordDrop('verify_parse_failed', { kind: fallbackKind, claim, verdict: raw ? 'parse_failed' : (verifyTrace.errorCode || 'empty_response') });
      return false;
    }
    if (verdict === 'skip') {
      recordDrop('verdict_skip_clean', { kind: fallbackKind, claim, verdict: 'skip' });
      return false;
    }
    const validVerdict = verdict === 'correction' || verdict === 'external_contrast' || verdict === 'pass';
    if (!validVerdict || !String(v.text || '').trim()) {
      recordDrop('verdict_skip', { kind: fallbackKind, claim, verdict });
      return false;
    }
    const kind = verdict === 'external_contrast' ? 'external_case' : (verdict === 'correction' ? 'fact_check' : fallbackKind);
    if (kind === 'fact_check' && CONSISTENT_WASTE_RE.test(String(v.text || '').trim())) {
      recordDrop('consistent_waste_card', { kind, claim: claim.slice(0, 60) });
      return false;
    }

    const textHasNumbers = /\d/.test(String(v.text || ''));
    const quotedSources = [];
    const fallbackSources = [];
    for (const src of (Array.isArray(v.sources) ? v.sources : []).slice(0, 2)) {
      const url = String(src?.url || '').trim();
      if (!/^https:\/\//.test(url) || !opened.has(url)) {
        if (url) stats.fabricatedUrlBlocked++;
        continue;
      }
      const page = opened.get(url);
      const excerpt = page.excerpt;
      const quote = String(src?.quote || '').replace(/\s+/g, ' ').trim();
      const grounded = groundQuote(excerpt, quote);
      const numStrict = numNorm.numbersSupported(v.text, excerpt, claim);
      const numPartial = numStrict || numNorm.numbersConsistent(v.text, excerpt);

      if (grounded && numStrict) {
        quotedSources.push({
          name: String(src?.name || page.name || ''),
          url,
          quote: grounded,
          evidenceKind: 'public_page_excerpt',
          excerpt,
          fetchedAt: now()
        });
      } else if (grounded || numPartial || (kind === 'external_case' && !textHasNumbers && String(v.text || '').trim().length >= 16)) {
        // Opus P1 fix: external_case text containing numbers MUST pass numbersConsistent(v.text, excerpt)
        if (kind === 'external_case' && textHasNumbers && !numPartial) continue;
        fallbackSources.push({
          name: String(src?.name || page.name || ''),
          url,
          quote: grounded || '',
          evidenceKind: grounded ? 'public_page_excerpt' : 'public_page_unverified',
          excerpt,
          fetchedAt: now()
        });
      }
    }

    if (quotedSources.length) {
      return await emitCard(kind, {
        title: v.title || candidate.title,
        text: v.text,
        details: v.details,
        caveat: v.caveat,
        credibility: v.credibility || uiStr.verified,
        sources: quotedSources,
        sourceIds: candidate.sourceIds,
        sourceLayer: 'external'
      }, 'quoted', startedAt, wakeGen);
    }
    if (fallbackSources.length) {
      return await emitCard(kind, {
        title: v.title || candidate.title,
        text: v.text,
        details: v.details,
        caveat: v.caveat,
        credibility: uiStr.publicSource,
        sources: fallbackSources,
        sourceIds: candidate.sourceIds,
        sourceLayer: 'external'
      }, 'source', startedAt, wakeGen);
    }

    recordDrop('ungrounded', {
      kind,
      claim: claim.slice(0, 80),
      corrected: String(v.text || '').slice(0, 80),
      sourceCount: (v.sources || []).length
    });
    return false;
  }

  async function processWake(job) {
    const startedAt = now();
    const wakeGen = job.gen;
    const rows = job.rows || [];
    if (!rows.length || !live()) return;

    const langCode = targetUiLang(session).code;
    const uiStr = UI_STRINGS[langCode] || UI_STRINGS.zh;
    const scenario = scenarioMod.ensure(session || {}, { dataDir, now });
    let memoryHints = '';
    try {
      const liveExpert = require('./live-expert');
      if (typeof liveExpert.buildMemoryHints === 'function') {
        memoryHints = String(liveExpert.buildMemoryHints(session, dataDir) || '');
      }
    } catch {}
    if (!memoryHints && typeof session?.memoryHints === 'string') {
      memoryHints = session.memoryHints;
    }

    // Build recent transcript window with up to 6000 chars total (up to 1200 chars/row) + explicit isNew marker
    const windowRows = rows.slice(-10);
    const validRowIds = new Set(windowRows.map(r => String(r.id || '')).filter(Boolean));
    const sanitizeSourceIds = list => Array.isArray(list) ? list.map(x => String(x || '')).filter(id => validRowIds.has(id)) : [];
    let charBudget = 6000;
    const recentTranscript = new Array(windowRows.length);
    for (let i = windowRows.length - 1; i >= 0; i--) {
      const r = windowRows[i];
      const rKey = String(r.id || `${r.t || ''}:${String(r.text || '').slice(0, 32)}`);
      const isNew = !seenRowKeys.has(rKey);
      const rawText = String(r.text || '');
      const take = Math.min(1200, Math.max(120, charBudget));
      const text = rawText.length > take ? rawText.slice(0, take) : rawText;
      charBudget = Math.max(0, charBudget - text.length);
      recentTranscript[i] = { id: r.id || '', t: r.t || '', speaker: r.speaker || '', isNew, text };
    }

    const searchAvailable = searchCount < currentMaxSearches();
    let prefProfile = null;
    try {
      if (dataDir) prefProfile = require('./card-feedback').buildPreferenceProfile(dataDir, { uiLang: langCode });
    } catch {}
    const userPayload = {
      today: new Date(now()).toISOString().slice(0, 10),
      meetingModel: String(session?.expertModel || '').slice(0, MODEL_LIMIT),
      searchAvailable,
      shownCards: shownCardsList.slice(-10).map(c => ({ kind: c.kind, title: c.title, text: c.text })),
      recentTranscript,
      ...(memoryHints ? { memoryHints: memoryHints.slice(0, 2000) } : {}),
      ...(prefProfile && (prefProfile.liked.length || prefProfile.disliked.length)
        ? { userPreferences: { liked: prefProfile.liked, disliked: prefProfile.disliked } }
        : {})
    };

    stats.triageCalls++;
    const triageTrace = {
      sessionId: session?.id || '',
      purpose: 'live-expert-understand',
      tier: 'quick',
      json: true,
      thinkGuide: false,
      maxTokens: 1200,
      timeoutMs: 25000
    };
    const raw = await ask(buildTriageSystemPrompt(session, scenario), JSON.stringify(userPayload), triageTrace);
    if (!live() || wakeGen !== generation) return;
    const parsed = parseJsonObject(raw);
    if (!parsed) {
      recordDrop(raw ? 'triage_parse_failed' : (triageTrace.errorCode || 'triage_empty_response'), { wakeId: job.wakeId });
      return;
    }
    // Opus P1 fix: mark rows as seen ONLY after triage succeeded and parsed cleanly
    for (const r of windowRows) {
      const rKey = String(r.id || `${r.t || ''}:${String(r.text || '').slice(0, 32)}`);
      seenRowKeys.add(rKey);
    }
    if (typeof parsed.meetingModel === 'string' && parsed.meetingModel.trim() && session) {
      session.expertModel = parsed.meetingModel.trim().slice(0, MODEL_LIMIT);
    }

    const hardOnly = !!scenario?.hardEvidenceOnly;
    const baseMinGain = hardOnly ? 4 : 3;
    const minGainFor = kind => {
      // MiMo guardrail: avoid compounding few-shot disliked suppression with minGain bump on the same kind
      const nudged = prefProfile?.minGainByKind?.[kind];
      if (!hardOnly && nudged && !(prefProfile?.disliked || []).some(d => d.kind === kind)) {
        return Math.max(baseMinGain, nudged);
      }
      return baseMinGain;
    };

    // Normalize BOTH new decoupled schema { insight, probes } AND legacy { cards } for backwards compatibility
    let insightCandidate = (parsed.insight && typeof parsed.insight === 'object') ? parsed.insight : null;
    const probeQueue = [];
    if (Array.isArray(parsed.probes)) {
      for (const p of parsed.probes) {
        if (!p || typeof p !== 'object') continue;
        if (!searchAvailable) {
          recordDrop('search_unavailable', { kind: 'fact_check', claim: String(p.claim || '').slice(0, 60) });
          continue;
        }
        if (probeQueue.length < MAX_SEARCH_CANDIDATES_PER_WAKE) {
          probeQueue.push({ ...p, sourceIds: sanitizeSourceIds(p.sourceIds) });
        }
      }
    }
    // Legacy cards[] compatibility (e.g. unit tests or models returning cards[])
    const legacyCards = Array.isArray(parsed.cards) ? parsed.cards : [];
    const legacyMemory = [];
    const legacyBlinds = [];
    for (const c of legacyCards) {
      if (!c || typeof c !== 'object') continue;
      const k = String(c.kind || '').trim();
      if (k === 'memory_conflict') legacyMemory.push(c);
      else if (k === 'blind_spot') legacyBlinds.push(c);
      else if (k === 'fact_check' || k === 'external_case') {
        if (!searchAvailable) {
          recordDrop('search_unavailable', { kind: k, claim: String(c.claim || c.title || '').slice(0, 60) });
        } else if (probeQueue.length < MAX_SEARCH_CANDIDATES_PER_WAKE) {
          probeQueue.push({ ...c, sourceIds: sanitizeSourceIds(c.sourceIds) });
        }
      }
    }
    if (!insightCandidate) {
      if (legacyMemory.length) insightCandidate = legacyMemory[0];
      else if (legacyBlinds.length && (!legacyCards.length || !probeQueue.length)) insightCandidate = legacyBlinds[0];
    }

    // CHANNEL 1: Emit insight (memory_conflict or blind_spot) IMMEDIATELY (~2s, zero search wait!)
    let emittedInsight = false;
    if (insightCandidate) {
      const kind = String(insightCandidate.kind || 'blind_spot').trim();
      const rawGain = insightCandidate.gain;
      const parsedGain = (rawGain !== undefined && rawGain !== null && typeof rawGain !== 'boolean' && String(rawGain).trim() !== '') ? Number(rawGain) : NaN;
      const gain = Number.isFinite(parsedGain) ? parsedGain : 4;
      const safeSourceIds = sanitizeSourceIds(insightCandidate.sourceIds);
      if (kind === 'memory_conflict') {
        const basis = String(insightCandidate.basis || '').trim();
        if (basis.length < 10 || !normText(memoryHints).includes(normText(basis))) {
          recordDrop('memory_ungrounded', { kind, title: insightCandidate.title });
        } else if (gain < minGainFor('memory_conflict')) {
          recordDrop('low_gain', { kind, gain, title: insightCandidate.title });
        } else {
          emittedInsight = await emitCard('memory_conflict', {
            title: insightCandidate.title,
            text: insightCandidate.text,
            details: insightCandidate.details || basis,
            sources: [{ name: uiStr.pastMemory, url: '', quote: basis }],
            sourceIds: safeSourceIds,
            sourceLayer: 'memory'
          }, 'memory', startedAt, wakeGen);
        }
      } else if (kind === 'blind_spot') {
        if (hardOnly) {
          recordDrop('scenario_hard_evidence_only', { kind: 'blind_spot', title: insightCandidate.title });
        } else if (gain < minGainFor('blind_spot')) {
          recordDrop('low_gain', { kind: 'blind_spot', gain, title: insightCandidate.title });
        } else {
          emittedInsight = await emitCard('blind_spot', {
            title: insightCandidate.title,
            text: insightCandidate.text,
            details: insightCandidate.details,
            sourceIds: safeSourceIds,
            sourceLayer: 'meeting'
          }, 'meeting', startedAt, wakeGen);
        }
      }
    }

    // CHANNEL 2: Run silent verification probes independently in Stage 2 (NEVER blocks Channel 1!)
    let emittedProbe = false;
    if (probeQueue.length) {
      onStatus({ state: 'checking', kind: 'external', count: probeQueue.length });
      try {
        for (const p of probeQueue) {
          if (!live() || wakeGen !== generation) break;
          try {
            const ok = await verifyAndEmit(p, rows, startedAt, wakeGen);
            if (ok) {
              emittedProbe = true;
              break;
            }
          } catch (e) {
            log('proactive-brain verify error: ' + (e && e.message || e));
            recordDrop('verify_error', { kind: p.kind || 'fact_check', error: String(e && e.message || e) });
          }
        }
      } finally {
        onStatus({ state: 'idle', count: 0 });
      }
    }

    if (!emittedInsight && !emittedProbe && !insightCandidate && !probeQueue.length) {
      recordDrop('triage_no_card', { wakeId: job.wakeId });
    }
  }

  async function drain() {
    if (running) return;
    running = true;
    try {
      while (waiting && live()) {
        const job = waiting;
        waiting = null;
        try {
          await processWake(job);
        } catch (e) {
          log('proactive-brain drain error: ' + (e && e.message || e));
          recordDrop('drain_error', { error: String(e && e.message || e) });
        }
      }
    } finally {
      running = false;
      if (waiting && live()) drain();
    }
  }

  return {
    wake(rows, focus = '') {
      if (!live() || !Array.isArray(rows) || !rows.length) return;
      stats.wakes++;
      const wakeId = 'sb' + (++wakeSeq);
      waiting = { rows: rows.map(r => ({ ...r })), focus, gen: generation, wakeId, ctxVer: contextVersion() };
      drain();
    },
    invalidate() {
      generation++;
      waiting = null;
      onStatus({ state: 'idle', count: 0 });
    },
    close() {
      closed = true;
      waiting = null;
      onStatus({ state: 'idle', count: 0 });
    },
    pending() {
      return !!waiting || running;
    },
    funnel() {
      return { ...stats, emittedByKind: { ...stats.emittedByKind }, emittedByEvidence: { ...stats.emittedByEvidence }, dropsByReason: { ...stats.dropsByReason }, recentDrops: stats.recentDrops.slice() };
    }
  };
}

module.exports = { create, parseJsonObject, groundQuote, withBadge, BADGE_MAP };
