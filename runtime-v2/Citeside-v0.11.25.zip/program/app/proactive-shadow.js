'use strict';
// P1-CARD-003: Silent shadow mode runner & telemetry for proactive live card v2.
// Runs in parallel during real meetings without displaying anything to the user,
// recording per-hop P50/P90 latencies and drop-reason distributions as release-gate evidence.
const fs = require('fs');
const path = require('path');
const v2 = require('./live-card-v2');

function percentile(values, p) {
  const nums = (Array.isArray(values) ? values : []).filter(n => typeof n === 'number' && Number.isFinite(n) && n >= 0).sort((a, b) => a - b);
  if (!nums.length) return null;
  const idx = Math.min(nums.length - 1, Math.max(0, Math.ceil((p / 100) * nums.length) - 1));
  return Math.round(nums[idx]);
}

function hopStats(values) {
  const nums = (Array.isArray(values) ? values : []).filter(n => typeof n === 'number' && Number.isFinite(n) && n >= 0);
  return { count: nums.length, p50: percentile(nums, 50), p90: percentile(nums, 90) };
}

function summarize(events = []) {
  const list = Array.isArray(events) ? events.filter(Boolean) : [];
  const hops = { inputGate: [], mainGen: [], localGuard: [], pubGate: [], e2e: [] };
  const dropReasons = {};
  const byMode = {};
  let emittedTotal = 0;
  let droppedTotal = 0;
  let minTs = Infinity;
  let maxTs = -Infinity;

  for (const ev of list) {
    if (typeof ev.ts === 'number' && Number.isFinite(ev.ts)) {
      if (ev.ts < minTs) minTs = ev.ts;
      if (ev.ts > maxTs) maxTs = ev.ts;
    }
    const h = ev.hops || {};
    if (typeof h.inputGateMs === 'number') hops.inputGate.push(h.inputGateMs);
    if (typeof h.mainGenMs === 'number') hops.mainGen.push(h.mainGenMs);
    if (typeof h.localGuardMs === 'number') hops.localGuard.push(h.localGuardMs);
    if (typeof h.pubGateMs === 'number') hops.pubGate.push(h.pubGateMs);
    if (typeof h.e2eMs === 'number') hops.e2e.push(h.e2eMs);

    const emitted = Number(ev.emittedCount) || 0;
    emittedTotal += emitted;

    let roundDropped = 0;
    for (const [reason, count] of Object.entries(ev.dropReasons || {})) {
      const n = Number(count) || 0;
      if (n <= 0) continue;
      dropReasons[reason] = (dropReasons[reason] || 0) + n;
      droppedTotal += n;
      roundDropped += n;
    }

    const mode = String(ev.mode || 'conservative');
    if (!byMode[mode]) byMode[mode] = { rounds: 0, emitted: 0, dropped: 0, emittedTimestamps: [] };
    byMode[mode].rounds++;
    byMode[mode].emitted += emitted;
    byMode[mode].dropped += roundDropped;
    if (emitted > 0 && typeof ev.ts === 'number') {
      for (let i = 0; i < emitted; i++) byMode[mode].emittedTimestamps.push(ev.ts);
    }
  }

  // Check 1:1 quietness: <= 1 card in any 10-minute sliding window.
  const modeSummary = {};
  for (const [mode, st] of Object.entries(byMode)) {
    let maxIn10Min = 0;
    const ts = st.emittedTimestamps.sort((a, b) => a - b);
    for (let i = 0; i < ts.length; i++) {
      let j = i;
      while (j < ts.length && ts[j] - ts[i] < 10 * 60 * 1000) j++;
      if (j - i > maxIn10Min) maxIn10Min = j - i;
    }
    modeSummary[mode] = {
      rounds: st.rounds,
      emitted: st.emitted,
      dropped: st.dropped,
      ...(mode === '1on1' ? { maxIn10Min, quietnessPass: maxIn10Min <= 1 } : {}),
    };
  }

  const spanHours = Number.isFinite(minTs) && Number.isFinite(maxTs) && maxTs > minTs
    ? (maxTs - minTs) / 3600000
    : 0;

  return {
    rounds: list.length,
    emittedTotal,
    droppedTotal,
    cardsPerHour: spanHours > 0 ? Number((emittedTotal / spanHours).toFixed(2)) : null,
    latency: {
      inputGate: hopStats(hops.inputGate),
      mainGen: hopStats(hops.mainGen),
      localGuard: hopStats(hops.localGuard),
      pubGate: hopStats(hops.pubGate),
      e2e: hopStats(hops.e2e),
    },
    dropReasons,
    byMode: modeSummary,
  };
}

function readSummary(dataDir) {
  if (!dataDir) return summarize([]);
  try {
    const file = path.join(dataDir, 'state', 'proactive-shadow.jsonl');
    if (!fs.existsSync(file)) return summarize([]);
    const events = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map(line => {
      try { return JSON.parse(line); } catch { return null; }
    }).filter(Boolean);
    return summarize(events);
  } catch {
    return summarize([]);
  }
}

function isEnabled(env) {
  try {
    const e = typeof env === 'function' ? env() : (env || {});
    return /^(on|1|true)$/i.test(String(e?.PROACTIVE_SHADOW || ''));
  } catch { return false; }
}

function create({
  dataDir = '',
  session = null,
  ask,
  gates = null,
  env = () => ({}),
  now = Date.now,
  log = () => {},
  getScenario = () => session?.scenario || null,
  getRollingSummary = () => '',
  getRetrieved = () => [],
  getMemoryDocs = () => [],
  getWebExcerpts = () => [],
  enabled = null,
  maxLogBytes = 2 * 1024 * 1024,
} = {}) {
  const rateLimiter = v2.createRateLimiter();
  const events = [];
  const issued = [];
  const emittedClientCards = [];
  let busy = false;
  let closed = false;

  const active = () => !closed && (enabled === null ? isEnabled(env) : !!enabled);

  function persist(entry) {
    events.push(entry);
    if (events.length > 500) events.shift();
    if (!dataDir) return;
    try {
      const file = path.join(dataDir, 'state', 'proactive-shadow.jsonl');
      fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
      const cap = Number.isFinite(Number(maxLogBytes)) && Number(maxLogBytes) > 0 ? Number(maxLogBytes) : 2 * 1024 * 1024;
      try {
        if (fs.existsSync(file) && fs.statSync(file).size >= cap) {
          fs.renameSync(file, file + '.1');
        }
      } catch {}
      fs.appendFileSync(file, JSON.stringify(entry) + '\n', { mode: 0o600 });
    } catch (e) {
      log('shadow telemetry write skipped ' + String(e?.message || e).slice(0, 60));
    }
  }

  async function observe({ speechEndedAt = now(), rows = null } = {}) {
    if (!active() || busy || typeof ask !== 'function') return null;
    busy = true;
    const roundStart = now();
    const scenario = v2.normalizeScenario(getScenario());
    const dropReasons = {};
    const addDrop = (reason, n = 1) => { dropReasons[reason] = (dropReasons[reason] || 0) + n; };
    const hops = {};
    let emittedCount = 0;

    try {
      const transcript = Array.isArray(rows) ? rows : (Array.isArray(session?.transcript) ? session.transcript : []);
      const editEpoch = session?.editEpoch || 0;

      // Hop 1: Input gate (if provided)
      if (gates && typeof gates.input === 'function') {
        const t0 = now();
        let hit = false;
        try {
          const res = await gates.input(transcript.slice(-12), { scenario });
          hit = typeof res === 'boolean' ? res : (!!res?.hit && !res?.error);
        } catch {
          hit = false;
          addDrop('input_gate_error');
        }
        hops.inputGateMs = Math.max(0, now() - t0);
        if (!hit) {
          addDrop('input_gate_skip');
          const entry = { ts: roundStart, mode: scenario.mode, emittedCount: 0, dropReasons, hops };
          persist(entry);
          return entry;
        }
      }

      // Hop 2: Slimmed v2 main generation (non-reasoning fast model, stable Chinese prefix, 3-layer context)
      const { system, prefixHash } = v2.buildPrompt({ scenario, language: session?.uiLang || 'zh' });
      const layered = v2.buildLayeredContext({
        transcript,
        now: now(),
        rollingSummary: getRollingSummary(),
        retrieved: getRetrieved(),
        issued,
      });

      const genStart = now();
      let raw;
      try {
        raw = await ask(system, JSON.stringify(layered), {
          ...v2.MAIN_CALL_OPTIONS,
          sessionId: session?.id || '',
          purpose: 'native-live-v2-shadow',
        });
      } catch (e) {
        hops.mainGenMs = Math.max(0, now() - genStart);
        addDrop('model_error');
        const entry = { ts: roundStart, mode: scenario.mode, prefixHash, emittedCount: 0, dropReasons, hops };
        persist(entry);
        return entry;
      }
      hops.mainGenMs = Math.max(0, now() - genStart);

      if (closed || (session && (session.editEpoch || 0) !== editEpoch)) {
        addDrop('stale');
        const entry = { ts: roundStart, mode: scenario.mode, prefixHash, emittedCount: 0, dropReasons, hops };
        persist(entry);
        return entry;
      }

      // Hop 3: Local anti-waste-card guards (anchor, delta, display sanitizer, coaching, <=44 chars, cross-lingual dedupe, rate limit)
      const guardStart = now();
      let evaluated;
      try {
        evaluated = v2.evaluateCandidates(raw, {
          scenario,
          recentRows: layered.recent90s,
          memoryDocs: getMemoryDocs(),
          webExcerpts: getWebExcerpts(),
          issued,
          rateLimiter,
          now: now(),
        });
      } catch {
        hops.localGuardMs = Math.max(0, now() - guardStart);
        addDrop('parse_error');
        const entry = { ts: roundStart, mode: scenario.mode, prefixHash, emittedCount: 0, dropReasons, hops };
        persist(entry);
        return entry;
      }
      hops.localGuardMs = Math.max(0, now() - guardStart);

      for (const d of evaluated.dropped) addDrop(d.reason);

      let survivors = evaluated.passed;

      // Hop 4: Binary publication gate (with scenario + negative feedback examples)
      if (survivors.length && gates && typeof gates.publication === 'function') {
        const pubStart = now();
        try {
          const pubResult = await gates.publication(
            survivors.map(c => ({
              type: c.type,
              display: c.display,
              delta: c.delta,
              anchor: c.anchor,
              text: c.display.body,
            })),
            {
              title: session?.title || '',
              scenario,
              meetingFrame: session?.meetingFrame || null,
              transcript: layered.recent90s,
            }
          );
          hops.pubGateMs = Math.max(0, now() - pubStart);
          if (pubResult?.error || !Array.isArray(pubResult?.decisions)) {
            addDrop('publication_gate_error', survivors.length);
            survivors = [];
          } else {
            const kept = [];
            survivors.forEach((c, idx) => {
              if (pubResult.decisions[idx]?.pass === true) kept.push(c);
              else addDrop('publication_gate');
            });
            survivors = kept;
          }
        } catch {
          hops.pubGateMs = Math.max(0, now() - pubStart);
          addDrop('publication_gate_error', survivors.length);
          survivors = [];
        }
      }

      const readyAt = now();
      for (const card of survivors) {
        rateLimiter.record(card, scenario, readyAt);
        issued.push(card);
        if (issued.length > 80) issued.shift();
        emittedClientCards.push(v2.toClientCard(card));
        if (emittedClientCards.length > 80) emittedClientCards.shift();
        emittedCount++;
      }
      if (emittedCount > 0 && Number.isFinite(speechEndedAt)) {
        hops.e2eMs = Math.max(0, readyAt - speechEndedAt);
      }

      const entry = {
        ts: roundStart,
        mode: scenario.mode,
        prefixHash,
        emittedCount,
        emittedTypes: survivors.map(c => c.type),
        dropReasons,
        hops,
      };
      persist(entry);
      return entry;
    } catch (e) {
      log('proactive shadow error ' + String(e?.message || e).slice(0, 80));
      return null;
    } finally {
      busy = false;
    }
  }

  return {
    observe,
    summary: () => summarize(events),
    events: () => events.slice(),
    emittedCards: () => emittedClientCards.slice(),
    close: () => { closed = true; },
  };
}

module.exports = { create, summarize, readSummary, percentile, isEnabled };
