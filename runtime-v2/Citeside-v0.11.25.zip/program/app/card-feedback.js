'use strict';

// Layer 1 of the Self-Improving Card Quality Flywheel:
// Records lightweight user feedback (useful / dismiss / thumbs_down + reason) on proactive cards
// into <dataDir>/state/card-feedback.jsonl, computes per-kind dismiss rates for adaptive calibration,
// and exposes negative samples for automated offline quality evaluation.

const fs = require('fs');
const path = require('path');

const VALID_ACTIONS = new Set([
  'impression', 'useful', 'open_source', 'copy', 'copy_to_ai', 'bookmark', 'deep_research',
  'dismiss', 'thumbs_down', 'retract_thumbs_down'
]);
const POSITIVE_WEIGHTS = { deep_research: 3, bookmark: 2, copy_to_ai: 2, copy: 1, open_source: 1, useful: 1 };
const VALID_REASONS = new Set(['', 'consistent_waste', 'nitpick', 'inaccurate', 'too_slow', 'duplicate', 'other']);
const FEEDBACK_ROTATE_BYTES = 4 * 1024 * 1024;
const HALF_LIFE_MS = 14 * 86400 * 1000;

function feedbackPath(dataDir) {
  return path.join(dataDir, 'state', 'card-feedback.jsonl');
}

function record(dataDir, entry = {}) {
  if (!dataDir) throw new Error('dataDir required');
  const action = String(entry.action || '').trim();
  if (!VALID_ACTIONS.has(action)) throw new Error('invalid_action');
  const reason = String(entry.reason || '').trim();
  const safeReason = VALID_REASONS.has(reason) ? reason : 'other';
  const row = {
    at: new Date().toISOString(),
    sessionId: String(entry.sessionId || '').slice(0, 120),
    cardId: String(entry.cardId || '').slice(0, 120),
    cardKind: String(entry.cardKind || 'unknown').slice(0, 40),
    uiLang: String(entry.uiLang || '').toLowerCase().slice(0, 12),
    evidenceLevel: String(entry.evidenceLevel || '').slice(0, 24),
    title: String(entry.title || '').replace(/[\r\n]+/g, ' ').trim().slice(0, 120),
    text: String(entry.text || '').replace(/[\r\n]+/g, ' ').trim().slice(0, 320),
    action,
    reason: safeReason,
    transcriptTail: Array.isArray(entry.transcriptTail)
      ? entry.transcriptTail.slice(-4).map(t => String(t || '').slice(0, 200))
      : []
  };
  const file = feedbackPath(dataDir);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  try {
    if (fs.existsSync(file) && fs.statSync(file).size >= FEEDBACK_ROTATE_BYTES) {
      fs.renameSync(file, file + '.1');
    }
  } catch {}
  fs.appendFileSync(file, JSON.stringify(row) + '\n', 'utf8');
  return row;
}

function readAll(dataDir, limit = 500) {
  const file = feedbackPath(dataDir);
  if (!dataDir || !fs.existsSync(file)) return [];
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
  const out = [];
  for (const line of lines.slice(-limit)) {
    try { out.push(JSON.parse(line)); } catch {}
  }
  return out;
}

function summarize(dataDir, windowSize = 100, opts = {}) {
  const rows = readAll(dataDir, windowSize);
  const nowMs = Number.isFinite(opts.nowMs) ? opts.nowMs : Date.now();
  // Honor retract_thumbs_down so an accidental click + un-toggle never poisons stats or few-shot examples.
  const retractedIds = new Set();
  const effective = [];
  for (let i = rows.length - 1; i >= 0; i--) {
    const r = rows[i];
    if (r.action === 'retract_thumbs_down') {
      if (r.cardId) retractedIds.add(r.cardId);
      continue;
    }
    if (r.action === 'thumbs_down' && r.cardId && retractedIds.has(r.cardId)) {
      retractedIds.delete(r.cardId);
      continue;
    }
    effective.push(r);
  }
  effective.reverse();

  const byKind = {};
  let feedbackCount = 0;
  for (const r of effective) {
    const k = r.cardKind || 'unknown';
    if (!byKind[k]) {
      byKind[k] = {
        total: 0, impressions: 0, positive: 0, negative: 0,
        weightedImpressions: 0, weightedPos: 0, weightedNeg: 0,
        dismissRate: 0, posteriorNegRate: 0.5, reasons: {}
      };
    }
    const ts = Date.parse(r.at || '');
    const ageMs = Number.isFinite(ts) ? Math.max(0, nowMs - ts) : 0;
    const decay = Math.pow(0.5, ageMs / HALF_LIFE_MS);

    if (r.action === 'impression') {
      byKind[k].impressions++;
      byKind[k].weightedImpressions += decay;
      continue;
    }
    byKind[k].total++;
    feedbackCount++;
    // Opus P1: only explicit thumbs_down (or dismiss with explicit quality reason) counts as quality negative
    if (r.action === 'thumbs_down' || (r.action === 'dismiss' && r.reason)) {
      byKind[k].negative++;
      byKind[k].weightedNeg += decay;
      if (r.reason) byKind[k].reasons[r.reason] = (byKind[k].reasons[r.reason] || 0) + 1;
    } else if (POSITIVE_WEIGHTS[r.action]) {
      byKind[k].positive++;
      byKind[k].weightedPos += decay;
    }
  }
  for (const k of Object.keys(byKind)) {
    const st = byKind[k];
    const denom = Math.max(st.impressions, st.positive + st.negative);
    st.dismissRate = denom ? Number((st.negative / denom).toFixed(3)) : 0;
    // Opus P0/P2: Beta(2, 2) Bayesian prior over time-decayed impressions denominator
    const wDenom = Math.max(st.weightedImpressions, st.weightedPos + st.weightedNeg);
    st.posteriorNegRate = Number(((2 + st.weightedNeg) / (4 + wDenom)).toFixed(3));
  }
  return { total: feedbackCount, byKind, effective };
}

function buildPreferenceProfile(dataDir, opts = {}) {
  const windowSize = Number.isFinite(opts.windowSize) ? opts.windowSize : 120;
  const targetLang = String(opts.uiLang || '').toLowerCase().slice(0, 2);
  const { total, byKind, effective } = summarize(dataDir, windowSize, opts);
  if (total < 5) return null;

  const liked = [];
  const disliked = [];
  const seenLiked = new Set();
  const seenDisliked = new Set();
  for (let i = effective.length - 1; i >= 0; i--) {
    const r = effective[i];
    if (r.action === 'impression') continue;
    // Opus P1: strict uiLang isolation so Chinese examples never leak into Japanese/English meetings
    const rowLang = String(r.uiLang || '').toLowerCase().slice(0, 2);
    if (targetLang && rowLang && rowLang !== targetLang) continue;
    const key = r.cardId || r.title || r.text;
    if (!key) continue;
    if (r.action === 'thumbs_down') {
      if (disliked.length < 3 && !seenDisliked.has(key)) {
        seenDisliked.add(key);
        disliked.push({ kind: r.cardKind, title: r.title, snippet: String(r.text || '').slice(0, 90) });
      }
    } else if (POSITIVE_WEIGHTS[r.action]) {
      if (liked.length < 3 && !seenLiked.has(key)) {
        seenLiked.add(key);
        liked.push({ kind: r.cardKind, signal: r.action, title: r.title, snippet: String(r.text || '').slice(0, 90) });
      }
    }
    if (liked.length >= 3 && disliked.length >= 3) break;
  }

  // Opus P0/P2: Beta(2,2) posterior gate over impression denominator (prevents permanent kind suppression)
  const minGainByKind = {};
  for (const [k, st] of Object.entries(byKind)) {
    if (st.weightedNeg >= 3 && st.posteriorNegRate > 0.45) {
      minGainByKind[k] = 4;
    }
  }

  if (!liked.length && !disliked.length && !Object.keys(minGainByKind).length) return null;
  return { total, liked, disliked, minGainByKind };
}

module.exports = { feedbackPath, record, readAll, summarize, buildPreferenceProfile };
