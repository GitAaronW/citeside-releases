'use strict';
// 官方授权的四个入口（实现见 oauth-link.js）：
//   GET  /oauth/start/<feishu|lark|notion>[?want=docs]  本机才能发起，302 到官方授权页
//   GET  /oauth/callback/<provider>?code&state          官方授权页跳回来；浏览器带的是跨站导航，过不了 isLocalReq，
//                                                       所以这里只认「回环地址 + 没有转发头 + 一次性 state」
//   GET  /oauth/status                                  已认证可读：配了哪几家、绑了哪几个账号（不含令牌）
//   POST /oauth/disconnect {key}                        本人：撤销 + 删本机令牌
const link = require('./tools/oauth-link');

const { renderOAuthCallbackPage } = require('./oauth-callback-page');

const LOOPBACK = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);

module.exports = async function oauthRoutes(req, res, u, ctx) {
  const p = u.pathname.replace(/^\/asr-relay/, '');
  if (!p.startsWith('/oauth/')) return false;
  const json = (status, body) => { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(body)); return true; };
  const html = (status, ok, text, service = 'notion') => {
    res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
    res.end(renderOAuthCallbackPage({
      service,
      status: ok ? 'success' : 'error',
      lang: u.searchParams.get('lang') || '',
      acceptLanguage: req.headers['accept-language'] || '',
      detail: ok ? '' : text,
    }));
    return true;
  };
  const env = ctx.env(), base = { env, dataDir: ctx.dataDir, fetchImpl: ctx.fetchImpl };
  let m;

  if (req.method === 'GET' && (m = p.match(/^\/oauth\/start\/(feishu|lark|notion)$/))) {
    if (!ctx.isLocal) return json(403, { ok: false, error: '只能在这台 Mac 上发起授权' });
    const r = await link.start(m[1], { ...base, port: ctx.port, want: u.searchParams.get('want') === 'docs' ? 'docs' : 'base' });
    if (!r.ok) return html(400, false, r.error);
    ctx.log && ctx.log('oauth start ' + m[1]);
    res.writeHead(302, { Location: r.url, 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' }); res.end(); return true;
  }
  if (req.method === 'GET' && (m = p.match(/^\/oauth\/callback\/(feishu|lark|notion)$/))) {
    const forwarded = Object.keys(req.headers).some(h => h.startsWith('x-forwarded-') || h === 'forwarded' || h === 'tailscale-funnel-request');
    if (!LOOPBACK.has(req.socket.remoteAddress) || forwarded) return html(403, false, '授权回调只接受本机');
    const r = await link.callback(m[1], { code: u.searchParams.get('code'), state: u.searchParams.get('state'), error: u.searchParams.get('error') }, base);
    if (r.ok && m[1] === 'notion') {
      try {
        const settings = ctx.settings || require('./config');
        if (require('path').resolve(settings.dataDir) !== require('path').resolve(ctx.dataDir)) throw Error('settings-scope');
        const current = settings.load();
        if (current.NOTION_DISCONNECTED === '1') settings.save({ ...current, NOTION_DISCONNECTED: '' });
      } catch {
        return html(500, false, 'Notion 授权已保存，但本机连接状态恢复失败；请重试连接。');
      }
    }
    ctx.log && ctx.log('oauth callback ' + m[1] + ' ' + (r.ok ? 'ok ' + r.key : 'fail'));
    return r.ok ? html(200, true, r.label + (r.stored === 'keychain' ? '（令牌已存进钥匙串）' : '')) : html(400, false, r.error);
  }
  if (req.method === 'GET' && p === '/oauth/status') {
    if (!ctx.authed) return json(401, { ok: false, error: '请连接 Mac' });
    return json(200, { ok: true, ...(await link.status(base)) });
  }
  if (req.method === 'POST' && p === '/oauth/disconnect') {
    if (!ctx.owner) return json(403, { ok: false, error: '只有本人能断开' });
    let body = '';
    for await (const c of req) { body += c; if (body.length > 2048) return json(413, { ok: false, error: '请求太大' }); }
    let key = ''; try { key = String(JSON.parse(body || '{}').key || ''); } catch (e) {}
    if (!/^(lark|notion)-[a-f0-9]{16}$/.test(key)) return json(400, { ok: false, error: '缺少绑定' });
    const r = await link.disconnect(key, base);
    ctx.log && ctx.log('oauth disconnect ' + key + ' ' + (r.ok ? 'ok' : 'fail'));
    return json(r.ok ? 200 : 404, r);
  }
  return json(404, { ok: false, error: '没有这个授权接口' });
};
