'use strict';
// 首次引导的进度（onboarding-spec.md §2）：存 dataDir/onboarding.json。
// 权限状态不存，页面每次实时读 /native/permissions。
const fs=require('fs'),path=require('path');
const VERSION=5,STEPS=4;
const SYS=['idle','granted','skipped'];
const fresh=()=>({version:VERSION,step:0,sys:'idle',trialDone:false,finished:false,coachSeen:false});
const file=dataDir=>path.join(dataDir,'onboarding.json');
// 老用户（已经开过会）没有这个文件：当作已走完，不再弹引导，也不出首页气泡。
function hasMeetings(dataDir){
 try{return fs.readdirSync(path.join(dataDir,'sessions')).some(n=>!n.startsWith('.'));}catch(e){return false;}
}
function load(dataDir){
 if(!dataDir)return fresh();
 let raw=null;try{raw=JSON.parse(fs.readFileSync(file(dataDir),'utf8'));}catch(e){}
 if(!raw||typeof raw!=='object')return hasMeetings(dataDir)?{...fresh(),step:STEPS-1,finished:true,coachSeen:true}:fresh();
 // v1: welcome/mic/sys/trial/ai/done; v2 added calendar; v3 removes trial; v4 removes ai from startup;
 // v5 merges mic+sys into a single perms step: welcome(0) / cal(1) / perms(2) / done(3).
 if(raw.finished===true)raw={...raw,version:VERSION,step:STEPS-1};
 else if(!raw.version||raw.version===1){
  const old=Number.isInteger(raw.step)?Math.max(0,Math.min(5,raw.step)):0;
  raw={...raw,version:VERSION,step:[0,2,2,2,2,3][old]};
 }else if(raw.version===2){
  const old=Number.isInteger(raw.step)?Math.max(0,Math.min(6,raw.step)):0;
  raw={...raw,version:VERSION,step:[0,1,2,2,2,2,3][old]};
 }else if(raw.version===3){
  const old=Number.isInteger(raw.step)?Math.max(0,Math.min(5,raw.step)):0;
  raw={...raw,version:VERSION,step:[0,1,2,2,2,3][old]};
 }else if(raw.version===4){
  const old=Number.isInteger(raw.step)?Math.max(0,Math.min(4,raw.step)):0;
  raw={...raw,version:VERSION,step:[0,1,2,2,3][old]};
 }
 return clean({...fresh(),...raw});
}
function clean(s){
 const step=Number.isInteger(s.step)?Math.max(0,Math.min(STEPS-1,s.step)):0;
 return {version:VERSION,step,sys:SYS.includes(s.sys)?s.sys:'idle',trialDone:s.trialDone===true,finished:s.finished===true,coachSeen:s.coachSeen===true};
}
// 只收白名单字段；类型不对整单拒绝。finished 只能从 false 变 true。
function patch(dataDir,body){
 if(!body||typeof body!=='object'||Array.isArray(body))throw Error('invalid onboarding');
 const keys=['step','sys','trialDone','finished','coachSeen'];
 if(!Object.keys(body).length||Object.keys(body).some(k=>!keys.includes(k)))throw Error('invalid onboarding');
 if('step' in body&&!(Number.isInteger(body.step)&&body.step>=0&&body.step<STEPS))throw Error('invalid onboarding');
 if('sys' in body&&!SYS.includes(body.sys))throw Error('invalid onboarding');
 for(const k of ['trialDone','finished','coachSeen'])if(k in body&&typeof body[k]!=='boolean')throw Error('invalid onboarding');
 const cur=load(dataDir),next=clean({...cur,...body});
 if(cur.finished)next.finished=true;
 fs.mkdirSync(dataDir,{recursive:true});
 require('./durable-json').write(file(dataDir),next,{space:1});
 return next;
}
module.exports={load,patch,fresh,STEPS,VERSION};
