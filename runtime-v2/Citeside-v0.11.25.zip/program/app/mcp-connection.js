"use strict";
// Grants authorize only this API, never the generic tool registry or relay owner token.
const fs = require("fs"),
  path = require("path"),
  crypto = require("crypto");
const { tools } = require("./citeside-mcp-tools.cjs");
const hash = (s) => crypto.createHash("sha256").update(s).digest("hex");
const validId = (s) =>
  typeof s === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(s);
const error = (status, code, message) =>
  Object.assign(Error(message), { status, code });
function atomic(file, value) {
  atomicRaw(file, JSON.stringify(value));
}
function atomicRaw(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  require('./durable-json').writeText(file, text);
}
function create({
  dataDir,
  settings,
  isLocalReq,
  port,
  runtimePath = process.execPath,
  bridgePath = path.join(__dirname, "citeside-mcp.cjs"),
  researchEngine,
  now = () => new Date().toISOString(),
  homeDir = process.env.CITESIDE_MCP_HOME || require("os").homedir(),
  platform = process.platform,
}) {
  const file = path.join(dataDir, "mcp-connections.json"),
    replays = new Map();
  const load = () => {
    try {
      const v = JSON.parse(fs.readFileSync(file, "utf8"));
      return {
        grants: Array.isArray(v.grants) ? v.grants : [],
        latest: v.latest || null,
      };
    } catch (e) {
      if (e.code === "ENOENT") return { grants: [], latest: null };
      throw e;
    }
  };
  const save = atomic.bind(null, file);
  const latest = () => {
    const db = load();
    return db.grants.find((g) => g.id === db.latest) || null;
  };
  function profileItems(g) {
    if (!g) return [];
    try {
      const snap = JSON.parse(
        fs.readFileSync(
          path.join(dataDir, "mcp-profile-snapshots", g.id + ".json"),
          "utf8",
        ),
      );
      return require("./my-ai-brief").filterImportedItems(snap.items)
        .slice(0, 20)
        .map((i) => ({
          kind: String(i.kind).slice(0, 20),
          text: String(i.text).slice(0, 300),
        }));
    } catch {
      return [];
    }
  }
  const CLIENTS = [
    { id: "claude_desktop", label: "Claude Desktop" },
    { id: "cursor", label: "Cursor" },
    { id: "codex", label: "Codex CLI" },
    { id: "antigravity", label: "Antigravity" },
  ];
  function clientPaths(id) {
    if (id === "antigravity") {
      return [
        path.join(homeDir, ".gemini", "config", "mcp_config.json"),
        path.join(homeDir, ".gemini", "antigravity", "mcp_config.json"),
      ];
    }
    const p = clientPath(id);
    return p ? [p] : [];
  }
  function clientPath(id) {
    if (id === "claude_desktop") {
      if (platform === "darwin")
        return path.join(homeDir, "Library", "Application Support", "Claude", "claude_desktop_config.json");
      if (platform === "win32")
        return path.join(homeDir, "AppData", "Roaming", "Claude", "claude_desktop_config.json");
      return path.join(homeDir, ".config", "Claude", "claude_desktop_config.json");
    }
    if (id === "cursor") return path.join(homeDir, ".cursor", "mcp.json");
    if (id === "codex") return path.join(homeDir, ".codex", "config.toml");
    if (id === "antigravity") return path.join(homeDir, ".gemini", "config", "mcp_config.json");
    return null;
  }
  function citesideConfigured(id, configPath) {
    try {
      const text = fs.readFileSync(configPath, "utf8");
      if (id === "codex") return /^\s*\[mcp_servers\.citeside\]\s*$/m.test(text);
      const doc = JSON.parse(text);
      return !!(
        doc &&
        typeof doc === "object" &&
        !Array.isArray(doc) &&
        doc.mcpServers &&
        typeof doc.mcpServers === "object" &&
        !Array.isArray(doc.mcpServers) &&
        doc.mcpServers.citeside
      );
    } catch {
      return false;
    }
  }
  function detectClients() {
    return CLIENTS.map(({ id, label }) => {
      const paths = clientPaths(id);
      const configPath = paths[0] || null;
      let detected = false, configured = false;
      for (const p of paths) {
        try {
          if (fs.existsSync(path.dirname(p)) || fs.existsSync(p)) detected = true;
          if (fs.existsSync(p) && citesideConfigured(id, p)) configured = true;
        } catch {}
      }
      return { id, label, detected, configured, configPath, ...(paths.length > 1 ? { configPaths: paths } : {}) };
    });
  }
  function identityStatus() {
    const found = require("./my-ai-brief").extractIdentity(dataDir) || {};
    const names = Array.isArray(found.names) ? found.names : [];
    const roleKeywords = Array.isArray(found.roleKeywords) ? found.roleKeywords : [];
    const missingIdentity = [];
    if (!names.length) missingIdentity.push("names");
    if (!roleKeywords.length) missingIdentity.push("roleKeywords");
    const followUpQuestion =
      missingIdentity.length === 2
        ? "顺便确认两件事，方便我开会时识别你：大家工作/开会时通常怎么称呼你（全名、常用名、英文名）？你的岗位或职能关键词是什么（如产品经理/PM）？"
        : missingIdentity[0] === "names"
          ? "我已记下你的岗位。方便补充一下大家工作/开会时通常怎么称呼你吗（中文全名、常用名、英文名）？"
          : missingIdentity[0] === "roleKeywords"
            ? "我已记下你的称呼。方便补充一下你的岗位或职能关键词吗（如 产品经理 / Product Manager / PM）？"
            : "";
    return { identity: { names, roleKeywords }, missingIdentity, followUpQuestion };
  }
  function state(g = latest()) {
    const items = profileItems(g);
    return {
      profileItems: items,
      ok: true,
      status: !g
        ? "not_connected"
        : g.revokedAt
          ? "disconnected"
          : g.profileReceivedAt
            ? "profile_received"
            : g.lastConnectedAt
              ? "connected"
              : "not_connected",
      connectionId: g?.id || null,
      awaitingClient: !!g && !g.revokedAt && !g.lastConnectedAt,
      client: g?.client || null,
      lastConnectedAt: g?.lastConnectedAt || null,
      lastReadAt: g?.lastReadAt || null,
      profileReceivedAt: g?.profileReceivedAt || null,
      profileItemCount: items.length,
      profileCoverage: require("./my-ai-brief").coverage(items),
      scope: g?.scope || { meetings: "all" },
      ...identityStatus(),
      clients: detectClients(),
    };
  }
  function active(id) {
    const g = load().grants.find((g) => g.id === id);
    if (!g || g.revokedAt)
      throw error(403, "REVOKED", "此连接已撤销，请重新连接");
    return g;
  }
  function update(id, patch) {
    const db = load(),
      g = db.grants.find((g) => g.id === id);
    if (!g || g.revokedAt) throw error(403, "REVOKED", "此连接已撤销");
    Object.assign(g, patch);
    save(db);
    return g;
  }
  function authenticate(secret) {
    if (typeof secret !== "string" || !secret)
      throw error(401, "UNAUTHORIZED", "需要此连接的授权");
    const h = hash(secret),
      g = load().grants.find((g) =>
        crypto.timingSafeEqual(
          Buffer.from(g.secretHash, "hex"),
          Buffer.from(h, "hex"),
        ),
      );
    if (!g) throw error(401, "UNAUTHORIZED", "连接无效");
    if (g.revokedAt) throw error(403, "REVOKED", "此连接已撤销");
    return g;
  }
  function connect(j) {
    if (
      (typeof j.client !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._ -]{0,79}$/.test(j.client)) ||
      typeof j.requestId !== "string" ||
      !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
        j.requestId,
      )
    )
      throw error(400, "INVALID_PARAMS", "连接参数无效");
    if (!j.scope || !["all", "selected"].includes(j.scope.meetings))
      throw error(400, "INVALID_SCOPE", "请选择授权范围");
    if (j.scope.meetings === "selected" && !Array.isArray(j.scope.meetingIds))
      throw error(400, "INVALID_SCOPE", "授权会议编号无效");
    const scope =
      j.scope.meetings === "all"
        ? { meetings: "all" }
        : {
            meetings: "selected",
            meetingIds: [...new Set(j.scope.meetingIds || [])],
          };
    if (
      scope.meetings === "selected" &&
      (!Array.isArray(j.scope.meetingIds) ||
        scope.meetingIds.length > 1000 ||
        !scope.meetingIds.every(validId))
    )
      throw error(400, "INVALID_SCOPE", "授权会议编号无效");
    const signature = hash(JSON.stringify({ client: j.client, scope })),
      cached = replays.get(j.requestId);
    if (cached && Date.now() < cached.until) {
      if (cached.signature !== signature)
        throw error(409, "REQUEST_CONFLICT", "请使用新的请求编号");
      active(cached.response.connectionId);
      return cached.response;
    }
    const db = load();
    if (db.grants.some((g) => g.requestId === j.requestId))
      throw error(409, "REQUEST_EXPIRED", "请使用新的请求编号重试连接");
    const secret = crypto.randomBytes(32).toString("base64url"),
      g = {
        id: crypto.randomUUID(),
        requestId: j.requestId,
        secretHash: hash(secret),
        client: j.client,
        scope,
        createdAt: now(),
        revokedAt: null,
        lastConnectedAt: null,
        lastReadAt: null,
        profileReceivedAt: null,
        profileItemCount: 0,
      };
    // This UI manages one connection: replacement revokes every prior pending/active grant atomically.
    for (const previous of db.grants)
      if (!previous.revokedAt) previous.revokedAt = g.createdAt;
    db.grants.push(g);
    db.latest = g.id;
    save(db);
    const config = {
      mcpServers: {
        citeside: {
          command: runtimePath,
          args: [bridgePath],
          env: {
            CITESIDE_MCP_ORIGIN: "http://127.0.0.1:" + port,
            CITESIDE_MCP_GRANT: secret,
          },
        },
      },
    };
    const response = {
      ...state(g),
      config,
      install: {
        config,
        instructions:
          "请使用你已知且可靠的长期记忆，以及我已授权的资料，整理我的身份与职责、项目目标与阶段、伙伴与术语、决策约束、会议偏好；每组注明来源与最近确认时间，未知就写未知。不要从当前目录、仓库、AGENTS 或通用 AI 规则推断我的职业或项目事实，不编造，不自行翻邮箱补资料。资料不足时先同步明确已知，只问一个最关键的问题。建议交给熟悉我工作的 AI；新的聊天未必拥有长期记忆。通过已有的 Citeside MCP 连接调用 profile_sync，不重建或撤销当前授权。此连接仅支持可访问这台 Mac 的本机 MCP 客户端。",
        oneShotPrompt: [
          "请使用你已有且可靠的长期记忆，调用 Citeside 的 profile_sync，传入 names（全名、常用名、英文名）和 roleKeywords（岗位或职能关键词）。",
          "不要从当前目录、仓库、AGENTS 或通用 AI 规则推断我的身份，不编造，不自行翻邮箱。",
          "如果返回的 followUpQuestion 非空，只问我这一个问题，得到回答后再调用一次 profile_sync。",
        ].join("\n"),
      },
    };
    replays.set(j.requestId, {
      signature,
      response,
      until: Date.now() + 5 * 60 * 1000,
    });
    for (const [key, value] of replays)
      if (value.until < Date.now()) replays.delete(key);
    return response;
  }
  function readJsonClient(configPath) {
    if (!fs.existsSync(configPath)) return {};
    let text = "";
    try {
      text = fs.readFileSync(configPath, "utf8");
    } catch (e) {
      if (e.code === "ENOENT") return {};
      throw e;
    }
    if (!String(text).trim()) return {};
    let doc;
    try {
      doc = JSON.parse(text);
    } catch {
      throw error(400, "INVALID_CLIENT_CONFIG", "现有客户端配置格式无效，请先检查原配置文件");
    }
    if (!doc || typeof doc !== "object" || Array.isArray(doc))
      throw error(400, "INVALID_CLIENT_CONFIG", "现有客户端配置格式无效，请先检查原配置文件");
    return doc;
  }
  function stripCodexSections(text) {
    const lines = String(text || "").replace(/\r\n/g, "\n").split("\n");
    const out = [];
    let skip = false;
    for (const line of lines) {
      const header = /^\s*\[([^\]]+)\]\s*$/.exec(line);
      if (header) {
        const name = header[1].trim();
        skip = name === "mcp_servers.citeside" || name === "mcp_servers.citeside.env";
      }
      if (!skip) out.push(line);
    }
    return out.join("\n");
  }
  function autoconnect(clientId) {
    if (clientId === "auto") {
      const detected = detectClients().filter((c) => c.detected);
      const connectedClients = [];
      for (const c of detected) {
        try {
          autoconnect(c.id);
          connectedClients.push({ id: c.id, label: c.label });
        } catch {}
      }
      return { ok: true, connectedClients, ...state() };
    }
    const paths = clientPaths(clientId);
    const configPath = paths[0] || null;
    if (!configPath) throw error(400, "INVALID_CLIENT", "不支持此客户端");
    const jsonClient =
      clientId === "claude_desktop" ||
      clientId === "cursor" ||
      clientId === "antigravity";
    const primaryDoc = jsonClient ? readJsonClient(configPath) : null;
    const conn = connect({
      client: clientId,
      requestId: crypto.randomUUID(),
      scope: { meetings: "all" },
    });
    const server = conn.config.mcpServers.citeside;
    if (jsonClient) {
      const mcpServers =
        primaryDoc.mcpServers && typeof primaryDoc.mcpServers === "object" && !Array.isArray(primaryDoc.mcpServers)
          ? primaryDoc.mcpServers
          : {};
      atomic(configPath, {
        ...primaryDoc,
        mcpServers: { ...mcpServers, citeside: server },
      });
      // Best-effort sync to legacy compat paths (e.g. ~/.gemini/antigravity/mcp_config.json)
      // so corrupt JSON in a legacy file never aborts writing the primary config.
      for (const compatPath of paths.slice(1)) {
        try {
          const compatDoc = readJsonClient(compatPath);
          const compatServers =
            compatDoc.mcpServers && typeof compatDoc.mcpServers === "object" && !Array.isArray(compatDoc.mcpServers)
              ? compatDoc.mcpServers
              : {};
          atomic(compatPath, {
            ...compatDoc,
            mcpServers: { ...compatServers, citeside: server },
          });
        } catch {}
      }
    } else {
      let existing = "";
      if (fs.existsSync(configPath)) {
        try {
          existing = fs.readFileSync(configPath, "utf8");
        } catch (e) {
          if (e.code !== "ENOENT") throw e;
        }
      }
      let body = stripCodexSections(existing);
      if (body && !body.endsWith("\n")) body += "\n";
      const block = [
        "[mcp_servers.citeside]",
        "command = " + JSON.stringify(server.command),
        "args = " + JSON.stringify(server.args),
        "",
        "[mcp_servers.citeside.env]",
        "CITESIDE_MCP_ORIGIN = " + JSON.stringify(server.env.CITESIDE_MCP_ORIGIN),
        "CITESIDE_MCP_GRANT = " + JSON.stringify(server.env.CITESIDE_MCP_GRANT),
        "",
      ].join("\n");
      atomicRaw(configPath, body + block);
    }
    return {
      ...conn,
      ...state(),
      config: conn.config,
      install: conn.install,
      clientId,
      configPath,
      ...(paths.length > 1 ? { configPaths: paths } : {}),
      oneShotPrompt: conn.install.oneShotPrompt,
    };
  }
  function disconnect(id) {
    const db = load(),
      g = db.grants.find((g) => g.id === id);
    if (!g) throw error(404, "NOT_FOUND", "连接不存在");
    if (!g.revokedAt) {
      g.revokedAt = now();
      save(db);
    }
    for (const [key, value] of replays)
      if (value.response.connectionId === id) replays.delete(key);
    return state(g);
  }
  const allowed = (g, id) =>
    validId(id) &&
    (g.scope.meetings === "all" || g.scope.meetingIds.includes(id));
  function meetings(g) {
    return require("./tools/local")
      .loadMeetings(dataDir, { max: 1000 })
      .meetings.filter(
        (m) => allowed(g, m.id) && !require("./native-trial").isTrialId(m.id),
      );
  }
  const project = (m) => ({
    meetingId: m.id,
    title: m.title,
    date: m.date,
    summary: m.summary,
    conclusions: m.conclusions,
    topics: m.topics,
    todos: m.briefTodos.length ? m.briefTodos : m.todos,
    version: hash(
      JSON.stringify([
        m.summary,
        m.conclusions,
        m.topics,
        m.briefTodos,
        m.todos,
      ]),
    ),
    updatedAt: new Date(m.mtime).toISOString(),
  });
  function reports(g) {
    if (settings.load().LIVE_RESEARCH_TIER === "free") return [];
    const out = [];
    for (const m of meetings(g)) {
      // Existing engine enforces the product tier and report projection; do not start generators.
      if (researchEngine?.has(m.id)) {
        const view = researchEngine.readSnapshot(m.id);
        if (view.tier !== "free")
          for (const item of view.items || [])
            if (item.state === "done")
              out.push({
                meetingId: m.id,
                reportId: item.id,
                report: require("./live-research").reportView(item, {
                  full: true,
                }),
                truncated: false,
                version: String(view.version),
                updatedAt: item.completedAt || null,
              });
      }
      const snap = require("./research-report").loadFinal(dataDir, m.id);
      if (
        snap?.final === true &&
        !snap.incomplete &&
        !snap.pending &&
        !snap.fallback &&
        typeof snap.markdown === "string" &&
        snap.markdown.trim()
      )
        out.push({
          meetingId: m.id,
          reportId: m.id,
          markdown: snap.markdown,
          version: String(snap.version || hash(snap.markdown)),
          updatedAt: snap.updatedAt || new Date(m.mtime).toISOString(),
        });
    }
    return out;
  }
  function sync(g, input) {
    const brief = require("./my-ai-brief");
    const markdown = typeof input === "string" ? input : input?.markdown;
    const items = brief.parseImported(markdown);
    if (!items.length)
      throw error(
        400,
        "EMPTY_PROFILE",
        "没有可接收的明确背景；目录、仓库和 AI 规则不能作为身份或项目事实来源，请同步已知背景并注明来源与确认时间",
      );
    const cleaned = brief.cleanStructuredIdentity(
      typeof input === "object" && input ? input : {},
    );
    const names = cleaned.names, roleKeywords = cleaned.roleKeywords;
    const contentHash =
        !names.length && !roleKeywords.length
          ? hash(markdown)
          : hash(JSON.stringify({ markdown, names, roleKeywords })),
      target = path.join(dataDir, "mcp-profile-snapshots", g.id + ".json");
    let previous;
    try {
      previous = JSON.parse(fs.readFileSync(target, "utf8"));
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
    }
    if (previous?.contentHash === contentHash)
      return {
        ok: true,
        changed: false,
        itemCount: previous.items.length,
        receivedAt: previous.receivedAt,
        ...identityStatus(),
      };
    // No await between the revocation recheck, atomic snapshot commit and receipt commit.
    active(g.id);
    const receivedAt = now();
    const snap = {
      sourceId: g.id,
      source: "mcp",
      contentHash,
      receivedAt,
      items,
    };
    if (names.length) snap.names = names;
    if (roleKeywords.length) snap.roleKeywords = roleKeywords;
    atomic(target, snap);
    update(g.id, {
      profileReceivedAt: receivedAt,
      profileItemCount: items.length,
    });
    if (names.length || roleKeywords.length) {
      fs.mkdirSync(dataDir, { recursive: true });
      const ownerTracking = require("./owner-tracking");
      const cur = ownerTracking.loadOwnerProfile(dataDir);
      const merged = brief.cleanStructuredIdentity({
        names: [...(Array.isArray(cur.names) ? cur.names : []), ...names],
        roleKeywords: [
          ...(Array.isArray(cur.roleKeywords) ? cur.roleKeywords : []),
          ...roleKeywords,
        ],
      });
      ownerTracking.saveOwnerName(
        dataDir,
        names[0] || cur.displayName || "我",
        merged.names,
        merged.roleKeywords,
      );
    }
    return {
      ok: true,
      changed: true,
      itemCount: items.length,
      receivedAt,
      ...identityStatus(),
    };
  }
  async function call(g, name, args) {
    const def = tools.find((t) => t.name === name);
    if (!def) throw error(403, "TOOL_NOT_ALLOWED", "此连接不允许调用该工具");
    const parsed = def.inputSchema.safeParse(args);
    if (!parsed.success) throw error(400, "INVALID_PARAMS", "工具参数无效");
    g = active(g.id);
    const a = parsed.data;
    let result;
    if (name === "profile_sync") return sync(g, a);
    if (name === "meetings_search") {
      let rows = meetings(g);
      if (a.query) {
        const q = a.query.toLowerCase();
        rows = rows.filter((m) =>
          JSON.stringify(project(m)).toLowerCase().includes(q),
        );
      }
      result = {
        ok: true,
        items: rows.slice(a.offset, a.offset + a.limit).map(project),
        total: rows.length,
      };
    } else if (name === "meetings_get") {
      if (!allowed(g, a.meetingId))
        throw error(403, "OUT_OF_SCOPE", "会议不在授权范围");
      const m = meetings(g).find((m) => m.id === a.meetingId);
      if (!m) throw error(404, "NOT_FOUND", "会议不存在");
      result = { ok: true, data: project(m) };
    } else if (name === "research_list") {
      if (a.meetingId && !allowed(g, a.meetingId))
        throw error(403, "OUT_OF_SCOPE", "会议不在授权范围");
      const rows = reports(g).filter(
        (r) => !a.meetingId || r.meetingId === a.meetingId,
      );
      result = {
        ok: true,
        items: rows
          .slice(a.offset, a.offset + a.limit)
          .map(({ markdown, report, ...meta }) => ({
            ...meta,
            title:
              report?.title ||
              meetings(g).find((m) => m.id === meta.meetingId)?.title ||
              "",
          })),
        total: rows.length,
      };
    } else if (name === "research_get") {
      if (!allowed(g, a.meetingId))
        throw error(403, "OUT_OF_SCOPE", "会议不在授权范围");
      if (settings.load().LIVE_RESEARCH_TIER === "free")
        throw error(403, "PLAN_REQUIRED", "当前方案不提供完整研究报告");
      const row = reports(g).find(
        (r) =>
          r.meetingId === a.meetingId &&
          r.reportId === (a.reportId || a.meetingId),
      );
      if (!row) throw error(404, "NOT_READY", "研究报告未完成或不存在");
      result = { ok: true, data: row };
    } else if (name === "search_meetings") {
      let rows = meetings(g);
      const q = String(a.query || "").trim().toLowerCase();
      if (q) {
        rows = rows.filter((m) => {
          const p = project(m);
          const hay = [
            p.title,
            p.summary,
            ...(Array.isArray(p.conclusions) ? p.conclusions : []),
            ...(Array.isArray(p.topics) ? p.topics : []),
          ]
            .join(" ")
            .toLowerCase();
          return hay.includes(q);
        });
      }
      result = {
        ok: true,
        items: rows.slice(a.offset, a.offset + a.limit).map((m) => {
          const p = project(m);
          const rawSnippet =
            String(p.summary || "").trim() ||
            (Array.isArray(p.conclusions) && p.conclusions.length
              ? p.conclusions.join("；")
              : "");
          return {
            id: p.meetingId,
            title: p.title || "",
            date: p.date || "",
            snippet:
              rawSnippet.length > 240
                ? rawSnippet.slice(0, 240) + "…"
                : rawSnippet,
          };
        }),
        total: rows.length,
      };
    } else if (name === "get_meeting_minutes") {
      if (!allowed(g, a.meetingId))
        throw error(403, "OUT_OF_SCOPE", "会议不在授权范围");
      const m = meetings(g).find((row) => row.id === a.meetingId);
      if (!m) throw error(404, "NOT_FOUND", "会议不存在");
      const p = project(m);
      let markdown = "";
      try {
        const pmFile = path.join(dataDir, "post-meeting", m.id + ".json");
        if (fs.existsSync(pmFile)) {
          const pm = JSON.parse(fs.readFileSync(pmFile, "utf8"));
          markdown = String(
            pm?.summary?.markdown || pm?.state?.summary?.markdown || "",
          ).trim();
        }
      } catch {}
      if (!markdown) {
        const parts = [];
        if (p.title) parts.push("# " + p.title);
        if (p.summary) parts.push("## 摘要\n" + p.summary);
        if (Array.isArray(p.conclusions) && p.conclusions.length)
          parts.push(
            "## 关键结论\n" + p.conclusions.map((c) => "- " + c).join("\n"),
          );
        markdown = parts.join("\n\n");
      }
      const MAX_MD = 12000;
      const truncated = markdown.length > MAX_MD;
      result = {
        ok: true,
        data: {
          meetingId: p.meetingId,
          title: p.title || "",
          date: p.date || "",
          markdown: truncated ? markdown.slice(0, MAX_MD) + "\n…" : markdown,
          truncated,
          summary: String(p.summary || "").slice(0, 1200),
          conclusions: (Array.isArray(p.conclusions) ? p.conclusions : []).slice(
            0,
            20,
          ),
          topics: (Array.isArray(p.topics) ? p.topics : []).slice(0, 20),
          todos: (Array.isArray(p.todos) ? p.todos : []).slice(0, 30),
        },
      };
    } else if (name === "list_todos") {
      if (a.meetingId && !allowed(g, a.meetingId))
        throw error(403, "OUT_OF_SCOPE", "会议不在授权范围");
      const targetMeetings = meetings(g).filter(
        (m) => !a.meetingId || m.id === a.meetingId,
      );
      const collected = [];
      for (const m of targetMeetings) {
        const p = project(m);
        const liveTodos =
          researchEngine?.has(m.id) &&
          Array.isArray(researchEngine.readSnapshot(m.id)?.minutes?.todos)
            ? researchEngine.readSnapshot(m.id).minutes.todos
            : [];
        const rawTodos = liveTodos.length
          ? liveTodos
          : Array.isArray(p.todos)
            ? p.todos
            : [];
        rawTodos.forEach((t, idx) => {
          const isObj = t && typeof t === "object";
          const text = String(
            isObj ? t.text || t.what || t.title || "" : t || "",
          ).trim();
          if (!text) return;
          const done = Boolean(isObj ? t.done || t.completed : false);
          if (a.status === "open" && done) return;
          if (a.status === "done" && !done) return;
          collected.push({
            id: String((isObj && t.id) || `${m.id}-todo-${idx + 1}`),
            meetingId: m.id,
            meetingTitle: p.title || "",
            text: text.slice(0, 300),
            owner: String((isObj && t.owner) || "").slice(0, 80),
            due: String((isObj && t.due) || "").slice(0, 40),
            done,
          });
        });
      }
      result = {
        ok: true,
        items: collected.slice(a.offset, a.offset + a.limit),
        total: collected.length,
      };
    } else if (name === "get_research_reports") {
      if (a.meetingId && !allowed(g, a.meetingId))
        throw error(403, "OUT_OF_SCOPE", "会议不在授权范围");
      const rows = reports(g).filter(
        (r) => !a.meetingId || r.meetingId === a.meetingId,
      );
      const mapped = rows.map((r) => {
        const rep = r.report || {};
        const subQuestions = Array.isArray(rep.subs)
          ? rep.subs.slice(0, 12).map((s) => ({
              question: String(s?.q || s?.question || "").slice(0, 200),
              answer: String(
                s?.section?.answer || s?.answer || "",
              ).slice(0, 800),
            }))
          : [];
        const sources = Array.isArray(rep.sources)
          ? rep.sources
              .filter((s) => s && typeof s.url === "string" && /^https?:\/\//i.test(s.url))
              .slice(0, 20)
              .map((s) => ({
                title: String(s.title || s.name || "").slice(0, 160),
                url: s.url,
              }))
          : [];
        return {
          meetingId: r.meetingId,
          reportId: r.reportId,
          title:
            String(
              rep.title ||
                meetings(g).find((m) => m.id === r.meetingId)?.title ||
                "",
            ).slice(0, 200),
          conclusion: String(
            rep.conclusion || (r.markdown ? r.markdown.slice(0, 1200) : ""),
          ).slice(0, 1600),
          subQuestions,
          sources,
          updatedAt: r.updatedAt || null,
        };
      });
      result = {
        ok: true,
        items: mapped.slice(a.offset, a.offset + a.limit),
        total: mapped.length,
      };
    } else {
      throw error(403, "TOOL_NOT_ALLOWED", "此连接不允许调用该工具");
    }
    active(g.id);
    update(g.id, { lastReadAt: now() });
    return result;
  }
  async function route(req, res, u) {
    const management =
        u.pathname === "/setup/mcp-connection" ||
        u.pathname === "/setup/mcp-connection/autoconnect",
      bridge = u.pathname === "/asr-relay/mcp-connection";
    if (!management && !bridge) return false;
    const send = (status, value) => {
      res.writeHead(status, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
      });
      res.end(JSON.stringify(value));
      return true;
    };
    try {
      if (!isLocalReq(req))
        throw error(403, "LOCAL_ONLY", "只能从本机 Citeside 连接");
      if (management) {
        const token = String(req.headers["x-tht-token"] || ""),
          owner = String(settings.load().RELAY_TOKEN || "");
        if (
          !token ||
          !owner ||
          !crypto.timingSafeEqual(
            Buffer.from(hash(token), "hex"),
            Buffer.from(hash(owner), "hex"),
          )
        )
          throw error(401, "UNAUTHORIZED", "请从本机引导页面操作");
        if (req.method === "GET") {
          if (u.pathname !== "/setup/mcp-connection")
            throw error(405, "METHOD_NOT_ALLOWED", "不支持此方法");
          return send(200, state());
        }
      }
      if (req.method !== "POST")
        throw error(405, "METHOD_NOT_ALLOWED", "不支持此方法");
      if (
        !/^application\/json(?:\s*;|$)/i.test(req.headers["content-type"] || "")
      )
        throw error(415, "JSON_REQUIRED", "请使用 JSON 请求");
      const grant = bridge
        ? authenticate(
            /^Bearer ([A-Za-z0-9_-]+)$/.exec(
              req.headers.authorization || "",
            )?.[1],
          )
        : null;
      const chunks = [];
      let bodyBytes = 0;
      for await (const chunk of req) {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        bodyBytes += buffer.length;
        if (bodyBytes > 90000) throw error(413, "TOO_LARGE", "请求过长");
        chunks.push(buffer);
      }
      const body = Buffer.concat(chunks, bodyBytes).toString("utf8");
      let j;
      try {
        j = JSON.parse(body);
      } catch {
        throw error(400, "INVALID_JSON", "JSON 无效");
      }
      if (!j || typeof j !== "object" || Array.isArray(j))
        throw error(400, "INVALID_PARAMS", "参数无效");
      if (management) {
        if (u.pathname === "/setup/mcp-connection/autoconnect" || j.action === "autoconnect")
          return send(200, autoconnect(j.clientId));
        if (j.action === "connect") return send(200, connect(j));
        if (j.action === "disconnect")
          return send(200, disconnect(j.connectionId));
        throw error(400, "INVALID_ACTION", "操作无效");
      }
      if (j.method === "hello") {
        const g = update(grant.id, { lastConnectedAt: now() });
        return send(200, { ok: true, result: state(g) });
      }
      if (j.method === "tools/list") {
        active(grant.id);
        return send(200, {
          ok: true,
          result: {
            tools: tools.map((t) => ({
              name: t.name,
              title: t.title,
              description: t.description,
              annotations: t.annotations,
            })),
          },
        });
      }
      if (j.method !== "tools/call")
        throw error(403, "METHOD_NOT_ALLOWED", "此连接不允许此操作");
      const result = await call(grant, j.params?.name, j.params?.arguments);
      return send(200, { ok: true, result });
    } catch (e) {
      return send(e.status || 500, {
        ok: false,
        code: e.code || "INTERNAL_ERROR",
        error: e.status ? e.message : "连接暂时不可用",
      });
    }
  }
  return { route, state, connect, disconnect, authenticate, call };
}
module.exports = { create };
