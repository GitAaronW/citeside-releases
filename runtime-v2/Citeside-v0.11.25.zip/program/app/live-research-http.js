'use strict';
const ui=require('../web/live-research'),{esc}=require('../web/safe-markdown');
function html(body,title='会中研究',scripts=''){
 return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><link rel="stylesheet" href="/seatnote/live-research.css"><link rel="stylesheet" href="/seatnote/postmeeting.css"></head><body class="lr-scope lr-after-page">'+body+scripts+'</body></html>';
}
function afterPage(session,state){return html('<main data-live-research-after="'+esc(session.id||state.id)+'">'+ui.afterHtml(state)+'</main>',state.title,'<script src="/seatnote/safe-markdown.js"></script><script src="/seatnote/live-research.js"></script><script src="/seatnote/meeting-minutes.js"></script>');}
async function route(req,res,url,{engine,authed,owner,sessionOf=()=>null}={}){
 const p=url.pathname.replace(/^\/asr-relay/,'');if(!/^\/live-research(?:\/|$)/.test(p))return false;
 const send=(code,body,type='application/json')=>{res.writeHead(code,{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'"});res.end(type==='application/json'?JSON.stringify(body):body);return true;};
 if(!engine)return send(404,{error:'会中研究未开启'});
 const match=p.match(/^\/live-research\/share\/([a-f0-9]{48})$/);
 if(match){if(req.method!=='GET')return send(405,{error:'只读链接'});const snapshot=engine.readShare(match[1]);return snapshot?send(200,html(ui.snapshotHtml(snapshot),snapshot.title),'text/html'):send(404,'链接已失效','text/plain');}
 if(p!=='/live-research')return send(404,{error:'找不到页面'});
 if(!authed)return send(401,{error:'请连接 Mac'});if(!['GET','POST'].includes(req.method))return send(405,{error:'method'});
 if(req.method==='POST'&&!owner)return send(403,{error:'需要主令牌'});
 try{
  let j;if(req.method==='POST'){const chunks=[];let size=0;for await(const b of req){size+=Buffer.byteLength(b);if(size>24000)return send(413,{error:'请求太长'});chunks.push(Buffer.from(b));}try{j=JSON.parse(Buffer.concat(chunks).toString()||'{}');}catch{return send(400,{error:'格式不对'});}}
  const id=String(req.method==='GET'?url.searchParams.get('id')||'':j.id||'');if(!/^[\w-]{1,80}$/.test(id))return send(400,{error:'会议编号不对'});
  let session;try{session=sessionOf(id);}catch(e){if(!engine.has(id))return send(e.code||404,{error:'找不到这场会议'});}
  if(session){if(!session.id)session={...session,id};engine.sync(session);}else if(!engine.has(id))return send(404,{error:'找不到这场会议'});
  if(req.method==='GET'){if(typeof engine.warmAccountStatus==='function')await engine.warmAccountStatus();return send(200,engine.get(id));}
  const out=await engine.action(j);
  if(out&&out.ok===false&&out.code){
   const status=out.code==='account_login_required'?401:402;
   return send(status,out);
  }
  return send(200,out);
 }catch(e){
  const code=e&&typeof e.code==='string'?e.code:'';
  const status=code==='account_login_required'?401:['entitlement_required','quota_exhausted','research_quota_exhausted','ai_credits_exhausted'].includes(code)?402:400;
  return send(status,{ok:false,...(code?{code}:{}),error:e.message});
 }
}
module.exports={route,html,afterPage};
