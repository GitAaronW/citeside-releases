'use strict';

// Unified Feature Flags (Mother-Set vs External Stable Subset)
// - All experimental features default to FALSE (fail-closed) for external/public/MAS builds.
// - Internal dogfooding enables flags via a local-only file outside the app bundle:
//     ~/Library/Application Support/Citeside/feature-flags.json
//   or explicit environment variable CITESIDE_FEATURE_<NAME>=1.

const fs = require('fs');
const path = require('path');

const DEFAULTS = Object.freeze({
  interviewQuickReply: false,
  liveReportTick: false
});

const ENV_MAP = Object.freeze({
  interviewQuickReply: 'CITESIDE_FEATURE_INTERVIEW_QUICK_REPLY',
  liveReportTick: 'LIVE_REPORT_TICK'
});

function parseBool(v) {
  if (typeof v === 'boolean') return v;
  const s = typeof v === 'string' ? v.trim().toLowerCase() : v;
  if (s === 1 || s === '1' || s === 'true' || s === 'on') return true;
  if (s === 0 || s === '0' || s === 'false' || s === 'off') return false;
  return undefined;
}

function readLocalFlagsFile(dataDir) {
  if (!dataDir) return {};
  const file = path.join(dataDir, 'feature-flags.json');
  try {
    if (!fs.existsSync(file)) return {};
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function getFeatureFlags({ dataDir = '', env = process.env } = {}) {
  // Hard build-channel guard: public / MAS builds ALWAYS stay strict fail-closed subset
  const ch = String((env && env.CITESIDE_BUILD_CHANNEL) || '').trim().toLowerCase();
  if (ch === 'public' || ch === 'mas' || String((env && env.CITESIDE_MAS) || '') === '1') {
    return { ...DEFAULTS };
  }
  const local = readLocalFlagsFile(dataDir);
  const out = {};
  for (const [key, defVal] of Object.entries(DEFAULTS)) {
    let val = defVal;
    const localVal = parseBool(local[key]);
    if (localVal !== undefined) val = localVal;
    const envName = ENV_MAP[key];
    if (envName && env && Object.prototype.hasOwnProperty.call(env, envName)) {
      const envVal = parseBool(String(env[envName] || '').trim().toLowerCase());
      if (envVal !== undefined) val = envVal;
    }
    out[key] = Boolean(val);
  }
  return out;
}

function isFeatureEnabled(name, opts = {}) {
  const flags = getFeatureFlags(opts);
  return Boolean(flags[name]);
}

module.exports = {
  DEFAULTS,
  ENV_MAP,
  getFeatureFlags,
  isFeatureEnabled
};
