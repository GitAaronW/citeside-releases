'use strict';
// Adapt a saved, single-meeting text document to the existing cloud snapshot
// service. Never accept document content, transcripts or audio from the client.
const {reportView}=require('./live-research');
const MAX_BYTES=256*1024,TTL_HOURS=24,ID=/^[\w-]{1,80}$/,REQUEST=/^[a-f0-9-]{20,80}$/i;
const fail=(code,message,status=400)=>Object.assign(Error(message),{code,status});
function isSameMeetingSourceRef(ref, candidateId, meetingId){
 if(candidateId&&!String(candidateId).startsWith(meetingId+':'))return false;
 if(!ref)return true;
 const s=String(ref);
 if(s.startsWith(meetingId+':'))return true;
 if(s==='meeting-minutes'||s==='meeting-minutes:'+meetingId)return true;
 if(s==='pending-external'||s.startsWith('solution-section:'))return true;
 return false;
}
function textParagraphs(document,meetingId,{literal=false}={}){
 const ids=[...new Set((document.meetingIds||[]).map(value=>typeof value==='string'?value:value?.id||value?.meetingId).filter(Boolean))];
 if(ids.length!==1||ids[0]!==meetingId)throw fail('share_cross_meeting','这份笔记包含跨会议内容，现有云分享不能完整、安全地分享。',409);
 const lines=[];let count=0;
 function visit(node,prefix=''){
  if(++count>20000)throw fail('share_too_large','笔记超过现有云分享容量，未上传或截断。',413);
  const ref=node.attrs?.sourceRef;if(!isSameMeetingSourceRef(ref,node.attrs?.candidateId,meetingId))throw fail('share_cross_meeting','这份笔记包含其他来源内容，未创建分享。',409);
  if(ref==='pending-external'||(typeof ref==='string'&&ref.startsWith('solution-section:pending')))return;
  if((node.marks||[]).some(mark=>!['bold','italic'].includes(mark.type)))throw fail('share_rich_content','笔记包含现有云分享不能完整保留的链接、代码或富内容，未上传。',409);
  const children=Array.isArray(node.content)?node.content:[];
  const inline=n=>{if(n.type==='text'&&typeof n.text==='string'){if((n.marks||[]).some(mark=>!['bold','italic'].includes(mark.type)))throw fail('share_rich_content','笔记包含现有云分享不能完整保留的链接或富内容，未上传。',409);return n.text;}if(n.type==='hardBreak')return '\n';throw fail('share_rich_content','笔记包含现有云分享不能完整保留的富内容，未上传。',409);};
  if(['paragraph','heading'].includes(node.type)){const value=children.map(inline).join('');if(!literal&&/`[^`]+`|\*\*[^*]+\*\*|(^|\s)_[^_]+_|^#{1,6}\s/m.test(value))throw fail('share_literal_markup','笔记含现有云页面会改写显示的特殊文字标记，未上传。',409);for(const line of value.split('\n'))lines.push(prefix+line);return;}
  if(['doc','listItem'].includes(node.type)){children.forEach(child=>visit(child,prefix));return;}
  if(node.type==='blockquote'){children.forEach(child=>visit(child,prefix+'› '));return;}
  if(node.type==='bulletList'){children.forEach(child=>visit(child,prefix+'• '));return;}
  if(node.type==='orderedList'){children.forEach((child,index)=>visit(child,prefix+((node.attrs?.start||1)+index)+'. '));return;}
  if(node.type==='taskList'){children.forEach(child=>visit(child,prefix));return;}
  if(node.type==='taskItem'){children.forEach(child=>visit(child,prefix+(node.attrs?.checked?'☑ ':'☐ ')));return;}
  throw fail('share_rich_content','笔记包含图片、图表、富表格或其他现有云分享不能完整保留的内容，未上传。',409);
 }
 if(!document.content||document.content.type!=='doc')throw fail('share_note_unavailable','尚无可完整分享的已保存文字笔记。',409);
 visit(document.content);return lines.filter(line=>String(line||'').trim());
}
function summaryLinesOf(session){
 const s=String(session?.summary||session?.shareNote||'').trim();
 if(!s)return [];
 return s.split(/\r?\n/).map(line=>line.trim()).filter(Boolean);
}
function markdownBody(note,research,meetingId,{session=null,includeTranscript=false}={}){
 let paragraphs=textParagraphs(note,meetingId,{literal:true});
 const fallbackSummary=summaryLinesOf(session);
 if(!paragraphs.some(line=>line.trim())&&fallbackSummary.length)paragraphs=fallbackSummary;
 const sections=[];
 const title=String(note.title||session?.topicTitle||session?.title||'').trim();
 if(title)sections.push('# '+title);
 const bodyText=paragraphs.join('\n\n').trim();
 if(bodyText)sections.push(bodyText);
 const doneResearch=(research?.items||[]).filter(item=>item.state==='done').map(item=>reportView(item,{full:true}));
 if(doneResearch.length){
  const parts=['## 深度研究'];
  for(const r of doneResearch){
   if(r.title)parts.push('### '+r.title);
   if(r.conclusion)parts.push(r.conclusion);
   for(const sub of r.subs||[]){
    if(sub.q)parts.push('#### '+sub.q);
    if(sub.section?.answer)parts.push(sub.section.answer);
   }
  }
  sections.push(parts.join('\n\n'));
 }
 if(includeTranscript&&Array.isArray(session?.transcript)&&session.transcript.length){
  const txLines=['## 完整转写'];
  for(const row of session.transcript){
   const txt=String(row?.text||'').trim();
   if(!txt)continue;
   const t=row.t||row.atSec||'';
   const spk=row.speaker||row.spk||'';
   const head=[t?`[${t}]`:'',spk].filter(Boolean).join(' ');
   txLines.push(head?`${head} ${txt}`:txt);
  }
  if(txLines.length>1)sections.push(txLines.join('\n\n'));
 }
 if(!bodyText&&!doneResearch.length&&!(includeTranscript&&session?.transcript?.length))throw fail('share_empty','这场会议还没有可分享的文字笔记或已完成研究。',409);
 return {ok:true,title:title||'meeting-notes',markdown:sections.join('\n\n')+'\n'};
}
function snapshot(note,research,meetingId,now=Date.now(),session=null){
 let paragraphs=textParagraphs(note,meetingId,{literal:true});
 const fallbackSummary=summaryLinesOf(session);
 if(!paragraphs.some(line=>line.trim())&&fallbackSummary.length)paragraphs=fallbackSummary;
 const items=[];
 if(paragraphs.some(line=>line.trim()))items.push({kind:'minutes',minutes:{format:'plain-text-v1',notice:'完整文字笔记',discussion:paragraphs,conclusions:[],todos:[]}});
 for(const item of research?.items||[])if(item.state==='done')items.push({kind:'research',report:reportView(item,{full:true})});
 if(!items.length)throw fail('share_empty','这场会议还没有可分享的文字笔记或已完成研究。',409);
 const value={title:String(note.title||''),createdAt:now,items};
 if(Buffer.byteLength(JSON.stringify(value))>MAX_BYTES)throw fail('share_too_large','内容超过256 KiB云分享容量，未上传或截断。',413);
 return value;
}
function savedNote({dataDir,hub,meetingId,documentId,revision,titleFor}={}){
 if(!ID.test(meetingId||'')||!/^doc-[a-f0-9]{24}$/.test(documentId||'')||!Number.isSafeInteger(revision)||revision<0)throw fail('share_note_changed','请先保存本场笔记后再分享。',409);
 const source=hub?.data?.sources?.find(value=>value.sessionId===meetingId||value.key==='session:'+meetingId);
 if(!source||source.motherDocumentId!==documentId)throw fail('share_note_changed','笔记绑定已变化，请重新打开本场笔记。',409);
 const entry=require('./mother-documents').get(dataDir).read(documentId),record=entry.record;
 if(record.revision!==revision)throw fail('share_note_changed','笔记版本已变化，请保存后重试。',409);
 const ids=[...new Set((record.meetings||[]).map(value=>typeof value==='string'?value:value?.id||value?.meetingId).filter(Boolean))];
 if(ids.length!==1||ids[0]!==meetingId)throw fail('share_cross_meeting','这份笔记包含跨会议内容，未创建分享。',409);
 const title=typeof titleFor==='function'?titleFor(meetingId,source):source.title;
 const out={title:typeof title==='string'?title:String(source.title||''),documentId,revision,meetingIds:record.meetings,content:require('./mother-document-runtime').yDocToProsemirrorJSON(entry.doc,'default')};
 if(dataDir)Object.defineProperty(out,'dataDir',{value:dataDir,enumerable:false});
 return out;
}
function create({getNote,getSession=()=>null,getResearch=()=>null,cloudShare,dataDir='',now=Date.now,forbidShare=()=>false}={}){
 const jobs=new Map();
 async function withdraw(job){if(!job.result?.token)return;if(!job.revocation)job.revocation=Promise.resolve(cloudShare.revokeShare({token:job.result.token})).then(result=>{if(!result?.ok)throw fail('share_revoke_unconfirmed','撤回分享未确认，请在账号分享管理中重试。',502);});await job.revocation;}
 function jobFor(id,requestId){if(!ID.test(id||'')||!REQUEST.test(requestId||''))throw fail('share_invalid_request','分享请求无效。');for(const [key,job]of jobs)if(job.finishedAt&&now()-job.finishedAt>300000)jobs.delete(key);let job=jobs.get(requestId);if(job&&job.id!==id)throw fail('share_request_changed','会议已切换，未创建分享。',409);if(!job){if(jobs.size>=64)throw fail('share_busy','分享请求过多，请稍后重试。',429);job={id,cancelled:false};jobs.set(requestId,job);}return job;}
 return {
  async cancel({id,requestId}){const job=jobFor(id,requestId);job.cancelled=true;if(!job.promise)job.finishedAt=now();await withdraw(job);return {ok:true,cancelled:true};},
  async markdown({id,documentId,revision,noteVersion,includeTranscript=false}){
   if(forbidShare())throw fail('share_forbidden','已开启全局「禁止分享锁」，无法导出或分享。',403);
   const legacy=noteVersion!==undefined;
   if(legacy?(!/^[a-f0-9]{64}$/.test(noteVersion||'')||documentId!==undefined||revision!==undefined):(!/^doc-[a-f0-9]{24}$/.test(documentId||'')||!Number.isSafeInteger(revision)||revision<0))throw fail('share_note_changed','请先保存本场笔记后再分享。',409);
   const note=await getNote(id,legacy?{noteVersion}:{documentId,revision});
   if(!note||(legacy?note.noteVersion!==noteVersion:note.documentId!==documentId||note.revision!==revision))throw fail('share_note_changed','笔记尚未保存或版本已变化，请保存后重试。',409);
   return markdownBody(note,await getResearch(id),id,{session:await getSession(id),includeTranscript:!!includeTranscript});
  },
  async share({id,documentId,revision,noteVersion,requestId,hours}){
   if(forbidShare())throw fail('share_forbidden','已开启全局「禁止分享锁」，无法创建外发链接。',403);
   const legacy=noteVersion!==undefined;
   if(legacy?(!/^[a-f0-9]{64}$/.test(noteVersion||'')||documentId!==undefined||revision!==undefined):(!/^doc-[a-f0-9]{24}$/.test(documentId||'')||!Number.isSafeInteger(revision)||revision<0))throw fail('share_note_changed','请先保存本场笔记后再分享。',409);
   const ttl=hours===undefined?TTL_HOURS:Number(hours);
   if(!Number.isInteger(ttl)||![24,48].includes(ttl))throw fail('share_invalid_hours','分享有效期仅支持 24 小时或 48 小时。',400);
   const job=jobFor(id,requestId);if(job.cancelled)return {ok:true,cancelled:true};
   if(job.promise)return job.promise;
   job.promise=(async()=>{
    if(!cloudShare?.createShare)throw fail('share_unavailable','云分享暂时不可用，请稍后重试。',503);
    const note=await getNote(id,legacy?{noteVersion}:{documentId,revision});
    if(!note||(legacy?note.noteVersion!==noteVersion:note.documentId!==documentId||note.revision!==revision))throw fail('share_note_changed','笔记尚未保存或版本已变化，请保存后重试。',409);
    const body=snapshot(note,await getResearch(id),id,now(),await getSession(id));if(job.cancelled)return {ok:true,cancelled:true};
    const result=await cloudShare.createShare({snapshot:body,hours:ttl});
    if(!result?.ok)throw fail(result?.code||'share_failed',result?.code==='unauthorized'?'请先在设置中登录账号。':result?.code==='share_limit_reached'?'云分享链接数量已达上限，请先在账号分享管理中撤销旧链接。':'云分享未成功，请稍后重试。',result?.code==='unauthorized'?401:502);
    if(!/^https:\/\//.test(result.url||'')||!result.token)throw fail('share_invalid_response','云分享未返回有效链接。',502);
    job.result=result;if(job.cancelled){await withdraw(job);return {ok:true,cancelled:true};}
    const targetDir=note?.dataDir||dataDir;
    if(targetDir){
      const ts=new Date(now()).toISOString();
      try{require('./memory-state').ingestSharedNote(targetDir,{meetingId:id,title:note.title,snapshot:body,nowIso:ts});}catch{}
      try{Promise.resolve(require('./structured-memory').consolidateSharedNote(targetDir,{meetingId:id,title:note.title,snapshot:body,nowIso:ts,useLlm:false})).catch(()=>{});}catch{}
    }
    return {ok:true,url:result.url,expiresAt:result.expiresAt,hours:Number.isInteger(result.hours)?result.hours:ttl};
   })().finally(()=>{job.finishedAt=now();});return job.promise;
  }
 };
}
async function route(req,res,url,{engine,authed,owner}={}){
 if(url.pathname.replace(/^\/asr-relay/,'')!=='/meeting-cloud-share')return false;
 const send=(status,body)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body));return true;};
 if(!authed)return send(401,{error:'请先连接本机服务。'});if(!owner)return send(403,{error:'需要主窗口授权。'});if(req.method!=='POST')return send(405,{error:'method'});
 if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)return send(403,{error:'origin'});
 try{let length=0,chunks=[];for await(const chunk of req){length+=Buffer.byteLength(chunk);if(length>4096)return send(413,{error:'请求过长。'});chunks.push(Buffer.from(chunk));}const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
  if(Object.keys(body).some(key=>!['id','documentId','revision','noteVersion','requestId','action','hours','includeTranscript'].includes(key)))return send(400,{error:'分享只能读取已保存的本场笔记。'});
  if(body.action!==undefined&&!['cancel','markdown'].includes(body.action))return send(400,{error:'无效分享操作。'});
  if(body.hours!==undefined&&![24,48].includes(Number(body.hours)))return send(400,{error:'分享有效期仅支持 24 小时或 48 小时。'});
  if(!engine)return send(503,{error:'云分享暂时不可用。'});return send(200,body.action==='cancel'?await engine.cancel(body):body.action==='markdown'?await engine.markdown(body):await engine.share(body));
 }catch(error){return send(error.status||400,{error:error.message,code:error.code||'share_invalid_request'});}
}
module.exports={MAX_BYTES,TTL_HOURS,textParagraphs,snapshot,savedNote,create,route};
