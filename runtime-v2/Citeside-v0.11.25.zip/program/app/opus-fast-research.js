'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const FAST_BUDGET_MS = 25000;
const MAX_SOURCES = 5;
const VERDICTS = new Set(['成立', '存疑', '不成立', '查不到', '口径差异', '有条件成立']);
const PEAK_RE = /理论峰值|理论极限|标称峰值|峰值|theoretical peak|\bpeak\b/i;
const COMMERCIAL_AVG_RE = /商业均值|商用均值|商业平均|商用平均|行业均值|commercial average|typical average/i;
const VIZ_TYPES = new Set(['compare_bar', 'timeline', 'metric_table', 'checklist']);
const UUID_RE = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/i;
const HEX_ID_RE = /^[0-9a-f]{16,}$/i;
const RAW_REF_RE = /^(?:W\d+|S\d+|src[-_]?\d+|source[-_]?\d+|id[-_]?\d+)$/i;

function clip(s, n = 200) {
  return String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);
}

function isUuidLike(s) {
  const v = String(s == null ? '' : s).trim();
  if (!v) return true;
  return UUID_RE.test(v) || HEX_ID_RE.test(v) || RAW_REF_RE.test(v);
}

function safeHttpUrl(raw) {
  try {
    const u = new URL(String(raw || '').trim());
    if (!['https:', 'http:'].includes(u.protocol) || u.username || u.password) return '';
    return u.href;
  } catch {
    return '';
  }
}

function hostnameOf(rawUrl) {
  try {
    const u = new URL(String(rawUrl || '').trim());
    return String(u.hostname || '').replace(/^www\./i, '').toLowerCase();
  } catch {
    return '';
  }
}

function rootDomainOf(rawUrl) {
  const host = hostnameOf(rawUrl);
  if (!host) return '';
  const parts = host.split('.').filter(Boolean);
  if (parts.length <= 2) return host;
  const tail2 = parts.slice(-2).join('.');
  if (/^(?:com|org|net|gov|edu|co)\.[a-z]{2}$/i.test(tail2) && parts.length >= 3) {
    return parts.slice(-3).join('.');
  }
  return tail2;
}

function sanitizeSourceName(src, url, title = '') {
  const host = hostnameOf(url);
  const candidate = clip(src, 48);
  if (candidate && !isUuidLike(candidate) && !/^https?:\/\//i.test(candidate)) {
    return candidate;
  }
  const cleanTitle = clip(title, 60);
  if (cleanTitle && !isUuidLike(cleanTitle)) {
    const seg = cleanTitle.split(/\s+[-–—|·]\s+/).map(x => x.trim()).filter(Boolean);
    if (seg.length > 1) {
      const last = seg[seg.length - 1];
      if (last && last.length <= 32 && !isUuidLike(last)) return last;
    }
  }
  return host || '';
}

function resolveUiLang(session, reqLang) {
  const explicit = String(reqLang || session?.uiLang || '').trim().toLowerCase();
  if (explicit === 'en' || explicit.startsWith('en-')) return 'en';
  if (explicit === 'zh' || explicit.startsWith('zh-')) return 'zh';
  const fallback = String(session?.lang || '').trim().toLowerCase();
  if (fallback === 'en' || fallback.startsWith('en-')) return 'en';
  return 'zh';
}

function normCardKind(cardKind) {
  return String(cardKind || '').trim().toLowerCase();
}

function defaultVizForCardKind(cardKind) {
  const k = normCardKind(cardKind);
  if (k === 'fact_check' || k === 'external_case' || k === 'external') return 'metric_table';
  if (['timeline', 'history', 'roadmap', 'policy', 'milestone'].includes(k)) return 'timeline';
  if (['comparison', 'pricing', 'metrics', 'market', 'benchmark_table'].includes(k)) return 'metric_table';
  if (['blind_spot', 'risk', 'compliance', 'action', 'memory_conflict', 'checklist'].includes(k)) return 'checklist';
  return 'compare_bar';
}

function peakVersusCommercialAverage(raw) {
  const viz = raw?.viz && typeof raw.viz === 'object' ? raw.viz : {};
  const cells = [];
  for (const it of Array.isArray(viz.items) ? viz.items : []) cells.push(it?.label, it?.display, it?.note);
  for (const col of Array.isArray(viz.columns) ? viz.columns : []) cells.push(col);
  for (const row of Array.isArray(viz.rows) ? viz.rows : []) {
    for (const cell of Array.isArray(row) ? row : []) cells.push(cell);
  }
  const blob = [raw?.title, raw?.delta, raw?.say, raw?.conclusion, raw?.takeaway, ...cells].map(v => String(v == null ? '' : v)).join('\n');
  return PEAK_RE.test(blob) && COMMERCIAL_AVG_RE.test(blob);
}

function chineseProposition(value) {
  const text = clip(typeof value === 'string' ? value : value?.q, 80).replace(/^[0-9]+[.、)\]]\s*/, '');
  if (Array.from(text).length < 8 || !/[\u4e00-\u9fff]/.test(text)) return '';
  if (/^(其他|待定|补充|未知|待查|拆解)/.test(text)) return '';
  return text;
}

function independentDomainCount(evidence) {
  const domains = new Set();
  for (const e of Array.isArray(evidence) ? evidence : []) {
    const d = rootDomainOf(e?.url);
    if (d) domains.add(d);
  }
  return domains.size;
}

function validateViz(viz, hasEvidence) {
  if (!hasEvidence || !viz || typeof viz !== 'object') return null;
  const type = String(viz.type || '').trim();
  if (!VIZ_TYPES.has(type)) return null;
  const title = clip(viz.title, 48);
  const unit = clip(viz.unit, 16);

  if (type === 'compare_bar') {
    const items = (Array.isArray(viz.items) ? viz.items : [])
      .map(it => ({
        label: clip(it?.label, 28),
        value: typeof it?.value === 'number' && Number.isFinite(it.value) ? it.value : Number(it?.value),
        display: clip(it?.display, 24),
        highlight: it?.highlight === true
      }))
      .filter(it => it.label && Number.isFinite(it.value) && it.value >= 0)
      .slice(0, 6);
    if (items.length < 2) return null;
    return { type, title, unit, items };
  }

  if (type === 'timeline') {
    const items = (Array.isArray(viz.items) ? viz.items : [])
      .map(it => ({
        date: clip(it?.date, 20),
        label: clip(it?.label, 40),
        note: clip(it?.note, 48)
      }))
      .filter(it => it.date && it.label)
      .slice(0, 6);
    if (items.length < 2) return null;
    return { type, title, items };
  }

  if (type === 'metric_table') {
    const columns = (Array.isArray(viz.columns) ? viz.columns : [])
      .map(c => clip(c, 24)).filter(Boolean).slice(0, 4);
    const rows = (Array.isArray(viz.rows) ? viz.rows : [])
      .map(r => (Array.isArray(r) ? r : []).map(c => clip(c, 40)))
      .filter(r => r.length === columns.length && r.some(Boolean))
      .slice(0, 6);
    if (columns.length < 2 || !rows.length) return null;
    return { type, title, columns, rows };
  }

  if (type === 'checklist') {
    const items = (Array.isArray(viz.items) ? viz.items : [])
      .map(it => ({
        label: clip(it?.label, 48),
        status: ['ok', 'warn', 'miss'].includes(it?.status) ? it.status : 'warn',
        note: clip(it?.note, 48)
      }))
      .filter(it => it.label)
      .slice(0, 6);
    if (!items.length) return null;
    return { type, title, items };
  }

  return null;
}

function enforceCharBudget(delta, say, maxTotal = 120) {
  let d = clip(delta, 90);
  let s = clip(say, 45);
  const dArr = Array.from(d), sArr = Array.from(s);
  if (dArr.length + sArr.length <= maxTotal) return { delta: d, say: s };
  const sCap = Math.min(sArr.length, 40);
  const dCap = Math.max(20, maxTotal - sCap);
  d = dArr.length > dCap ? dArr.slice(0, dCap - 1).join('') + '…' : d;
  s = sArr.length > sCap ? sArr.slice(0, sCap - 1).join('') + '…' : s;
  return { delta: d, say: s };
}

function validateFastCard(raw, fetchedSources, { cardKind = '', uiLang = 'zh', fallbackTitle = '' } = {}) {
  const allowedByUrl = new Map();
  for (const s of Array.isArray(fetchedSources) ? fetchedSources : []) {
    const u = safeHttpUrl(s?.url);
    if (u && !allowedByUrl.has(u)) allowedByUrl.set(u, s);
  }

  const rawEvidence = Array.isArray(raw?.evidence) ? raw.evidence : [];
  const evidence = [];
  const seenUrls = new Set();
  for (const e of rawEvidence) {
    const url = safeHttpUrl(e?.url);
    if (!url || seenUrls.has(url)) continue;
    if (allowedByUrl.size > 0 && !allowedByUrl.has(url)) continue;
    const matched = allowedByUrl.get(url);
    const src = sanitizeSourceName(e?.src || e?.source || e?.name, url, matched?.title || e?.title || '');
    if (!src || isUuidLike(src)) continue;
    seenUrls.add(url);
    evidence.push({
      src,
      url,
      date: clip(e?.date, 20),
      fact: clip(e?.fact || e?.quote || matched?.snippet || '', 60)
    });
    if (evidence.length >= MAX_SOURCES) break;
  }

  let verdict = VERDICTS.has(raw?.verdict) ? raw.verdict : '存疑';
  const domainCount = independentDomainCount(evidence);
  const kind = normCardKind(cardKind);
  const peakGap = peakVersusCommercialAverage(raw);
  const nuanced = verdict === '口径差异' || verdict === '有条件成立';
  if (evidence.length === 0) {
    verdict = '查不到';
  } else if (nuanced && !peakGap) {
    verdict = '存疑';
  } else if (!nuanced && (verdict === '成立' || verdict === '不成立') && domainCount < 2) {
    verdict = '存疑';
  }

  const budgeted = enforceCharBudget(
    raw?.delta || (evidence.length === 0 ? (uiLang === 'en' ? 'No verifiable public source found.' : '暂未查到可交叉核验的公开权威来源。') : ''),
    raw?.say || '',
    120
  );

  const viz = validateViz(raw?.viz, evidence.length > 0);
  const title = clip(raw?.title || fallbackTitle, 60);
  const subQuestions = kind === 'blind_spot'
    ? [...new Set((Array.isArray(raw?.subQuestions) ? raw.subQuestions : []).map(chineseProposition).filter(Boolean))].slice(0, 3)
    : [];
  const keptQuestions = subQuestions.length >= 2 ? subQuestions : [];
  const conclusion = kind === 'blind_spot' ? chineseProposition(raw?.conclusion || raw?.delta) : '';
  const ask = kind === 'blind_spot' ? chineseProposition(raw?.ask || raw?.say) : '';
  const takeaway = kind === 'external_case' ? clip(raw?.takeaway || raw?.say || raw?.delta, 120) : '';

  return {
    schema: 'opus-fast-v1',
    uiLang,
    cardKind: String(cardKind || ''),
    defaultViz: defaultVizForCardKind(cardKind),
    title,
    verdict,
    delta: budgeted.delta,
    say: budgeted.say,
    viz,
    evidence,
    independentDomains: domainCount,
    subQuestions: keptQuestions,
    conclusion,
    ask,
    takeaway
  };
}

function parseJsonLoose(raw) {
  const txt = String(raw || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  try { return JSON.parse(txt); } catch {}
  const a = txt.indexOf('{'), b = txt.lastIndexOf('}');
  if (a >= 0 && b > a) {
    try { return JSON.parse(txt.slice(a, b + 1)); } catch {}
  }
  return null;
}

function buildQueryPrompt(uiLang) {
  return [
    'Generate 2 to 3 concise, high-precision web search queries to fact-check the claim or question.',
    'Convert relative time ("this year"/"last year"/"今年"/"去年") using payload "today" into explicit calendar years.',
    'Prefer authoritative official data, filings, standards, or mainstream financial/tech media.',
    uiLang === 'zh' ? 'Search queries may use Chinese or English keywords (whichever retrieves better primary sources).' : 'Use concise English search queries.',
    'Return strict JSON only: {"queries":["q1","q2"]}'
  ].join('\n');
}

function kindPrompt(uiLang, cardKind, defaultViz) {
  const kind = normCardKind(cardKind);
  if (uiLang === 'en') {
    if (kind === 'fact_check') return [
      'cardKind=fact_check. Do NOT emit subQuestions or a research breakdown.',
      'When the claim cites a theoretical peak and sources cite a commercial average (or the reverse), and the two are not the same metric, verdict MUST be "口径差异" or "有条件成立". Do not collapse that gap into plain "不成立" or "成立".',
      'Prefer a clean comparison table: viz.type="metric_table" with columns such as ["Metric","Meeting claim","Public figure"].'
    ];
    if (kind === 'blind_spot') return [
      'cardKind=blind_spot. Return 2 or 3 clear Simplified-Chinese proposition subQuestions (declarative sentences, not English labels), plus conclusion and ask in Simplified Chinese.',
      'Preserve those propositions. Do not replace them with a vague topic list.',
      `Preferred viz.type is "${defaultViz}".`
    ];
    if (kind === 'external_case') return [
      'cardKind=external_case. Return viz.type="metric_table" as a precedent comparison (columns such as ["Precedent","Move","Result","Takeaway"]) and a one-sentence takeaway.',
      'Do not invent a numbered research breakdown.'
    ];
    return [];
  }
  if (kind === 'fact_check') return [
    'cardKind=fact_check：不要输出 subQuestions，也不要做研究拆解。',
    '若会上说法是理论峰值、实验室极限或标称上限，公开来源给出的是商业均值、商用平均或行业典型值，且两者不是同一口径，verdict 必须用「口径差异」或「有条件成立」，不要判成单纯的「不成立」或「成立」。',
    '优先给干净对照表：viz.type="metric_table"，columns 例如 ["口径","会上说法","公开数据"]。'
  ];
  if (kind === 'blind_spot') return [
    'cardKind=blind_spot：必须保留 2 到 3 条简体中文命题式 subQuestions（每条是说得清的判断句，不要英文、不要「其他/待查」这类空词），再给 conclusion（中文结论）和 ask（一句中文追问）。',
    '不要把这 2–3 条命题拆成含糊的主题清单。',
    `优先 viz.type="${defaultViz}"。`
  ];
  if (kind === 'external_case') return [
    'cardKind=external_case：必须返回 viz.type="metric_table" 的先例对照表（列如 ["先例","做法","结果","可借鉴"]）以及一句 takeaway。',
    '不要再套一层编号研究拆解。'
  ];
  return [];
}

function buildSynthPrompt(uiLang, defaultViz, cardKind = '') {
  const extra = kindPrompt(uiLang, cardKind, defaultViz);
  if (uiLang === 'en') {
    return [
      'You are an executive real-time fact-check analyst. Synthesize ONLY from the provided sources in ONE shot.',
      'STRICT OUTPUT LANGUAGE: Write title, delta, say, viz labels, and evidence[].fact strictly in English.',
      'Verdict MUST be one of: "成立" (confirmed), "不成立" (refuted), "存疑" (uncertain/single-source), "查不到" (not found).',
      'HARD RULES:',
      '1. Only use "成立" or "不成立" when >=2 independent domains confirm it; otherwise use "存疑".',
      '2. delta + say MUST be <=120 characters total. delta must state "Meeting said X -> Actually Y".',
      '3. evidence[].src MUST be a real media/org name or domain (e.g. "Reuters", "sec.gov") — NEVER a UUID or internal ID. Copy url verbatim from sources.',
      `4. Preferred viz.type is "${defaultViz}" (choose from compare_bar|timeline|metric_table|checklist). If sources are empty, set viz:null.`,
      'Return strict JSON only: {"title":"...","verdict":"成立|存疑|不成立|查不到|口径差异|有条件成立","delta":"...","say":"...","subQuestions":[],"conclusion":"","ask":"","takeaway":"","viz":{"type":"'+defaultViz+'","title":"...","unit":"","items":[]},"evidence":[{"src":"Reuters","url":"https://...","date":"2026-03","fact":"..."}]}',
      ...extra
    ].join('\n');
  }
  return [
    '你是顶级实时会议核查分析师，只根据程序已抓取的公开来源，一次性输出极简 Fact-Check 卡。',
    '严格中文输出红线：即使会议原话或检索网页是英文，title、delta、say、viz 内所有标签以及 evidence[].fact 必须全部使用简体中文！',
    'verdict 只能是："成立" | "存疑" | "不成立" | "查不到" | "口径差异" | "有条件成立"。后两个仅在理论峰值与商业均值口径不同时使用。',
    '硬性规则：',
    '1. 必须至少有 2 个独立域名来源交叉印证才能判「成立」或「不成立」；只有 1 个来源或有冲突时一律判「存疑」；无有效来源判「查不到」。',
    '2. delta（对比结论，采用「会上说 X → 实际是 Y」）+ say（可直接开口说的一句话）总字数严格 ≤120 字。',
    '3. evidence[].src 必须是真实媒体名/机构名或域名（如「国家统计局」「Reuters」「sec.gov」），严禁出现 UUID 或 W1/S1 等内部编号；url 必须原样复制自 sources。',
    `4. 优先使用 viz.type="${defaultViz}"（仅限 compare_bar | timeline | metric_table | checklist 四种）。无出处时 viz 必须为 null。`,
    'viz 格式要求：',
    '- compare_bar: {"type":"compare_bar","title":"...","unit":"%","items":[{"label":"会上说法","value":30,"highlight":true},{"label":"公开数据","value":18}]}',
    '- timeline: {"type":"timeline","title":"...","items":[{"date":"2024-06","label":"...","note":"..."}]}',
    '- metric_table: {"type":"metric_table","title":"...","columns":["指标","会上说法","公开数据"],"rows":[["...","...","..."]]}',
    '- checklist: {"type":"checklist","title":"...","items":[{"label":"...","status":"ok|warn|miss","note":"..."}]}',
    '只返回严格 JSON：{"title":"<=20字中文标题","verdict":"成立|存疑|不成立|查不到|口径差异|有条件成立","delta":"会上说X→实际是Y","say":"可直接说的一句话","subQuestions":["中文命题"],"conclusion":"","ask":"","takeaway":"","viz":null,"evidence":[{"src":"真实媒体或域名","url":"https://...","date":"2026-03","fact":"<=40字中文依据"}]}',
    ...extra
  ].join('\n');
}

function heuristicQueries(text) {
  const clean = clip(text, 120);
  if (!clean) return [];
  const short = clean.split(/[，。？！,!?；;]/)[0].trim();
  return [...new Set([clean, short].filter(x => x && x.length >= 4))].slice(0, 2);
}

function cacheFileOf(dataDir) {
  return dataDir ? path.join(dataDir, 'live-research-fast-cache.json') : '';
}

function cacheKeyOf(claim, cardKind, uiLang) {
  return crypto.createHash('sha256')
    .update([clip(claim, 240).toLowerCase(), String(cardKind || '').toLowerCase(), uiLang].join('\n'))
    .digest('hex')
    .slice(0, 32);
}

function readCache(dataDir, key, nowMs) {
  const file = cacheFileOf(dataDir);
  if (!file) return null;
  try {
    const db = JSON.parse(fs.readFileSync(file, 'utf8'));
    const entry = db && db[key];
    if (entry && Number.isFinite(entry.at) && (nowMs - entry.at) < CACHE_TTL_MS && entry.card) {
      return entry.card;
    }
  } catch {}
  return null;
}

function writeCache(dataDir, key, card, nowMs) {
  const file = cacheFileOf(dataDir);
  if (!file) return;
  try {
    let db = {};
    try { db = JSON.parse(fs.readFileSync(file, 'utf8')) || {}; } catch {}
    for (const [k, v] of Object.entries(db)) {
      if (!v || !Number.isFinite(v.at) || (nowMs - v.at) >= CACHE_TTL_MS) delete db[k];
    }
    db[key] = { at: nowMs, card };
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = file + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, file);
  } catch {}
}

async function runFastCheck({
  claim,
  cardKind = '',
  uiLang = 'zh',
  transcript = [],
  ask,
  search,
  dataDir = '',
  sessionId = '',
  now = Date.now,
  signal = null
}) {
  const startedAt = now();
  const lang = uiLang === 'en' ? 'en' : 'zh';
  const defaultViz = defaultVizForCardKind(cardKind);
  const cKey = cacheKeyOf(claim, cardKind, lang);
  const cached = readCache(dataDir, cKey, startedAt);
  if (cached) {
    return { ...cached, cached: true, elapsedMs: Math.max(0, now() - startedAt) };
  }

  const today = new Date(startedAt).toISOString().slice(0, 10);
  const deadline = startedAt + FAST_BUDGET_MS;
  const remaining = () => Math.max(1500, deadline - now());

  // Step 1: Flash generates 2-3 search queries (fast, <=6s)
  let queries = [];
  try {
    const qRaw = await ask(
      buildQueryPrompt(lang),
      JSON.stringify({ today, claim: clip(claim, 400), context: (Array.isArray(transcript) ? transcript : []).slice(-6) }),
      { kind: 'quick', purpose: 'opus-fast-queries', sessionId, tools: false, json: true, maxTokens: 300, timeoutMs: Math.min(6000, remaining()), signal }
    );
    const qObj = parseJsonLoose(qRaw);
    if (Array.isArray(qObj?.queries)) {
      queries = [...new Set(qObj.queries.map(q => clip(q, 140)).filter(Boolean))].slice(0, 3);
    }
  } catch {}
  if (!queries.length) queries = heuristicQueries(claim);

  // Step 2: Parallel search, cap at <=5 unique sources
  const settled = await Promise.allSettled(
    queries.slice(0, 3).map(q => Promise.resolve(search(q, MAX_SOURCES, { signal, sessionId, purpose: 'opus-fast-search' })))
  );
  const fetchedSources = [];
  const seenUrls = new Set();
  for (const r of settled) {
    if (r.status !== 'fulfilled' || !Array.isArray(r.value)) continue;
    for (const row of r.value) {
      const url = safeHttpUrl(row?.url);
      if (!url || seenUrls.has(url)) continue;
      const src = sanitizeSourceName(row?.src || row?.source || row?.siteName, url, row?.title || '');
      if (!src || isUuidLike(src)) continue;
      seenUrls.add(url);
      fetchedSources.push({
        src,
        url,
        title: clip(row?.title, 160),
        date: clip(row?.date || row?.publishedAt, 20),
        snippet: clip(row?.snippet || row?.text || row?.content, 500)
      });
      if (fetchedSources.length >= MAX_SOURCES) break;
    }
    if (fetchedSources.length >= MAX_SOURCES) break;
  }

  // Step 3: Strong model single-shot synthesis
  let synthRaw = null;
  if (fetchedSources.length > 0) {
    try {
      const rawText = await ask(
        buildSynthPrompt(lang, defaultViz, cardKind),
        JSON.stringify({
          today,
          uiLang: lang,
          cardKind,
          defaultViz,
          claim: clip(claim, 400),
          sources: fetchedSources
        }),
        { kind: 'think', purpose: 'opus-fast-synth', sessionId, tools: false, json: true, maxTokens: 900, timeoutMs: Math.min(15000, remaining()), signal }
      );
      synthRaw = parseJsonLoose(rawText);
    } catch {}
  }

  const card = validateFastCard(synthRaw || {}, fetchedSources, {
    cardKind,
    uiLang: lang,
    fallbackTitle: clip(claim, 40)
  });

  if (card.evidence.length > 0) {
    writeCache(dataDir, cKey, card, now());
  }

  return { ...card, cached: false, elapsedMs: Math.max(0, now() - startedAt) };
}

module.exports = {
  CACHE_TTL_MS,
  FAST_BUDGET_MS,
  MAX_SOURCES,
  VERDICTS,
  VIZ_TYPES,
  isUuidLike,
  hostnameOf,
  rootDomainOf,
  sanitizeSourceName,
  resolveUiLang,
  normCardKind,
  defaultVizForCardKind,
  peakVersusCommercialAverage,
  independentDomainCount,
  validateViz,
  enforceCharBudget,
  validateFastCard,
  runFastCheck
};
