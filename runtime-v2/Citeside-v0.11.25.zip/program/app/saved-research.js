'use strict';
// Existing live-report snapshots only. No provider, session loading or writes.
const fs=require('node:fs'),path=require('node:path');
const clip=(s,n)=>String(s==null?'':s).replace(/\s+/g,' ').trim().slice(0,n);
const sidOk=v=>typeof v==='string'&&/^[A-Za-z0-9_.-]{1,80}$/.test(v)&&v!=='.'&&v!=='..';
const fail=(status,code,message)=>Object.assign(Error(message),{status,code});
function sourcesOf(rows){const seen=new Set(),out=[];for(const row of rows)for(const source of Array.isArray(row.sources)?row.sources:[]){const key=JSON.stringify(source);if(!seen.has(key)){seen.add(key);out.push(source);}}return out;}
function researchOf(report){
 const named=Array.isArray(report.researchResults)?report.researchResults.filter(r=>r&&String(r.text||'').trim()):[];
 if(named.length)return named.map((r,index)=>({id:String(r.id||'research-'+index).slice(0,80),title:clip(r.title||String(r.text).split('\n')[0],80),at:r.updatedAt||r.at||'',text:String(r.text),sources:sourcesOf([r])})).filter(r=>r.title);
 const groups=new Map();for(const [index,item]of (Array.isArray(report.items)?report.items:[]).entries()){
  if(!item||item.action||item.topic!=='外部研究'||!String(item.text||'').trim())continue;
  // Group by the full saved card identity. A legacy 80-character list-id
  // collision must be ambiguous at read time, never silently merge reports.
  const key=String(item.card||item.id||'research-'+index);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item);
 }
 return [...groups].map(([key,rows])=>({id:key.slice(0,80),title:clip(rows[0].title||String(rows[0].text).split('\n')[0],80),at:rows[0].at||'',text:rows.map(r=>String(r.text)).join('\n\n'),sources:sourcesOf(rows)})).filter(r=>r.title);
}
function snapshot(dataDir,sessionId){
 if(!sidOk(sessionId))throw fail(400,'saved_research_invalid_id','无效会议编号');
 let fd;
 try{
  const root=fs.realpathSync(dataDir),dir=path.join(root,'live-reports'),file=path.join(dir,sessionId+'.json');
  if(fs.lstatSync(dir).isSymbolicLink()||!fs.statSync(dir).isDirectory()||fs.realpathSync(dir)!==dir)throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  const entry=fs.lstatSync(file);if(entry.isSymbolicLink()||!entry.isFile())throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);if(!fs.fstatSync(fd).isFile())throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  let report;try{report=JSON.parse(fs.readFileSync(fd,'utf8'));}catch{throw fail(500,'saved_research_invalid_snapshot','已保存研究文件无法读取');}
  if(!report||typeof report!=='object'||Array.isArray(report))throw fail(500,'saved_research_invalid_snapshot','已保存研究文件格式无效');return report;
 }catch(e){if(e.status)throw e;if(e.code==='ENOENT')throw fail(404,'saved_research_not_found','没有这份已保存研究');if(e.code==='ELOOP')throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');throw fail(500,'saved_research_read_failed','已保存研究文件无法读取');}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}
function readLiveResearchSnapshot(dataDir,sessionId){
 if(!sidOk(sessionId))throw fail(400,'saved_research_invalid_id','无效会议编号');
 let fd;
 try{
  const root=fs.realpathSync(dataDir),dir=path.join(root,'live-research'),file=path.join(dir,sessionId+'.json');
  if(fs.lstatSync(dir).isSymbolicLink()||!fs.statSync(dir).isDirectory()||fs.realpathSync(dir)!==dir)throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  const entry=fs.lstatSync(file);if(entry.isSymbolicLink()||!entry.isFile())throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);if(!fs.fstatSync(fd).isFile())throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  let lr;try{lr=JSON.parse(fs.readFileSync(fd,'utf8'));}catch{throw fail(500,'saved_research_invalid_snapshot','已保存研究文件无法读取');}
  if(!lr||typeof lr!=='object'||Array.isArray(lr))throw fail(500,'saved_research_invalid_snapshot','已保存研究文件格式无效');return lr;
 }catch(e){if(e.status)throw e;if(e.code==='ENOENT')throw fail(404,'saved_research_not_found','没有这份已保存研究');if(e.code==='ELOOP')throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');throw fail(500,'saved_research_read_failed','已保存研究文件无法读取');}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}
function liveResearchMarkdown(item){
 const parts=[];
 if(item.title)parts.push('# '+String(item.title).trim());
 if(item.conclusion)parts.push(String(item.conclusion).trim());
 for(const sub of Array.isArray(item.subs)?item.subs:[]){
  if(!sub?.section)continue;
  const secParts=[];
  if(sub.q)secParts.push('## '+String(sub.q).trim());
  if(sub.section.answer)secParts.push(String(sub.section.answer).trim());
  const cols=Array.isArray(sub.section.columns)?sub.section.columns:[],rows=Array.isArray(sub.section.rows)?sub.section.rows:[];
  if(cols.length&&rows.length){
   secParts.push('| '+cols.map(c=>String(c||'').replace(/\|/g,'\\|')).join(' | ')+' |\n| '+cols.map(()=>'---').join(' | ')+' |\n'+rows.map(r=>'| '+(Array.isArray(r.cells)?r.cells:[]).map(c=>String(c||'').replace(/\|/g,'\\|')).join(' | ')+' |').join('\n'));
  }
  if(secParts.length)parts.push(secParts.join('\n\n'));
 }
 for(const fu of Array.isArray(item.followups)?item.followups:[]){
  if(fu?.state==='done'&&fu.section){
   parts.push('## '+String(fu.title||'追问').trim()+'\n\n'+String(fu.section.answer||'').trim());
  }
 }
 // Stopped before any section finished: only the title is present — say so and list the planned questions.
 if(parts.length===1&&item.title){
  parts.push('> 研究已暂停，可点击「继续」恢复。');
  for(const sub of Array.isArray(item.subs)?item.subs:[])if(sub?.q)parts.push('- '+String(sub.q).trim());
 }
 return parts.filter(Boolean).join('\n\n');
}
function read({dataDir='',sessionId='',outputId=''}={}){
 if(!sidOk(sessionId)||!String(outputId))throw fail(400,'saved_research_invalid_id','缺少有效的会议或研究编号');
 const outId=String(outputId);
 if(outId.startsWith('lr:'+sessionId+':')){
  const lr=readLiveResearchSnapshot(dataDir,sessionId);
  const matches=(Array.isArray(lr.items)?lr.items:[]).filter(r=>r&&(['done','stopped','partial'].includes(r.state)||!!r.pause)&&r.id&&'lr:'+sessionId+':'+String(r.id).slice(0,80)===outId);
  if(!matches.length)throw fail(404,'saved_research_not_found','没有这份已保存研究');
  if(matches.length!==1)throw fail(409,'saved_research_ambiguous','研究编号对应多份已保存报告，无法确定目标');
  const row=matches[0],ts=row.completedAt||row.deepStartedAt||row.openedAt;
  const at=typeof ts==='number'&&Number.isFinite(ts)?new Date(ts).toISOString():(typeof ts==='string'?ts:(lr.updatedAt||''));
  return {id:outId,sessionId,kind:'research',title:clip(row.title||row.conclusion||'',80),text:liveResearchMarkdown(row),sources:Array.isArray(row.sources)?row.sources:[],at,state:(row.state==='stopped'||row.pause)?'stopped':row.state,itemId:String(row.id)};
 }
 if(!outId.startsWith('research:'+sessionId+':'))throw fail(404,'saved_research_not_found','没有这份已保存研究');
 const saved=snapshot(dataDir,sessionId),matches=researchOf(saved).filter(r=>'research:'+sessionId+':'+r.id===outId);
 if(!matches.length)throw fail(404,'saved_research_not_found','没有这份已保存研究');if(matches.length!==1)throw fail(409,'saved_research_ambiguous','研究编号对应多份已保存报告，无法确定目标');
 const row=matches[0];return {id:outId,sessionId,kind:'research',title:row.title,text:row.text,sources:row.sources,at:row.at||saved.updatedAt||''};
}
module.exports={researchOf,snapshot,read,sidOk};
