/* Shared App-only account forms. Field validators are the vendored Better Auth UI MIT exports. */
(function(root){
 'use strict';
 function mount({host,prefix='account-auth-',text:T,render,request,onSignedIn,onCancel,callback,googleUrl='',openExternal=url=>root.open(url,'_blank','noopener,noreferrer'),primaryClass='btn',secondaryClass='btn2',fieldClass='field',fieldWrap=false,primaryIcon=''}){
  const V=root.CitesideAuthValidation;if(!V)throw Error('auth_validation_unavailable');
  const doc=host.ownerDocument||root.document,escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let revision=0,busy=false,disposed=false,state='login',email='',external=false;
  const id=name=>prefix+name,get=name=>doc.getElementById(id(name)),clearPasswords=()=>host.querySelectorAll('input[type="password"]').forEach(input=>input.value='');
  const button=(label,name,{submit=false,secondary=false,link=false}={})=>`<button type="${submit?'submit':'button'}" class="${link?'lnk':secondary?secondaryClass:primaryClass}" id="${id(name)}">${label}${!link&&!secondary?primaryIcon:''}</button>`;
  const field=(name,label,type,autocomplete,placeholder)=>{const labelHtml=`<label class="sub" for="${id(name)}">${label}</label>`,input=`<input class="${fieldWrap?'':fieldClass}" id="${id(name)}" type="${type}" autocomplete="${autocomplete}" required maxlength="${name==='email'?254:128}" placeholder="${placeholder}"${name==='email'?` value="${escape(email)}"`:''}>`;return fieldWrap?`<div class="field">${labelHtml}${input}</div>`:labelHtml+input;};
  const on=(name,fn)=>{const node=get(name);if(node)node.onclick=fn;};
  function errorText(code){const messages=({invalid_credentials:T('邮箱或密码不正确','Email or password is incorrect'),invalid_email:T('请输入有效邮箱','Enter a valid email'),invalid_password:T('密码至少 10 位，不能超过 128 位','Use a password between 10 and 128 characters'),account_exists:T('这个邮箱已经注册，请直接登录','This email is already registered. Sign in instead.'),invalid_callback:T('请在本机 App 中注册，以接收邮箱确认后的回调','Register in the local app so email confirmation can return here'),mail_unavailable:T('验证邮件暂时无法发送，请稍后再试','The email could not be sent. Please try again later'),rate_limited:T('操作太频繁，请稍后再试','Too many attempts. Please try again later'),offline:T('账号服务暂时连不上，请重试','The account service is temporarily unavailable. Please retry')});return Object.hasOwn(messages,code)?messages[code]:T('暂时无法完成，请重试','Unable to complete this now. Please retry');}
  function message(value){const node=get('message');if(node)node.textContent=value;}
  function rememberEmail(){const node=get('email');if(node)email=node.value.trim();}
  function go(next){rememberEmail();clearPasswords();revision++;busy=false;state=next;external=false;draw();}
  function draw(){
   if(disposed)return;
   const isLogin=state==='login',isSignup=state==='signup',isForgot=state==='forgot';let title,body;
   if(isLogin||isSignup||isForgot){
    title=isLogin?T('登录 Citeside','Sign in to Citeside'):isSignup?T('创建账号','Create your account'):T('找回密码','Reset your password');
    body=isSignup?`<p class="lead">${T('在 App 内设置邮箱和密码，再到邮箱确认。','Set your email and password in the app, then confirm your email.')}</p>`:isForgot?`<p class="lead">${T('输入注册邮箱，我们会发给你重置密码的安全链接。','Enter your registered email. We will send a secure password-reset link.')}</p>`:'';
    body+=`<form class="account-auth-form" id="${id('form')}" novalidate>`+field('email',T('邮箱','Email'),'email','username','you@company.com');
    if(!isForgot)body+=field('password',isSignup?T('设置密码','Set a password'):T('密码','Password'),'password',isSignup?'new-password':'current-password',isSignup?T('至少 10 位','At least 10 characters'):T('输入密码','Enter your password'));
    body+=button(isLogin?T('登录','Sign in'):isSignup?T('创建账号','Create account'):T('发送重置邮件','Send reset email'),'submit',{submit:true})+'</form>';
    if(isLogin){body+=`<div id="${id('google-slot')}"></div>`;body+=button(T('忘记密码','Forgot password'),'forgot',{link:true})+button(T('创建账号','Create account'),'signup',{link:true})+button(T('取消','Cancel'),'cancel',{link:true});}
    else body+=button(isSignup?T('已有账号，登录','Already have an account? Sign in'):T('返回登录','Back to sign in'),'login',{link:true});
   }else{
    title=state==='sent'?T('请确认邮箱','Confirm your email'):T('检查重置邮件','Check your reset email');
    body=`<p class="lead">${state==='sent'?T('验证邮件已发送。点击邮件里的链接，确认这是你的邮箱。','Verification email sent. Follow the link to confirm your email.'):T('如果这个邮箱已注册，重置链接已发出。通过邮件中的安全页面设置新密码后，回到 App 登录。','If this email is registered, a reset link has been sent. Set your password on the secure email page, then return to the app.')}</p>`;
    if(state==='sent')body+=`<p class="foot">${T('确认后回到 Citeside，权益继续记在同一账号。','Return to Citeside after confirmation. Your membership stays with the same account.')}</p>`;
    body+=button(T('返回登录','Back to sign in'),'login',{link:true});
   }
   render(title,body+`<p id="${id('message')}" class="service-message" role="status" aria-live="polite"></p>`);
   on('login',()=>go('login'));on('signup',()=>go('signup'));on('forgot',()=>go('forgot'));on('cancel',()=>{dispose();onCancel?.();});
   setGoogleUrl(googleUrl);
   const form=get('form');if(form){form.oninput=()=>{message('');host.querySelectorAll('[aria-invalid]').forEach(el=>el.removeAttribute('aria-invalid'));};form.onsubmit=submit;}
  }
  async function submit(event){
   event.preventDefault();if(busy||disposed)return;message('');const emailInput=get('email'),passwordInput=get('password');
   let error=V.validateEmailAddress(emailInput.value,{requiredMessage:T('请输入邮箱','Enter your email'),invalidMessage:T('请输入有效邮箱','Enter a valid email')});
   let invalid=emailInput;
   if(!error&&passwordInput){invalid=passwordInput;error=V.validateStringLength(passwordInput.value,{requiredMessage:T('请输入密码','Enter your password'),minLength:state==='signup'?10:1,minLengthMessage:T('密码至少 10 位','Use at least 10 characters'),maxLength:128,maxLengthMessage:T('密码不能超过 128 位','Use no more than 128 characters'),trim:false});}
   if(error){invalid.setAttribute('aria-invalid','true');invalid.focus();message(error.message);return;}
   if(state==='signup'&&(!Number.isInteger(callback.port)||callback.port<1024||callback.port>65535)){message(errorText('invalid_callback'));return;}
   email=emailInput.value.trim();const action=state,payload={email,...(passwordInput?{password:passwordInput.value}:{}),...(action!=='login'?{lang:callback.lang}:{}),...(action==='signup'?{from:'app',port:callback.port}:{})};
   if(passwordInput)passwordInput.value='';const token=revision;busy=true;host.querySelectorAll('input,button').forEach(el=>el.disabled=true);const submitButton=get('submit');submitButton.textContent=T('处理中…','Working…');
   try{
    const result=await request(action==='login'?'/account/login/password':action==='signup'?'/account/register':'/account/password/forgot',payload);
    if(disposed||token!==revision)return;
    if(!result?.ok)throw {code:result?.code||result?.status};
    if(action==='login'){if(result.status!=='signed_in'||!result.email)throw {code:'unconfirmed'};dispose();await onSignedIn(result);}
    else if(action==='signup'){if(result.status==='cooldown'){message(T('请稍后再发送验证邮件','Wait before sending another verification email'));return;}if(result.status!=='verification_sent')throw {code:'unconfirmed'};go('sent');}
    else if(result.status==='cooldown')message(T('请稍后再发送重置邮件','Wait before sending another reset email'));
    else{if(result.status!=='reset_requested')throw {code:'unconfirmed'};go('reset-sent');}
   }catch(error){if(!disposed&&token===revision)message(errorText(error?.code));}
   finally{delete payload.password;if(!disposed&&token===revision){busy=false;host.querySelectorAll('input,button').forEach(el=>el.disabled=false);submitButton.textContent=action==='login'?T('登录','Sign in'):action==='signup'?T('创建账号','Create account'):T('发送重置邮件','Send reset email');}}
  }
  function setGoogleUrl(url){googleUrl=url;const slot=get('google-slot');if(disposed||state!=='login'||!slot)return;slot.innerHTML=url?button(T('使用 Google 登录','Sign in with Google'),'google',{secondary:true}):'';const node=get('google');if(node){node.disabled=busy;node.onclick=()=>{if(busy||disposed)return;rememberEmail();clearPasswords();external=true;openExternal(googleUrl);message(T('在系统浏览器完成 Google 授权后返回 Citeside。','Finish Google authorization in your system browser, then return to Citeside.'));};}}
  function dispose(){clearPasswords();revision++;busy=false;disposed=true;external=false;}
  draw();return {dispose,setGoogleUrl,get busy(){return busy;},get waitingForExternal(){return state==='sent'||external;}};
 }
 function googleUrl(base,location,lang){try{const port=Number(location.port),u=new URL(base);if(!['localhost','127.0.0.1','[::1]'].includes(location.hostname)||!Number.isInteger(port)||port<1024||port>65535||u.username||u.password||u.search||u.hash||(u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname))))return '';const url=new URL('/v1/auth/google/start',u);url.search=new URLSearchParams({from:'app',port:String(port),lang}).toString();return url.href;}catch{return '';}}
 root.CitesideAccountAuth={mount,googleUrl};
})(typeof window==='object'?window:globalThis);
