'use strict';
// 首次引导（真 app 版）。界面、文案、交互逐条照搬原型
// docs/design/approved/onboarding-v5.html；真实接口与恢复边界见 docs/handoffs/2026-11-04-onboarding-natural-flow.md；
// 原型里模拟的部分换成真接口：
//   权限 → GET /native/permissions（小助手上报）+ POST /native/permissions/request（弹系统框或开系统设置）
//   进度 → GET/POST /setup/onboarding（dataDir/onboarding.json，权限状态不存、实时读）
//   试听 → POST /native/trial/start|stop + GET /native/trial/state；后端没有这条路时走需求单的失败文案
// 走完或「稍后再说」都回首页 index.html，首页的引导气泡 / 继续设置条读 THT_BOOT.onboarding。
(function(){
const LANG=String(window.liveMateSystemLanguage||((navigator.languages||[navigator.language]).some(l=>/^zh/i.test(l||''))?'zh':'en'))==='en'?'en':'zh';
document.documentElement.lang=LANG==='en'?'en':'zh-CN';
const T={
zh:{
  c_t:'先看看你今天有哪些会',c_l:'连接 Google 日历后，Citeside能提前知道会议主题和参会人。',
  c_n:'<b>只读取日程，不会修改。</b>随时可以断开。',
  c_go:'连接 Google 日历',c_skip:'跳过，之后再连',c_ok_t:'已连接日历',c_today:'今天的会',c_go2:'继续',
  c_bl_t:'这个账号还不能用',c_bl_n:'试用版只开放给名单里的账号。把这个邮箱发给邀请你的人，或者换一个账号。',c_other:'换一个账号',
  g_wait_t:'在浏览器里完成授权',g_wait_l:'浏览器已打开 Google 授权页。',g_wait_w:'完成后自动回到这里',g_c:['选账号','高级','继续','允许'],g_cancel:'取消',g_again:'没看到页面？重新打开',
  title:'Citeside',later:'稍后再说',back:'返回',next:'继续',
  w_t:'开会时，它帮你记',w_l:'把会上每句话变成文字，并提醒你该跟进的事。',
  w_s:{cal:'连接日历',mic:'允许听到你的声音',sys:'允许听到线上会的声音',trial:'说几句试试',ai:'让你的 AI 介绍一下你'},w_go:'开始',w_time:'大约 2 分钟',
  ai_t:'让你的 AI 介绍一下你',ai_l:'把这段话发给你常用的 ChatGPT 或 Claude，再把它的回答贴到下面。开会时Citeside会按这些背景给提示。',
  ai_prompt:'根据你对我的记忆，只写你确定的，不确定的不写、不要编。按这个格式：\n身份：\n项目：（每行「项目名：一句话，到哪一步」）\n常用文档：（每行「名称：链接」）\n我常开的会：（每行「会名：我的角色」）\n最近在意的事：',
  ai_copy:'复制',ai_copied:'已复制',ai_ph:'把 AI 的回答贴在这里',ai_save:'读一下',ai_more:'再贴一段',ai_read:'我读了什么',ai_del:'删除',
  ai_none:'没读出内容。回答里要有「身份：」「项目：」这样的标题。',ai_fail:'没存上，再试一次',ai_skip:'跳过',
  ai_n:'保存在这台 Mac 上。开会用到时才发给 AI。下面每一条都能删。',ai_k:{identity:'身份',project:'项目',doc:'常用文档',meeting:'我常开的会',focus:'最近在意的事'},
  m_t:'让Citeside听到你',m_l:'当面开会时，用麦克风记下现场说的话。',
  m_n:'<b>只在你点「开始记录」后使用</b>，结束就停。转写和 AI 按设置使用；自己的服务与云试用分别设置，登录不会自动切换。云试用需登录、确认邮箱并兑换 20 小时。记录保存在这台电脑和你开启同步的 Notion。',
  m_go:'允许使用麦克风',
  m_den_t:'麦克风还没打开',m_den_n:'打开系统设置，在<b>「隐私与安全性 › 麦克风」</b>里打开「Citeside」。改完回到这里，会自动继续。',
  open_set:'打开系统设置',waiting:'等你在系统设置里打开…回来后自动继续',
  s_t:'也听到线上会的对方',s_l:'用飞书、腾讯会议、Zoom 开会时，录下对方说的话。',
  s_n:'macOS 会把这一项叫<b>「屏幕与系统录音」</b>。Citeside只录声音，不录屏幕；同样只在你开始记录时使用。',
  s_go:'允许录制系统声音',s_skip:'先跳过，只录当面会',
  s_den_t:'系统声音还没打开',s_den_n:'打开系统设置，在<b>「隐私与安全性 › 屏幕与系统录音」</b>里打开「Citeside」。也可以先跳过，之后在设置里再开。',
  allowed:'已允许',
  t_t:'说几句试试',t_l:'随便说点什么，比如今天要开的会。Citeside会当场写下来。',t_go:'开始试听',t_skip:'跳过试听',
  t_listen:'正在听',t_stop:'停',t_ph:'说话吧，文字会出现在这里',
  t_done_t:'就是这样',t_done_l:'开会时，左边是逐字稿，右边会冒出这样的提示。',t_done_nocard:'开会时，右边会冒出要跟进的提示',t_fin:'完成',t_again:'再试一次',
  t_quiet:'没听到声音，靠近一点或检查输入设备',t_slow:'网络有点慢，已自动重试',t_fail:'这次没连上，先跳过，开会时会自动重连',
  card_lab:'会前准备',
  t_sf_t:'试听还没停下来',t_sf_n:'停止请求没有成功，麦克风可能还在听。点「再停一次」重试，停下后才会离开这一页。',t_sf_go:'再停一次',
  save_fail:'进度没保存上，下次打开可能要从这一步重来。',save_retry:'重试保存',save_leave:'不保存，直接离开'
},
en:{
  c_t:'See what’s on today',c_l:'Connect Google Calendar so Citeside knows each meeting’s topic and people ahead of time.',
  c_n:'<b>Read-only.</b> Disconnect anytime.',
  c_go:'Connect Google Calendar',c_skip:'Skip for now',c_ok_t:'Calendar connected',c_today:'Today',c_go2:'Continue',
  c_bl_t:'This account isn’t on the list yet',c_bl_n:'The beta is limited to invited accounts. Send this email to whoever invited you, or use another account.',c_other:'Use another account',
  g_wait_t:'Finish in your browser',g_wait_l:'Google’s sign-in page is open in your browser.',g_wait_w:'We’ll continue automatically when you’re done',g_c:['Choose account','Advanced','Continue','Allow'],g_cancel:'Cancel',g_again:'Don’t see it? Open again',
  title:'Citeside',later:'Not now',back:'Back',next:'Continue',
  w_t:'Your notes, while you meet',w_l:'Citeside turns every word into text and flags what to follow up on.',
  w_s:{cal:'Connect your calendar',mic:'Let it hear you',sys:'Let it hear online calls',trial:'Try a few words',ai:'Let your AI introduce you'},w_go:'Get started',w_time:'About 2 minutes',
  ai_t:'Let your AI introduce you',ai_l:'Send this to the ChatGPT or Claude you use, then paste its answer below. In meetings, tips will use this background.',
  ai_prompt:"From what you remember about me, write only what you are sure of. Leave out anything you are unsure of, and do not make things up. Use this format:\nIdentity:\nProjects: (one per line, \"name: one sentence, where it stands\")\nDocs: (one per line, \"name: link\")\nMeetings: (one per line, \"meeting: my role\")\nFocus:",
  ai_copy:'Copy',ai_copied:'Copied',ai_ph:'Paste the answer here',ai_save:'Read it',ai_more:'Paste more',ai_read:'What I read',ai_del:'Delete',
  ai_none:'Nothing read. The answer needs headings like “Identity:” and “Projects:”.',ai_fail:'Not saved. Try again.',ai_skip:'Skip',
  ai_n:'Saved only on this Mac. Sent to the AI only when it helps with your meetings. Every item below can be deleted.',ai_k:{identity:'Identity',project:'Projects',doc:'Docs',meeting:'Meetings',focus:'Focus'},
  m_t:'Let Citeside hear you',m_l:'For in-person meetings, the microphone captures what’s said in the room.',
  m_n:'<b>Only used after you press “Start”</b>, and stops when you finish. Speech and AI use your settings. Your own services and the cloud trial are configured separately; signing in does not switch services. Cloud trial needs sign-in, email confirmation and a 20-hour code. Notes are saved on this Mac.',
  m_go:'Allow microphone',
  m_den_t:'Microphone is off',m_den_n:'Open System Settings and turn on Citeside under <b>Privacy & Security › Microphone</b>. Come back and we’ll continue.',
  open_set:'Open System Settings',waiting:'Waiting for System Settings… we’ll continue automatically',
  s_t:'Hear the other side of online calls',s_l:'On Zoom, Lark or Tencent Meeting, capture what others say.',
  s_n:'macOS calls this <b>“Screen & System Audio Recording”</b>. Citeside records audio only, never your screen, and only while you’re recording.',
  s_go:'Allow system audio',s_skip:'Skip, in-person only',
  s_den_t:'System audio is off',s_den_n:'Open System Settings and turn on Citeside under <b>Privacy & Security › Screen & System Audio Recording</b>. Or skip and turn it on later.',
  allowed:'Allowed',
  t_t:'Say a few words',t_l:'Anything works, like a meeting you have today. It writes it down as you talk.',t_go:'Start',t_skip:'Skip',
  t_listen:'Listening',t_stop:'Stop',t_ph:'Start talking — text appears here',
  t_done_t:'That’s it',t_done_l:'In a meeting, the transcript runs on the left and tips like this pop up on the right.',t_done_nocard:'In a meeting, tips on what to follow up pop up on the right.',t_fin:'Done',t_again:'Try again',
  t_quiet:'Can’t hear you. Move closer or check your input device.',t_slow:'The network is slow. Retrying…',t_fail:'Couldn’t connect this time. Skip for now — it reconnects when you meet.',
  card_lab:'Before the meeting',
  t_sf_t:'The trial hasn’t stopped',t_sf_n:'The stop request failed, so the microphone may still be listening. Press “Stop again”; this page stays open until it stops.',t_sf_go:'Stop again',
  save_fail:'Your progress wasn’t saved. Next time you may start from this step again.',save_retry:'Retry',save_leave:'Leave without saving'
}}[LANG];
document.title=T.title;

const IC={
  calbig:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="5" y="7" width="22" height="20" rx="4"/><path d="M5 13h22M11 4v6M21 4v6"/></svg>',
  back:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3 5 8l5 5"/></svg>',
  logo:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 13v6M11 9v14M16 5v22M21 10v12M26 14v4"/></svg>',
  mic:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="11" y="4" width="10" height="16" rx="5"/><path d="M6.5 15a9.5 9.5 0 0 0 19 0M16 24.5V28"/></svg>',
  sys:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="6" width="25" height="16" rx="3"/><path d="M11 27h10M16 22v5"/><path d="M12 12v4M16 10v8M20 12v4"/></svg>',
  talk:'<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8.5A3.5 3.5 0 0 1 8.5 5h15A3.5 3.5 0 0 1 27 8.5v10a3.5 3.5 0 0 1-3.5 3.5H14l-6 5v-5h0A3.5 3.5 0 0 1 5 18.5z"/><path d="M11 12h10M11 16h6"/></svg>',
  check:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3.5 8.5 3 3 6-7"/></svg>',
  excl:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 4v5M8 12v.01"/></svg>',
  lock:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="7" width="9" height="6.5" rx="1.5"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/></svg>',
  info:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 7v4M8 5v.01"/></svg>',
  x:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="m4.5 4.5 7 7M11.5 4.5l-7 7"/></svg>',
  spark:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M8 1.5 9.4 6.6 14.5 8 9.4 9.4 8 14.5 6.6 9.4 1.5 8 6.6 6.6z"/></svg>'
};

const STEPS=['welcome','cal','mic','sys','trial','ai','done'],DONE=STEPS.indexOf('done'),AI=STEPS.indexOf('ai');
const KIND={mic:'microphone',sys:'screen'};
const boot=window.THT_BOOT||{};
const saved=boot.onboarding||{};
const directIntro=new URLSearchParams(location.search||'').get('step')==='ai';
// 旧快捷方式/恢复的标签页不能把已完成用户再次送入引导；设置中的 AI 回访保留。
if(saved.finished===true&&!directIntro){location.replace('index.html');return;}
// 权限状态只来自系统（/native/permissions），本地只记 sys 跳过与否、在第几步
const S={step:directIntro?AI:Number.isInteger(saved.step)?Math.min(saved.step,AI):0,cal:'idle',calConfigured:true,calEmail:'',calEvents:[],calEventsLoaded:false,mic:'idle',sys:saved.sys==='skipped'?'skipped':'idle',
  ask:{mic:false,sys:false},trial:'idle',lines:[],card:null,trialMsg:'',trialDone:saved.trialDone===true,known:false,
  ai:{items:[],text:'',msg:'',copied:false,loaded:false,busy:false}};
const app=document.getElementById('app');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let timers=[],meterIv=null,trialIv=null,leaving=false;
const clearT=()=>{timers.forEach(clearTimeout);timers=[];if(meterIv){clearInterval(meterIv);meterIv=null}};

// 复审 ONB-03：进度写入只认 2xx 回执；失败把这次的改动攒着，页面上明说「没保存」并给重试，不假装存好了。
let unsaved=null,saveFail=null;
async function persist(patch){
  if(directIntro)return true;
  const body={...(unsaved||{}),...patch};
  let ok=false;
  try{const r=await fetch('/setup/onboarding',{method:'POST',headers:{'content-type':'application/json','x-tht-token':boot.relayToken||''},body:JSON.stringify(body)});ok=r.ok;}catch(e){}
  unsaved=ok?null:body;return ok;
}
// 复审 ONB-01：试听一旦发出 start（哪怕回执还没到），离开前都要收到 stop 的 2xx 回执；轮询停掉不等于录音停掉。
// 复审 ONB-02：stop 的 2xx 只代表「命令收到」；要等 state==='done'（小窗 end + 文件清理都完成）才算停下。
// stopping 就每 500ms 读一次 /native/trial/state，最多等 STOP_POLLS 次；failed / 超时 / 网络错都按没停下处理，交给「再停一次」。
let trialLive=false,startP=null,stopP=null,pendingBack=null;
const STOP_POLLS=30,sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function trialState(){try{const r=await fetch('/native/trial/state',{cache:'no-store'});return r.ok?await r.json():null;}catch(e){return null}}
async function stopOnce(){
  // start 还在路上就先等它落地，免得 stop 先到、start 后到又把试听拉起来
  if(startP)await startP.catch(()=>{});
  let j=null;
  try{const r=await fetch('/native/trial/stop',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});const b=await r.json().catch(()=>({}));j=r.ok&&b.ok!==false?b:null;}catch(e){}
  for(let i=0;j&&j.state!=='done'&&j.state!=='failed'&&i<STOP_POLLS;i++){await sleep(500);j=await trialState()||j;}
  const ok=!!j&&j.state==='done';
  if(ok){trialLive=false;if(Array.isArray(j.lines)&&j.lines.length)S.lines=j.lines.map(String);if(j.card&&!S.card)S.card=j.card;}
  return ok;
}
// 同时只跑一份：连点「停」/ 离开 + 停 不会叠出多个 stop
function stopRemote(){return stopP||(stopP=stopOnce().finally(()=>{stopP=null}));}
// 统一退出：停轮询 → 停试听（等回执，失败就留在页上给重试）→ 存进度（失败给重试或明确不保存离开）→ 回首页
async function leave(patch,{force=false}={}){
  if(leaving)return;leaving=true;pendingBack=null;stopCalendar();stopTrial();
  if(trialLive&&!await stopRemote()){leaving=false;S.step=STEPS.indexOf('trial');S.trial='stopfail';S.pendingLeave=patch;render();return;}
  if(!await persist(patch)&&!force){leaving=false;saveFail={patch,leave:true};render();return;}
  location.replace('index.html');
}

// ---------- 渲染（结构与原型同） ----------
const visibleSteps=()=>STEPS.filter(k=>k!=='cal'||S.calConfigured);
function dots(){const visible=visibleSteps(),index=visible.indexOf(STEPS[S.step]);return `<div class="dots" aria-label="${index+1} / ${visible.length}">${visible.map((_,i)=>`<i class="${i===index?'on':i<index?'done':''}"></i>`).join('')}</div>`}
function shell(inner){
  const back=!directIntro&&S.step>0&&S.step<DONE?`<button class="ib" data-act="back" aria-label="${T.back}">${IC.back}${T.back}</button>`:'<span></span>';
  const later=S.step<DONE?`<button class="ib" data-act="later">${T.later}</button>`:'<span></span>';
  return `<div class="stage"><section class="win" role="dialog" aria-modal="true" aria-labelledby="h"><div class="whead"><span class="l">${back}</span>${dots()}<span class="r">${later}</span></div><div class="wbody">${saveFail?saveNote():''}${inner}</div></section></div>`;
}
const saveNote=()=>`<div class="note warn" role="alert">${IC.info}<span>${T.save_fail} <button class="btn link" data-act="retrysave">${T.save_retry}</button>${saveFail.leave?`<button class="btn link" data-act="leaveunsaved">${T.save_leave}</button>`:''}</span></div>`;
const hero=(ic,badge)=>`<div class="hero">${ic}${badge==='ok'?`<span class="badge ok">${IC.check}</span>`:badge==='no'?`<span class="badge no">${IC.excl}</span>`:''}</div>`;


let calIv=null,calEpoch=0,calBusy=false;
function stopCalendar(){calEpoch++;if(calIv){clearInterval(calIv);calIv=null;}}
const calendarHeaders=()=>({'content-type':'application/json','x-tht-token':boot.relayToken||''});
const calendarBlocked=j=>/access_denied|test_user|testing|org_internal|admin_policy_enforced/i.test(j.authError||j.error||'');
async function calendarStatus(){
  try{const r=await fetch('/google/calendar',{cache:'no-store',headers:calendarHeaders()});return r.ok?await r.json():null;}catch(e){return null;}
}
async function calendarEvents(epoch){
  S.calEventsLoaded=true;
  try{
    const r=await fetch('/meeting-board?calendar=1&refresh=authorization',{cache:'no-store',headers:calendarHeaders()});
    if(!r.ok)return;const j=await r.json();
    if(epoch!==calEpoch||j.error)return;
    const today=new Date().toDateString();
    S.calEvents=(Array.isArray(j.events)?j.events:[]).filter(e=>new Date(e.start).toDateString()===today).sort((a,b)=>new Date(a.start)-new Date(b.start));
    if(STEPS[S.step]==='cal')render();
  }catch(e){}
}
function applyCalendar(j){
  if(!j)return;
  S.calConfigured=j.configured!==false;S.calEmail=j.email||'';
  S.cal=j.pending?'waiting':calendarBlocked(j)?'blocked':j.connected?'granted':'idle';
}
function watchCalendar(){
  if(calIv)return;
  const epoch=calEpoch;let reading=false;
  calIv=setInterval(async()=>{
    if(reading||epoch!==calEpoch)return;reading=true;
    const j=await calendarStatus();reading=false;
    if(epoch!==calEpoch||STEPS[S.step]!=='cal'||!j)return;
    applyCalendar(j);
    if(!S.calConfigured){stopCalendar();go(S.step+1);return;}
    if(!j.pending){stopCalendar();if(S.cal==='granted')calendarEvents(calEpoch);}
    render();
  },2000);
}
async function calendarConnect(){
  if(calBusy)return;calBusy=true;stopCalendar();const epoch=calEpoch;
  S.cal='waiting';S.calEvents=[];S.calEventsLoaded=false;render();
  try{
    const r=await fetch('/google/calendar/connect',{method:'POST',headers:calendarHeaders(),body:'{}'});
    const j=await r.json();
    if(epoch!==calEpoch)return;
    if(!r.ok||j.ok===false){S.cal=calendarBlocked(j)?'blocked':'idle';render();return;}
    watchCalendar();
  }catch(e){if(epoch===calEpoch){S.cal='idle';render();}}
  finally{calBusy=false;}
}
function calendarMeetings(){
  return S.calEvents.map(e=>`<div class="m"><time>${esc(new Date(e.start).toLocaleTimeString(LANG,{hour:'2-digit',minute:'2-digit',hour12:false}))}</time><b>${esc(e.title||'')}</b></div>`).join('');
}

function calStep(){
  if(S.cal==='granted')return hero(IC.calbig,'ok')+`<h1 id="h">${T.c_ok_t}</h1><span class="acct">${esc(S.calEmail)}</span><div class="mlist">${calendarMeetings()}</div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="next">${T.c_go2}</button></div>`;
  if(S.cal==='blocked')return hero(IC.calbig,'no')+`<h1 id="h">${T.c_bl_t}</h1><div class="note warn">${IC.info}<span>${T.c_bl_n}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="calgo">${T.c_other}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
  if(S.cal==='waiting')return hero(IC.calbig)+`<h1 id="h">${T.g_wait_t}</h1><p class="lead">${T.g_wait_l}</p><div class="gchain">${T.g_c.map((c,i)=>`${i?'<span>›</span>':''}<b>${c}</b>`).join('')}</div><span class="wait" style="margin-top:20px"><span class="spin"></span>${T.g_wait_w}</span><div class="spacer"></div><div class="acts"><button class="btn link" data-act="gagain">${T.g_again}</button><button class="btn ghost" data-act="calcancel">${T.g_cancel}</button></div>`;
  return hero(IC.calbig)+`<h1 id="h">${T.c_t}</h1><p class="lead">${T.c_l}</p><div class="note">${IC.lock}<span>${T.c_n}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="calgo">${T.c_go}</button><button class="btn link" data-act="calskip">${T.c_skip}</button></div>`;
}

function permStep(kind){
  const st=S[kind],ic=kind==='mic'?IC.mic:IC.sys,p=kind==='mic'?'m':'s';
  if(st==='denied'||st==='waiting'){
    return hero(ic,'no')+`<h1 id="h">${T[p+'_den_t']}</h1><div class="note warn">${IC.info}<span>${T[p+'_den_n']}</span></div><div class="spacer"></div><div class="acts">`+
      `<button class="btn lg pri" data-act="openset" data-k="${kind}">${T.open_set}</button>`+
      (st==='waiting'?`<span class="wait"><span class="spin"></span>${T.waiting}</span>`:'')+
      (kind==='sys'?`<button class="btn link" data-act="skipsys">${T.s_skip}</button>`:'')+`</div>`;
  }
  const granted=st==='granted';
  return hero(ic,granted?'ok':'')+`<h1 id="h">${T[p+'_t']}</h1><p class="lead">${T[p+'_l']}</p><div class="note">${IC.lock}<span>${T[p+'_n']}</span></div><div class="spacer"></div><div class="acts">`+
    (granted?`<span class="state" role="status">${IC.check}${T.allowed}</span><button class="btn lg pri" data-act="next">${T.next}</button>`
      :`<button class="btn lg pri" data-act="ask" data-k="${kind}">${T[p+'_go']}</button>`+
       (kind==='sys'?`<button class="btn link" data-act="skipsys">${T.s_skip}</button>`:''))+`</div>`;
}
const card=c=>`<div class="aicard"><div class="lab">${IC.spark}${esc(c.label||T.card_lab)}</div><h4>${esc(c.title||'')}</h4>${c.body?`<div class="bd">${esc(c.body)}</div>`:''}${c.source?`<div class="src">${esc(c.source)}</div>`:''}</div>`;
const lineHtml=()=>S.lines.map(l=>`<p>${esc(l)}</p>`).join('');
function trialStep(){
  const t=S.trial;
  if(t==='done'){
    return `<h1 id="h" style="margin-top:20px">${T.t_done_t}</h1><p class="lead">${S.card?T.t_done_l:T.t_done_nocard}</p><div class="trial"><div class="tx">${lineHtml()}</div>${S.card?card(S.card):''}</div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="finish">${T.t_fin}</button><button class="btn link" data-act="trialstart">${T.t_again}</button></div>`;
  }
  if(t==='stopfail'){
    return hero(IC.talk,'no')+`<h1 id="h">${T.t_sf_t}</h1><div class="note warn" role="alert">${IC.info}<span>${T.t_sf_n}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="retrystop">${T.t_sf_go}</button></div>`;
  }
  if(t==='failed'){
    return hero(IC.talk,'no')+`<h1 id="h">${T.t_t}</h1><div class="note warn">${IC.info}<span>${T.t_fail}</span></div><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="finish">${T.t_fin}</button></div>`;
  }
  if(t==='listening'){
    return `<h1 id="h" style="margin-top:20px">${T.t_t}</h1><div class="trial"><div class="meter"><span class="dot"></span><span>${T.t_listen}</span><span class="bars">${'<i></i>'.repeat(22)}</span><span class="t" id="cd">0:30</span></div><div class="tx" id="tx" aria-live="polite">${S.lines.length?lineHtml():`<span class="ph">${T.t_ph}</span>`}</div><div id="cardslot">${S.card?card(S.card):''}</div><p class="cap" id="tmsg"${S.trialMsg?'':' hidden'}>${esc(S.trialMsg)}</p></div><div class="spacer"></div><div class="acts"><button class="btn lg sec" data-act="trialstop">${T.t_stop}</button></div>`;
  }
  return hero(IC.talk)+`<h1 id="h">${T.t_t}</h1><p class="lead">${T.t_l}</p><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="trialstart">${T.t_go}</button><button class="btn link" data-act="trialskip">${T.t_skip}</button></div>`;
}
// 「连接你的 AI」：提示词交给用户自己的 ChatGPT / Claude，回答贴回来拆成条目存本机，「我读了什么」逐条可删
function aiRead(){
  const it=S.ai.items;if(!it.length)return '';
  const g=Object.keys(T.ai_k).map(k=>[k,it.filter(i=>i.kind===k)]).filter(x=>x[1].length);
  return `<div class="airead"><div class="lab">${T.ai_read}</div>${g.map(([k,xs])=>`<div class="grp"><span class="k">${T.ai_k[k]}</span><ul>${xs.map(i=>`<li><span>${esc(i.text)}</span><button class="x" data-act="aidel" data-id="${esc(i.id)}" aria-label="${T.ai_del}">${IC.x}</button></li>`).join('')}</ul></div>`).join('')}</div>`;
}
function aiStep(){
  const a=S.ai,has=a.items.length>0;
  return `<h1 id="h" style="margin-top:12px">${T.ai_t}</h1><p class="lead">${T.ai_l}</p>`+
    `<div class="aibox"><pre class="aiprompt" id="aiprompt">${esc(T.ai_prompt)}</pre><button class="btn sec" data-act="aicopy">${a.copied?T.ai_copied:T.ai_copy}</button></div>`+
    `<textarea class="aiin" id="aiin" rows="${has?3:5}" placeholder="${has?T.ai_more:T.ai_ph}">${esc(a.text)}</textarea>`+
    (a.msg?`<p class="cap" role="status">${esc(a.msg)}</p>`:'')+aiRead()+
    `<div class="note">${IC.lock}<span>${T.ai_n}</span></div><div class="spacer"></div><div class="acts">`+
    (has?`<button class="btn lg pri" data-act="next">${T.t_fin}</button>${a.text.trim()?`<button class="btn link" data-act="aisave"${a.busy?' disabled':''}>${T.ai_save}</button>`:''}`
       :`<button class="btn lg pri" data-act="aisave"${a.busy||!a.text.trim()?' disabled':''}>${T.ai_save}</button><button class="btn link" data-act="next">${T.ai_skip}</button>`)+`</div>`;
}
async function aiLoad(){
  S.ai.loaded=true;
  try{const r=await fetch('/setup/my-ai',{cache:'no-store',headers:{'x-tht-token':boot.relayToken||''}});if(r.ok){const j=await r.json();S.ai.items=Array.isArray(j.items)?j.items:[];if(STEPS[S.step]==='ai')render();}}catch(e){}
}
async function aiPost(body){
  if(S.ai.busy)return;S.ai.busy=true;S.ai.msg='';render();
  let j=null;
  try{const r=await fetch('/setup/my-ai',{method:'POST',headers:{'content-type':'application/json','x-tht-token':boot.relayToken||''},body:JSON.stringify(body)});j=r.ok?await r.json():null;}catch(e){}
  S.ai.busy=false;
  if(!j){S.ai.msg=T.ai_fail;render();return}
  S.ai.items=Array.isArray(j.items)?j.items:[];
  if('text' in body){if(j.added>0)S.ai.text='';else S.ai.msg=T.ai_none;}
  render();
}
function aiCopy(){
  const done=()=>{S.ai.copied=true;render();};
  const sel=()=>{const el=document.getElementById('aiprompt');if(!el)return;const rg=document.createRange();rg.selectNodeContents(el);const s=getSelection();s.removeAllRanges();s.addRange(rg);try{if(document.execCommand('copy'))done()}catch(e){}};
  try{navigator.clipboard.writeText(T.ai_prompt).then(done,sel)}catch(e){sel()}
}
function welcome(){
  return hero(IC.logo)+`<h1 id="h">${T.w_t}</h1><p class="lead">${T.w_l}</p><ol class="steplist">${visibleSteps().filter(k=>T.w_s[k]).map((step,i)=>`<li><span class="n">${i+1}</span>${T.w_s[step]}</li>`).join('')}</ol><div class="spacer"></div><div class="acts"><button class="btn lg pri" data-act="next">${T.w_go}</button><span class="cap" style="margin-top:4px">${T.w_time}</span></div>`;
}
function render(){
  clearT();
  const k=STEPS[S.step];
  app.innerHTML=shell(k==='welcome'?welcome():k==='cal'?calStep():k==='mic'?permStep('mic'):k==='sys'?permStep('sys'):k==='ai'?aiStep():trialStep());
  if(k==='cal'&&S.cal==='waiting'&&!calBusy)watchCalendar();
  if(k==='cal'&&S.cal==='granted'&&!S.calEventsLoaded)calendarEvents(calEpoch);
  if(k==='ai'&&!S.ai.loaded)aiLoad();
  if(k==='trial'&&S.trial==='listening')startMeter();
}

function go(n){
  stopCalendar();
  if(!S.calConfigured&&STEPS[n]==='cal')n+=n>S.step?1:-1;
  S.step=Math.max(0,Math.min(STEPS.length-1,n));
  if(STEPS[S.step]==='done')return leave({step:DONE,finished:true,trialDone:S.trialDone,sys:S.sys==='granted'?'granted':S.sys==='skipped'?'skipped':'idle'});
  const patch={step:S.step,sys:S.sys==='skipped'?'skipped':S.sys==='granted'?'granted':'idle'};
  persist(patch).then(ok=>{const was=!!saveFail;saveFail=ok?null:{patch};if(was!==!!saveFail)render();});
  render();
}

// ---------- 权限：实时读系统状态 ----------
const map=v=>v==='authorized'?'granted':v==='denied'||v==='restricted'?'denied':'idle';
async function readPerms(){
  try{const r=await fetch('/native/permissions',{cache:'no-store'});if(!r.ok)return null;return await r.json();}catch(e){return null}
}
function applyPerms(p,initial){
  if(!p)return;S.known=!!p.known;if(!p.known)return;
  let changed=false;
  for(const k of ['mic','sys']){
    const sysState=map(p[KIND[k]]);
    let next=S[k];
    if(sysState==='granted')next='granted';
    else if(k==='sys'&&S.sys==='skipped')next='skipped';
    else if(sysState==='denied')next=S[k]==='waiting'?'waiting':'denied';
    else if(S[k]==='granted')next='idle';
    if(next!==S[k]){
      const became=next==='granted'&&S[k]!=='granted';S[k]=next;changed=true;
      // 和原型一致：授权成功先显示「已允许」，900ms 后自动进下一步
      if(became&&!initial&&STEPS[S.step]===k){render();timers.push(setTimeout(()=>{if(STEPS[S.step]===k&&S[k]==='granted')go(S.step+1)},900));changed=false}
    }
  }
  if(changed&&!initial&&(STEPS[S.step]==='mic'||STEPS[S.step]==='sys'))render();
}
async function poll(){applyPerms(await readPerms())}
async function request(k){
  try{const r=await fetch('/native/permissions/request',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:KIND[k]})});
    const j=await r.json().catch(()=>({}));
    // 小助手不在线时服务端直接打开了系统设置那一页：进入等待态，回来后轮询到已授权就自动继续
    if(j.via==='settings'&&S[k]!=='granted'){S[k]='waiting';render()}
  }catch(e){}
  poll();
}

// ---------- 试听：走正式会议同一条管线的「试听」模式（不写 Notion、不建任务） ----------
function startMeter(){
  const cd=document.getElementById('cd'),bars=[...document.querySelectorAll('.bars i')];
  const t0=S.trialStarted||Date.now();
  meterIv=setInterval(()=>{const lv=S.level==null?Math.random()*.6:S.level;bars.forEach(b=>b.style.height=(3+Math.random()*13*Math.max(.15,lv))+'px');
    const sec=Math.max(0,30-Math.floor((Date.now()-t0)/1000));if(cd)cd.textContent='0:'+String(sec).padStart(2,'0')},120);
}
function stopTrial(){if(trialIv){clearInterval(trialIv);trialIv=null}}
async function trialStart(){
  S.trial='listening';S.lines=[];S.card=null;S.trialMsg='';S.level=null;S.trialStarted=Date.now();render();
  let ok=false;trialLive=true;
  startP=fetch('/native/trial/start',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});
  try{ok=(await startP).ok}catch(e){}finally{startP=null}
  // start 回执到之前用户已经离开 / 返回：离开流程的 stop 会等 start 落地后再发，这里不再重复
  if(S.trial!=='listening'||leaving)return;
  if(!ok){trialLive=false;S.trial='failed';render();return}
  stopTrial();
  trialIv=setInterval(async()=>{
    let j=null;try{const r=await fetch('/native/trial/state',{cache:'no-store'});if(r.ok)j=await r.json()}catch(e){}
    if(S.trial!=='listening'){stopTrial();return}
    const el=(Date.now()-S.trialStarted)/1000;
    if(!j){if(el>30)trialStop();return}
    S.level=typeof j.level==='number'?j.level:null;
    const lines=Array.isArray(j.lines)?j.lines.map(String):[];
    const tx=document.getElementById('tx');
    if(lines.join('\n')!==S.lines.join('\n')&&tx){S.lines=lines;tx.innerHTML=lineHtml()||`<span class="ph">${T.t_ph}</span>`}
    if(j.card&&!S.card){S.card=j.card;const slot=document.getElementById('cardslot');if(slot)slot.innerHTML=card(j.card)}
    const msg=!lines.length&&el>5&&!(S.level>0.05)?T.t_quiet:j.retrying&&el>10?T.t_slow:'';
    const m=document.getElementById('tmsg');if(m&&msg!==S.trialMsg){S.trialMsg=msg;m.textContent=msg;m.hidden=!msg}
    if(j.done||el>=30){trialStop();return}
    if(j.error&&el>30)trialStop();
  },500);
}
// 复审 ONB-02：只有收到 stop 的 2xx 回执才算停下；失败保留「没停下」状态并给「再停一次」，不标完成。
async function trialStop(){
  stopTrial();if(stopP||S.trial!=='listening'&&S.trial!=='stopfail')return;
  const wasLeaving=S.pendingLeave;
  if(!await stopRemote()){S.trial='stopfail';render();return}
  if(wasLeaving){S.pendingLeave=null;S.trial='idle';return leave(wasLeaving)}
  if(pendingBack!==null){const target=pendingBack;pendingBack=null;S.trial='idle';return go(target)}
  if(!S.lines.length){S.trial='failed';render();return}
  S.trial='done';S.trialDone=true;render();
  const ok=await persist({trialDone:true});const was=!!saveFail;saveFail=ok?null:{patch:{trialDone:true}};if(was!==!!saveFail)render();
}

// ---------- 交互 ----------
app.addEventListener('input',e=>{if(e.target.id==='aiin'){const had=!!S.ai.text.trim();S.ai.text=e.target.value;if(had!==!!S.ai.text.trim()){const pos=e.target.selectionStart;render();const t=document.getElementById('aiin');if(t){t.focus();t.setSelectionRange(pos,pos)}}}});
app.addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');if(!b)return;const a=b.dataset.act,k=b.dataset.k;
  if(a==='next')go(S.step+1);
  else if(a==='back'){if(STEPS[S.step]==='trial'&&(S.trial==='listening'||trialLive)){pendingBack=S.step-1;stopTrial();S.trial='stopping';stopRemote().then(ok=>{if(!ok){S.trial='stopfail';render();return}const target=pendingBack;pendingBack=null;S.trial='idle';go(target)});return}S.trial='idle';go(S.step-1)}
  else if(a==='calgo'||a==='gagain')calendarConnect();
  else if(a==='calcancel'){stopCalendar();S.cal='idle';render();}
  else if(a==='calskip')go(S.step+1);
  else if(a==='later')leave({step:S.step});
  else if(a==='ask'||a==='openset'){S.ask[k]=true;request(k)}
  else if(a==='skipsys'){S.sys='skipped';go(S.step+1)}
  else if(a==='trialstart')trialStart();
  else if(a==='trialstop'||a==='retrystop')trialStop();
  else if(a==='retrysave'){const f=saveFail;if(!f)return;saveFail=null;if(f.leave)leave(f.patch);else persist(f.patch).then(ok=>{if(!ok){saveFail=f;}render();});}
  else if(a==='leaveunsaved'){const f=saveFail;saveFail=null;leave(f?.patch||{step:S.step},{force:true});}
  else if(a==='trialskip'||a==='finish')go(AI);
  else if(a==='aicopy')aiCopy();
  else if(a==='aisave')aiPost({text:S.ai.text});
  else if(a==='aidel')aiPost({deleteId:b.dataset.id});
});
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&e.target.tagName!=='TEXTAREA'&&!(e.target.closest&&e.target.closest('button'))){const p=app.querySelector('.btn.pri');if(p){e.preventDefault();p.click()}}
  if(e.key==='Escape'&&S.step<DONE)leave({step:S.step});
});
// 关窗 / 刷新：页面没机会等回执，用 sendBeacon（不行就 keepalive fetch）把 stop 送出去
window.addEventListener('pagehide',()=>{
  stopCalendar();
  if(!trialLive)return;stopTrial();
  const body=new Blob(['{}'],{type:'application/json'});let sent=false;
  try{sent=!!navigator.sendBeacon?.('/native/trial/stop',body)}catch(e){}
  if(!sent){try{fetch('/native/trial/stop',{method:'POST',headers:{'content-type':'application/json'},body:'{}',keepalive:true})}catch(e){}}
});
window.addEventListener('focus',poll);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll()});

// 启动：先读一次系统权限，停在的那一步已授权就直接跳到下一个没做完的步骤（spec §2）
(async()=>{
  const [p,calendar]=await Promise.all([readPerms(),calendarStatus()]);applyPerms(p,true);applyCalendar(calendar);
  if(!S.calConfigured&&STEPS[S.step]==='cal')S.step++;
  if(S.known){
    while((STEPS[S.step]==='mic'&&S.mic==='granted')||(STEPS[S.step]==='sys'&&(S.sys==='granted'||S.sys==='skipped')))S.step++;
  }
  render();
  setInterval(()=>{if(!document.hidden&&(STEPS[S.step]==='mic'||STEPS[S.step]==='sys'))poll()},1000);
})();
})();
