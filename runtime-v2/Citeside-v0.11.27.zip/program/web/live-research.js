'use strict';
(function(root,factory){
 const api=factory(typeof module==='object'&&module.exports?require('./safe-markdown'):root.ThtSafeMarkdown);
 if(typeof module==='object'&&module.exports)module.exports=api;else{root.ThtLiveResearch=api;api.install(root);}
})(typeof globalThis!=='undefined'?globalThis:this,function(md){
 const {esc,markdown}=md,list=x=>Array.isArray(x)?x:[];
 const inline=x=>md.inline(String(x??'').replace(/^#{1,6}\s+/gm,''));
 const I={fd:'<svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 2l1.8 6.2L18 10l-6.2 1.8L10 18l-1.8-6.2L2 10l6.2-1.8z"/></svg>',ok:'<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="10" cy="10" r="7.5"/><path d="M6.8 10.2l2.2 2.2 4.2-4.4"/></svg>',stop:'<svg viewBox="0 0 20 20" fill="currentColor"><rect x="5" y="5" width="10" height="10" rx="1.5"/></svg>'};
 const clock=at=>{const d=new Date(at);return Number.isFinite(+d)?d.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false}):'';};
 const duration=i=>i.state==='done'&&Number.isFinite(i.deepStartedAt)&&Number.isFinite(i.completedAt)?`用时 ${Math.max(0,Math.ceil((i.completedAt-i.deepStartedAt)/60000))} 分钟`:'';
 const dated=at=>{const d=new Date(at);return at&&Number.isFinite(+d)?`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`:'';};
 const btn=(a,text,id='',cls='')=>`<button type="button" data-lr="${a}"${id?` data-item="${esc(id)}"`:''}${cls?` class="${cls}"`:''}>${text}</button>`;
 const effortBtn=(a,id)=>`<span class="effort">${btn(a,a==='deep'?'深入研究':'再深一层 · 穷举',id)} <span class="eta">约 ${a==='deep'?8:20} 分钟</span></span>`;
 const upgrade=()=>'<span class="quiet">升级 Pro 后可深度研究</span>';
 const mark=(text,changed)=>changed?`<mark class="chg">${inline(text)}</mark>`:inline(text);
 function subsHtml(item,tier='pro',flash=false){return `<ol class="subs">${list(item.subs).map((s,i)=>{
  const symbol=tier==='free'?i+1:s.state==='done'?'✓':s.state==='running'?'<span class="spin"></span>':s.state==='failed'?'!':'·';
  const label=tier==='free'?'':s.state==='done'?'已答':s.state==='running'?'在查':s.state==='failed'?'未完成':'待查';
  return `<li><span class="m ${s.state==='done'?'okm':s.state==='running'?'go':''}" aria-label="${label}">${symbol}</span><span>${mark(s.q,flash&&s.changed)}<span class="fm">${esc(s.shape)}</span></span></li>`;}).join('')}</ol>`;}
 function progress(item){if(item.budgetReached)return '';if(!item.deepStarted)return item.quickDone?'速查完成 · 子问题待查':'速查中 · 子问题待查';const subs=list(item.subs),total=subs.reduce((n,s)=>n+list(s.dims).length,0),done=subs.reduce((n,s)=>n+(s.state==='done'?list(s.dims).length:0),0);
  return `穷举 ${subs.length} 类 ${total} 项 · 已查 ${done} 项 · 一页版约 ${clock(Number(item.openedAt)+8*60000)} 出`;}
 function noteForm(item){return `<form class="noteform" data-lr-form="refine" data-item="${esc(item.id)}"><textarea name="text" aria-label="补一句研究方向" placeholder="说一句你想要的方向，例如口径、对象、要不要算某一类">${esc(item.constraint||'')}</textarea><div class="row"><button class="solid" type="submit">按这句改写</button>${btn('note-cancel','取消',item.id,'quiet')}</div></form>`;}
 function safeSrcLabel(src,url){
  const UUID_RE=/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/i;
  const HEX_RE=/^[0-9a-f]{16,}$/i;
  const RAW_RE=/^(?:W\d+|S\d+|src[-_]?\d+|source[-_]?\d+)$/i;
  const v=String(src==null?'':src).trim();
  if(v&&!UUID_RE.test(v)&&!HEX_RE.test(v)&&!RAW_RE.test(v)&&!/^https?:\/\//i.test(v))return v.slice(0,48);
  try{return new URL(String(url||'')).hostname.replace(/^www\./i,'');}catch{return '';}
 }
 function cardKindOf(item){return String(item?.cardKind||item?.fastCard?.cardKind||'').trim().toLowerCase();}
 function cleanComparisonHtml(viz,evidence,kind){
  const ev=list(evidence).filter(e=>safeUrl(e?.url)&&safeSrcLabel(e?.src,e?.url));
  if(!ev.length||!viz||typeof viz!=='object')return '';
  const type=String(viz.type||'').trim();
  const title=viz.title?`<div class="lr-fv-title">${inline(viz.title)}</div>`:'';
  if(type==='metric_table')return fastVizHtml(viz,ev);
  if(type!=='compare_bar')return '';
  const items=list(viz.items).filter(it=>it&&it.label&&number(Number(it.value))&&Number(it.value)>=0);
  if(items.length<2)return '';
  const unit=String(viz.unit||'');
  const head=kind==='external_case'?'<th>先例</th><th>数值</th>':'<th>对照项</th><th>数值</th>';
  return `<div class="lr-fv lr-fv-tbl lr-fc-table" data-fast-viz="metric_table" data-card-kind="${esc(kind)}">${title}<table><thead><tr>${head}</tr></thead><tbody>${items.map(it=>`<tr><td>${inline(it.label)}</td><td>${esc(it.display||(Number(it.value)+unit))}</td></tr>`).join('')}</tbody></table></div>`;
 }
 function blindSpotHtml(fc){
  const qs=list(fc?.subQuestions).map(q=>String(q||'').trim()).filter(q=>/[\u4e00-\u9fff]/.test(q)).slice(0,3);
  const listHtml=qs.length>=2?`<ol class="lr-bs-qs">${qs.map(q=>`<li>${inline(q)}</li>`).join('')}</ol>`:'';
  const conclusion=fc?.conclusion?`<p class="lr-bs-conclusion"><strong>结论：</strong>${inline(fc.conclusion)}</p>`:'';
  const ask=fc?.ask?`<p class="lr-bs-ask"><strong>建议追问：</strong>${inline(fc.ask)}</p>`:'';
  return `${listHtml}${conclusion}${ask}`;
 }
 function fastVizHtml(viz,evidence){
  const ev=list(evidence).filter(e=>safeUrl(e?.url)&&safeSrcLabel(e?.src,e?.url));
  if(!ev.length||!viz||typeof viz!=='object')return '';
  const type=String(viz.type||'').trim();
  const title=viz.title?`<div class="lr-fv-title">${inline(viz.title)}</div>`:'';
  if(type==='compare_bar'){
   const items=list(viz.items).filter(it=>it&&it.label&&number(Number(it.value))&&Number(it.value)>=0);
   if(items.length<2)return '';
   const max=Math.max(1,...items.map(it=>Number(it.value)));
   const unit=String(viz.unit||'');
   return `<div class="lr-fv lr-fv-bar" data-fast-viz="compare_bar">${title}${items.map(it=>{
    const val=Number(it.value),pct=Math.max(6,Math.min(100,Math.round(val/max*100)));
    return `<div class="lr-fv-brow${it.highlight?' is-claim':''}"><span class="lr-fv-blab">${inline(it.label)}</span><span class="lr-fv-btrack"><i style="width:${pct}%"></i></span><span class="lr-fv-bval">${esc(it.display||(val+unit))}</span></div>`;
   }).join('')}</div>`;
  }
  if(type==='timeline'){
   const items=list(viz.items).filter(it=>it&&it.date&&it.label);
   if(items.length<2)return '';
   return `<div class="lr-fv lr-fv-tl" data-fast-viz="timeline">${title}<ol class="lr-fv-tl-list">${items.map(it=>`<li><span class="lr-fv-tl-date">${esc(it.date)}</span><div class="lr-fv-tl-body"><strong>${inline(it.label)}</strong>${it.note?`<span>${inline(it.note)}</span>`:''}</div></li>`).join('')}</ol></div>`;
  }
  if(type==='metric_table'){
   const cols=list(viz.columns).filter(Boolean),rows=list(viz.rows).filter(r=>Array.isArray(r)&&r.length===cols.length);
   if(cols.length<2||!rows.length)return '';
   return `<div class="lr-fv lr-fv-tbl" data-fast-viz="metric_table">${title}<table><thead><tr>${cols.map(c=>`<th>${inline(c)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  }
  if(type==='checklist'){
   const items=list(viz.items).filter(it=>it&&it.label);
   if(!items.length)return '';
   const iconOf=st=>st==='ok'?'✓':st==='miss'?'×':'!';
   return `<div class="lr-fv lr-fv-chk" data-fast-viz="checklist">${title}<ul class="lr-fv-chk-list">${items.map(it=>{
    const st=['ok','warn','miss'].includes(it.status)?it.status:'warn';
    return `<li class="is-${st}"><span class="lr-fv-chk-ic" aria-hidden="true">${iconOf(st)}</span><div class="lr-fv-chk-body"><strong>${inline(it.label)}</strong>${it.note?`<span>${inline(it.note)}</span>`:''}</div></li>`;
   }).join('')}</ul></div>`;
  }
  return '';
 }
 function fastCardHtml(item,{readonly=false,showExpand=true}={}){
  const fc=item?.fastCard;
  if(!fc||typeof fc!=='object')return '';
  const kind=cardKindOf(item);
  const verdict=String(fc.verdict||'存疑');
  const vCls=verdict==='成立'||verdict==='有条件成立'?'is-ok':verdict==='不成立'?'is-no':verdict==='查不到'?'is-none':verdict==='口径差异'?'is-gap':'is-warn';
  const ev=list(fc.evidence).map(e=>{
   const url=safeUrl(e?.url),src=safeSrcLabel(e?.src,url);
   return url&&src?{src,url,date:String(e?.date||''),fact:String(e?.fact||'')}:null;
  }).filter(Boolean);
  const tableHtml=kind==='fact_check'||kind==='external_case'?cleanComparisonHtml(fc.viz,ev,kind):'';
  const vizHtml=tableHtml||fastVizHtml(fc.viz,ev);
  const spot=kind==='blind_spot'?blindSpotHtml(fc):'';
  const takeaway=kind==='external_case'&&fc.takeaway?`<p class="lr-ec-take"><strong>可借鉴：</strong>${inline(fc.takeaway)}</p>`:'';
  const srcHtml=ev.length?`<div class="lr-fc-sources">${ev.map(e=>`<a class="lr-fc-src" href="${esc(e.url)}" target="_blank" rel="noopener noreferrer" title="${esc(e.fact||e.src)}"><span>${esc(e.src)}</span>${e.date?`<small>${esc(e.date)}</small>`:''}</a>`).join('')}</div>`:'';
  const expandBtn=kind==='fact_check'?'':(!readonly&&showExpand&&!item.fullExpanded?`<div class="lr-fc-foot">${btn('expand-full','展开完整版',item.id,'lr-fc-expand')}</div>`:'');
  return `<div class="lr-fast-card" data-verdict="${esc(verdict)}" data-card-kind="${esc(kind)}"><div class="lr-fc-head"><span class="lr-fc-verdict ${vCls}">${esc(verdict)}</span>${fc.cached?'<span class="lr-fc-tag">24h 缓存</span>':''}</div>${fc.delta?`<p class="lr-fc-delta">${inline(fc.delta)}</p>`:''}${kind==='blind_spot'?'':(fc.say?`<p class="lr-fc-say"><strong>可直接说：</strong>${inline(fc.say)}</p>`:'')}${spot}${vizHtml}${takeaway}${srcHtml}${expandBtn}</div>`;
 }
 function researchPresentation(item={}){
  const status=({done:'completed',partial:'stopped'})[item.state]||(['running','queued','refining','planned','completed','failed','interrupted','stopped'].includes(item.state)?item.state:'planned');
  const meaningful=value=>typeof value==='string'&&!!value.trim()&&!/速查没找到可靠答案|no reliable answer|確かな答えが見つかりません/i.test(value);
  const hasFast=!!(item.fastCard&&typeof item.fastCard==='object');
  const hasReport=hasFast||meaningful(item.conclusion)||list(item.subs).some(s=>meaningful(s.section?.answer));
  const sources=list(item.quick?.sources).map(id=>list(item.sources).find(s=>s.id===id)).filter(s=>s&&safeUrl(s.url));
  const raw=status==='completed'&&meaningful(item.conclusion)?item.conclusion:item.quick?.answer;
  const answer=meaningful(raw)&&(sources.length||raw===item.conclusion)?String(raw).trim():'';
  const executing=['running','queued','refining'].includes(status);
  const retryable=['failed','interrupted'].includes(status)||(item.state==='partial'&&!hasReport);
  return {visible:executing||hasReport||!!(answer&&sources.length)||retryable,status,answer,sources,hasReport,retryable};
 }
 function researchItem(item,tier='pro',ui={}){
  const presentation=researchPresentation(item),{answer,sources:sourceLinks,hasReport,retryable}=presentation;
  if(!presentation.visible)return '';
  const free=tier==='free',done=presentation.status==='completed',stopped=['failed','interrupted','stopped'].includes(presentation.status),noAnswer=!answer;
  if(!free&&item.fastCard&&!item.fullExpanded&&done){
   const kind=cardKindOf(item),specialized=['fact_check','blind_spot','external_case'].includes(kind);
   const lab=kind==='blind_spot'?'关键盲区':kind==='external_case'?'外部先例':kind==='fact_check'?'事实核查':'极速深度核查';
   return `<article class="lr-scope lr-feed-entry lr-compact lr-fast-entry" data-lr-item="${esc(item.id)}" data-stream-key="research:${esc(item.id)}" data-published-at="${Number(item.openedAt)||0}"><div class="it ok"><div class="lab"><b>${lab}</b><time>${clock(item.completedAt||item.openedAt)}</time></div><h2 class="rt">${mark(item.title,ui.flash)}</h2>${fastCardHtml(item,{readonly:false,showExpand:false})}<div class="acts">${btn('report','打开详情 ›',item.id,'lr-act-primary')}${specialized?'':btn('expand-full','展开完整版',item.id,'quiet')}${btn('copy','复制给我的 AI',item.id,'quiet')}</div></div></article>`;
  }
  const pct=Math.max(12,Math.min(95,Math.round(100*(list(item.subs).filter(s=>s.state==='done').length+0.4)/Math.max(1,list(item.subs).length))));
  if(!hasReport&&!answer&&['running','queued','refining'].includes(presentation.status))return `<article class="lr-scope lr-feed-entry lr-compact" data-lr-item="${esc(item.id)}" data-stream-key="research:${esc(item.id)}" data-published-at="${Number(item.openedAt)||0}"><div class="it rs"><div class="lab"><b>${item.deepStarted?'正在研究':'正在速查'}</b><time>${clock(item.openedAt)}</time></div><h2 class="rt">${inline(item.title)}</h2>${item.deepStarted?`<div class="prog" role="status">${progress(item)}</div><div class="ctv2-prog"><div style="width:${pct}%"></div></div><div class="acts">${btn('stop','停止研究',item.id)}</div>`:''}</div></article>`;
  const expanded=ui.expanded===item.id;
  const kindNow=cardKindOf(item);
  const plan=kindNow==='fact_check'?'':(list(item.subs).length?`<button type="button" data-lr="expand" data-item="${esc(item.id)}" aria-expanded="${expanded}">${expanded?'收起拆解':'查看拆解 · '+list(item.subs).length+' 项'}</button>`:'');
  const primaryAction=hasReport?btn('report','打开报告 ›',item.id,'lr-act-primary'):(retryable?btn('resume',presentation.status==='interrupted'?'已中断 · 重试':'研究失败 · 重试',item.id,'lr-act-primary'):(!item.deepStarted?btn('deep','深入研究',item.id,'lr-act-primary'):(!done&&!stopped?btn('stop','停止研究',item.id,'lr-act-primary'):'')));
  const secondaryDeep=hasReport&&!item.deepStarted?btn('deep','深入研究',item.id,'quiet'):(hasReport&&!done&&!stopped?btn('stop','停止',item.id,'quiet'):'');
  const actions=free?upgrade():primaryAction+secondaryDeep+plan+btn('note',ui.note===item.id?'收起补充':'补一句',item.id,'quiet')+(!retryable&&(stopped||['partial','failed','interrupted'].includes(item.state))?btn('resume','继续',item.id,'quiet'):'')+btn('copy','复制给我的 AI',item.id,'quiet')+(tier==='max'&&item.deepStarted&&!item.exhaustiveStarted?btn('exhaustive','再深一层 · 穷举',item.id,'quiet'):'');
  const sources=!done&&sourceLinks.length?`<div class="lr-compact-sources">来源：${sourceLinks.map(source=>`<a href="${esc(safeUrl(source.url))}" target="_blank" rel="noopener noreferrer">${inline(safeSrcLabel(source.src||source.title,source.url)||source.title)}</a>`).join(' · ')}</div>`:'';
  const statusText=({completed:'研究完成',failed:'研究失败',interrupted:'研究已中断',stopped:'研究已停止',queued:'排队中',running:'正在研究',refining:'正在完善',planned:'速查完成'})[presentation.status];
  const spotInline=kindNow==='blind_spot'?blindSpotHtml(item.fastCard):'';
  return `<article class="lr-scope lr-feed-entry lr-compact" data-lr-item="${esc(item.id)}" data-stream-key="research:${esc(item.id)}" data-published-at="${Number(item.openedAt)||0}"><div class="it ${free?'fd':done?'ok':'rs'}"><div class="lab"><b>${statusText}</b><time>${clock(done?item.completedAt:item.openedAt)}${done&&duration(item)?' · '+duration(item):''}</time></div><h2 class="rt">${mark(item.title,ui.flash)}</h2>${!free&&answer&&!noAnswer?`<div class="tx lr-compact-answer">${markdown(answer)}</div>${sources}`:''}${spotInline}${expanded&&kindNow!=='fact_check'?`<div class="lr-plan-title">研究拆解</div>${subsHtml(item,tier,ui.flash)}`:''}<div class="acts">${actions}</div>${item.deepStarted&&!done&&!stopped&&!item.budgetReached?`<div class="prog" role="status">${progress(item)} · 可随时停止</div>`:''}${!free&&ui.note===item.id?noteForm(item):''}</div></article>`;
 }
 function followupItem(item,f){const done=f.state==='done';return `<article class="lr-scope lr-feed-entry" data-lr-item="${esc(f.id)}" data-stream-key="research:${esc(f.id)}" data-published-at="${Number(f.at)||0}"><div class="it ${done?'ok':'rs'}"><span class="ic">${done?I.ok:'<span class="spin"></span>'}</span><div class="lab"><b>研究</b><time>${clock(f.at)} · 接着问</time></div><div class="tx">${markdown(done?f.title:f.q)}</div><p class="basis">${done?'答案已追加到同一份报告':f.state==='failed'?'未完成，继续后重试':'答案追加到同一份报告'}</p>${done?`<div class="acts">${btn('report','打开报告 ›',item.id)}</div>`:''}</div></article>`;}
 const number=v=>typeof v==='number'&&Number.isFinite(v),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const tx=(x,y,value,color='var(--sub)',size=12)=>`<text x="${x}" y="${y}" fill="${color}" font-size="${size}">${esc(value)}</text>`;
 const rect=(x,y,w,h,fill='var(--paper)',extra='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="3" fill="${fill}" ${extra}/>`;
 const line=(x1,y1,x2,y2,color='var(--rail)',extra='')=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" ${extra}/>`;
 const dot=(x,y,r=3,color='var(--fd)',extra='')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${color}" ${extra}/>`;
 const strings=a=>Array.isArray(a)&&a.length>0&&a.every(x=>typeof x==='string');
 const wrapped=(x,y,value,width=26,color='var(--sub)')=>{const chars=Array.from(String(value??''));return Array.from({length:Math.max(1,Math.ceil(chars.length/width))},(_,i)=>tx(x,y+i*14,chars.slice(i*width,(i+1)*width).join(''),color)).join('');};
 const chartNotes=notes=>list(notes).filter(Boolean).map(n=>`<p class="lr-chart-note">${inline(n)}</p>`).join('');
 // Charts use design pixels. Tables grow by 28px per row; detailed annotations
 // flow below diagrams rather than increasing or scaling their SVG viewport.
 function chartComparison(c){
  if(!c.options&&Array.isArray(c.bars)&&c.bars.length&&c.bars.every(b=>number(b.value)&&b.value>=0)){const max=Math.max(1,...c.bars.map(b=>b.value));return {table:true,h:16+c.bars.length*28,body:c.bars.map((b,i)=>tx(8,24+i*28,b.label)+rect(150,12+i*28,b.value/max*255,14,'var(--fd)')+tx(414,24+i*28,b.value+String(c.unit||''))).join('')};}
  if(!strings(c.options)||!Array.isArray(c.criteria)||!c.criteria.length||!c.criteria.every(r=>r&&typeof r.name==='string'&&Array.isArray(r.scores)&&r.scores.length===c.options.length&&r.scores.every(v=>Number.isInteger(v)&&v>=1&&v<=3))||!Number.isInteger(c.recommend)||c.recommend<0||c.recommend>=c.options.length)return null;
  const cw=116,w=148+c.options.length*cw,h=44+c.criteria.length*28;
  return {w,h,table:true,body:rect(142+c.recommend*cw,0,cw,h,'var(--hl)','data-recommended="true"')+c.options.map((v,i)=>wrapped(150+i*cw,15,v,8)).join('')+c.criteria.map((r,i)=>tx(8,60+i*28,r.name)+r.scores.map((v,j)=>Array.from({length:v},(_,k)=>dot(166+j*cw+k*12,56+i*28,3,'var(--fd)','data-score="true"')).join('')).join('')).join('')};
 }
 function chartEnumeration(c){if(!strings(c.objects)||!Array.isArray(c.dims)||!c.dims.length||!c.dims.every(r=>r&&typeof r.name==='string'&&Array.isArray(r.marks)&&r.marks.length===c.objects.length&&r.marks.every(v=>typeof v==='boolean')))return null;
  const cw=112,w=144+c.objects.length*cw,h=64+c.dims.length*28;
  return {w,h,table:true,body:c.objects.map((v,j)=>wrapped(148+j*cw,15,v,8)).join('')+c.dims.map((r,i)=>line(8,64+i*28,w-8,64+i*28)+tx(8,56+i*28,r.name)+r.marks.map((v,j)=>`<g data-mark="${v}">${tx(180+j*cw,56+i*28,v?'✓':'—',v?'var(--ok)':'var(--faint)')}</g>`).join('')).join('')+c.objects.map((_,j)=>tx(174+j*cw,h-6,c.dims.filter(r=>r.marks[j]).length+'/'+c.dims.length)).join('')};
 }
 function chartPosition(c){if(!number(c.min)||!number(c.max)||c.max<=c.min||!Array.isArray(c.marks)||!c.marks.every(m=>m&&number(m.value))||!number(c.self?.value))return null;
  const unit=String(c.unit||'');
  const points=[...c.marks.map(m=>({label:String(m.label||''),value:m.value,isSelf:false})),{label:String(c.self.label||'我们'),value:c.self.value,isSelf:true}];
  const sortedDesc=[...points].sort((a,b)=>b.value-a.value);
  if(points.length<=3){
   const rows=sortedDesc.map(p=>`<tr${p.isSelf?' class="is-self"':''}><td>${inline(p.label)}${p.isSelf?' <span class="lr-self-tag">当前</span>':''}</td><td class="num"><strong>${esc(String(p.value))}${esc(unit)}</strong></td></tr>`).join('');
   return {html:`<div class="lr-pos-table" data-chart="定位" data-chart-fallback="table"><table><thead><tr><th>对照项</th><th class="num">数值</th></tr></thead><tbody>${rows}</tbody></table></div>`,notes:[c.note]};
  }
  const x=v=>12+clamp((v-c.min)/(c.max-c.min),0,1)*456;
  const estW=p=>Array.from(p.label+' '+p.value+unit).length*7.5+16;
  const byX=[...points].map(p=>({...p,px:x(p.value),w:estW(p)})).sort((a,b)=>a.px-b.px);
  let hasCollision=false;
  for(let i=1;i<byX.length;i++){
   const dist=Math.abs(byX[i].px-byX[i-1].px);
   if(dist<Math.max(byX[i].w,byX[i-1].w)){hasCollision=true;break;}
  }
  if(points.length>5||hasCollision){
   const maxVal=Math.max(c.max,...sortedDesc.map(p=>p.value),1),minVal=Math.min(0,c.min,...sortedDesc.map(p=>p.value));
   const span=Math.max(1e-6,maxVal-minVal);
   const h=16+sortedDesc.length*28;
   const body=sortedDesc.map((p,i)=>{
    const y=12+i*28,barW=Math.max(8,clamp((p.value-minVal)/span,0,1)*230);
    const fill=p.isSelf?'var(--fd)':'var(--rail)';
    const labColor=p.isSelf?'var(--fd)':'var(--sub)';
    const labChars=Array.from(String(p.label||'')),labText=labChars.length>10?labChars.slice(0,9).join('')+'…':p.label;
    return tx(8,y+12,labText,labColor,12)+rect(144,y,230,14,'var(--hover)')+rect(144,y,barW,14,fill,p.isSelf?'data-self="true"':'data-benchmark="true"')+tx(382,y+12,p.value+unit,p.isSelf?'var(--fd)':'var(--text)',12);
   }).join('');
   return {w:480,h,table:true,fallback:'hbar',body,notes:[c.note]};
  }
  return {h:unit.length>1?110:86,body:line(12,38,468,38)+c.marks.map((m,i)=>line(x(m.value),31,x(m.value),45)+tx(clamp(x(m.value),70,400),62+i%2*14,m.label+' '+m.value+unit).replace('<text ','<text text-anchor="middle" ')).join('')+line(x(c.self.value),28,x(c.self.value),48,'var(--fd)','stroke-width="3" data-self="true"')+c.marks.map(m=>dot(x(m.value),38,2,'var(--faint)','data-benchmark="true"')).join('')+tx(clamp(x(c.self.value)-26,12,360),18,c.self.label+' '+c.self.value+unit,'var(--fd)')+tx(12,unit.length>1?100:82,c.min)+tx(468,unit.length>1?100:82,c.max+unit).replace('<text ','<text text-anchor="end" '),notes:[c.note]};
 }
 function chartComposition(c){const rows=c.layers||c.parts;if(!Array.isArray(rows)||!rows.length||!rows.every(r=>r&&number(r.value)&&r.value>=0))return null;const max=Math.max(...rows.map(r=>r.value));if(!max)return null;
  const gap=Math.min(36,204/rows.length),body=rows.map((r,i)=>{const w=r.value/max*440,y=6+i*gap;return rect((480-w)/2,y,w,Math.min(26,gap-4),'var(--hl)','data-layer="true"')+tx((480-w)/2+6,y+Math.min(18,gap-7),r.label+' '+r.value+String(c.unit||''),'var(--text)');}).join('');return {h:Math.min(220,12+rows.length*gap),body,notes:rows.map(r=>r.basis?r.label+'：'+r.basis:'')};}
 function chartTrend(c){if(!Array.isArray(c.points)||c.points.length<2||!c.points.every(p=>p&&number(p.y)&&typeof p.x==='string')||c.events!==undefined&&(!Array.isArray(c.events)||!c.events.every(e=>e&&c.points.some(p=>p.x===e.x))))return null;
  const lo=Math.min(...c.points.map(p=>p.y)),hi=Math.max(...c.points.map(p=>p.y)),pt=(p,i)=>[28+i/(c.points.length-1)*420,130-(p.y-lo)/(hi-lo||1)*76],pts=c.points.map(pt),end=c.points.at(-1);
  return {h:190,body:`<polygon points="28,136 ${pts.map(p=>p.join(',')).join(' ')} 448,136" fill="var(--hl)"/><polyline points="${pts.map(p=>p.join(',')).join(' ')}" fill="none" stroke="var(--fd)" stroke-width="2"/>`+list(c.events).map((e,i)=>{const x=pts[c.points.findIndex(p=>p.x===e.x)][0];return line(x,30,x,140,'var(--warn)','stroke-dasharray="4 4" data-event="true"')+wrapped(clamp(x-30,5,150),16+i%2*14,e.label,24);}).join('')+c.points.map((p,i)=>dot(...pts[i],3)+tx(clamp(pts[i][0]-18,0,425),158,p.x)).join('')+tx(390,182,end.y+String(c.unit||''),'var(--fd)')};
 }
 function chartDecision(c){if(typeof c.question!=='string'||!Array.isArray(c.options)||!c.options.length||!c.options.every(o=>o&&typeof o.label==='string'&&typeof o.pick==='boolean'&&typeof o.why==='string')||typeof c.reversal!=='string')return null;
  const gap=Math.min(38,174/c.options.length);return {h:Math.min(220,38+c.options.length*gap),body:tx(8,16,c.question,'var(--text)')+c.options.map((o,i)=>{const y=32+i*gap;return rect(8,y,464,gap-5,o.pick?'var(--okbg)':'var(--hover)',`data-option="${o.pick}"`)+tx(16,y+18,(o.pick?'✓ ':'')+o.label,o.pick?'var(--ok)':'var(--text)');}).join(''),notes:[...c.options.map(o=>o.label+'：'+o.why),'推翻条件：'+c.reversal]};}
 function chartMechanism(c){if(!Array.isArray(c.steps)||!c.steps.length||!c.steps.every(s=>s&&typeof s.label==='string'&&typeof s.fault==='boolean'&&typeof s.evidence==='string'))return null;
  const gap=Math.min(42,204/c.steps.length);return {h:Math.min(220,12+c.steps.length*gap),body:c.steps.map((s,i)=>{const y=6+i*gap;return (i?line(85,y-12,85,y-2,'var(--sub)')+`<path d="M81 ${y-6}l4 4 4-4" fill="none" stroke="var(--sub)"/>`:'')+rect(8,y,464,gap-8,s.fault?'var(--warnbg)':'var(--hl)',`stroke="${s.fault?'var(--warn)':'var(--rail)'}" data-step="true"`)+tx(16,y+18,s.label,s.fault?'var(--warn)':'var(--text)');}).join(''),notes:c.steps.map(s=>s.label+'：'+s.evidence)};}
 function chartEstimate(c){if(!number(c.answer?.low)||!number(c.answer?.high)||c.answer.high<c.answer.low||!Array.isArray(c.assumptions)||!c.assumptions.length||!c.assumptions.every(a=>a&&typeof a.label==='string'&&typeof a.value==='string'&&typeof a.source==='string'))return null;
  const gap=Math.min(30,164/c.assumptions.length);return {h:Math.min(220,48+c.assumptions.length*gap),body:rect(8,4,464,30,'var(--hl)')+tx(20,24,c.answer.low+'–'+c.answer.high+' '+String(c.answer.unit||''),'var(--fd)')+c.assumptions.map((a,i)=>{const y=46+i*gap;return line(20,34,20,y+12)+line(20,y+12,38,y+12)+rect(38,y,434,gap-4,'var(--hover)','data-assumption="true"')+tx(46,y+17,a.label,'var(--text)');}).join(''),notes:c.assumptions.map(a=>a.label+'：'+a.value+' · 来源：'+a.source)};}
 function chartLandscape(c){if(typeof c.metric!=='string'||!Array.isArray(c.points)||!c.points.length||!c.points.every(p=>p&&typeof p.x==='string'&&number(p.y)&&typeof p.method==='string'&&typeof p.label==='string'&&typeof p.best==='boolean'))return null;
  const times=[...new Set(c.points.map(p=>p.x))].sort(),methods=[...new Set(c.points.map(p=>p.method))],lo=Math.min(...c.points.map(p=>p.y)),hi=Math.max(...c.points.map(p=>p.y)),palette=['var(--fd)','var(--tk)','var(--ok)','var(--warn)','var(--sub)'],labels=[];return {h:210,body:tx(8,16,c.metric)+line(28,30,28,160)+line(28,160,464,160)+times.map((v,i)=>tx(28+i/(times.length-1||1)*400,182,v)).join('')+c.points.map((p,i)=>{const x=44+times.indexOf(p.x)/(times.length-1||1)*390,y=140-(p.y-lo)/(hi-lo||1)*80;let ly=y-12;while(labels.some(l=>Math.abs(l.x-x)<90&&Math.abs(l.y-ly)<15))ly-=16;labels.push({x,y:ly});return dot(x,y,p.best?5:3,palette[methods.indexOf(p.method)%5],`data-point="true"`)+tx(clamp(x-24,8,350),ly,p.label+(p.best?' · SOTA':'')+' '+p.y);}).join(''),legend:methods.map((m,i)=>({label:m,color:palette[i%5]}))};}
 function chartApplicability(c){if(!strings(c.rows)||!strings(c.cols)||!Array.isArray(c.cells)||c.cells.length!==c.rows.length||!c.cells.every(row=>Array.isArray(row)&&row.length===c.cols.length&&row.every(v=>['适用','不适用','需律师'].includes(v))))return null;
  const cw=112,w=144+c.cols.length*cw,h=64+c.rows.length*28;return {w,h,table:true,body:c.cols.map((v,j)=>wrapped(148+j*cw,15,v,8)).join('')+c.rows.map((r,i)=>tx(8,58+i*28,r)+c.cells[i].map((v,j)=>rect(142+j*cw,40+i*28,106,24,v==='适用'?'var(--okbg)':v==='不适用'?'var(--hover)':'var(--warnbg)','data-cell="true"')+tx(152+j*cw,57+i*28,v,v==='适用'?'var(--ok)':v==='需律师'?'var(--warn)':'var(--sub)')).join('')).join(''),notes:['这类报告不是法律意见']};}
 function chartPractices(c){if(!Array.isArray(c.items)||!c.items.length||!c.items.every(i=>i&&typeof i.text==='string'&&typeof i.case==='string'&&typeof i.cost==='string'))return null;
  const gap=Math.min(38,204/c.items.length);return {h:Math.min(220,12+c.items.length*gap),body:c.items.map((r,i)=>{const y=20+i*gap;return dot(18,y,10,'var(--hl)','data-practice="true"')+tx(14,y+4,i+1,'var(--fd)')+tx(36,y+4,r.text,'var(--text)');}).join(''),notes:c.items.map((r,i)=>(i+1)+'. '+r.case+' · 成本：'+r.cost)};}
 const chartRenderers={'对比':chartComparison,'穷举':chartEnumeration,'定位':chartPosition,'构成':chartComposition,'趋势':chartTrend,'决策':chartDecision,'机制':chartMechanism,'估算':chartEstimate,'版图':chartLandscape,'适用判定':chartApplicability,'做法':chartPractices};
 function chartHtml(chart,shape){try{if(!chart||chart.type!==shape||!Object.hasOwn(chartRenderers,shape))return '';const out=chartRenderers[shape](chart);if(!out)return '';if(out.html)return `${out.html}${chartNotes(out.notes)}`;const w=out.w||480,h=out.h||200;return `<svg class="lr-chart${out.fallback?' lr-pos-'+out.fallback:''}" data-chart="${esc(shape)}"${out.fallback?` data-chart-fallback="${esc(out.fallback)}"`:''}${out.table?' data-chart-table="true"':''} width="${w}px" height="${h}px" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(shape)}图">${out.body}</svg>${chartNotes(out.notes)}${out.legend?'<div class="lr-chart-legend">'+out.legend.map(l=>`<span style="color:${l.color}">● ${inline(l.label)}</span>`).join('')+'</div>':''}`;}catch{return '';}}
 function executiveBriefHtml(item,{readonly=false}={}){
  const b=item?.executiveBrief;
  if(!b||typeof b!=='object'||(!b.verdict&&!list(b.facts).length))return '';
  const facts=list(b.facts).filter(f=>f&&(f.claim||f.value)).slice(0,3);
  const factsBlock=facts.length?`<div class="lr-brief-facts">${facts.map(f=>{
   const metric=[f.value,f.unit].filter(Boolean).join(' ');
   const cite=[f.source,f.date].filter(Boolean).join(' · ');
   return `<div class="lr-brief-fact">${metric?`<div class="lr-brief-num">${esc(metric)}</div>`:''}<div class="lr-brief-claim">${inline(f.claim||'')}</div>${cite?`<div class="lr-brief-cite">${esc(cite)}</div>`:''}</div>`;
  }).join('')}</div>`:'';
  const soWhat=b.so_what?`<p class="lr-brief-impact">${inline(b.so_what)}</p>`:'';
  const counter=b.counter?`<p class="lr-brief-counter">反方与边界：${inline(b.counter)}</p>`:'';
  const ask=b.ask&&!readonly?`<div class="lr-brief-ask"><button type="button" class="lr-ask-chip" data-lr="quick-ask" data-item="${esc(item.id||'')}" data-q="${esc(b.ask)}">追问：${esc(b.ask)}</button></div>`:(b.ask?`<p class="lr-brief-counter">建议追问：${inline(b.ask)}</p>`:'');
  return `<div class="lr-brief-card">${b.verdict?`<div class="lr-brief-verdict">${inline(b.verdict)}</div>`:''}${factsBlock}${soWhat}${counter}${ask}</div>`;
 }
 function tableHtml(section){
  const badge=cred=>`<span class="cb ${cred==='证实'?'ok':cred==='传闻'?'lo':'mid'}">${esc(cred)}</span>`;
  return `<div class="tw"><table><thead><tr>${list(section.columns).map(c=>`<th>${inline(c)}</th>`).join('')}<th>可信度</th><th>来源</th></tr></thead><tbody>${list(section.rows).map(r=>`<tr>${list(r.cells).map(c=>`<td>${markdown(c)}</td>`).join('')}<td>${badge(r.cred)}</td><td>${list(r.sources).map(id=>`<a href="#lr-source-${esc(id)}">${esc(id)}</a>`).join('、')}</td></tr>`).join('')}</tbody></table></div>`;
 }
 const safeUrl=x=>{try{const u=new URL(x);return ['https:','http:'].includes(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}};
 function markdownOfReport(item){
  const lines=['# '+(item.title||'研究报告'),'',item.conclusion?'## 一句话结论\n\n'+item.conclusion:'',...list(item.subs).map((s,i)=>'## '+(i+1)+'. '+(s.q||'')+'\n\n'+(s.section?.answer||'')).filter(Boolean)];
  if(list(item.sources).length){lines.push('','## 来源');for(const s of list(item.sources))lines.push(`- ${s.id||''} ${s.title||''} ${safeUrl(s.url)||''}`.trim());}
  return lines.filter(x=>x!==null&&x!==undefined).join('\n');
 }
 function standaloneHtml(item){
  const headline=list(item.subs).find(s=>s.id===item.headline);
  const meta=[item.meetingTitle,dated(item.completedAt||item.deepStartedAt||item.openedAt)?`${dated(item.completedAt||item.deepStartedAt||item.openedAt)} ${clock(item.completedAt||item.deepStartedAt||item.openedAt)}`:'',item.effort==='exhaustive'?'完整版':'一页版',duration(item)].filter(Boolean).join(' · ');
  const sections=list(item.subs).map((sub,i)=>`<section class="sec" id="sub-${esc(sub.id)}"><h2>${i+1}. ${inline(sub.q||'')} <span class="badge">${esc(sub.shape||'')}</span></h2>${sub.section?markdown(sub.section.answer)+(sub.id===item.headline?'':chartHtml(sub.section.chart,sub.shape))+tableHtml(sub.section):'<p class="muted">暂无章节正文</p>'}</section>`).join('');
  const followups=list(item.followups).map(f=>`<section class="sec"><h3>追问：${inline(f.title||f.q)}</h3>${f.section?markdown(f.section.answer)+tableHtml(f.section):''}</section>`).join('');
  const sources=list(item.sources).map(s=>`<li id="src-${esc(s.id)}">[${esc(s.id)}] ${safeUrl(s.url)?`<a href="${esc(safeUrl(s.url))}" target="_blank" rel="noopener noreferrer">${inline(s.title||s.url)}</a>`:inline(s.title||'')}</li>`).join('');
  const css=':root{--bg:#f6f7fb;--card:#ffffff;--ink:#1c1e26;--sub:#5e6472;--line:#e5e8f0;--accent:#0a66c2;--fd:#0a66c2;--tk:#7c5cff;--ok:#15803d;--okbg:#dcfce7;--warn:#b45309;--warnbg:#fef3c7;--hl:rgba(10,132,255,.09);--rail:#d1d5db;--paper:#e5e7eb;--hover:#f1f5f9;--text:#1c1e26}body{margin:0;padding:32px 20px;background:var(--bg);color:var(--ink);font:15px/1.7 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}main{max-width:860px;margin:0 auto;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:34px 38px;box-shadow:0 8px 30px rgba(15,23,42,.05)}h1{margin:0 0 8px;font-size:24px;line-height:1.35}.meta{color:var(--sub);font-size:13px;margin-bottom:22px}.hero{padding:16px 20px;border-radius:12px;background:linear-gradient(135deg,#eef5ff,#f5f3ff);border:1px solid #dbeafe;margin:18px 0 24px}.hk{font-size:12px;font-weight:600;color:var(--accent);margin-bottom:6px}.sec{margin:26px 0;padding-top:18px;border-top:1px solid var(--line)}h2{font-size:17px;margin:0 0 10px}.badge{font-size:11px;padding:2px 8px;border-radius:999px;background:#eef2ff;color:#4f46e5;font-weight:500;margin-left:8px}table{width:100%;border-collapse:collapse;margin:12px 0;font-size:13.5px}th,td{border:1px solid var(--line);padding:8px 10px;text-align:left}th{background:#f8fafc}.cb{padding:1px 6px;border-radius:999px;font-size:11px;font-weight:600}.cb.ok{background:var(--okbg);color:var(--ok)}.cb.mid{background:#e0f2fe;color:#0369a1}.cb.lo{background:var(--warnbg);color:var(--warn)}svg.lr-chart{max-width:100%;height:auto;display:block;margin:12px 0}.lr-pos-hbar{display:flex;flex-direction:column;gap:8px;margin:12px 0;padding:12px;border:1px solid var(--line);border-radius:10px}.lr-hbar-row{display:grid;grid-template-columns:minmax(72px,140px) minmax(0,1fr) auto;align-items:center;gap:10px;font-size:13px}.lr-hbar-track{height:10px;border-radius:999px;background:#f1f5f9;overflow:hidden}.lr-hbar-fill{display:block;height:100%;border-radius:999px;background:#94a3b8}.lr-hbar-row.is-self .lr-hbar-fill{background:var(--accent)}.lr-brief-card{margin:16px 0 22px;padding:16px 20px;border-radius:12px;border:1px solid var(--line);background:#fbfcfe;display:flex;flex-direction:column;gap:12px}.lr-brief-verdict{font-size:17px;font-weight:650}.lr-brief-facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}.lr-brief-fact{padding:10px 12px;border-radius:9px;background:#fff;border:1px solid var(--line)}.lr-brief-num{font-size:17px;font-weight:700;color:var(--accent)}.lr-brief-cite,.lr-brief-counter{font-size:12px;color:var(--sub);margin:0}.lr-chart-legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:var(--sub)}.lr-chart-note{font-size:12.5px;color:var(--sub);margin:6px 0}.sources{padding-left:20px;font-size:13.5px;color:var(--sub)}.sources a{color:var(--accent);text-decoration:none}.foot{margin-top:28px;padding-top:14px;border-top:1px solid var(--line);font-size:12px;color:var(--sub)}';
  const heroBlock=executiveBriefHtml(item,{readonly:true})||`<div class="hero"><div class="hk">一句话结论</div><div>${markdown(item.conclusion||'暂无结论')}</div></div>`;
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(item.title||'Citeside 研究报告')}</title><style>${css}</style></head><body><main><h1>${inline(item.title||'研究报告')}</h1><div class="meta">${esc(meta)}</div>${heroBlock}${chartHtml(headline?.section?.chart,headline?.shape)}${sections}${followups}<section class="sec"><h2>来源参考</h2><ol class="sources">${sources}</ol></section><footer class="foot">由 Citeside 本地导出 · 离线单文件报告</footer></main></body></html>`;
 }
 function reportHtml(item,{readonly=false,handoff={}}={}){
  const headline=list(item.subs).find(s=>s.id===item.headline),renderSection=(sub,i)=>{
   const answer=String(sub.section?.answer||'').trim(),match=answer.match(/^([\s\S]*?[。！？!?]|[^\n]+(?:\n|$))/),first=(match?.[0]||answer).trim(),plain=first.replace(/^#{1,6}\s*/,'').replace(/[*_`]/g,'').replace(/[。！？!?]+$/,'').trim();
   const title=Array.from(plain||sub.q).slice(0,40).join(''),rest=answer.slice(first.length).trim();
   const chartRendered=sub.id===item.headline?'':chartHtml(sub.section?.chart,sub.shape);
   const tableRendered=sub.section?tableHtml(sub.section):'';
   const vizBlock=!readonly&&sub.section&&chartRendered
    ?`<div class="lr-viz-card" data-viz-card="${esc(sub.id)}"><div class="lr-viz-tabs" role="tablist"><button type="button" class="lr-viz-btn active" data-viz-tab="chart" role="tab" aria-selected="true">可视化图表</button><button type="button" class="lr-viz-btn" data-viz-tab="table" role="tab" aria-selected="false">数据对照表</button></div><div class="lr-viz-panel" data-viz-pane="chart">${chartRendered}</div><div class="lr-viz-panel" data-viz-pane="table" hidden>${tableRendered}</div></div>`
    :(chartRendered+tableRendered);
   return `<section class="rs-sec" id="lr-sub-${esc(sub.id)}"><h4>${i+1}. ${inline(title)}</h4><p class="q">${inline(String(sub.q||'').split(/[：:]/)[0])} · ${esc(sub.shape)}</p>${sub.section?(rest?markdown(rest):'')+vizBlock:'<p class="quiet">'+(sub.state==='failed'?'未完成，继续后重试':'正在研究')+'</p>'}</section>`;
  };
  const meta=[item.meetingTitle,dated(item.completedAt||item.deepStartedAt||item.openedAt)?`${dated(item.completedAt||item.deepStartedAt||item.openedAt)} ${clock(item.completedAt||item.deepStartedAt||item.openedAt)}`:'',item.effort==='exhaustive'?'完整版':'一页版',duration(item)].filter(Boolean).join(' · ');
  let stickyHeader='';
  if(!readonly){
   const ho=handoff||{},openMenu=ho.menu||'',nst=ho.notion||{},synced=nst.syncedOutputs?.[ho.meetingKey]||(ho.itemKey&&nst.syncedOutputs?.[ho.itemKey]);
   const mcp=ho.mcp||{},clients=list(mcp.clients);
   const notionBtnText=ho.notionBusy?'正在同步 Notion…':synced?'更新 Notion':nst.authorized?'导入 Notion':'连接 Notion';
   const aiPop=`<div class="lr-ho-pop" data-pop="ai"${openMenu==='ai'?'':' hidden'}>`+
    `<div class="lr-ho-sec"><strong>⚡ 一键连接本机 AI (MCP)</strong><p class="lbl">${mcp.status==='connected'||mcp.status==='profile_received'?'本机 MCP 已就绪':'探测并写入本机 AI 客户端配置，无需复制粘贴'}</p>`+
    (clients.length?`<div class="lr-ho-clients">${clients.map(c=>`<button type="button" class="lr-ho-chip${c.configured?' ok':''}" data-lr="mcp-autoconnect" data-item="${esc(item.id)}" data-client="${esc(c.id)}">${c.configured?'✓ ':''}${esc(c.label||c.id)}</button>`).join('')}</div>`:'')+
    `</div><div class="lr-ho-sec"><button type="button" class="lr-ho-row" data-lr="ai-item" data-item="${esc(item.id)}">生成本机 MCP 交接凭据</button>${btn('copy','复制给我的 AI 研究',item.id,'lr-ho-row')}</div>`+
    (ho.mcpMsg?`<p class="lr-ho-msg" role="status">${esc(ho.mcpMsg)}</p>`:'')+`</div>`;
   const parentOpts=list(nst.candidateParents).length?`<select class="lr-ho-select" data-lr-parent aria-label="Notion 目标页面">${list(nst.candidateParents).map(p=>`<option value="${esc(p.id)}"${p.id===nst.parentId?' selected':''}>${esc(p.title||p.id)}</option>`).join('')}</select>`:'';
   const sharePop=`<div class="lr-ho-pop" data-pop="share"${openMenu==='share'?'':' hidden'}>`+
    `<button type="button" class="lr-ho-row" data-lr="export-html" data-item="${esc(item.id)}">导出离线 HTML (单文件)</button>`+
    `${btn('share','生成 24h 阅后即焚链接',item.id,'lr-ho-row')}`+
    `<button type="button" class="lr-ho-row" data-lr="mirror-local" data-item="${esc(item.id)}">写入本机文件夹</button>`+
    `<button type="button" class="lr-ho-row" data-lr="export-md" data-item="${esc(item.id)}">下载 Markdown (.md)</button>`+
    (nst.authorized&&parentOpts?`<div class="lr-ho-sec"><span class="lbl">Notion 存放页面</span>${parentOpts}</div>`:'')+
    (synced?.url?`<a class="lr-ho-row" href="${esc(safeUrl(synced.url))}" target="_blank" rel="noopener noreferrer">在 Notion 打开页面 ↗</a>`:'')+
    (ho.shareMsg?`<p class="lr-ho-msg" role="status">${esc(ho.shareMsg)}</p>`:'')+`</div>`;
   stickyHeader=`<div class="lr-art-sticky"><div class="rbar lr-art-head">${btn('back','← 返回','','lr-back-btn')}<span class="lr-art-badges"><span class="lr-effort-badge">${item.effort==='exhaustive'?'完整版':'一页版'}</span>${item.tier==='max'&&item.deepStarted&&!item.exhaustiveStarted?effortBtn('exhaustive',item.id):''}</span><button type="button" class="lr-wide-btn" data-lr="toggle-wide" title="展开/还原阅读画布" aria-label="展开/还原阅读画布">⤢</button></div><div class="lr-handoff-bar"><div class="lr-ho-group"><button type="button" class="lr-ho-btn primary" data-lr="handoff-ai" data-item="${esc(item.id)}" aria-expanded="${openMenu==='ai'}">⚡ 交给我的 AI ▾</button>${aiPop}</div><div class="lr-ho-group"><button type="button" class="lr-ho-btn${synced?' synced':''}" data-lr="notion-sync" data-item="${esc(item.id)}" ${ho.notionBusy?'disabled':''}>${esc(notionBtnText)}</button>${synced?.url?`<a class="lr-notion-open" href="${esc(safeUrl(synced.url))}" target="_blank" rel="noopener noreferrer" title="打开 Notion 页面">↗</a>`:''}</div><div class="lr-ho-group"><button type="button" class="lr-ho-btn" data-lr="handoff-share" data-item="${esc(item.id)}" aria-expanded="${openMenu==='share'}">↗ 分享与流转 ▾</button>${sharePop}</div></div>${ho.notionMsg?`<div class="lr-ho-banner" role="status">${esc(ho.notionMsg)}</div>`:''}</div>`;
  }
  const askDock=readonly?'':`<div class="lr-ask-dock"><div class="lr-ask-chips">${['继续深挖竞品定价','补充落地风险与对策','提炼成 3 条老板汇报要点'].map(q=>`<button type="button" class="lr-ask-chip" data-lr="quick-ask" data-item="${esc(item.id)}" data-q="${esc(q)}">${esc(q)}</button>`).join('')}</div><form class="ask" data-lr-form="ask" data-item="${esc(item.id)}"><input name="text" placeholder="基于当前报告继续追问…" aria-label="接着问" required><button class="solid" type="submit">接着问</button></form></div>`;
  const heroBlock=item.fastCard&&!item.fullExpanded?fastCardHtml(item,{readonly}):(executiveBriefHtml(item,{readonly})||`<div class="hero"><div class="hk">一句话结论</div><div class="hv">${markdown(item.conclusion||'正在研究')}</div></div>`);
  const quietBreakdown=!!item.fastCard&&!item.fullExpanded&&['fact_check','blind_spot','external_case'].includes(cardKindOf(item));
  return `<div class="side">${stickyHeader}<h3 class="rq">${inline(item.title)}</h3><div class="rmeta">${esc(meta)}</div>${item.fastCard&&!item.fullExpanded||quietBreakdown?'':`<ol class="subidx">${list(item.subs).map(s=>`<li><a href="#lr-sub-${esc(s.id)}">${inline(s.q)}</a></li>`).join('')}</ol>`}${heroBlock}${quietBreakdown?'':chartHtml(headline?.section?.chart,headline?.shape)}${quietBreakdown?'':list(item.subs).map(renderSection).join('')}<div class="rs-sec"><h4>来源</h4><ol class="sources">${list(item.sources).map(s=>{const label=safeSrcLabel(s.src||s.title,s.url)||s.title||'';return `<li id="lr-source-${esc(s.id)}">${safeUrl(s.url)?`<a href="${esc(safeUrl(s.url))}" target="_blank" rel="noopener noreferrer">${inline(label)}</a>`:inline(label)}</li>`;}).join('')}</ol></div>${!quietBreakdown&&list(item.subs).length?`<details><summary>完整版：维度树、来源</summary><ul class="tree">${list(item.subs).map(s=>`<li><b>${inline(s.q)}</b><span>${list(s.dims).map(inline).join(' · ')}</span></li>`).join('')}</ul></details>`:''}${list(item.followups).map(f=>`<div class="ans"><div class="lab"><b>接着问</b>${readonly?'':`<time>${clock(f.at)}</time>`}</div><p><b>${inline(f.title||f.q)}</b></p>${f.section?markdown(f.section.answer)+tableHtml(f.section):'<p class="quiet">'+(f.state==='failed'?'未完成，继续后重试':'接着研究中，结果追加在这里。')+'</p>'}</div>`).join('')}${askDock}</div>`;
 }
// 头像取字：小/老/阿开头的中文名取末字；其他中文名取首字；拉丁名取首字母大写；「你」原样。
function avatarChar(name){const n=String(name||'').trim();if(!n)return '未';if(n==='你')return '你';const cs=Array.from(n);if(/^[A-Za-z]/.test(n))return cs[0].toUpperCase();if(cs.length>1&&/^[小老阿]/.test(n))return cs[cs.length-1];return cs[0];}
 const personColor=name=>['var(--gb)','var(--gr)','var(--gg)','var(--gy)'][Array.from(String(name||'')).reduce((n,c)=>(n*31+c.charCodeAt(0))%997,0)%4];
 const MINUTE_LEAD_INS=['会上卡在哪：','已知的做法和数据：','对这场会的含义：','进展：','结论：','决策：','风险：','未决问题：','核心摘要：'];
 function minuteBare(raw){return String(raw??'').trim().replace(/^(?:[-*•]|\d+\.)\s+/,'');}
 function minuteRule(raw){return /^(?:---|\*\*\*|___)$/.test(minuteBare(raw));}
 function minuteAction(raw){
  const m=minuteBare(raw).match(/^(?:\*\*)?(行动|Action|アクション)([：:])(?:\*\*)?\s*([\s\S]*)$/i);
  if(!m)return null;
  const word=/^action$/i.test(m[1])?'Action':m[1];
  return {label:word==='Action'?'Action:':word+'：',rest:(m[3]||'').replace(/^\s+/,'')};
 }
 function minuteLead(raw){
  const t=minuteBare(raw);
  for(const label of MINUTE_LEAD_INS){
   for(const form of [label,label.slice(0,-1)+':']){
    if(t.startsWith(form))return {label,rest:t.slice(form.length).replace(/^\s+/,'')};
    const wrapped='**'+form+'**';
    if(t.startsWith(wrapped))return {label,rest:t.slice(wrapped.length).replace(/^\s+/,'')};
   }
  }
  return null;
 }
 function minuteTopic(raw,{atStart=false,afterRule=false,editorial=false}={}){
  const t=String(raw??'').trim();
  if(/^#{1,3}\s+\S/.test(t))return true;
  if(!editorial||!(atStart||afterRule)||!t||minuteRule(t)||minuteAction(t)||minuteLead(t))return false;
  if(/^(?:[-*•]|\d+\.)\s+/.test(t)||/[：:.。]/.test(t))return false;
  return Array.from(t).length<=42;
 }
 function discussionHtml(items,editorial,plain){
  const rows=list(items),wrap=html=>plain?`<span style="white-space:pre-wrap">${html}</span>`:html;
  return rows.map((raw,i)=>{
   const text=String(raw??''),trimmed=text.trim();
   if(!trimmed)return '';
   const prev=i>0?String(rows[i-1]??'').trim():'';
   if(minuteRule(trimmed))return '<hr class="cs-divider">';
   if(minuteTopic(trimmed,{atStart:i===0,afterRule:minuteRule(prev),editorial}))return `<h5 class="cs-topic-h">${inline(trimmed)}</h5>`;
   const action=minuteAction(trimmed);
   if(action)return `<p class="cs-action-callout"><strong>${esc(action.label)}</strong>${inline(action.rest)}</p>`;
   const lead=minuteLead(trimmed);
   if(lead){
    const body=`<strong>${esc(lead.label)}</strong>${inline(lead.rest)}`;
    return editorial?`<p class="cs-minute-line">${body}</p>`:`<p class="gli"><i></i><span>${body}</span></p>`;
   }
   if(!editorial)return `<p class="gli"><i></i><span>${inline(text)}</span></p>`;
   return `<p class="cs-minute-line">${wrap(inline(minuteBare(trimmed)))}</p>`;
  }).join('');
 }
 function minutesHtml(minutes,{select=false,readonly=false}={}){
  const plain=minutes.format==='plain-text-v1',editorial=readonly===true||plain;
  const check='<svg class="conclusion-check" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m3 8 3 3 7-7"/></svg>';
  const hasStructuredMd=!plain&&typeof minutes.markdown==='string'&&/^#{1,3}\s+/m.test(minutes.markdown);
  const summaryBlock=hasStructuredMd
   ? `<div class="lr-minutes-md">${markdown(minutes.markdown)}</div>`
   : `${!readonly||list(minutes.discussion).length?'<div class="mt">讨论了什么</div>':''}${discussionHtml(minutes.discussion,editorial,plain)}${!readonly||list(minutes.conclusions).length?'<div class="mt">结论</div>':''}${list(minutes.conclusions).map(x=>`<p class="gli">${check}<span>${plain?`<span style="white-space:pre-wrap">${inline(x)}</span>`:inline(x)}</span></p>`).join('')}`;
  return `${minutes.notice?`<p class="hint" role="status">${inline(minutes.notice)}</p>`:''}${summaryBlock}${!readonly||list(minutes.todos).length?'<div class="mt">待办</div>':''}${list(minutes.todos).map(t=>{const col=personColor(t.owner);return `<div class="todo">${readonly||select?'':`<input type="checkbox" data-todo-done="${esc(t.id)}" aria-label="完成待办" ${t.done?'checked':''}>`}<span class="av" style="background:${col};${col==='var(--gy)'?'color:var(--avatar-ink)':''}" aria-hidden="true">${esc(avatarChar(t.owner))}</span><div class="todo-body">${readonly||select?`<span class="tt">${inline(t.text)}</span>`:`<input class="ed tt" data-todo="${esc(t.id)}" data-field="text" aria-label="待办内容" value="${esc(t.text)}">`}<span class="who">${readonly?`${inline(t.owner||'未指定')} · ${inline(t.due?t.due.replaceAll('-','/'):'未定日期')}`:`<input class="ed o" data-todo="${esc(t.id)}" data-field="owner" aria-label="负责人" value="${esc(t.owner)}" ${select?'readonly tabindex="-1"':''}><label class="lr-date pill2"><i style="background:${col}"></i><span aria-hidden="true">${inline(t.due?t.due.replaceAll('-','/'):'未定日期')}</span><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" aria-hidden="true"><rect x="2" y="3" width="12" height="11" rx="1"/><path d="M2 6h12M5 1v4M11 1v4"/></svg><input class="ed d" type="date" data-todo="${esc(t.id)}" data-field="due" aria-label="日期" value="${esc(t.due)}" ${select?'readonly tabindex="-1"':''}></label>`}</span></div>${readonly||select?'':btn('todo-delete','×',t.id,'quiet')}</div>`;}).join('')}${readonly||select?'':btn('todo-add','＋ 添加待办','','quiet')}`;
 }
 function miniHtml(item){
  const sub=list(item.subs).find(s=>s.id===item.headline),c=sub?.section?.chart;if(!c||!chartHtml(c,sub.shape))return '';
  if(sub.shape==='定位'){
   const values=list(c.marks).map(m=>m.value),lo=Math.min(...values),hi=Math.max(...values),v=c.self?.value,min=c.min??0,max=c.max;
   if(!values.length||!number(v)||!number(max)||max<=min)return '';
   const pos=x=>clamp((x-min)/(max-min)*100,0,100),unit=c.unit||'',label=`${c.self.label||'我们'} ${v}${unit} · 行业 ${lo}–${hi}${unit}`;
   return `<div class="mini" role="img" aria-label="${esc(label)}"><span class="mtrack"><i class="mband" style="left:${pos(lo)}%;width:${pos(hi)-pos(lo)}%"></i><i class="mmark" style="left:${pos(v)}%;background:var(--gb)"></i></span><span class="mlab">${inline(c.self.label||'我们')} <b style="color:var(--gb)">${v}${esc(unit)}</b> · 行业 ${lo}–${hi}${esc(unit)}</span></div>`;
  }
  const bars=list(c.bars||c.parts).filter(b=>number(b.value)&&b.value>=0).slice(0,3);if(!bars.length)return '';const max=Math.max(1,...bars.map(b=>b.value));
  return `<div class="mini" role="img" aria-label="${esc(bars.map(b=>`${b.label} ${b.value}`).join('，'))}"><span class="mbars">${bars.map((b,i)=>`<span>${inline(b.label)}<s><u style="width:${b.value/max*100}%;background:${['var(--gb)','var(--gy)','var(--gg)'][i]}"></u></s>${b.value}</span>`).join('')}</span></div>`;
 }
 const researchStatus=i=>i.state==='done'?(i.exhaustiveStarted||i.effort==='exhaustive'?['已穷举','var(--gg)']:['已深入','var(--gb)']):!i.deepStarted&&i.quickDone?['速查','var(--gy)']:['进行中','var(--gy)'];
 function meetingMeta(meta={}){const at=meta.start,date=dated(at),time=date?clock(at)+(meta.end?'–'+clock(meta.end):''):'',people=meta.people?`${meta.people} 人`:'';return [date&&`${date} ${time}`,people].filter(Boolean).join(' · ');}
 function canSendToAi(data){
  const start=Number(data?.meta?.start||0),end=Number(data?.meta?.end||0);
  if(start>0&&end>start&&(end-start)<180000)return false;
  const todoCount=list(data?.minutes?.todos).length;
  const researchCount=list(data?.items).filter(i=>i&&(i.state==='done'||i.conclusion)).length;
  const insightCount=list(data?.minutes?.conclusions).length+list(data?.minutes?.discussion).length;
  if(todoCount===0&&researchCount===0&&insightCount<3)return false;
  return true;
 }
 function outputHtml(data,ui={}){const hasMinutes=['discussion','conclusions','todos'].some(key=>list(data.minutes?.[key]).length>0),items=list(data.items);if(!hasMinutes&&!items.length&&!ui.deletedTodo)return '';const showAi=canSendToAi(data);return `<div class="side"><div class="bar lr-out-bar">${showAi?btn('ai-all','发给 AI','','lr-out-btn lr-out-ai'):''}${btn('share-all','分享','','lr-out-btn lr-out-share')}</div>${hasMinutes?'<div class="sec">纪要</div>'+minutesHtml(data.minutes||{}):''}${ui.deletedTodo?btn('todo-restore','已删除待办 · 撤销','','quiet'):''}${items.length?'<div class="sec">研究</div>':''}${items.map(i=>{
  const free=data.tier==='free',running=i.state==='running',queued=i.state==='queued',paused=i.state==='stopped'||!!i.pause,failed=i.state==='failed',interrupted=i.state==='interrupted',done=i.state==='done';
  const label=free?'未研究':interrupted?'已中断':paused?'已暂停':failed?'研究失败':done?'已完成':queued?'排队中':running?'进行中':i.state==='planned'?'速查完成':'待继续';
  const control=free||done?'':running||queued?btn('stop',`${running?'<i class="spin" aria-hidden="true"></i>':''}<span>暂停</span>`,i.id,'quiet'):paused||failed||interrupted||i.state==='partial'?btn('resume',failed||interrupted||i.state==='partial'?'重试':'继续',i.id,'quiet'):'';
  return `<div class="rrow"><span>${free||!researchPresentation(i).hasReport?inline(i.title):btn('report',inline(i.title),i.id)}</span><span class="st">${label}</span>${control?`<div class="acts">${control}</div>`:''}${free?upgrade():i.conclusion?`<span class="c">${markdown(i.conclusion)}</span>`:''}</div>`;
 }).join('')}</div>`;}

 function afterHtml(data,ui={}){
  const sm=!!ui.select,sel=ui.selected||new Set(),free=data.tier==='free',ck=k=>sm&&(!free||k==='minutes')?`<span class="ck"><input type="checkbox" ${sel.has(k)?'checked':''} aria-label="选择这一项" tabindex="-1"></span>`:'<span></span>',m=data.minutes||{};
  const uniqueItems=[];const seenItemTitle=new Set();
  for(const i of list(data.items)){
   const k=String(i.title||'').replace(/\s+/g,' ').trim().slice(0,40).toLowerCase();
   if(k&&seenItemTitle.has(k))continue;
   if(k)seenItemTitle.add(k);
   uniqueItems.push(i);
  }
  const hasResearch=uniqueItems.length>0,showAi=canSendToAi(data);
  return `<div class="pg g lr-granola${sm?' sm':''}"><div class="ph"><h3>${inline(data.title||'会议纪要')}</h3>${meetingMeta(data.meta)?`<div class="meta">${esc(meetingMeta(data.meta))}</div>`:''}<div class="bar" style="margin-top:14px">${sm?'<span class="quiet">勾选要分享的内容，点空白处或按 Esc 退出</span>':btn('select','选择')+(showAi?btn('ai-all','发给我的 AI'):'')+btn('share-all','分享纪要')}</div></div><section class="blk${sel.has('minutes')?' on':''}"${sm?' data-tg="minutes" tabindex="0" role="checkbox" aria-checked="'+sel.has('minutes')+'"':''}>${ck('minutes')}<div class="bd"><h4>会议纪要${sm?'':`<span class="a">${btn('share','分享','minutes')}</span>`}</h4>${ui.minutesHtml?.(data,ui)??minutesHtml(m,{select:sm})}</div></section>${hasResearch?`<section class="blk"><span></span><div class="bd"><h4>深度研究<small>${uniqueItems.length} 项</small></h4>${uniqueItems.map(i=>{const [label,col]=researchStatus(i);return `<div class="ri${sel.has(i.id)?' on':''}"${sm&&!free?' data-tg="'+esc(i.id)+'" tabindex="0" role="checkbox" aria-checked="'+sel.has(i.id)+'"':''}>${ck(i.id)}<div style="min-width:0"><div class="rst" style="color:${col}"><i style="background:${col}"></i>${label}</div><div class="t">${inline(i.title)}</div>${free?subsHtml(i,'free'):`<div class="c">${markdown(i.conclusion||i.quick?.answer||'进行中')}</div>${miniHtml(i)}`}${sm?'':`<div class="a" style="margin-top:10px">${free?upgrade():btn('report','打开报告 ›',i.id)+btn('copy','复制给我的 AI 研究',i.id)+btn('share','分享',i.id,'quiet')}</div>`}</div></div>`;}).join('')}</div></section>`:''}</div>${sm?`<div class="selbar"><span>已选 ${sel.size} 项</span>${btn('select-all',sel.size===(free?1:uniqueItems.length+1)?'取消全选':'全选')}<span class="grow">${btn('select-cancel','取消','','quiet')}<button class="solid" type="button" data-lr="share-selected" ${sel.size?'':'disabled'}>分享所选</button></span></div>`:''}`;
 }
 function snapshotHtml(snapshot){return `<div class="pg"><div class="ph"><h3>${inline(snapshot.title||'会议分享')}</h3></div><ol class="subidx">${list(snapshot.items).map((x,i)=>`<li><a href="#shared-${i}">${x.kind==='minutes'?'纪要':inline(x.report.title)}</a></li>`).join('')}</ol>${list(snapshot.items).map((x,i)=>`<section class="blk" id="shared-${i}"><span></span><div class="bd">${x.kind==='minutes'?'<h4>纪要</h4>'+minutesHtml(x.minutes,{readonly:true}):reportHtml(x.report,{readonly:true})}</div></section>`).join('')}</div>`;}
 function popHtml(pop){
  if(!pop)return '';let body='';
  const head=t=>`<div class="hd"><h5>${t}</h5>${btn('close','关闭','','x')}</div>`;
  if(pop.kind==='upgrade')body=head('订阅后可深度研究')+'<p class="lbl">会上提出的问题自动拆题、穷举取证、出报告，还能补一句、接着问、复制给你的 AI。</p><div class="plans">'+[['Pro','$24','每月 15 小时会议','标准模型，3–5 个子问题加要点表'],['Max','$59','每月 30 小时会议','更聪明的模型，穷举级研报：维度树、逐项出处、间接获取手段']].map(p=>`<div class="plan"><b>${p[0]}</b><span class="pr">${p[1]}<small>/月</small></span><span class="q">${p[2]}</span><span class="q">${p[3]}</span>${btn('close','订阅','','solid')}</div>`).join('')+'</div><p class="lbl">价格待定，示例</p>';
  else if(pop.kind==='share-confirm')body=head(pop.target==='ai'?'发给我的 AI':'分享成果')+`<div class="bar">${btn('share-check-all','全选')}${btn('share-check-none','取消全选')}</div>${pop.hasMinutes?`<p><label><input type="checkbox" data-share-part="minutes" ${pop.minutes?'checked':''}> 纪要</label></p>${list(pop.todoItems).length?`<p><label><input type="checkbox" data-share-part="todos" ${pop.todos?'checked':''}> 待办</label></p>${list(pop.todoItems).map(t=>`<p><label><input type="checkbox" data-share-todo="${esc(t.id)}" ${pop.todoIds.has(t.id)?'checked':''}> ${inline(t.text)} · ${inline(t.owner||'未指定')} · ${inline(t.due||'未定日期')}</label></p>`).join('')}`:''}`:''}${list(pop.research).map(i=>`<p><label><input type="checkbox" data-share-research="${esc(i.id)}" ${pop.researchIds.has(i.id)?'checked':''}> ${inline(i.title)}</label></p>`).join('')}${pop.target==='ai'?'<p class="lbl">仅保存在本机 · 主动点分享后才生成云端链接；本次仅授权所选成果，不含完整转写。你的 AI 使用自己的连接器，外发前需再次确认。</p><textarea data-ai-intent aria-label="交给 AI 的任务">'+esc(pop.intent)+'</textarea>':''}${pop.target==='ai'?'':`<p><label>有效期 <select data-share-hours aria-label="分享有效期"><option value="24" ${pop.hours===24?'selected':''}>24 小时</option><option value="48" ${pop.hours===48?'selected':''}>48 小时</option></select></label></p>`}<p class="lbl">${pop.target==='ai'?'本机授权24小时后失效，可随时撤销。':'不包含完整转写，也不会自动更新。到期停止访问并安排删除分享副本；接收人已下载或截图的内容无法收回。不是「看过一次即删除」。'}</p>${pop.error?`<p role="status">${esc(pop.error)}</p>`:''}<div class="row">${btn('close','取消','','quiet')}<button type="button" class="solid" data-lr="share-confirm" ${pop.busy?'disabled':''}>${pop.busy?'正在创建…':pop.target==='ai'?'准备交接':'创建链接'}</button></div>`;
  else if(pop.kind==='ai-mcp'){
   const clients=list(pop.mcp?.clients);
   const rows=clients.length
    ? clients.map(c=>`<div class="rrow" style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 0"><span><strong>${esc(c.label||c.id)}</strong>${c.configured?' <small style="color:#10b981">✓ 已连接</small>':c.detected?' <small class="lbl">已检测到</small>':''}</span><button type="button" class="${c.configured?'quiet':'solid'}" data-lr="mcp-autoconnect" data-client="${esc(c.id)}" ${pop.busy?'disabled':''}>${c.configured?'重新连接':'一键连接'}</button></div>`).join('')
    : '<p class="lbl">正在检测本机 AI 客户端（Antigravity / Claude Desktop / Cursor / Codex CLI）…</p>';
   body=head('发给我的 AI · MCP 一键直连')+'<p class="lbl">自动写入本机 MCP 配置，授权你的 AI 只读访问 Citeside 全部会议纪要、待办与研究报告（仅本机只读，随时可撤销）；若只想授权单场选中内容，请点下方「仅分享本场选中内容」。</p>'+rows+(pop.message?`<p role="status" style="color:#10b981;font-weight:500">${esc(pop.message)}</p>`:'')+(pop.error?`<p role="status">${esc(pop.error)}</p>`:'')+`<div class="row">${btn('ai-manual','仅分享本场选中内容','','quiet')}${btn('close','完成','','solid')}</div>`;
  }
  else if(pop.kind==='ai-ready')body=head('发给我的 AI')+`<p role="status">${pop.handover.status==='revoked'?'授权已撤销':pop.handover.status==='received'?'你的 AI 已读取所选成果':'待 AI 接收 · 尚未发送'}</p><p class="lbl">在支持本机 MCP 的 AI 中添加以下连接配置，然后让它调用 citeside_handover_read。连接仅可读取这次所选成果，24 小时后失效。读取回执不代表 Slack 等外部任务已执行。</p><textarea class="ptext" readonly aria-label="本机 MCP 连接配置">${esc(JSON.stringify(pop.mcpConfig,null,2))}</textarea>${pop.error?`<p role="status">${esc(pop.error)}</p>`:''}<div class="row">${btn('ai-status','检查接收状态')}${btn('ai-revoke','撤销授权','','quiet')}</div>`;
  else if(pop.kind==='copy')body=head('复制给我的 AI 研究')+`<p class="lbl">可以直接改下面的文字，也可以在下面告诉 AI 怎么改。</p><textarea class="ptext" data-copy-text aria-label="要复制的内容">${esc(pop.text)}</textarea><form class="rw" data-lr-form="rewrite-prompt" data-item="${esc(pop.itemId)}"><input name="instruction" autocomplete="off" placeholder="告诉 AI 怎么改，比如：只要美国数据、加上竞品 Chewy" aria-label="告诉 AI 怎么改" value="${esc(pop.instruction||'')}" ${pop.busy?'disabled':''}>${pop.busy?'<span class="spin" role="status" aria-label="改写中"></span>':''}</form>${pop.error?`<small class="rewrite-error" role="status">${esc(pop.error)}</small>`:''}<div class="row">${btn('copy-again',pop.message||'复制','','solid')}</div>`;
  else body=head(pop.revoked?'链接已撤销':`已生成${list(pop.snapshot?.items).length>1?' '+pop.snapshot.items.length+' 项的合集':'分享'}链接`)+`<div><p class="lbl">包含</p><ul>${list(pop.snapshot?.items).map(x=>`<li>${x.kind==='minutes'?'纪要（讨论了什么、结论、待办）':inline(x.report.title)}${x.kind==='minutes'?'<ul>'+list(x.minutes.todos).map(t=>`<li>${inline(t.text)}：${inline(t.owner||'未指定')} · ${inline(t.due?t.due.replaceAll('-','/'):'未定日期')}</li>`).join('')+'</ul>':''}</li>`).join('')}</ul></div><div><p class="lbl">不包含</p><ul>${list(pop.excluded).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>${pop.revoked?'<p class="lbl">链接已撤销，打开的人会看到「链接已失效」。</p>':`<b class="toast">${esc(pop.message||'已复制链接')}</b><div class="link">${esc(pop.url)}</div><p class="lbl">${pop.cloud?`云端只读快照，${esc(new Date(pop.expiresAt).toLocaleString())} 到期失效。`:'本机只读链接，尚未部署云端服务。'}</p><div class="row">${btn('revoke','撤销链接','','quiet')}</div>`}`;
  return `<div class="scrim" data-lr="close"><div class="pop" role="dialog" aria-modal="true" aria-label="${pop.kind==='upgrade'?'订阅':pop.kind==='copy'?'复制给我的 AI 研究':'分享'}">${body}</div></div>`;
 }
 function install(win){
  const doc=win.document;if(!doc)return;
  const ui={id:'',data:null,note:'',expanded:'',report:'',deletedTodo:'',select:false,selected:new Set(),pop:null,epoch:0,flash:false,handoff:{menu:'',loadedFor:'',mcp:null,notion:null,notionBusy:false,mcpMsg:'',notionMsg:'',shareMsg:''}};
  let timer=0,pollTimer=0,busy=false,base=()=>'/asr-relay',token=()=>{const query=new URLSearchParams(win.location.search).get('token');if(query)return query;try{return JSON.parse(win.localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{return '';}};
  const afterHosts=new Set(),reportHosts=new Map(),bound=new WeakSet();
  const current=()=>ui.id||win.thtViewedMeetingId||new URLSearchParams(win.location.search).get('id')||'';
  const item=id=>list(ui.data?.items).find(i=>i.id===id);
  const url=()=>base()+'/live-research?id='+encodeURIComponent(current())+'&token='+encodeURIComponent(token());
  const request=async(body)=>{const id=current(),ep=ui.epoch,r=await win.fetch(url(),{method:body?'POST':'GET',cache:'no-store',headers:{'x-tht-token':token(),...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify({id,...body})}:{}),signal:AbortSignal.timeout(body?90000:15000)}),j=await r.json();if(!r.ok)throw Error(j.error||'请求失败');return {j,id,ep};};
  const apiFetch=async(path,body)=>{const full=(path.startsWith('/setup/')?'':base())+path;const sep=full.includes('?')?'&':'?';const r=await win.fetch(full+sep+'token='+encodeURIComponent(token()),{method:body?'POST':'GET',cache:'no-store',headers:{'x-tht-token':token(),...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});const j=await r.json().catch(()=>({}));if(!r.ok||j?.ok===false)throw Error(j?.error||'请求失败');return j;};
  const handoffFor=id=>({...ui.handoff,meetingKey:current()+':'+id,itemKey:id});
  function triggerDownload(filename,mime,text){try{const blob=new win.Blob([text],{type:mime});const u=win.URL.createObjectURL(blob);const a=doc.createElement('a');a.href=u;a.download=filename;doc.body.append(a);a.click();a.remove();win.setTimeout(()=>win.URL.revokeObjectURL(u),1000);return true;}catch{return false;}}
  async function loadHandoffStatus(force=false){const cid=current();if(!cid||typeof win.fetch!=='function')return;if(!force&&ui.handoff.loadedFor===cid)return;ui.handoff.loadedFor=cid;try{const [mcp,notion]=await Promise.all([apiFetch('/setup/mcp-connection').catch(()=>null),apiFetch('/notion-outputs/status?meetingId='+encodeURIComponent(cid)+'&includeParents=1').catch(()=>null)]);if(current()!==cid)return;if(mcp)ui.handoff.mcp=mcp;if(notion)ui.handoff.notion=notion;paint();}catch{}}
  const accept=(j,id,ep)=>{if(ep!==ui.epoch||id!==current()||j.id!==id)return false;const changed=JSON.stringify(j)!==JSON.stringify(ui.data);ui.data=j;if(changed){paint();win.dispatchEvent(new win.CustomEvent('tht-live-research-updated',{detail:j}));}return true;};
  function terminal(){return !!ui.data&&ui.data.ended&&list(ui.data.items).every(i=>i.state==='stopped'||(['done','partial','failed','planned'].includes(i.state)&&list(i.followups).every(f=>['done','failed'].includes(f.state))));}
  function schedule(){win.clearTimeout(timer);timer=0;if(!terminal()&&current())timer=win.setTimeout(load,1500);}
  async function load(){if(!current()||busy)return;busy=true;try{const {j,id,ep}=await request();accept(j,id,ep);}catch{}finally{busy=false;schedule();}}
  function switchTo(id){if(ui.id===String(id))return;ui.epoch++;win.clearTimeout(timer);win.clearTimeout(pollTimer);Object.assign(ui,{id:String(id||''),data:null,note:'',expanded:'',report:'',deletedTodo:'',select:false,selected:new Set(),pop:null,handoff:{menu:'',loadedFor:'',mcp:null,notion:null,notionBusy:false,mcpMsg:'',notionMsg:'',shareMsg:''}});try{const saved=JSON.parse(win.sessionStorage?.getItem('citeside-meeting-view-v1')||'null');if(saved?.version===1&&saved.sessionId===ui.id)ui.expanded=list(saved.expandedIds)[0]||'';}catch{}paint();}
  function renderHost(host,html){if(host.dataset.lrSignature===html)return;const active=host.contains(doc.activeElement)?doc.activeElement:null;const field=active&&/INPUT|TEXTAREA/.test(active.tagName)?{copy:active.matches?.('[data-copy-text]')?'text':active.name==='instruction'?'instruction':'',todo:active.dataset.todo,kind:active.dataset.field,form:active.closest('[data-lr-form]')?.dataset.lrForm,value:active.value,start:active.selectionStart,end:active.selectionEnd,before:active.dataset.before}:null;host.dataset.lrSignature=html;const scroll=host.scrollTop;host.innerHTML=html;host.scrollTop=scroll;bind(host);if(field){const el=field.copy?host.querySelector(field.copy==='text'?'[data-copy-text]':'[name="instruction"]'):field.todo?host.querySelector('[data-todo="'+field.todo+'"][data-field="'+field.kind+'"]'):host.querySelector('[data-lr-form="'+field.form+'"] [name="text"]');if(el){if(!field.copy)el.value=field.value;el.focus();el.dataset.before=field.before;try{el.setSelectionRange(field.start,field.end);}catch{}}}}
  function mountFeed(host){
   if(!host||!ui.data)return;
   const ids=new Set();for(const i of ui.data.items){ids.add(i.id);for(const f of list(i.followups))ids.add(f.id);}
   for(const n of host.querySelectorAll('[data-lr-item]'))if(!ids.has(n.dataset.lrItem))n.remove();
   for(const i of ui.data.items){
    const entries=[[i.id,researchItem(i,ui.data.tier,ui)],...(ui.data.tier==='free'?[]:list(i.followups).map(f=>[f.id,followupItem(i,f)]))];
    for(const [id,html] of entries){let n=[...host.children].find(x=>x.dataset.lrItem===id);if(!html){n?.remove();continue;}if(n?.dataset.lrHtml===html)continue;
     // Preserve a form the user is typing in across background state changes.
     const active=n?.contains(doc.activeElement)?doc.activeElement:null,draft=active&&'value'in active?active.value:null;
     const tpl=doc.createElement('template');tpl.innerHTML=html;const next=tpl.content.firstElementChild;next.dataset.lrHtml=html;
     if(n)n.replaceWith(next);else host.append(next);bind(next);
     if(active&&draft!==null){const field=next.querySelector('textarea');if(field){field.value=draft;field.focus();}}
    }
   }
   host.hidden=!host.children.length;
  }
  function paint(){
   mountFeed(doc.querySelector('#myagent-panel .ma-insights'));
   for(const host of afterHosts){if(!host.isConnected){afterHosts.delete(host);continue;}const i=item(ui.report),data=ui.data||{id:current(),items:[],minutes:{}};renderHost(host,i?reportHtml({...i,meetingTitle:data.title},{handoff:handoffFor(i.id)}):afterHtml(data,{...ui,minutesHtml:afterOptions.get(host)?.minutesHtml}));}
   for(const [host,rid] of reportHosts){if(!host.isConnected){reportHosts.delete(host);continue;}const i=item(rid),data=ui.data||{id:current(),items:[],minutes:{}};if(i)renderHost(host,reportHtml({...i,meetingTitle:data.title},{handoff:handoffFor(i.id)}));}
   let modal=doc.getElementById('lr-pop-host');if(!modal){modal=doc.createElement('div');modal.id='lr-pop-host';modal.className='lr-scope';doc.body.append(modal);bind(modal);}
   renderHost(modal,popHtml(ui.pop));
  }
  async function post(body){const targetId=body?.id||win.thtViewedMeetingId;if(targetId&&current()!==targetId){switchTo(targetId);}const {j,id,ep}=await request(body);if(ep!==ui.epoch||id!==current())return j;if(j&&j.id)accept(j,id,ep);schedule();return j;}
  async function copied(text,kind){try{await win.navigator.clipboard.writeText(text);return kind;}catch{return '复制失败，请手动复制下方内容';}}
  function share(keys,target='share'){const research=list(ui.data?.items).filter(i=>keys.includes(i.id)&&i.state==='done'),hasMinutes=keys.includes('minutes'),todoItems=list(ui.data?.minutes?.todos),hasTodos=todoItems.length>0;const defaultIntent=hasTodos?'处理选中的待办；向外发送前让我确认渠道、负责人和内容。':'基于本次会议纪要整理知识卡片，并列出 3 个值得继续追问的下一步问题。';ui.pop={kind:'share-confirm',target,intent:defaultIntent,hasMinutes,minutes:hasMinutes,todos:hasMinutes&&hasTodos,todoItems,todoIds:new Set(todoItems.map(t=>t.id)),research,researchIds:new Set(research.map(i=>i.id)),hours:24};paint();}
  async function confirmShare(){const pop=ui.pop;if(pop?.kind!=='share-confirm'||pop.busy)return;const keys=[...(pop.hasMinutes&&(pop.minutes||pop.todos)?['minutes']:[]),...pop.researchIds];if(!keys.length||(!pop.minutes&&!(pop.todos&&pop.todoIds.size)&&!pop.researchIds.size)){pop.error='请选择有内容的成果';paint();return;}pop.busy=true;pop.error='';paint();try{const j=await post({action:pop.target==='ai'?'ai-handover':'share',intent:pop.intent,cloud:true,keys,hours:pop.hours,parts:{minutes:pop.minutes,todos:pop.todos,todoIds:[...pop.todoIds]}});if(!j||ui.pop!==pop)return;if(pop.target==='ai'){ui.pop={...j,kind:'ai-ready'};return;}const link=new URL(j.url,win.location.origin).href;ui.pop={...j,kind:'share',url:link,message:await copied(link,'已复制链接')};}catch(e){if(ui.pop===pop)pop.error=e.message||'创建失败，请重试';}finally{pop.busy=false;paint();}}
  const allKeys=()=>['minutes',...(ui.data?.tier==='free'?[]:list(ui.data?.items).map(i=>i.id))];
  const exitSelect=()=>{ui.select=false;ui.selected.clear();paint();};
  const toggle=k=>{if(!allKeys().includes(k))return;ui.selected.has(k)?ui.selected.delete(k):ui.selected.add(k);paint();};
  async function act(a,id,node){
   if(win.thtViewedMeetingId&&current()!==win.thtViewedMeetingId){switchTo(win.thtViewedMeetingId);void load();return;}
   if(a==='todo-add'){await post({action:'todo-add',text:'新待办'});const fields=doc.querySelectorAll('[data-field="text"]');const field=fields[fields.length-1];field?.focus();field?.select();return;}
   if(a==='todo-delete'){await post({action:'todo-delete',todoId:id});ui.deletedTodo=id;paint();win.dispatchEvent(new win.CustomEvent('tht-live-research-updated',{detail:ui.data}));return;}
   if(a==='todo-restore'){await post({action:'todo-restore',todoId:ui.deletedTodo});ui.deletedTodo='';paint();win.dispatchEvent(new win.CustomEvent('tht-live-research-updated',{detail:ui.data}));return;}
   if(a==='close'){ui.pop=null;paint();return;}
   if(a==='upgrade'){ui.pop={kind:'upgrade'};paint();return;}
   if(a==='expand'){ui.expanded=ui.expanded===id?'':id;paint();return;}
   if(a==='note'){ui.note=id;paint();const field=doc.querySelector('textarea[aria-label="补一句研究方向"]');field?.focus();return;}
   if(a==='note-cancel'){ui.note='';paint();return;}
   if(['stop','resume','deep','exhaustive','expand-full'].includes(a)){await post({action:a,itemId:id});return;}
   if(a==='toggle-wide'){win.thtToggleArtifactWide?.();return;}
   if(a==='handoff-ai'){ui.handoff.menu=ui.handoff.menu==='ai'?'':'ai';ui.handoff.mcpMsg='';paint();void loadHandoffStatus(true);return;}
   if(a==='handoff-share'){ui.handoff.menu=ui.handoff.menu==='share'?'':'share';ui.handoff.shareMsg='';paint();void loadHandoffStatus(true);return;}
   if(a==='ai-item'){ui.handoff.menu='';return share([id],'ai');}
   if(a==='mcp-autoconnect'){const clientId=node?.dataset?.client||'';if(!clientId)return;const pop=ui.pop;if(pop?.kind==='ai-mcp'){pop.busy=true;pop.error='';pop.message='';paint();}try{const r=await apiFetch('/setup/mcp-connection/autoconnect',{clientId});const msg=r.ok!==false?('✓ 已自动配置 '+clientId):'配置未完成';ui.handoff.mcpMsg=msg;await loadHandoffStatus(true);if(ui.pop?.kind==='ai-mcp'){ui.pop.mcp=ui.handoff.mcp||r;ui.pop.message=msg;ui.pop.busy=false;paint();}}catch(e){ui.handoff.mcpMsg=e.message;if(ui.pop?.kind==='ai-mcp'){ui.pop.error=e.message;ui.pop.busy=false;}paint();}return;}
   if(a==='notion-sync'){
    const i=item(id);if(!i)return;
    if(!ui.handoff.notion){await loadHandoffStatus(true);}
    const nst=ui.handoff.notion||{};
    if(!nst.authorized){
     if(nst.oauthConfigured&&typeof win.open==='function'){
      win.open('/oauth/start/notion','_blank','noopener');
      ui.handoff.notionMsg='已打开 Notion 官方授权页，完成后自动刷新状态…';paint();
      let tries=0;const poll=()=>{win.clearTimeout(pollTimer);if(++tries>15)return;pollTimer=win.setTimeout(async()=>{await loadHandoffStatus(true);if(ui.handoff.notion?.authorized){ui.handoff.notionMsg='✓ Notion 已连接，可再次点击导入';paint();}else poll();},2000);};poll();
     }else{ui.handoff.notionMsg='请先在设置中连接 Notion OAuth 或配置 Token';paint();doc.getElementById('gear2')?.click?.();}
     return;
    }
    ui.handoff.notionBusy=true;ui.handoff.notionMsg='正在写入 Notion…';paint();
    try{
     const key=current()+':'+i.id;
     const payload={key,title:i.title||'Citeside 研究报告',conclusion:i.conclusion||'',sections:list(i.subs).filter(s=>s.section).map(s=>({title:s.q||'',shape:s.shape||'',answer:s.section?.answer||''})),rows:list(i.subs).flatMap(s=>list(s.section?.rows).map(r=>({cells:list(r.cells),cred:r.cred||''}))),sources:list(i.sources).map(s=>({id:s.id,title:s.title||s.url||'',url:safeUrl(s.url)})),markdown:markdownOfReport(i)};
     const res=await apiFetch('/notion-outputs/push',payload);
     ui.handoff.notion={...(ui.handoff.notion||{}),authorized:true,syncedOutputs:{...(ui.handoff.notion?.syncedOutputs||{}),[key]:{pageId:res.pageId,url:res.url,title:res.title,syncedAt:res.syncedAt}}};
     ui.handoff.notionMsg=res.unchanged?'Notion 内容已是最新':res.updated?'✓ 已增量同步到 Notion':'✓ 已导入 Notion';
    }catch(e){ui.handoff.notionMsg=e.message||'同步 Notion 失败';}finally{ui.handoff.notionBusy=false;paint();}
    return;
   }
   if(a==='export-html'){const i=item(id);if(!i)return;const stem=String(i.title||'citeside-report').replace(/[^\p{L}\p{N}_.-]+/gu,'-').replace(/^-+|-+$/g,'').slice(0,40)||'citeside-report';const ok=triggerDownload(stem+'.html','text/html;charset=utf-8',standaloneHtml({...i,meetingTitle:ui.data?.title}));ui.handoff.shareMsg=ok?'✓ 已导出离线 HTML 单文件':'当前环境不支持直接下载';paint();return;}
   if(a==='export-md'){const i=item(id);if(!i)return;const stem=String(i.title||'citeside-report').replace(/[^\p{L}\p{N}_.-]+/gu,'-').replace(/^-+|-+$/g,'').slice(0,40)||'citeside-report';const ok=triggerDownload(stem+'.md','text/markdown;charset=utf-8',markdownOfReport(i));ui.handoff.shareMsg=ok?'✓ 已下载 Markdown 文件':'当前环境不支持直接下载';paint();return;}
   if(a==='mirror-local'){const i=item(id);if(!i)return;try{const res=await apiFetch('/local-mirror',{action:'write',force:true,id:i.id,title:i.title||'citeside-report',markdown:markdownOfReport(i),html:standaloneHtml({...i,meetingTitle:ui.data?.title})});ui.handoff.shareMsg='✓ 已写入本机文件夹'+(res.files?.[0]?'：'+res.files[0]:'');}catch(e){ui.handoff.shareMsg=e.message||'写入本机目录失败';}paint();return;}
   if(a==='quick-ask'){const q=node?.dataset?.q;if(!q)return;await post({action:'ask',itemId:id,text:q});return;}
   if(a==='copy'){ui.handoff.menu='';const i=item(id);if(!i||ui.data.tier==='free')return;const pop={kind:'copy',itemId:id,text:i.copyText||'',instruction:'',message:''};ui.pop=pop;paint();if(ui.data.copyAuto!==false){const message=await copied(pop.text,'');if(ui.pop===pop&&message){pop.error=message;paint();}}return;}
   if(a==='copy-again'){const pop=ui.pop;if(pop?.kind==='copy'){pop.text=doc.querySelector('[data-copy-text]')?.value??pop.text;const message=await copied(pop.text,'已复制');if(ui.pop!==pop)return;if(message==='已复制')pop.message=message;else pop.error=message;paint();win.setTimeout(()=>{if(ui.pop===pop){pop.message='';paint();}},1600);}return;}
   if(a==='report'){
    if(ui.data?.tier==='free')return;ui.report=id;ui.select=false;ui.selected.clear();ui.handoff.menu='';
    if(win.thtOpenResearchReport){ui.report='';win.thtOpenResearchReport(id);}else paint();return;
   }
   if(a==='back'){ui.report='';ui.handoff.menu='';if(win.thtCloseResearchReport)win.thtCloseResearchReport();paint();return;}
   if(a==='select'){ui.select=true;ui.report='';paint();return;}
   if(a==='select-cancel'){exitSelect();return;}
   if(a==='select-all'){ui.selected=ui.selected.size===allKeys().length?new Set():new Set(allKeys());paint();return;}
   if(a==='ai-all'){ui.pop={kind:'ai-mcp',mcp:ui.handoff.mcp,busy:false,message:'',error:''};paint();try{const mcp=await apiFetch('/setup/mcp-connection');ui.handoff.mcp=mcp;if(ui.pop?.kind==='ai-mcp'){ui.pop.mcp=mcp;paint();}}catch(e){if(ui.pop?.kind==='ai-mcp'){ui.pop.error=e.message||'读取 MCP 状态失败';paint();}}return;}
   if(a==='ai-manual')return share(allKeys(),'ai');
   if(a==='ai-status'||a==='ai-revoke'){const p=ui.pop;if(p?.kind!=='ai-ready')return;try{const j=await post({action:a==='ai-status'?'ai-handover-status':'ai-handover-revoke',handoverId:p.handover.id});if(ui.pop===p){p.handover=j.handover;p.error='';if(a==='ai-revoke')p.error='授权已撤销';}}catch(e){p.error=e.message;}paint();return;}
   if(a==='share')return share([id]);if(a==='share-all')return share(allKeys());if(a==='share-selected')return share([...ui.selected]);
   if(a==='share-confirm')return confirmShare();
   if(a==='share-check-all'||a==='share-check-none'){const p=ui.pop;if(p?.kind==='share-confirm'){const on=a==='share-check-all';p.minutes=p.todos=on&&p.hasMinutes;p.todoIds=new Set(on?p.todoItems.map(t=>t.id):[]);p.researchIds=new Set(on?p.research.map(i=>i.id):[]);paint();}return;}
   if(a==='revoke'){const pop=ui.pop;await post({action:'unshare',token:pop.token});if(ui.pop===pop){pop.revoked=true;paint();}return;}
  }
  function error(host,e){let p=host.querySelector('.lr-error');if(!p){p=doc.createElement('p');p.className='lr-error status';p.setAttribute('role','status');host.append(p);}p.textContent=e.message||'未完成，请重试';}
  function bind(host){if(bound.has(host))return;bound.add(host);
   host.addEventListener('click',e=>{
    const vt=e.target?.closest?.('[data-viz-tab]');
    if(vt&&host.contains(vt)){
     const card=vt.closest?.('.lr-viz-card'),mode=vt.dataset?.vizTab;
     if(card&&mode){
      e.preventDefault();
      for(const b of card.querySelectorAll?.('[data-viz-tab]')||[]){const on=b===vt;b.classList?.toggle?.('active',on);b.setAttribute?.('aria-selected',String(on));}
      for(const p of card.querySelectorAll?.('[data-viz-pane]')||[]){p.hidden=p.dataset?.vizPane!==mode;}
     }
     return;
    }
    const srcA=e.target?.closest?.('a[href^="#lr-source-"]');
    if(srcA&&host.contains(srcA)){
     const targetEl=doc.getElementById?.(String(srcA.getAttribute('href')||'').slice(1));
     if(targetEl){e.preventDefault();targetEl.scrollIntoView?.({behavior:'smooth',block:'center'});targetEl.classList?.add('lr-src-flash');win.setTimeout(()=>targetEl.classList?.remove('lr-src-flash'),1800);}
     return;
    }
    if(ui.select&&!ui.pop){const tg=e.target.closest('[data-tg]');if(tg&&host.contains(tg)){e.preventDefault();e.stopPropagation();toggle(tg.dataset.tg);return;}}
    const b=e.target.closest('[data-lr]');if(!b||!host.contains(b))return;
    if(b.classList.contains('scrim')&&e.target!==b)return;e.preventDefault();e.stopPropagation();
    if(b.disabled)return;b.disabled=true;Promise.resolve(act(b.dataset.lr,b.dataset.item||'',b)).catch(err=>error(host,err)).finally(()=>{b.disabled=false;});
   });
   host.addEventListener('change',e=>{const t=e.target,p=ui.pop;if(t?.hasAttribute?.('data-lr-parent')){apiFetch('/notion-outputs/parent',{parentId:t.value,parentTitle:t.options?.[t.selectedIndex]?.text||''}).then(r=>{if(ui.handoff.notion){ui.handoff.notion.parentId=r.parentId;ui.handoff.notion.parentTitle=r.parentTitle;}ui.handoff.shareMsg='✓ 已切换 Notion 目标页';paint();}).catch(err=>{ui.handoff.shareMsg=err.message;paint();});return;}if(p?.kind==='share-confirm'){if(t.dataset.sharePart)p[t.dataset.sharePart]=t.checked;else if(t.dataset.shareTodo)t.checked?p.todoIds.add(t.dataset.shareTodo):p.todoIds.delete(t.dataset.shareTodo);else if(t.dataset.shareResearch)t.checked?p.researchIds.add(t.dataset.shareResearch):p.researchIds.delete(t.dataset.shareResearch);else if(t.hasAttribute('data-share-hours'))p.hours=Number(t.value);return;}if(t.dataset.todoDone)post({action:'todo-done',todoId:t.dataset.todoDone,value:t.checked}).catch(err=>{t.checked=!t.checked;error(host,err);});else if(t.dataset.todo&&t.dataset.field==='due'&&!ui.select){const before=t.dataset.before;t.dataset.before=t.value;post({action:'todo-edit',todoId:t.dataset.todo,field:'due',value:t.value}).catch(err=>{t.value=before||'';error(host,err);});}});
   host.addEventListener('input',e=>{const pop=ui.pop;if(pop?.kind==='share-confirm'&&e.target.hasAttribute?.('data-ai-intent')){pop.intent=e.target.value;return;}if(pop?.kind!=='copy')return;if(e.target.matches?.('[data-copy-text]'))pop.text=e.target.value;else if(e.target.name==='instruction')pop.instruction=e.target.value;});
   host.addEventListener('submit',async e=>{const form=e.target.closest('[data-lr-form]');if(!form)return;e.preventDefault();e.stopPropagation();if(form.dataset.lrForm==='rewrite-prompt'){
     const pop=ui.pop;if(pop?.kind!=='copy'||pop.busy)return;const instruction=form.querySelector('[name="instruction"]')?.value.trim();if(!instruction)return;
     pop.text=doc.querySelector('[data-copy-text]')?.value??pop.text;const original=pop.text;pop.instruction=instruction;pop.busy=true;pop.error='';pop.message='';paint();
     try{const result=await post({action:'rewrite-prompt',itemId:pop.itemId,text:original,instruction});if(ui.pop!==pop||!result)return;if(typeof result.text!=='string'||!result.text.trim())throw Error('改写未完成，原文已保留，请重试');if(pop.text!==original)throw Error('改写期间你编辑了正文，已保留你的文字，请重试');pop.text=result.text;pop.instruction='';}
     catch(err){if(ui.pop===pop)pop.error=err.message||'改写未完成，原文已保留，请重试';}finally{pop.busy=false;if(ui.pop===pop)paint();}return;
    }const input=form.querySelector('[name="text"]'),text=input?.value.trim();if(!text)return;const button=form.querySelector('button[type="submit"]');if(button?.disabled)return;if(button)button.disabled=true;const ep=ui.epoch;
    try{await post({action:form.dataset.lrForm,itemId:form.dataset.item,text});if(ep!==ui.epoch)return;if(form.dataset.lrForm==='refine'){ui.note='';ui.flash=true;paint();win.setTimeout(()=>{ui.flash=false;},1800);}else if(input)input.value='';}
    catch(err){error(form,err);}finally{if(button)button.disabled=false;}
   });
   host.addEventListener('focusin',e=>{if(e.target.dataset.todo)e.target.dataset.before=e.target.value;});
   host.addEventListener('focusout',e=>{const t=e.target;if(!t.dataset.todo||ui.select||t.value===t.dataset.before)return;const before=t.dataset.before;t.dataset.before=t.value;post({action:'todo-edit',todoId:t.dataset.todo,field:t.dataset.field,value:t.value}).catch(err=>{t.value=before;error(host,err);});});
   host.addEventListener('keydown',e=>{const tg=e.target.closest('[data-tg]');if(ui.select&&tg&&['Enter',' '].includes(e.key)){e.preventDefault();toggle(tg.dataset.tg);return;}
    const t=e.target;if(!t.dataset.todo||ui.select)return;if(e.key==='Escape'){t.value=t.dataset.before??t.value;t.blur();e.stopPropagation();}else if(e.key==='Enter'){if(e.isComposing||e.keyCode===229)return;e.preventDefault();t.blur();}
   });
  }
  doc.addEventListener('click',e=>{if(ui.select&&!ui.pop&&!e.target.closest('[data-tg],.ri,.blk,.selbar,[data-lr],.scrim'))exitSelect();if(ui.handoff.menu&&!e.target?.closest?.('.lr-handoff-bar')){ui.handoff.menu='';paint();}});
  doc.addEventListener('keydown',e=>{if(e.key!=='Escape')return;if(ui.pop){ui.pop=null;paint();}else if(ui.handoff.menu){ui.handoff.menu='';paint();}else if(ui.select)exitSelect();});
  const afterOptions=new WeakMap();
  function mountAfter(host,{id,minutesHtml}={}){if(!host||!id)return;switchTo(id);host.classList.add('lr-scope');afterHosts.add(host);afterOptions.set(host,{minutesHtml});bind(host);paint();void load();}
  win.addEventListener('tht-meeting-navigating',e=>{switchTo(e.detail?.id);void load();});
  win.addEventListener('tht-proactive-data',e=>{const d=e.detail||{};if(d.id!==win.thtViewedMeetingId||d.session?.id&&d.session.id!==d.id)return;switchTo(d.id);void load();});
  win.addEventListener('tht-native-status',()=>{if(!current()){const id=win.thtViewedMeetingId||win.thtRecordingMeetingId?.();if(id)switchTo(id);}void load();});
  win.addEventListener('pagehide',()=>{ui.epoch++;win.clearTimeout(timer);win.clearTimeout(pollTimer);});
  const ready=()=>{const host=doc.querySelector('[data-live-research-after]');if(host&&!host.hasAttribute('data-postmeeting-after'))mountAfter(host,{id:host.dataset.liveResearchAfter});};
  if(doc.readyState==='loading')doc.addEventListener('DOMContentLoaded',ready);else ready();
  win.thtLiveResearch={configure:options=>{if(options.base)base=options.base;if(options.token)token=options.token;},load,mountFeed,mountAfter,bind,state:()=>ui,renderReport:(host,id)=>{const i=item(id);host.classList.add('lr-scope');if(i){reportHosts.set(host,id);renderHost(host,reportHtml({...i,meetingTitle:ui.data?.title},{handoff:handoffFor(id)}));void loadHandoffStatus(false);}},outputHtml:()=>ui.data?outputHtml(ui.data,ui):'',data:()=>ui.data,
   minutesHtml,updateAfter:host=>{if(afterHosts.has(host))paint();},unmountAfter:host=>{afterHosts.delete(host);afterOptions.delete(host);},openReport:id=>act('report',id),post};
 }
 return {researchPresentation,safeSrcLabel,fastVizHtml,fastCardHtml,avatarChar,canSendToAi,chartRenderers,researchItem,followupItem,subsHtml,progress,chartHtml,tableHtml,reportHtml,standaloneHtml,minutesHtml,miniHtml,afterHtml,outputHtml,popHtml,snapshotHtml,install};
});
