'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const TIMEOUT_MS = 10_000;
const searchPrivacy = require('../insight-search');
const { assertAllowed } = require('../outbound-policy');
const domainHealth = require('../source-domain-health');
const openSources = require('../open-sources');
let cloudSearchDisabledUntil = 0;

function settingsFile(env = process.env) {
  const dataDir = env.THT_DATA_DIR || path.join(os.homedir(), 'Library/Application Support/Citeside');
  return path.join(dataDir, 'settings.json');
}
function braveKey(env = process.env) {
  try {
    const value = require('../secret-store').readSettings(path.dirname(settingsFile(env)), env).BRAVE_API_KEY;
    return typeof value === 'string' ? value.trim() : '';
  } catch (_) { return ''; }
}
function clean(value, max = 500) {
  return String(value || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}
function decodeHtml(value) {
  return String(value || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)));
}
function resultUrl(raw) {
  const decoded = decodeHtml(raw);
  try {
    const url = new URL(decoded, 'https://duckduckgo.com');
    return url.searchParams.get('uddg') || url.href;
  } catch (_) { return decoded; }
}
function parseDuckDuckGo(html, n) {
  const blocks = String(html || '').split(/class=["'][^"']*result(?:\s|__body)/i).slice(1), rows = [];
  for (const block of blocks) {
    const link = block.match(/class=["'][^"']*result__a[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/i);
    if (!link) continue;
    const snippet = block.match(/class=["'][^"']*result__snippet[^"']*["'][^>]*>([\s\S]*?)<\/(?:a|div|span)>/i);
    const url = resultUrl(link[1]);
    if (!/^https?:\/\//i.test(url)) continue;
    rows.push({ title: clean(decodeHtml(link[2]), 300), url, snippet: clean(decodeHtml(snippet && snippet[1]), 500) });
    if (rows.length >= n) break;
  }
  return rows;
}
async function tryCloudSearch(q, limit, env, dataDir, fetchImpl, signal) {
  if (env.CLOUD_SEARCH === 'off' || Date.now() < cloudSearchDisabledUntil) return null;
  const cloudInf = require('../cloud-inference');
  if (!cloudInf.trialOn(env)) return null;
  let session;
  try { session = cloudInf.loadSession(dataDir, env); } catch { return null; }
  if (!session?.url || !session?.token) return null;
  const url = session.url.replace(/\/$/, '') + '/v1/trial/search';
  try {
    assertAllowed(env, 'search', url);
    const res = await fetchImpl(url, {
      method: 'POST', redirect: 'error', signal,
      headers: { Authorization: 'Bearer ' + session.token, 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: q, count: limit })
    });
    if (res.status === 404 || res.status === 405 || res.status === 501) {
      cloudSearchDisabledUntil = Date.now() + 10 * 60 * 1000;
      return null;
    }
    if (!res.ok) return null;
    const json = await res.json();
    const list = Array.isArray(json?.results) ? json.results : [];
    return list.slice(0, limit).map(row => ({
      title: clean(row.title, 300),
      url: String(row.url || ''),
      snippet: clean(row.snippet || row.description || '', 500),
      ...(String(row.excerpt || '').trim().length >= 80 ? { excerpt: clean(row.excerpt, 6000), cloudExtracted: true } : {}),
      ...(row.publishedAt ? { publishedAt: String(row.publishedAt).slice(0, 40) } : {})
    })).filter(row => /^https?:\/\//i.test(row.url));
  } catch {
    return null;
  }
}
async function search(query, n = 5, options = {}) {
  const q = String(query || '').trim(), limit = Math.max(1, Math.min(10, Number(n) || 5));
  if (!q || !searchPrivacy.isSafeQuery(q, searchPrivacy.loadSensitiveNames(options))) return [];
  const env=require('../meeting-work-state').environment(options.workState,options.env||{});
  const dataDir = options.dataDir || env.THT_DATA_DIR || path.dirname(settingsFile(env));
  const accounting=require('../llm').createAttemptRecorder({...options,resource:'search',tier:'resource',callBudget:require('../model-routing').callBudget(env)});
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (typeof fetchImpl !== 'function') return [];
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), options.timeoutMs || TIMEOUT_MS);
  try {
    const useLayeredSources = !options.fetchImpl || options.openSources === true;
    // L1: Cloud Search-for-AI API (when deployed on Railway /v1/trial/search)
    if (useLayeredSources && !String(options.braveApiKey || '').trim()) {
      const cloudRows = await tryCloudSearch(q, limit, env, dataDir, fetchImpl, controller.signal);
      if (Array.isArray(cloudRows) && cloudRows.length) {
        return domainHealth.rankUrls(dataDir, cloudRows).slice(0, limit);
      }
    }
    // L2: Zero-anti-bot official open APIs (Wikipedia EN/ZH, GitHub, HN Algolia) in parallel with primary web search
    const openPromise = useLayeredSources
      ? openSources.search(q, Math.min(3, limit), { env, fetchImpl, timeoutMs: Math.min(3500, options.timeoutMs || TIMEOUT_MS) }).catch(() => [])
      : Promise.resolve([]);
    const primaryPromise = (async () => {
      const key = options.braveApiKey === undefined ? braveKey(options.workState ? env : options.env) : String(options.braveApiKey || '');
      if (key) {
        const url = 'https://api.search.brave.com/res/v1/web/search?q=' + encodeURIComponent(q) + '&count=' + limit;
        assertAllowed(env, 'search', url);
        const response = await accounting.run({provider:'search',model:'brave'},()=>fetchImpl(url, { redirect:'error',signal: controller.signal, headers: { Accept: 'application/json', 'X-Subscription-Token': key } }),r=>({ok:r.ok,errorCode:'http_'+r.status}));
        if (!response.ok) return [];
        const json = await response.json();
        return ((json.web && json.web.results) || []).slice(0, limit).map(row => ({
          title: clean(row.title, 300), url: String(row.url || ''), snippet: clean(row.description, 500),
        })).filter(row => /^https?:\/\//i.test(row.url));
      }
      const url = 'https://html.duckduckgo.com/html/?q=' + encodeURIComponent(q);
      assertAllowed(env, 'search', url);
      const response = await accounting.run({provider:'search',model:'duckduckgo'},()=>fetchImpl(url, { redirect:'error',signal: controller.signal, headers: { Accept: 'text/html', 'User-Agent': 'Mozilla/5.0 Citeside/1.0' } }),r=>({ok:r.ok,errorCode:'http_'+r.status}));
      if (!response.ok) return [];
      return parseDuckDuckGo(await response.text(), limit);
    })().catch(e => { if (String(e.code || '').startsWith('call_budget_')) throw e; return []; });
    const [openRows, primaryRows] = await Promise.all([openPromise, primaryPromise]);
    const seen = new Set(), merged = [];
    for (const row of [...(openRows || []), ...(primaryRows || [])]) {
      if (!row?.url || seen.has(row.url)) continue;
      seen.add(row.url);
      merged.push(row);
    }
    return domainHealth.rankUrls(dataDir, merged).slice(0, limit);
  } catch (e) {if(String(e.code||'').startsWith('call_budget_'))throw e;return []; } finally { clearTimeout(timer); }
}
// Read only the first two public results. The existing transport validates all
// DNS addresses, pins TLS, caps bytes and refuses redirects and private hosts.
function pageText(html) {
  const source=String(html || '').replace(/<(script|style|nav|footer|header)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,' ');
  const main=source.match(/<(?:main|article)\b[^>]*>([\s\S]*?)<\/(?:main|article)\s*>/i);
  return clean(decodeHtml((main ? main[1] : source).replace(/<[^>]*>/g,' ')),12000);
}
async function searchWithSources(query, n=5, options={}) {
  const rows=await (options.searchImpl || search)(query,n,options);
  const read=options.pageFetch || require('../public-page-fetch').fetch;
  return Promise.all(rows.map(async(row,index)=>{
    if(index>=2)return row;
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),options.pageTimeoutMs || 6000);
    try {
      const response=await read(row.url,{...options,signal:controller.signal});
      if(!response.ok)return row;
      const type=String(response.headers.get('content-type') || '');
      if(!/html|text\/plain/i.test(type))return row;
      const text=pageText(await response.text());
      if(text.length<80)return row;
      return {...row,searchSnippet:row.snippet,snippet:text,evidenceKind:'public_page_excerpt'};
    } catch (e) {if(String(e.code||'').startsWith('call_budget_'))throw e;return row; } finally { clearTimeout(timer); }
  }));
}
module.exports = { search, searchWithSources, pageText };
