(() => {
  'use strict';

  const CONSENT_KEY = 'tht-iqr-consent-ack-v1';
  const STRIP_PREFIX_RE = /^(?:lead|tip|point|cue|action|result|anchor|close|clarify|connect|structure)\s*[:：]\s*/i;

  let curSessionId = '';
  let scenarioMode = '';
  let featureEnabled = false; // Fail-closed: only enabled when backend feature flag is true
  let notes = []; // newest first, max 4, deduped by id or questionGist

  function getSettingsToken() {
    try { return JSON.parse(localStorage.getItem('tht-settings') || '{}').relayToken || ''; } catch { return ''; }
  }

  function apiBase() {
    return typeof window.relayBase === 'function' ? window.relayBase() : '/asr-relay';
  }

  async function apiFetch(path, opts = {}) {
    const token = getSettingsToken();
    const sep = path.includes('?') ? '&' : '?';
    const url = `${apiBase()}${path}${token ? `${sep}token=${encodeURIComponent(token)}` : ''}`;
    const res = await fetch(url, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      signal: AbortSignal.timeout(8000)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  function isEn() {
    return document.documentElement.lang === 'en';
  }

  function cleanTipText(raw, lang) {
    const s = String(raw || '').replace(/\[([^\]]+)\]/g, '$1').trim();
    return lang === 'en' ? s : s.replace(STRIP_PREFIX_RE, '');
  }

  function buildSingleTip(card) {
    const slots = Array.isArray(card.slots) ? card.slots : [];
    const parts = slots
      .map((s) => cleanTipText(typeof s === 'string' ? s : s?.text, card.lang))
      .filter(Boolean);
    if (!parts.length) return '';
    return parts.join('；').slice(0, 68);
  }

  function fmtHHMM(ts) {
    const d = new Date(ts || Date.now());
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }

  function upsertNote(card) {
    if (!card) return;
    const key = card.id || card.questionGist || '';
    const idx = notes.findIndex((n) => (card.id && n.id === card.id) || (card.questionGist && n.questionGist === card.questionGist));
    if (idx >= 0) {
      notes[idx] = card;
      if (idx > 0) {
        notes.splice(idx, 1);
        notes.unshift(card);
      }
    } else if (key) {
      notes.unshift(card);
    }
    notes = notes.slice(0, 4);
  }

  let dock, feedWrap, consentBar;

  function ensureDom() {
    if (dock) return dock;
    dock = document.createElement('aside');
    dock.className = 'iqr-dock';
    dock.id = 'iqr-dock';
    dock.hidden = true;
    dock.setAttribute('aria-live', 'polite');

    const head = document.createElement('div');
    head.className = 'iqr-head';
    const title = document.createElement('div');
    title.className = 'iqr-head-title';
    title.innerHTML = isEn()
      ? '<span class="iqr-live-dot"></span><span>Interview Quick-Reply</span><span class="iqr-live-hint">Auto-listening</span>'
      : '<span class="iqr-live-dot"></span><span>面试快答</span><span class="iqr-live-hint">自动听题 · 随时提醒</span>';

    const actions = document.createElement('div');
    actions.className = 'iqr-head-actions';

    const triggerBtn = document.createElement('button');
    triggerBtn.type = 'button';
    triggerBtn.className = 'iqr-btn';
    triggerBtn.title = 'Option + Space';
    triggerBtn.textContent = isEn() ? 'Cue (⌥Space)' : '补卡 (⌥Space)';
    triggerBtn.onclick = () => void handleManualTrigger();

    const wipeBtn = document.createElement('button');
    wipeBtn.type = 'button';
    wipeBtn.className = 'iqr-btn iqr-btn-danger';
    wipeBtn.textContent = isEn() ? 'Wipe' : '一键销毁';
    wipeBtn.onclick = () => void handleWipe();

    actions.append(triggerBtn, wipeBtn);
    head.append(title, actions);

    consentBar = document.createElement('div');
    consentBar.className = 'iqr-consent';
    const consentText = document.createElement('span');
    consentText.textContent = isEn()
      ? 'No audio saved · Never fabricates experience · Confirm local consent laws.'
      : '本模式不留音频、绝不编造经历 · 请自行确认当地录音法规。';
    const consentOk = document.createElement('button');
    consentOk.type = 'button';
    consentOk.className = 'iqr-btn';
    consentOk.textContent = isEn() ? 'OK' : '知道了';
    consentOk.onclick = () => {
      try { localStorage.setItem(CONSENT_KEY, '1'); } catch {}
      consentBar.hidden = true;
    };
    consentBar.append(consentText, consentOk);
    try { if (localStorage.getItem(CONSENT_KEY) === '1') consentBar.hidden = true; } catch {}

    feedWrap = document.createElement('div');
    feedWrap.className = 'iqr-feed';

    dock.append(head, consentBar, feedWrap);
    document.body.append(dock);
    return dock;
  }

  function renderFeed() {
    feedWrap.replaceChildren();
    if (!notes.length) {
      const empty = document.createElement('div');
      empty.className = 'iqr-empty';
      empty.textContent = isEn()
        ? 'Listening… When the interviewer asks a question, a 3-line cue appears here automatically. Press ⌥Space anytime to trigger manually.'
        : '自动听题中… 面试官提问后，这里会自动弹出 3 行极简提醒（注意红线 + 接话 + 要点）。随时按 ⌥Space 可手动补卡。';
      feedWrap.append(empty);
      return;
    }

    notes.forEach((card, idx) => {
      const el = document.createElement('article');
      el.className = 'iqr-note' + (idx > 0 ? ' is-old' : '') + (idx === 0 && card.frozen ? ' is-frozen' : '');

      const top = document.createElement('div');
      top.className = 'iqr-note-top';
      if (card.redFlag) {
        const rf = document.createElement('span');
        rf.className = 'iqr-redflag';
        rf.textContent = `⚠ ${card.redFlag}`;
        top.append(rf);
      }
      const tm = document.createElement('span');
      tm.className = 'iqr-time';
      tm.textContent = (card.askedBy ? `${card.askedBy} · ` : '') + fmtHHMM(card.shownAt);
      top.append(tm);
      el.append(top);

      if (idx === 0 && Array.isArray(card.multiPart) && card.multiPart.length) {
        const mp = document.createElement('div');
        mp.className = 'iqr-multipart';
        for (const item of card.multiPart) {
          const chk = document.createElement('span');
          chk.className = 'iqr-check-item' + (item.covered ? ' is-covered' : '');
          chk.textContent = `${item.covered ? '✓' : '☐'} ${item.index}. ${item.label}`;
          mp.append(chk);
        }
        el.append(mp);
      }

      const opening = document.createElement('div');
      opening.className = 'iqr-opening';
      opening.textContent = cleanTipText(card.openingLine, card.lang);
      el.append(opening);

      const tipText = buildSingleTip(card);
      if (tipText) {
        const tip = document.createElement('div');
        tip.className = 'iqr-tip';
        tip.textContent = tipText;
        el.append(tip);
      }

      if (idx === 0 && card.nudge) {
        const nudge = document.createElement('div');
        nudge.className = 'iqr-nudge';
        nudge.textContent = `⚡ ${card.nudge}`;
        el.append(nudge);
      }

      feedWrap.append(el);
    });
  }

  function syncFeatureUi() {
    const liteBtn = document.getElementById('btn-lite-iqr');
    if (liteBtn) liteBtn.hidden = !(featureEnabled && scenarioMode === 'interview_reply');
    render();
  }

  async function loadFeatures() {
    try {
      const res = await apiFetch('/features');
      if (res && res.features && typeof res.features.interviewQuickReply === 'boolean') {
        featureEnabled = res.features.interviewQuickReply;
        syncFeatureUi();
      }
    } catch {}
  }

  function render() {
    ensureDom();
    const isHomeOpen = document.body.classList.contains('document-home-open');
    const visible = featureEnabled && !isHomeOpen && scenarioMode === 'interview_reply';
    const liteBtn = document.getElementById('btn-lite-iqr');
    if (liteBtn) liteBtn.hidden = !visible;
    dock.hidden = !visible;
    document.body.classList.toggle('lite-interview-mode', Boolean(visible && liteBtn));
    if (!visible) return;
    renderFeed();
  }

  async function handleManualTrigger() {
    if (!curSessionId) return;
    try {
      const res = await apiFetch('/interview-quick-reply/trigger', { method: 'POST', body: { id: curSessionId } });
      if (res.card) { upsertNote(res.card); render(); }
    } catch {}
  }

  async function handleWipe() {
    if (!curSessionId) {
      notes = [];
      render();
      return;
    }
    try {
      await apiFetch('/interview-quick-reply/wipe', { method: 'POST', body: { id: curSessionId } });
      notes = [];
      render();
    } catch {}
  }

  window.addEventListener('tht-meeting-scenario', (e) => {
    const d = e.detail || {};
    if (d.sessionId) curSessionId = String(d.sessionId);
    if (d.scenario && d.scenario.mode) {
      scenarioMode = d.scenario.mode;
      render();
    }
  });

  window.addEventListener('tht-proactive-data', (e) => {
    const sess = e.detail && e.detail.session;
    if (!sess) return;
    curSessionId = String(sess.id || '');
    if (sess.meetingScenario && sess.meetingScenario.mode) {
      scenarioMode = sess.meetingScenario.mode;
    }
    if (sess.interviewCard) upsertNote(sess.interviewCard);
    render();
  });

  window.addEventListener('tht-interview-card', (e) => {
    const d = e.detail || {};
    if (d.card) {
      upsertNote(d.card);
      render();
    }
  });

  window.addEventListener('tht-interview-wiped', () => {
    notes = [];
    render();
  });

  document.addEventListener('keydown', (e) => {
    if (e.altKey && (e.code === 'Space' || e.key === ' ') && scenarioMode === 'interview_reply') {
      e.preventDefault();
      void handleManualTrigger();
    }
  });

  window.THT_INTERVIEW_QR = {
    syncScenario: ({ sessionId, mode } = {}) => {
      if (sessionId !== undefined) curSessionId = String(sessionId || '');
      if (mode !== undefined) scenarioMode = String(mode || '');
      render();
    },
    setCard: (c) => { upsertNote(c); render(); },
    trigger: () => handleManualTrigger()
  };

  // Lite Mode 1-click "面试快答" toggle (only active when feature flag is enabled)
  const liteBtn = document.getElementById('btn-lite-iqr');
  if (liteBtn) {
    liteBtn.hidden = !featureEnabled;
    liteBtn.addEventListener('click', async () => {
      if (!featureEnabled) return;
      const sid = curSessionId || (new URLSearchParams(location.search).get('id') || '');
      if (!sid) return;
      const nextMode = scenarioMode === 'interview_reply' ? 'active' : 'interview_reply';
      try {
        const res = await apiFetch('/meeting-scenario', {
          method: 'POST',
          body: { id: sid, mode: nextMode, lang: isEn() ? 'en' : 'zh' }
        });
        if (res.scenario) scenarioMode = res.scenario.mode;
        if (res.interviewCard) upsertNote(res.interviewCard);
        render();
      } catch {}
    });
  }

  void loadFeatures();
})();
