'use strict';
// The page is read-only until its explicit send click. Keep the original note
// and transcript in place when switching views; never regenerate a summary.
(()=>{
 const research=document.querySelector('[data-live-research-after]');if(research){if(window.thtPostmeeting&&research.hasAttribute('data-postmeeting-after')){const id=research.dataset.liveResearchAfter;research.replaceChildren();window.thtPostmeeting.mount(research,{id});}try{const t=localStorage.getItem('tht-theme');if(['light','dark'].includes(t))document.documentElement.dataset.theme=t;}catch{}return;}
 const main=document.getElementById('minutes-note'),bar=document.getElementById('minutes-share'),record=document.getElementById('minutes-transcript');
 if(!main||!bar)return;
 try{const theme=localStorage.getItem('tht-theme');if(['light','dark'].includes(theme))document.documentElement.dataset.theme=theme;}catch{}
 const params=new URLSearchParams(location.search),id=main.dataset.meetingId;
 let token=params.get('token')||'';if(!token)try{token=JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}
 const endpoint='/asr-relay/meeting-board/minutes?id='+encodeURIComponent(id)+'&token='+encodeURIComponent(token);
 const safeUrl=v=>/^https:\/\/(?:www\.|app\.)?notion\.(?:so|com)\/[^\s<>"']+$/.test(v||'');
 let busy=false,timer=null,generation=0;
 const el=(tag,text,cls='pill')=>{const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;};
 const button=(text,fn)=>{const n=el('button',text);n.type='button';n.addEventListener('click',fn);return n;};
 const wait=()=>{clearTimeout(timer);timer=setTimeout(()=>load(),2500);};
 const paint=(state={},error='')=>{
  bar.replaceChildren();
  if(state.synced&&state.status==='done'&&safeUrl(state.url)){
   const label=el('span','✓ 已发到 Notion','pill on'),open=el('a','打开');open.href=state.url;open.target='_blank';open.rel='noopener noreferrer';
   const copy=button('复制链接',async()=>{try{await navigator.clipboard.writeText(state.url);copy.textContent='已复制';}catch{copy.textContent='复制失败，请重试';}});
   bar.append(label,open,copy);return;
  }
  if(busy||['queued','running'].includes(state.status)){bar.append(el('span','正在发到 Notion…'));return;}
  const send=button('发到 Notion',sendNote);send.dataset.minutesSend='';bar.append(send);
  if(error||state.status==='failed'){const msg=el('span',error||'发送未完成，请重试','empty');msg.setAttribute('role','status');bar.append(msg);}
 };
 const request=async(opt={})=>{const r=await fetch(endpoint,{cache:'no-store',signal:AbortSignal.timeout(15000),...opt}),j=await r.json();if(!r.ok||j.ok===false)throw Error(j.error||'读取失败，请重试');return j;};
 const load=async()=>{const epoch=generation;try{const j=await request();if(epoch!==generation||busy)return;paint(j);if(['queued','running'].includes(j.status))wait();}catch{if(epoch===generation&&!busy)wait();}};
 async function sendNote(){
  if(busy)return;busy=true;generation++;clearTimeout(timer);paint();
  try{const j=await request({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirmed:true})});busy=false;paint(j);if(['queued','running'].includes(j.status))wait();}
  catch(e){busy=false;paint({},e.message);}
 }
 const showRecord=show=>{if(!record)return;main.hidden=show;record.hidden=!show;};
 document.querySelector('[data-minutes-transcript]')?.addEventListener('click',e=>{e.preventDefault();showRecord(true);});
 document.querySelector('[data-minutes-back]')?.addEventListener('click',()=>showRecord(false));
 if(location.hash==='#minutes-transcript')showRecord(true);
 window.addEventListener('pagehide',()=>{generation++;clearTimeout(timer);});
 paint();void load();
})();
