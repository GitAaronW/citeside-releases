(function (root) {
  'use strict';

  function hasRealUrl(list) {
    return Array.isArray(list) && list.some(s => s && /^https?:\/\//i.test(String(s.url || '').trim()));
  }

  // Single source of truth for Main Window (my-agent.js) and Lite Window (lite.js).
  // Both windows MUST render the exact same proactive cards; generic un-badged transcript
  // echoes are filtered out uniformly in BOTH windows.
  function shouldShowProactiveCard(item) {
    if (!item || typeof item !== 'object') return false;
    if (item.cardKind || item.semanticBadge) return true;
    if (hasRealUrl(item.sources) || hasRealUrl(item.verify && item.verify.sources)) return true;
    return false;
  }

  // Single source of truth for the latest discussion-summary timeline label in BOTH windows.
  // Never show "正在发生 / Happening now" once a meeting has ended.
  function meetingTimelineLabel({ ended = false, paused = false, isLatest = true, en = false } = {}) {
    if (!isLatest) return en ? 'Earlier' : '稍早';
    if (ended) return en ? 'Final recap' : '讨论收尾';
    if (paused) return en ? 'Paused' : '已暂停';
    return en ? 'Happening now' : '正在发生';
  }

  // Single source of truth for ended/paused control bar presentation in BOTH windows.
  function meetingControlBarState({ active = false, paused = false, ended = false, captureEnding = false, en = false } = {}) {
    const isEnded = !active && !paused && !!ended;
    return {
      state: captureEnding ? 'saving' : paused ? 'paused' : isEnded ? 'ended' : active ? 'recording' : 'idle',
      badgeLabel: captureEnding
        ? (en ? 'Saving stopped recording' : '录音已停止，正在保存')
        : paused
          ? (en ? 'Paused' : '已暂停')
          : isEnded
            ? (en ? 'Ended' : '已结束')
            : '',
      resumeLabel: en ? 'Resume' : '继续录制',
      showWave: !!active && !paused && !isEnded,
      showMic: !isEnded,
      suppressAudioError: !!captureEnding || isEnded || (!active && !paused)
    };
  }

  const api = {
    shouldShowProactiveCard,
    meetingTimelineLabel,
    meetingControlBarState
  };

  if (typeof module === 'object' && module && module.exports) {
    module.exports = api;
  }
  if (root && typeof root === 'object') {
    root.ThtProactiveContract = api;
  }
})(typeof window !== 'undefined' ? window : globalThis);
