'use strict';

// Step B: Lightweight Mock Interview Practice Mode
// Reuses the exact same createInterviewQuickReply engine & card schema as live interviews.

const { createInterviewQuickReply } = require('./interview-quick-reply');

const PRACTICE_PACKS = {
  ja_midcareer: {
    id: 'ja_midcareer',
    lang: 'ja',
    title: '日本中途転職面接（定番＋深掘り）',
    subtitle: '本番の「頭真っ白」対策・PREP法と一問二答の練習',
    interviewerName: '採用マネージャー（佐藤）',
    turns: [
      {
        kind: 'intro',
        text: '本日はお時間ありがとうございます。当社では現在BtoBプロダクトのエンタープライズ展開とクロスファンクショナルな開発推進を強化しています。まずは簡単に自己紹介と直近の職務経歴をお願いできますか？'
      },
      {
        kind: 'question',
        text: 'ありがとうございます。今回、転職を考えられた理由をお聞かせいただけますでしょうか。'
      },
      {
        kind: 'question',
        text: '2点伺います。1つ目は直近で最も成果を出したプロジェクトの工夫、2つ目はその経験を当社でどう活かせるか教えてください。'
      },
      {
        kind: 'question',
        text: 'なるほど。ちなみに、そのプロジェクトで反対意見が出たとき、ご自身はどう合意形成しましたか？'
      },
      {
        kind: 'question',
        text: '条件面も確認させてください。ご希望年収のイメージはどのあたりでしょうか？'
      },
      {
        kind: 'question',
        text: '最後に、当社やポジションについて何かご質問はありますか？'
      }
    ]
  },
  en_tech_biz: {
    id: 'en_tech_biz',
    lang: 'en',
    title: 'US Tech & Business Interview',
    subtitle: 'Practice ownership ("I" vs "we"), clarifying Qs & two-part prompts',
    interviewerName: 'Hiring Manager (Alex)',
    turns: [
      {
        kind: 'intro',
        text: 'Thanks for joining today. Our team owns enterprise onboarding reliability and cross-functional roadmap execution. Could you start with a quick intro and your recent scope?'
      },
      {
        kind: 'question',
        text: 'Tell me about a time you disagreed with a key stakeholder and had to drive alignment.'
      },
      {
        kind: 'question',
        text: 'How would you prioritize our enterprise onboarding roadmap if retention dropped 15% this quarter?'
      },
      {
        kind: 'question',
        text: 'Two questions: first, what metric proved your last launch worked, and second, what would you do differently today?'
      },
      {
        kind: 'question',
        text: 'We have a few minutes left — do you have any questions for us?'
      }
    ]
  },
  zh_general: {
    id: 'zh_general',
    lang: 'zh',
    title: '中文实战面试（深挖＋反问）',
    subtitle: '练习先接住再引导、一题两问不漏答与防大脑空白',
    interviewerName: '业务面试官（陈经理）',
    turns: [
      {
        kind: 'intro',
        text: '你好，感谢来参加面试。我们团队目前核心负责商业化增长和跨部门交付提效。你先花两分钟介绍一下自己和最近主导的项目吧？'
      },
      {
        kind: 'question',
        text: '你刚提到的项目挺有意思，能聊聊你现在为什么考虑看新机会吗？'
      },
      {
        kind: 'question',
        text: '我有两个问题：第一，你在这件事里最难的推进卡点是什么；第二，最后怎么用数据验证结果达标的？'
      },
      {
        kind: 'question',
        text: '具体来说，当时研发和业务意见不一致，你个人拍板了什么决定？'
      },
      {
        kind: 'question',
        text: '最后你有什么想问我们团队的吗？'
      }
    ]
  }
};

function listPracticePacks() {
  return Object.values(PRACTICE_PACKS).map(({ id, lang, title, subtitle, interviewerName, turns }) => ({
    id,
    lang,
    title,
    subtitle,
    interviewerName,
    totalTurns: turns.length
  }));
}

function createPracticeSession({ packId = 'ja_midcareer', askModel = null, onEvent = () => {} } = {}) {
  const pack = PRACTICE_PACKS[packId] || PRACTICE_PACKS.ja_midcareer;
  let active = false;
  let turnIndex = -1;
  let history = [];
  let latestCard = null;
  let nowCursor = Date.now();

  const engine = createInterviewQuickReply({
    lang: pack.lang,
    tShowMs: 0,
    useTimers: false,
    askModel,
    onCard: (card) => {
      latestCard = card;
      onEvent({ type: 'interview-card', card, practice: true });
    }
  });

  function emitState() {
    const state = getState();
    onEvent({ type: 'practice-state', state });
    return state;
  }

  function advanceTurn() {
    if (!active) return getState();
    turnIndex += 1;
    if (turnIndex >= pack.turns.length) {
      active = false;
      return emitState();
    }
    const turn = pack.turns[turnIndex];
    nowCursor += 4000;
    history.push({ role: 'interviewer', speaker: pack.interviewerName, text: turn.text, at: nowCursor });
    engine.onFinal({ text: turn.text, speaker: pack.interviewerName, isMe: false, ts: nowCursor });
    return emitState();
  }

  function start() {
    active = true;
    turnIndex = -1;
    history = [];
    latestCard = null;
    nowCursor = Date.now();
    return advanceTurn();
  }

  function submitAnswer(text) {
    if (!active) return getState();
    const clean = String(text || '').trim();
    if (clean) {
      nowCursor += 2500;
      history.push({ role: 'candidate', speaker: 'Me', text: clean, at: nowCursor });
      engine.onFinal({ text: clean, speaker: 'Me', isMe: true, ts: nowCursor });
    }
    return emitState();
  }

  function nextQuestion() {
    return advanceTurn();
  }

  function triggerManual() {
    nowCursor += 100;
    const card = engine.manualTrigger(nowCursor);
    if (card) latestCard = card;
    return emitState();
  }

  function stop() {
    active = false;
    engine.dispose();
    return emitState();
  }

  function getState() {
    return {
      active,
      packId: pack.id,
      lang: pack.lang,
      title: pack.title,
      interviewerName: pack.interviewerName,
      turnIndex,
      totalTurns: pack.turns.length,
      completed: !active && turnIndex >= pack.turns.length,
      currentPrompt: turnIndex >= 0 && turnIndex < pack.turns.length ? pack.turns[turnIndex].text : '',
      history: history.slice(-12),
      card: latestCard,
      context: engine.getContextSummary(),
      metrics: engine.getMetrics()
    };
  }

  return {
    start,
    submitAnswer,
    nextQuestion,
    triggerManual,
    stop,
    getState
  };
}

module.exports = {
  PRACTICE_PACKS,
  listPracticePacks,
  createPracticeSession
};
