'use strict';
// Lightweight numeric normalizer for live-expert evidence tiering (quoted vs source).
// Normalizes forms like "35.1B", "351亿", "$35,082 million", "4.5%", "14种" into
// comparable numeric entries and checks consistency within ±1.5% tolerance.

const SCALE_PATTERNS = [
  { re: /(?:\$|US\$|USD\s*|¥|RMB\s*)?(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(?:trillion|T\b|万亿)/gi, mult: 1e12, kind: 'num' },
  { re: /(?:\$|US\$|USD\s*|¥|RMB\s*)?(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(?:billion|bn\b|B\b|十亿)/gi, mult: 1e9, kind: 'num' },
  { re: /(?:\$|US\$|USD\s*|¥|RMB\s*)?(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*亿/g, mult: 1e8, kind: 'num' },
  { re: /(?:\$|US\$|USD\s*|¥|RMB\s*)?(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(?:million|mn\b|M\b|百万)/gi, mult: 1e6, kind: 'num' },
  { re: /(?:\$|US\$|USD\s*|¥|RMB\s*)?(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*万/g, mult: 1e4, kind: 'num' },
  { re: /(?:\$|US\$|USD\s*|¥|RMB\s*)?(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(?:thousand|K\b|千)/gi, mult: 1e3, kind: 'num' },
  { re: /(\d+(?:\.\d+)?)\s*(?:%|percent|个百分点|百分点)/gi, mult: 1, kind: 'pct' },
  { re: /(?<![A-Za-z0-9.])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?![A-Za-z0-9.%])/g, mult: 1, kind: 'num' }
];

function extractNumbers(text) {
  const s = String(text || '')
    .replace(/％/g, '%')
    .replace(/．/g, '.')
    .replace(/，(?=\d{3}\b)/g, ',')
    .replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0));
  if (!s) return [];
  const found = [];
  const usedRanges = [];
  const overlaps = (a, b) => usedRanges.some(([x, y]) => a < y && b > x);
  for (const { re, mult, kind } of SCALE_PATTERNS) {
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(s)) !== null) {
      const start = m.index, end = start + m[0].length;
      if (overlaps(start, end)) continue;
      const num = Number(String(m[1]).replace(/,/g, ''));
      if (!Number.isFinite(num)) continue;
      // Ignore 4-digit calendar years (1900-2099) when plain unscaled numbers
      if (mult === 1 && kind === 'num' && Number.isInteger(num) && num >= 1900 && num <= 2099) {
        usedRanges.push([start, end]);
        continue;
      }
      usedRanges.push([start, end]);
      found.push({ value: num * mult, kind, raw: m[0] });
    }
  }
  return found;
}

function closeEnough(a, b, tolerance = 0.015) {
  if (a.kind !== b.kind) return false;
  if (a.value === 0 && b.value === 0) return true;
  const denom = Math.max(Math.abs(a.value), Math.abs(b.value), 1e-9);
  return Math.abs(a.value - b.value) / denom <= tolerance;
}

function numbersConsistent(claimText, excerptText, tolerance = 0.015) {
  const claimNums = extractNumbers(claimText);
  if (!claimNums.length) return true;
  const excerptNums = extractNumbers(excerptText);
  if (!excerptNums.length) return false;
  return claimNums.some(cn => excerptNums.some(en => closeEnough(cn, en, tolerance)));
}

// Strict fact-check verification (P0-2):
// Every corrected number that differs from the speaker's original claim MUST be matched in excerpt.
// If corrected only repeats claim numbers (no newly grounded number), returns false.
function numbersSupported(correctedText, excerptText, claimText = '', tolerance = 0.015) {
  const correctedNums = extractNumbers(correctedText);
  if (!correctedNums.length) return true;
  const claimNums = extractNumbers(claimText);
  const newNums = correctedNums.filter(cn => !claimNums.some(cl => closeEnough(cn, cl, tolerance)));
  if (!newNums.length) return false;
  const excerptNums = extractNumbers(excerptText);
  if (!excerptNums.length) return false;
  return newNums.every(nn => excerptNums.some(en => closeEnough(nn, en, tolerance)));
}

module.exports = { extractNumbers, closeEnough, numbersConsistent, numbersSupported };
