'use strict';
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

const SALT = 'citeside-device-v1:';
let cachedHash = null;

function hashRawId(rawId) {
  const clean = String(rawId || '').trim().toUpperCase();
  if (!clean) return '';
  return crypto.createHash('sha256').update(SALT + clean).digest('hex');
}

function readMacPlatformUuid(execImpl = execFileSync) {
  try {
    const out = String(execImpl('/usr/sbin/ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice'], {
      encoding: 'utf8',
      timeout: 2000,
      stdio: ['ignore', 'pipe', 'ignore']
    }));
    const match = /"IOPlatformUUID"\s*=\s*"([0-9A-Fa-f-]+)"/.exec(out);
    return match ? match[1] : '';
  } catch {
    return '';
  }
}

/**
 * Returns a deterministic one-way SHA-256 hardware hash on macOS (never the raw UUID).
 * Safe and non-throwing: returns '' on non-darwin or if ioreg is unavailable.
 */
function getDeviceHash({ platform = process.platform, execImpl = execFileSync, bypassCache = false } = {}) {
  if (!bypassCache && cachedHash !== null) return cachedHash;
  let value = '';
  if (platform === 'darwin') {
    const uuid = readMacPlatformUuid(execImpl);
    value = hashRawId(uuid);
  }
  if (!bypassCache) cachedHash = value;
  return value;
}

module.exports = { getDeviceHash, hashRawId, readMacPlatformUuid };
