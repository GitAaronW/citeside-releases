'use strict';
// Meeting scenario context (P1-CARD-003):
// - t=0 defaults to conservative mode (hard-evidence cards only) when undecided.
// - Structured {mode, userRole, goal, watchFor, suppress} injected into BOTH
//   live card generation and publication gate (no 3-5 min meetingFrame cold start).
// - 1-click user override locks the scenario for the current meeting and saves
//   local-only attendee-group preferences ("what meeting these people usually hold").
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const journal = require('./session-journal');

const VALID_MODES = ['active', 'conservative', 'interview_reply', 'interview', 'review', 'client', '1on1', 'sync'];
const MEMORY_FILE = 'meeting-scenario-memory.json';
const MAX_LEARNED_GROUPS = 400;

const PRESETS = {
  active: {
    mode: 'active',
    hardEvidenceOnly: false,
    featured: true,
    zh: {
      label: '积极模式',
      tag: '默认',
      shortDesc: '默认主动出卡：覆盖事实核查、讨论盲区、外部案例与跨会记忆冲突',
      userRole: '参会人',
      goal: '主动捕捉事实核查、关键盲区、外部对照案例与跨会记忆冲突',
      watchFor: ['fact_check', 'blind_spot', 'external_case', 'memory_conflict'],
      suppress: ['会议复述', '泛泛建议', '说教式提醒', '无证据推测']
    },
    en: {
      label: 'Active',
      tag: 'Default',
      shortDesc: 'Default proactive mode: fact checks, blind spots, external benchmarks & memory conflicts',
      userRole: 'Participant',
      goal: 'Proactively surface fact checks, blind spots, external benchmarks and memory conflicts',
      watchFor: ['fact_check', 'blind_spot', 'external_case', 'memory_conflict'],
      suppress: ['meeting recap', 'generic advice', 'preachy coaching', 'ungrounded guesses']
    }
  },
  conservative: {
    mode: 'conservative',
    hardEvidenceOnly: true,
    featured: false,
    zh: {
      label: '保守模式',
      tag: '低打扰',
      shortDesc: '仅放行硬证据卡（事实核查、跨会记忆冲突），适合只想安静听会时切换',
      userRole: '参会人',
      goal: '仅在有硬证据（事实核查或跨会记忆冲突）时提醒',
      watchFor: ['fact_check', 'memory_conflict'],
      suppress: ['会议复述', '泛泛建议', '说教式提醒', '无证据推测']
    },
    en: {
      label: 'Conservative',
      tag: 'Quiet',
      shortDesc: 'Only hard-evidence cards (fact checks & memory conflicts) for minimal interruption',
      userRole: 'Participant',
      goal: 'Surface only hard-evidence fact checks or cross-meeting memory conflicts',
      watchFor: ['fact_check', 'memory_conflict'],
      suppress: ['meeting recap', 'generic advice', 'preachy coaching', 'ungrounded guesses']
    }
  },
  interview_reply: {
    mode: 'interview_reply',
    hardEvidenceOnly: false,
    featured: true,
    noAudioSave: true,
    zh: {
      label: '面试快答',
      tag: '练习+防空白',
      shortDesc: '面试练习与实战防大脑空白：0秒开口句、一题多问打勾、默认不留音频且会后一键销毁',
      userRole: '求职面试者',
      goal: '识别面试官提问，提供极简开口句与词块骨架，绝不编造经历',
      watchFor: ['interview_quick_reply'],
      suppress: ['长段落朗读稿', '编造数字与经历', '普通会议总结打扰']
    },
    en: {
      label: 'Interview Quick-Reply',
      tag: 'Prep + Live',
      shortDesc: 'Interview prep & real-time thinking aid: instant opener, multi-part checklist, no audio saved & 1-click wipe',
      userRole: 'Candidate',
      goal: 'Detect interviewer questions and surface ultra-brief opening cues without fabricating experience',
      watchFor: ['interview_quick_reply'],
      suppress: ['full-paragraph scripts', 'fabricated numbers or facts', 'generic meeting chatter']
    }
  },
  interview: {
    mode: 'interview',
    hardEvidenceOnly: false,
    featured: true,
    zh: {
      label: '用户调研访谈',
      tag: '高频重点',
      shortDesc: '追踪访谈盲区、未量化细节与外部对照案例',
      userRole: '访谈主持',
      goal: '捕捉未覆盖的访谈盲区、关键事实核查与外部对照案例',
      watchFor: ['blind_spot', 'fact_check', 'external_case', 'memory_conflict'],
      suppress: ['复述受访者原话', '教主持人怎么提问', '常规寒暄']
    },
    en: {
      label: 'User Interview',
      tag: 'Key mode',
      shortDesc: 'Track interview blind spots, unquantified gaps and external references',
      userRole: 'Interviewer',
      goal: 'Spot uncovered interview blind spots, fact checks and external benchmarks',
      watchFor: ['blind_spot', 'fact_check', 'external_case', 'memory_conflict'],
      suppress: ['repeating interviewee words', 'coaching how to ask', 'small talk']
    }
  },
  review: {
    mode: 'review',
    hardEvidenceOnly: false,
    featured: true,
    zh: {
      label: '研究型 / 方案评审',
      tag: '高频重点',
      shortDesc: '注入外部行业案例、对标数据、反例与架构盲区',
      userRole: '评审决策者',
      goal: '找出方案技术盲区、成熟产品对标数据、反例与历史决策冲突',
      watchFor: ['external_case', 'blind_spot', 'fact_check', 'memory_conflict'],
      suppress: ['复述方案内容', '泛泛架构说教', '无证据猜测']
    },
    en: {
      label: 'Design / Tech Review',
      tag: 'Key mode',
      shortDesc: 'Inject external benchmarks, counterexamples and technical blind spots',
      userRole: 'Reviewer',
      goal: 'Surface technical blind spots, benchmarks, counterexamples and past decision conflicts',
      watchFor: ['external_case', 'blind_spot', 'fact_check', 'memory_conflict'],
      suppress: ['restating proposal', 'generic engineering advice', 'ungrounded claims']
    }
  },
  client: {
    mode: 'client',
    hardEvidenceOnly: false,
    featured: false,
    zh: {
      label: '客户商务沟通',
      tag: '',
      shortDesc: '竞品核查、合规背书数据与历史承诺冲突提醒',
      userRole: '商务对接',
      goal: '核实对方提到的竞品方案与合规依据，警惕历史承诺冲突',
      watchFor: ['fact_check', 'external_case', 'memory_conflict', 'blind_spot'],
      suppress: ['复述客户原话', '销售话术说教', '无依据报价推测']
    },
    en: {
      label: 'Client & Sales',
      tag: '',
      shortDesc: 'Competitor fact-checks, compliance references and commitment conflicts',
      userRole: 'Account Lead',
      goal: 'Verify competitor claims and compliance facts; catch commitment conflicts',
      watchFor: ['fact_check', 'external_case', 'memory_conflict', 'blind_spot'],
      suppress: ['repeating client words', 'sales coaching', 'unverified pricing claims']
    }
  },
  '1on1': {
    mode: '1on1',
    hardEvidenceOnly: false,
    featured: false,
    zh: {
      label: '1:1 沟通',
      tag: '极静',
      shortDesc: '极静低打扰，仅在记忆冲突或关键事实偏差时开口',
      userRole: '1:1 对话方',
      goal: '保持安静，仅在跨会记忆冲突或硬事实偏差时提醒',
      watchFor: ['memory_conflict', 'fact_check'],
      suppress: ['常规进展复述', '管理说教', '高频打扰']
    },
    en: {
      label: '1:1 Check-in',
      tag: 'Quiet',
      shortDesc: 'Ultra-quiet: speak only on memory conflicts or clear factual discrepancies',
      userRole: '1:1 Participant',
      goal: 'Stay quiet except for cross-meeting memory conflicts or hard factual discrepancies',
      watchFor: ['memory_conflict', 'fact_check'],
      suppress: ['routine recap', 'management coaching', 'frequent interruptions']
    }
  },
  sync: {
    mode: 'sync',
    hardEvidenceOnly: false,
    featured: false,
    zh: {
      label: '常规同步 / 周会',
      tag: '低打扰',
      shortDesc: '过滤常规进度同步，仅拦记忆冲突与关键事实核查',
      userRole: '参会人',
      goal: '安静过滤常规进度播报，只拦跨会记忆冲突与硬事实偏差',
      watchFor: ['memory_conflict', 'fact_check'],
      suppress: ['常规进度播报', '周报复述', '泛泛提醒']
    },
    en: {
      label: 'Team Sync',
      tag: 'Quiet',
      shortDesc: 'Filter routine updates; interrupt only for memory conflicts or fact checks',
      userRole: 'Team Member',
      goal: 'Filter routine status updates; flag memory conflicts and hard fact checks only',
      watchFor: ['memory_conflict', 'fact_check'],
      suppress: ['routine status updates', 'recaps', 'generic reminders']
    }
  }
};

const SOURCE_LABELS = {
  zh: {
    default: '默认积极',
    learned: '本机习惯',
    calendar: '日历识别',
    frame: '自动识别',
    user: '已锁定'
  },
  en: {
    default: 'Active',
    learned: 'Learned locally',
    calendar: 'From calendar',
    frame: 'Auto-detected',
    user: 'Locked'
  }
};

const squeeze = s => String(s || '').replace(/\s+/g, ' ').trim();
const langOf = (session, lang) => ((lang || session?.uiLang || 'zh') === 'en' ? 'en' : 'zh');
const isRealPerson = value => {
  const s = squeeze(value);
  if (s.length < 2) return false;
  if (/^(?:S\d+|说话人\s*\d*|发言人\s*\d*|Speaker\s*\d*|Unknown|未知|Guest\s*\d*|访客\s*\d*)$/i.test(s)) return false;
  if (/^(?:vp-)?[a-f0-9-]{32,}$/i.test(s)) return false;
  return true;
};

function normalizeMode(value) {
  const raw = squeeze(value).toLowerCase();
  if (VALID_MODES.includes(raw)) return raw;
  if (/^1\s*[:：\/v-]\s*1$|^one[\s_-]*on[\s_-]*one$|^working[\s_-]*1\s*[:：]\s*1$/i.test(raw)) return '1on1';
  return '';
}

function classifyText(text) {
  const s = squeeze(text);
  if (!s) return '';
  if (/用户访谈|用户调研|深度访谈|调研访谈|受访者|user\s*interview|customer\s*interview|discovery\s*interview/i.test(s)) return 'interview';
  if (/方案评审|架构评审|设计评审|技术评审|需求评审|评审会|研究型|design\s*review|tech\s*review|architecture\s*review|rfc\s*review|\breview\b|评审|评估|路线图|对齐|规划|复盘|架构|方案|提速|功耗|优化|\b(?:benchmark|roadmap|architecture|design|postmortem|retrospective)\b/i.test(s)) return 'review';
  if (/客户沟通|客户拜访|商务沟通|商务谈判|售前|采购|报价|client\s*call|sales\s*call|customer\s*call|vendor\s*call|demo\s*call|商务/i.test(s)) return 'client';
  if (/(?:^|[\s·\-_/（(])1\s*[:：\/v-]\s*1(?:$|[\s·\-_/）)])|一对一|one[\s-]on[\s-]one|working[\s_-]*1\s*[:：]\s*1/i.test(s)) return '1on1';
  if (/周会|例会|站会|进度同步|信息同步|例行同步|weekly\s*sync|daily\s*standup|\bstandup\b|status\s*sync|\bsync\b/i.test(s)) return 'sync';
  return '';
}

function presetFor(mode, lang = 'zh') {
  const key = normalizeMode(mode) || 'active';
  const def = PRESETS[key] || PRESETS.active;
  const copy = def[lang === 'en' ? 'en' : 'zh'];
  return {
    mode: def.mode,
    userRole: copy.userRole,
    goal: copy.goal,
    watchFor: copy.watchFor.slice(),
    suppress: copy.suppress.slice(),
    hardEvidenceOnly: def.hardEvidenceOnly
  };
}

function cleanList(list, fallback, maxItems = 8, maxLen = 80) {
  if (!Array.isArray(list)) return fallback.slice();
  const out = [];
  for (const item of list) {
    const s = squeeze(item).slice(0, maxLen);
    if (s && !out.includes(s)) out.push(s);
    if (out.length >= maxItems) break;
  }
  return out.length ? out : fallback.slice();
}

function normalizeScenario(raw, { lang = 'zh', now = Date.now } = {}) {
  const mode = normalizeMode(raw?.mode) || 'active';
  const base = presetFor(mode, lang);
  const userRole = squeeze(raw?.userRole).slice(0, 60) || base.userRole;
  const goal = squeeze(raw?.goal).slice(0, 200) || base.goal;
  const watchFor = cleanList(raw?.watchFor, base.watchFor);
  const suppress = cleanList(raw?.suppress, base.suppress);
  const hardEvidenceOnly = typeof raw?.hardEvidenceOnly === 'boolean' ? raw.hardEvidenceOnly : mode === 'conservative';
  const locked = raw?.locked === true;
  const source = ['default', 'learned', 'calendar', 'frame', 'user'].includes(raw?.source) ? raw.source : (locked ? 'user' : 'default');
  const updatedAt = Number.isFinite(Number(raw?.updatedAt)) && Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : now();
  return { mode, userRole, goal, watchFor, suppress, hardEvidenceOnly, locked, source, updatedAt };
}

function extractParticipants(session = {}) {
  const names = [];
  const push = value => {
    const s = squeeze(value);
    if (isRealPerson(s)) names.push(s.toLowerCase());
  };
  const cal = session.calendar || {};
  const attendeeLists = [cal.attendees, cal.event?.attendeeList, cal.event?.attendees, session.participants];
  for (const list of attendeeLists) {
    if (!Array.isArray(list)) continue;
    for (const item of list) {
      if (typeof item === 'string') push(item);
      else if (item && typeof item === 'object' && !item.declined) {
        push(item.email || item.name || item.displayName || '');
      }
    }
  }
  if (session.names && typeof session.names === 'object') {
    for (const v of Object.values(session.names)) push(v);
  }
  return [...new Set(names)].sort();
}

function attendeeSignature(session = {}) {
  const people = extractParticipants(session);
  if (!people.length) return '';
  return crypto.createHash('sha256').update(people.join('|')).digest('hex').slice(0, 24);
}

function memoryPath(dataDir) {
  return dataDir ? path.join(dataDir, 'state', MEMORY_FILE) : '';
}

function readMemory(dataDir) {
  const file = memoryPath(dataDir);
  if (!file) return { version: 1, groups: {} };
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (parsed && typeof parsed === 'object' && parsed.groups && typeof parsed.groups === 'object') {
      return { version: 1, groups: parsed.groups };
    }
  } catch {}
  return { version: 1, groups: {} };
}

function writeMemory(dataDir, mem) {
  const file = memoryPath(dataDir);
  if (!file) return;
  const entries = Object.entries(mem.groups || {})
    .sort((a, b) => (Number(b[1]?.updatedAt) || 0) - (Number(a[1]?.updatedAt) || 0))
    .slice(0, MAX_LEARNED_GROUPS);
  journal.write(file, { version: 1, groups: Object.fromEntries(entries) });
}

function lookupLearned(session, dataDir) {
  if (!dataDir) return null;
  const sig = attendeeSignature(session);
  if (!sig) return null;
  const mem = readMemory(dataDir);
  const rec = mem.groups[sig];
  if (!rec) return null;
  const mode = normalizeMode(rec.mode);
  if (!mode) return null;
  return {
    mode,
    goal: squeeze(rec.goal).slice(0, 200),
    userRole: squeeze(rec.userRole).slice(0, 60),
    count: Math.max(1, Number(rec.count) || 1)
  };
}

function recordCorrection(session, scenario, { dataDir, now = Date.now } = {}) {
  if (!dataDir) return false;
  const sig = attendeeSignature(session);
  if (!sig) return false;
  const mem = readMemory(dataDir);
  const prev = mem.groups[sig] || { counts: {}, count: 0 };
  const counts = { ...(prev.counts || {}) };
  counts[scenario.mode] = (Number(counts[scenario.mode]) || 0) + 1;
  mem.groups[sig] = {
    mode: scenario.mode,
    userRole: scenario.userRole,
    goal: scenario.goal,
    count: (Number(prev.count) || 0) + 1,
    counts,
    updatedAt: now()
  };
  writeMemory(dataDir, mem);
  return true;
}

function inferFromMetadata(session = {}) {
  const calTitle = squeeze(session.calendar?.event?.title || session.calendar?.title || '');
  const calDesc = squeeze(session.calendar?.event?.description || '');
  const title = squeeze(session.topicTitle || session.title || '');
  const fromCal = classifyText(calTitle) || classifyText(calDesc);
  if (fromCal) return { mode: fromCal, source: 'calendar' };
  const fromTitle = classifyText(title);
  if (fromTitle) return { mode: fromTitle, source: 'calendar' };
  return null;
}

function resolveInitial(session = {}, { dataDir, lang, now = Date.now } = {}) {
  const uiLang = langOf(session, lang);
  if (session.meetingScenario && typeof session.meetingScenario === 'object') {
    return normalizeScenario(session.meetingScenario, { lang: uiLang, now });
  }
  const learned = lookupLearned(session, dataDir);
  if (learned) {
    const base = presetFor(learned.mode, uiLang);
    return normalizeScenario({
      ...base,
      userRole: learned.userRole || base.userRole,
      goal: learned.goal || base.goal,
      locked: false,
      source: 'learned',
      updatedAt: now()
    }, { lang: uiLang, now });
  }
  const meta = inferFromMetadata(session);
  if (meta) {
    return normalizeScenario({
      ...presetFor(meta.mode, uiLang),
      locked: false,
      source: meta.source,
      updatedAt: now()
    }, { lang: uiLang, now });
  }
  // t=0 undecided default: active mode (proactive cards enabled; user can switch to conservative anytime).
  return normalizeScenario({
    ...presetFor('active', uiLang),
    hardEvidenceOnly: false,
    locked: false,
    source: 'default',
    updatedAt: now()
  }, { lang: uiLang, now });
}

function ensure(session, opts = {}) {
  const sc = resolveInitial(session, opts);
  if (session && typeof session === 'object') session.meetingScenario = sc;
  return sc;
}

function override(session, patch = {}, { dataDir, lang, now = Date.now } = {}) {
  if (!session || typeof session !== 'object') throw Error('session_required');
  const uiLang = langOf(session, lang);
  const current = ensure(session, { dataDir, lang: uiLang, now });
  const requestedMode = patch.mode !== undefined ? normalizeMode(patch.mode) : current.mode;
  if (patch.mode !== undefined && !requestedMode) throw Error('invalid_scenario_mode');
  const modeChanged = requestedMode !== current.mode;
  const base = presetFor(requestedMode, uiLang);
  const next = normalizeScenario({
    mode: requestedMode,
    userRole: patch.userRole !== undefined ? patch.userRole : (modeChanged ? base.userRole : current.userRole),
    goal: patch.goal !== undefined ? (squeeze(patch.goal) || base.goal) : (modeChanged ? base.goal : current.goal),
    watchFor: patch.watchFor !== undefined ? patch.watchFor : (modeChanged ? base.watchFor : current.watchFor),
    suppress: patch.suppress !== undefined ? patch.suppress : (modeChanged ? base.suppress : current.suppress),
    hardEvidenceOnly: typeof patch.hardEvidenceOnly === 'boolean' ? patch.hardEvidenceOnly : base.hardEvidenceOnly,
    locked: true,
    source: 'user',
    updatedAt: now()
  }, { lang: uiLang, now });
  session.meetingScenario = next;
  recordCorrection(session, next, { dataDir, now });
  return next;
}

function applyFrame(session, frame, { dataDir, lang, now = Date.now } = {}) {
  if (!session || typeof session !== 'object' || !frame || typeof frame !== 'object') return session?.meetingScenario || null;
  const uiLang = langOf(session, lang);
  const current = ensure(session, { dataDir, lang: uiLang, now });
  // User-locked scenario stays locked for the entire meeting.
  if (current.locked) return current;
  const detectedMode = classifyText(frame.type || '');
  if (!detectedMode) return current;
  // Only upgrade automatically when still on default conservative or prior frame inference.
  if (!['default', 'frame'].includes(current.source)) return current;
  const base = presetFor(detectedMode, uiLang);
  // Never copy frame.purpose (private frame) into scenario.
  const next = normalizeScenario({
    ...base,
    locked: false,
    source: 'frame',
    updatedAt: now()
  }, { lang: uiLang, now });
  session.meetingScenario = next;
  return next;
}

function forModel(session, opts = {}) {
  const sc = ensure(session, opts);
  return {
    mode: sc.mode,
    userRole: sc.userRole,
    goal: sc.goal,
    watchFor: sc.watchFor.slice(),
    suppress: sc.suppress.slice(),
    hardEvidenceOnly: sc.hardEvidenceOnly,
    locked: sc.locked,
    source: sc.source
  };
}

function listModes(lang = 'zh', opts = {}) {
  const key = lang === 'en' ? 'en' : 'zh';
  const iqrOn = require('./feature-flags').isFeatureEnabled('interviewQuickReply', opts);
  return VALID_MODES.filter(mode => mode !== 'interview_reply' || iqrOn).map(mode => {
    const def = PRESETS[mode];
    const copy = def[key];
    return {
      mode: def.mode,
      label: copy.label,
      tag: copy.tag,
      shortDesc: copy.shortDesc,
      featured: !!def.featured,
      hardEvidenceOnly: !!def.hardEvidenceOnly,
      defaultGoal: copy.goal,
      userRole: copy.userRole
    };
  });
}

function forClient(session, { dataDir, lang } = {}) {
  const uiLang = langOf(session, lang);
  const sc = ensure(session, { dataDir, lang: uiLang });
  const def = PRESETS[sc.mode] || PRESETS.conservative;
  const copy = def[uiLang];
  const srcLabels = SOURCE_LABELS[uiLang];
  return {
    mode: sc.mode,
    label: copy.label,
    shortDesc: copy.shortDesc,
    userRole: sc.userRole,
    goal: sc.goal,
    watchFor: sc.watchFor.slice(),
    suppress: sc.suppress.slice(),
    hardEvidenceOnly: sc.hardEvidenceOnly,
    locked: sc.locked,
    source: sc.source,
    sourceLabel: sc.locked ? srcLabels.user : (srcLabels[sc.source] || srcLabels.default),
    options: listModes(uiLang, { dataDir })
  };
}

module.exports = {
  VALID_MODES,
  PRESETS,
  MEMORY_FILE,
  normalizeMode,
  classifyText,
  presetFor,
  attendeeSignature,
  resolveInitial,
  ensure,
  override,
  applyFrame,
  forModel,
  forClient,
  listModes,
  readMemory,
  lookupLearned,
  recordCorrection
};
