'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

// Only remove historical backup/stage bundles left behind by the retired
// canonical-app-upgrade backup/rollback mechanism. Never touch Citeside.app
// itself, unrelated apps, or symlinks.
const LEGACY_CANONICAL_BUNDLE_RE = /^Citeside\.app\.canonical-(?:backup|stage)-[a-f0-9-]{36}\.app$/i;

function cleanupLegacyCanonicalBundles({ dirs, home = os.homedir(), platform = process.platform, log = () => {} } = {}) {
  const removed = [];
  if (platform !== 'darwin') return removed;
  const targets = Array.isArray(dirs) ? dirs : ['/Applications', path.join(home, 'Applications')];
  const seen = new Set();
  for (const dir of targets) {
    if (!dir || seen.has(dir)) continue;
    seen.add(dir);
    let entries;
    try {
      entries = fs.readdirSync(dir);
    } catch {
      continue;
    }
    for (const name of entries) {
      if (!LEGACY_CANONICAL_BUNDLE_RE.test(name)) continue;
      const fullPath = path.join(dir, name);
      try {
        const stat = fs.lstatSync(fullPath);
        if (stat.isSymbolicLink() || !stat.isDirectory()) continue;
        fs.rmSync(fullPath, { recursive: true, force: true });
        removed.push(fullPath);
        log(`[cleanup] removed legacy canonical bundle: ${fullPath}`);
      } catch (err) {
        log(`[cleanup] skipped legacy canonical bundle ${fullPath}: ${err.message}`);
      }
    }
  }
  return removed;
}

module.exports = { cleanupLegacyCanonicalBundles, LEGACY_CANONICAL_BUNDLE_RE };
