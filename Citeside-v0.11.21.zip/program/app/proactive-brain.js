'use strict';

// Single-Brain Proactive Intelligence Engine (v3)
// Replaces 4 competing live-meeting LLM loops with ONE unified 2-stage brain:
//   Stage 1 (1 fast LLM call): unified triage + working memory update across all 4 core card types
//     - blind_spot & memory_conflict emit immediately (~2s, 0 search wait)
//     - fact_check & external_case enqueue up to 2 search targets
//   Stage 2 (parallel search + 1 verify-and-write LLM call):
//     - Hard Red Line: 0 fabricated URLs (every URL must belong to real opened search results)
//     - Honest Grading: quoted (exact quote + numbersSupported) vs source (real https:// page + numbersConsistent)
//     - Structured funnel diagnostics (0 black-box drops)

const numNorm = require('./number-normalize');
const scenarioMod = require('./meeting-scenario');

const BADGE_MAP = {
  fact_check: { zh: '事实核查', en: 'Fact check' },
  blind_spot: { zh: '盲区', en: 'Blind spot' },
  external_case: { zh: '外部案例', en: 'External case' },
  memory_conflict: { zh: '记忆冲突', en: 'Memory conflict' }
};

const MODEL_LIMIT = 900;
const MAX_SEARCH_CARDS_PER_WAKE = 2;
const DEFAULT_MAX_SEARCHES = 15;

function parseJsonObject(raw) {
  const s = String(raw || '').trim();
  if (!s) return null;
  let pos = 0;
  let fallback = null;
  while (pos < s.length) {
    const start = s.indexOf('{', pos);
    if (start < 0) break;
    let depth = 0, inStr = false, esc = false, end = -1;
    for (let i = start; i < s.length; i++) {
      const ch = s[i];
      if (inStr) {
        if (esc) { esc = false; continue; }
        if (ch === '\\') { esc = true; continue; }
        if (ch === '"') inStr = false;
        continue;
      }
      if (ch === '"') { inStr = true; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) { end = i; break; }
      }
    }
    if (end < 0) break;
    try {
      const obj = JSON.parse(s.slice(start, end + 1));
      if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
        if ('cards' in obj || 'verdict' in obj || 'meetingModel' in obj) return obj;
        if (!fallback) fallback = obj;
      }
      pos = end + 1;
    } catch {
      pos = start + 1;
    }
  }
  return fallback;
}

function normText(s) {
  return String(s || '').replace(/[\s\p{P}\p{S}]+/gu, '').toLowerCase();
}

function groundQuote(excerpt, quote) {
  const ex = String(excerpt || '').replace(/\s+/g, ' ').trim();
  const q = String(quote || '').replace(/\s+/g, ' ').trim();
  if (!ex || q.length < 12) return '';
  if (ex.includes(q)) return q;
  const exLow = ex.toLowerCase(), qLow = q.toLowerCase();
  const idx = exLow.indexOf(qLow);
  if (idx >= 0) return ex.slice(idx, idx + q.length);
  return '';
}

function withBadge(kind, card, en) {
  const safeKind = BADGE_MAP[kind] ? kind : 'blind_spot';
  return {
    ...card,
    cardKind: safeKind,
    semanticBadge: BADGE_MAP[safeKind][en ? 'en' : 'zh']
  };
}

function buildTriageSystemPrompt(session, scenario) {
  const en = session?.uiLang === 'en';
  const watchFor = (scenario?.watchFor || ['fact_check', 'blind_spot', 'external_case', 'memory_conflict']).join(', ');
  const hardOnly = !!scenario?.hardEvidenceOnly;
  if (en) {
    return [
      'You are the user\'s private meeting copilot. Cards are visible ONLY to the user, who reviews them personally.',
      `Scenario: ${scenario?.label || 'Active'} (${scenario?.goal || ''}). Focus on: ${watchFor}.`,
      hardOnly
        ? 'Quiet mode: ONLY emit fact_check or memory_conflict when there is a concrete factual error or direct conflict with past memory.'
        : 'Surface high-value cards when >=50% confident it helps the user right now. Never echo/recap what was just said.',
      'Card types:',
      '- fact_check: speaker states a verifiable number, date, policy, or technical claim that may be wrong or outdated. Return claim + 1-2 short search queries.',
      '- external_case: speaker discusses a design/strategy problem where a concrete industry benchmark or mature precedent helps. Return claim + 1-2 short search queries.',
      '- blind_spot: critical unexamined risk, missing trade-off, or contradiction inside this meeting. Provide concise title + text directly (emitted immediately).',
      '- memory_conflict: direct contradiction with memoryHints. Must copy >=12 verbatim chars from memoryHints into basis, plus concise title + text.',
      'Return JSON only: {"meetingModel":"<=900 char working summary","cards":[{"kind":"fact_check|blind_spot|external_case|memory_conflict","title":"...","text":"...","details":"...","claim":"...","queries":["..."],"basis":"...","sourceIds":["..."]}]}',
      'Return {"meetingModel":"...","cards":[]} if nothing is worth interrupting for (e.g. small talk).'
    ].join('\n');
  }
  return [
    '你是使用者的私人会议副驾，卡片只给他一个人看，他会自己复核。有 50% 以上把握对他有实际帮助就出卡，严禁复述发言内容。',
    `当前场景：${scenario?.label || '积极模式'}（${scenario?.goal || ''}）。重点关注：${watchFor}。`,
    hardOnly
      ? '低打扰模式：仅当出现明确事实偏差（fact_check）或与跨会记忆直接冲突（memory_conflict）时才出卡。'
      : '覆盖四类高价值主动智能：',
    '- fact_check：发言中出现可能不准、过时或存疑的具体数字、年份、政策、技术定义，输出 claim + 1~2 个精准检索词 queries。',
    '- external_case：讨论方案/定价/架构时，有成熟外部行业案例或对标数据可参考，输出 claim + 1~2 个精准检索词 queries。',
    '- blind_spot：讨论漏掉的关键风险、未量化前提、或本场前后发言自相矛盾；直接写精炼 title 和 text（立即出卡，不联网）。',
    '- memory_conflict：与下方 memoryHints 里的跨会历史决定/承诺冲突；必须在 basis 中原样摘录 memoryHints 里 >=12 字的依据，并写 title 和 text。',
    '只返回严格 JSON：{"meetingModel":"<=900字工作记忆","cards":[{"kind":"fact_check|blind_spot|external_case|memory_conflict","title":"简短结论标题","text":"1-2句核心内容","details":"可选展开","claim":"待核查陈述","queries":["检索词"],"basis":"记忆原句","sourceIds":["r1"]}]}',
    '如果只是寒暄、过渡或无高价值信息，返回 {"meetingModel":"...","cards":[]}。'
  ].join('\n');
}

function buildVerifyWriteSystemPrompt(session, kind) {
  const en = session?.uiLang === 'en';
  if (en) {
    return [
      'You are verifying a meeting claim against opened web excerpts and writing ONE concise private card for the user.',
      kind === 'external_case'
        ? 'Summarize the most relevant real-world precedent/benchmark from the opened pages.'
        : 'Correct or verify the claim using ONLY the opened pages. If a number may be an ASR mishear, phrase as "If X was said, public data shows Y".',
      'HARD RULE: Every source URL MUST be copied verbatim from the provided opened pages. Never invent a URL. Do not use sources older than the period discussed to "correct" newer data.',
      'Return JSON only: {"verdict":"pass|skip","title":"short headline","text":"1-2 concise sentences","details":"optional detail","caveat":"optional caveat","credibility":"Verified|Public source","sources":[{"name":"source name","url":"https://...","quote":"verbatim quote >=12 chars from excerpt"}]}'
    ].join('\n');
  }
  return [
    '你正在根据程序已打开的公开网页正文核实会议陈述，并直接写出一张精炼的私人参考卡。',
    kind === 'external_case'
      ? '提炼网页中最相关的外部成熟案例或对标数据，直接给出可借鉴结论。'
      : '仅依据提供的网页正文纠偏或核实。若数字可能是语音听错，写成“若会上说的是X，公开数据为Y（来源）”。',
    '硬红线：sources 里的 url 必须原样来自提供的 opened 网页列表，严禁编造任何网址；来源日期早于会议所述期间的，不能用来纠正较新数据。',
    '只返回严格 JSON：{"verdict":"pass|skip","title":"<=22字结论标题","text":"1-2句核心纠正或案例","details":"可选补充","caveat":"可选边界提醒","credibility":"权威来源|公开来源","sources":[{"name":"来源名","url":"https://...","quote":"从正文原样摘录>=12字引文"}]}'
  ].join('\n');
}

function create({
  session,
  ask,
  search,
  pageFetch,
  dataDir = '',
  env = () => ({}),
  log = () => {},
  now = Date.now,
  contextVersion = () => '',
  active = () => true,
  onStatus = () => {},
  onCard = () => true,
  onPending = () => {}
} = {}) {
  const getEnv = typeof env === 'function' ? env : () => env || {};
  const maxSearches = Math.max(1, Number(getEnv().LIVE_EXPERT_MAX_SEARCHES) || DEFAULT_MAX_SEARCHES);
  const searchCache = new Map();
  const shownNorms = new Set();
  const shownTitles = [];
  let closed = false;
  let running = false;
  let waiting = null;
  let generation = 0;
  let wakeSeq = 0;
  let searchCount = 0;

  const stats = {
    engine: 'single-brain-v3',
    wakes: 0,
    triageCalls: 0,
    verifyCalls: 0,
    searchCalls: 0,
    searchCacheHits: 0,
    published: 0,
    emittedByKind: { fact_check: 0, blind_spot: 0, external_case: 0, memory_conflict: 0 },
    emittedByEvidence: { quoted: 0, source: 0, meeting: 0, memory: 0 },
    fabricatedUrlBlocked: 0,
    dropsByReason: {},
    recentDrops: []
  };

  function recordDrop(reason, detail) {
    stats.dropsByReason[reason] = (stats.dropsByReason[reason] || 0) + 1;
    stats.recentDrops.push({ at: now(), reason, ...detail });
    if (stats.recentDrops.length > 25) stats.recentDrops.shift();
  }

  function isDuplicate(title, text) {
    const nt = normText(title);
    const nb = normText(text);
    if (nt && shownNorms.has('t:' + nt)) return true;
    if (nb && shownNorms.has('b:' + nb)) return true;
    return false;
  }

  function rememberShown(title, text) {
    const nt = normText(title);
    const nb = normText(text);
    if (nt) shownNorms.add('t:' + nt);
    if (nb) shownNorms.add('b:' + nb);
    if (title) shownTitles.push(String(title).slice(0, 60));
    if (shownTitles.length > 20) shownTitles.shift();
  }

  function live() {
    return !closed && !!active();
  }

  function defaultSearch(q) {
    const webTool = require('./tools/web');
    return webTool.search(q, 3, { dataDir, env: getEnv() });
  }

  function defaultFetch(url) {
    return require('./public-page-fetch').fetch(url, { timeoutMs: 8000 });
  }

  async function runSearch(query) {
    const key = String(query || '').trim().toLowerCase();
    if (!key) return [];
    if (searchCache.has(key)) {
      stats.searchCacheHits++;
      return searchCache.get(key);
    }
    if (searchCount >= maxSearches) {
      recordDrop('search_budget_exhausted', { query });
      return [];
    }
    searchCount++;
    stats.searchCalls++;
    const fn = search || defaultSearch;
    try {
      const res = await fn(query);
      const list = Array.isArray(res) ? res : (Array.isArray(res?.results) ? res.results : []);
      searchCache.set(key, list);
      return list;
    } catch (e) {
      log('proactive-brain search error: ' + (e && e.message || e));
      return [];
    }
  }

  async function openPages(queries) {
    const opened = new Map();
    const fetchFn = pageFetch || defaultFetch;
    for (const q of (queries || []).slice(0, 2)) {
      if (opened.size >= 2) break;
      const hits = await runSearch(q);
      for (const h of hits.slice(0, 3)) {
        if (opened.size >= 2) break;
        const url = String(h?.url || '').trim();
        if (!/^https:\/\//.test(url) || opened.has(url)) continue;
        let excerpt = String(h?.excerpt || h?.content || h?.snippet || '').replace(/\s+/g, ' ').trim();
        if (excerpt.length < 80) {
          try {
            const page = await fetchFn(url);
            if (page?.excerpt && String(page.excerpt).trim().length > excerpt.length) {
              excerpt = String(page.excerpt).replace(/\s+/g, ' ').trim();
            }
          } catch {}
        }
        if (excerpt.length >= 20) {
          opened.set(url, {
            name: String(h?.name || h?.title || ''),
            url,
            excerpt: excerpt.slice(0, 1800),
            publishedAt: String(h?.publishedAt || h?.published_date || 'unknown')
          });
        }
      }
    }
    return opened;
  }

  async function emitCard(kind, card, evidenceLevel, startedAt, wakeGen) {
    const en = session?.uiLang === 'en';
    const title = String(card.title || '').trim();
    const text = String(card.text || '').trim();
    if (!title && !text) return false;
    if (isDuplicate(title, text)) {
      recordDrop('duplicate', { kind, title });
      return false;
    }
    const payload = withBadge(kind, {
      title,
      text,
      ...(card.details ? { details: String(card.details).trim() } : {}),
      caveat: String(card.caveat || '').trim(),
      sources: Array.isArray(card.sources) ? card.sources : [],
      credibility: String(card.credibility || ''),
      evidenceLevel,
      sourceIds: Array.isArray(card.sourceIds) ? card.sourceIds : [],
      sourceLayer: card.sourceLayer || (evidenceLevel === 'meeting' ? 'meeting' : evidenceLevel === 'memory' ? 'memory' : 'external'),
      latencyMs: Math.max(0, now() - startedAt),
      isCurrent: () => live() && (wakeGen === undefined || wakeGen === generation)
    }, en);
    const accepted = await onCard(payload);
    if (accepted !== false) {
      rememberShown(title, text);
      stats.published++;
      stats.emittedByKind[payload.cardKind] = (stats.emittedByKind[payload.cardKind] || 0) + 1;
      stats.emittedByEvidence[evidenceLevel] = (stats.emittedByEvidence[evidenceLevel] || 0) + 1;
      return true;
    }
    recordDrop('rejected_by_consumer', { kind, title });
    return false;
  }

  async function verifyAndEmit(candidate, rows, startedAt, wakeGen) {
    const kind = candidate.kind === 'external_case' ? 'external_case' : 'fact_check';
    const queries = Array.isArray(candidate.queries) ? candidate.queries.filter(q => typeof q === 'string' && q.trim()).slice(0, 2) : [];
    const claim = String(candidate.claim || candidate.text || candidate.title || '').trim();
    if (!queries.length || !claim) {
      recordDrop('missing_query_or_claim', { kind, claim });
      return;
    }
    const opened = await openPages(queries);
    if (!live() || wakeGen !== generation) return;
    if (!opened.size) {
      recordDrop('no_page', { kind, claim, queries });
      onPending({
        id: `${session?.id || 'sess'}:brain:${wakeSeq}:${kind}`,
        kind: 'insight',
        title: session?.uiLang === 'en' ? 'Needs verification' : '待核实',
        body: claim,
        sourceIds: Array.isArray(candidate.sourceIds) ? candidate.sourceIds : [],
        sourceLayer: 'external',
        reason: 'no_page'
      });
      return;
    }

    const today = new Date(now()).toISOString().slice(0, 10);
    const payload = {
      today,
      kind,
      claim,
      transcriptTail: rows.slice(-4).map(r => `[${r.t || ''}] ${r.text || ''}`),
      opened: [...opened.values()]
    };
    stats.verifyCalls++;
    const raw = await ask(buildVerifyWriteSystemPrompt(session, kind), JSON.stringify(payload), {
      sessionId: session?.id || '',
      purpose: 'live-expert-check',
      maxTokens: 900,
      timeoutMs: 18000
    });
    if (!live() || wakeGen !== generation) return;
    const v = parseJsonObject(raw);
    if (!v || v.verdict !== 'pass' || !String(v.text || '').trim()) {
      recordDrop('verdict_skip', { kind, claim, verdict: v?.verdict || 'parse_failed' });
      return;
    }

    const quotedSources = [];
    const fallbackSources = [];
    for (const src of (Array.isArray(v.sources) ? v.sources : []).slice(0, 2)) {
      const url = String(src?.url || '').trim();
      if (!/^https:\/\//.test(url) || !opened.has(url)) {
        if (url) stats.fabricatedUrlBlocked++;
        continue;
      }
      const page = opened.get(url);
      const excerpt = page.excerpt;
      const quote = String(src?.quote || '').replace(/\s+/g, ' ').trim();
      const grounded = groundQuote(excerpt, quote);
      const numStrict = numNorm.numbersSupported(v.text, excerpt, claim);
      const numPartial = numStrict || numNorm.numbersConsistent(v.text, excerpt);

      if (grounded && numStrict) {
        quotedSources.push({
          name: String(src?.name || page.name || ''),
          url,
          quote: grounded,
          evidenceKind: 'public_page_excerpt',
          excerpt,
          fetchedAt: now()
        });
      } else if (grounded || numPartial) {
        fallbackSources.push({
          name: String(src?.name || page.name || ''),
          url,
          quote: grounded || '',
          evidenceKind: grounded ? 'public_page_excerpt' : 'public_page_unverified',
          excerpt,
          fetchedAt: now()
        });
      }
    }

    if (quotedSources.length) {
      await emitCard(kind, {
        title: v.title || candidate.title,
        text: v.text,
        details: v.details,
        caveat: v.caveat,
        credibility: v.credibility || (session?.uiLang === 'en' ? 'Verified' : '权威来源'),
        sources: quotedSources,
        sourceIds: candidate.sourceIds,
        sourceLayer: 'external'
      }, 'quoted', startedAt, wakeGen);
      return;
    }
    if (fallbackSources.length) {
      await emitCard(kind, {
        title: v.title || candidate.title,
        text: v.text,
        details: v.details,
        caveat: v.caveat,
        credibility: session?.uiLang === 'en' ? 'Public source' : '公开来源',
        sources: fallbackSources,
        sourceIds: candidate.sourceIds,
        sourceLayer: 'external'
      }, 'source', startedAt, wakeGen);
      return;
    }

    recordDrop('ungrounded', {
      kind,
      claim: claim.slice(0, 80),
      corrected: String(v.text || '').slice(0, 80),
      sourceCount: (v.sources || []).length
    });
  }

  async function processWake(job) {
    const startedAt = now();
    const wakeGen = job.gen;
    const rows = job.rows || [];
    if (!rows.length || !live()) return;

    const scenario = scenarioMod.ensure(session || {}, { dataDir, now });
    let memoryHints = '';
    try {
      const liveExpert = require('./live-expert');
      if (typeof liveExpert.buildMemoryHints === 'function') {
        memoryHints = String(liveExpert.buildMemoryHints(session, dataDir) || '');
      }
    } catch {}
    if (!memoryHints && typeof session?.memoryHints === 'string') {
      memoryHints = session.memoryHints;
    }

    // Cache-friendly payload order: append-only working memory + shownCards -> newest transcript window + memoryHints
    const userPayload = {
      meetingModel: String(session?.expertModel || '').slice(0, MODEL_LIMIT),
      shownCards: shownTitles.slice(-12),
      recentTranscript: rows.slice(-10).map(r => ({ id: r.id || '', t: r.t || '', speaker: r.speaker || '', text: String(r.text || '').slice(0, 320) })),
      ...(memoryHints ? { memoryHints: memoryHints.slice(0, 2000) } : {})
    };

    stats.triageCalls++;
    const raw = await ask(buildTriageSystemPrompt(session, scenario), JSON.stringify(userPayload), {
      sessionId: session?.id || '',
      purpose: 'live-expert-understand',
      maxTokens: 1100,
      timeoutMs: 18000
    });
    if (!live() || wakeGen !== generation) return;
    const parsed = parseJsonObject(raw);
    if (!parsed) {
      recordDrop('triage_parse_failed', { wakeId: job.wakeId });
      return;
    }
    if (typeof parsed.meetingModel === 'string' && parsed.meetingModel.trim() && session) {
      session.expertModel = parsed.meetingModel.trim().slice(0, MODEL_LIMIT);
    }

    const candidates = Array.isArray(parsed.cards) ? parsed.cards : [];
    const searchQueue = [];

    for (const c of candidates) {
      if (!c || typeof c !== 'object') continue;
      const kind = String(c.kind || '').trim();
      if (kind === 'blind_spot') {
        if (scenario?.hardEvidenceOnly) {
          recordDrop('scenario_hard_evidence_only', { kind, title: c.title });
          continue;
        }
        await emitCard('blind_spot', {
          title: c.title,
          text: c.text,
          details: c.details,
          sourceIds: c.sourceIds,
          sourceLayer: 'meeting'
        }, 'meeting', startedAt, wakeGen);
      } else if (kind === 'memory_conflict') {
        const basis = String(c.basis || '').trim();
        if (basis.length < 10 || !normText(memoryHints).includes(normText(basis))) {
          recordDrop('memory_ungrounded', { kind, title: c.title });
          continue;
        }
        await emitCard('memory_conflict', {
          title: c.title,
          text: c.text,
          details: c.details || basis,
          sources: [{ name: session?.uiLang === 'en' ? 'Past meeting memory' : '跨会记忆', url: '', quote: basis }],
          sourceIds: c.sourceIds,
          sourceLayer: 'memory'
        }, 'memory', startedAt, wakeGen);
      } else if (kind === 'fact_check' || kind === 'external_case') {
        if (searchQueue.length < MAX_SEARCH_CARDS_PER_WAKE) {
          searchQueue.push(c);
        }
      }
    }

    if (searchQueue.length) {
      onStatus({ state: 'checking', kind: searchQueue[0].kind, count: searchQueue.length });
      try {
        await Promise.all(searchQueue.map(c => verifyAndEmit(c, rows, startedAt, wakeGen).catch(e => {
          log('proactive-brain verify error: ' + (e && e.message || e));
          recordDrop('verify_error', { kind: c.kind, error: String(e && e.message || e) });
        })));
      } finally {
        onStatus({ state: 'idle', count: 0 });
      }
    }
  }

  async function drain() {
    if (running) return;
    running = true;
    try {
      while (waiting && live()) {
        const job = waiting;
        waiting = null;
        try {
          await processWake(job);
        } catch (e) {
          log('proactive-brain drain error: ' + (e && e.message || e));
          recordDrop('drain_error', { error: String(e && e.message || e) });
        }
      }
    } finally {
      running = false;
      if (waiting && live()) drain();
    }
  }

  return {
    wake(rows, focus = '') {
      if (!live() || !Array.isArray(rows) || !rows.length) return;
      stats.wakes++;
      const wakeId = 'sb' + (++wakeSeq);
      waiting = { rows: rows.map(r => ({ ...r })), focus, gen: generation, wakeId, ctxVer: contextVersion() };
      drain();
    },
    invalidate() {
      generation++;
      waiting = null;
      onStatus({ state: 'idle', count: 0 });
    },
    close() {
      closed = true;
      waiting = null;
      onStatus({ state: 'idle', count: 0 });
    },
    pending() {
      return !!waiting || running;
    },
    funnel() {
      return { ...stats, emittedByKind: { ...stats.emittedByKind }, emittedByEvidence: { ...stats.emittedByEvidence }, dropsByReason: { ...stats.dropsByReason }, recentDrops: stats.recentDrops.slice() };
    }
  };
}

module.exports = { create, parseJsonObject, groundQuote, withBadge };
