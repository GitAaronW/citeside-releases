'use strict';
const {meetingClock}=require('./meeting-time');
// The native panel is a second view of the same Session, never another archive.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{execFile}=require('child_process');
const journal=require('./session-journal');
// A test helper has a separate bundle identity; production never reads the override.
const APP=process.env.THT_TEST==='1'&&path.isAbsolute(process.env.THT_NATIVE_TEST_APP||'')?process.env.THT_NATIVE_TEST_APP:path.join(__dirname,'native-capture','CitesideCapture.app');
const BIN=path.join(APP,'Contents','MacOS','Citeside');
function available(){return process.platform==='darwin'&&fs.existsSync(BIN);}
function meetingLink(value){
  if(typeof value!=='string')throw Error('请粘贴完整的会议链接');
  let u;try{u=new URL(value);}catch{throw Error('请粘贴完整的飞书 / Lark 或 Google Meet 会议链接');}
  if(u.protocol!=='https:'||u.username||u.password||u.port||value.length>2000)throw Error('invalid_meeting_link');
  const valid=u.hostname==='meet.google.com'?/^\/[a-z]{3}-[a-z]{4}-[a-z]{3}\/?$/.test(u.pathname):['vc.feishu.cn','vc.larksuite.com','vc-sg.larksuite.com'].includes(u.hostname)&&/^\/j\/\d{9}\/?$/.test(u.pathname);
  if(!valid)throw Error('目前支持飞书 / Lark 的 /j/ 会议链接与 Google Meet 会议链接');
  return u.href;
}
const STALE_TOLERANCE_ROWS=4;
const cardMeaning=c=>({...c,text:c.details||c.text});
// Exact shipped prompt hashes, including persisted defaults. A revision number alone never identifies a default.
const LEGACY_RULE_PROMPTS=new Set(["30a2fd4accd85ba3e071f687d39117c829ab96e41264961759b04cd3f466f746", "339d778d0b71fe4a8c5f101d21b86210723fa110478cd81fddc0ac1e6bc4417f", "5b8ea2d9f2ee276b094b27a375f614eae6e41613fb8707a71120b3f6a8af3c85", "24978e0b1135b769d42e1fc43f3a0e4dc0df9777441a6073cdf9ea645b328bb7", "61cb39d39c207e5e2abd483b80f235258567fa64c89db174586e73cf86c9f244", "abe40c687362683d0ef6031fcbe0e2af05821e5ae0ff2f1fab6867af8ffa5675", "f3a73559b5d5797a0f10b8869a2e5b73bd9805cd6e132d7067cc909f704bbe18", "a7fe8a1c9a907054880977c8c63c286262b74e2bd51d50364f9120a39658e192"]);
function rules(dataDir){
  const fallback=JSON.parse(fs.readFileSync(path.join(__dirname,'native-insight-rules.json'),'utf8'));
  fallback.prompt=require('./live-card-body').renderPrompt(fallback.prompt);
  let x;try{x=JSON.parse(fs.readFileSync(path.join(dataDir,'state','native-insight-rules.json'),'utf8'));}catch{x=fallback;}
  if(typeof x.prompt==='string'&&LEGACY_RULE_PROMPTS.has(crypto.createHash('sha256').update(x.prompt).digest('hex'))){x={...x,prompt:fallback.prompt,revision:fallback.revision};journal.write(path.join(dataDir,'state','native-insight-rules.json'),x);}
  return {revision:String(x.revision||fallback.revision).slice(0,40),prompt:typeof x.prompt==='string'&&x.prompt.trim()?x.prompt.slice(0,6000):fallback.prompt,
    minGapMs:Math.max(1000,Math.min(60000,Number(x.minGapMs)||fallback.minGapMs)),recentSentences:Math.max(1,Math.min(6,Number(x.recentSentences)||6)),maxTextChars:Math.max(200,Math.min(2400,Number(x.maxTextChars)||2400)),requireAction:typeof x.requireAction==='boolean'?x.requireAction:!!fallback.requireAction};
}
function jpegSize(b){
  if(b.length<4||b[0]!==255||b[1]!==216)throw Error('invalid_jpeg');
  for(let i=2;i<b.length;){if(b[i++]!==255)throw Error('invalid_jpeg');while(b[i]===255)i++;const m=b[i++];if(m===217||m===218)break;if(m===1||(m>=208&&m<=215))continue;
    if(i+2>b.length)break;const n=b.readUInt16BE(i);if(n<2||i+n>b.length)break;
    if([192,193,194].includes(m)){if(n<8)break;return {width:b.readUInt16BE(i+5),height:b.readUInt16BE(i+3)};}i+=n;
  }throw Error('invalid_jpeg');
}
function parseFirstJsonObject(raw){
  const s=String(raw||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();
  try{return JSON.parse(s);}catch{}
  let fallbackObj=null;
  let pos=0;
  while(pos<s.length){
    const start=s.indexOf('{',pos);
    if(start<0)break;
    let depth=0,inStr=false,esc=false,end=-1;
    for(let i=start;i<s.length;i++){
      const ch=s[i];
      if(inStr){if(esc){esc=false;}else if(ch==='\\'){esc=true;}else if(ch==='"'){inStr=false;}continue;}
      if(ch==='"'){inStr=true;continue;}
      if(ch==='{')depth++;
      else if(ch==='}'){depth--;if(depth===0){end=i;break;}}
    }
    if(end<0){pos=start+1;continue;}
    try{
      const obj=JSON.parse(s.slice(start,end+1));
      if(obj&&typeof obj==='object'&&('suggestion' in obj||'insights' in obj||'confirmation' in obj))return obj;
      if(!fallbackObj)fallbackObj=obj;
    }catch{}
    pos=start+1;
  }
  if(fallbackObj)return fallbackObj;
  throw new SyntaxError('No valid JSON object found in model response');
}
function cards(text,sourceIds){
  const j=parseFirstJsonObject(text);
  const clean=x=>{if(!x||typeof x.text!=='string'||!x.text.trim())return null;const refs=(Array.isArray(x.sourceIds)?x.sourceIds:[]).filter(id=>sourceIds.has(id)).slice(0,6);if(!refs.length)return null;return {text:x.text.trim(),...(x.details?{details:x.details}:{}),sourceIds:refs,...(typeof x.title==='string'&&x.title.trim()&&[...x.title.trim()].length<=48?{title:x.title.trim()}: {})};};
  return {suggestion:clean(j.suggestion),insights:(Array.isArray(j.insights)?j.insights:[]).map(clean).filter(Boolean)};
}
// A source-backed judgment can replace its repeated lightweight explanation.
// Keep different useful points, even when they cite the same sentence.
function mergeJudgmentCards(next, signals, en=false, existing=[]) {
  const {repeated}=require('./grounded-card-dedupe');
  const fresh=new Set(signals);
  for(const item of [...signals,...existing.filter(x=>!fresh.has(x))].filter(x=>x.channel==='judgment'&&!x.stale&&!x.supersededBy)){
    const card={text:(en?'AI interpretation: ':'AI 解读：')+item.point.slice(0,1200),...(item.details?{details:item.details}:{}),sourceIds:item.sourceRefs.map(x=>x.segId)};
    const meaning={...card,text:item.point.slice(0,1200)};
    if(next.suggestion&&repeated(next.suggestion,meaning))next.suggestion=null;
    next.insights=next.insights.filter(x=>!repeated(x,meaning));
    if(fresh.has(item)&&next.insights.length<2)next.insights.push(card);
  }
  return next;
}
// Append-only presentation history lives on the same persisted Session.
function panelCards(session,current,{append=false,now=Date.now}={}) {
  const stamp = item => {
    if(!item?.text)return null;
    const sourceIds=(item.sourceIds||[]).slice(0,6);
    const row=(session?.transcript||[]).find(r=>sourceIds.includes(r.id||r.segId));
    const clock=meetingClock(row?.at??row?.atSec??row?.t,session?.start??session?.startTs);
    const speaker=row?.speaker||row?.spk||row?.who||'';
    return {...item,sourceIds,key:crypto.createHash('sha256').update((item.details||item.text)+'|'+sourceIds.join(',')).digest('hex').slice(0,16),sourceLabel:[clock,speaker].filter(Boolean).join(' · ')};
  };
  const suggestion=stamp(current?.suggestion),insights=(current?.insights||[]).map(stamp).filter(Boolean);
  const existing=(session?.nativeInsights?.history||[]).map(stamp).filter(Boolean);
  const candidates=append?[...[suggestion,...insights].filter(Boolean).map(x=>({...x,kind:x===suggestion?'suggestion':'insight',createdAt:now()}))]:[];
  // Browser capture already journals prior judgements/fact checks; reuse them.
  const journal=(session?.factchecks||[]).map(x=>stamp({text:x.point||x.claim||x.md||'',...(x.details?{details:x.details}:{}),sourceIds:(x.sourceRefs||[]).map(r=>typeof r==='string'?r:(r.segId||r.id)),superseded:!!x.supersededBy||!!x.stale,kind:x.channel==='judgment'?'judgment':'insight',createdAt:x.createdAt})).filter(Boolean);
  const history=new Map();for(const x of [...existing,...journal,...candidates]){const old=history.get(x.key);if(!old)history.set(x.key,x);else if(x.superseded)history.set(x.key,{...old,superseded:true});}
  const result={...current,...(current?.discussion?{discussion:stamp(current.discussion)}:{}),suggestion,insights,history:[...history.values()]};
  return result;
}
function escapeReg(value){return String(value||'').replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
// Strip a leading vocative so the stored task is the deliverable phrase. The quote itself stays the evidence.
function liveTaskPhrase(text, names){
  const original=String(text||'').trim().replace(/\s+/g,' ');
  const ordered=[...new Set((names||[]).map(n=>String(n||'').trim()).filter(Boolean))].sort((a,b)=>b.length-a.length);
  const name=ordered.length?`(?:${ordered.map(escapeReg).join('|')}|[A-Z][A-Za-z.'-]{1,25}(?:\\s+[A-Z][A-Za-z.'-]{1,25})?)`:`[A-Z][A-Za-z.'-]{1,25}(?:\\s+[A-Z][A-Za-z.'-]{1,25})?`;
  const request='(?:[Cc]ould\\s+you|[Cc]an\\s+you|[Ww]ould\\s+you|[Pp]lease)';
  const verb='(?:[Dd]raft|[Ww]rite|[Ss]end|[Pp]repare|[Cc]ompile|[Pp]ut\\s+together)';
  const strips=[
    new RegExp(`^(?:[Hh]ey|[Hh]i|[Hh]ello)\\s+@?${name}\\s*[,，:\\-]\\s*${request}\\s+`),
    new RegExp(`^@?${name}\\s*[,，:\\-]\\s*${request}\\s+`),
    new RegExp(`^@${name}\\s+${request}\\s+`),
    new RegExp(`^@?${name}\\s*[:\\-]\\s*(?:[Pp]lease\\s+)?${verb}\\s+`),
    new RegExp(`^(?:麻烦|拜托)\\s*${name}\\s*`),
    new RegExp(`^${name}\\s*[，,]\\s*(?:今天|明天|会后|稍后|现在)?[^，。]{0,20}?(?:帮我|麻烦你|请帮我|请你|能不能)`),
    new RegExp(`^${name}\\s*(?:请帮我|帮我|麻烦你)`),
    /^(?:[Cc]ould|[Cc]an|[Ww]ould)\s+you\s+/,
    /^(?:[Pp]lease\s+)?(?:[Aa]ssign(?:ed)?\s+to|[Hh]and(?:ed)?\s+over\s+to)\s+[A-Z][A-Za-z.'-]{1,25}\s+/
  ];
  let task=original;
  for(const re of strips){if(re.test(task)){task=task.replace(re,'').trim();break;}}
  task=task.replace(/[,，]\s*[A-Z][A-Za-z.'-]{1,25}\s*[?.!]?$/,'').replace(/[。！？?!]+$/,'').trim();
  return task.length>=5?task:original.replace(/[。！？?!]+$/,'').trim();
}
class InsightFeed {
  constructor({dataDir,session,ask,onChange=()=>{},onDeliverable=()=>{},onSignals=()=>{},detectionContext=()=>null,env=()=>session.env||{},gates=null,understanding=null,discussionSummary=false,now=Date.now,log=()=>{},expertAsk=null,expertStage=null,pageFetch=null,fetchBudgetMs=0,onPersonalAction=null,actForMe=null,shadow=null}){require('./meeting-scenario').ensure(session,{dataDir,now});this.expertStage=expertStage;this.expertAsk=expertAsk;this.pageFetch=pageFetch;this.fetchBudgetMs=fetchBudgetMs;this.shadow=shadow;this.reviewed=new Set();this.pendingInputs=[];this.expertStatus={state:'idle',count:0};const resolvedEnv=typeof env==='function'?env():(env||{});this.singleBrain=!!expertAsk&&String(resolvedEnv?.PROACTIVE_BRAIN||'v3').toLowerCase()!=='legacy';const expertMod=this.singleBrain?require('./proactive-brain'):require('./live-expert');this.expert=expertAsk?expertMod.create({session,ask:expertAsk,dataDir,env,log,now,contextVersion:()=>JSON.stringify([require('./live-expert').topicVersion(session),this.epoch]),active:()=>this.enabled&&!this.closed,onStatus:st=>{const next=st&&st.state==='checking'?{state:'checking',kind:st.kind||'external',count:Number(st.count)||1}:{state:'idle',count:0};if(this.expertStatus.state!==next.state||this.expertStatus.kind!==next.kind||this.expertStatus.count!==next.count){this.expertStatus=next;this.onChange();}},onCard:card=>this.expertCard(card),onPending:item=>{session.expertPending=[...(session.expertPending||[]),item].slice(-100);this.flushExpertPending();this.onChange();}}):null;this.gates=gates;this.understanding=understanding;if(understanding){understanding.active=()=>this.enabled&&!this.closed;understanding.onChange=()=>this.onChange();}Object.assign(this,{dataDir,session,ask,onChange,onDeliverable,onSignals,detectionContext,env,now,log,onPersonalAction,actForMe});this.revision=0;this.epoch=0;this.handled=0;this.lastCall=0;this.busy=false;this.enabled=true;this.closed=false;this.seen=new Set();this.personalSeen=new Set();this.image=null;this.issued=[];this.shown=0;this.judgedTranscriptCount=0;this.judgedEditEpoch=this.session?.editEpoch||0;this.cardState={suggestion:null,insights:[]};this.calls=0;this.phase='listening';this.discussion=discussionSummary?new (require('./live-discussion-summary').DiscussionSummary)({session,ask,dataDir,env,now,log,minGapMs:Math.max(15000,Number((typeof env==='function'?env():env)?.DISCUSSION_SUMMARY_GAP_MS)||30000),onChange:value=>{this.cardState={...this.cardState,discussion:value};this.understanding?.observe(value?.title);this.onChange();}}):null;if(this.discussion?.value)this.cardState.discussion=this.discussion.value;}
  retainFailure(){
    const prior=this.recovery;
    this.recoveryPendingIds=[...new Set([...(this.recoveryPendingIds||[]),...(this.gates?.pending?.()||[]).map(x=>x.id)])];
    this.recovery={id:prior?.id||crypto.randomUUID(),state:'failed',revision:this.revision,sourceIds:this.session.transcript.slice(-32).map(r=>r.id),at:prior?.at||this.now()};
    this.onChange();
  }
  retry(id){
    if(this.closed||!this.enabled||this.session.finalized)throw Error('insight_recovery_inactive');
    if(!this.recovery&&id===this.resolvedRecoveryId)return {accepted:true,resolved:true};
    if(!this.recovery||this.recovery.id!==id)throw Error('insight_recovery_changed');
    if(this.recovery.state==='retrying')return {accepted:true,recovery:this.recovery};
    if(this.busy)throw Error('insight_recovery_busy');
    this.recovery={...this.recovery,state:'retrying',revision:this.revision};
    this.recoveryPendingIds=(this.gates?.pending?.()||[]).map(x=>x.id);
    // Rebuild from current discussion and human draft, never replay cached output.
    this.pendingInputs=[];this.revision++;clearTimeout(this.timer);this.timer=null;
    this.onChange();void this.run();return {accepted:true,recovery:this.recovery};
  }
  resolveRecovery(){if(this.recovery){this.gates?.acknowledge?.(this.recoveryPendingIds||[]);this.resolvedRecoveryId=this.recovery.id;this.recovery=null;this.recoveryPendingIds=[];}}
  text(event){if(this.closed||!this.enabled)return false;const key=String(event.key||'');const text=String(event.text||'').trim().slice(0,4000);if(!key||key.length>120||!text||this.seen.has(key))return false;this.seen.add(key);if(this.seen.size>2000)this.seen.delete(this.seen.values().next().value);const count=this.session.transcript.length;this.session.onMacResult({type:'final',text});if(this.session.transcript.length===count)return false;this.changed(true);return true;}
  frame(encoded){if(this.closed||!this.enabled)return false;const b=Buffer.from(String(encoded||''),'base64');if(!b.length||b.length>160000)throw Error('frame_too_large');const size=jpegSize(b);if(size.width>960||size.height>960||size.width<32||size.height<32)throw Error('frame_dimensions');const hash=crypto.createHash('sha256').update(b).digest('hex');if(this.image?.hash===hash)return false;
    const dir=path.join(this.dataDir,'state','native-frames',this.session.id);fs.mkdirSync(dir,{recursive:true,mode:0o700});const file=path.join(dir,hash+'.jpg');fs.writeFileSync(file,b,{mode:0o600});this.image={hash,path:file,mime:'image/jpeg',capturedAt:new Date(this.now()).toISOString()};this.session.nativeCurrentFrame=this.image;this.changed();return true;}
  changed(transcript=false){
    this.revision++;
    if(transcript){this.discussion?.changed();this.understanding?.observe(this.discussion?.value?.title);}else this.discussion?.validate();
    if(transcript&&this.gates&&this.enabled&&!this.closed){
      const workState=this.captureWorkState();
      if(!require('./cloud-inference').trialOn(require('./meeting-work-state').environment(workState,this.env()))){
        const editEp=this.session.editEpoch||0;
        if(this.judgedEditEpoch!==editEp||workState.facts.transcript.length<this.judgedTranscriptCount){this.judgedTranscriptCount=0;this.judgedEditEpoch=editEp;}
        const rows=workState.facts.transcript.slice(this.judgedTranscriptCount);
        this.judgedTranscriptCount=workState.facts.transcript.length;
        if(rows.length){
          const context=workState.facts.inputs.decisionThread;
          // Non-cloud judges each final on newly added rows; cloud run() judges each consumed batch.
          const promise=Promise.resolve().then(()=>this.gates.input(rows,context,workState)).catch(()=>false);
          this.pendingInputs.push({revision:this.revision,promise,workState});
        }
      }
    }
    if(transcript&&this.shadow&&this.enabled&&!this.closed){
      try{void Promise.resolve(this.shadow.observe({speechEndedAt:this.now(),rows:this.session.transcript.slice(-24)})).catch(()=>{});}catch{}
    }
    this.schedule();
  }
  // 过期判定：转写被改（editEpoch）或被截短一律过期；只是追加了新话（或只换了画面帧）时不丢弃。
  // 模型返回时（limit=Infinity）：不论追加多少，交给发布门按「调用开始以来的全部新话 + 前 2 段」重新判断，下一轮照常看新话。
  // 发布门返回时（limit=STALE_TOLERANCE_ROWS）：门期间只追加了不超过 4 段才发布，否则丢弃。
  // 没有发布门、或用户点的「重试」时保持严格判定（revision 变了就丢弃）。
  // 10-27：持续长段发言时每轮都有新话，旧规则（模型期间超 4 段 / 发布门期间任何新话即丢）让整段判断一直出不来。
  stale(revision,rowCount,editEpoch,limit=Infinity){const n=this.session.transcript.length;if(editEpoch!==(this.session.editEpoch||0)||n<rowCount)return true;if(revision===this.revision)return false;return !this.gates||this.recovery?.state==='retrying'||n-rowCount>limit;}
  // 本场文档可能晚于第一条漏洞才建好，所以没写进去的留着，下次再试，散会前再试一次。
  // 研报的外部发现过一次编辑：先打开已有来源正文。弹与不弹都记理由，原发现不删。
  async researchFinding(f){
    if(!this.expertAsk||!this.enabled||this.closed||this.session.finalized||this.session.end||this.session.miniPaused||this.session.recordingAccessBlocked||this.reviewed.has(f.id))return false;this.reviewed.add(f.id);
    const version=()=>{const focus=this.discussion?.value||this.cardState?.discussion||this.session.nativeInsights?.discussion;return JSON.stringify([require('./live-expert').topicVersion(this.session),this.epoch,focus?.text||focus?.title||focus?.chapters?.at(-1)?.text||'',focus?.updatedAt??focus?.chapters?.at(-1)?.at??null]);};
    const originalRows=(this.session.transcript||[]).map(r=>({...r}));let editRows=null;
    const retained=rows=>{const current=this.session.transcript||[];return current.length>=rows.length&&rows.every((r,i)=>r.id===current[i]?.id&&r.text===current[i]?.text);};
    const startedVersion=version(),isCurrent=()=>this.enabled&&!this.closed&&!this.session.finalized&&!this.session.end&&!this.session.miniPaused&&!this.session.recordingAccessBlocked&&version()===startedVersion&&retained(originalRows)&&(!editRows||(retained(editRows)&&require('./live-intelligence-policy').tolerableAppend((this.session.transcript||[]).slice(editRows.length))));
    const read=this.pageFetch||require('./public-page-fetch').fetch,limits=Number(this.fetchBudgetMs)>0?{fetchBudgetMs:Number(this.fetchBudgetMs)}:{};
    const workState=this.captureWorkState();
    let d;try{d=await require('./live-research-editor').review({finding:f,session:this.session,dataDir:this.dataDir,budgetContext:{propositionId:f.card||null},env:require('./meeting-work-state').environment(workState,typeof this.env==='function'?this.env():this.env||{}),ask:(s,u,o)=>{if(!isCurrent())return '{"pop":false,"reason":"stale"}';editRows=(this.session.transcript||[]).map(r=>({...r}));return this.expertAsk(s+'\n'+require('./live-intelligence-policy')[this.session.uiLang==='en'?'en':'zh'],u,{...o,workState:require('./meeting-work-state').withTranscript(workState,editRows)});},cards:this.cardState?.insights||[],background:'',pageFetch:read,...limits});}catch(e){d={pop:false,reason:'编辑失败：'+e.message};}
    const stale=!isCurrent();const published=d.pop&&!stale&&this.expertCard({...d,sourceIds:[],isCurrent});
    this.session.expertDecisions=[...(this.session.expertDecisions||[]),{at:Date.now(),finding:f.id,text:String(f.text||'').slice(0,120),pop:!!published,reason:stale?'议题已过期：'+d.reason:d.pop&&!published?'发布被拒：'+d.reason:d.reason}].slice(-200);
    this.log('research card '+(published?'published':'held')+': '+d.reason);this.onChange(this.cardState);return !!published;
  }
  flushExpertPending(){if(!this.expertStage)return;for(const item of this.session.expertPending||[])if(!item.staged)try{if(this.expertStage(this.session,item))item.staged=true;}catch(e){this.log('expert stage '+e.message);}}
  // 11-02 Aaron：已核实的外部卡不再过 Jev 发布闸（当天 2 进 2 拒）；只留生命周期、去重、话题屏蔽和禁用词。被拒写日志。
  expertCard(c){
    const policy=require('./native-work-decision'),dedupe=require('./grounded-card-dedupe');
    const foot=[c.sources.map(s=>s.name).join('、'),c.credibility,c.caveat].filter(Boolean).join(' · ');
    const card={title:c.title,text:c.text+'\n'+foot,...(c.details?{details:c.details}:{}),...(c.cardKind?{cardKind:c.cardKind}:{}),...(c.semanticBadge?{semanticBadge:c.semanticBadge}:{}),caveat:c.caveat,foot,sourceIds:c.sourceIds,sources:c.sources,credibility:c.credibility,sourceLayer:c.sourceLayer||'external'};
    const refused=!(this.enabled&&!this.closed&&!this.session.finalized&&!this.session.end&&!this.session.miniPaused&&!this.session.recordingAccessBlocked&&c.isCurrent?.()===true)?'stale':policy.violatesCardPolicy(card)?'policy':require('./meeting-topics').blocked(this.session,card)?'topic':[...this.issued,...(this.session.nativeInsights?.history||[])].some(old=>dedupe.similar(cardMeaning(c),cardMeaning(old)))?'duplicate':'';
    if(refused){this.log('expert card refused '+refused+': '+c.title);return false;}
    this.issued.push({text:c.details||c.text,sourceIds:c.sourceIds});
    this.cardState={...this.cardState,insights:[...(this.cardState.insights||[]),card]};
    this.log('expert card '+c.latencyMs+'ms');this.flushExpertPending();this.onChange(this.cardState);return true;
  }
  schedule(){if(this.closed||!this.enabled||this.busy||this.timer||this.revision<=this.handled)return;const cfg=rules(this.dataDir);const wait=Math.max(120,this.lastCall+cfg.minGapMs-this.now());this.timer=setTimeout(()=>{this.timer=null;this.run();},wait);this.timer.unref?.();}
  captureWorkState(){
    const session=this.session,signals=require('./live-signals');
    return require('./meeting-work-state').create({dataDir:this.dataDir,env:this.env(),session,
      pack:this.detectionContext(session),rules:{native:rules(this.dataDir)},inputs:{
        meetingType:require('./meeting-document-layout').meetingType(session),topicControls:require('./meeting-topics').context(session),
        language:session.uiLang,decisionThread:signals.decisionThread(session),previousJudgments:signals.context(session),
        issuedCards:this.issued.slice(-8).map(c=>c.text.slice(0,160)),documentExcerpts:this.understanding?.excerpts?.()||null}});
  }
  // Mine-only local capture from the current transcript window. Never sends or calls a tool.
  captureLivePersonalActions(recent){
    const personalActions=require('./personal-actions');
    const env=typeof this.env==='function'?this.env():(this.env||{});
    let names=[];
    try{names=require('./context-pack').actionIdentity(this.dataDir,this.session,env)||[];}catch(e){this.log('personal action names '+(e&&e.message||e));}
    if(!names.length){try{names=personalActions.selfNames(this.session,env);}catch(e){this.log('personal action names '+(e&&e.message||e));}}
    if(!names.length||!Array.isArray(recent))return;
    let roleKeywords=[];
    try{roleKeywords=require('./context-pack').actionRoleKeywords?.(this.dataDir, this.session, env)||[];}catch(e){roleKeywords=[];}
    const transcript=Array.isArray(this.session.transcript)?this.session.transcript:[];
    for(const row of recent){
      if(!row||typeof row!=='object')continue;
      const sourceRef=String(row.segId||row.id||'');
      if(!sourceRef||this.personalSeen.has(sourceRef))continue;
      const original=transcript.find(item=>String(item&&(item.segId||item.id)||'')===sourceRef)||row;
      const evidence=String(original.text||row.text||'').trim().replace(/\s+/g,' ');
      if(!evidence)continue;
      const phrase=liveTaskPhrase(evidence,names);
      let candidate={id:'live-'+sourceRef,do:phrase,said:true,evidence,sourceRef,background:this.session.title||'In-meeting live capture'};
      let classification;
      try{classification=personalActions.classify(candidate,transcript,names,{roleKeywords});}catch(e){this.log('personal action classify '+(e&&e.message||e));continue;}
      if(classification.group!=='mine'&&phrase!==evidence){
        try{const fallback={...candidate,do:evidence};const again=personalActions.classify(fallback,transcript,names,{roleKeywords});if(again.group==='mine'){candidate=fallback;classification=again;}}catch(e){this.log('personal action classify '+(e&&e.message||e));}
      }
      this.personalSeen.add(sourceRef);
      if(!classification||classification.group!=='mine')continue;
      const existing=Array.isArray(this.session.myActions)?this.session.myActions:[];
      if(existing.some(item=>String(item&&item.sourceRef||'')===sourceRef))continue;
      const saved={...candidate,owner:classification.owner,attribution:classification.attribution||null,group:'mine'};
      this.session.myActions=existing.concat(saved);
      const notify=typeof this.onPersonalAction==='function'?this.onPersonalAction:(this.actForMe&&typeof this.actForMe.prepare==='function'?entry=>this.actForMe.prepare(entry):null);
      if(notify)Promise.resolve().then(()=>notify(saved)).catch(e=>this.log('personal action notify '+(e&&e.message||e)));
    }
  }
  async run(){if(this.closed||!this.enabled||this.busy||this.revision<=this.handled)return;this.busy=true;const epoch=this.epoch;try{const revision=this.revision,editEpoch=this.session.editEpoch||0,rowCount=this.session.transcript.length;this.handled=revision;this.lastCall=this.now();const latest=this.pendingInputs.filter(x=>x.revision===revision).at(-1);const workState=latest?.workState||this.captureWorkState();const snapshot=workState.facts,cfg=workState.rules.native;const roundAsk=(s,u,o)=>this.ask(s,u,{...o,workState});const image=this.image&&this.now()-Date.parse(this.image.capturedAt)<=120000?this.image:null;
    // Window = every sentence the model has not seen yet (since the last call that produced a result), with
    // at least recentSentences rows of context and the text budget as the only cap. A fixed "last six rows"
    // skipped most sentences whenever more than six arrived between calls (baseline-v3: 8–16 rows per minute).
    const all=snapshot.transcript,trial=require('./cloud-inference').trialOn(require('./meeting-work-state').environment(workState,this.env()));
    let shownAt=all.length,recent;
    if(trial){
      // Drain retained speech in complete consecutive batches. A successful
      // batch must not advance past utterances that were never sent.
      const pending=(this.shown||0)<all.length,from=pending?Math.min(this.shown||0,all.length):Math.max(0,all.length-cfg.recentSentences),rows=[];let chars=0;
      for(let i=from;i<all.length;i++){
        const x=all[i],row={id:x.id,t:x.t,at:x.at,speaker:x.speaker,text:String(x.text||'')};
        if(rows.length&&(chars+row.text.length>Math.min(cfg.maxTextChars,1600)||rows.length>=cfg.recentSentences))break;
        rows.push(row);chars+=row.text.length;
      }
      recent=rows;shownAt=pending?from+rows.length:all.length;
    }else{
      const from=Math.max(0,Math.min(this.shown||0,all.length-cfg.recentSentences));
      const rows=all.slice(from).map(x=>({id:x.id,t:x.t,at:x.at,speaker:x.speaker,text:String(x.text||'')}));let budget=cfg.maxTextChars;for(let i=rows.length-1;i>=0;i--){rows[i].text=budget>0?rows[i].text.slice(-budget):'';budget-=rows[i].text.length;}recent=rows.filter(x=>x.text);
    }
    try{this.captureLivePersonalActions(recent);}catch(e){this.log('personal action capture '+(e&&e.message||e));}
    const ids=new Set(recent.map(x=>x.id));if(image)ids.add('screen');
    this.phase='checking';this.onChange();
    const inputs=this.pendingInputs.filter(x=>x.revision<=revision);this.pendingInputs=this.pendingInputs.filter(x=>x.revision>revision);const hits=this.gates?await Promise.all(inputs.map(x=>x.promise)):[];const inputAccepted=!this.gates||(trial?await this.gates.input(recent,snapshot.inputs.decisionThread,workState):(latest&&hits.at(-1)===true)||((!latest||hits.some(Boolean))&&await this.gates.input(latest?inputs.filter((x,i)=>hits[i]).at(-1)?.workState.facts.transcript.slice(-3)||recent:recent,snapshot.inputs.decisionThread,workState)));if(this.closed||!this.enabled||epoch!==this.epoch)return;if(!inputAccepted){if(this.gates?.snapshot?.().lastError)this.retainFailure();else{if(trial){this.shown=shownAt;if(shownAt<all.length)this.handled=Math.min(this.handled,revision-1);}if(revision===this.revision&&epoch===this.epoch)this.resolveRecovery();}this.phase='listening';this.onChange();return;}if(this.closed||!this.enabled||epoch!==this.epoch)return;this.expert?.wake(recent);if(this.singleBrain){this.calls++;this.resolveRecovery();this.shown=shownAt;if(trial&&shownAt<all.length)this.handled=Math.min(this.handled,revision-1);this.phase='listening';this.onChange(this.cardState);return;}this.phase='thinking';this.calls++;this.onChange();const liveSignals=require('./live-signals'),context=snapshot.pack,selection=require('./live-draft-selection'),binding=selection.create(this.session.id,recent,context);const documentExcerpts=snapshot.inputs.documentExcerpts;const scenario=require('./meeting-scenario').forModel(this.session,{dataDir:this.dataDir,now:this.now});const payload={meetingType:snapshot.inputs.meetingType,scenario,topicControls:snapshot.inputs.topicControls,language:snapshot.inputs.language,evidenceScope:{recentSourceIds:recent.map(r=>r.id),meetingStartedAt:this.session.start||null},transcript:recent,cues:require('./live-coverage-policy').cues(recent),issuedCards:snapshot.inputs.issuedCards,screen:image?'当前共享画面':null,previousJudgments:snapshot.inputs.previousJudgments,decisionThread:snapshot.inputs.decisionThread,draftContext:binding.input,...(documentExcerpts?{documentExcerpts}:{})};const raw=await roundAsk(require('./native-live-prompt').build(require('./native-work-decision').cardPolicy(cfg.prompt)+(this.expert?'\n外部补充由另一路核实后发出，这里不出外部补充，只做内部推进。':'')+(this.expert&&this.discussion?'\n常规进度汇报、排期与复述已由「正在发生」脉络承接，纯同步段 suggestion 和 insights 保持留空，仅在出现未说破的内部矛盾或改变决策的新增条件时才发卡。':''),this.session.uiLang),JSON.stringify(payload),{sessionId:this.session.id,purpose:'native-live',...require('./context-pack').stamp(context),images:image?[image]:[],...(image?{imagesOptional:true,textOnlyUser:JSON.stringify({...payload,screen:null}),onImagesDropped:()=>{ids.delete('screen');this.log('native insight text only: no vision provider');}}:{}),tools:false,thinkGuide:false,json:true,timeoutMs:35000});
      if(this.closed||!this.enabled||epoch!==this.epoch)return;if(this.stale(revision,rowCount,editEpoch)){this.phase='listening';this.onChange();return;}if(typeof raw!=='string'||!raw.trim())throw Error('model_empty_response');let parsed=parseFirstJsonObject(raw);{const cardBody=require('./live-card-body');const droppedBefore=cardBody.stats().droppedOversizedFirstSentence;parsed=await cardBody.prepare(parsed);const droppedDelta=cardBody.stats().droppedOversizedFirstSentence-droppedBefore;if(droppedDelta>0)this.log('native card dropped oversized-first-sentence '+droppedDelta);}if(this.closed||!this.enabled||epoch!==this.epoch)return;if(this.stale(revision,rowCount,editEpoch)){this.phase='listening';this.onChange();return;}parsed=require('./native-work-decision').requireAction(parsed,cfg.requireAction);parsed=require('./live-coverage-policy').guard(parsed,{said:[...all.map(r=>r.text),...(documentExcerpts?.items||[]).map(x=>x.quote)].join('\n'),issued:this.issued});for(const d of parsed.dropped||[])this.log('native card dropped '+d.why+(d.numbers?' '+d.numbers.join(','):'')+' '+d.text);if(this.gates){const publicationRevision=this.revision,publicationRows=this.session.transcript.length;const publicationState=require('./meeting-work-state').withTranscript(workState,this.session.transcript);parsed=await this.gates.publication(parsed,{title:this.session.title||'',meetingFrame:snapshot.meetingFrame,scenario,transcript:publicationState.facts.transcript.slice(Math.max(0,Math.min(rowCount-2,publicationRows-6))),priorCards:this.cardState,decisionThread:snapshot.inputs.decisionThread,draftContext:binding.input},publicationState);if(this.closed||!this.enabled||epoch!==this.epoch||this.stale(publicationRevision,publicationRows,editEpoch,STALE_TOLERANCE_ROWS)){this.phase=this.enabled?'listening':'paused';this.onChange();return;}}if(this.gates?.snapshot?.().lastError){this.retainFailure();this.phase='listening';return;}this.resolveRecovery();parsed=require('./meeting-topics').filter(this.session,parsed);parsed=require('./native-work-decision').requireAction(parsed,true);const next=cards(JSON.stringify(parsed),ids);const decision=selection.assess(parsed,binding,selection.create(this.session.id,recent,this.detectionContext(this.session)));const {deliverable,...record}=decision;this.session.nativeDraftDecision={...record,at:new Date(this.now()).toISOString()};if(decision.state==='invalid')this.log('native draft protocol '+decision.code);if(deliverable)this.onDeliverable(this.session,deliverable,recent);require('./live-confirmations').offer(this.session,parsed.confirmation,recent);
      const signals=this.onSignals(this.session,parsed,recent)||[];
      mergeJudgmentCards(next,signals,this.session.uiLang==='en',this.session.factchecks||[]);
      // Another publication may have completed while this model or gate was awaiting.
      {const keep=c=>!require('./native-work-decision').violatesCardPolicy(c)&&!this.issued.some(old=>require('./grounded-card-dedupe').similar(cardMeaning(c),cardMeaning(old)));if(next.suggestion&&!keep(next.suggestion))next.suggestion=null;next.insights=next.insights.filter(keep);}
      for(const c of [next.suggestion,...next.insights].filter(Boolean))this.issued.push({text:c.details||c.text,sourceIds:c.sourceIds});if(this.issued.length>80)this.issued.splice(0,this.issued.length-80);this.shown=shownAt;if(trial&&shownAt<all.length)this.handled=Math.min(this.handled,revision-1);
      this.cardState={...next,...(this.discussion?.value?{discussion:this.discussion.value}:{})};this.phase='listening';this.ruleRevision=cfg.revision;this.onChange(this.cardState);}
    catch(e){if(!this.closed&&this.enabled&&epoch===this.epoch){this.retainFailure();this.recovery={...this.recovery,errorCode:e.errorCode||e.message,...Object.fromEntries(['inputChars','inputLimit'].filter(k=>Number.isSafeInteger(e[k])).map(k=>[k,e[k]]))};this.phase='model_unavailable';this.log('native insight '+e.message+(Number.isSafeInteger(e.inputChars)?' '+e.inputChars+'/'+e.inputLimit:''));this.onChange();}}
    finally{this.busy=false;if(this.recovery?.state==='retrying'){this.recovery={...this.recovery,state:'failed'};this.onChange();}this.pruneFrames();this.schedule();}
  }
  pruneFrames(){const dir=path.join(this.dataDir,'state','native-frames',this.session.id);try{for(const f of fs.readdirSync(dir))if(f!==path.basename(this.image?.path||'')&&/^[a-f0-9]{64}\.jpg$/.test(f))fs.unlinkSync(path.join(dir,f));}catch{}}
  pause(value){this.expert?.invalidate();if(value)this.expertStatus={state:'idle',count:0};this.discussion?.pause(value);this.pendingInputs=[];if(value){this.image=null;this.session.nativeCurrentFrame=null;}this.epoch++;this.enabled=!value;clearTimeout(this.timer);this.timer=null;this.handled=this.revision;this.phase=value?'paused':'listening';this.onChange();}
  close(){this.expert?.close();this.expertStatus={state:'idle',count:0};this.flushExpertPending();this.discussion?.close();this.understanding?.close();this.shadow?.close();this.pendingInputs=[];this.image=null;this.session.nativeCurrentFrame=null;this.epoch++;this.closed=true;this.enabled=false;clearTimeout(this.timer);this.timer=null;this.phase='ended';this.onChange();if(!this.busy)this.pruneFrames();}
}
function normalizeInputs(rows){return (Array.isArray(rows)?rows:[]).filter(d=>d&&typeof d.uid==='string'&&d.uid&&typeof d.name==='string').slice(0,100).map(d=>({uid:d.uid.slice(0,300),name:d.name.slice(0,200),isDefault:!!d.isDefault}));}
function create({expertAsk=null,expertStage=null,expertEnabled=()=>true,setTier=null,research=null,dataDir,startSession,activeSession,ask,port,accountFetchImpl,onDeliverable=()=>{},onSignals=()=>{},detectionContext=()=>null,log=()=>{},openMain=require('./desktop-open').openMain,openEnv={allowSystemWindows:true},ownerAlive,canLaunch=available,launch=execFile,watchMeetings=false,config=()=>({}),prepareStart=j=>j,prepareResume=j=>prepareStart(j),resumeWindowMs=600000,startTimeoutMs=120000,onCaptureReady=()=>{},onUnderstanding=()=>{},audioStallMs=10000,trialOptions={},runtime=require('./native-runtime').create({binary:BIN,port}),signal=(pid,sig)=>process.kill(pid,sig)}){
  const launchHelper=require('./native-app-launch').create({app:APP,execute:launch});
  const cloudAccount=require('./cloud-account');
  let launchAccessGrant=null;
  const currentSessionToken=()=>{const s=cloudAccount.loadSession(dataDir,config());return s&&typeof s.token==='string'&&s.token?s.token:'';};
  async function requireAccess({issueLaunchGrant=false,useLaunchGrant=false}={}) {
    if(useLaunchGrant){
      const token=currentSessionToken();
      if(launchAccessGrant&&Date.now()<launchAccessGrant.expiresAt&&token&&token===launchAccessGrant.token){launchAccessGrant=null;return token;}
      launchAccessGrant=null;
    }
    const access=await cloudAccount.requireProductAccess({dataDir,env:config(),fetchImpl:accountFetchImpl});
    if(!access.ok){launchAccessGrant=null;throw Object.assign(Error(access.code==='account_login_required'?'请先登录 Citeside 后再开始会议。':'请先兑换有效额度后再开始会议。'),{code:access.code,status:access.code==='account_login_required'?401:402});}
    const token=currentSessionToken();
    if(issueLaunchGrant)launchAccessGrant=token?{expiresAt:Date.now()+15000,token}:null;
    return token;
  }
  let updating=false;
  let current=null,command='',launching=false,launchCommand='',pendingJoinUrl='',pendingStart=null,pendingStartAt=0,launchGeneration=0,startupError='',startupErrorSessionId='',resumable=null,pendingAcked=false,voidedTrial=null;
  // Process-local receipts: an unknown ID after a restart must preserve local capture.
  const endedSessions=new Set();
  const trial=require('./native-trial').create({dataDir,log,...trialOptions});
  // F-01：试听的 pendingStart 被作废（stop / 超时）时记一笔。原小窗可能已经在授权弹窗里等着、稍后才发 /native/start；
  // 那次迟到的 start 没有 pendingStart 可认，不能顺手被 prepareStart 铸成一场正式会议。
  // 小窗走自动开始时会先发 /native/launch-ack（autoStart / join / command=start 三条路都这样），手动点「开始」不发：
  // acked = 作废前后收到过这个 helper 的 ack，迟到的 start 一定是它，直接拒；没 ack 的只在 startTimeoutMs 窗口内拒一次。
  // F-01 复审：每次 launch 铸一个 launchId，跟着 --launch-id / status.launchId 交给小窗，小窗在 launch-ack / start / cancel-start 原样带回。
  // 带 launchId 的 start 只能消费同一个 launchId 的 pendingStart；没有有效 pendingStart（取消、超时、已消费）就一律拒。慢 helper 的超时语义：intent 过 startTimeoutMs 即作废，旧 id 不再落到手动路径，要重开就重新 launch 拿新 id。
  // 不带 launchId 的（手动点「开始」）仍走下面 voidedTrial 的老判据。
  const launchIds=new WeakMap();
  const pendingLaunchId=()=>pendingStart?launchIds.get(pendingStart)||'':'';
  const launchIdOf=j=>typeof j?.launchId==='string'?j.launchId.slice(0,80):'';
  const staleLaunch=j=>{const id=launchIdOf(j);return !!id&&!!pendingStart&&id!==pendingLaunchId();};
  const voidPending=()=>{if(pendingStart?.trial)voidedTrial={at:Date.now(),acked:pendingAcked};pendingAcked=false;};
  const takeVoidedTrial=()=>{const v=voidedTrial;voidedTrial=null;return !!v&&(v.acked||Date.now()-v.at<startTimeoutMs);};
  // Start in the capsule after a failed start keeps the same page instead of minting native-<uuid>.
  // An End before capture was ready is the helper giving up on that start; after a deliberate End it starts fresh: back-to-back meetings must not be appended to the previous one.
  const remember=id=>{resumable=id?{id,at:Date.now()}:null;};
  const resumeIntent=j=>{if(j.sessionId||!resumable)return null;if(Date.now()-resumable.at>resumeWindowMs){resumable=null;return null;}return prepareResume({sessionId:resumable.id,lang:j.lang,uiLang:j.uiLang});};
  const launchWatcher=()=>launchHelper(['--server','http://[::1]:'+port,'--watch'],e=>{if(e)log('meeting watcher '+e.message);});
  // 安装后仍映射旧程序的闲置小窗由服务端静默换新：用户不需要知道小窗是独立进程；会议进行中不碰。
  let retiring=null,lastRetireDoneAt=0,lastRetireLivePids=[];
  function retireStale(relaunch=true){return retiring||(retiring=(async()=>{
    const stale=[],livePids=[];for(const h of await runtime.helpers()){if(await runtime.current(h.pid))livePids.push(h.pid);else stale.push(h.pid);}
    if(!stale.length){lastRetireLivePids=livePids;lastRetireDoneAt=Date.now();return;}
    if(status().active)throw Error('录音组件正在更新，请稍后再试');
    for(const pid of stale)try{signal(pid,'SIGTERM');}catch{}
    const alive=()=>stale.filter(pid=>{try{signal(pid,0);return true;}catch{return false;}});
    for(const end=Date.now()+3000;alive().length&&Date.now()<end;)await new Promise(r=>setTimeout(r,100));
    if(alive().length)throw Error('录音组件正在更新，请稍后再试');
    log('retired stale helpers '+stale.join(','));
    if(relaunch&&watchMeetings&&canLaunch())launchWatcher();
    lastRetireLivePids=livePids;lastRetireDoneAt=Date.now();
  })().finally(()=>{retiring=null;}));}
  if(watchMeetings&&canLaunch()){launchWatcher();retireStale().catch(e=>log('stale helper '+e.message));}
  const owners=require('./native-owner').create({active:token=>(current?.owner===token&&!current.session.finalized)||(!!pendingStart&&pendingOwner===token),...(typeof ownerAlive==='function'?{isAlive:ownerAlive}:{})});let pendingOwner='';
  // The capture singleton posts microphone lists only while it has no local session.
  let helperReportedIdleAt=0;
  const helperIdle=()=>Date.now()-helperReportedIdleAt<2000&&!(current&&!current.session.finalized);
  const isPidAlive=pid=>{if(!Number.isSafeInteger(pid)||pid<2)return false;try{signal(pid,0);return true;}catch(e){return e&&e.code==='EPERM';}};
  let lastUnownedHelperPollAt=0;const lastOwnerHelperPollAt=new Map();
  const isBrowserUA=req=>/Mozilla\//.test(String(req.headers['user-agent']||''));
  const noteHelperPoll=(reqOwner)=>{if(reqOwner&&owners.has(reqOwner))lastOwnerHelperPollAt.set(reqOwner,Date.now());else if(!reqOwner)lastUnownedHelperPollAt=Date.now();};
  const helperGone=pid=>{try{signal(pid,0);return false;}catch{return true;}};
  async function replaceIdleHelper(pids){
    if(!helperIdle())return false;
    for(const pid of pids){try{signal(pid,'SIGTERM');}catch{}}
    for(const end=Date.now()+1500;pids.some(pid=>!helperGone(pid))&&Date.now()<end;)await new Promise(r=>setTimeout(r,50));
    // AppKit cancels SIGTERM when the previous owner can no longer confirm quit.
    // This process already reported no local session, and the server has no recording.
    if(!(current&&!current.session.finalized))for(const pid of pids)if(!helperGone(pid)){try{signal(pid,'SIGKILL');}catch{}}
    for(const end=Date.now()+1000;pids.some(pid=>!helperGone(pid))&&Date.now()<end;)await new Promise(r=>setTimeout(r,50));
    return pids.every(helperGone);
  }
  let browserCommand='',browserCommandSession='',browserView='expanded',inputUID='',inputDevices=[],uiLanguage='';
  const panelPresence=require('./meeting-presence').create();
  let explicitPanel=null,panelSerial=0;
  const browserSession=()=>{const s=activeSession();return s&&!s.finalized&&!s.nativeCapture&&!(current&&current.session===s&&!s.finalized)?s:null;};
  const transcriptSeconds=value=>{const parts=String(value??'').split(':');const n=parts.length>1&&parts.length<=3&&parts.every(x=>/^\d+(?:\.\d+)?$/.test(x))?parts.reduce((seconds,x)=>seconds*60+Number(x),0):Number(value);return Number.isFinite(n)?Math.max(0,n):0;};
  const recentTranscript=s=>{const profile=require('./profile');let fixes=[];try{fixes=profile.read(dataDir).fixes;}catch{}return (s?.transcript||[]).slice(-120).map(r=>({t:transcriptSeconds(r.t),text:profile.display(r.text,fixes).slice(0,2000)}));};
  // Interim speech is presentation-only; never append it to durable transcript.
  const hiddenInterim=new WeakMap();
  const interimText=(s,paused=false)=>{
    if(!s||s.finalized)return '';
    const text=String(s.lastPartialText||'').trim();
    if(paused||s.miniPaused||s.recordingAccessBlocked){hiddenInterim.set(s,text);return '';}
    if(!text){hiddenInterim.delete(s);return '';}
    if(hiddenInterim.get(s)===text)return '';
    hiddenInterim.delete(s);
    if(text===String(s.transcript?.at(-1)?.text||'').trim())return '';
    const profile=require('./profile');let fixes=[];try{fixes=profile.read(dataDir).fixes;}catch{}
    return profile.display(text,fixes).slice(0,2000);
  };
  const speakerFields=session=>{
    if(!session||!session.meetSpeakerSeen)return {};
    const extra={};
    if(typeof session.meetAccessibilityTrusted==='boolean')extra.accessibilityTrusted=session.meetAccessibilityTrusted;
    if(Number.isFinite(session.meetSpeakerCount))extra.meetSpeakerCount=session.meetSpeakerCount;
    return extra;
  };
  const forwardNativeSpeakerSignals=(session,body,pcmBytes=0)=>{
    if(!session||typeof session.ingestNativeSpeakerSignals!=='function'||!body||typeof body!=='object')return;
    const hasEnergy=body.trackEnergy&&typeof body.trackEnergy==='object';
    const hasMeet=Array.isArray(body.meetSpeakers);
    const hasTrust=typeof body.accessibilityTrusted==='boolean';
    if(!hasEnergy&&!hasMeet&&!hasTrust)return;
    try{session.ingestNativeSpeakerSignals({capturedAtMs:Number(body.capturedAt)||Date.now(),pcmBytes:pcmBytes||0,trackEnergy:hasEnergy?body.trackEnergy:undefined,meetSpeakers:hasMeet?body.meetSpeakers:undefined,accessibilityTrusted:hasTrust?body.accessibilityTrusted:undefined});}
    catch(e){log('native speaker signals '+(e&&e.message||e));}
  };
  const status=()=>{
    if(pendingStart&&Date.now()-pendingStartAt>startTimeoutMs){voidPending();startupErrorSessionId=pendingStart.sessionId;remember(pendingStart.sessionId);pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';launchGeneration++;launching=false;startupError='录音启动超时，请重试';}
    const s=browserSession();
    if(s)return {available:canLaunch(),active:true,captureMode:'browser',asrStatus:s.asrStatus||null,recentTranscript:recentTranscript(s),interimText:interimText(s),gate:s.jev?.snapshot?.()||null,startedAt:s.startTs||Date.parse(s.start)||null,sessionId:s.id,title:s.title||'',scenario:require('./meeting-scenario').forClient(s,{dataDir}),phase:s.miniPaused?'paused':'listening',target:null,confirmation:require('./live-confirmations').visible(s),cards:panelCards(s,s.nativeInsights||{suggestion:null,insights:(s.factchecks||[]).filter(x=>!x.stale&&!x.supersededBy&&(!x.channel||x.channel==='judgment')).slice(-2).map(x=>({text:(x.channel==='judgment'?'AI 解读：':'')+(x.point||x.claim||x.md||''),sourceIds:(x.sourceRefs||[]).map(r=>r.segId||r)}))}),command:browserCommandSession===s.id?browserCommand:'',audioSeconds:Math.max(0,(Date.now()-(s.startTs||Date.now()))/1000),audioLevel:Date.now()-(s.audioLevelAt||0)<1200&&!s.miniPaused?s.audioLevel||0:0,error:'',view:browserView,...speakerFields(s)};
    const live=current&&!current.session.finalized?current:null;
    // Live heartbeats with a frozen helper clock mean capture stopped without an error; never show that as recording.
    // A helper-reported error is the more specific cause, so it suppresses this generic state.
    const stalled=!!live&&!!live.captureReady&&live.feed.phase!=='paused'&&!live.session.miniPaused&&command!=='pause'&&Date.now()-(live.lastHeartbeat||0)<20000&&Date.now()-(live.audioAdvancedAt||0)>audioStallMs&&!live.error;
    return {starting:!!pendingStart,pendingSessionId:pendingStart?.sessionId||'',launchId:pendingLaunchId(),captureReady:!!live&&!live.session.finalized&&!!live.captureReady,available:canLaunch(),active:!!live&&!live.session.finalized,captureMode:'native',captureEnding:!!live?.captureEnding,asrStatus:live?.session.asrStatus||null,recentTranscript:live&&!live.session.finalized?recentTranscript(live.session):[],interimText:interimText(live?.session,live?.feed.phase==='paused'||command==='pause'||!!live?.captureEnding),startedAt:live?.session.startTs||Date.parse(live?.session.start)||null,sessionId:live&&!live.session.finalized?live.session.id:'',title:live?.session.title||'',scenario:live&&!live.session.finalized?require('./meeting-scenario').forClient(live.session,{dataDir}):null,phase:live?.feed.phase||'idle',expertStatus:live?.feed?.expertStatus||{state:'idle',count:0},proactiveFunnel:live?.feed?.expert?.funnel?.()||null,target:live?.target||null,confirmation:require('./live-confirmations').visible(live?.session),cards:panelCards(live?.session,live?.feed.cardState||{suggestion:null,insights:[]}),calls:live?.feed.calls||0,gate:live?.feed.gates?.snapshot()||null,insightRecovery:live?.feed.recovery||null,command:live&&!live.session.finalized?command:launchCommand,meetingUrl:pendingJoinUrl,audioSeconds:live?.audioSeconds||0,audioLevel:Date.now()-(live?.audioLevelAt||0)<1200?live?.audioLevel||0:0,frames:live?.frames||0,inputUID:live?.inputUID||'',inputName:live?.inputName||'',inputDevices,audioSource:'system-microphone',audioEvidence:live?.audioEvidence||null,requestedInputUID:inputUID,microphoneChange:live?.microphoneChange||null,microphoneReceipt:live?.microphoneReceipt||null,captureRecovery:live?.captureRecovery||'ready',captureRetry:live?.captureRetry||null,stalled,captureHealth:stalled?'callback-stalled':'',error:live&&!live.session.finalized?live.error||(stalled?'没有收到录音数据，请检查麦克风与系统声音权限后结束重开；已录内容保留':''):startupError,errorSessionId:live&&!live.session.finalized?live.session.id:startupErrorSessionId,view:live?.view||'expanded',...speakerFields(live?.session)};
  };
  const notify=()=>{if(current){current.session.nativeInsights={...panelCards(current.session,current.feed.cardState,{append:true}),expertPending:current.session.expertPending||[],expertDecisions:current.session.expertDecisions||[],phase:current.feed.phase,expertStatus:current.feed.expertStatus||{state:'idle',count:0},proactiveFunnel:current.feed.expert?.funnel?.()||null,ruleRevision:current.feed.ruleRevision||'',calls:current.feed.calls,gate:current.feed.gates?.snapshot()||null,understanding:current.feed.understanding?.snapshot()||null};try{onUnderstanding(current.session);}catch(e){log('meeting materials skipped '+e.message);}current.session.checkpoint();current.session.broadcast({type:'native-status',...status()});}};
  const audioConfig=(e=config())=>{const provider=e.ASR_PROVIDER||'volc';if(require('./cloud-inference').trialOn(e))return {transport:'pcm',provider:'volc'};return provider==='deepgram'&&e.DEEPGRAM_API_KEY?{transport:'pcm',provider:'deepgram'}:provider!=='mac'&&e.VOLC_APP_KEY&&e.VOLC_ACCESS_KEY?{transport:'pcm',provider:'volc'}:{transport:'text',provider:'mac'};};
  async function start(j,owner=''){const verifiedToken=await requireAccess({useLaunchGrant:true});if(updating)throw Error('正在更新，请完成后再开始会议');if(!lastRetireDoneAt||Date.now()-lastRetireDoneAt>15000)await retireStale();lastRetireDoneAt=0;if(updating)throw Error('正在更新，请完成后再开始会议');if(pendingStart&&Date.now()-pendingStartAt>startTimeoutMs)status();   // 过期的 pendingStart 先按超时作废，不让迟到的 start 拿它开场
    if(owner&&!owners.has(owner))throw Error('native_owner_unknown');if(pendingStart&&pendingOwner!==owner)throw Error('native_start_owner_changed');if(owner&&owners.status(owner).quitRequested)throw Error('native_owner_quitting');if(owner&&browserSession())throw Error('browser_capture_owns_this_meeting');// F-02：上一场试听收尾失败还挂着，先重试收尾；finalize 本身还没过就不让新会议进来（资源可能还占着）。
    if(current?.session.trial&&current.session.trialCleanup&&!current.session.trialDiscarded){try{await trial.discard(current);}catch(e){if(!current.session.finalized)throw Error('trial_cleanup_pending: '+e.message);log('试听残留文件未删净，启动清扫和孤儿恢复会兜住 '+e.message);}}
    if(current&&!current.session.finalized)throw Error('native_capture_already_active');const other=activeSession();if(pendingStart?.trial&&other)throw Error('trial_meeting_active');
    // F-01：作废的试听迟到回连，每次都拒且零新场次；无身份的手动开始正式会议照常。
    const launchId=launchIdOf(j);
    if(launchId&&(!pendingStart||launchId!==pendingLaunchId())){if(!pendingStart)voidedTrial=null;throw Error('native_start_superseded');}   // 带 launchId 只认当前有效 intent；没有有效 intent（取消、超时、已消费）一律拒，不靠作废名单；认出迟到窗口后不再挡无身份的手动开始
    if(!launchId&&!pendingStart&&!other&&voidedTrial&&takeVoidedTrial())throw Error('native_start_superseded');
    const target=j.target||{bundleId:'',title:'',windowId:0};
    if(!target||typeof target.bundleId!=='string'||typeof target.title!=='string'||!Number.isInteger(target.windowId))throw Error('meeting_window_required');
    const intent=pendingStart||(!other&&resumeIntent(j))||prepareStart(j);
    const session=other||startSession({...intent,nativeCapture:true,source:'mac-native',title:intent.title||target.title.slice(0,200),lang:intent.lang||j.lang||'zh',uiLang:intent.uiLang||j.uiLang||'zh',...(typeof accountFetchImpl==='function'?{accountFetchImpl}:{})});pendingStart=null;pendingOwner='';resumable=null;session.restoreRecordingAccess?.();const isTrial=!!intent.trial&&!other;
    if(isTrial)trial.attach(session,()=>requestTrialStop(session));
    if(other){other.enableNativeCapture();other.broadcast({type:'native-handoff',sessionId:other.id});}
    if(typeof accountFetchImpl==='function'){try{Object.defineProperty(session,'_accountFetchImpl',{value:accountFetchImpl,writable:true,configurable:true,enumerable:false});}catch{}}
    session.grantAsrAccess?.(verifiedToken,30000);
    const shadowEnv=()=>session.env||config();
    const shadow=!isTrial&&require('./proactive-shadow').isEnabled(shadowEnv)?require('./proactive-shadow').create({dataDir,session,ask,env:shadowEnv,log,getScenario:()=>require('./meeting-scenario').forModel(session,{dataDir}),gates:require('./proactive-gate-router').create({env:shadowEnv,dataDir,sessionId:session.id,log})}):null;
    const feed=new InsightFeed({dataDir,session,ask,env:config,...(!isTrial&&expertAsk&&expertEnabled()?{expertAsk,expertStage}:{}),discussionSummary:true,onChange:notify,onDeliverable:isTrial?()=>{}:onDeliverable,onSignals:isTrial?()=>{}:onSignals,detectionContext:isTrial?()=>null:detectionContext,log,shadow,understanding:isTrial?null:require('./meeting-frame').create({session,ask,env:config,dataDir,log}),gates:require('./native-insight-gates').create({env:()=>session.env||config(),dataDir,sessionId:session.id,log})});current={session,feed,owner,launchId:other?'':launchId,target:{bundleId:target.bundleId.slice(0,120),title:target.title.slice(0,200),windowId:target.windowId},lastHeartbeat:Date.now(),audioSeconds:0,frames:0,audioIngress:require('./native-audio').createIngress()};const asr=audioConfig(session.env||config());session.onNativeTranscript=()=>{if(asr.transport==='pcm')feed.changed(true);};if(asr.transport==='pcm')session.enableNativeAudio(asr.provider);current.asr=asr;endedSessions.delete(session.id);startupError='';command='';launchCommand='';const pendingAudio=session.pendingAudioPolicy===true;notify();return {...status(),inputUID,pendingAudio,audioPath:pendingAudio?'':(session.audioPath||''),asr:current.asr};
  }
  // ONB-02：stop 只是「请小窗结束」；state 要等 end + 清理真正完成才报 done，失败报 failed 并可再 stop 重试。
  function requestTrialStop(session){
    if(session.trialStopRequested||session.trialStopConfirmed)return;
    session.trialEndError='';session.trialStopRequested=Date.now();command='stop';
    trial.graceStop(session,()=>{if(current?.session===session)notify();});
  }
  function trialState(){
    const s=current?.session,snap=trial.snapshot({live:current&&!current.session.finalized?current:null,pending:pendingStart,startupError,startupErrorSessionId});
    if(s?.trial&&!s.trialDiscarded){
      const failed=!!s.trialEndError&&!s.trialDiscarding,stopping=!failed&&(!!s.trialStopRequested||s.finalized||!!s.trialDiscarding||!!s.trialCleanup);
      if(failed||stopping)return {...snap,done:false,state:failed?'failed':'stopping',error:failed?snap.error||'试听收尾失败，请重试':snap.error||''};
      return {...snap,done:false,state:'live'};
    }
    if(pendingStart?.trial)return {...snap,done:false,state:'starting'};
    return {...snap,state:snap.done?'done':'live'};
  }
  async function end(options={}){launchAccessGrant=null;if(!current)return status();void current.session.reportRecordingActivity?.(false);endedSessions.add(current.session.id);command='';if(current.session.trial){
      const s=current.session;s.trialStopConfirmed=true;clearTimeout(s.trialStopTimer);
      if(s.trialDiscarded)return status();
      try{if(!current.feed.closed)current.feed.close();await trial.discard(current);return status();}
      catch(e){s.trialEndError=s.trialEndError||String(e?.message||e||'trial_end_failed');throw e;}
    }if(!current.captureReady)remember(current.session.id);noteUnconfirmedLiveTail(current.session,options.liveTail);current.feed.close();await current.session.finalize('原生会议已结束');notify();return status();}
  const lease=setInterval(()=>{if(current&&!current.session.finalized&&Date.now()-current.lastHeartbeat>20000){if(current.error!=='小窗连接中断，本机录音可继续，正在等待重连'){current.error='小窗连接中断，本机录音可继续，正在等待重连';notify();}}},5000);lease.unref();
  async function requestLaunch(j,owner='',launchPath='/native/launch',bound=false,preset=null){
    await requireAccess({issueLaunchGrant:true});
    const send=(code,body)=>({code,body});
    if(owner&&!owners.has(owner))throw Error('native_owner_unknown');
        if(!canLaunch())return send(503,{error:'原生小窗尚未安装'});
        if(updating)throw Error('正在更新，请完成后再开始会议');
        await retireStale();
        if(bound){const s=status();if(s.active&&s.sessionId!==j.sessionId||s.starting&&s.pendingSessionId!==j.sessionId)throw Error('trigger_other_meeting_active');}
        if(owner&&owners.status(owner).quitRequested)throw Error('native_owner_quitting');
        if(owner&&current&&!current.session.finalized&&current.owner!==owner)throw Error('native_capture_owned_by_another_window');
        if(owner&&browserSession())throw Error('browser_capture_owns_this_meeting');
        if(pendingStart&&pendingOwner!==owner)throw Error('native_start_owner_changed');
        if(pendingStart&&Date.now()-pendingStartAt>startTimeoutMs){voidPending();pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';launchGeneration++;}
        const joinUrl=launchPath==='/native/join'?meetingLink(j.url):'';
        if(joinUrl&&status().active){
          if(!j.sessionId||j.sessionId!==current?.session.id)return send(409,{error:'已有会议正在录制，请先结束这场再加入另一场'});
          const failure=await new Promise(resolve=>launch('/usr/bin/open',[joinUrl],{timeout:6000},resolve));
          return failure?send(503,{error:'会议链接未能打开，请重试；现有录音仍在继续'}):send(200,{ok:true,...status()});
        }
        const queued=!!launchCommand;
        const intent=(j.autoStart||launchPath==='/native/join')&&!status().active?(preset||prepareStart(j)):null;
        if(intent&&pendingStart&&pendingStart.sessionId!==intent.sessionId)throw Error('另一场会议正在接入，请先取消或完成');
        if(launchPath==='/native/join'){
          const url=joinUrl;
          if(pendingJoinUrl&&pendingJoinUrl!==url)return send(409,{error:'正在打开另一场会议，请先在小窗处理'});
          pendingJoinUrl=url;launchCommand='start';
        }
        if(intent){startupError='';startupErrorSessionId='';resumable=null;if(!launchIds.has(intent))launchIds.set(intent,(pendingStart&&pendingStart.sessionId===intent.sessionId&&pendingLaunchId())||crypto.randomUUID());pendingStart=intent;pendingOwner=owner;pendingStartAt=Date.now();pendingAcked=false;voidedTrial=null;}
        if((j.autoStart||joinUrl)&&!status().active)launchCommand='start';
        if(joinUrl&&!queued){
          const failure=await new Promise(resolve=>launch('/usr/bin/open',[joinUrl],{timeout:6000},resolve));
          if(failure){launchCommand='';pendingJoinUrl='';pendingStart=null;pendingOwner='';return send(503,{error:'会议链接未能打开，请重试'});}
        }
        const helperArgs=()=>['--server','http://[::1]:'+port,...((j.autoStart||joinUrl)&&!status().active?['--start']:[]),...(owner?['--owner',owner]:[]),...(pendingLaunchId()?['--launch-id',pendingLaunchId()]:[]),'--locale',j.lang==='en'?'en-US':'zh-CN','--ui-lang',j.uiLang==='en'?'en':'zh'];
        if(!launching&&!queued){
          let skipOpen=false;
          if(!joinUrl){
            if(owner){
              const ownPid=owners.status(owner).helperPid||0,pollAt=lastOwnerHelperPollAt.get(owner)||0;
              // Idle is required: a helper-ready registration alone is not a live poll that can take command:start.
              skipOpen=ownPid>1&&isPidAlive(ownPid)&&(Date.now()-pollAt<2000)&&helperIdle();
            }else skipOpen=(Date.now()-lastUnownedHelperPollAt<2000)&&lastRetireLivePids.some(isPidAlive);
          }
          if(!skipOpen){
            launching=true;const generation=++launchGeneration,launchedIntent=pendingStart;
            const failure=await new Promise(resolve=>launchHelper(helperArgs(),resolve));
            if(generation===launchGeneration)launching=false;
            if(failure){if(pendingStart===launchedIntent){launchCommand='';pendingJoinUrl='';pendingStart=null;pendingOwner='';}log('native launch '+failure.message);return send(503,{error:'录音小窗未能启动，请重试'});}
          }
        }
        if(owner){
          // open(1) succeeding proves launch dispatch only, not that the existing
          // singleton watcher accepted the owner. A helper already bound to a
          // previous main window ignores the handoff and keeps helperPid at 0.
          const started=Date.now();let deadline=started+4000,replaced=false;
          while(!owners.status(owner).helperPid&&Date.now()<deadline){
            if(!replaced&&Date.now()-started>=400&&helperIdle()){
              let helpers=[];try{helpers=await runtime.helpers();}catch(e){log('helper list '+e.message);}
              const pids=helpers.map(h=>h&&h.pid).filter(pid=>pid&&pid!==owners.status(owner).helperPid);
              if(pids.length){
                replaced=true;
                if(await replaceIdleHelper(pids)&&!owners.status(owner).helperPid){
                  log('idle capture helper replaced '+pids.join(','));
                  launching=true;const generation=++launchGeneration,launchedIntent=pendingStart;
                  const failure=await new Promise(resolve=>launchHelper(helperArgs(),resolve));
                  if(generation===launchGeneration)launching=false;
                  if(failure){if(pendingStart===launchedIntent){launchCommand='';pendingJoinUrl='';pendingStart=null;pendingOwner='';}log('native launch '+failure.message);return send(503,{error:'录音小窗未能启动，请重试'});}
                  deadline=Date.now()+3000;
                }
              }
            }
            if(!owners.status(owner).helperPid)await new Promise(r=>setTimeout(r,50));
          }
          if(!owners.status(owner).helperPid){
            if(pendingOwner===owner){pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';}
            return send(503,{error:'录音没有接上，请再点一次开始'});
          }
        }
        return send(200,{ok:true,...status()});
  }
  const trigger=require('./meeting-trigger').create({dataDir,port,status,ownerValid:owner=>{if(!owners.has(owner))return false;const o=owners.status(owner);if(o.quitRequested||!o.mainPid)return false;try{process.kill(o.mainPid,0);return true;}catch(e){return e.code!=='ESRCH';}},prepare:prepareStart,launch:(j,owner)=>requestLaunch(j,owner,'/native/launch',true),canControl:(id,owner)=>!current||current.session.finalized||current.session.id===id&&current.owner===owner,finalized:id=>!!current&&current.session.id===id&&!!current.session.finalized,stop:sessionId=>{if(!current||current.session.finalized||current.session.id!==sessionId)return false;command='stop';return true;}});
  async function route(req,res,u,local){const p=u.pathname.replace(/^\/asr-relay/,'');if(!p.startsWith('/native/')||p==='/native/postmeeting')return false; // 会后整理按会议 id 读写，不归正在进行的会管；由 postmeeting-route 处理
    const send=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(j));return true;};if(!local)return send(403,{error:'native_local_only'});
    if(req.headers.origin&&req.headers.origin!==`http://127.0.0.1:${port}`&&req.headers.origin!==`http://localhost:${port}`&&req.headers.origin!==`http://[::1]:${port}`)return send(403,{error:'native_origin_rejected'});
    const owner=String(req.headers['x-tht-native-owner']||'');
    const ownedStatus=()=>{
      const result=status(),own=owner&&owners.has(owner)?owners.status(owner):null;
      if(result.command==='quit'||(!result.active&&pendingOwner!==owner))result.command='';
      if(own){
        if(own.quitRequested)result.command='quit';
        if(!current?.owner||current.owner===owner)result.panelPolicy=owners.panelPolicy(owner,result.sessionId,result.active);
      }
      // A watcher can start recording before a main window owns it. Only an
      // explicit, still-current handoff offers ownership of that same session.
      if(!owner&&current&&!current.session.finalized&&explicitPanel?.owner&&
        (!current.owner||current.owner===explicitPanel.owner&&current.ownerHandoffSerial===explicitPanel.serial)&&
        explicitPanel.sessionId===current.session.id&&owners.has(explicitPanel.owner)&&
        owners.mainAlive(explicitPanel.owner)&&!owners.status(explicitPanel.owner).quitRequested)
        result.ownerHandoff={owner:explicitPanel.owner,sessionId:current.session.id,serial:explicitPanel.serial};
      // The menu bar follows the main window's interface language, also mid-meeting.
      if(uiLanguage)result.uiLang=uiLanguage;
      if(updating){result.command='update-quit';return result;}
      const presence=panelPresence.visible(result.sessionId);
      if(presence!==null){
        const dismissed=panelPresence.dismissed(result.sessionId)||own?.dismissedSessionId===result.sessionId;
        result.panelPolicy={managed:true,sessionId:result.sessionId,show:!!result.active&&!presence&&own?.mainForeground!==true&&!dismissed&&result.command!=='quit'};
      }else if(!result.active&&panelPresence.known())result.panelPolicy={managed:true,sessionId:'',show:false};
      if(explicitPanel&&explicitPanel.sessionId!==result.sessionId)explicitPanel=null;
      const mainShown=panelPresence.mainVisible(explicitPanel?explicitPanel.at:-Infinity);
      if(mainShown)result.panelPolicy={managed:true,sessionId:result.panelPolicy?.sessionId||'',show:false,mainForeground:true};
      if(explicitPanel&&explicitPanel.owner===owner&&result.active&&result.command!=='quit'&&!own?.quitRequested&&own?.mainForeground!==true&&!mainShown)result.panelPolicy={managed:true,sessionId:result.sessionId,show:true,view:explicitPanel.view,serial:explicitPanel.serial};
      if(result.panelPolicy&&own?.mainPid){result.panelPolicy.mainPid=own.mainPid;if(typeof own.mainForeground==='boolean'&&!mainShown)result.panelPolicy.mainForeground=own.mainForeground;}
      if(own?.mainRestorePending)result.panelPolicy={...(result.panelPolicy||{}),managed:true,show:false,mainForeground:true,mainPid:own.mainPid,mainRestorePending:true};
      if(own&&result.panelPolicy){result.panelPolicy.mainRestoreSerial=own.mainRestoreSerial;result.panelPolicy.mainRestoreEpoch=own.mainRestoreEpoch;}
      // The installed helper returns before reading panel policy when command is stop.
      // Hold that command until the mini has reported hidden, then deliver it.
      if(own?.mainRestorePending&&result.command==='stop'&&own.mainRestoreAckPid!==own.helperPid)result.command='';
      // Lite sidecar owns the meeting surface. Keep the legacy 360px capture panel hidden unless this owner explicitly opened it.
      if(config().UI_MODE==='lite'&&!explicitPanel){
        if(result.panelPolicy)result.panelPolicy.show=false;
        else result.panelPolicy={managed:true,sessionId:result.sessionId||'',show:false};
      }
      return result;
    };
    if(req.method==='GET'&&p==='/native/owner-status'){try{return send(200,{ok:true,...owners.status(owner)});}catch(e){return send(409,{error:String(e?.message||e||'native_request_failed')});}}
    if(req.method==='GET'&&p==='/native/trigger-status'){try{return send(200,trigger.inspect(owner));}catch(e){return send(409,{error:String(e?.message||e||'native_request_failed')});}}
    if(req.method==='GET'&&p==='/native/status'){if(owner&&!owners.has(owner))return send(409,{error:'native_owner_unknown'});if(!isBrowserUA(req))noteHelperPoll(owner);return send(200,ownedStatus());}
    if(req.method==='GET'&&p==='/native/audio-config')return send(200,{...audioConfig(),inputUID});
    if(req.method==='GET'&&p==='/native/rules')return send(200,rules(dataDir));
    if(req.method==='GET'&&p==='/native/meeting-frame')return send(200,{understanding:current?.feed.understanding?.snapshot()||null});
    if(p==='/native/tier'&&req.method!=='POST')return send(405,{error:'method'});
    let j={};if(req.method==='POST'||req.method==='PUT'){try{const chunks=[];let n=0;for await(const c of req){n+=c.length;if(n>240000)throw Error('payload_too_large');chunks.push(c);}j=JSON.parse(Buffer.concat(chunks).toString()||'{}');}catch(e){return send(400,{error:e.message});}}
    try{
      // 首次引导试听：同一条采集管线，场次标 trial，结束即删，不进会议库（app/native-trial.js）
      if(req.method==='GET'&&p==='/native/trial/state')return send(200,trialState());
      if(req.method==='POST'&&p==='/native/trial/start'){
        if(!canLaunch())return send(503,{error:'原生小窗尚未安装'});
        if(status().active||pendingStart||activeSession())return send(409,{error:'已有会议正在录制，结束后再试听'});
        const intent=trial.intent(j,uiLanguage);const result=await requestLaunch({autoStart:true,lang:intent.lang,uiLang:intent.uiLang},'','/native/launch',false,intent);
        return send(result.code,result.code===200?{ok:true,...trial.snapshot({live:null,pending:pendingStart})}:result.body);
      }
      if(req.method==='POST'&&p==='/native/trial/stop'){
        const s=current?.session;
        if(s?.trial&&!s.trialDiscarded&&s.trialStopConfirmed&&(s.trialEndError||s.finalized)&&!s.trialDiscarding){   // 上次收尾失败（或小窗失联后的强制收尾失败）：现在重试，失败报 409 + 当前状态（F-02）
          try{await end();}catch(e){return send(409,{error:String(e?.message||e||'trial_end_failed').slice(0,200),...trialState()});}
        }
        else if(s?.trial&&!s.finalized)requestTrialStop(s);
        else if(pendingStart?.trial){voidPending();startupErrorSessionId='';pendingStart=null;pendingOwner='';launchCommand='';launching=false;launchGeneration++;}
        return send(200,{ok:true,...trialState()});
      }
      // 分档手动改：处理函数由 server.js 注入（它手上有会中场次和归档管线）
      if(req.method==='POST'&&p==='/native/tier'){if(!setTier)return send(404,{error:'tier_unavailable'});const r=setTier(j);return send(r.code,r.body);}
      // 原生卡已全文显示；旧 Swift 的 expand 只是点击，忽略且不写账本。
      // JS 入口支持真实显示/复制/关闭/采纳；当前 Swift 尚未上报这些事件。
      if(req.method==='POST'&&p==='/native/card-signal'){if(['expand','click'].includes(j.action))return send(200,{ok:true,ignored:true,reason:'native_card_already_full_text'});const rec=['shown','copy','dismiss','adopt'].includes(j.action)?require('./card-signals').append(dataDir,{...j,source:'native'}):null;return send(rec?200:400,rec?{ok:true}:{error:'invalid_card_signal'});}
      // 小窗卡片「深度研究」（MINI-01）：开始一张卡片的研究 / 查回执；处理函数由 server.js 注入（research-report.cardRoute）
      if(req.method==='POST'&&(p==='/native/research'||p==='/native/research-status')){if(!research)return send(404,{error:'research_unavailable'});const r=research({...j,status:p==='/native/research-status'});return send(r.code,r.body);}
      if(req.method==='POST'&&p==='/native/trigger-bind')return send(200,trigger.bind(j,owner));
      if(req.method==='POST'&&p==='/native/trigger-revoke')return send(200,trigger.revoke(owner));
      if(req.method==='POST'&&p==='/native/trigger-command')return send(200,await trigger.command(j,String(req.headers['x-tht-trigger-capability']||'')));
      if(req.method==='POST'&&p==='/native/owner-register')return send(200,{ok:true,...owners.register(owner,j.pid||0)});
      if(req.method==='POST'&&p==='/native/panel-presence'){if(j.sessionId){const s=status();if(!s.active||s.sessionId!==j.sessionId)throw Error('meeting_changed');panelPresence.update(j.clientId,j.sessionId,j.foreground);}panelPresence.touch(j.clientId,j.foreground);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-visibility')return send(200,{ok:true,...owners.visibility(owner,j.foreground)});
      if(req.method==='POST'&&p==='/native/panel-show'){if(owner&&!owners.has(owner))throw Error('native_owner_unknown');const s=status();if(!s.active||s.sessionId!==j.sessionId||!['capsule','compact','expanded'].includes(j.view)||current&&!current.session.finalized&&current.owner&&current.owner!==owner)throw Error('native_panel_session_changed');explicitPanel={owner,sessionId:s.sessionId,view:j.view,serial:++panelSerial,at:panelPresence.clock()};if(owner)owners.reopenPanel(owner,s.sessionId);panelPresence.reopen(s.sessionId);return send(200,{ok:true,...ownedStatus(),serial:explicitPanel.serial});}
      if(req.method==='POST'&&p==='/native/main-handoff-begin'){const started=owners.beginMainRestore(owner,j.requestId);log('main-handoff begin serial='+started.serial+' helper='+(started.helperPid||0));return send(200,{ok:true,...started});}
      if(req.method==='POST'&&p==='/native/main-handoff-status')return send(200,{ok:true,...owners.mainRestoreStatus(owner,j.serial)});
      if(req.method==='POST'&&p==='/native/main-handoff-ack'){if(j.hidden!==true)throw Error('native_main_restore_unconfirmed');return send(200,{ok:true,...owners.ackMainRestore(owner,j.serial,j.pid)});}
      if(req.method==='POST'&&p==='/native/main-handoff-finish')return send(200,{ok:true,...owners.finishMainRestore(owner,j.serial)});
      if(req.method==='POST'&&p==='/native/main-handoff-cancel'){const cancelled=owners.cancelMainRestore(owner,j.requestId);log('main-handoff cancel');return send(200,{ok:true,...cancelled});}
      if(req.method==='POST'&&p==='/native/panel-handoff-ack'){const policy=ownedStatus().panelPolicy;if(!explicitPanel||explicitPanel.owner!==owner||explicitPanel.sessionId!==j.sessionId||explicitPanel.serial!==j.serial||j.visible!==true||!owner||owners.status(owner).helperPid!==j.pid||!j.pid||!policy?.show||policy.serial!==j.serial)throw Error('native_panel_handoff_stale');explicitPanel.visible=true;explicitPanel.helperPid=j.pid;return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/panel-handoff-status'){if(!explicitPanel||explicitPanel.owner!==owner||explicitPanel.sessionId!==j.sessionId||explicitPanel.serial!==j.serial)throw Error('native_panel_handoff_stale');const policy=ownedStatus().panelPolicy;return send(200,{ok:true,visible:!!explicitPanel?.visible&&!!policy?.show&&policy.serial===j.serial,helperPid:explicitPanel?.helperPid||0});}
      if(req.method==='POST'&&p==='/native/panel-handoff-cancel'){if(explicitPanel&&explicitPanel.owner===owner&&explicitPanel.sessionId===j.sessionId&&explicitPanel.serial===j.serial){explicitPanel=null;if(owner)owners.dismissPanel(owner,j.sessionId);else panelPresence.dismiss(j.sessionId);}return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-panel-dismiss'){const s=status();if(!s.active||!j.sessionId||s.sessionId!==j.sessionId||current&&!current.session.finalized&&current.owner&&current.owner!==owner)throw Error('native_panel_session_changed');explicitPanel=null;if(owner)owners.dismissPanel(owner,j.sessionId);else panelPresence.dismiss(j.sessionId);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-panel-reopen'){if(owner&&!owners.has(owner))throw Error('native_owner_unknown');const s=status();if(!s.active||!j.sessionId||s.sessionId!==j.sessionId||current&&!current.session.finalized&&current.owner&&current.owner!==owner)throw Error('native_panel_session_changed');explicitPanel={owner,sessionId:s.sessionId,view:['capsule','compact','expanded'].includes(j.view)?j.view:'expanded',serial:++panelSerial,at:-Infinity};if(owner)owners.reopenPanel(owner,j.sessionId);panelPresence.reopen(j.sessionId);return send(200,{ok:true,...ownedStatus()});}
      if(req.method==='POST'&&p==='/native/owner-helper-ready'){
        noteHelperPoll(owner);
        if(!await runtime.current(j.pid)){retireStale().catch(e=>log('stale helper '+e.message));throw Error('helper_outdated');}
        if(j.sessionId!==undefined){
          const live=current,offer=explicitPanel;
          const valid=()=>live&&current===live&&!live.session.finalized&&owners.has(owner)&&
            (!live.owner||live.owner===owner&&live.ownerHandoffSerial===j.serial&&owners.status(owner).helperPid===j.pid)&&
            live.session.id===j.sessionId&&offer&&explicitPanel===offer&&offer.owner===owner&&
            offer.sessionId===j.sessionId&&offer.serial===j.serial&&owners.mainAlive(owner)&&!owners.status(owner).quitRequested;
          if(!valid())throw Error('native_owner_handoff_stale');
          // The singleton already recording must claim itself; never select or
          // launch another helper to satisfy a presentation request.
          const helpers=await runtime.helpers();
          if(helpers.length!==1||helpers[0].pid!==j.pid||!valid())throw Error('native_owner_handoff_stale');
          const ready=owners.helperReady(owner,j.pid);live.owner=owner;live.ownerHandoffSerial=offer.serial;
          return send(200,{ok:true,...ready,sessionId:live.session.id,serial:offer.serial});
        }
        return send(200,{ok:true,...owners.helperReady(owner,j.pid)});
      }
      if(req.method==='POST'&&p==='/native/owner-open-main'){
        owners.openMain(owner,j.sessionId,j.panel);
        const own=owners.status(owner);
        // 原生主窗口还在时，它读 openSerial 回到同一扇。这里再开 Chrome 会多出一扇。
        if(owners.mainAlive(owner))return send(200,{ok:true,mode:'native-main',openSerial:own.openSerial});
        const sessionId=j.sessionId||status().sessionId||'';
        const chromePanel=['settings','update'].includes(j.panel)?{panel:j.panel}:{};
        const result=await openMain({port,sessionId,...chromePanel},openEnv);
        return send(200,{ok:true,...result,openSerial:own.openSerial});
      }
      if(req.method==='POST'&&p==='/native/owner-quit'){owners.requestQuit(owner);if(pendingOwner===owner){pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';}return send(200,{ok:true,...owners.status(owner)});}
      if(req.method==='POST'&&p==='/native/owner-quit-failed'){owners.failed(owner,j.error);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-quit-ready'){
        if(pendingOwner===owner||current?.owner===owner&&!current.session.finalized)throw Error('native_meeting_not_saved');
        owners.saved(owner);return send(200,{ok:true});
      }
      if(req.method==='POST'&&p==='/native/owner-release'){owners.release(owner);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/input-devices'){helperReportedIdleAt=Date.now();noteHelperPoll(owner);}
      if(owner&&!owners.has(owner))throw Error('native_owner_unknown');
      if(req.method==='POST'&&p==='/native/input-devices'){if(!owner||!owners.has(owner))throw Error('native_owner_unknown');if(current&&!current.session.finalized&&current.owner&&owner!==current.owner)throw Error('native_capture_owned_by_another_window');inputDevices=normalizeInputs(j.inputDevices);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/input-preference'){if(status().active)throw Error('capture_already_active');const uid=String(j.inputUID||'');if(uid&&!inputDevices.some(d=>d.uid===uid))throw Error('microphone_disconnected');inputUID=uid;return send(200,{ok:true,inputUID});}
      if(req.method==='POST'&&p==='/native/open-main'){const sessionId=j.sessionId||status().sessionId||'';const result=await openMain({port,sessionId,...(j.panel?{panel:j.panel}:{})},openEnv);return send(200,{ok:true,...result});}
      if(req.method==='POST'&&p==='/native/ui-language'){if(!['en','zh'].includes(j.language))throw Error('invalid_ui_language');uiLanguage=j.language;return send(200,{ok:true,uiLang:uiLanguage});}
      if(req.method==='POST'&&(p==='/native/launch'||p==='/native/join')){const result=await requestLaunch(j,owner,p);return send(result.code,result.body);}
      if(pendingStart&&pendingOwner!==owner&&['/native/cancel-start','/native/launch-ack'].includes(p))throw Error('native_start_owner_changed');
      // 旧小窗（别的 launchId）迟到的放弃 / 回执不能取消或确认后来的那次 launch
      if(req.method==='POST'&&['/native/cancel-start','/native/launch-ack'].includes(p)&&staleLaunch(j))return send(200,{ok:true,stale:true});
      if(req.method==='POST'&&p==='/native/cancel-start'){
        // The start response may time out after its session was created. Only
        // the same launch/owner's explicit stopped receipt can retire that
        // unready session; a late cancellation must never end live capture.
        if(current&&!current.session.finalized&&!current.captureReady&&j.captureStopped===true&&launchIdOf(j)&&current.launchId===launchIdOf(j)&&current.owner===owner)await end();
        if(!pendingStart)voidedTrial=null;   // 小窗自己报放弃：它不会再发 start
        if(!status().active){launchAccessGrant=null;startupErrorSessionId=pendingStart?.sessionId||'';if(pendingStart?.sessionId)remember(pendingStart.sessionId);pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';launching=false;launchGeneration++;startupError=typeof j.error==='string'?j.error.slice(0,200):'';}return send(200,{ok:true,...status()});}
      if(req.method==='POST'&&p==='/native/launch-ack'){if(pendingStart)pendingAcked=true;else if(voidedTrial)voidedTrial.acked=true;launchCommand='';pendingJoinUrl='';return send(200,{ok:true});}
      if(req.method==='PUT'&&p==='/native/rules'){if(typeof j.prompt!=='string'||!j.prompt.trim()||j.prompt.length>6000)throw Error('invalid_prompt');journal.write(path.join(dataDir,'state','native-insight-rules.json'),j);return send(200,{ok:true,rules:rules(dataDir)});}
      if(req.method==='POST'&&p==='/native/start')return send(200,{ok:true,...await start(j,owner)});
      if(current&&!current.session.finalized&&current.owner&&owner!==current.owner&&p!=='/native/rules'&&!(['/native/insight-retry','/native/asr-retry','/native/capture-retry'].includes(p)&&!owner&&[`http://127.0.0.1:${port}`,`http://localhost:${port}`,`http://[::1]:${port}`].includes(req.headers.origin))&&!(p==='/native/microphone-switch'&&!owner&&[`http://127.0.0.1:${port}`,`http://localhost:${port}`,`http://[::1]:${port}`].includes(req.headers.origin)))throw Error('native_capture_owned_by_another_window');
      if(req.method==='POST'&&p==='/native/asr-retry'){
        const session=browserSession()||current?.session;
        if(!session||session.finalized||session.id!==j.sessionId)return send(409,{error:'meeting_changed'});
        if(session.miniPaused)return send(409,{error:'录音已暂停，请恢复录音后重试转写。',asrStatus:session.asrStatus||null});
        if(session.mac||session.dg)return send(409,{error:'cloud_asr_not_active'});
        const boundaryRetry=String(session.asrStatus?.code||'').startsWith('outbound_');
        session.env=config();session.hasKey=!!(session.env.VOLC_APP_KEY&&session.env.VOLC_ACCESS_KEY);
        clearTimeout(session.volcReconnectTimer);session.volcReconnectTimer=null;session.volcFailStreak=0;
        session.asrStatus={state:'retrying',code:'',message:session.audioSaveError?'正在重新连接转写；音频保存异常，请保留并导出录音备份。':'正在重新连接转写，录音继续保留。',audioPreserved:!session.audioSaveError,updatedAt:Date.now()};
        session.broadcast({type:'asr-status',asrStatus:session.asrStatus});
        if(session.volcWs)session.dropVolc('manual retry');if(boundaryRetry)session.connectAsr();else session.connectVolc();notify();
        return send(200,{ok:true,asrStatus:session.asrStatus});
      }
      if(req.method==='POST'&&p==='/native/insight-retry'){
        if(!current||current.session.finalized||current.session.id!==j.sessionId)return send(409,{error:'meeting_changed'});
        return send(200,{ok:true,...current.feed.retry(j.recoveryId)});
      }
      if(req.method==='POST'&&p==='/native/confirmation'){
        const session=browserSession()||current?.session;if(!session||session.id!==j.sessionId)return send(409,{error:'meeting_changed'});
        const confirmation=require('./live-confirmations').respond(session,j.confirmationId,j.response,{dataDir,text:j.text});return send(200,{ok:true,confirmation,...status()});
      }
      if(req.method==='POST'&&endedSessions.has(j.sessionId)&&['/native/heartbeat','/native/audio','/native/text','/native/frame','/native/events'].includes(p))return send(409,{error:'meeting_ended'});
      const browser=browserSession();
      if(browser){
        if(j.sessionId!==browser.id)return send(409,{error:'meeting_changed'});
      if(req.method==='POST'&&p==='/native/heartbeat'){if(['expanded','compact','transcript','hidden'].includes(j.view))browserView=j.view;forwardNativeSpeakerSignals(browser,j,0);return send(200,{ok:true,...ownedStatus()});}
        if(req.method==='POST'&&p==='/native/browser-state'){if(!j.paused){await requireAccess();browser.restoreRecordingAccess?.();}if(j.paused)void browser.reportRecordingActivity?.(false);browser.miniPaused=!!j.paused;browser.idle?.keep(Date.now());return send(200,{ok:true,...status()});}
        if(req.method==='POST'&&p==='/native/browser-ack'){if(j.command===browserCommand&&browserCommandSession===browser.id){browserCommand='';browserCommandSession='';}return send(200,{ok:true,...status()});}
        if(req.method==='POST'&&p==='/native/command'){if(j.command==='resume'){await requireAccess();browser.restoreRecordingAccess?.();}if(!['stop','pause','resume'].includes(j.command))throw Error('invalid_command');browserCommand=j.command;browserCommandSession=browser.id;browser.broadcast?.({type:'native-view-command',command:browserCommand});return send(200,{ok:true,...status()});}
        return send(409,{error:'browser_capture_owns_this_meeting'});
      }
      if(p==='/native/end'&&current?.session.trial&&current.session.finalized&&j.sessionId===current.session.id){if(!current.session.trialDiscarded)await end();return send(200,{ok:true,...status()});}
      if(!current||current.session.finalized)return send(409,{error:'no_native_meeting'});
      if(j.sessionId!==current.session.id)return send(409,{error:'meeting_changed'});
      if(req.method==='POST'&&p==='/native/capture-retry'){
        if(!current.captureReady)throw Error('native_capture_not_ready');
        if(command||current.session.miniPaused)throw Error('native_capture_control_pending');
        if(current.captureRecovery==='recovering')return send(200,{ok:true,...status()});
        if(!current.captureRetry)current.captureRetry={requestId:crypto.randomUUID(),sessionId:current.session.id};
        return send(200,{ok:true,...status()});
      }
      if(req.method==='POST'&&p==='/native/microphone-switch'){
        const uid=String(j.inputUID||'');if(uid&&!inputDevices.some(d=>d.uid===uid))throw Error('microphone_disconnected');
        if(current.microphoneChange&&Date.now()>current.microphoneChange.expiresAt){current.microphoneReceipt={requestId:current.microphoneChange.requestId,ok:false,error:'录音端未确认切换，可重试；请以实际声音来源为准'};current.microphoneChange=null;}
        if(current.microphoneChange){if(current.microphoneChange.inputUID===uid)return send(200,{ok:true,...status()});throw Error('microphone_switch_pending');}
        current.microphoneChange={requestId:require('crypto').randomUUID(),inputUID:uid,expiresAt:Date.now()+20000};return send(200,{ok:true,...status()});
      }
      if(req.method==='POST'&&p==='/native/microphone-ack'){
        const change=current.microphoneChange;if(!change||change.requestId!==j.requestId){if(current.microphoneReceipt?.requestId===j.requestId)return send(200,{ok:true,...status()});return send(409,{error:'microphone_request_changed'});}
        const error=String(j.error||'').slice(0,200);
        if(!error){current.inputUID=String(j.inputUID||'');current.inputName=String(j.inputName||'');inputUID=change.inputUID;}
        current.microphoneReceipt={requestId:change.requestId,ok:!error,error};current.microphoneChange=null;notify();return send(200,{ok:true,...status()});
      }
      if(req.method==='POST'&&p==='/native/ready'){if(!current.captureReady){onCaptureReady(current.session);current.captureReady=true;current.audioAdvancedAt=Date.now();}return send(200,{ok:true,...status()});}
      if(req.method==='POST'&&p==='/native/heartbeat'){if(current.captureRetry&&j.captureRetryAck===current.captureRetry.requestId)current.captureRetry=null;if(['ready','recovering','failed','system-audio-unavailable'].includes(j.captureRecovery))current.captureRecovery=j.captureRecovery;if(Array.isArray(j.inputDevices))inputDevices=normalizeInputs(j.inputDevices);if(typeof j.captureEnding==='boolean')current.captureEnding=j.captureEnding;current.inputUID=String(j.inputUID||current.inputUID||'').slice(0,300);current.inputName=String(j.inputName||current.inputName||'').slice(0,200);if(typeof j.capturePaused==='boolean'){const paused=!!current.session.recordingAccessBlocked||j.capturePaused;const phaseDesync=paused?current.feed.phase!=='paused':current.feed.phase==='paused';if(current.session.miniPaused!==paused||phaseDesync){current.audioAdvancedAt=Date.now();current.session.idle?.keep(Date.now());current.session.miniPaused=paused;current.feed.pause(paused);}if(command==='pause'&&j.capturePaused===true)command='';else if(command==='resume'&&j.capturePaused===false&&!current.session.recordingAccessBlocked)command='';}if(j.audioEvidence&&typeof j.audioEvidence==='object')current.audioEvidence=Object.fromEntries(['microphoneFrames','systemFrames','microphonePeak','systemPeak','microphoneLevel','systemLevel'].map(k=>[k,Math.max(0,Number(j.audioEvidence[k])||0)]));current.audioLevel=Math.max(0,Math.min(1,Number(j.audioLevel)||0));current.audioLevelAt=Date.now();current.lastHeartbeat=Date.now();const captureState=JSON.stringify({paused:!!j.capturePaused,reason:String(j.pauseReason||'').slice(0,80),error:String(j.error||'').slice(0,200),transport:String(j.transportError||'').slice(0,200)});if(current.captureState!==captureState){current.captureState=captureState;log('native capture state '+current.session.id+' '+captureState+' pending='+Math.max(0,Number(j.pendingAudioPackets)||0));}if(['expanded','compact','transcript','hidden'].includes(j.view)&&current.view!==j.view){current.view=j.view;notify();}if(owner&&['hidden','expanded','compact','capsule','transcript'].includes(j.view)){try{if(owners.noteHelperView(owner,j.view))log('main-handoff helper reported hidden');}catch(e){}}{const seconds=Math.max(0,Number(j.audioSeconds)||0);if(seconds>(current.audioSeconds||0)){current.audioAdvancedAt=Date.now();if(current.captureReady&&!current.session.miniPaused&&!current.captureEnding)void current.session.reportRecordingActivity?.(true);}if(current.session.miniPaused||current.captureEnding)void current.session.reportRecordingActivity?.(false);current.audioSeconds=Math.max(current.audioSeconds,seconds);}if(typeof j.error==='string'&&current.error!==j.error){current.error=String(j.error).slice(0,200);notify();}forwardNativeSpeakerSignals(current.session,j,0);return send(200,{ok:true,...ownedStatus()});}
      if(req.method==='POST'&&p==='/native/audio'){
        if(current.asr.transport!=='pcm' && current.session.pendingAudioPolicy!==true)throw Error('native_audio_not_configured');
        // Pausing stops capture, not ACK/retry of already saved tail audio.
        const result=current.audioIngress.accept(j,pcm=>{require('./latency-diagnostics').receive(current.session,j.latencyDiagnostic);forwardNativeSpeakerSignals(current.session,j,pcm.length);current.session.sendAudio(pcm,{capturedAt:Number(j.capturedAt)});});return send(200,{ok:true,...result});
      }
      if(req.method==='POST'&&p==='/native/text')return send(200,{ok:true,accepted:current.feed.text(j)});
      if(req.method==='POST'&&p==='/native/frame'){const accepted=current.feed.frame(j.jpeg);if(accepted)current.frames++;return send(200,{ok:true,accepted});}
      if(req.method==='POST'&&p==='/native/pause'){if(!j.paused){await requireAccess();current.session.restoreRecordingAccess?.();}else void current.session.reportRecordingActivity?.(false);command='';current.captureRetry=null;current.session.miniPaused=!!j.paused;current.session.idle?.keep(Date.now());current.feed.pause(!!j.paused);current.audioAdvancedAt=Date.now();notify();return send(200,{ok:true,...status()});}
      if(req.method==='POST'&&p==='/native/end')return send(200,{ok:true,...await end({liveTail:j.liveTail==='unconfirmed'?'unconfirmed':''})});
      if(req.method==='POST'&&p==='/native/command'){if(j.command==='resume'){await requireAccess();current.session.restoreRecordingAccess?.();}if(!['stop','pause','resume'].includes(j.command))throw Error('invalid_command');if(j.command==='resume'&&current.captureEnding)throw Error('native_capture_ending');command=j.command;current.captureRetry=null;return send(200,{ok:true,...status()});}
      return send(404,{error:'native_route_not_found'});
    }catch(e){return send(e.status||409,{error:String(e?.message||e||'native_request_failed').slice(0,200),...(e.code?{code:e.code}:{})});}
  }
  async function prepareUpdate({timeoutMs=5000}={}){
    if(updating)throw Error('正在更新，请稍后重试');
    if(status().active||pendingStart||launching)throw Error('会议仍在进行或接入，结束后再更新');
    updating=true;
    try{
      const deadline=Date.now()+timeoutMs;
      while((await runtime.helpers()).length){
        if(status().active||pendingStart)throw Error('会议状态已变化，未更新');
        if(Date.now()>=deadline)throw Error('录音小窗尚未安全退出，未替换程序。请正常退出闲置小窗后重试；录音不会被强制关闭');
        await new Promise(r=>setTimeout(r,100));
      }
      return ()=>{updating=false;};
    }catch(e){updating=false;throw e;}
  }
  async function ensureWatcher(){
    if(!canLaunch()||updating||current||pendingStart||launching||status().active||status().starting)return false;
    try{const helpers=await runtime.helpers();if(helpers.length)return false;}catch{}
    launchWatcher();
    return true;
  }
  async function recycleIdleHelperForPermissions(){
    if(!canLaunch()||updating||current||pendingStart||launching||status().active||status().starting)return false;
    let helpers=[];
    try{helpers=await runtime.helpers();}catch{return false;}
    const pids=helpers.map(h=>h&&h.pid).filter(Boolean);
    if(!pids.length)return false;
    if(updating||current||pendingStart||launching||status().active||status().starting)return false;
    for(const pid of pids){try{signal(pid,'SIGTERM');}catch{}}
    for(const end=Date.now()+1500;pids.some(pid=>!helperGone(pid))&&Date.now()<end;)await new Promise(r=>setTimeout(r,50));
    if(!(current&&!current.session.finalized)&&!pendingStart&&!launching)for(const pid of pids)if(!helperGone(pid)){try{signal(pid,'SIGKILL');}catch{}}
    for(const end=Date.now()+1000;pids.some(pid=>!helperGone(pid))&&Date.now()<end;)await new Promise(r=>setTimeout(r,50));
    if(canLaunch()&&!updating&&!current&&!pendingStart&&!launching&&!status().active&&!status().starting){
      log('recycled idle helper for fresh TCC preflight '+pids.join(','));
      launchWatcher();
      return true;
    }
    return false;
  }
  return {researchFinding(sessionId,f){if(current&&!current.session.finalized&&current.session.id===sessionId)void current.feed.researchFinding(f);},route,status,language:()=>uiLanguage||'zh',requestLaunch,prepareUpdate,ensureWatcher,recycleIdleHelperForPermissions,requestCommand(sessionId,value){if(!current||current.session.finalized||current.session.id!==sessionId)return false;if(!['stop','pause','resume'].includes(value))return false;command=value;current.captureRetry=null;if(value==='pause'){current.audioAdvancedAt=Date.now();if(current.feed.phase!=='paused'){current.session.miniPaused=true;current.feed.pause(true);}}else if(value==='resume')current.audioAdvancedAt=Date.now();return true;},close(){clearInterval(lease);current?.feed.close();}};
}
function noteUnconfirmedLiveTail(session,liveTail){
  if(!session||session.finalized||liveTail!=='unconfirmed')return false;
  session.liveTailUnconfirmed=true;
  if(!session.asrFinalizationError)session.asrFinalizationError='实时尾段未确认，原始录音仍留在本机';
  return true;
}
function retainUnconfirmedLiveTail(session){
  if(!session?.liveTailUnconfirmed)return false;
  const mark='实时尾段未确认，原始录音仍留在本机';
  const current=String(session.asrFinalizationError||'');
  if(current.includes(mark))return false;
  session.asrFinalizationError=current?current+'；'+mark:mark;
  return true;
}
module.exports={meetingLink,panelCards,mergeJudgmentCards,available,rules,jpegSize,cards,InsightFeed,create,noteUnconfirmedLiveTail,retainUnconfirmedLiveTail};
