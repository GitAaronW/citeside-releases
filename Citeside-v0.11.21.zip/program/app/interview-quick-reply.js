'use strict';

// Interview Quick-Reply engine ("面试快答 / 面接クイック回答 / Interview Quick-Reply")
// Incorporates turn state machine, <100ms local instant cards, multi-part question checklist,
// free JD & free self-intro fact reuse (zero fabrication), JA/EN/ZH workplace rules,
// and speculative fast LLM refinement.

const DEFAULT_T_SHOW = { ja: 900, en: 700, zh: 700 };
const DEFAULT_MERGE_WINDOW_MS = 1500;
const DEFAULT_RUSH_WINDOW_MS = 2000;
const DEFAULT_USER_FREEZE_MS = 2000;
const DEFAULT_USER_FREEZE_CHARS = 8;

const NOISE_PATTERNS = [
  /聞こえますか/u,
  /見えますか/u,
  /音声.{0,6}(大丈夫|聞こえ)/u,
  /画面.{0,6}(見え|共有)/u,
  /接続.{0,4}(大丈夫|安定)/u,
  /\bcan you hear me\b/i,
  /\bcan you see my screen\b/i,
  /\bis my (mic|audio|video)\b/i,
  /\bhow are you doing today\b/i,
  /听得到吗|听得见吗|能听到吗|能看到屏幕吗|声音清楚吗|画面卡吗/u
];

const REVERSE_Q_PATTERNS = [
  /何か(ご)?質問はありますか/u,
  /(ご)?質問は(ござい|あり)ますか/u,
  /最後に(何か)?質問/u,
  /逆質問/u,
  /聞いておきたいこと/u,
  /\b(any|do you have any)\s+questions?\s+(for\s+(us|me|the team))?/i,
  /\bquestions?\s+for\s+(us|me)\b/i,
  /你有什么(想)?问(我们|我)?的/u,
  /有什么问题(想问|要问)/u,
  /反问环节/u
];

const IMPROPER_PATTERNS = [
  /結婚|ご結婚|既婚|独身|出産|妊娠|お子さん|子供.{0,4}(予定|計画)|家族構成|本籍|出身地.{0,4}家族|宗教|支持政党|年齢.{0,4}(いくつ|何歳)/u,
  /\b(married|marital status|pregnant|plan to have kids|children|how old are you|your age|religion|nationality|political|salary history|current salary|what do you currently make)\b/i,
  /结婚了吗|婚育|打算要孩子|生孩子|生二胎|你多大|年龄多大|宗教信仰|籍贯家庭|目前薪资流水/u
];

const CODING_BOUNDARY_PATTERNS = [
  /\b(leetcode|big[\s-]?o|time complexity|space complexity|dynamic programming|binary tree|linked list|red-black tree|system design|design twitter|design uber|whiteboard coding|write (a |the )?(function|algorithm|code))\b/i,
  /アルゴリズム.{0,6}(実装|書い)|計算量|システムデザイン|ライブコーディング|ホワイトボード/u,
  /算法题|动态规划|时间复杂度|空间复杂度|手写代码|白板编程|系统设计|设计一个高并发/u
];

const BANNED_FLUFF = [
  'コミュニケーション能力',
  'チームワーク',
  '頑張ります',
  '精一杯',
  '何でもやります',
  'hard-working',
  'hardworking',
  'team player',
  'passionate',
  'fast learner',
  'detail-oriented',
  'self-starter',
  '抗压能力强',
  '学习能力强',
  '吃苦耐劳',
  '沟通能力强',
  '团队合作精神'
];

const JA_QUESTION_RE = /(か|でしょうか|ですか|ますか|ください|いただけますか|お願いします|教えて|聞かせて|お聞かせ|いかが|どう思|どう考え|理由は|なぜ|どこが|何が|ありますか|でしたか)[。？?！!\s]*$/u;
const EN_QUESTION_START_RE = /^(what|why|how|when|where|who|which|could you|can you|would you|do you|did you|have you|are you|were you|tell me|walk me through|describe|give me an example|share a time|talk me through|explain)\b/i;
const EN_QUESTION_INLINE_RE = /\b(tell me about|walk me through|give me an example|how did you|how would you|why did you|why do you|what did you|what would you|what is your|what are your|can you describe|could you share)\b/i;
const ZH_QUESTION_RE = /(吗|呢|呀|啊|吧|怎么|为什么|为何|能否|是不是|可以.{0,8}(说|讲|介绍)|请.{0,8}(介绍|说|讲|举例)|举个例子|怎么看|如何|什么|哪(个|些|里)|有没有)[。？?！!\s]*$/u;

const JA_STOPWORDS = new Set(['こと', 'もの', 'ところ', 'ため', 'よう', 'これ', 'それ', 'あれ', '私', '当社', '弊社', '御社', '今回', '今日', '現在', '基本', '感じ', '部分', '内容', '質問', '回答', '面接', 'よろしく', 'お願い']);
const EN_STOPWORDS = new Set(['the', 'and', 'for', 'with', 'that', 'this', 'from', 'have', 'your', 'about', 'what', 'when', 'where', 'which', 'would', 'could', 'should', 'there', 'their', 'they', 'been', 'were', 'will', 'into', 'more', 'some', 'very', 'just', 'like', 'also', 'our', 'are', 'you', 'can', 'how', 'why', 'tell', 'give', 'time', 'team', 'role', 'work']);
const ZH_STOPWORDS = new Set(['我们', '你们', '他们', '这个', '那个', '什么', '怎么', '为什么', '可以', '能够', '一下', '一个', '一些', '然后', '因为', '所以', '如果', '但是', '主要', '目前', '现在', '这边', '那边', '问题', '面试', '介绍一下']);

function detectLang(text, fallback = 'ja') {
  const s = String(text || '');
  if (/[\u3040-\u30ff]/u.test(s)) return 'ja';
  const cjk = (s.match(/[\u4e00-\u9fff]/gu) || []).length;
  const latin = (s.match(/[A-Za-z]/g) || []).length;
  if (cjk >= 2 && cjk >= latin * 0.25) return 'zh';
  if (latin >= 4) return 'en';
  return fallback || 'ja';
}

function normalizeSpace(s) {
  return String(s || '').replace(/\s+/g, ' ').trim();
}

function isNoiseUtterance(text) {
  const s = normalizeSpace(text);
  if (!s || s.length < 3) return true;
  // Only treat as pure noise when short and not followed by an actual interview question
  if (s.length > 28 && /(教えて|聞かせて|理由|経歴|成果|強み|tell me|walk me|how would|why did|介绍一下|怎么)/iu.test(s)) {
    return false;
  }
  return NOISE_PATTERNS.some((re) => re.test(s));
}

function detectReverseQuestion(text) {
  const s = normalizeSpace(text);
  return REVERSE_Q_PATTERNS.some((re) => re.test(s));
}

function detectImproperQuestion(text) {
  const s = normalizeSpace(text);
  return IMPROPER_PATTERNS.some((re) => re.test(s));
}

function detectCodingBoundary(text) {
  const s = normalizeSpace(text);
  return CODING_BOUNDARY_PATTERNS.some((re) => re.test(s));
}

function extractQuestionClause(text, langHint) {
  const s = normalizeSpace(text);
  if (!s) return '';
  // Split bundled multi-sentence ASR utterances and pick the most recent substantive question clause
  const clauses = s.split(/(?<=[。！？.!?])\s*/u).map(normalizeSpace).filter(Boolean);
  if (clauses.length <= 1) return s;
  for (let i = clauses.length - 1; i >= 0; i -= 1) {
    if (detectQuestion(clauses[i], langHint)) return clauses[i];
  }
  return s;
}

function detectQuestion(text, langHint) {
  const s = normalizeSpace(text);
  if (!s || isNoiseUtterance(s)) return false;
  if (detectReverseQuestion(s) || detectImproperQuestion(s) || detectCodingBoundary(s)) return true;

  const lang = detectLang(s, langHint);
  // If bundled multi-sentence text contains an embedded question clause ending with ? / ？
  const clauses = s.split(/(?<=[。！？.!?])\s*/u).map(normalizeSpace).filter(Boolean);
  if (clauses.length > 1) {
    if (clauses.some((c) => c !== s && detectQuestion(c, lang))) return true;
  }

  const stripped = s.replace(/[。、,.!！\s]+$/u, '');
  const hasQuestionMark = /[？?]\s*$/u.test(s);

  if (lang === 'ja') {
    if (JA_QUESTION_RE.test(stripped)) return true;
    if (hasQuestionMark && stripped.length >= 5) return true;
    return /(転職理由|志望動機|希望年収|入社可能|残業|転勤|深掘り|実績|工夫した点)/u.test(stripped);
  }
  if (lang === 'en') {
    if (EN_QUESTION_START_RE.test(stripped) || EN_QUESTION_INLINE_RE.test(stripped)) return true;
    if (hasQuestionMark && stripped.split(/\s+/).length >= 3) return true;
    return /\b(salary expectations?|walk me through|tell me about)\b/i.test(stripped);
  }
  if (ZH_QUESTION_RE.test(stripped)) return true;
  if (hasQuestionMark && stripped.length >= 4) return true;
  return /(离职原因|为什么离开|期望薪资|介绍一下|举例说明|怎么解决|最大挑战|复盘)/u.test(stripped);
}

function cleanClause(str, maxLen = 20) {
  const s = normalizeSpace(str).replace(/^[、。,:：\-—\s]+|[、。,:：?？!！\s]+$/gu, '');
  if (!s) return '';
  return [...s].length > maxLen ? [...s].slice(0, maxLen).join('') + '…' : s;
}

function extractKeywordsForMatch(text) {
  const s = normalizeSpace(text).toLowerCase();
  const tokens = new Set();
  for (const m of s.match(/[a-z][a-z0-9_-]{2,}/g) || []) {
    if (!EN_STOPWORDS.has(m)) tokens.add(m);
  }
  for (const m of s.match(/[\u4e00-\u9fff\u30a0-\u30ff]{2,8}/gu) || []) {
    if (!JA_STOPWORDS.has(m) && !ZH_STOPWORDS.has(m)) tokens.add(m);
  }
  // Japanese kanji+okurigana nouns (e.g. 強み, 工夫, 学び, 動き方)
  for (const m of s.match(/[\u4e00-\u9fff][\u3041-\u3096]{1,2}/gu) || []) {
    if (!JA_STOPWORDS.has(m) && !/^(して|され|でき|あり|なり|思い|考え|教え|聞か|伺い|いた)$/u.test(m)) {
      tokens.add(m);
    }
  }
  return [...tokens];
}

function detectMultiPart(text, langHint) {
  const s = normalizeSpace(text);
  const lang = detectLang(s, langHint);
  const items = [];

  if (lang === 'ja') {
    const m1 = s.match(/(?:1つ目|一つ目|まず|①)[^。？?]*?(?:は|が|として)?([^。？?]{3,28})/u);
    const m2 = s.match(/(?:2つ目|二つ目|もう一つ|次に|②)[^。？?]*?(?:は|が|として)?([^。？?]{3,28})/u);
    const m3 = s.match(/(?:3つ目|三つ目|③)[^。？?]*?(?:は|が|として)?([^。？?]{3,28})/u);
    if (m1 && m2) {
      items.push({ index: 1, label: cleanClause(m1[1], 18), covered: false });
      items.push({ index: 2, label: cleanClause(m2[1], 18), covered: false });
      if (m3) items.push({ index: 3, label: cleanClause(m3[1], 18), covered: false });
    } else if (/(2点|二点|二つ|2つ)/u.test(s)) {
      const parts = s.split(/(?:、|と|および|それと|あと)/u).map((x) => cleanClause(x, 18)).filter((x) => x.length >= 3);
      if (parts.length >= 2) {
        items.push({ index: 1, label: parts[parts.length - 2], covered: false });
        items.push({ index: 2, label: parts[parts.length - 1], covered: false });
      }
    }
  } else if (lang === 'en') {
    const m = s.match(/\bfirst(?:ly)?[,:\s]+([^.?]{4,50})[.,;\s]+(?:and\s+)?second(?:ly)?[,:\s]+([^.?]{4,50})/i);
    if (m) {
      items.push({ index: 1, label: cleanClause(m[1], 28), covered: false });
      items.push({ index: 2, label: cleanClause(m[2], 28), covered: false });
    } else if (/\b(two things|two questions|two parts|a couple of questions)\b/i.test(s)) {
      const parts = s.split(/\band\b|[;?:]/i).map((x) => cleanClause(x, 28)).filter((x) => x.length >= 6);
      if (parts.length >= 2) {
        items.push({ index: 1, label: parts[parts.length - 2], covered: false });
        items.push({ index: 2, label: parts[parts.length - 1], covered: false });
      }
    }
  } else {
    const m1 = s.match(/(?:第一|第一个|首先|①)[、，,：:\s是]*([^。？?；;]{3,24})/u);
    const m2 = s.match(/(?:第二|第二个|其次|另外|②)[、，,：:\s是]*([^。？?；;]{3,24})/u);
    if (m1 && m2) {
      items.push({ index: 1, label: cleanClause(m1[1], 18), covered: false });
      items.push({ index: 2, label: cleanClause(m2[1], 18), covered: false });
    } else if (/(两个问题|两点|两件事)/u.test(s)) {
      const parts = s.split(/[，,；;？?]|以及|还有/u).map((x) => cleanClause(x, 18)).filter((x) => x.length >= 3);
      if (parts.length >= 2) {
        items.push({ index: 1, label: parts[parts.length - 2], covered: false });
        items.push({ index: 2, label: parts[parts.length - 1], covered: false });
      }
    }
  }

  return items.map((item) => ({
    ...item,
    keywords: extractKeywordsForMatch(item.label)
  }));
}

function extractJdKeywords(text, existing = []) {
  const s = normalizeSpace(text);
  const out = new Set(existing);
  const patterns = [
    /[\u4e00-\u9fff\u30a0-\u30ff]{2,10}(?:推進|開発|改善|拡大|立ち上げ|運用|設計|管理|営業|戦略|チーム|事業|プロダクト|顧客|課題)/gu,
    /[\u4e00-\u9fff]{2,8}(?:增长|转型|推进|架构|团队|商业化|交付|合规|客户|研发|质量)/gu,
    /\b(?:cross-functional|enterprise|scalability|reliability|go-to-market|gtm|b2b|saas|retention|conversion|migration|architecture|roadmap|stakeholders?|platform|revenue|latency)\b/gi
  ];
  for (const re of patterns) {
    for (const m of s.match(re) || []) {
      const clean = normalizeSpace(m);
      if (clean.length >= 2 && !JA_STOPWORDS.has(clean) && !ZH_STOPWORDS.has(clean)) {
        out.add(clean);
      }
    }
  }
  return [...out].slice(0, 12);
}

function extractUserFacts(text, existing = []) {
  const s = normalizeSpace(text);
  if (!s) return existing;
  const out = [...existing];
  const seen = new Set(existing.map((x) => x.text));
  const clauses = s.split(/[。！？.!?\n]+/u).map((x) => normalizeSpace(x)).filter(Boolean);
  const factRe = /(\d+(?:\.\d+)?\s*(?:%|％|倍|x|年|ヶ月|か月|人|名|名規模|億|万|k|m|ms|秒|件|社|プロジェクト)|リード|責任者|担当|立ち上げ|改善|削減|売上|负责|主导|提升|降低|led|built|shipped|reduced|grew|scaled|owned)/i;
  for (const c of clauses) {
    if (factRe.test(c) && c.length >= 6) {
      const snippet = [...c].length > 32 ? [...c].slice(0, 32).join('') + '…' : c;
      if (!seen.has(snippet)) {
        seen.add(snippet);
        out.push({ text: snippet, keywords: extractKeywordsForMatch(c) });
      }
    }
  }
  return out.slice(-12);
}

function extractNumbers(text) {
  const matches = String(text || '').match(/\d+(?:\.\d+)?/g) || [];
  return [...new Set(matches)];
}

function checkFabricatedNumbers(candidateText, allowedSourceText) {
  const candidateNums = extractNumbers(candidateText);
  if (!candidateNums.length) return [];
  const allowed = new Set(extractNumbers(allowedSourceText));
  // Ignore checklist index numbers 1, 2, 3 when standalone
  return candidateNums.filter((n) => !allowed.has(n));
}

function containsBannedFluff(text) {
  const low = String(text || '').toLowerCase();
  return BANNED_FLUFF.filter((w) => low.includes(w.toLowerCase()));
}

function findMatchingUserFact(questionText, userFacts) {
  if (!userFacts || !userFacts.length) return null;
  const qKeys = new Set(extractKeywordsForMatch(questionText));
  let best = null;
  let bestScore = 0;
  for (const fact of userFacts) {
    let score = 0;
    for (const k of fact.keywords || []) {
      if (qKeys.has(k)) score += 2;
    }
    if (score > bestScore) {
      bestScore = score;
      best = fact;
    }
  }
  return best || userFacts[userFacts.length - 1];
}

function buildQuestionGist(text, lang) {
  const s = normalizeSpace(text)
    .replace(/^(えーと|あの|そうですね|それでは|では|まず|well|so|um|uh|okay|alright|那|嗯|好)[、,.\s]+/iu, '');
  const max = lang === 'en' ? 48 : 24;
  return [...s].length > max ? [...s].slice(0, max).join('') + '…' : s;
}

function detectClassicTemplate(text, lang, ctx = {}) {
  const s = normalizeSpace(text);
  const jdRef = (ctx.jdKeywords && ctx.jdKeywords[0]) || '';

  if (detectImproperQuestion(s)) {
    if (lang === 'ja') {
      return {
        mode: 'improper',
        zeroLlm: true,
        openingLine: '業務遂行には支障ありません',
        slots: [{ text: '[業務・役割への意欲に戻す]' }, { text: '[具体的な貢献イメージ]' }],
        redFlag: '選考外質問・丁寧に転換',
        intent: '見ている点：配慮しつつ業務軸へ戻す（法的判断ではありません）'
      };
    }
    if (lang === 'en') {
      return {
        mode: 'improper',
        zeroLlm: true,
        openingLine: 'Happy to focus on the role fit:',
        slots: [{ text: '[Pivot back to job requirements]' }, { text: '[Your relevant impact]' }],
        redFlag: 'Sensitive Q · pivot',
        intent: 'Note: Often inappropriate — redirect politely (not legal advice)'
      };
    }
    return {
      mode: 'improper',
      zeroLlm: true,
      openingLine: '这方面不影响我的工作投入',
      slots: [{ text: '[礼貌拉回岗位要求]' }, { text: '[强调可交付成果]' }],
      redFlag: '敏感提问·礼貌转回岗位',
      intent: '提示：此类问题通常与岗位无关，可礼貌转回工作（非法律建议）'
    };
  }

  if (detectCodingBoundary(s)) {
    if (lang === 'ja') {
      return {
        mode: 'coding_boundary',
        zeroLlm: true,
        openingLine: 'まず要件と前提を確認します',
        slots: [{ text: '[制約・スケール確認]' }, { text: '[トレードオフを2点]' }],
        redFlag: '実装・設計面は対象外',
        intent: '範囲外：アルゴリズム・設計面は汎用枠組みのみ表示'
      };
    }
    if (lang === 'en') {
      return {
        mode: 'coding_boundary',
        zeroLlm: true,
        openingLine: 'Let me clarify constraints first:',
        slots: [{ text: '[Scale & edge cases]' }, { text: '[Core trade-offs]' }],
        redFlag: 'Not for coding Qs',
        intent: 'Out of scope: coding/system design uses structure cue only'
      };
    }
    return {
      mode: 'coding_boundary',
      zeroLlm: true,
      openingLine: '我先确认下边界与约束条件',
      slots: [{ text: '[规模与核心约束]' }, { text: '[权衡方案]' }],
      redFlag: '算法/系统设计面非覆盖',
      intent: '边界提示：仅提供澄清与权衡骨架，不代解算法题'
    };
  }

  if (detectReverseQuestion(s)) {
    if (lang === 'ja') {
      const q1 = jdRef ? `「${jdRef}」の最初の90日で期待される成果は？` : '入社後90日で最も期待される成果は？';
      const q2 = '活躍している方に共通する動き方は？';
      return {
        mode: 'reverse_q',
        zeroLlm: true,
        openingLine: '逆質問：2点伺いたいです',
        slots: [{ text: `① ${q1}` }, { text: `② ${q2}` }],
        redFlag: '一次面接は待遇NG',
        intent: '見ている点：志望度・入社後の解像度',
        jdRef
      };
    }
    if (lang === 'en') {
      const q1 = jdRef ? `What does 90-day success look like for ${jdRef}?` : 'What does success in the first 90 days look like?';
      const q2 = 'What separates top performers on this team?';
      return {
        mode: 'reverse_q',
        zeroLlm: true,
        openingLine: 'Great — I have two quick questions:',
        slots: [{ text: `1) ${q1}` }, { text: `2) ${q2}` }],
        redFlag: 'Save comp for later',
        intent: 'Testing: genuine interest & role clarity',
        jdRef
      };
    }
    const q1 = jdRef ? `围绕「${jdRef}」，入职前90天最看重什么结果？` : '这个岗位入职前90天最核心的交付目标是什么？';
    const q2 = '目前团队里做得最好的人有什么共同特质？';
    return {
      mode: 'reverse_q',
      zeroLlm: true,
      openingLine: '我有 2 个和岗位相关的问题',
      slots: [{ text: `① ${q1}` }, { text: `② ${q2}` }],
      redFlag: '一面先不问福利薪资',
      intent: '他在测：岗位理解度与加入诚意',
      jdRef
    };
  }

  if (lang === 'ja') {
    if (/転職.{0,8}理由|なぜ(辞め|退職|転職)|現職.{0,6}(不満|課題|辞)/u.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '「結論から申しますと、より上流の課題に挑戦したいと考えたためです。」',
        slots: [
          { text: '理由：現職でやり切ったことと、次に広げたい領域を前向きに伝える' },
          { text: jdRef ? `結び：御社の「${jdRef}」ならその挑戦が実現できると繋ぐ` : '結び：御社の環境でどう貢献したいかに着地させる' }
        ],
        redFlag: '前職批判NG',
        intent: '見ている点：定着性・他責でないか（PREP法）',
        jdRef
      };
    }
    if (/志望動機|なぜ当社|なぜ弊社|うちを選んだ|当社に興味/u.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: jdRef
          ? `「御社の『${jdRef}』への取り組みに強く共感し、志望しました。」`
          : '「御社の事業フェーズと、これまでの私の実績が最も活かせると感じたためです。」',
        slots: [
          { text: '根拠：職務経歴の中で再現性のある実績を1つ挙げる' },
          { text: '貢献：入社後にまず力になれる領域を具体的に伝える' }
        ],
        redFlag: '福利厚生のみNG',
        intent: '見ている点：本気度・企業理解',
        jdRef
      };
    }
    if (/希望年収|年収.{0,6}(希望|どれくらい|イメージ)|給与/u.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '「現年収をベースに、ポジションの役割に応じてご相談できればと思います。」',
        slots: [
          { text: 'レンジ：下限〜上限を幅で伝え、過度な固定額は避ける' },
          { text: '姿勢：成果と期待役割に合わせて柔軟に相談したいと添える' }
        ],
        redFlag: '根拠なき高額NG',
        intent: '見ている点：相場観・柔軟性'
      };
    }
    if (/入社可能|いつから入社|退職交渉|引き継ぎ/u.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '「内定から引き継ぎを含め、最短で調整したいと考えております。」',
        slots: [
          { text: '目安：現職の引き継ぎに必要な期間を率直に伝える' },
          { text: '意欲：決まり次第スムーズに動ける旨を一言添える' }
        ],
        redFlag: '曖昧な先送りNG',
        intent: '見ている点：段取り力・志望度'
      };
    }
    if (/残業|転勤|出社|リモート|勤務地/u.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '「前提条件を確認させていただいたうえで、柔軟に対応したいです。」',
        slots: [
          { text: '現実ライン：対応できる範囲を正直かつ前向きに伝える' },
          { text: '強み：時間だけでなく生産性で成果を出す姿勢を添える' }
        ],
        redFlag: '条件確認前の即拒否NG',
        intent: '見ている点：現実的マッチ度'
      };
    }
    if (/短期離職|ブランク|空白期間|すぐ辞め|短い期間/u.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '「当時の判断とそこから得た学びを率直にお伝えします。」',
        slots: [
          { text: '事実：背景を言い訳せず簡潔に1〜2文で説明する' },
          { text: '学び：今はどう改善し、長く貢献できる軸があるかを伝える' }
        ],
        redFlag: '言い訳・他責NG',
        intent: '見ている点：自己客観視・定着性'
      };
    }
    if (/本当にできますか|それだけですか|浅い|成果が弱い|厳し|甘く|納得できない/u.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '「ご指摘ありがとうございます。事実ベースで1点補足させてください。」',
        slots: [
          { text: '補足：感情的にならず、自分が実際に動いた具体例を1つ出す' },
          { text: '改善：足りない点は認識しており、次の打ち手まで言い切る' }
        ],
        redFlag: '反論・感情的NG',
        intent: '見ている点：ストレス耐性・冷静さ'
      };
    }
    return null;
  }

  if (lang === 'en') {
    if (/\b(salary expectations?|compensation|expected pay|pay range)\b/i.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '"Before sharing a number, could you share the budgeted range for this role?"',
        slots: [
          { text: 'Anchor: Give a market-aligned range rather than a single rigid figure' },
          { text: 'Close: Emphasize total scope, impact, and flexibility' }
        ],
        redFlag: 'No past salary needed',
        intent: 'Testing: level & market alignment'
      };
    }
    if (/\b(tell me about a time|describe a (time|situation)|give me an example|conflict|disagree|mistake|failed|failure|biggest challenge)\b/i.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '"Sure — to give you the outcome first, here is a specific situation I owned:"',
        slots: [
          { text: 'Action ("I"): Focus on the exact decision you personally drove' },
          { text: 'Result: Close with your real measurable outcome or lesson' }
        ],
        redFlag: 'Say "I", not "we"',
        intent: 'Testing: personal ownership & impact'
      };
    }
    if (/\b(how would you|what would you do|design a strategy|approach|prioritize|ambiguous|first 90 days)\b/i.test(s)) {
      return {
        mode: 'standard',
        zeroLlm: true,
        openingLine: '"Before diving into a solution, let me quickly clarify two assumptions:"',
        slots: [
          { text: 'Clarify: Confirm the primary goal or constraint with the interviewer' },
          { text: jdRef ? `Connect: Tie your trade-offs directly back to ${jdRef}` : 'Structure: Lay out 2 clear options and state your trade-off' }
        ],
        redFlag: 'Ask clarifying Qs',
        intent: 'Testing: structured thinking under ambiguity',
        jdRef
      };
    }
    return null;
  }

  // ZH classic templates
  if (/离职原因|为什么离开|为什么看新机会|上一份工作/u.test(s)) {
    return {
      mode: 'standard',
      zeroLlm: true,
      openingLine: '「核心原因是我希望往更上游的业务/技术空间走一步。」',
      slots: [
        { text: '正向收口：一句话讲清上一份经历已经积累了什么，现在想突破什么' },
        { text: jdRef ? `落回岗位：顺势连到对方刚提的「${jdRef}」方向` : '落回岗位：说明看重贵司这个岗位能带来的真实挑战' }
      ],
      redFlag: '别说前司坏话',
      intent: '他在测：稳定性与正向归因',
      jdRef
    };
  }
  if (/期望薪资|薪资要求|薪资预期/u.test(s)) {
    return {
      mode: 'standard',
      zeroLlm: true,
      openingLine: '「我更看重岗位空间，想先了解一下这个职级目前的薪资区间？」',
      slots: [
        { text: '给区间：结合自身当前水平报一个合理区间，留出沟通余地' },
        { text: '表态度：强调看重团队匹配度和长期成长' }
      ],
      redFlag: '别只报死数字',
      intent: '他在测：定级匹配与预期合理性'
    };
  }
  return null;
}

function buildGenericInstantCard(questionText, lang, ctx = {}) {
  const jdRef = (ctx.jdKeywords && ctx.jdKeywords[0]) || '';
  const fact = findMatchingUserFact(questionText, ctx.userFacts || []);
  const isFollowUp = /^(なぜ|どうして|具体的には|ちなみに|あと|and what|why did|how did|那你|具体来说|为什么)/iu.test(normalizeSpace(questionText));

  if (lang === 'ja') {
    const slot1 = fact
      ? { text: `さっき話した実績と一貫：${fact.text}`, fromSelfIntro: true }
      : { text: '結論→理由：自分が主導した具体例を1つ挙げる（PREP法）' };
    const slot2 = jdRef
      ? { text: `結び：御社の「${jdRef}」にどう活かせるかで締める` }
      : { text: '結果：当時の工夫と実際の変化で締める' };
    return {
      mode: 'standard',
      openingLine: isFollowUp ? '「背景を1点に絞ってお伝えすると——」' : '「はい、結論から申しますと——」',
      slots: [slot1, slot2],
      redFlag: isFollowUp ? '前発言と矛盾NG' : '抽象論NG・具体例で',
      intent: isFollowUp ? '見ている点：深掘り一貫性・主体性' : '見ている点：再現性・職務経歴の解像度',
      jdRef
    };
  }
  if (lang === 'en') {
    const slot1 = fact
      ? { text: `You mentioned: ${fact.text}`, fromSelfIntro: true }
      : { text: 'Action: Highlight the exact step you personally drove ("I")' };
    const slot2 = jdRef
      ? { text: `Connect: Tie your example back to ${jdRef}` }
      : { text: 'Outcome: Share the real metric or impact you achieved' };
    return {
      mode: 'standard',
      openingLine: isFollowUp ? '"To zoom in on the part I personally owned:"' : '"Sure — the short answer is:"',
      slots: [slot1, slot2],
      redFlag: 'Say "I", not "we"',
      intent: isFollowUp ? 'Testing: depth & consistency' : 'Testing: clarity & real ownership',
      jdRef
    };
  }
  const slot1 = fact
    ? { text: `你刚说过：${fact.text}`, fromSelfIntro: true }
    : { text: '讲做法：挑一个你实际主导过的项目，说明你拍板了什么' };
  const slot2 = jdRef
    ? { text: `落回岗位：顺手呼应对方刚提的「${jdRef}」` }
    : { text: '给结果：补上你真实做到的效果或数据变化' };
  return {
    mode: 'standard',
    openingLine: isFollowUp ? '「聚焦我个人负责的那一块来说——」' : '「先说结论，我结合实际经历分两点回答您——」',
    slots: [slot1, slot2],
    redFlag: isFollowUp ? '别和前面说矛盾' : '别泛泛而谈',
    intent: isFollowUp ? '他在测：追问一致性与真实归属' : '他在测：主体性与结果闭环',
    jdRef
  };
}

function getDisclaimer(lang) {
  if (lang === 'ja') return '経歴の創作はしません・画面共有に隠しません';
  if (lang === 'en') return 'Never fabricates experience · Screen-share honest';
  return '绝不编造经历 · 不做隐身隐藏';
}

function jaccardSimilarity(a, b) {
  const ta = new Set(extractKeywordsForMatch(a));
  const tb = new Set(extractKeywordsForMatch(b));
  if (!ta.size && !tb.size) return 1;
  if (!ta.size || !tb.size) return 0;
  let inter = 0;
  for (const x of ta) if (tb.has(x)) inter += 1;
  return inter / (ta.size + tb.size - inter);
}

function percentile(values, p) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[idx];
}

function createInterviewQuickReply(opts = {}) {
  const onCard = typeof opts.onCard === 'function' ? opts.onCard : () => {};
  const askModel = typeof opts.askModel === 'function' ? opts.askModel : null;
  const useTimers = opts.useTimers !== false;
  const defaultLang = opts.lang || 'ja';
  const mergeWindowMs = Number.isFinite(opts.mergeWindowMs) ? opts.mergeWindowMs : DEFAULT_MERGE_WINDOW_MS;
  const rushWindowMs = Number.isFinite(opts.rushWindowMs) ? opts.rushWindowMs : DEFAULT_RUSH_WINDOW_MS;
  const userFreezeMs = Number.isFinite(opts.userFreezeMs) ? opts.userFreezeMs : DEFAULT_USER_FREEZE_MS;
  const userFreezeChars = Number.isFinite(opts.userFreezeChars) ? opts.userFreezeChars : DEFAULT_USER_FREEZE_CHARS;

  let turnState = 'IDLE'; // IDLE | THEM_SPEAKING | QUESTION_OPEN | USER_ANSWERING
  let currentCard = null;
  let cardSeq = 0;
  let silenceTimer = null;

  let themBuffer = '';
  let themSpeaker = '';
  let themLastActivityTs = 0;
  let themTurnCount = 0;
  let themSpeakersSeen = new Set();

  let meSpeakStartTs = 0;
  let meCurrentAnswerChars = 0;

  let jdKeywords = [];
  let userFacts = [];
  let speculativeReq = null; // { text, promise, lang, startedAt }

  const metrics = {
    totalCards: 0,
    rushedCards: 0,
    firstLineLatenciesMs: [],
    specificityHits: 0,
    specificityTotal: 0,
    fabricatedNumbersCount: 0,
    manualTriggers: 0
  };

  function getTShowMs(lang) {
    if (Number.isFinite(opts.tShowMs)) return opts.tShowMs;
    return DEFAULT_T_SHOW[lang] ?? 700;
  }

  function clearTimer() {
    if (silenceTimer) {
      clearTimeout(silenceTimer);
      silenceTimer = null;
    }
  }

  function scoreCardSpecificity(card, questionText) {
    const qTokens = new Set(extractKeywordsForMatch(questionText));
    const lines = [card.openingLine, ...(card.slots || []).map((s) => s.text)].filter(Boolean);
    for (const line of lines) {
      metrics.specificityTotal += 1;
      const hasSlot = /\[[^\]]+\]|①|②|1\)|2\)|：|:/u.test(line);
      const hasNoun = extractKeywordsForMatch(line).some((k) => qTokens.has(k) || jdKeywords.includes(k));
      const hasFact = (card.slots || []).some((s) => s.text === line && s.fromSelfIntro);
      if (hasSlot || hasNoun || hasFact) metrics.specificityHits += 1;
    }
  }

  function sanitizeLlmOutput(parsed, card, questionText) {
    if (!parsed || typeof parsed !== 'object') return null;
    const allowedSource = [
      questionText,
      ...jdKeywords,
      ...userFacts.map((f) => f.text)
    ].join(' ');

    const opening = normalizeSpace(parsed.openingLine || '');
    const rawSlots = Array.isArray(parsed.slots) ? parsed.slots.slice(0, 2) : [];
    const redFlag = normalizeSpace(parsed.redFlag || '');
    const intent = normalizeSpace(parsed.intent || '');

    const checkText = [opening, ...rawSlots.map((s) => (typeof s === 'string' ? s : s?.text || '')), redFlag, intent].join(' ');
    if (containsBannedFluff(checkText).length > 0) return null;
    if (checkFabricatedNumbers(checkText, allowedSource).length > 0) return null;

    const stripPrefixRe = card.lang === 'en' ? /^$/ : /^(?:lead|tip|point|cue|action|result|anchor|close|clarify|connect|structure)\s*[:：]\s*/i;
    const cleanSlots = rawSlots
      .map((s) => {
        const txt = normalizeSpace(typeof s === 'string' ? s : s?.text || '')
          .replace(/\[([^\]]+)\]/g, '$1')
          .replace(stripPrefixRe, '');
        if (!txt || txt.length < 4) return null;
        return { text: txt, fromSelfIntro: Boolean(s && s.fromSelfIntro) };
      })
      .filter(Boolean);

    if (!opening || cleanSlots.length < 2) return null;
    return {
      openingLine: [...opening].length > 52 ? [...opening].slice(0, 52).join('') + '…' : opening,
      slots: cleanSlots,
      redFlag: redFlag ? ([...redFlag].length > 18 ? [...redFlag].slice(0, 18).join('') : redFlag) : card.redFlag,
      intent: intent || card.intent
    };
  }

  function startSpeculativeLlm(text, lang, targetCardId) {
    if (!askModel) return null;
    const systemPrompt = [
      'You are a Speakable-First real-time interview whisper coach.',
      'Return strict JSON ONLY: {"openingLine":"1 natural spoken sentence the candidate can literally read aloud","slots":["1 short natural tip without any English prefix","1 short follow-up cue"],"redFlag":"<=10 chars warning","intent":""}.',
      'Rules: NEVER write "Lead:" or any English label in Chinese/Japanese output. NEVER use [square brackets]. NEVER fabricate numbers or experiences not in USER_FACTS. NEVER use generic fluff (team player, hard-working, コミュニケーション能力, ガクチカ).',
      lang === 'ja' ? 'For Japan mid-career interviews use polite spoken Japanese + PREP (結論→理由→具体例), never ガクチカ.' : '',
      lang === 'en' ? 'For US interviews encourage clarifying questions on open-ended prompts and remind "I" not "we" on behavioral prompts.' : ''
    ].filter(Boolean).join('\n');

    const userPayload = JSON.stringify({
      lang,
      question: normalizeSpace(text).slice(-400),
      jdKeywords: jdKeywords.slice(0, 6),
      userFacts: userFacts.slice(-5).map((f) => f.text)
    }).slice(0, 1500);

    const req = {
      text: normalizeSpace(text),
      lang,
      startedAt: Date.now(),
      promise: Promise.resolve()
        .then(() => askModel(systemPrompt, userPayload, { purpose: 'interview-quick-reply', maxTokens: 120 }))
        .then((raw) => {
          if (!raw) return null;
          const str = typeof raw === 'string' ? raw : String(raw.text || raw.content || '');
          const m = str.match(/\{[\s\S]*\}/);
          if (!m) return null;
          return JSON.parse(m[0]);
        })
        .catch(() => null)
    };
    speculativeReq = req;

    if (targetCardId) {
      req.promise.then((parsed) => {
        if (!parsed || !currentCard || currentCard.id !== targetCardId || currentCard.frozen) return;
        const safe = sanitizeLlmOutput(parsed, currentCard, currentCard.rawQuestion);
        if (!safe) return;
        currentCard = {
          ...currentCard,
          revision: currentCard.revision + 1,
          stage: 'refined',
          openingLine: safe.openingLine,
          slots: safe.slots,
          redFlag: safe.redFlag,
          intent: safe.intent
        };
        onCard({ ...currentCard });
      });
    }
    return req;
  }

  function emitCardForQuestion(questionText, nowTs, { isMerge = false, isManual = false } = {}) {
    const cleanQ = extractQuestionClause(questionText, defaultLang);
    if (!cleanQ) return null;
    const lang = detectLang(cleanQ, defaultLang);
    const tpl = detectClassicTemplate(cleanQ, lang, { jdKeywords, userFacts });
    const base = tpl || buildGenericInstantCard(cleanQ, lang, { jdKeywords, userFacts });
    const multiPart = detectMultiPart(cleanQ, lang).map(({ index, label, covered, keywords }) => ({
      index,
      label,
      covered,
      _keywords: keywords
    }));

    const shownAt = Number.isFinite(nowTs) ? nowTs : Date.now();
    const silenceStart = themLastActivityTs || shownAt;
    const firstLineLatencyMs = Math.max(0, Math.min(5000, shownAt - silenceStart));

    if (isMerge && currentCard) {
      if (shownAt - currentCard.shownAt <= rushWindowMs) {
        metrics.rushedCards += 1;
      }
      currentCard = {
        ...currentCard,
        revision: currentCard.revision + 1,
        stage: 'instant',
        mode: base.mode || 'standard',
        lang,
        askedBy: themSpeakersSeen.size > 1 ? (themSpeaker || '') : '',
        rawQuestion: cleanQ,
        questionGist: buildQuestionGist(cleanQ, lang),
        multiPart: multiPart.length ? multiPart : currentCard.multiPart,
        openingLine: base.openingLine,
        slots: base.slots,
        redFlag: base.redFlag || '',
        intent: base.intent || '',
        jdRef: base.jdRef || '',
        merged: true
      };
    } else {
      cardSeq += 1;
      metrics.totalCards += 1;
      metrics.firstLineLatenciesMs.push(firstLineLatencyMs);
      if (isManual) metrics.manualTriggers += 1;
      currentCard = {
        id: `iqr-${cardSeq}`,
        revision: 1,
        stage: 'instant',
        mode: base.mode || 'standard',
        lang,
        askedBy: themSpeakersSeen.size > 1 ? (themSpeaker || '') : '',
        rawQuestion: cleanQ,
        questionGist: buildQuestionGist(cleanQ, lang),
        multiPart,
        openingLine: base.openingLine,
        slots: base.slots,
        redFlag: base.redFlag || '',
        intent: base.intent || '',
        jdRef: base.jdRef || '',
        frozen: false,
        dimmed: false,
        merged: false,
        createdAt: shownAt,
        shownAt,
        firstLineLatencyMs,
        disclaimer: getDisclaimer(lang)
      };
      scoreCardSpecificity(currentCard, cleanQ);
    }

    turnState = 'QUESTION_OPEN';
    const publicCard = stripInternal(currentCard);
    onCard(publicCard);

    // Speculative / async LLM refinement for non-zero-LLM standard questions
    if (askModel && currentCard.mode === 'standard' && !(tpl && tpl.zeroLlm)) {
      const targetId = currentCard.id;
      if (speculativeReq && jaccardSimilarity(speculativeReq.text, cleanQ) >= 0.55) {
        speculativeReq.promise.then((parsed) => {
          if (!parsed || !currentCard || currentCard.id !== targetId || currentCard.frozen) return;
          const safe = sanitizeLlmOutput(parsed, currentCard, currentCard.rawQuestion);
          if (!safe) return;
          currentCard = {
            ...currentCard,
            revision: currentCard.revision + 1,
            stage: 'refined',
            openingLine: safe.openingLine,
            slots: safe.slots,
            redFlag: safe.redFlag,
            intent: safe.intent
          };
          onCard(stripInternal(currentCard));
        });
      } else {
        startSpeculativeLlm(cleanQ, lang, targetId);
      }
    }

    return publicCard;
  }

  function stripInternal(card) {
    if (!card) return null;
    return {
      ...card,
      multiPart: (card.multiPart || []).map(({ index, label, covered }) => ({ index, label, covered })),
      jdKeywords: jdKeywords.slice(0, 6),
      userFacts: userFacts.slice(-4).map((f) => f.text)
    };
  }

  function updateChecklistFromUserSpeech(text) {
    if (!currentCard || !currentCard.multiPart || !currentCard.multiPart.length) return false;
    const low = normalizeSpace(text).toLowerCase();
    let changed = false;
    for (const item of currentCard.multiPart) {
      if (item.covered) continue;
      const keys = item._keywords || extractKeywordsForMatch(item.label);
      if (keys.some((k) => low.includes(k))) {
        item.covered = true;
        changed = true;
      }
    }
    if (changed) {
      currentCard = { ...currentCard, revision: currentCard.revision + 1 };
      onCard(stripInternal(currentCard));
    }
    return changed;
  }

  function scheduleSilenceCheck(lang, baseTs) {
    if (!useTimers) return;
    clearTimer();
    const wait = getTShowMs(lang);
    silenceTimer = setTimeout(() => {
      onSilenceTick(baseTs + wait);
    }, wait);
    if (typeof silenceTimer.unref === 'function') silenceTimer.unref();
  }

  function handleThemActivity(text, speaker, ts, isFinal) {
    const clean = normalizeSpace(text);
    if (!clean) return;
    const nowTs = Number.isFinite(ts) ? ts : Date.now();
    if (speaker) {
      themSpeaker = String(speaker);
      themSpeakersSeen.add(themSpeaker);
    }

    // Extract free JD keywords from early interviewer turns
    if (isFinal && themTurnCount < 5) {
      jdKeywords = extractJdKeywords(clean, jdKeywords);
    }

    // If QUESTION_OPEN and interviewer continues within mergeWindowMs -> merge in-place
    if (turnState === 'QUESTION_OPEN' && currentCard && !currentCard.frozen && (nowTs - currentCard.shownAt) <= mergeWindowMs) {
      const mergedText = currentCard.rawQuestion.endsWith(clean) ? currentCard.rawQuestion : `${currentCard.rawQuestion} ${clean}`;
      themBuffer = mergedText;
      themLastActivityTs = nowTs;
      emitCardForQuestion(mergedText, nowTs, { isMerge: true });
      return;
    }

    // If USER_ANSWERING, interviewer speaking starts a fresh turn immediately (no 6s cooldown!)
    if (turnState === 'USER_ANSWERING') {
      themBuffer = '';
      meSpeakStartTs = 0;
      meCurrentAnswerChars = 0;
    }

    turnState = 'THEM_SPEAKING';
    if (isFinal) {
      themTurnCount += 1;
      themBuffer = themBuffer ? `${themBuffer} ${clean}` : clean;
    } else {
      themBuffer = clean;
    }
    themLastActivityTs = nowTs;

    const lang = detectLang(themBuffer, defaultLang);
    if (!isFinal && askModel && detectQuestion(themBuffer, lang) && !speculativeReq) {
      startSpeculativeLlm(themBuffer, lang, null);
    }

    if (getTShowMs(lang) === 0 && isFinal && detectQuestion(themBuffer, lang)) {
      const q = themBuffer;
      themBuffer = '';
      emitCardForQuestion(q, nowTs);
      return;
    }

    scheduleSilenceCheck(lang, nowTs);
  }

  function handleMeActivity(text, ts, isFinal) {
    const clean = normalizeSpace(text);
    if (!clean) return;
    const nowTs = Number.isFinite(ts) ? ts : Date.now();

    if (isFinal) {
      userFacts = extractUserFacts(clean, userFacts);
    }
    updateChecklistFromUserSpeech(clean);

    if (turnState === 'QUESTION_OPEN' && currentCard && !currentCard.frozen) {
      if (!meSpeakStartTs) meSpeakStartTs = nowTs;
      meCurrentAnswerChars += clean.replace(/\s+/g, '').length;
      const elapsed = nowTs - meSpeakStartTs;
      if (elapsed >= userFreezeMs || meCurrentAnswerChars >= userFreezeChars) {
        turnState = 'USER_ANSWERING';
        currentCard = { ...currentCard, frozen: true, dimmed: true, revision: currentCard.revision + 1 };
        onCard(stripInternal(currentCard));
      }
    } else if (turnState === 'USER_ANSWERING' && currentCard) {
      meCurrentAnswerChars += clean.replace(/\s+/g, '').length;
      let nextNudge = '';
      const uncovered = (currentCard.multiPart || []).find((m) => !m.covered);
      if (currentCard.multiPart && currentCard.multiPart.length >= 2 && uncovered && meCurrentAnswerChars >= 45) {
        nextNudge = currentCard.lang === 'ja'
          ? `忘れず回答：${uncovered.index}. ${uncovered.label}`
          : (currentCard.lang === 'en' ? `Don't miss #${uncovered.index}: ${uncovered.label}` : `别漏第 ${uncovered.index} 问：${uncovered.label}`);
      } else if (meCurrentAnswerChars >= 90 && !/\d/.test(clean)) {
        nextNudge = currentCard.lang === 'ja'
          ? 'そろそろ結論・具体的な成果で締めましょう'
          : (currentCard.lang === 'en' ? 'Wrap up with 1 concrete result or metric' : '该收口了：补 1 个你的真实结果或数据');
      }
      if (nextNudge && nextNudge !== currentCard.nudge) {
        currentCard = { ...currentCard, nudge: nextNudge, revision: currentCard.revision + 1 };
        onCard(stripInternal(currentCard));
      }
    }
  }

  function onPartial({ text, speaker, isMe, ts } = {}) {
    if (isMe) handleMeActivity(text, ts, false);
    else handleThemActivity(text, speaker, ts, false);
  }

  function onFinal({ text, speaker, isMe, ts } = {}) {
    if (isMe) handleMeActivity(text, ts, true);
    else handleThemActivity(text, speaker, ts, true);
  }

  function onSilenceTick(nowTs = Date.now()) {
    if (turnState !== 'THEM_SPEAKING' || !themBuffer) return null;
    const lang = detectLang(themBuffer, defaultLang);
    const tShow = getTShowMs(lang);
    if ((nowTs - themLastActivityTs) < tShow) return null;
    if (!detectQuestion(themBuffer, lang)) return null;
    const q = themBuffer;
    themBuffer = '';
    return emitCardForQuestion(q, nowTs);
  }

  function manualTrigger(nowTs = Date.now(), fallbackText = '') {
    const target = normalizeSpace(themBuffer || fallbackText || (currentCard && currentCard.rawQuestion) || '');
    if (!target) return null;
    themBuffer = '';
    return emitCardForQuestion(target, nowTs, { isManual: true });
  }

  function getMetrics() {
    const rushRate = metrics.totalCards ? metrics.rushedCards / metrics.totalCards : 0;
    const specificityRate = metrics.specificityTotal ? metrics.specificityHits / metrics.specificityTotal : 1;
    return {
      totalCards: metrics.totalCards,
      rushedCards: metrics.rushedCards,
      rushRate: Number(rushRate.toFixed(4)),
      firstLineLatenciesMs: [...metrics.firstLineLatenciesMs],
      p50LatencyMs: percentile(metrics.firstLineLatenciesMs, 50),
      p90LatencyMs: percentile(metrics.firstLineLatenciesMs, 90),
      specificityRate: Number(specificityRate.toFixed(4)),
      fabricatedNumbersCount: metrics.fabricatedNumbersCount,
      manualTriggers: metrics.manualTriggers
    };
  }

  function getContextSummary() {
    return {
      turnState,
      jdKeywords: [...jdKeywords],
      userFacts: userFacts.map((f) => f.text)
    };
  }

  function dispose() {
    clearTimer();
  }

  return {
    onPartial,
    onFinal,
    onSilenceTick,
    manualTrigger,
    getCard: () => stripInternal(currentCard),
    getMetrics,
    getContextSummary,
    dispose
  };
}

module.exports = {
  createInterviewQuickReply,
  detectLang,
  detectQuestion,
  detectMultiPart,
  detectClassicTemplate,
  detectImproperQuestion,
  detectReverseQuestion,
  detectCodingBoundary,
  extractJdKeywords,
  extractUserFacts,
  checkFabricatedNumbers,
  containsBannedFluff,
  isNoiseUtterance
};
