'use strict';
// Operating-system edges for the single verified legacy upgrade coordinator.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),cp=require('node:child_process');
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
function create(context){
 const {identity}=require('./legacy-upgrade');
 const home=context.home||os.homedir(),env=context.env||process.env,artifacts=require('./upgrade-artifacts'),port=Number(env.THT_PORT||47823),appDefault=path.join(home,'Applications/Citeside.app');
 const run=(file,args,options={})=>cp.execFileSync(file,args,{encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:30000,...options});
 const processRows=()=>run('/bin/ps',['-axo','pid=,command=']).split('\n').map(s=>s.trim().match(/^(\d+)\s+(.+)$/)).filter(Boolean).map(m=>({pid:Number(m[1]),command:m[2]}));
 const matches=(command,file)=>command===file||command.startsWith(file+' ')||command.endsWith(' '+file)||command.includes(' '+file+' ');
 let installedLocation;
 const installedApp=()=>{if(installedLocation)return installedLocation;const choices=[appDefault,'/Applications/Citeside.app'],rows=processRows(),active=choices.filter(app=>rows.some(r=>matches(r.command,path.join(app,'Contents/MacOS/Citeside'))));if(active.length>1)throw Error('upgrade_multiple_apps_running');const explicit=context.installedApp||context.appPath;if(context.installedApp&&!choices.includes(path.resolve(context.installedApp)))throw Error('upgrade_installation_path_not_supported');if(explicit&&choices.includes(path.resolve(explicit))){installedLocation=path.resolve(explicit);if(active.length&&active[0]!==installedLocation)throw Error('upgrade_multiple_app_locations');return installedLocation;}if(active.length)return installedLocation=active[0];const existing=choices.filter(app=>fs.existsSync(app));if(existing.length>1)throw Error('upgrade_installation_ambiguous');return installedLocation=existing[0]||appDefault;};
 const alive=pid=>{try{process.kill(pid,0);return true;}catch(e){return e.code!=='ESRCH';}};
 const readHealth=async()=>{try{const r=await fetch('http://127.0.0.1:'+port+'/health',{signal:AbortSignal.timeout(3000)});if(!r.ok)throw Error('upgrade_health_not_authorized');return await r.json();}catch(e){if(e.cause?.code==='ECONNREFUSED')return null;throw Error('upgrade_health_unknown');}};
 let legacyArtifact,incomingArtifact,prepared;
 return {
  async acquireLegacy(){legacyArtifact=await artifacts.acquireLegacy({appPath:fs.existsSync(installedApp())?installedApp():undefined,cacheDir:path.join(home,'Library/Caches/Citeside/upgrade-artifacts/legacy')});return legacyArtifact;},
  async acquireIncoming(want){incomingArtifact=await artifacts.acquireIncoming({...want,...(context.appPath?{appPath:context.appPath}:{}),cacheDir:path.join(home,'Library/Caches/Citeside/upgrade-artifacts',want.version)});return incomingArtifact;},
  async inspect({source,legacy,incoming}){
   const program=path.join(source,'program'),server=path.join(program,'app/server.js'),helper=path.join(program,'app/native-capture/CitesideCapture.app/Contents/MacOS/Citeside'),rows=processRows();
   const ownRows=rows.filter(r=>r.pid!==context.callerPid&&(matches(r.command,server)||matches(r.command,helper)));
   let agent=null;const labelFile=path.join(source,'supervisor-label');if(fs.existsSync(labelFile)){const label=fs.readFileSync(labelFile,'utf8').trim();if(!/^[\w.-]+$/.test(label))throw Error('upgrade_agent_label_invalid');const file=path.join(home,'Library/LaunchAgents',label+'.plist');const original=fs.readFileSync(file),spec=JSON.parse(run('/usr/bin/plutil',['-convert','json','-o','-',file]));if(spec.Label!==label||spec.WorkingDirectory!==program||spec.EnvironmentVariables?.THT_DATA_DIR!==source||spec.Program||spec.ProgramArguments?.length!==2||spec.ProgramArguments[1]!==server)throw Error('upgrade_agent_not_owned');const expected=[legacy.runtime,incoming.runtime].map(f=>hash(fs.readFileSync(f)));if(!expected.includes(hash(fs.readFileSync(spec.ProgramArguments[0]))))throw Error('upgrade_agent_runtime_untrusted');agent={label,file,original,spec};}
   const health=await readHealth();if(health){const owned=health.dataDirectoryId===require('../app/server-state').dataDirectoryId(source)&&require('./process-owner').ownsServer(health.pid,{serverPath:server,rootDir:program,trustedNodeFiles:[legacy.runtime,incoming.runtime]});return {owned,idle:owned&&health.activeSessions===0&&health.uiRefresh?.idle===true,health,agent,processes:ownRows};}
   return {owned:ownRows.length===0,idle:ownRows.length===0,agent,processes:ownRows};
  },
  async prepare({source,target,incoming,proof,cache}){
   const installed=installedApp(),parent=path.dirname(installed);fs.mkdirSync(parent,{recursive:true,mode:0o700});fs.accessSync(parent,fs.constants.W_OK);const incomingPath=path.join(parent,'.Citeside-upgrade-'+crypto.randomUUID()+'.app'),backup=path.join(cache,'previous-main.app');if(fs.existsSync(backup))throw Error('upgrade_rollback_already_present');
   run('/usr/bin/ditto',[incoming.appPath,incomingPath]);run('/usr/bin/codesign',['--verify','--deep','--strict',incomingPath]);const main=path.join(installed,'Contents/MacOS/Citeside'),mains=processRows().filter(r=>matches(r.command,main));
   if(mains.length&&context.entry!=='launcher')run('/usr/bin/codesign',['--verify','--deep','--strict',installed]);
   prepared={installed,incomingPath,backup,agent:proof.agent,mains:context.entry==='launcher'?[]:mains,swapped:false,agentStopped:false,agentStarted:false,codexChanged:false};return prepared;
  },
  async stop({proof,transition}){
   if(proof.agent){run('/bin/launchctl',['bootout','gui/'+process.getuid()+'/'+proof.agent.label]);transition.agentStopped=true;}
   const pids=[...new Set([...proof.processes,...transition.mains].map(p=>p.pid))];for(const pid of pids)if(alive(pid))process.kill(pid,'SIGTERM');for(let i=0;i<60&&pids.some(alive);i++)await new Promise(r=>setTimeout(r,100));if(pids.some(alive))throw Error('upgrade_owned_process_did_not_stop');
  },
  nativeSpool(legacy){
   if(!prepared)throw Error('upgrade_incoming_not_prepared');
   const helper=path.join(prepared.incomingPath,'Contents/Resources/program/app/native-capture/CitesideCapture.app');
   run('/usr/bin/codesign',['--verify','--deep','--strict',helper]);
   const executable=path.join(helper,'Contents/MacOS/Citeside');if(!fs.statSync(executable).isFile()||fs.lstatSync(executable).isSymbolicLink())throw Error('upgrade_incoming_helper_invalid');
   return {...require('../app/native-spool-migration').identify({binary:path.join(legacy.nativeHelper,'Contents/MacOS/Citeside'),verify:()=>true,applicationSupport:path.join(home,'Library/Application Support')}),trustedExecutable:executable};
  },
  async install({source,target,incoming,transition}){
   const program=path.join(target,'program');if(fs.existsSync(program)){if(identity(program).sourceSha!==identity(incoming.program).sourceSha)throw Error('upgrade_target_program_conflict');}else{const pending=path.join(target,'.program-'+crypto.randomUUID());run('/usr/bin/ditto',[incoming.program,pending]);fs.renameSync(pending,program);}
   const nodeDir=path.dirname(path.dirname(incoming.runtime)),runtime=path.join(target,'runtime',path.basename(nodeDir));fs.mkdirSync(path.dirname(runtime),{recursive:true,mode:0o700});if(!fs.existsSync(runtime))run('/usr/bin/ditto',[nodeDir,runtime]);transition.node=path.join(runtime,'bin/node');fs.writeFileSync(path.join(target,'node-path'),transition.node+'\n',{mode:0o600});
   const preset=path.join(source,'program/preset.json');if(fs.existsSync(preset)){const out=path.join(program,'preset.json');if(fs.existsSync(out))throw Error('upgrade_local_preset_conflict');fs.copyFileSync(preset,out);fs.chmodSync(out,0o600);if(hash(fs.readFileSync(preset))!==hash(fs.readFileSync(out)))throw Error('upgrade_local_preset_mismatch');}
   if(context.entry==='launcher'&&path.resolve(incoming.appPath)===path.resolve(transition.installed)){fs.rmSync(transition.incomingPath,{recursive:true,force:true});return;}
   if(fs.existsSync(transition.installed))fs.renameSync(transition.installed,transition.backup);try{fs.renameSync(transition.incomingPath,transition.installed);transition.swapped=true;}catch(e){if(fs.existsSync(transition.backup))fs.renameSync(transition.backup,transition.installed);throw e;}
  },
  async updatePaths({source,target,transition}){
   const file=path.join(home,'.codex/config.toml');if(fs.existsSync(file)){const before=fs.readFileSync(file,'utf8'),after=before.split('\n').map(line=>/^\s*(command|args)\s*=/.test(line)?line.split(source).join(target):line).join('\n');if(after!==before){fs.copyFileSync(file,path.join(path.dirname(transition.backup),'previous-codex-config.toml'));transition.codexChanged=true;const temp=file+'.'+crypto.randomUUID();fs.writeFileSync(temp,after,{mode:fs.statSync(file).mode&0o777});fs.renameSync(temp,file);}}
   if(transition.agent){const spec=transition.agent.spec;spec.WorkingDirectory=path.join(target,'program');spec.ProgramArguments=[transition.node,path.join(target,'program/app/server.js')];spec.EnvironmentVariables={...spec.EnvironmentVariables,THT_DATA_DIR:target,THT_BUNDLED_RUNTIME_ROOT:path.join(transition.installed,'Contents/Resources/runtime')};fs.writeFileSync(path.join(path.dirname(transition.backup),'previous-launchagent.plist'),transition.agent.original,{mode:0o600});run('/usr/bin/plutil',['-convert','xml1','-o',transition.agent.file,'-'],{input:JSON.stringify(spec)});}
  },
  async start({target,incoming,transition}){
   const root=path.join(target,'program'),serverPath=path.join(root,'app/server.js');
   const nextEnv={...env,THT_DATA_DIR:target,THT_NO_OPEN:'1',THT_BUNDLED_RUNTIME_ROOT:path.join(transition.installed,'Contents/Resources/runtime'),NODE_OPTIONS:''};
   if(transition.agent){run('/bin/launchctl',['bootstrap','gui/'+process.getuid(),transition.agent.file]);transition.agentStarted=true;}
   else run(transition.node,[path.join(root,'scripts/launch.js')],{cwd:root,env:nextEnv,timeout:60000});
   let health;const deadline=Date.now()+60000;
   while(Date.now()<deadline){health=await readHealth();if(health)break;await new Promise(r=>setTimeout(r,200));}
   const owned=health&&require('./process-owner').ownsServer(health.pid,{serverPath,rootDir:root,nodePaths:[transition.node],trustedNodeFiles:[incoming.runtime]});
   if(!health||health.buildCommit!==incoming.sourceSha||health.dataDirectoryId!==require('../app/server-state').dataDirectoryId(target)||!owned||health.activeSessions!==0||health.uiRefresh?.idle!==true)throw Error('upgrade_new_server_not_verified');
   transition.startedPid=health.pid;
   if(context.entry!=='launcher'){const log=fs.openSync(path.join(target,'launcher.log'),'a',0o600);try{const child=cp.spawn(path.join(transition.installed,'Contents/MacOS/Citeside'),[],{env:{...env,THT_DATA_DIR:target},detached:true,stdio:['ignore',log,log]});child.on('error',()=>{});child.unref();}finally{fs.closeSync(log);}}
  },
  async rollback({target,transition}){
   if(transition.agentStarted&&transition.agent)run('/bin/launchctl',['bootout','gui/'+process.getuid()+'/'+transition.agent.label]);
   else if(transition.startedPid&&alive(transition.startedPid)){
    const h=await readHealth(),owned=h&&h.pid===transition.startedPid&&h.dataDirectoryId===require('../app/server-state').dataDirectoryId(target)&&h.activeSessions===0&&h.uiRefresh?.idle===true&&require('./process-owner').ownsServer(h.pid,{serverPath:path.join(target,'program/app/server.js'),rootDir:path.join(target,'program'),nodePaths:[transition.node]});
    if(!owned)throw Error('upgrade_rollback_server_not_owned');process.kill(transition.startedPid,'SIGTERM');
   }
   if(transition.swapped){const rejected=transition.installed+'.rejected-'+crypto.randomUUID();fs.renameSync(transition.installed,rejected);if(fs.existsSync(transition.backup))fs.renameSync(transition.backup,transition.installed);}
   if(transition.agentStopped&&transition.agent){fs.writeFileSync(transition.agent.file,transition.agent.original);run('/bin/launchctl',['bootstrap','gui/'+process.getuid(),transition.agent.file]);}
   const cfg=path.join(path.dirname(transition.backup),'previous-codex-config.toml');if(transition.codexChanged&&fs.existsSync(cfg))fs.copyFileSync(cfg,path.join(home,'.codex/config.toml'));
   if(fs.existsSync(transition.incomingPath))fs.rmSync(transition.incomingPath,{recursive:true,force:true});
  }
 };
}
module.exports={create};
