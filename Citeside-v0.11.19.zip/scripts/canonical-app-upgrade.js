'use strict';
// No production default adapter or CLI: callers must explicitly supply every
// platform boundary. The core only writes its private transaction directory.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const atomic=require('../app/session-journal');
const PHASES=['initial','prepared','appQuitConfirmed','serverStopped','swapped','started','verified'];
const METHODS=['inspect','prepare','quitMain','stopServer','moveOld','moveNew','updatePaths','start','verify','restore'];
const fail=code=>Object.assign(Error('Canonical App upgrade: '+code),{code});
const diagnosticName=value=>typeof value==='string'&&/^[A-Za-z0-9_.:-]{1,128}$/.test(value);
function errorDetails(error,depth=0){
 if(!error||typeof error!=='object')return {};
 const details={};for(const key of ['code','domain'])if(diagnosticName(error[key])||key==='code'&&Number.isSafeInteger(error[key]))details[key]=error[key];
 if(Number.isSafeInteger(error.appleEventCode))details.appleEventCode=error.appleEventCode;
 if(Number.isSafeInteger(error.status))details.status=error.status;
 if(error.signal===null||diagnosticName(error.signal))details.signal=error.signal;
 if(typeof error.killed==='boolean')details.killed=error.killed;
 if(depth<2&&error.cause&&typeof error.cause==='object'){const cause=errorDetails(error.cause,depth+1);if(Object.keys(cause).length)details.cause=cause;}
 return details;
}
const canonical=value=>JSON.stringify(value,(_key,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const clone=value=>JSON.parse(JSON.stringify(value));
const digest=value=>crypto.createHash('sha256').update(canonical(value)).digest('hex');
const same=(a,b)=>canonical(a)===canonical(b);
const inside=(root,file)=>file===root||file.startsWith(root+path.sep);
const identity=value=>value&&/^[a-f0-9]{40}$/.test(value.sourceSha||'')&&/^\d+\.\d+\.\d+$/.test(value.version||'')&&/^[a-f0-9]{64}$/.test(value.treeSha256||'');
const equalIdentity=(a,b)=>!!a&&!!b&&['sourceSha','version','treeSha256'].every(k=>a[k]===b[k]);
const targetIdentity=(value,target)=>identity(value)&&value.sourceSha===target.sourceSha&&value.version===target.version;
function absolute(value){if(typeof value!=='string'||!path.isAbsolute(value)||value.includes('\0'))throw fail('invalid_path');return path.resolve(value);}
function realFuture(file){if(fs.existsSync(file))return fs.realpathSync(file);return path.join(realFuture(path.dirname(file)),path.basename(file));}
function contextOf(input){
 const c=clone(input||{});for(const name of ['transactionDir','installedApp','dataDir','programRoot','sourceRoot'])c[name]=absolute(c[name]);
 if(!Number.isSafeInteger(c.uid)||c.uid<0||typeof process.getuid!=='function'||c.uid!==process.getuid())throw fail('uid_mismatch');
 if(!c.installedApp.endsWith('.app')||typeof c.dataDirectoryId!=='string'||!c.dataDirectoryId.trim()||c.dataDirectoryId.length>256)throw fail('invalid_binding');
 for(const item of [c.current,c.target])if(!item||!/^\d+\.\d+\.\d+$/.test(item.version||'')||!/^[a-f0-9]{40}$/.test(item.sourceSha||''))throw fail('invalid_fixed_identity');
 if(c.current.sourceSha!==c.target.sourceSha||c.current.version!==c.target.version)throw fail('program_upgrade_required');
 if(('dmgSha256'in c.target)||('dmgBytes'in c.target))if(!/^[a-f0-9]{64}$/.test(c.target.dmgSha256||'')||!Number.isSafeInteger(c.target.dmgBytes)||c.target.dmgBytes<=0)throw fail('invalid_fixed_asset');
 for(const name of ['home','agentFile'])if(c[name]!==undefined)c[name]=absolute(c[name]);if(c.port!==undefined&&(!Number.isInteger(c.port)||c.port<1||c.port>65535))throw fail('invalid_port');
 const installed=realFuture(c.installedApp),data=realFuture(c.dataDir);if(inside(data,installed)||inside(installed,data))throw fail('app_overlaps_data');
 const state=realFuture(c.transactionDir);for(const name of ['dataDir','installedApp','programRoot','sourceRoot']){const other=realFuture(c[name]);if(inside(other,state)||inside(state,other))throw fail('state_overlaps_application_or_data');}
 return c;
}
function secure(file,uid,directory=false){const s=fs.lstatSync(file);if(s.isSymbolicLink()||s.uid!==uid||(s.mode&0o7777)!==(directory?0o700:0o600)||(directory?!s.isDirectory():!s.isFile()||s.nlink!==1))throw fail('unsafe_transaction_state');}
function exists(file){try{fs.lstatSync(file);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
function syncDirectory(dir){const fd=fs.openSync(dir,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
function write(file,value,uid){secure(path.dirname(file),uid,true);const temp=file+'.tmp.'+process.pid;if(exists(temp))secure(temp,uid);atomic.write(file,value);secure(file,uid);syncDirectory(path.dirname(file));}
function acquire(dir,uid,recover){
 const file=path.join(dir,'lock.json'),nonce=crypto.randomUUID();
 for(let attempt=0;attempt<3;attempt++){
  let fd;try{fd=fs.openSync(file,'wx',0o600);}catch(error){if(error.code!=='EEXIST')throw error;secure(file,uid);let old;try{old=JSON.parse(fs.readFileSync(file));}catch{throw fail('unknown_lock_owner');}if(old.uid!==uid||!Number.isSafeInteger(old.pid)||old.pid<=0||typeof old.nonce!=='string')throw fail('unknown_lock_owner');
   let alive=true;try{process.kill(old.pid,0);}catch(e){if(e.code==='ESRCH')alive=false;else throw fail('lock_owner_not_proven_dead');}if(alive||!recover)throw fail('transaction_locked');
   // Preserve dead-owner evidence. Never steal a live or unverifiable lock.
   try{fs.renameSync(file,file+'.stale-'+crypto.randomUUID());syncDirectory(dir);}catch(e){if(e.code!=='ENOENT')throw e;}continue;
  }
  try{fs.writeFileSync(fd,JSON.stringify({uid,pid:process.pid,nonce}));fs.fsyncSync(fd);}finally{fs.closeSync(fd);}syncDirectory(dir);
  return ()=>{try{secure(file,uid);const current=JSON.parse(fs.readFileSync(file));if(current.nonce===nonce){fs.unlinkSync(file);syncDirectory(dir);}}catch(e){if(e.code!=='ENOENT')throw e;}};
 }
 throw fail('transaction_locked');
}
function journalOf(file,c){
 const bindingSha256=digest(c);if(exists(file)){secure(file,c.uid);let j;try{j=JSON.parse(fs.readFileSync(file));}catch{throw fail('invalid_journal');}
  if(j.schemaVersion!==1||j.bindingSha256!==bindingSha256||!same(j.binding,c))throw fail('journal_binding_conflict');
  if(!PHASES.includes(j.phase)||!['active','blocked','recovery-required','restored','verified'].includes(j.status)||!/^[a-f0-9-]{36}$/.test(j.transactionId||'')||!Number.isSafeInteger(j.sequence)||j.sequence<0)throw fail('invalid_journal');
  const expected={incomingPath:c.installedApp+'.canonical-stage-'+j.transactionId+'.app',backupPath:c.installedApp+'.canonical-backup-'+j.transactionId+'.app'};if(!same(j.paths,expected)||j.plan&&j.planSha256!==digest(j.plan))throw fail('journal_plan_conflict');if(j.plan&&(!same({incomingPath:j.plan.incomingPath,backupPath:j.plan.backupPath},j.paths)||!identity(j.plan.oldIdentity)||!targetIdentity(j.plan.newIdentity,c.target)||!j.plan.originalPaths||!('agentSnapshot'in j.plan)))throw fail('journal_plan_conflict');if(['prepared','appQuitConfirmed','serverStopped','swapped','started'].includes(j.phase)&&!j.plan)throw fail('invalid_journal');return j;
 }
 const transactionId=crypto.randomUUID();return {schemaVersion:1,transactionId,binding:c,bindingSha256,paths:{incomingPath:c.installedApp+'.canonical-stage-'+transactionId+'.app',backupPath:c.installedApp+'.canonical-backup-'+transactionId+'.app'},phase:'initial',status:'active',sequence:0,steps:{},intent:null,plan:null,createdAt:new Date().toISOString()};
}
async function run({context,adapter,recover=false}={}){
 const c=contextOf(context);if(!adapter||METHODS.some(name=>typeof adapter[name]!=='function'))throw fail('explicit_adapter_required');
 const installationLocks=path.join(os.tmpdir(),'citeside-canonical-app-locks-'+c.uid),installationLock=path.join(installationLocks,digest({uid:c.uid,installedApp:realFuture(c.installedApp)}));fs.mkdirSync(installationLock,{recursive:true,mode:0o700});secure(installationLocks,c.uid,true);secure(installationLock,c.uid,true);const releaseInstallation=acquire(installationLock,c.uid,recover);let release;const file=path.join(c.transactionDir,'journal.json');
 try{
  fs.mkdirSync(c.transactionDir,{recursive:true,mode:0o700});secure(c.transactionDir,c.uid,true);syncDirectory(path.dirname(c.transactionDir));release=acquire(c.transactionDir,c.uid,recover);
  const existed=exists(file),j=journalOf(file,c),completedBefore=j.phase==='verified'&&!!j.completedAt,persist=()=>{j.sequence++;j.updatedAt=new Date().toISOString();write(file,j,c.uid);},call=(name)=>adapter[name]({context:clone(c),journal:clone(j)});
  const inspect=async()=>{const s=await call('inspect');if(s?.uid!==c.uid)throw fail('uid_mismatch');if(s.owner!==true)throw fail('not_owner');if(typeof s.idle!=='boolean'||typeof s.mainRunning!=='boolean'||typeof s.serverRunning!=='boolean'||typeof s.pathsUpdated!=='boolean'||typeof s.pathsRestored!=='boolean'||!s.paths)throw fail('invalid_inspection');for(const name of ['installed','incoming','backup'])if(s.paths[name]!==null&&!identity(s.paths[name]))throw fail('unknown_app_identity');return s;};
  const idle=s=>{if(!s.idle)throw fail('busy');};
  const known=s=>Object.values(s.paths).every(id=>id===null||equalIdentity(id,j.plan?.oldIdentity)||equalIdentity(id,j.plan?.newIdentity));
  const oldAt=s=>equalIdentity(s.paths.installed,j.plan?.oldIdentity),newAt=s=>equalIdentity(s.paths.installed,j.plan?.newIdentity);
  const checkpoint=(name,phase)=>{j.steps[name]=true;j.intent=null;if(phase)j.phase=phase;j.status='active';persist();};
  const intent=name=>{j.intent={action:name,sequence:j.sequence+1,at:new Date().toISOString()};persist();};
  const act=async(name,phase,check)=>{intent(name);const result=await call(name),state=await inspect();check(state,result);checkpoint(name,phase);return state;};
  const verify=async expected=>{intent('verify');const result=await call('verify'),s=await inspect();if(result?.ok!==true||result.uid!==c.uid||result.dataDirectoryId!==c.dataDirectoryId||result.sourceSha!==c.target.sourceSha||result.version!==c.target.version||!equalIdentity(s.paths.installed,expected)||!s.mainRunning||!s.serverRunning||j.plan&&!s.pathsUpdated)throw fail('verification_failed');j.verifiedIdentity=expected;j.phase='verified';j.status='verified';j.intent=null;j.completedAt=new Date().toISOString();persist();return {ok:true,phase:'verified',transactionId:j.transactionId,alreadyCurrent:!j.plan};};
  const restore=async()=>{const s=await inspect();idle(s);if(!j.plan||!known(s))throw fail('unknown_recovery_identity');j.recovery={requested:true,completed:false};intent('restore');const result=await call('restore'),after=await inspect();if(result?.restored!==true||!oldAt(after)||!after.pathsRestored||!after.mainRunning||!after.serverRunning||!known(after))throw fail('restoration_unverified');j.recovery.completed=true;j.status='restored';j.intent=null;persist();return true;};
  if(!existed)persist();
  if(existed&&j.phase!=='verified'&&!recover)return {ok:false,phase:j.phase,status:j.status,transactionId:j.transactionId,error:'recovery_required',recoveryRequired:true,restored:j.recovery?.completed===true};
  try{
   if(j.status==='restored'||j.recovery?.requested){if(!j.recovery.completed)await restore();else {const s=await inspect();if(!oldAt(s)||!s.pathsRestored||!s.mainRunning||!s.serverRunning)throw fail('restoration_unverified');}return {ok:false,phase:j.phase,status:'restored',transactionId:j.transactionId,error:'prior_attempt_restored',restored:true,recoveryRequired:true};}
   if(j.phase==='verified'){const s=await inspect();if(!targetIdentity(s.paths.installed,c.target)||!equalIdentity(s.paths.installed,j.verifiedIdentity))throw fail('verified_app_changed');return await verify(j.verifiedIdentity);}
   if(j.phase==='initial'){
    let s=await inspect();idle(s);if(targetIdentity(s.paths.installed,c.target)&&!j.plan)return await verify(s.paths.installed);if(!s.paths.installed||s.paths.backup!==null)throw fail('installation_conflict');
    intent('prepare');const plan=await call('prepare');if(!plan||plan.incomingPath!==j.paths.incomingPath||plan.backupPath!==j.paths.backupPath||!identity(plan.oldIdentity)||!targetIdentity(plan.newIdentity,c.target)||!plan.originalPaths||!('agentSnapshot'in plan))throw fail('invalid_preparation');
    s=await inspect();idle(s);if(!equalIdentity(s.paths.installed,plan.oldIdentity)||!equalIdentity(s.paths.incoming,plan.newIdentity)||s.paths.backup!==null)throw fail('prepared_identity_conflict');j.plan=clone(plan);j.planSha256=digest(j.plan);checkpoint('prepare','prepared');
   }
   if(j.phase==='prepared'){
    const before=await inspect();idle(before);if(!oldAt(before)||!equalIdentity(before.paths.incoming,j.plan.newIdentity)||before.paths.backup!==null)throw fail('prepared_identity_conflict');
    await act('quitMain','appQuitConfirmed',(s,result)=>{if(result?.confirmed!==true||s.mainRunning)throw fail('main_quit_rejected');if(!oldAt(s))throw fail('installed_app_changed');});
   }
   if(j.phase==='appQuitConfirmed'){
    const before=await inspect();idle(before);if(before.mainRunning||!oldAt(before))throw fail('main_quit_not_confirmed');
    if(!before.serverRunning)checkpoint('stopServer','serverStopped');else await act('stopServer','serverStopped',s=>{if(s.mainRunning||s.serverRunning||!oldAt(s))throw fail('owned_server_not_stopped');});
   }
   if(j.phase==='serverStopped'){
    let s=await inspect();idle(s);if(s.mainRunning||s.serverRunning||!known(s))throw fail('swap_preflight_failed');
    if(oldAt(s)&&s.paths.backup===null&&equalIdentity(s.paths.incoming,j.plan.newIdentity))s=await act('moveOld',null,after=>{if(after.paths.installed!==null||!equalIdentity(after.paths.backup,j.plan.oldIdentity)||!equalIdentity(after.paths.incoming,j.plan.newIdentity))throw fail('old_rename_unverified');});
    if(s.paths.installed===null&&equalIdentity(s.paths.backup,j.plan.oldIdentity)&&equalIdentity(s.paths.incoming,j.plan.newIdentity))s=await act('moveNew','swapped',after=>{if(!newAt(after)||after.paths.incoming!==null||!equalIdentity(after.paths.backup,j.plan.oldIdentity))throw fail('new_rename_unverified');});
    else if(newAt(s)&&s.paths.incoming===null&&equalIdentity(s.paths.backup,j.plan.oldIdentity))checkpoint('moveNew','swapped');else throw fail('swap_identity_conflict');
   }
   if(j.phase==='swapped'){
    let s=await inspect();idle(s);if(!newAt(s)||!known(s))throw fail('swapped_identity_conflict');
    if(!s.pathsUpdated)s=await act('updatePaths',null,after=>{if(!newAt(after)||!after.pathsUpdated)throw fail('paths_update_unverified');});
    if(s.mainRunning&&s.serverRunning)checkpoint('start','started');else await act('start','started',after=>{if(!newAt(after)||!after.mainRunning||!after.serverRunning||!after.pathsUpdated)throw fail('start_unverified');});
   }
   if(j.phase==='started')return await verify(j.plan.newIdentity);throw fail('invalid_phase');
  }catch(error){
   j.lastError={code:diagnosticName(error?.code)?error.code:'operation_failed',phase:j.phase,at:new Date().toISOString(),details:errorDetails(error)};j.status='recovery-required';persist();let restored=j.recovery?.completed===true;
   if(j.plan&&!restored&&!completedBefore){try{const s=await inspect();if(known(s)&&s.idle&&(!oldAt(s)||!s.mainRunning||!s.serverRunning||!s.pathsRestored))restored=await restore();}catch{j.status='recovery-required';persist();}}
   return {ok:false,phase:j.phase,status:j.status,transactionId:j.transactionId,error:j.lastError.code,recoveryRequired:true,restored};
  }
 }finally{try{release?.();}finally{releaseInstallation();}}
}
module.exports={run,PHASES};
