'use strict';
// Only complete, signed official Apps may supply executable upgrade APIs.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),cp=require('node:child_process');
const REPO='GitAaronW/citeside-releases';
const LEGACY=Object.freeze({version:'0.11.6',sourceSha:'d502421a07376ed2e48e91b1159b2897f3335dcc',sha256:'70467276b4faa883f4b1f7213e82a10b3320bb2c2619ed5121a1d5d6f1533712',bytes:213069277});
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const json=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const command=(file,args,options={})=>cp.execFileSync(file,args,{encoding:'utf8',timeout:120000,maxBuffer:8*1024*1024,stdio:['ignore','pipe','pipe'],...options});
function regular(root,relative,directory=false){if(path.isAbsolute(relative)||relative.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('invalid_artifact_path');let result=root;for(const part of relative.split('/')){result=path.join(result,part);const s=fs.lstatSync(result);if(s.isSymbolicLink())throw Error('artifact_symlink');}const stat=fs.statSync(result);if(directory?!stat.isDirectory():!stat.isFile())throw Error('invalid_artifact_type');return result;}
function signature(app,run){if(fs.lstatSync(app).isSymbolicLink()||!fs.statSync(app).isDirectory())throw Error('invalid_app');run('/usr/bin/codesign',['--verify','--deep','--strict','-R','=anchor apple generic and certificate leaf[subject.OU] = "234AZL4UWP" and identifier "com.citeside.app"',app]);}
function verifyApp(appPath,{version,sourceSha,deps={}}){
 const run=deps.command||command;appPath=path.resolve(appPath);signature(appPath,run);
 const program=regular(appPath,'Contents/Resources/program',true),identity=json(regular(program,'app/build-identity.json'));
 if(identity.commit!==sourceSha||json(regular(program,'package.json')).version!==version||json(regular(program,'version.json')).version!==version)throw Error('app_identity_mismatch');
 const manifest=json(regular(program,'compiled-modules.json'));
 if(manifest.schema!==2||manifest.sourceSha!==sourceSha||!manifest.runtimes||!Array.isArray(manifest.modules)||!manifest.modules.length)throw Error('manifest_identity_mismatch');
 const seen=new Set();for(const item of manifest.modules){if(typeof item.path!=='string'||! /^(app|scripts)\/.+\.js$/.test(item.path)||seen.has(item.path))throw Error('invalid_module_manifest');seen.add(item.path);if(hash(regular(program,item.path))!==item.loaderSha256)throw Error('module_hash_mismatch');for(const arch of ['arm64','x64'])if(hash(regular(program,item.path+'.jsc.'+arch))!==item.bytecodeSha256?.[arch])throw Error('module_hash_mismatch');}
 const arch=deps.arch||process.arch,expected=manifest.runtimes[arch];if(!expected||expected.arch!==arch||expected.platform!=='darwin')throw Error('runtime_manifest_mismatch');
 const roots=['Contents/Resources/runtime','Contents/Resources/program/runtime'].map(p=>path.join(appPath,p)).filter(p=>fs.existsSync(p));let runtime;
 for(const root of roots){if(fs.lstatSync(root).isSymbolicLink())throw Error('artifact_symlink');for(const name of fs.readdirSync(root)){if(!/^node-.+-darwin-(arm64|x64)$/.test(name)||!name.endsWith('-'+arch))continue;const binary=regular(root,name+'/bin/node');const actual=deps.probe?deps.probe(binary):JSON.parse(run(binary,['-e','console.log(JSON.stringify({node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch}))']));if(['node','v8','platform','arch'].every(k=>actual[k]===expected[k])){runtime=binary;break;}}if(runtime)break;}
 if(!runtime)throw Error('matching_runtime_missing');
 const capture=regular(program,'app/native-capture',true),helpers=fs.readdirSync(capture).filter(n=>n.endsWith('.app'));
 if(helpers.length!==1)throw Error('native_helper_missing');const nativeHelper=regular(capture,helpers[0],true);
 // Outer deep verification already covers the helper; verify independently as well.
 run('/usr/bin/codesign',['--verify','--deep','--strict',nativeHelper]);
 const launcher=fs.readFileSync(regular(appPath,'Contents/Resources/launcher.sh'),'utf8');
 const defaults=Array.from(launcher.matchAll(/^ROOT="\$\{[A-Z_]+:-\$HOME\/(Library\/Application Support\/[^"'\n$\\{}]+)\}"$/gm));
 if(defaults.length!==1||defaults[0][1].split('/').some(x=>!x||x==='.'||x==='..'))throw Error('launcher_default_root_unavailable');
 const dataRelativeRoot=defaults[0][1];
 return {appPath,program,runtime,sourceSha,nativeHelper,dataRelativeRoot,legacyDefaultRoot:home=>path.join(home,dataRelativeRoot)};
}
async function release(version){const url=`https://api.github.com/repos/${REPO}/releases/tags/v${version}`;const r=await fetch(url,{headers:{Accept:'application/vnd.github+json'},signal:AbortSignal.timeout(30000),redirect:'error'});if(!r.ok)throw Error('official_release_unavailable');return r.json();}
async function download(url,file){await new Promise((resolve,reject)=>{const p=cp.spawn('/usr/bin/curl',['--fail','--location','--retry','2','--proto','=https','--proto-redir','=https','--output',file,url],{stdio:'ignore'});p.once('error',reject);p.once('exit',code=>code===0?resolve():reject(Error('artifact_download_failed')));});}
function assetUrl(version,name){return `https://github.com/${REPO}/releases/download/v${version}/${name}`;}
async function acquireDmg({version,sourceSha,cacheDir,sha256,bytes,deps={}}){
 if(!/^\d+\.\d+\.\d+$/.test(version)||!/^[a-f0-9]{40}$/.test(sourceSha)||!/^[a-f0-9]{64}$/.test(sha256||''))throw Error('fixed_artifact_identity_required');
 const run=deps.command||command,dir=path.resolve(cacheDir||path.join(os.tmpdir(),'citeside-upgrade-artifacts'));fs.mkdirSync(dir,{recursive:true,mode:0o700});
 const name='Citeside-v'+version+'.dmg',file=path.join(dir,name),url=assetUrl(version,name);if(fs.existsSync(file)&&(fs.lstatSync(file).isSymbolicLink()||hash(file)!==sha256))throw Error('cached_artifact_hash_mismatch');
 if(!fs.existsSync(file)){const partial=path.join(dir,crypto.randomUUID()+'.part');try{await (deps.download||download)(url,partial);if(hash(partial)!==sha256||bytes!==undefined&&fs.statSync(partial).size!==bytes)throw Error('download_artifact_hash_mismatch');fs.renameSync(partial,file);}finally{fs.rmSync(partial,{force:true});}}
 if(bytes!==undefined&&fs.statSync(file).size!==bytes)throw Error('artifact_size_mismatch');
 const mount=fs.mkdtempSync(path.join(dir,'mount-'));let mounted=false;
 const cleanup=async()=>{if(mounted){await run('/usr/bin/hdiutil',['detach',mount]);mounted=false;}if(fs.existsSync(mount))fs.rmdirSync(mount);};
 try{await run('/usr/bin/hdiutil',['attach',file,'-readonly','-nobrowse','-mountpoint',mount]);mounted=true;const apps=fs.readdirSync(mount).filter(n=>n.endsWith('.app'));if(apps.length!==1)throw Error('full_app_required');const result=verifyApp(path.join(mount,apps[0]),{version,sourceSha,deps});fs.writeFileSync(path.join(dir,'verified-'+version+'.json'),JSON.stringify({version,sourceSha,sha256,bytes:fs.statSync(file).size,url,verifiedAt:new Date().toISOString()}),{mode:0o600});return {...result,cleanup};}catch(error){try{await cleanup();}catch{}throw error;}
}
async function acquireLegacy({appPath,cacheDir,deps={}}={}){if(appPath){try{const app=path.resolve(appPath);signature(app,deps.command||command);const program=regular(app,'Contents/Resources/program',true),version=json(regular(program,'package.json')).version,sourceSha=json(regular(program,'app/build-identity.json')).commit;if(!/^[a-f0-9]{40}$/.test(sourceSha)||!/^\d+\.\d+\.\d+$/.test(version)||version.split('.').reduce((n,p)=>n*1000+Number(p),0)>11006)throw Error('not_a_legacy_app');return {...verifyApp(app,{version,sourceSha,deps}),cleanup:async()=>{}};}catch{/* Replaced or unavailable old App: fixed complete official image only. */}}return acquireDmg({...LEGACY,cacheDir,deps});}
async function acquireIncoming({version,sourceSha,appPath,cacheDir,deps={}}={}){
 if(!/^\d+\.\d+\.\d+$/.test(version||'')||!/^[a-f0-9]{40}$/.test(sourceSha||''))throw Error('fixed_artifact_identity_required');
 if(appPath)return {...verifyApp(appPath,{version,sourceSha,deps}),cleanup:async()=>{}};
 const metadata=await (deps.release||release)(version);if(metadata.tag_name!=='v'+version||metadata.draft||metadata.prerelease||!Array.isArray(metadata.assets))throw Error('official_release_identity_mismatch');
 const name='Citeside-v'+version+'.dmg',assets=metadata.assets.filter(a=>a.name===name),asset=assets[0];
 if(assets.length!==1||asset.browser_download_url!==assetUrl(version,name)||!/^sha256:[a-f0-9]{64}$/.test(asset.digest||'')||!Number.isSafeInteger(asset.size)||asset.size<=0)throw Error('pinned_dmg_metadata_required');
 // The official tag/digest pins the complete image; its signed embedded commit
 // binds the requested source SHA before any bundled API or runtime can execute.
 return acquireDmg({version,sourceSha,cacheDir,sha256:asset.digest.slice(7),bytes:asset.size,deps});
}
module.exports={LEGACY,acquireLegacy,acquireIncoming,verifyApp};
