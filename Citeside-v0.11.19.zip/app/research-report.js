'use strict';
const {meetingClock}=require('./meeting-time');
// 会中研报（北极星，dev-intel 2026-10-23；设计见 side-session-notes/北极星_会中研报设计_dev-intel_20261023.md）。
// 会议进行中把转写累积成一篇研报：议题 → 发现（带网页来源）+ 待办（谁 / 做什么 / 何时 / 怎么算完）+ 待定问题。
// 模型每轮只回「补丁」，本机合并、校验、渲染 markdown；id 不变，界面上已有条目不跳。
// 联网只走已批的 ④（会中主动智能可联网、用高档模型）；检索词另过 insight-search 的去敏词表，多一道保险。
// 输出形状与北极星评测底座、live-report.setProvider 一致：{ markdown, items:[{text, sources, action:{do,owner,due}|null}] }。

const fs = require('fs'), path = require('path');
const tier = require('./meeting-tier');
const personalActions = require('./personal-actions');
const { normalizeActionDue, staleDue, normalizeDue, numericText, ownerName, anonymousOwner } = require('./research-quality');
const clip =(s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);
// 不在交付时腰斩句子或 URL；模型输入已有窗口限制，完整发现留给读者。
const cutAt = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
const completeUrl = u => { try { const url = new URL(u); return /^(?:https?:|memory:)$/.test(url.protocol) && !/…|\.\.\.|%[0-9a-f]?$/i.test(u); } catch (_) { return false; } };
// 只核对带计量语义的数字；日期、版本、编号、普通序数不构成参数断言。
function factNumbers(text, claims = false) {
  const t = numericText(String(text || '').replace(/(?:另|每|任|某)一(?=个|次|项|条)/g, '').replace(/https?:\/\/[^\s）)]+/g, '')
    .replace(/(?:20\d{2}[-/.年]\d{1,2}[-/.月]\d{1,2}日?|\d{1,2}月\d{1,2}日|(?:版本|版|v)\s*\d+(?:\.\d+)*)/gi, ''));
  const values = [...t.matchAll(/(?<![A-Za-z0-9.第])(\d+(?:[.,]\d+)?)(\s*(?:[%％]|万|亿|元|美元|人民币|台|部|辆|套|种|个|组|批|人|位|家|页|轮|次|箱|小时|分钟|毫秒|秒|天|GB|MB|KB|TB|TOPS|ms|mW|W|mAh|Wh|Hz|MHz|GHz|nm|mm|cm|kg|fps|倍|比))/gi)].map(m => ({number:m[1], text:m[0]}));
  // 无单位但有明确参数/价格语义，以及币种前缀和比例，也属于事实断言。
  for (const m of t.matchAll(/(?:比例|比值|配比)(?:为|是|约|[：:=])?([0-9]+):([0-9]+)|(?:售价|价格|销量|金额|参数值|分辨率|比例)(?:为|是|约|达到|[：:=])?([0-9]+(?:\.[0-9]+)?)|[$￥¥]([0-9]+(?:\.[0-9]+)?)/g)) {
    for (const n of m.slice(1).filter(Boolean)) values.push({number:n, text:m[0]});
  }
  return claims ? values : values.map(v => v.number);
}
const squash = s => String(s || '').replace(/[\s,，]/g, '');
const DUE_PHRASE = /(?:\d{4}-\d{1,2}-\d{1,2}|\d{1,2}月\d{1,2}[日号]?|\d{1,2}[\/.]\d{1,2}|\d{1,2}[日号]|(?:下{1,2}|这|本)?(?:周|星期|礼拜)[一二三四五六日天1-7]|大?后天|明天|今天|今晚|下班前?|月底|年底|[\d一二两三四五六七八九十]+天(?:后|内))/g;
const keyOf = s => String(s || '').replace(/[\s，。,.!！?？:：;；、"'“”‘’()（）*#>-]/g, '').toLowerCase();

const SYSTEM = `你在会议进行中维护一份研报，读者是会后要拍板的负责人。你收到：当前研报（JSON，带 id，含说话人角色表）、这一轮新增的会议转写（每句前是 [时间] 说话人）、上一轮的网页检索结果（编号 W1、W2…）、本项目台账里和这段转写相关的记载（编号 L1、L2…，是已确认的项目事实）、已经查过的检索词。
只回一个 JSON 对象，不要别的文字：
{"ops":[...], "queries":["..."]}
ops 可用：
- {"op":"add","topic":"议题名","text":"一条发现","basis":"会上|网页|推断","sources":["W1","L2"]}
- {"op":"update","id":"f3","text":"改后的发现","basis":"…","sources":["W2"]}
- {"op":"drop","id":"f3"}（仅有相同内容的保留项时删除；其他核验意见保留并标注）
- {"op":"open","text":"会上没结论、会后要确认的问题"}
- {"op":"close","id":"q1","evidence":"转写中逐字出现的结论"}
- {"op":"role","speaker":"1","role":"方案方负责人","side":"我方|对方|第三方"}（转写里说话人常只有编号：角色可推断但不得当人名；身份只接受转写里明确的自我介绍或指派，不能猜，后面可改。role 只写 ≤16 字的身份名词短语，不带时间戳、引文、「推断 / 待确认」字样；推断依据写进发现，不写进 role）
要求：
1. 每个议题形成「事实 → 机制（为什么、在什么条件下成立）→ 对本产品的含义（改变哪个判断、何时不适用）→ 行动（验证什么、怎样验收）」链。外部对照要比较原因与适用条件，不能只罗列产品参数；缺证据明确说未知，不为凑链编造因果、数字或承诺。不复述会议，不写常识；按信息需要写完整句子，不设数量或字数配额；台账里有相关记载的，末尾加一句「对项目：…」并引用 L 编号。
2. 会上说法的确定程度要照原样保留：只是提到、讨论、考虑、提议的，写成「会上在考虑 / 有人提议」，不能写成「已定 / 决定」；只有会上明确拍板的才写「已定」。「我们」指说话人所属的一方（看角色表），不要默认是我方。网页事实必须引用 W 编号；数字只能来自转写或你引用的检索结果，不要编。拿不准写成推断。
2b. 引述会上内容照转写原样：人名、产品名、数字、因果都不改写（转写像识别错的，原样写再加「（疑为 X）」）；会上给的原因不能换成你推断的原因，推断只能并列写并标「推断」。台账里的项目事实（产品名、内部项目）只能写在「对项目：…」里，不能写成会上有人说过，会上没人提到的项目产品不进正文。
3. 会上出现延期 / 推迟 / 改到 / 定了 / 取消这类状态变更，必须写成一条「会上」发现（写明谁说的、[时间]），不能只放进 open。台账记载与会上说法不一致时写「与台账记载（L 编号）不一致」，不替任何一方改口。
4. 新增发现要跟这一轮新增转写的话题走；老话题这一轮没人再提就不再扩展，除非是用检索结果坐实已有条目。同一论点不重复写，用 update 补充。
5. 待办不归你写（另有一步专门提取）；会上没结论的问题才写 open。先核对已有待定与本轮答案，已回答的用 close 并附 evidence（逐字原话），后续撤回或仍有条件则保留。basis=会上 的状态结论附 evidence 原话，禁止把建议改成承诺、条件句改成事实。外部研究以引用的外链为出处，evidence 不要求在转写里出现。未核实数字标注「数字待核实」，保留其余研究内容；未补到来源不能声称已核实。
6. 按实质议题组织，不设议题数量上限；没有新东西就回 {"ops":[],"queries":[]}。
7. queries 给 0–4 个下一轮要查的检索词，按这个优先级：① 这一轮转写新出现的产品 / 公司 / 标准 / 开源项目 / 模型名，用那个名字（加 官网、发布、评测、文档 等词）去核实，每个名字至少查一次，已查过的不重复；② 会上「没有 / 不存在 / 唯一 / 首个 / 最…」这类绝对化断言，去找反证，查到就把那条发现写成「半对 / 不成立，W 编号」，查不到写「无法核实」；③ 之后才是行业对比。只用技术名词、产品名、公开公司名，不要出现项目代号、内部人名、会议原句。`;

// 待办单独一步（总控 10-23：和研究放在同一次调用里会互相挤，v3 深度掉到 3）。每 3 轮研究跑一次，散会再跑一次。
const ACTIONS_SYSTEM = `你从会议转写里提取待办，读者是会后要逐条跟进的人。你收到：已有待办（带 id）、待定问题（带 id）、说话人角色表、新增转写（每句前是 [时间] 说话人）、会议日期和建议期限。
只回一个 JSON 对象：{"ops":[...]}
- {"op":"action","id":"已有待办的 id，新增就省略","do":"做什么（动词开头）","owner":"具体承诺人，统一使用会上明确出现的姓名；无姓名写待定负责人；仅明确集体承诺可写团队","due":"期限","done_when":"完成标准","from":"由哪条待定问题转来，可省略","said":"会上有人明确答应=true；是你根据讨论建议的=false"}
要求：
1. 会上有人答应去做、去确认、去回复、去提供的，每一件都写成一条（said=true），一条不漏。会上没人答应、但会后明显得有人跟的，才写建议（said=false）：按实际需要，只写会后要拍板的事，不写「说明一下 / 写一页解释」这种向演示者追问的题，也不写回听录音、核对转写这类关于转写本身的事；数字只能来自转写。同一件事只写一条，已有的用 id 更新。
2. 待定问题能落到某一方（会上答应过，或明显该由某一方回复）的，转成待办并带 from；落不到人的不要硬转。
3. due：保留会上期限原话，程序按会议日期在 Asia/Shanghai 换成绝对日期。已过期、无效或互相冲突的日期不得当作承诺期限，保留原话待确认；没说就写「建议 <给你的建议期限>」。done_when 未明确约定时用「建议：」开头，不冒充承诺。
4. done_when：写成可以核对的交付物，例如「发出 X 平台 INT8 与 INT4 的识别错误率对比表」。会上说了就照原话写。
4b. 每条 action 必须带 evidence（任务对应的完整逐字原句，不截去其他人的名字）、source_ref（原句 id）、background（动作对象及为何要做的一句背景，来自会议，不编）。do 自包含，不能写「看一下这个」。只有明确点名本人、原句明确收话人为本人的「你来」、或本人说「我来/我回头发」可算本人的任务。其他人的分工保留为会议待办；不从职位/相邻发言/你我代词猜归属。
5. 会上说已经做完、已经发出、已经确认的事不写成新待办；已有待办本轮明确全部完成时，回 {"op":"complete-action","id":"已有待办 id","evidence":"本轮新增转写中的完成原话"}。只完成一部分就按原 id 更新剩余工作；未提到的事项保持原状。
6. owner 只能使用已知参会人/说话人名单里的姓名；别名统一也必须匹配名单，不从自我介绍、拼音相似或职责猜人。同一角色对应多人时只用明确指派的人名，无人名写待定负责人，不写泛称「硬件侧」「产品」。没明确承诺的 said=false，期限或验收标准是建议时单独标明。会上没出现过的人或团队不能当负责人；明确的「X 你来 / 交给 X / X 负责」按所指任务写 X，不把发话人当作被指派人；答应的人只有编号就写「待定负责人」，不把说话人编号或推断角色当作姓名。待定问题本轮已有明确答案时回 {"op":"close","id":"q1","evidence":"逐字答案"}；提议、部分回答和撤回不能销项。没有新待办或答案就回 {"ops":[]}。`;

// 期限里的日期早于会议日（模型把「上周三」之类算错，或照抄旧日期）：不可能完成，改用建议期限。
// Use the meeting's Shanghai calendar day, independent of the host timezone.
const shanghaiDay = iso => {
  const t = Date.parse(iso);
  return Number.isFinite(t) ? new Date(t + 8 * 3600e3).toISOString().slice(0, 10) : '';
};
const addDays = (iso, n) => { const day = shanghaiDay(iso); return day ? new Date(Date.parse(day) + n * 864e5).toISOString().slice(0, 10) : ''; };

// 小窗卡片上的「深度研究」（MINI-01，2026-10-25）：用户点名一张卡片，对这一张单独跑一次研究，结果并进研报的「外部研究」一节。
// 四步对应小窗的「研究中 n/4」：① 定研究方向和检索词 ② 联网检索 ③ 写发现 ④ 并进研报（走同一个 apply / check：没来源降为推断、数字对不上标待核实）。
const CARD_TOPIC = '外部研究', CARD_STEPS = 4;
const CARD_PLAN_SYSTEM = `会议进行中，用户点了一张会中卡片要求深度研究。你收到：卡片原文、会上最近说的话、已经查过的检索词。
只输出 JSON：{"direction":"一句话：这次要查清什么","queries":["联网检索词",...]}。queries 1–4 条，每条是能直接搜的短语，写外部公开信息（产品、参数、价格、标准、公司公告），不写会议里的人名和内部代号。`;
const CARD_WRITE_SYSTEM = `每个研究议题串起事实 → 机制（为什么、成立条件）→ 对本产品的含义 → 可验收的行动；未知明确标注，不能只列竞品。引用或数字未补证时标注待核实并保留研究内容，不编因果或承诺。
会议进行中，用户点了一张会中卡片要求深度研究，你写研究结论，读者是会后要拍板的负责人。你收到：卡片原文、研究方向、网页检索结果（编号 W1、W2…）、本项目台账里相关的记载（编号 L1、L2…）。
只输出 JSON：{"ops":[{"op":"add","text":"一条发现：先结论，再给依据；最后半句写对我们意味着什么","basis":"网页|推断","sources":["W1"]}]}。1–4 条；每条有网页依据就引 W / L 编号、basis 写网页；没有依据写推断。数字只用检索结果里出现过的，不要自己补。`;

function parseJson(text) {
  const s = String(text || ''), a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b <= a) return null;
  try { return JSON.parse(s.slice(a, b + 1)); } catch (e) { return null; }
}

const mmss = sec => { const s = Math.max(0, Math.round(sec)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
// 两条发现是不是同一论点：去标点后的字二元组 Jaccard（金标准 10-24：回放里表盘读数 ≥8 条、网关价格 ≥5 条互相重复）。
const bigrams = s => { const k = keyOf(s), out = new Set(); for (let i = 0; i + 2 <= k.length; i++) out.add(k.slice(i, i + 2)); return out; };
function similar(a, b, min = 0.6) {
  const x = bigrams(a), y = bigrams(b); if (!x.size || !y.size) return false;
  let both = 0; for (const g of x) if (y.has(g)) both++;
  return both / (x.size + y.size - both) >= min;
}

// context(delta) → [{file, line, text}]：本项目台账里和这段转写相关的行（见 ledgerContext）；topicCap = 每个议题最多几条发现；
// gapSec = 转写两句间隔超过多少秒算断流（金标准 10-24：calendar 场断了 10 分钟，产品三种产出都没提）。
function createReport({ ask: modelAsk, search: webSearch, context, env = () => ({}), session = null, sessionId = '', dataDir = '', title = '', date = '', now = () => Date.now(), safeQuery = () => true, actionEvery = 3,
  minChars = 600, maxIdleMs = 90e3, minGapMs = 45e3, maxDeltaChars = 6000, topicCap = 8, gapSec = 120, suggestCap = 6, participants = [], selfNames = [], roleKeywords = [], draftContext, draftStateFile = '', actionsOnly = false, prepareDrafts = true, onFinding = null } = {}) {
  const roleOpts = { roleKeywords: [...(Array.isArray(roleKeywords) ? roleKeywords : []), ...(Array.isArray(selfNames && selfNames.roleKeywords) ? selfNames.roleKeywords : [])] };
  const st = {
    topics: [], findings: [], actions: [], open: [], roles: new Map(),   // roles: 说话人编号 → {role, side}（模型推断）
    seq: { f: 0, a: 0, q: 0, r: 0 }, jobs: new Map(),   // jobs: 卡片 id → 深度研究回执
    web: new Map(), webText: new Map(), webSeq: 0, fresh: [],   // fresh = 上一轮检索结果，下一轮喂给模型
    local: new Map(), localSeq: 0, localFresh: [], queried: [], entities: new Set(), claims: [],   // local: L 编号 → 台账行；queried: 已查过的检索词；entities: 见过的专名；claims: 已处理过的绝对化断言
    said: '', speakers: new Set(), pending: [], actionBuf: [], rounds: 0, pendingChars: 0, lastAt: null, inflight: null, calls: 0, failed: 0, version: 0,
    speech: [], originalRows: [],
    lastRowAt: null, span: ['', ''],   // span: 这一轮新增转写的起止时间，写进「会上」发现
  };

  // Scope each round/card independently; concurrent cards never share a mutable
  // current-task slot. Existing model adapters still execute every request.
  const shared = require('./meeting-work-state'), tasks = new (require('node:async_hooks').AsyncLocalStorage)();
  const settings = () => typeof env === 'function' ? env() : env || {};
  const runTask = (propositionId, run) => {
    const current = (typeof session === 'function' ? session() : session) || { id: sessionId, title, transcript: st.originalRows };
    const workState = shared.create({ dataDir, env: settings(), session: current,
      rules: { report: SYSTEM, actions: ACTIONS_SYSTEM, cardPlan: CARD_PLAN_SYSTEM, cardWrite: CARD_WRITE_SYSTEM } });
    return tasks.run({ trace: { workState, sessionId: current.id || sessionId, propositionId: propositionId || 'report-round:' + require('node:crypto').randomUUID(), operationId: require('node:crypto').randomUUID() }, pendingRemaining: st.pending.length, actionRemaining: st.actionBuf.length }, run);
  };
  const ask = (system, user, trace = {}) => modelAsk(system, user, { ...trace, ...(tasks.getStore()?.trace || {}) });
  const search = typeof webSearch === 'function' ? (query, options = {}) => {
    const task = tasks.getStore()?.trace;
    return webSearch(query, { ...options, ...(task || {}), ...(task ? { env: shared.environment(task.workState) } : {}) });
  } : null;

  const reviewKey=a=>keyOf(a.do+'|'+a.evidence);
  let reviews={};const reviewFile=draftStateFile?draftStateFile+'.reviews.json':'';
  if(reviewFile){try{reviews=JSON.parse(fs.readFileSync(reviewFile,'utf8'));}catch(_){}}
  const restoreReview=a=>{a.attributionReview=reviews[reviewKey(a)]||null;return a;};
  const drafts = require('./act-for-me').create({ask, context:draftContext, names:selfNames, rows:()=>st.originalRows, now, stateFile:draftStateFile});
  function feed(rows) {
    for (const r of rows || []) {
      const text = String(r && r.text || '').replace(/\s+/g, ' ').trim(); if (!text) continue;
      const raw = clip(r.speaker || r.name, 40), who = /^\d+$/.test(raw) ? '说话人' + raw : raw;
      if (raw) { st.speakers.add(raw); st.speakers.add(who); }
      st.speech.push(text); st.originalRows.push({ ...r, text });
      const at = Number(r.at), t = typeof r.t === 'string' && r.t ? r.t : Number.isFinite(at) ? mmss(at) : '';
      if (Number.isFinite(at)) {
        // 转写断流：两句之间隔太久，这段没有任何证据——写进待定并告诉模型，不让它把断流前后当成连贯讨论。
        if (st.lastRowAt != null && at - st.lastRowAt > gapSec) {
          const note = `转写断流约 ${Math.round((at - st.lastRowAt) / 60)} 分钟（${meetingClock(st.lastRowAt,date)||"时间未知"}→${meetingClock(at,date)||"时间未知"}）：这段没有证据，建议回听录音`;
          if (!st.open.some(q => keyOf(q.text) === keyOf(note))) { st.open.push({ id: 'q' + (++st.seq.q), text: note }); st.version++; }
          st.pending.push(`[${mmss(at)}] （${note}）`);
        }
        st.lastRowAt = at;
      }
      if (!st.span[0]) st.span[0] = t; if (t) st.span[1] = t;
      const line = (t ? `[${t}] ` : '') + (who ? who + '：' : '') + text;
      st.pending.push(line); st.actionBuf.push(line); st.pendingChars += text.length; st.said += '\n' + text;
    }
  }
  let finishing = null;
  function due() {
    if (finishing || st.inflight || !st.pendingChars) return false;
    if (st.lastAt == null) return st.pendingChars >= minChars;   // 第一轮也要攒够字：试音、报数的会一个字都没攒够就不该花一次 opus（Aaron 10-24「按难度和价值匹配 effort」）
    const gap = now() - st.lastAt;
    if (gap < minGapMs) return false;
    return st.pendingChars >= minChars || gap >= maxIdleMs;
  }

  const topicOf = name => {
    const t = clip(name, 40) || '其他', k = keyOf(t);
    if (k === keyOf(CARD_TOPIC)) return CARD_TOPIC;   // 卡片深度研究的专节：不占会中议题的 6 个名额
    st.topics = st.topics.filter(topic => st.findings.some(f => f.topic === topic));
    let hit = st.topics.find(x => keyOf(x) === k);
    if (!hit) { st.topics.push(t); hit = t; }
    return hit;
  };
  // W 编号 → 网址；L 编号 → 台账行（memory://文件#L行号，正文已放进 webText 供数字校验）。
  const resolve = refs => [...new Set((Array.isArray(refs) ? refs : []).map(r => { const k = String(r).trim().toUpperCase(); return st.web.get(k) || (st.local.get(k) || {}).ref; }).filter(completeUrl))];
  // 数字要整个对上：语料里的「13.5」不算支持「3.5」，「2026」不算支持「26」（peer_review a98e3694）。
  const hasNum = (corpus, n) => new RegExp('(?:^|[^\\d.])' + squash(n).replace(/[.]/g, '\\.') + '(?![\\d.])').test(corpus);
  // 模型偶尔把 W / L 编号写进正文（v11 评测 248 条里 128 条），来源已单独渲染成链接，正文里的编号既读不懂、又让「45」这类编号数字误触发待核实。
  // 抽出来并进来源，再删掉；模型自己写的「数字待核实」也删，只留 check() 的判定。
  const REF_IN_TEXT = /[\[【（(]\s*(?:[WL]\d+\s*[,，、;；/]?\s*)+[\]】）)]|(?<![A-Za-z0-9])[WL]\d+(?![A-Za-z0-9])/g;
  // finding id 由 'f' + seq.f 生成；只清理明确引用，避免误伤型号、光圈和英文单词。
  const FINDING_REF_IN_TEXT = /[\[【（(]\s*f\d+(?:\s*[,，、;；/]\s*f\d+)*\s*[\]】）)]|(?:参见|参考|见)\s*f\d+(?![A-Za-z0-9_]|\.\d)(?:\s*[,，、;；/]\s*f\d+(?![A-Za-z0-9_]|\.\d))*/g;
  function cleanText(text) {
    const refs = [];
    const out = String(text || '').replace(REF_IN_TEXT, m => {
      // Bare names such as L2 cache or W12 are also real terms/models in speech.
      if (/^[WL]\d+$/.test(m) && new RegExp('(?<![A-Za-z0-9])' + m + '(?![A-Za-z0-9])').test(st.said)) return m;
      refs.push(...(m.match(/[WL]\d+/g) || [])); return '';
    })
      .replace(/\[[^\]\n]*\]\((https?:\/\/[^)\s]*)\)/g, (m, u) => /…|\.\.\.|%[0-9a-f]?$/i.test(u) ? '' : m)
      .replace(/https?:\/\/[^\s<>）)]+/g, u => { try { const url = new URL(u); return /…|\.\.\.|%[0-9a-f]?$/i.test(u) || !url.hostname.includes('.') ? '' : u; } catch (_) { return ''; } })
      .replace(/(?:^|(?<=[。！？；;]))[^。！？；;]*?(?:…|\.{3})\s*$/g, '').replace(FINDING_REF_IN_TEXT, '').replace(/[（(]?\s*数字待核实\s*[）)]?/g, '').replace(/\s+([，。；、,.;])/g, '$1').replace(/[ \t]{2,}/g, ' ').trim();
    return { text: out, refs: refs.filter(r => st.web.has(r) || st.local.has(r)) };
  }
  // 本机硬校验：网页类没来源降为推断；数字既不在转写里、也不在所引来源摘要里，标待核实。
  function check(f) {
    if (f.basis === '网页' && !f.sources.length) f.basis = '推断';
    const corpus = numericText(st.said + ' ' + f.sources.map(u => (st.webText.get(u) || '')).join(' '));
    f.missingNumbers = [...new Set(factNumbers(f.text).filter(n => !hasNum(corpus, n)))];
    f.unverified = !!f.missingNumbers.length;
    const external = f.sources.some(u => /^(?:https?:\/\/|memory:\/\/)/i.test(u));
    f.relayed = f.basis === '会上' && external && !!f.evidence;
    f.evidenceInvalid = !external && !!f.evidence && !squash(st.said).includes(squash(f.evidence));
    if (f.basis === '会上' && /已定|已决定|已确认|已确定|已承诺|拍板/.test(f.text) && !squash(st.said).includes(squash(f.text))) {
      if (!f.evidence || /考虑|提议|建议|暂定|可能|不承诺|尚未|未定/.test(f.evidence)) f.evidenceInvalid = true;
    }
    return f;
  }
  // Names come only from the supplied roster or literal speaker labels, never sentence parsing.
  // 「张三（说话人1）」去掉括号保留张三；纯编号不进名单。
  const roster = () => [...participants, ...selfNames, ...st.speakers].map(n => String(n).replace(/[（(][^）)]*[）)]/g, '').trim()).filter(n => n && !anonymousOwner(n));
  const canonicalOwner = owner => {
    const name = ownerName(owner, roster());
    return name && /^(?:[\p{Script=Han}·]{2,8}|[A-Za-z][A-Za-z .'-]{0,39})$/u.test(name) &&
      !/[，。！？；：,!?;:\n]|(?:我来|我们|需要|负责|确认一下)|\b(?:I|we)\s+(?:will|need|should|can|am|are)\b/i.test(name) ? name : '';
  };
  const hasEvidence = evidence => !!String(evidence || '').trim() &&
    st.said.replace(/\s+/g, '').includes(String(evidence).replace(/\s+/g, ''));

  function checkAction(a) {
    a.missingNumbers = [...new Set(factNumbers(a.do+' '+a.doneWhen).filter(n=>!hasNum(numericText(st.said),n)))];
    a.unverified = !!a.missingNumbers.length;
    return a.said || !a.unverified;
  }

  function reportDeadline(raw, evidence, task = '') {
    // 没有会议日期时相对日期仍按当前时间解析，但不按会议日判过期。
    const meetingDate = date || new Date(now()).toISOString(), original = String(raw || '');
    // 只有会上原话给出的期限才算证据；模型补的「建议 …」日期不靠行动证据保留。
    const evidenced = !/^\s*建议/.test(original) && hasEvidence(evidence);
    // 期限本身也要有出处：原话里有这个期限，或行动原话里带时间词；否则不编期限（10-27 审核）。
    // 期限要绑定到这条行动：行动原话、或会上提到这件事的那一句里，出现这个期限或解析出同一天的时间说法（版本号不算）。
    const dueOf = text => normalizeDue(String(text).replace(/[一二两三四五六七八九十]+天后/g, m => numericText(m)), meetingDate).due;
    const states = line => { const l = String(line).replace(/(?:版本|版|v)\s*\d+(?:\.\d+)*|\d+(?:\.\d+)*\s*(?:版本|版)/gi, '');
      const day = String(dueOf(original)).slice(0, 10);
      return squash(line).includes(squash(original)) ||
        (l.match(DUE_PHRASE) || []).some(p => { const d = dueOf(p); return d && !/^(?:建议|待定)/.test(d) && d.slice(0, 10) === day; }); };
    const object = actionObject(task), whole = actionKey(task);
    const sourced = /^\s*建议/.test(original) || (evidenced && states(evidence)) ||
      (object.length >= 3 && st.said.split(/[。！？!?；;\n]/).some(line => keyOf(line).includes(whole.length > object.length ? whole : object) && states(line)));
    const unsourced = d => (d.due && !/^\s*建议/.test(d.due) && !sourced ? {...d, due:'', reason:'会上没说期限，已忽略'} : d);
    if (date && normalizeActionDue(original, date) !== original)
      return unsourced({due:evidenced ? original : '', raw:original, reason:evidenced ? '' : '截止早于会议日期，已忽略'});
    const absolute = original.replace(/(?:版本|版|v)\s*\d+(?:\.\d+)*|\d+(?:\.\d+)*\s*(?:版本|版)/gi, '');
    const deadline = normalizeDue(original.replace(/[一二两三四五六七八九十]+天后/g, m => numericText(m)), meetingDate);
    deadline.raw = original;
    // 有原话证据的明确过去期限原样保留；其余过期值不另编建议日期。
    if (!date && (deadline.reason === 'past' || staleDue(absolute, meetingDate))) { deadline.due = original; deadline.reason = ''; }
    else if (deadline.reason === 'past' || (!['unresolved','invalid','invalid-time'].includes(deadline.reason) && staleDue(absolute, meetingDate))) {
      deadline.due = evidenced ? original : '';
      deadline.reason = deadline.due ? '' : '截止早于会议日期，已忽略';
    }
    return unsourced(deadline);
  }
  const actionKey = text => keyOf(String(text || '').replace(/^(?:（建议，会上未定）|建议[：:]?|下一步[：:]?|需要|要)\s*/g, '').replace(/[。；;]+$/, ''));
  const ACTION_VERB = /^(?:开发|实现|完成|上线|发布|提供|发出|发送|整理|确认|验证|测试)/;
  const actionObject = text => { const key = actionKey(text); return key.slice((key.match(ACTION_VERB) || [''])[0].length); };
  function completed(a) {
    const key = actionKey(a.do), verb = (key.match(ACTION_VERB) || [''])[0];
    const object = key.slice(verb.length);
    if (object.length < 3) return false;
    // 「已支持 X」只说明功能在，不说明「测试 / 验证 X」做完了（10-27 审核）。
    // 测试 / 验证类必须说的是测试或验证本身做完了，「已完成 X 开发」不算（10-27 复审）。
    const done = /^(?:验证|测试)$/.test(verb) ? new RegExp('已(?:经)?(?:完成)?'+verb+'|'+verb+'(?:已(?:经)?)?(?:完成|通过)') :
      /已(?:经)?(?:完成|上线|实现|发布|发出|提供)|已(?:经)?(?:有|支持|具备)|现已|现有功能/;
    const evidence = [st.said, ...st.findings.filter(f => f.basis === '会上' && hasEvidence(f.text)).map(f => f.text), hasEvidence(a.evidence) ? a.evidence : ''].join('。');
    return evidence.split(/[。！？;；，,\n]/).some(line => !/尚未|还没|未完成|未上线|没有|部分|待|计划|准备|需要|下一步|要上线/.test(line) &&
      done.test(line) && keyOf(line).includes(object));
  }
  // 只交付模型给出的待办，去掉已完成的；不从正文句子补抽（10-27 评测：补抽出半句碎片，合格 3/9→0/9）。
  function bodyActions() {
    return st.actions.filter(a => !completed(a));
  }

  function apply(ops, completionDelta = '') {
    let changed = 0;
    for (const op of Array.isArray(ops) ? ops : []) {
      if (!op || typeof op !== 'object') continue;
      if (op.op === 'add') {
        const ct = cleanText(cutAt(op.text, 600)), text = ct.text; if (!text) continue;
        const sources = resolve([...(Array.isArray(op.sources) ? op.sources : []), ...ct.refs]);
        // 相同正文已有：不加新条，只把新来源并进去。
        const dup = st.findings.find(f => keyOf(f.text) === keyOf(text));
        if (dup) { const n = dup.sources.length; dup.sources = [...new Set([...dup.sources, ...sources])].slice(0, 8); if (dup.sources.length > n) { check(dup); changed++; } continue; }
        const topic = topicOf(op.topic);
        const span = st.roundSpan || [];
        const card = topic === CARD_TOPIC && op.card ? { card: clip(op.card, 64) } : {};
        st.findings.push(check({ evidence: op.evidence ? String(op.evidence).trim() : '', id: 'f' + (++st.seq.f), topic, text, basis: ['会上', '网页', '推断'].includes(op.basis) ? op.basis : '推断', sources, at: card.card ? '' : span[0] ? (span[1] && span[1] !== span[0] ? span[0] + '–' + span[1] : span[0]) : '', ...card }));
        changed++;
      } else if (op.op === 'role') {
        const speaker = clip(op.speaker, 20).replace(/^(?:说话人|发言人)\s*/, ''), role = roleText(op.role); if (!speaker || !role) continue;
        if (!st.speakers.has(speaker) && !st.speakers.has('说话人' + speaker)) continue;   // 没发过言的编号不能有角色（peer_review a98e3694）
        const side = ['我方', '对方', '第三方'].includes(op.side) ? op.side : '';
        const cur = st.roles.get(speaker); if (cur && cur.role === role && cur.side === side) continue;
        st.roles.set(speaker, { role, side }); changed++;
      } else if (op.op === 'update') {
        const f = st.findings.find(x => x.id === op.id); const ct = cleanText(cutAt(op.text, 600)), text = ct.text; if (!f || !text) continue;
        f.text = text; f.evidence = op.evidence ? String(op.evidence).trim() : ''; if (op.basis) f.basis = ['会上', '网页', '推断'].includes(op.basis) ? op.basis : f.basis;
        const src = resolve([...(Array.isArray(op.sources) ? op.sources : []), ...ct.refs]); if (src.length) f.sources = src;
        check(f); changed++;
      } else if (op.op === 'drop') {
        const f = st.findings.find(x => x.id === op.id);
        if (!f) continue;
        // A drop needs an explicit surviving duplicate. Semantic similarity alone is not proof.
        const kept = st.findings.find(x => x.id !== f.id &&
          keyOf(x.text) === keyOf(f.text));
        if (kept) { kept.sources = [...new Set([...kept.sources, ...f.sources])]; st.findings = st.findings.filter(x => x !== f); }
        else f.reviewNote = '核验建议删除，保留待核实';
        changed++;
      } else if (op.op === 'action') {
        const deadline = reportDeadline(op.due, op.evidence, op.do);
        const a = { do: cleanText(op.do).text, owner: canonicalOwner(clip(op.owner, 80)), said: typeof op.said === 'boolean' ? op.said : hasEvidence(op.evidence),
          evidence: clip(op.evidence, 600), sourceRef: clip(op.source_ref, 100), background: clip(op.background, 500),
          due: deadline.due, dueRaw: deadline.raw, dueIssue: deadline.reason,
          doneWhen: cleanText(op.done_when).text && !/^待定/.test(op.done_when) ? cleanText(op.done_when).text : '建议：书面回复「' + cleanText(op.do).text + '」的结论' };
        if (!a.do || completed(a)) continue;
        if (a.doneWhen && !st.said.includes(a.doneWhen) && !/^建议/.test(a.doneWhen)) a.doneWhen = '建议：' + a.doneWhen;
        if (!a.owner) a.owner = '待定负责人';
        // 建议类待办（会上没人答应）管住：全场最多 suggestCap 条；带转写和来源里都没有的数字的不要（金标准 10-24：mu4tzo 回放 40 条待办 39 条是建议，
        // 其中「7B INT4 约 3.5GB」这类数字是模型补的；判卷把它们算成无依据数字）。会上答应过的（said=true）不受这两条限制。
        if (!a.said && !st.actions.some(x => x.id === op.id)) {
          if (st.actions.filter(x => !x.said).length >= suggestCap) continue;
          const corpus = numericText(st.said + ' ' + [...st.webText.values()].join(' '));
          const nums = factNumbers(a.do + ' ' + a.doneWhen);   // 建议类连单个数字也要有出处
          if (nums.some(n => !hasNum(corpus, n))) continue;
        }
        checkAction(a);
        const hit = st.actions.find(x => x.id === op.id) || st.actions.find(x => actionKey(x.do) === actionKey(a.do));
        if (hit) Object.assign(hit, a); else st.actions.push({ id: 'a' + (++st.seq.a), ...a });
        changed++;
      } else if (op.op === 'complete-action') {
        // Only actionRound accepts completion, after checking evidence in this round's transcript.
        const evidence = clip(op.evidence, 600);
        if (!evidence || !completionDelta.includes(evidence)) continue;
        const n = st.actions.length; st.actions = st.actions.filter(a => a.id !== op.id); changed += n - st.actions.length;
      } else if (op.op === 'open') {
        const text = clip(op.text, 200); if (!text || st.open.some(q => keyOf(q.text) === keyOf(text))) continue;
        st.open.push({ id: 'q' + (++st.seq.q), text }); changed++;
      } else if (op.op === 'close') {
        const q = st.open.find(q => q.id === op.id);
        const evidence = String(op.evidence || '').trim();
        if (!q || !evidence || !hasEvidence(evidence)) continue;
        const n = st.open.length; st.open = st.open.filter(q => q.id !== op.id); changed += n - st.open.length;
      }
    }
    return changed;
  }

  const rolesForModel = () => [...st.roles].map(([speaker, r]) => ({ speaker, role: r.role, side: r.side }));
  function stateForModel() {
    return JSON.stringify({
      roles: rolesForModel(),
      participants: roster(),
      topics: st.topics.map(t => ({ topic: t, findings: st.findings.filter(f => f.topic === t).map(f => ({ id: f.id, text: f.text, basis: f.basis, status: check(f).evidenceInvalid ? '原话不匹配' : f.unverified ? '数字待核实，保留研究内容' : '可用', sources: f.sources })) })),
      actions: st.actions.map(a => ({ id: a.id, do: a.do, owner: a.owner, due: a.due, due_raw: a.dueRaw, said: a.said, done_when: a.doneWhen })),
      open: st.open,
    });
  }

  // 台账相关行编成 L 编号（同一行一个会议里只编一次），给模型引用；正文进 webText 供数字校验。
  function localRefs(delta) {
    let hits = []; try { hits = typeof context === 'function' ? context(delta, tasks.getStore() ? { ...tasks.getStore().trace, env: shared.environment(tasks.getStore().trace.workState) } : {}) || [] : []; } catch (e) { hits = []; }
    return hits.slice(0, 8).map(h => {
      const ref = `memory://${h.file}#L${h.line}`;
      let id = [...st.local].find(([, v]) => v.ref === ref)?.[0];
      if (!id) { id = 'L' + (++st.localSeq); st.local.set(id, { ref, text: clip(h.text, 300) }); st.webText.set(ref, clip(h.text, 1500)); }
      return { id, ref, text: clip(h.text, 300) };
    });
  }

  // 代码级兜底（peer_review a98e3694：优先级只写在提示里不算数）：这一轮转写里新出现的拉丁字母专名（Meta Muse Gadgets、ColorOS 17、
  // SM7750…）如果模型的 queries 一个都没覆盖，自动补一条核实查询排在最前。中文专名靠提示，这里不认。
  const ENTITY = /\b[A-Z][A-Za-z0-9]{2,}(?:[ -][A-Z0-9][A-Za-z0-9]{1,})*\b/g;
  const ENTITY_STOP = new Set(['The', 'This', 'That', 'And', 'But', 'What', 'How', 'Why', 'When', 'Okay', 'Yes', 'API', 'APP', 'App', 'Agent', 'Agents', 'Demo', 'Skill', 'Model', 'Phone', 'Email', 'Chat', 'Web', 'Cloud', 'Mac', 'PC', 'Google', 'Apple', 'Microsoft', 'Nothing']);
  // 角色只留第一小句的身份短语：模型爱把时间戳、引文、「推断，待确认」塞进 role，40 字硬截后判卷看到的是「…做进了 sk（我方）」（intel-v10）。
  function roleText(s) {
    let t = clip(s, 160).replace(/\[[^\]]{0,12}\]/g, ' ').replace(/[「」“”"'‘’]/g, '');   // 先去时间戳 [5:11] 和引号（peer_review c332a1b0）
    t = t.trim().replace(/^(?:[（(]?(?:推断|待确认|可能|应该是|大概是|疑似|猜测)[）)]?[，,：:、\s]*)+/, '');
    const parts = t.split(/[。；！？\n，,（(）)【】[\]]/).map(x => x.replace(/^[：:、\s]+|[：:、\s]+$/g, '')).filter(Boolean);
    t = parts[0] || '';   // 第一个非空小句；全是括注和时间戳就没有角色
    return t.length > 24 ? t.slice(0, 24).replace(/[，,、：:；;\s]+$/, '') + '…' : t;
  }
  function newEntities(delta) {
    const seen = new Map();
    for (const m of String(delta || '').match(ENTITY) || []) { const e = m.trim(); if (ENTITY_STOP.has(e) || e.length > 40) continue; seen.set(e, (seen.get(e) || 0) + 1); }
    return [...seen].filter(([e]) => !st.entities.has(e.toLowerCase())).sort((a, b) => b[1] - a[1]).map(([e]) => e);
  }
  // 绝对化断言（市面上没有 / 不存在 / 唯一 / 首个 / 最早…）：模型不一定按提示去查反证，代码兜底每轮最多补一条。
  // 口语里的「没有问题」「唯一的区别」不算断言；同一断言只查一次（bigram 相似即视为同一条）。
  const ABSOLUTE = /(?:市面上|业界|行业[里内]?|国内|国外|全球|世界上|目前|现在)(?:还?没有|不存在|没人|无人|没有人)|没有?(?:人|厂商|公司|家|别人)(?:做|在做|做过|能|会|有)|不存在|唯一(?!的?(?:问题|区别|差别|担心|风险|难点|麻烦|办法))|首个|首创|首款|第一[个家款批]|(?:全球|行业|业内|国内|世界)(?:首[个家款批]?|第一[个家款批]?|最早|最大)|最早|独家|只有我们|only one|first ever|first to|no one (?:has|does|is)|nobody (?:has|does|is)/i;
  const FILLER = /(?:我们|他们|你们|我方|对方|这个|那个|这种|那种|就是|其实|然后|所以|因为|但是|可能|应该|觉得|现在|目前|的话|这边|那边|一下|一个|一些|反正|肯定|基本上|来说|的时候|已经|还是|或者|而且|所谓|而言)/g;
  function counterQuery(delta, qs) {
    for (const raw of String(delta || '').split(/[。！？；\n]+/)) {
      const s = raw.replace(/^\[[^\]]*\]\s*/, '').replace(/^[^：]{1,20}：/, '').trim();
      const m = s.match(ABSOLUTE); if (!m) continue;
      // 只取断言所在的小句和下一小句（ASR 行常常没有句号，整行可能很长）
      const clauses = s.split(/[，,]/); let k = 0;
      for (let pos = 0; k < clauses.length - 1 && pos + clauses[k].length <= m.index; k++) pos += clauses[k].length + 1;
      const piece = clauses.slice(k, k + 2).join(' ');
      if (piece.length < 8) continue;
      const core = piece.replace(new RegExp(ABSOLUTE.source, 'gi'), ' ').replace(FILLER, ' ').replace(/[，,、“”"'‘’（）()：:【】[\]]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 50).trim();
      if (core.replace(/\s/g, '').length < 6) continue;
      const ok = safeQuery(core), base = ok === true ? core : typeof ok === 'string' ? ok : '';   // 带敏感名的先去名，去不干净就不查
      if (!base) continue;
      const query = base + ' 已有 先例';
      if (st.claims.some(c => similar(c, query))) continue;   // 同一断言只处理一次——不管上次是我们查的还是模型自己查的
      st.claims.push(query);
      if (st.queried.some(x => similar(x, query)) || qs.some(q => similar(q, query))) continue;   // 已经有人在查 → 不重复发
      return query;
    }
    return '';
  }
  function planQueries(queries, delta) {
    const qs = (Array.isArray(queries) ? queries : []).map(x => clip(x, 80)).filter(Boolean);
    const fresh = newEntities(delta);
    for (const e of fresh) st.entities.add(e.toLowerCase());
    const miss = fresh.find(e => safeQuery(e) === true && !qs.some(q => q.toLowerCase().includes(e.toLowerCase())) && !st.queried.some(q => q.toLowerCase().includes(e.toLowerCase())));
    // 优先级：① 新专名核实 ② 绝对化断言反证 ③ 模型自己的检索词；总数 ≤ 4
    const head = [miss ? miss + ' 发布 官网' : '', counterQuery(delta, qs)].filter(Boolean);
    return [...head, ...qs].slice(0, 4);
  }

  // 会上说话的人是内部人，不当外部实体去搜（v11：把同事名当公司查了一轮）。名字删掉后剩不到 2 个字就不查。
  function dropSpeakers(q) {
    let out = String(q || '');
    for (const n of [...st.speakers].filter(s => s && !/^\d+$/.test(s) && !/^(?:说话人|发言人)/.test(s) && s.length >= 2)) {
      out = out.replace(new RegExp(n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), ' ');
    }
    if (out === String(q || '')) return out;   // 没删到名字就原样
    out = out.replace(/\s+/g, ' ').trim();
    return out.replace(/[\s\p{P}]/gu, '').length >= 2 ? out : '';
  }
  async function runSearch(queries, options = {}) {
    const out = [];
    if (typeof search !== 'function') return out;
    for (const q of (Array.isArray(queries) ? queries : []).map(x => clip(x, 80)).filter(Boolean).slice(0, 4)) {
      const ok = safeQuery(q), query = dropSpeakers(ok === true ? q : typeof ok === 'string' ? clip(ok, 80) : '');
      if (!query || st.queried.some(x => keyOf(x) === keyOf(query))) continue;   // 查过的不再查
      st.queried.push(query);
      let rows = []; try { rows = await search(query, options); } catch (e) { if(String(e.code||'').startsWith('call_budget_'))throw e; rows = []; }
      for (const r of rankSources(rows).slice(0, 4)) {
        if (!r || !/^https?:\/\//i.test(r.url || '')) continue;
        const id = 'W' + (++st.webSeq); st.web.set(id, r.url); st.webText.set(r.url, clip(r.snippet, 1500));
        out.push({ id, title: clip(r.title, 120), url: r.url, snippet: clip(r.snippet, 600) });
      }
    }
    return out;
  }

  function takeWindow(queue, limit, remaining) {
    const batch=[]; let size=0;
    while(queue.length && (remaining === undefined || batch.length < remaining) && (!batch.length || size+queue[0].length<=limit)) {
      const line=queue.shift();batch.push(line);size+=line.length+1;
    }
    return batch;
  }

  function taskWindow(queue, limit, key) {
    const task = tasks.getStore(), batch = takeWindow(queue, limit, task?.[key]);
    if (task) task[key] -= batch.length;
    return batch;
  }

  async function round(finalPass) {
    if (actionsOnly) { st.pending=[]; st.pendingChars=0; st.lastAt=now(); const changed=await actionRound(); if(changed)st.version++; return !!changed; }
    // Extract and prepare personal work before slower meeting-wide research.
    if (selfNames.length && await actionRound()) st.version++;
    const batch = taskWindow(st.pending, maxDeltaChars, 'pendingRemaining');
    const delta = batch.join('\n'); st.pendingChars = st.pending.join('\n').length; st.lastAt = now();
    const local = delta ? localRefs(delta) : [];
    const user = [
      '会议：' + (title || '（无标题）'),
      '当前研报：' + stateForModel(),
      '新增转写：\n' + (delta || '（无）'),
      st.fresh.length ? '检索结果：\n' + st.fresh.map(w => `${w.id} ${w.title} ${w.url}\n${w.snippet}`).join('\n') : '检索结果：（无）',
      local.length ? '项目台账里相关的记载：\n' + local.map(l => `${l.id} ${l.ref.replace('memory://', '')} ${l.text}`).join('\n') : '',
      (() => { const n = [...st.speakers].filter(s => /^\d+$/.test(s)); const miss = n.filter(s => !st.roles.has(s)); return n.length ? `出现过的说话人编号：${n.join('、')}${miss.length ? '；还没有角色的：' + miss.join('、') + '（用 role 补上）' : ''}` : ''; })(),
      st.queried.length ? '已查过的检索词：' + st.queried.slice(-30).join('；') : '',
      finalPass ? '会议已结束：把「推断」里能用检索结果坐实的改成「网页」并引用；未核实数字必须标注待核实，保留研究内容；若仍需补核可给只含公开实体/指标的 queries，禁止内部人名、代号与会议原句。其余不再给 queries。' : '',
    ].filter(Boolean).join('\n\n');
    const times = batch.map(line => line.match(/^\[([^\]]+)\]/)?.[1]).filter(Boolean);
    st.roundSpan = times.length ? [times[0],times.at(-1)] : st.span.slice();
    const remainingTimes = st.pending.map(line=>line.match(/^\[([^\]]+)\]/)?.[1]).filter(Boolean);
    st.span = remainingTimes.length ? [remainingTimes[0],remainingTimes.at(-1)] : ['', ''];   // 本轮转写的起止时间给 apply 写进「会上」发现；下一批重新计时
    st.calls++;
    let j = null;
    try { j = parseJson(await ask(SYSTEM, user, { ...ROUTE, purpose: 'research-report' })); } catch (e) { j = null; }
    if (!j) {
      st.failed++; st.pending.unshift(...(delta ? [delta] : [])); st.pendingChars += delta.length;
      st.span = [st.roundSpan[0] || st.span[0], st.span[1] || st.roundSpan[1]];
      // Research failure must not prevent independent promise extraction at the end.
      if (finalPass && await actionRound()) st.version++;
      return false;
    }
    const known = new Set(st.findings.map(f => f.id));
    let changed = apply(j.ops);
    // 会中的新外部发现递给编辑判断是否弹卡；研报本身不受影响。
    if (!finalPass && onFinding) for (const f of st.findings) if (!known.has(f.id) && f.basis === '网页' && f.sources.length && !f.unverified) try { onFinding(f); } catch (e) {}
    if (finalPass && st.findings.some(f => check(f).unverified) && Array.isArray(j.queries) && j.queries.length) {
      // One bounded verification pass, through the same scrubbed search channel.
      const web = await runSearch(planQueries(j.queries, ''));
      if (web.length) {
        st.calls++;
        let verified = null;
        try { verified = parseJson(await ask(SYSTEM, [
          '会议：' + (title || '（无标题）'),
          '当前研报：' + stateForModel(),
          '收口补核：只按以下来源更新待核实发现并引用 W 编号；查不到仍待核实，不编、不升级为结论，不再检索。',
          '检索结果：\n' + web.map(w => `${w.id} ${w.title} ${w.url}\n${w.snippet}`).join('\n'),
        ].join('\n\n'), { ...ROUTE, purpose: 'research-report-verify' })); } catch (e) {}
        if (verified) changed += apply((Array.isArray(verified.ops) ? verified.ops : []).filter(o => o && ['update','drop'].includes(o.op)));
        else st.failed++;
      }
      st.fresh = [];
    } else st.fresh = finalPass ? [] : await runSearch(planQueries(j.queries, delta));
    st.rounds++;
    if (finalPass || st.rounds % actionEvery === 0) changed += await actionRound();
    if (changed) st.version++;
    return changed > 0;
  }

  async function actionRound() {
    const delta = taskWindow(st.actionBuf, maxDeltaChars * 2, 'actionRemaining').join('\n');
    if (!delta && !st.open.length) return 0;
    const user = [
      '会议：' + (title || '（无标题）') + '；会议日期 ' + shanghaiDay(date || new Date(now()).toISOString()) + '；建议期限 ' + addDays(date || new Date(now()).toISOString(), 3),
      '已有待办：' + JSON.stringify(st.actions.map(a => ({ id: a.id, do: a.do, owner: a.owner, due: a.due, done_when: a.doneWhen, said: a.said }))),
      '待定问题：' + JSON.stringify(st.open),
      '已知姓名名单：' + JSON.stringify(roster()),
      '会议使用者本人姓名：' + JSON.stringify(selfNames),
      '原句定位：' + JSON.stringify(st.originalRows.filter(r=>delta.includes(r.text)).map(r=>({id:r.segId||r.id||'',speaker:r.speaker||r.name,text:r.text}))),
      '说话人角色表（推断）：' + JSON.stringify(rolesForModel()),
      '新增转写：\n' + (delta || '（无）'),
    ].join('\n\n');
    st.calls++;
    let j = null;
    try { j = parseJson(await ask(ACTIONS_SYSTEM, user, { ...ROUTE, purpose: 'research-report-actions' })); } catch (e) { j = null; }
    if (!j) { st.failed++; if (delta) st.actionBuf.unshift(delta); return 0; }
    const changed = apply((Array.isArray(j.ops) ? j.ops : []).filter(o => o && ['action', 'complete-action', 'close'].includes(o.op)), delta);
    for (const a of st.actions) { restoreReview(a); if (prepareDrafts && personalActions.classify(a,st.originalRows,selfNames,roleOpts).group==='mine') await drafts.prepare(a); }
    return changed;
  }

  // 有新内容且到时机才跑一轮；同一时间只有一轮。返回 true = 研报变了。
  async function refresh() {
    if (!due()) return false;
    st.inflight = runTask(null, () => round(false));
    try { return await st.inflight; } finally { st.inflight = null; }
  }
  // 卡片深度研究：同一张卡片已受理 / 在跑 / 已完成就回原回执，失败的可以重点。回执立即返回（state=accepted），研究在后台跑。
  const jobView = j => j ? { jobId: j.jobId, cardId: j.cardId, state: j.state, step: j.step, total: CARD_STEPS, added: j.added, direction: j.direction || '', error: j.error || '' } : null;
  function research({ cardId, text } = {}) {
    const id = clip(cardId, 64), card = clip(text, 600);
    if (!id || !card) return null;
    const cur = st.jobs.get(id);
    if (cur && cur.state !== 'failed') return jobView(cur);
    const job = { jobId: 'r' + (++st.seq.r), cardId: id, text: card, state: 'accepted', step: 0, added: 0, direction: '', error: '' };
    st.jobs.set(id, job);
    const view = jobView(job);
    job.promise = new Promise(r => setImmediate(r)).then(() => runTask(job.cardId, () => runCard(job))).catch(e => { job.state = 'failed'; job.error = clip(e && e.message || e, 200) || 'failed'; });
    return view;
  }
  async function runCard(job) {
    job.state = 'running'; job.step = 1;
    const said = st.said.slice(-1500).trim();
    st.calls++;
    let plan = null;
    try { plan = parseJson(await ask(CARD_PLAN_SYSTEM, ['会议：' + (title || '（无标题）'), '卡片：' + job.text, '会上最近说的：\n' + (said || '（无）'), st.queried.length ? '已查过的检索词：' + st.queried.slice(-30).join('；') : ''].filter(Boolean).join('\n\n'), { ...ROUTE, purpose: 'research-card-plan' })); } catch (e) { plan = null; }
    if (!plan) { st.failed++; throw Error('研究方向没定下来（模型无回应）'); }
    job.direction = clip(plan.direction, 200);
    job.step = 2;
    const web = await runSearch(Array.isArray(plan.queries) ? plan.queries : [], {propositionId:job.cardId});
    job.step = 3;
    const local = localRefs(job.text + '\n' + job.direction);
    st.calls++;
    let out = null;
    try { out = parseJson(await ask(CARD_WRITE_SYSTEM, [
      '会议：' + (title || '（无标题）'), '卡片：' + job.text, '研究方向：' + (job.direction || '（同卡片）'),
      web.length ? '检索结果：\n' + web.map(w => `${w.id} ${w.title} ${w.url}\n${w.snippet}`).join('\n') : '检索结果：（无）',
      local.length ? '项目台账里相关的记载：\n' + local.map(l => `${l.id} ${l.ref.replace('memory://', '')} ${l.text}`).join('\n') : '',
    ].filter(Boolean).join('\n\n'), { ...ROUTE, purpose: 'research-card-write' })); } catch (e) { out = null; }
    if (!out) { st.failed++; throw Error('研究结论没写出来（模型无回应）'); }
    job.step = 4;
    const ops = (Array.isArray(out.ops) ? out.ops : []).filter(o => o && o.op === 'add').map(o => ({ ...o, topic: CARD_TOPIC, card: job.cardId }));
    apply(ops);
    // 完成 = 至少一条带可核实来源的发现并入；只有未核实的照样留在研报里（标未核实），但卡片算失败、可重试。
    job.added = st.findings.filter(f => f.card === job.cardId && cardShown(f) && f.sources.length > 0).length;
    if (!job.added) throw Error(web.length ? '检索到了，但没有带可核实来源的新发现，没并进研报' : '没检索到可用结果，没并进研报');
    st.version++; job.state = 'done';
  }
  // 无来源研究同样保留，展示时标注未核实。
  const cardShown = f => f.topic === CARD_TOPIC && !!check(f);
  const cardStatus = cardId => jobView(st.jobs.get(clip(cardId, 64)));
  const cardsSettled = () => Promise.all([...st.jobs.values()].map(j => j.promise).filter(Boolean)).catch(() => {});
  // 「外部研究」一节：按卡片分组，每组标题是卡片原文（截短）。
  function cardSection() {
    // 正文保留研究及其未核实标记；待核实区只列具体疑点。
    const got = st.findings.filter(cardShown), items = [], lines = [];
    if (!got.length) return { items, lines };
    lines.push('', '## ' + (got.some(f => f.sources.length && !f.evidenceInvalid) ? CARD_TOPIC : '研究（未核实）'));
    const groups = [...st.jobs.values()].map(j => ({title: cutAt(j.text, 60), findings: got.filter(f => f.card === j.cardId)}));
    // The model may use the external-research topic without a card job. Keep those findings too.
    groups.push({title: '', findings: got.filter(f => !st.jobs.has(f.card))});
    for (const group of groups) {
      if (!group.findings.length) continue;
      if (group.title) lines.push('', '### ' + group.title);
      for (const [index, f] of group.findings.entries()) {
        if (index === topicCap) lines.push('', '### 更多');
        lines.push('- ' + f.text + (f.sources.length ? ' ' + f.sources.map((u, i) => u.startsWith('memory://') ? `[台账 ${u.slice(9)}]` : `[${i + 1}](${u})`).join(' ') : '') + (f.basis === '推断' ? '（推断）' : '') + findingNote(f));
        items.push({ text: f.text + findingNote(f), sources: f.sources.slice(0, 5), action: null, unverified: f.unverified || !f.sources.length || f.evidenceInvalid, basis: f.basis, topic: CARD_TOPIC, card: f.card || '', at: '' });
      }
    }
    return { items, lines };
  }

  function finish() {
    if (finishing) return finishing;
    finishing = (async () => {
      if (st.inflight) { try { await st.inflight; } catch (e) {} }
      await cardsSettled();
      const failedBefore = st.failed;
      do {
        st.inflight = runTask(null, () => round(true));
        try { await st.inflight; } finally { st.inflight = null; }
        // Keep failed input for a later retry; never spin on a failing dependency.
        if (st.failed > failedBefore) return { ...snapshot(false), incomplete: true };
      } while (st.pending.length || st.actionBuf.length);
      return snapshot(true);
    })().finally(() => { finishing = null; });
    return finishing;
  }

  // Anonymous speaker IDs and inferred roles are not human assignees.
  function ownerView(o) { return canonicalOwner(o) || '待定负责人'; }
  // 待定问题按会上讨论热度排（问题里的字二元组在转写里出现的次数），研报只列前 OPEN_SHOWN 条，其余给个数。
  const OPEN_SHOWN = 10;
  function rankedOpen() {
    const said = squash(st.said), counts = new Map();
    for (let k = 0; k + 2 <= said.length; k++) { const word = said.slice(k, k + 2); counts.set(word, (counts.get(word) || 0) + 1); }
    const heat = q => {
      const h = squash(q.text).replace(/^谁来：?/, ''); let n = 0;
      for (let k = 0; k + 2 <= h.length; k++) n += counts.get(h.slice(k, k + 2)) || 0;
      return n / Math.max(1, h.length - 1);
    };
    return st.open.map((q, i) => ({ q, i, h: heat(q) })).sort((a, b) => b.h - a.h || a.i - b.i).map(x => x.q);
  }

  function findingNote(f) {
    return (f.relayed ? '（转述）' : '') + (f.unverified ? '（数字待核实）' : '') +
      (!f.sources.length || f.evidenceInvalid ? '（未核实）' : '') + (f.reviewNote ? '（' + f.reviewNote + '）' : '');
  }

  function snapshot(final = false) {
    const items = [];
    // Preserve every finding; annotate missing evidence instead of hiding it.
    const shown = f => !!check(f);
    for (const a of st.actions) { const canonical = canonicalOwner(a.owner); if (canonical) a.owner = canonical; }
    const actions = bodyActions().map(a => { checkAction(a); return restoreReview(a); });
    const grouped = personalActions.groupActions(actions,st.originalRows,selfNames,roleOpts);
    const myActions = grouped.myActions.map(a=>({...a,draft:drafts.view(a.id)}));
    const {possibleActions,allActions} = grouped;
    const src = u => u.startsWith('memory://') ? `[台账 ${u.slice(9)}]` : '';
    for (const f of st.findings) if (shown(f) && f.topic !== CARD_TOPIC) items.push({ text: f.text + findingNote(f), sources: f.sources.slice(0, 5), action: null, basis: f.basis, topic: f.topic, at: f.at || '' });
    for (const a of actions) items.push({ id: a.id, group:allActions.find(x=>x.id===a.id)?.group, background:a.background, mine: myActions.some(m=>m.id===a.id), draft: myActions.find(m=>m.id===a.id)?.draft || null, text: (a.said ? '' : '（建议，会上未定）') + a.do + (a.unverified ? '（数字待核实）' : '') + ' @' + ownerView(a.owner) + ' · 完成标准：' + a.doneWhen, sources: [], action: { do: a.do, owner: myActions.find(m=>m.id===a.id)?.owner || ownerView(a.owner), due: a.due === '待定' ? '' : a.due, due_raw: a.dueRaw, due_issue: a.dueIssue, said: a.said, done_when: a.doneWhen } });
    const lines = ['# ' + (title || '会中研报')];
    // 说话人角色表和转写时间只给模型用，不进研报正文（Aaron 10-25：信噪比优先；大众版没有身份识别）。
    let section = 0;
    st.topics.forEach(t => {
      const fs = st.findings.filter(f => f.topic === t && shown(f)); if (!fs.length) return;
      lines.push('', '## ' + (++section) + '. ' + t);
      for (const [index, f] of fs.entries()) { if (index === topicCap) lines.push('', '### 更多'); lines.push('- ' + f.text + (f.sources.length ? ' ' + f.sources.map((u, i) => src(u) || `[${i + 1}](${u})`).join(' ') : '') + (f.basis === '推断' ? '（推断）' : '') + findingNote(f)); }
    });
    const cards = cardSection(); items.push(...cards.items); lines.push(...cards.lines);
    if (myActions.length) { lines.push('', '## 我的待办'); for (const a of myActions) { lines.push('- ' + a.do + ' — ' + a.background); if(a.draft) {lines.push('  '+a.draft.label); if(a.draft.status==='ready')lines.push('',a.draft.versions.at(-1).markdown);} } }
    if (possibleActions.length) { lines.push('', '## 可能是你'); for(const a of possibleActions) lines.push('- '+a.do+' — 负责人：未指定'); }
    if (actions.length) { lines.push('', '## 全量清单（会议待办）', '| 任务 | 负责人 | 截止 | 完成标准 |', '|---|---|---|---|'); for (const a of actions) lines.push('| '+(a.said?'':'（建议，会上未定）')+a.do.replace(/\|/g,'\\|')+(a.unverified?'（数字待核实）':'')+' | '+(allActions.find(x=>x.id===a.id).owner || '未指定')+' | '+a.due+' | '+a.doneWhen+' |'); }
    if (st.open.length) {
      const qs = rankedOpen(); lines.push('', '## 待定');
      for (const q of qs.slice(0, OPEN_SHOWN)) lines.push('- ' + q.text);
      if (qs.length > OPEN_SHOWN) lines.push('- 另有 ' + (qs.length - OPEN_SHOWN) + ' 条讨论较少的待定问题');
    }
    const pendingVerification = [], seenVerification = new Set();
    const pending = (id, text, reason, sources = []) => {
      const key = keyOf(text); if (!key || seenVerification.has(key)) return;
      seenVerification.add(key); pendingVerification.push({id, text, status:'待核实', reason, sources});
    };
    for (const f of st.findings) {
      check(f);
      if (f.missingNumbers.length) for (const v of factNumbers(f.text, true).filter(v => f.missingNumbers.includes(v.number))) pending(f.id, '数字「' + v.text + '」', '缺少来源依据', f.sources);
      else if (f.evidenceInvalid || f.reviewNote || (!f.sources.length && f.basis !== '会上')) {
        // 每条仅定位原句；不把整段研究分析复制到待核实区。
        const quote = f.text.split(/[。！？；;，,]/)[0];
        if (quote) pending(f.id, '「' + quote + '」', f.reviewNote || (f.evidenceInvalid ? '原话不匹配' : '缺少来源，未核实'), f.sources);
      }
    }
    for (const a of actions) for (const v of factNumbers(a.do + ' ' + a.doneWhen, true).filter(v => a.missingNumbers.includes(v.number))) pending(a.id, '数字「' + v.text + '」', '待办数字缺少会议依据');
    if (pendingVerification.length) {
      lines.push('', '## 待核实');
      for (const f of pendingVerification) lines.push('- ' + f.text + '（' + f.reason + '）');
    }
    return { researchJobs: [...st.jobs.values()].map(jobView), markdown: lines.join('\n'), items, selfNames, myActions, possibleActions, allActions, actForMeIncomplete:myActions.some(a=>a.draft?.status==='failed'), participants: roster(), pendingVerification, version: st.version, final: !!final, calls: st.calls, failedCalls: st.failed };
  }

  async function reviewAction(id,decision) {
    if(decision==='claim'&&!selfNames.length)throw Error('请先配置本人姓名');
    const a=st.actions.find(a=>a.id===id);
    if(!a || !['claim','dismiss'].includes(decision)) throw Error('无效待办或操作');
    if(personalActions.classify({...a,attributionReview:null},st.originalRows,selfNames,roleOpts).group==='all') throw Error('他人任务不能作为可能是你认领');
    reviews[reviewKey(a)]={decision};
    if(reviewFile){fs.mkdirSync(path.dirname(reviewFile),{recursive:true});require('./durable-json').write(reviewFile,reviews);}
    restoreReview(a); st.version++;
    if(decision==='claim') await drafts.prepare(a);
    return snapshot();
  }
  return { reviewAction, setActionsOnly:value=>{actionsOnly=!!value;}, feed, due, refresh, finish, snapshot, apply, research, cardStatus, cardsSettled, cardSection, _state: st };
}

// 检索词去敏（④ 允许带本地资料联网，这一步是多加的保险）：命中代号 / 内部人名时把那几个词删掉再搜，不整条丢掉，
// 免得为去敏把检索做弱（总控 10-23）。删完剩不到 2 个字才放弃。
// 来源分级（v11 评测：csdn / 知乎 / 百科类撑起的结论被评审打低分）。官方、标准、论文、厂商文档排前；
// 域名只影响顺序，不证明某条材料是否直接证据；不能因已有两个高层域名删除原始访谈、作者实测或维护者回复。
const HIGH_SRC = /(?:^|\.)(?:arxiv\.org|ieee\.org|acm\.org|3gpp\.org|w3\.org|ietf\.org|iso\.org|nature\.com|sciencedirect\.com|qualcomm\.com|apple\.com|android\.com|google\.com|googleblog\.com|microsoft\.com|anthropic\.com|claude\.com|openai\.com|meta\.com|samsung\.com|mediatek\.com|arm\.com|nvidia\.com|gsma\.com|idc\.com|counterpointresearch\.com|canalys\.com|gartner\.com|reuters\.com|bloomberg\.com|theverge\.com|gsmarena\.com|notebookcheck\.net|anandtech\.com|huggingface\.co|gov\.cn|gov)$/i;
const LOW_SRC = /(?:^|\.)(?:csdn\.net|zhihu\.com|sohu\.com|baike\.baidu\.com|baidu\.com|toutiao\.com|163\.com|qq\.com|smzdm\.com|bilibili\.com|douyin\.com|xiaohongshu\.com|medium\.com|dev\.to|youtube\.com|taobao\.com|jd\.com|javaguide\.cn|deepwiki\.com|jianshu\.com|cnblogs\.com|51cto\.com|juejin\.cn|quora\.com|reddit\.com)$/i;
function sourceTier(url) {
  const h = (String(url || '').match(/^https?:\/\/([^/:?#]+)/i) || [])[1] || '';
  return HIGH_SRC.test(h) ? 2 : LOW_SRC.test(h) ? 0 : 1;
}
function rankSources(rows) {
  const ok = (Array.isArray(rows) ? rows : []).filter(r => r && /^https?:\/\//i.test(r.url || ''));
  const ranked = ok.map((r, i) => ({ r, i, t: sourceTier(r.url) })).sort((a, b) => b.t - a.t || a.i - b.i);
  return ranked.map(x => x.r);
}

function softenQuery(q, names = []) {
  const isearch = require('./insight-search');
  if (isearch.isSafeQuery(q, names)) return true;
  let out = String(q || '');
  for (const t of ['chansey', '26191', 'nothing', 'moneta', '歌尔', 'goertek', ...names]) {
    const v = String(t || '').trim(); if (v.length < 2) continue;
    out = out.replace(new RegExp(v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), ' ');
  }
  out = out.replace(/\s+/g, ' ').trim();
  return out.replace(/[\s\p{P}]/gu, '').length >= 2 && isearch.isSafeQuery(out, names) ? out : false;
}

// 项目台账的本地检索（金标准 10-24：三场会的产品产出 0 次引用 .memory 台账）。读 ledger_*.md 与 project-state.md 的每一行，
// 按「字二元组 + 英文词」和这一轮转写的重合度打分（稀有词权重高），回最相关的几行给模型当 L 编号引用。
// 不走模型、不上云；目录不存在就什么都不回。
const LEDGER_FILE = /^(ledger_.*|project-state)\.md$/;
// 口语里满篇的虚字（我们 / 这个 / 然后…）不算内容词：含这些字的二元组不计分，免得长行靠虚字堆分。
const STOP = new Set('的了是这那个们我你他她它有没不在就也都说要会可以和与把被吗呢吧啊嗯然后什么怎样为什因所但而且或者如果还很太再又才能够对于到从去来做给让用多少些点儿着过了好吧呀哦'.split(''));
const tokensOf = s => {
  const out = new Set();
  for (const w of String(s || '').toLowerCase().match(/[a-z][a-z0-9+.-]{2,}|\d{3,}/g) || []) out.add(w);
  for (const run of String(s || '').match(/[一-鿿]{2,}/g) || []) for (let i = 0; i + 2 <= run.length; i++) { const g = run.slice(i, i + 2); if (!STOP.has(g[0]) && !STOP.has(g[1])) out.add(g); }
  return out;
};
// 每行只记最稀有的 5 个重合词，长行不能靠数量堆分。
function ledgerContext(dir, { max = 6, minScore = 14, perLine = 240, topK = 5 } = {}) {
  let index = null;
  const load = () => {
    const fs = require('fs'), path = require('path'), lines = [], df = new Map();
    let files = []; try { files = fs.readdirSync(dir).filter(f => LEDGER_FILE.test(f)).sort(); } catch (e) { files = []; }
    for (const file of files) {
      let text = ''; try { text = fs.readFileSync(path.join(dir, file), 'utf8'); } catch (e) { continue; }
      text.split('\n').forEach((raw, i) => {
        const t = raw.replace(/^[\s>#*|-]+/, '').replace(/\s*\|\s*/g, ' ').trim();
        if (t.length < 12 || /^[-:| ]+$/.test(t)) return;
        const tok = tokensOf(t); for (const k of tok) df.set(k, (df.get(k) || 0) + 1);
        lines.push({ file, line: i + 1, text: clip(t, perLine), tok });
      });
    }
    return { lines, df };
  };
  return function (delta) {
    if (!index) index = load();
    const { lines, df } = index; if (!lines.length) return [];
    const q = tokensOf(delta), n = lines.length, scored = [];
    for (const l of lines) {
      const w = []; for (const k of l.tok) if (q.has(k)) w.push(Math.log(n / df.get(k)));
      if (w.length < 2) continue;
      const score = w.sort((a, b) => b - a).slice(0, topK).reduce((s, x) => s + x, 0);
      if (score >= minScore) scored.push({ score, l });
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, max).map(({ l }) => ({ file: l.file, line: l.line, text: l.text }));
  };
}
function ledgerDir(env, dataDir) {
  try {
    const cp = require('./context-pack'), config = require('./config');
    return cp.memoryProjectionDir(dataDir || (typeof config.dataDir === 'function' ? config.dataDir() : config.dataDir), env);
  } catch (e) { return ''; }
}

// live-report.setProvider 用：GET /live-report 时同步返回当前快照，顺手把新句子喂进去、异步触发一轮。
// 不在会中管线里加钩子，不改 native-meeting.js。makeDeps(sess) → {ask, search, safeQuery}。
// 分档（meeting-tier.js，Aaron 2026-10-24「按 task 难度和对用价值匹配 effort 和等待时间」）：有新句子就重算档位，只升不降；
// 升到 deep 那一刻才建研报器，skip / light 一次模型调用都不花。档位写回 sess.tier（server.js 落盘 sess 时顺带存下，
// UI 读它显示「深度分析 · 预计 N 秒」）；sess.tier.override（本场手动）> 设置 MEETING_TIER > 自动，手动改成 light 即撤回。
// 收尾稿落盘：散会后重启也能看到成形的研报。dataDir/live-reports/<id>.json，只存快照，不存转写。
function finalPath(dataDir, id) { return dataDir ? path.join(dataDir, 'live-reports', String(id).replace(/[^\w.-]/g, '_') + '.json') : ''; }
function loadFinal(dataDir, id) { const f = finalPath(dataDir, id); if (!f) return null; try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); return j && Array.isArray(j.items) ? j : null; } catch (e) { return null; } }
function saveFinal(dataDir, id, snap) {
  const f = finalPath(dataDir, id); if (!f) return false;
  try { fs.mkdirSync(path.dirname(f), { recursive: true }); require('./durable-json').write(f, snap); return true; }
  catch (e) { console.warn('[research-report] 收尾稿落盘失败，只留在内存，重启后读不回：', id, e && e.message); return false; }
}

// 返回 p(sess, { final })：final = 会议已结束 → 喂完剩下的句子、只跑一次收尾轮（finish），结果缓存并落盘；
// 收尾轮没跑完时快照带 pending:true，live-report 据此先不标「已成形」，界面继续轮询。
// p.tick(active)：后台定时器调，active = 还在开的会；让研报不靠界面轮询也在长，散会的会补跑收尾轮。
// Historical final reports also enter the report/cards surface after a restart.
// Normalize the view only; preserve the archived file and unrelated report prose.
function reportDueView(report, meetingStart) {
  if (!report || !meetingStart) return report;
  const clean = a => {const due=normalizeActionDue(a.due,meetingStart);return due===a.due?a:{...a,due,dueRaw:a.dueRaw || a.due,dueIssue:'截止早于会议日期，已忽略'};};
  const out={...report};
  for (const key of ['myActions','possibleActions','allActions'])
    if (Array.isArray(out[key])) out[key]=out[key].map(clean);
  if (Array.isArray(out.items)) out.items=out.items.map(i=>i.action?{...i,action:clean(i.action)}:i);
  out.markdown=String(out.markdown||'').replace(/(## 全量清单（会议待办）\n)([\s\S]*?)(?=\n## |$)/g,(_m,heading,body)=>heading+body.split('\n').map(line=>{
    // Generated table cells escape task pipes; split only on unescaped separators.
    const cells=line.split(/(?<!\\)\|/);
    if(cells.length<6)return line;
    const raw=cells[3].trim(),due=normalizeActionDue(raw,meetingStart);
    if(due!==raw)cells[3]=' '+due+' ';
    return cells.join('|');
  }).join('\n'));
  return out;
}
function reviewMarkdown({myActions,possibleActions,allActions}) {
  return '\n## 我的待办\n'+myActions.map(a=>'- '+a.do+(a.draft?.status==='ready'?'\n'+a.draft.versions.at(-1).markdown:'')).join('\n')+
    '\n## 可能是你\n'+possibleActions.map(a=>'- '+a.do).join('\n')+
    '\n## 全量清单（会议待办）\n| 任务 | 负责人 | 截止 | 完成标准 |\n|---|---|---|---|\n'+allActions.map(a=>'| '+(a.said?'':'（建议，会上未定）')+a.do.replace(/\|/g,'\\|')+(a.unverified?'（数字待核实）':'')+' | '+(a.owner || '未指定')+' | '+(a.due||'')+' | '+(a.doneWhen||'')+' |').join('\n');
}
function provider(makeDeps, { now = () => Date.now(), env = () => ({}), dataDir = '', identity = sess => personalActions.selfNames(sess,env()), roleKeywords = null } = {}) {
  const rolesOf = sess => typeof roleKeywords === 'function' ? roleKeywords(sess) : (Array.isArray(roleKeywords) ? roleKeywords : []);
  const live = new Map();   // sessionId → {r, fed, tier, seen, override, last, finishing, done}
  const p = function (sess, { final = false, startFinal = false } = {}) {
    if (!sess || !sess.id) return null;
    // finalized is set before the streaming ASR end frame has drained.
    let s = live.get(sess.id);
    if (final && sess.finalizing && sess.closingWindow) return s?.r ? { ...s.r.snapshot(false), pending: true } : { pending: true };
    if (s && s.done) return reportDueView(s.done, sess.start);
    if (final && (!s || !s.r)) {   // 会已结束、内存里没有研报器（重启过 / 这场不是 deep）：读落盘的收尾稿
      const saved = reportDueView(loadFinal(dataDir, sess.id), sess.start);
      if (saved) { if (!s) { s = { done: saved }; live.set(sess.id, s); } else s.done = saved; return saved; }
      // History reads must never create a model worker. Only the end hook may cold-start.
      if (!startFinal) return s?.r ? s.r.snapshot(false) : null;
    }
    if (!s) { s = { r: null, fed: 0, tier: 'skip', seen: -1, override: '', forced: '' }; live.set(sess.id, s); if (live.size > 8) { for (const [k, v] of live) if (k !== sess.id && !v.finishing) { live.delete(k); break; } } }
    s.last = sess;
    const rows = Array.isArray(sess.transcript) ? sess.transcript : [];
    const override = sess.tier && tier.TIERS.includes(sess.tier.override) ? sess.tier.override : '';
    const e = env() || {}, forced = String(e.MEETING_TIER || '').toLowerCase();
    // 重算条件：转写长了、手动档改了、设置改了；已经 deep 且没有手动档就不再算（只升不降，算了也不会变）。
    // 代价：最长一场 35,504 字 781 行 featuresOf 12.5 ms，轮询 2 s 一次，不到 1% CPU。
    if ((rows.length !== s.seen && !(s.tier === 'deep' && !override)) || override !== s.override || forced !== s.forced) {
      const cal = sess.calendar || {};
      const minutes = Number(sess.startTs) > 0 ? (now() - Number(sess.startTs)) / 6e4 : undefined;
      // 日历标题有两种落法：matchCalendar 写 calendar.title；原生启动的 calendarBinding 只有 calendar.event.title（真实数据 22 场里 14 场只有后者）
      const c = tier.classify(tier.featuresOf(rows, { minutes }), { title: sess.title || '', calTitle: cal.title || (cal.event && (cal.event.title || cal.event.summary)) || '', override, env: e });
      s.seen = rows.length; s.override = override; s.forced = forced;
      s.tier = override ? c.tier : tier.upgrade(s.tier, c.tier);
      sess.tier = { ...(sess.tier || {}), tier: s.tier, reason: c.reason, etaSec: c.etaSec, at: now(), features: c.features };
    }
    // skip / light：不建研报器，live-report 用它自己的基线；用户点过卡片深度研究的，基线 + 「外部研究」一节（不跑整场研报轮次）。
    if (s.tier !== 'deep' && !identity(sess).length) return s.r && s.r._state.jobs.size ? cardsOnly(sess, s, final) : null;
    if (!ensure(sess, s)) return null;
    if (rows.length > s.fed) { s.r.feed(rows.slice(s.fed)); s.fed = rows.length; }
    if (final) {
      // 只有收尾入口（finalizeResearch / 后台 tick）能发起收尾轮；界面和历史读取只看已有结果
      if (!s.finishing && !startFinal) { const snap = s.r.snapshot(false); return snap.items.length || snap.researchJobs.length ? { ...snap, pending: true } : { pending: true }; }
      if (!s.finishing) {
        s.finalAttempts = (s.finalAttempts || 0) + 1;
        s.finishing = s.r.finish().catch(() => ({ ...s.r.snapshot(false), incomplete: true })).then(snap => {
          // Initial attempt plus at most two retries, including malformed model JSON.
          if (!snap.final && s.finalAttempts >= 3) snap = { ...s.r.snapshot(true), incomplete: true, fallback: true };
          if (snap.final) { s.done = snap; saveFinal(dataDir, sess.id, snap); }
          return snap;
        }).finally(() => { s.finishing = null; });
      }
      const snap = s.r.snapshot(false);
      return snap.items.length || snap.researchJobs.length ? { ...snap, pending: true } : { pending: true };   // 还没出条目也要带 pending，不然 live-report 回落 baseline 时会误标已成形
    }
    s.r.refresh().catch(() => {});
    const snap = s.r.snapshot(false);
    return snap.items.length || snap.researchJobs.length ? snap : null;   // 还没内容：交回 live-report 的基线
  };
  function ensure(sess, s) {
    if (s.r) { s.r.setActionsOnly(s.tier !== 'deep'); return true; }
    const deps = makeDeps(sess); if (!deps || typeof deps.ask !== 'function') return false;
    s.r = createReport({ ...deps, env, dataDir, session: () => s.last || sess, sessionId: sess.id, draftStateFile:dataDir ? path.join(dataDir,'act-for-me',String(sess.id).replace(/[^\w.-]/g,'_')+'.json') : '', participants: [...(sess.participants || []), ...require('./live-report').attendees(sess), ...identity(sess)], selfNames:identity(sess), roleKeywords:rolesOf(sess), actionsOnly:s.tier !== 'deep', minChars:identity(sess).length ? 1 : undefined, minGapMs:identity(sess).length ? 0 : undefined, title: sess.title || '', date: sess.start ? new Date(sess.start).toISOString() : '', now });
    return true;
  }
  function cardsOnly(sess, s, final) {
    const rows = Array.isArray(sess.transcript) ? sess.transcript : [];
    if (rows.length > s.fed) { s.r.feed(rows.slice(s.fed)); s.fed = rows.length; }
    const view = () => {
      const lr = require('./live-report'), base = lr.baseline(sess).items, cs = s.r.cardSection();
      return { markdown: lr.markdownOf(sess.title, base) + (cs.lines.length ? '\n' + cs.lines.join('\n') : ''), items: [...base, ...cs.items], researchJobs: s.r.snapshot(false).researchJobs, version: s.r._state.version };
    };
    if (!final) return view();
    const running = [...s.r._state.jobs.values()].some(j => j.state === 'accepted' || j.state === 'running');
    if (!running) { s.done = { ...view(), final: true }; saveFinal(dataDir, sess.id, s.done); return s.done; }
    if (!s.finishing) s.finishing = s.r.cardsSettled().then(() => { s.done = { ...view(), final: true }; saveFinal(dataDir, sess.id, s.done); return s.done; });
    return { ...view(), pending: true };
  }
  // 小窗卡片「深度研究」（MINI-01）：不改本场档位；不是 deep 的场次也建一个研报器，只跑这张卡片的研究。回执见 createReport.research。
  p.research = function (sess, card) {
    if (!sess || !sess.id || sess.finalized) return null;
    p(sess);
    const s = live.get(sess.id); if (!s || s.done || !ensure(sess, s)) return null;
    const rows = Array.isArray(sess.transcript) ? sess.transcript : [];
    if (rows.length > s.fed) { s.r.feed(rows.slice(s.fed)); s.fed = rows.length; }
    return s.r.research(card);
  };
  p.reviewAction = async (sess,id,decision) => {
    if(!sess?.id) throw Error('没有这场会');
    let s=live.get(sess.id);
    const saved=reportDueView(s?.done || loadFinal(dataDir,sess.id),sess.start);
    if(saved) {
      const actions=structuredClone(saved.allActions || []).map(a=>({...a,draft:saved.myActions?.find(x=>x.id===a.id)?.draft||null})), a=actions.find(a=>a.id===id);
      if(!a || !['claim','dismiss'].includes(decision)) throw Error('无效待办或操作');
      const names=identity(sess), rows=sess.transcript||[], roleOpts={roleKeywords:rolesOf(sess)};
      if(decision==='claim'&&!names.length)throw Error('请先配置本人姓名');
      if(personalActions.classify({...a,attributionReview:null},rows,names,roleOpts).group==='all') throw Error('他人任务不能认领');
      a.attributionReview={decision};
      const grouped=personalActions.groupActions(actions,rows,names,roleOpts);
      if(decision==='claim') {
        const deps=makeDeps(sess);
        const worker=require('./act-for-me').create({...deps,names,rows:()=>rows,context:deps.draftContext,
          stateFile:dataDir?path.join(dataDir,'act-for-me',sess.id+'.json'):''});
        a.draft=await worker.prepare(a);
      }
      grouped.myActions=grouped.myActions.map(x=>({...x,draft:actions.find(a=>a.id===x.id)?.draft||null}));
      const snap={...saved,...grouped,version:(saved.version||0)+1};
      snap.items=saved.items.map(i=>{const a=grouped.allActions.find(a=>a.id===i.id);return a?{...i,group:a.group,mine:a.group==='mine',draft:grouped.myActions.find(a=>a.id===i.id)?.draft||null}:i;});
      // Keep markdown consistent with the reviewed groups; previous draft receipts remain on disk.
      snap.markdown=saved.markdown.replace(/\n## (?:我的待办|可能是你|全量清单[^\n]*|会议待办[^\n]*)\n[\s\S]*?(?=\n## |$)/g,'')+reviewMarkdown(grouped);
      snap.actForMeIncomplete=grouped.myActions.some(a=>a.draft?.status==='failed');
      saveFinal(dataDir,sess.id,snap);
      if(!s){s={};live.set(sess.id,s);}s.done=snap;
      return snap;
    }
    p(sess); s=live.get(sess.id);
    if(!s?.r) throw Error('待办尚未生成');
    return s.r.reviewAction(id,decision);
  };
  p.cardStatus = (id, cardId) => { const s = live.get(id); return s && s.r ? s.r.cardStatus(cardId) : null; };
  p.tick = function (active) {
    const ids = new Set();
    for (const sess of active || []) { if (!sess || !sess.id || sess.finalized) continue; ids.add(sess.id); try { p(sess); } catch (e) {} }
    for (const [id, s] of live) if (!ids.has(id) && s.r && s.last && !s.finishing && !s.done) { try { p(s.last, { final: true, startFinal: true }); } catch (e) {} }
  };
  p.settled = id => { const s = live.get(id); return s && s.finishing ? s.finishing : Promise.resolve(s && s.done || null); };
  return p;
}

// 接进产品（server.js 一行；档位由本模块的 ROUTE 决定，server.js 不写死）：
//   require('./research-report').install(require('./live-report'), { ask:(s,u,t)=>askModel(loadEnv(),s,u,1600,t.kind,t), env:loadEnv });
// 设置项 RESEARCH_REPORT=off 时不接，live-report 用它自己的基线。
// 研报用哪档模型：思考档（Claude 命令行 = opus），不限只走原生 / API（nativeOnly 会把 Claude 命令行滤掉）。
// 依据：Aaron 2026-09-25 批准会中主动智能用高档模型；2026-10-23 23:01 LLM_PROVIDER 由 codex 改为 claude 后，
// 原来的 'quick' + nativeOnly 在生产里只剩 DeepSeek-flash（chainForStage 实测 [Claude, DeepSeek]，回放 22 次全是 deepseek-flash）。
// 不给工具：检索由本机做，模型只读材料出补丁。
const ROUTE = Object.freeze({ kind: 'think', nativeOnly: false, tools: false });

// sessions：() => 还在开的会（server.js 的 SESSIONS.values()）；给了就起一个后台定时器（unref，不挡退出），
// 研报在会中自己长、散会自己收尾，不再依赖界面开着研报面板轮询。dataDir：收尾稿落盘目录。
function install(liveReport, { ask, env = () => ({}), sessions = null, dataDir = '', tickMs = 15000, onFinding = null } = {}) {
  if (!liveReport || typeof liveReport.setProvider !== 'function' || typeof ask !== 'function') return false;
  if (String((env() || {}).RESEARCH_REPORT || '').toLowerCase() === 'off') return false;
  const web = require('./tools/web'), isearch = require('./insight-search');
  let names = null;
  const context = (delta, options = {}) => ledgerContext(ledgerDir(options.env || env() || {}, dataDir))(delta);
  const p = provider(sess => {
    return {
    ask, search: (q,options={}) => web.searchWithSources(q, 6, {...options,env:options.env || env(),dataDir,sessionId:sess.id,role:'research'}), context,
    onFinding: onFinding ? f => onFinding(sess, f) : null,
    draftContext: () => require('./context-pack').build(env(), {purpose:'act-for-me', dataDir, session:sess}),
    safeQuery: q => softenQuery(q, names || (names = isearch.loadSensitiveNames())),
  };}, { env, dataDir, identity:sess=>require('./context-pack').actionIdentity(dataDir,sess,env()), roleKeywords:sess=>require('./context-pack').actionRoleKeywords(dataDir,sess,env()) });
  liveReport.setProvider(p);
  module.exports.current = p;   // POST /native/research 用（cardRoute）；返回值仍是 true，不改既有调用方
  if (typeof sessions === 'function' && tickMs > 0) {
    const t = setInterval(() => { try { p.tick([...(sessions() || [])]); } catch (e) {} }, tickMs);
    if (t.unref) t.unref();
    p.timer = t;
  }
  return true;
}

// POST /native/research（开始）与 /native/research-status（查回执）的处理函数；路由在 native-meeting.js，server.js 注入。
// j = {sessionId, cardId, text}；回 {code, body}。卡片 id 是小窗 panelCards 给每张卡的 key。
function cardRoute(getProvider, getSession) {
  return function (j = {}) {
    const id = clip(j.sessionId || j.id, 100), cardId = clip(j.cardId, 64), text = clip(j.text, 600);
    if (!id || !cardId) return { code: 400, body: { ok: false, error: '缺少会议 id 或卡片 id' } };
    const p = getProvider();
    if (!p || typeof p.research !== 'function') return { code: 503, body: { ok: false, error: '研报模块没接上，深度研究不可用' } };
    if (j.status) { const r = p.cardStatus(id, cardId); return r ? { code: 200, body: { ok: true, ...r } } : { code: 404, body: { ok: false, error: '没有这张卡片的研究' } }; }
    if (!text) return { code: 400, body: { ok: false, error: '缺少卡片内容' } };
    const sess = getSession(id);
    if (!sess || sess.finalized) return { code: 409, body: { ok: false, error: '这场会不在进行中' } };
    const r = p.research(sess, { cardId, text });
    return r ? { code: 200, body: { ok: true, ...r } } : { code: 503, body: { ok: false, error: '研究没有启动（模型未配置）' } };
  };
}

// 北极星评测适配器：node scripts/north-star-eval.js replay --tag intel-v1 --adapter app/research-report.js
function adapter() {
  let r, clock = 0;
  return {
    start({ meeting, ask, dataDir }) {
      const web = require('./tools/web'), isearch = require('./insight-search');
      const names = isearch.loadSensitiveNames();
      let env = {}; try { env = require('./config').load() || {}; } catch (e) { env = {}; }
      clock = 0;
      r = createReport({ ask, dataDir, env, sessionId: meeting.id, title: meeting.title || '', date: meeting.start ? new Date(typeof meeting.start === 'number' ? meeting.start : Date.parse(meeting.start)).toISOString() : '', now: () => clock,
        search: (q,options={}) => web.searchWithSources(q, 6, {...options,env:options.env || env,dataDir,sessionId:meeting.id,role:'summary'}), safeQuery: q => softenQuery(q, names), context: ledgerContext(ledgerDir(env, dataDir)) });
    },
    async push(rows, tSec) {
      clock = tSec * 1000; r.feed(rows);
      return (await r.refresh()) ? r.snapshot(false) : null;
    },
    async finish() { return r.finish(); },
  };
}

module.exports = adapter;
Object.assign(module.exports, { loadFinal, createReport, provider, install, cardRoute, current: null, CARD_TOPIC, adapter, softenQuery, rankSources, sourceTier, staleDue, parseJson, ledgerContext, similar, SYSTEM, ROUTE });
