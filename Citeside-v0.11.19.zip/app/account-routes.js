'use strict';
// 仅给本机账号操作挂入口；不暴露会话令牌，不依赖录音或会议内容。
const cloud = require('./cloud-account');
function create(ctx) {
  const client = cloud.create(ctx);
  return async (req, res, u) => {
    const p = u.pathname.replace(/^\/asr-relay/, '');
    if (p === '/account-login' && req.method === 'GET') {
      // The cloud-to-loopback navigation is cross-site by definition. Only this
      // inert GET shell may enter that way; the subsequent verification is same-origin.
      const navigation = req.headers['sec-fetch-mode'] === 'navigate' && req.headers['sec-fetch-dest'] === 'document';
      const local = navigation ? { ...req, headers: { ...req.headers, 'sec-fetch-site': 'none' } } : req;
      if (!ctx.isLocalReq(local)) { res.writeHead(403); res.end('local only'); return true; }
      // Preserve the fragment in the browser; the HTTP request never contains the token.
      res.writeHead(302, { Location: '/seatnote/account.html?view=applogin', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
      res.end(); return true;
    }
    if (!p.startsWith('/account/')) return false;
    const json = (status, body) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(body)); return true; };
    if (!ctx.isLocalReq(req)) return json(403, { ok: false, code: 'local_only', error: '只能在本机操作账号' });
    const action = { 'GET /account/status': 'status', 'GET /account/auth/config': 'authConfig', 'GET /account/mine': 'mine', 'POST /account/login/password': 'passwordLogin', 'POST /account/register': 'register', 'POST /account/password/forgot': 'forgotPassword', 'POST /account/login/start': 'start', 'POST /account/login/verify': 'verify', 'POST /account/return-to-app': 'returnToApp', 'POST /account/logout': 'logout', 'POST /account/claim': 'claim', 'GET /account/admin/mfa/status': 'adminMfaStatus', 'POST /account/admin/mfa/setup': 'adminMfaSetup', 'POST /account/admin/mfa/confirm': 'adminMfaConfirm', 'POST /account/admin/mfa/verify': 'adminMfaVerify', 'POST /account/admin/mfa/lock': 'adminMfaLock', 'GET /account/admin/service': 'adminService', 'POST /account/admin/service': 'saveAdminService', 'GET /account/admin/invites': 'adminInvites', 'POST /account/admin/invites': 'createAdminInvite', 'POST /account/feedback/preview': 'feedbackPreview', 'POST /account/feedback/submit': 'feedbackSubmit', 'GET /account/admin/feedback': 'adminFeedback', 'POST /account/admin/feedback/approve': 'approveAdminFeedback', 'POST /account/admin/feedback/decline': 'declineAdminFeedback' }[req.method + ' ' + p];
    const payment = /^\/account\/payments\/(catalog|checkout|subscription|subscription\/cancel|orders|orders\/[a-zA-Z0-9_-]{1,128})$/.exec(p);
    if (!action && !payment) return json(404, { ok: false, code: 'not_found' });
    let body = {};
    if (req.method === 'POST') {
      if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || '')) return json(415, { ok: false, code: 'json_required' });
      const bodyLimit = (action === 'feedbackPreview' || action === 'feedbackSubmit') ? 3145728 : 8192;
      const parts = []; let size = 0;
      try {
        for await (const c of req) { const part = Buffer.from(c); size += part.length; if (size <= bodyLimit) parts.push(part); }
        if (size > bodyLimit) return json(413, { ok: false, code: 'body_too_large' });
        body = JSON.parse(Buffer.concat(parts).toString('utf8') || '{}');
        if (!body || typeof body !== 'object' || Array.isArray(body)) throw Error('invalid');
      } catch { return json(400, { ok: false, code: 'invalid_json' }); }
    }
    if (payment) {
      const name=payment[1], post=name==='checkout'||name==='subscription/cancel';
      if(req.method!==(post?'POST':'GET'))return json(405,{ok:false,code:'method_not_allowed'});
      const kind=name.startsWith('orders/')?'order':name==='subscription/cancel'?'cancel':name;
      const r=await client.payment(kind,kind==='order'?{id:name.slice(7)}:kind==='orders'?{before:u.searchParams.get('before')}:body);
      if (kind==='checkout' && r.ok) {
        try {
          const url=new URL(r.checkoutUrl);
          // Paddle can host checkout on a merchant domain. Require HTTPS and reject local targets.
          if(url.protocol!=='https:'||url.username||url.password||!url.hostname.includes('.')||/^(localhost|127\.|0\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2[0-9]|3[01])\.)/i.test(url.hostname)||url.hostname.endsWith('.local'))throw Error('unsafe');
          await (ctx.openPaymentUrl || (href=>new Promise((resolve,reject)=>require('node:child_process').execFile('/usr/bin/open',[href],{timeout:6000},e=>e?reject(e):resolve()))))(url.href);
          delete r.checkoutUrl; r.opened=true;
        } catch { return json(503,{ok:false,code:'checkout_open_failed',...(r.order?{order:r.order}:{})}); }
      }
      return json(r.ok?200:r.code==='unauthorized'?401:r.code==='subscriptions_not_configured'?503:400,r);
    }
    if (action === 'returnToApp') {
      const account = await client.status();
      if (account.status !== 'signed_in') return json(401, {ok:false,code:'unauthorized'});
      try { return json(200, await (ctx.returnToApp || require('./desktop-open').returnToNative)()); }
      catch { return json(503, {ok:false,code:'native_app_unavailable'}); }
    }
    const r = await client[action](body);
    if (['forbidden','mfa_required','mfa_setup_required'].includes(r.code)) return json(403, r);
    if (r.code === 'unauthorized' || r.code === 'invalid_credentials') return json(401, r);
    if (r.code === 'feedback_rate_limited' || r.code === 'refine_limit_reached' || r.httpStatus === 429) return json(429, r);
    return json(r.ok || r.status === 'disabled' || r.status === 'offline' ? 200 : 400, r);
  };
}
module.exports = { create };
