'use strict';
// Compare source-backed meanings, never presentation labels. Both texts must
// cover enough of each other so a short, different action is not swallowed.
function repeated(a,b){
 if(!(a.sourceIds||[]).some(id=>(b.sourceIds||[]).includes(id)))return false;
 const pairs=text=>{const s=String(text||'').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');return new Set(Array.from({length:Math.max(0,s.length-1)},(_,i)=>s.slice(i,i+2)));};
 const x=pairs(a.text),y=pairs(b.text);if(!x.size||!y.size)return false;
 const common=[...x].filter(v=>y.has(v)).length;
 return common>=8&&common/Math.min(x.size,y.size)>=.35&&common/Math.max(x.size,y.size)>=.35;
}
// Same point in other words, across batches: no shared source is required because
// later calls cite later sentences. Stricter than repeated() on the shorter text so
// a card that merely reuses the same action line is not swallowed.
// Only the information part is compared: the action line is boilerplate that many
// different cards share ("请负责 CI 的同事拉一下…").
// A text that is only an action line has no information part and matches nothing.
const ACTION_LINE=/(?:^|\n)\s*(?:动作|Action)\s*[:：]/i;
// Facts that change the meaning of an otherwise identical sentence: numbers, weekdays,
// relative days. The candidate a is only a repeat of b when every fact in a already
// appears in b (a new or changed date / amount is new information, not a repeat;
// peer_review 92272d28). Directional: a says nothing b did not → repeat.
const FACT=/\d+(?:[.,]\d+)?|[零一二两三四五六七八九十百千万亿]{2,}|周[一二三四五六日天]|礼拜[一二三四五六日天]|星期[一二三四五六日天]|月底|月初|月中|今天|明天|后天|昨天|本周|这周|下周|下下周|上周|下个月|这个月|上午|下午|晚上|年底|季度末/g;
function facts(text){return new Set((String(text||'').match(FACT)||[]).map(f=>f.replace(/[,，]/g,'')));}
function similar(a,b){
 const info=text=>String(text||'').split(ACTION_LINE)[0];
 const pairs=text=>{const s=String(text||'').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');return new Set(Array.from({length:Math.max(0,s.length-1)},(_,i)=>s.slice(i,i+2)));};
 const ia=info(a.text),ib=info(b.text);
 const x=pairs(ia),y=pairs(ib);if(!x.size||!y.size)return false;
 const common=[...x].filter(v=>y.has(v)).length;
 if(!(common>=4&&common/Math.min(x.size,y.size)>=.45&&common/Math.max(x.size,y.size)>=.3))return false;
 const fb=facts(ib);return [...facts(ia)].every(f=>fb.has(f));
}
function repeatsJudgment(text,sourceIds,judgments=[]){
 return judgments.some(x=>x.channel==='judgment'&&!x.stale&&!x.supersededBy&&repeated({text,sourceIds},{text:x.point,sourceIds:(x.sourceRefs||[]).map(r=>r.segId)}));
}

// Cross-lingual concept + normalized number + entity alignment for catching
// translation recaps (e.g. English transcript -> Chinese card) with zero external deps.
const BILINGUAL_CONCEPTS=[
 ['@budget',/\bbudgets?\b|预算/i],
 ['@deadline',/\b(?:deadlines?|due\s+date|ddl)\b|截止|交期/i],
 ['@batch',/\b(?:first\s+batch|batch(?:es)?|initial\s+run)\b|首批|批次/i],
 ['@price',/\b(?:pric(?:e|es|ing)|quotes?|unit\s+price)\b|报价|价格|单价/i],
 ['@cost',/\b(?:costs?|expense|spend)\b|成本|费用|花费/i],
 ['@delay',/\b(?:delay(?:ed|s)?|postpon(?:e|ed)|slip(?:ped)?)\b|延期|推迟/i],
 ['@launch',/\b(?:launch(?:ed|ing)?|release(?:d)?|ship(?:ped|ping)?|deliver(?:y|ed)?)\b|上线|发布|交付/i],
 ['@vendor',/\b(?:vendors?|suppliers?)\b|供应商|厂商/i],
 ['@contract',/\b(?:contracts?|agreements?)\b|合同|协议/i],
 ['@margin',/\b(?:margins?|profit)\b|毛利|利润/i],
 ['@revenue',/\b(?:revenue|arr|mrr)\b|营收|收入/i],
 ['@risk',/\brisks?\b|风险/i],
 ['@memory',/\b(?:memory|ram|vram)\b|内存|显存/i],
 ['@latency',/\b(?:latency|p90|p50|response\s+time)\b|延迟|耗时/i],
 ['@cache',/\bcach(?:e|ing)\b|缓存/i],
 ['@security',/\b(?:security|privacy|encrypt(?:ion|ed)?)\b|安全|隐私|加密/i],
 ['@compliance',/\b(?:compliance|gdpr|soc2)\b|合规/i],
 ['@license',/\b(?:licen[cs]e|gpl|mit|apache)\b|许可|授权/i],
 ['@quota',/\b(?:quotas?|limits?|caps?)\b|额度|上限|限额/i],
 ['@discount',/\bdiscounts?\b|折扣|优惠/i],
 ['@refund',/\brefunds?\b|退款/i],
 ['@headcount',/\b(?:headcount|hc|hiring)\b|编制|人手|招聘/i],
 ['@schedule',/\b(?:schedule|timeline|roadmap|milestone)\b|排期|时间表|里程碑/i],
 ['@offline',/\boffline\b|离线/i],
 ['@cloud',/\bcloud\b|云端/i],
 ['@local',/\b(?:local|on-device)\b|本地|本机|端侧/i],
 ['@unit',/\bunits?\b|台|件|套/i],
 ['@q1',/\bq1\b|一季度|第一季度/i],
 ['@q2',/\bq2\b|二季度|第二季度/i],
 ['@q3',/\bq3\b|三季度|第三季度/i],
 ['@q4',/\bq4\b|四季度|第四季度/i],
 ['@cancel',/\b(?:cancel(?:led|ed)?|drop(?:ped)?|abort)\b|取消|放弃/i],
 ['@upgrade',/\b(?:upgrad(?:e|ed)|migrat(?:e|ed|ion))\b|升级|迁移/i],
];
const EN_STOP=new Set(['the','and','for','with','that','this','from','have','will','are','was','were','our','your','their','not','but','can','all','any','per','about','into','over','than','then','when','what','which','who','how','why','has','had','may','should','could','would','been','being','also','just','only','more','most','very','some','such']);
const hasHan=s=>/\p{Script=Han}/u.test(String(s||''));
const hasLatin=s=>/[a-zA-Z]{2,}/.test(String(s||''));

function normalizedNumbers(text){
 const out=new Set();
 const s=String(text||'').replace(/[,，]/g,'');
 // Match Arabic numbers with optional magnitude suffix (k/m/b/万/亿/%)
 for(const m of s.matchAll(/(\d+(?:\.\d+)?)\s*(k|m|b|万|亿|%)?/gi)){
  let val=Number(m[1]);
  if(!Number.isFinite(val))continue;
  const unit=(m[2]||'').toLowerCase();
  if(unit==='k')val*=1e3;
  else if(unit==='万')val*=1e4;
  else if(unit==='m')val*=1e6;
  else if(unit==='亿')val*=1e8;
  else if(unit==='b')val*=1e9;
  out.add(unit==='%'?`${val}%`:String(val));
 }
 // Also include Chinese numerals (e.g. 五百 -> 500, 二十万 -> 200000),
 // stripping already-parsed Arabic+万/亿 spans so "20万" isn't double-counted as 10000.
 try{
  const {cnNumbers}=require('./live-coverage-policy');
  const stripped=s.replace(/\d+(?:\.\d+)?\s*(?:万|亿)/g,' ');
  for(const n of cnNumbers(stripped))out.add(String(Number(n)));
 }catch{}
 return out;
}

function conceptFingerprint(text){
 const s=String(text||'');
 const tokens=new Set();
 for(const [tag,re] of BILINGUAL_CONCEPTS)if(re.test(s))tokens.add(tag);
 for(const n of normalizedNumbers(s))tokens.add('#'+n);
 for(const m of s.toLowerCase().matchAll(/\b[a-z][a-z0-9_-]{1,24}\b/g)){
  const w=m[0];
  if(!EN_STOP.has(w)&&!BILINGUAL_CONCEPTS.some(([,re])=>re.test(w)))tokens.add('w:'+w);
 }
 return tokens;
}

function crossLingualSimilar(a,b){
 const ta=typeof a==='string'?a:String(a?.text||a?.body||'');
 const tb=typeof b==='string'?b:String(b?.text||b?.body||'');
 if(!ta.trim()||!tb.trim())return false;
 if(similar({text:ta},{text:tb}))return true;
 const fa=conceptFingerprint(ta),fb=conceptFingerprint(tb);
 if(fa.size<2||fb.size<2)return false;
 // Directional number check: if candidate introduces any number not in reference, it's new info (e.g. conflict/fact_check).
 const na=normalizedNumbers(ta),nb=normalizedNumbers(tb);
 if(na.size&&![...na].every(n=>nb.has(n)))return false;
 const shared=[...fa].filter(t=>fb.has(t)).length;
 const minSize=Math.min(fa.size,fb.size);
 const crossLang=(hasHan(ta)&&hasLatin(tb)&&!hasHan(tb))||(hasHan(tb)&&hasLatin(ta)&&!hasHan(ta))||(hasHan(ta)&&hasLatin(tb))||(hasHan(tb)&&hasLatin(ta));
 if(crossLang)return shared>=2&&(shared/minSize>=0.5||(shared>=3&&shared/minSize>=0.4));
 return shared>=3&&shared/minSize>=0.6;
}

// Returns true when candidate card `a` addresses a distinct sub-topic, metric,
// or constraint compared to prior card `b` (so mid/late meeting new sub-topics
// are not silenced by same-type cooldown).
function isDistinctTopic(a,b){
 const ta=typeof a==='string'?a:String(a?.display?.body||a?.text||a?.delta||'');
 const tb=typeof b==='string'?b:String(b?.display?.body||b?.text||b?.delta||'');
 if(!ta.trim()||!tb.trim())return false;
 if(crossLingualSimilar(ta,tb))return false;
 const pairs=text=>{const s=String(text||'').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');return new Set(Array.from({length:Math.max(0,s.length-1)},(_,i)=>s.slice(i,i+2)));};
 const pa=pairs(ta),pb=pairs(tb);
 const biOverlap=pa.size&&pb.size?[...pa].filter(v=>pb.has(v)).length/Math.min(pa.size,pb.size):0;
 const fa=conceptFingerprint(ta),fb=conceptFingerprint(tb);
 const conceptOverlap=fa.size&&fb.size?[...fa].filter(v=>fb.has(v)).length/Math.min(fa.size,fb.size):0;
 const na=normalizedNumbers(ta),nb=normalizedNumbers(tb);
 const hasNewNumbers=na.size>0&&[...na].some(n=>!nb.has(n));
 if(hasNewNumbers&&biOverlap<0.35)return true;
 return biOverlap<0.25&&conceptOverlap<0.4;
}

module.exports={repeated,similar,repeatsJudgment,crossLingualSimilar,conceptFingerprint,normalizedNumbers,isDistinctTopic};
