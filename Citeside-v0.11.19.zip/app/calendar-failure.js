'use strict';
// Fixed public messages: never reflect provider bodies (which may include credentials).
function classify(value = {}) {
 const raw = typeof value === 'string' ? value : [value.code,value.status,value.type,value.subtype,value.message,typeof value.error==='object'?JSON.stringify(value.error):value.error].filter(Boolean).join(' ');
 const text=String(raw).toLowerCase();
 let reason='transient';
 if(/enoent|enotdir|not.configured|config.*(?:missing|not.found)|missing.*config|not.installed|未安装|未配置|没.*工具|找不到.*工具/.test(text))reason='missing_tool';
 else if(/401|403|invalid_grant|unauthori[sz]ed|revoked|authentication|token[_ -]?(missing|expired|invalid)|refresh_token|token.*expired|授权.*(过期|失效)|未授权|重新连接|not logged|login required|auth.*required/.test(text))reason='reauth';
 return {ok:false,reason,message:{reauth:'需要重新授权，请重新连接日历',missing_tool:'没装工具，请安装并配置飞书命令行工具',transient:'临时失败，稍后自动重试'}[reason]};
}
module.exports={classify};
