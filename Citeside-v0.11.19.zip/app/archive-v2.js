'use strict';
// 会后页 v2（Aaron 2026-09-24 14:35 拍板）：会后 10 秒内知道这场会改变了什么、要我拍什么、该问谁。
// 服务端从 enhanced.json 挑出四块（改变 / 洞察→行动 / 下一步 / 可分享纪要），前端只渲染。
// ⌘E 改过的文字落在 enhanced.overrides（键 = 视图路径，如 "changes.0"、"insights.2.answer"），渲染时 override 优先。
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const editSamples = require('./edit-samples');
const owners = require('./owners');
const sendGate = require('./send-gate');
const personHandoff = require('./person-handoff');

const oneLine = v => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
const clip = (s, n) => { s = oneLine(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
// 立场 = 回答的第一句（中文句号 / 分号 / 换行前）
const firstSentence = s => { const t = oneLine(s); const m = /^(.+?[。！？；.!?])(\s|$)/.exec(t); return m ? m[1] : t; };
const okId = v => /^[A-Za-z0-9_-]{1,80}$/.test(String(v || ''));
const PATH_RE = /^(changes\.\d{1,2}|insights_md|insights\.\d{1,3}\.(question|stance|answer|action|owner)|next\.(text|owner)|summary\.\d{1,2}|minutes\.topic)$/;
// 第 2 块「军师怎么看」：正文 = enhanced.json 的 insights_md（模型自由写的 markdown，没有模板）。
// 右侧行动卡只对正文里 `@<人名>：` 开头的行生成——这是会中会后唯一保留的那个约定。
const ASSIGN_RE = /^\s*(?:[-*+]\s*)?(?:\*\*)?@\s*([^：:*\n]{1,20}?)(?:\*\*)?\s*[：:]\s*(.+)$/;
const KNOWN = () => new Set(Object.values(owners.table()).map(String));
// insights_md 缺失（老场次 / 模型没给）时，用旧 insights 数组拼一段 markdown 兜底：每条一段。
function fallbackMd(list) {
  return (list || []).filter(i => i && (i.question || i.answer)).map(i => {
    const q = oneLine(i.question), a = String(i.answer || '').trim();
    const act = (i.action && typeof i.action === 'object') ? oneLine(i.action.text || i.action.label) : oneLine(i.action);
    const who = act ? (owners.classify([q, act, a].join(' ')).owner || '未指定') : '';
    return [q ? '**' + q + '**' : '', a, act ? '@' + who + '：' + act : ''].filter(Boolean).join('\n\n');
  }).join('\n\n').trim();
}
// markdown 正文 → 行动卡：一行一条，人名先按正文里写的那个（认识才认），认不出保留未指定，不按主题推断负责人
function actionsFromMd(md) {
  const known = KNOWN(), out = [];
  for (const line of String(md || '').split('\n')) {
    const m = ASSIGN_RE.exec(line); if (!m) continue;
    const raw = oneLine(m[1]), text = clip(m[2], 200); if (!text) continue;
    const cls = owners.classify(raw + ' ' + text);
    const owner = known.has(raw) ? raw : cls.owner;
    out.push({ n: out.length + 1, action: text, owner, topic: cls.topic, named: raw, sourceId: 'v2-ins-' + crypto.createHash('sha1').update(owner + '|' + text).digest('hex').slice(0, 10), legacyId: 'v2-ins-' + (out.length + 1) });
    if (out.length >= 8) break;
  }
  return out;
}

// 传统纪要：从 summary Markdown 取一句话主题 + 二级标题 + 每节的「结论」段
function parseSummary(md) {
  const lines = String(md || '').split('\n');
  let topic = '', cur = null; const sections = [];
  let grab = false;
  for (const raw of lines) {
    const l = raw.trim();
    if (!l) { continue; }
    if (/^#\s/.test(l)) continue;
    if (/^##\s/.test(l)) { cur = { title: oneLine(l.replace(/^##\s*/, '').replace(/^[一二三四五六七八九十]+、\s*/, '')), conclusion: '' }; sections.push(cur); grab = false; continue; }
    if (!cur && !topic && !/^[#*\-|>]/.test(l)) { topic = oneLine(l); continue; }
    if (!cur) continue;
    if (/^\*\*[^*]*(结论|分歧|断点|未定|缺口)[^*]*\*\*$/.test(l)) { grab = true; continue; }
    if (/^\*\*[^*]+\*\*$/.test(l)) { grab = false; continue; }
    if (grab && !cur.conclusion) cur.conclusion = oneLine(l.replace(/^[-*]\s*/, ''));
  }
  return { topic, sections };
}

// 议题表（Aaron 09-24 13:58 批「议题改表」，14:05「不要详细议题」）：议题 / 结论 / 状态 / 未对齐 / 下一步，每格一句话。
// 数据全部复用 brief：overview.topics（标题）+ topics（结论、decision、open）+ overview.todos（按 topic 归属的下一步）+ decisions（人手改过的状态）。不新增模型调用。
const TOPIC_STATUS = ['已一致', '待讨论', '有分歧', '搁置'];
const cellLine = v => { const s = oneLine(v); const m = /^(.+?[。；;！!？?])/.exec(s); return clip(m ? m[1].replace(/[。；;]$/, '') : s, 40); };
function topicTable(b) {
  const ov = (b && b.overview) || {}, cards = (b && b.topics) || [], todos = ov.todos || [], dec = (b && b.decisions) || {};
  return (ov.topics || []).map((h, i) => {
    const c = cards.find(x => x && x.n === h.n) || cards[i] || {};
    const st = dec[String(h.n)] || c.decision;
    const concl = c.conclusion && c.conclusion !== '未形成结论' ? c.conclusion : '';
    return { n: h.n, title: clip(h.title, 24), conclusion: cellLine(concl), status: TOPIC_STATUS.includes(st) ? st : '待讨论',
      open: cellLine((c.open || []).filter(Boolean)[0] || ''),
      next: cellLine(todos.filter(t => t && t.topic === h.n).map(t => oneLine(t.what) + (oneLine(t.owner) ? '（' + oneLine(t.owner) + '）' : ''))[0] || '') };
  }).filter(r => r.title);
}

const isHardConflict = s => !/非硬冲突|不构成硬冲突|不是硬冲突/.test(String(s || ''));
const isUnstable = i => i.unstable === true || (typeof i.stability === 'number' && i.stability < 0.5);

// 说话人编号不上界面（Aaron 09-22 定，认人 09-24 删）：视图里出现的 S2 / 说话人 2 换成这场 names 里的真名，
// 没有名字就写「未认人」；负责人一栏只剩编号时直接留空。只认本场转写里真出现过的编号，免得误伤 Galaxy S24 这类型号。
function speakerNamer(r) {
  const names = (r && r.names) || {}, keys = new Set();
  for (const row of (r && r.transcript) || []) { const k = String(row.speaker ?? row.spk ?? row.who ?? ''); if (/^\d{1,3}$/.test(k)) keys.add(k); }
  for (const k of Object.keys(names)) { const m = /^S?(\d{1,3})$/.exec(k); if (m) keys.add(m[1]); }
  if (!keys.size) return { text: t => t, owner: t => t };
  const who = k => oneLine(names[k] || names['S' + k]) || '未认人';
  const re = new RegExp('(?:说话人\\s*|Speaker\\s*|S)(' + [...keys].join('|') + ')(?!\\d)', 'g');
  const text = t => String(t == null ? '' : t).replace(re, (m, k) => who(k));
  return { text, owner: t => { const v = text(t); return v === '未认人' ? '' : v; } };
}
function nameView(view, r) {
  const n = speakerNamer(r);
  view.changes.forEach(c => { c.text = n.text(c.text); });
  view.insights.forEach(i => { i.action = n.text(i.action); });
  if (view.next) view.next.text = n.text(view.next.text);
  const m = view.minutes;
  m.conclusions = m.conclusions.map(n.text);
  m.todos = m.todos.map(t => ({ ...t, text: n.text(t.text), owner: n.owner(t.owner) }));
  m.topicTable = m.topicTable.map(x => ({ ...x, conclusion: n.text(x.conclusion), open: n.text(x.open), next: n.text(x.next) }));
  return view;
}

function buildView(r) {
  const b = (r && r.brief) || {};
  const ib = b.insightsBrief || {};
  const meta = b.insightsMeta || {};
  const ov = b.overview || {};
  const decisions = (ib.decisionsForAaron || []).map(oneLine).filter(Boolean);
  const conflicts = (meta.conflictsWithBoard || []).map(oneLine).filter(isHardConflict);
  const conclusions = (ov.conclusions || []).map(oneLine).filter(Boolean);
  const todos = (ov.todos || []).map(t => ({ text: oneLine(t.what || t.text), owner: oneLine(t.owner) })).filter(t => t.text)
    .concat((r.todos || []).map(t => ({ text: oneLine(t.text), owner: oneLine(t.owner) })).filter(t => t.text));

  // 1. 这场会改变了什么：≤3 行，问题（要拍的 / 硬冲突）→ 进展（结论）→ 下一步（待办）
  const changes = [];
  const push = (kind, text) => { if (text && changes.length < 3 && !changes.some(c => c.text === clip(text, 40))) changes.push({ kind, text: clip(text, 40) }); };
  push('问题', decisions[0] || conflicts[0]);
  push('进展', conclusions[0]);
  push('下一步', todos[0] && todos[0].text);
  push('问题', decisions[1] || conflicts[1]);
  push('进展', conclusions[1]);

  // 2. 军师怎么看：正文是自由 markdown（insights_md），行动卡只从 `@人名：` 行来
  const insightsMd = String((r && r.insightsMd) || b.insightsMd || b.insights_md || (r && r.insights_md) || '').trim() || fallbackMd(b.insights);
  const insights = actionsFromMd(insightsMd);

  // 3. 下一步最重要的一件事：最重要的 decision，没有就 todos[0]
  const nextText = decisions[0] || (todos[0] && todos[0].text) || '';
  const next = nextText ? { text: nextText, owner: owners.classify(nextText).owner, topic: owners.classify(nextText).topic, sourceId: 'v2-next' } : null;

  // 4. 可分享纪要
  const ps = parseSummary(r.summary);
  const att = ((r.calendar || {}).attendees || []).filter(a => a && a.name && !a.declined).map(a => a.name);
  const participants = att.length ? att : (Array.isArray(r.participants) ? r.participants.filter(Boolean) : []);
  const minConcl = (conclusions.length ? conclusions : ps.sections.map(s => s.conclusion).filter(Boolean)).slice(0, 5);
  const minutes = { topic: ps.topic || oneLine(ib.purpose || ''), sections: ps.sections.filter(x => x.conclusion).slice(0, 8), topicTable: topicTable(b), conclusions: minConcl, todos: todos.slice(0, 8), participants };
  return nameView({ changes, insightsMd, insights, next, minutes }, r);
}

// 把 overrides 按路径盖到视图上。insights 用 n 找（位置会随排序变），别的按下标。
function applyOverrides(view, overrides) {
  const o = overrides && typeof overrides === 'object' ? overrides : {};
  for (const [p, text] of Object.entries(o)) {
    if (!PATH_RE.test(p) || typeof text !== 'string') continue;
    const seg = p.split('.');
    if (p === 'insights_md') { view.insightsMd = text; view.insights = actionsFromMd(text); view.insightsEdited = true; }
    else if (seg[0] === 'changes') { const c = view.changes[Number(seg[1])]; if (c) { c.text = text; c.edited = true; } }
    else if (seg[0] === 'insights') { const i = view.insights.find(x => String(x.n) === seg[1]); if (i) { i[seg[2]] = text; i.edited = { ...(i.edited || {}), [seg[2]]: true }; } }
    else if (seg[0] === 'next') { if (view.next) { view.next[seg[1]] = text; view.next.edited = { ...(view.next.edited || {}), [seg[1]]: true }; } }
    else if (seg[0] === 'summary') { const k = Number(seg[1]); if (k < view.minutes.conclusions.length) view.minutes.conclusions[k] = text; }
    else if (p === 'minutes.topic') view.minutes.topic = text;
  }
  return view;
}

// applyOverrides 的反向：某个位置现在显示什么。路径集合和 applyOverrides 一致，认不出返回 undefined。
function valueAt(view, p) {
  const seg = p.split('.');
  try {
    if (p === 'insights_md') return view.insightsMd;
    if (seg[0] === 'changes') return view.changes[Number(seg[1])] && view.changes[Number(seg[1])].text;
    if (seg[0] === 'insights') { const i = view.insights.find(x => String(x.n) === seg[1]); return i ? i[seg[2]] : undefined; }
    if (seg[0] === 'next') return view.next ? view.next[seg[1]] : undefined;
    if (seg[0] === 'summary') return view.minutes.conclusions[Number(seg[1])];
    if (p === 'minutes.topic') return view.minutes.topic;
  } catch (e) {}
  return undefined;
}

// 「发」过没有：先读 person-handoff 的已发索引（一人一批，按 sourceId 记），没有再退到旧的单条收据（key = ['person-handoff', 会议, sourceId]）
function sentState(dataDir, meetingId, sourceId) {
  if (!dataDir) return null;
  try { const s = personHandoff.sentState(dataDir, meetingId, sourceId); if (s) return s; } catch (e) {}
  try {
    const k = sendGate.hash(['person-handoff', meetingId, sourceId]);
    const j = JSON.parse(fs.readFileSync(path.join(dataDir, 'state', 'send-receipts', 'person-handoff', k + '.json'), 'utf8'));
    if (j && j.status === 'sent') return { at: j.at || 0, partial: !!j.partial, person: (j.assignee && j.assignee.name) || '', taskUrl: (j.task && j.task.url) || '' };
  } catch (e) {}
  return null;
}

// meeting-result 返回前经这里：加 view（含 override），原字段一个不动
function decorate(result, { dataDir } = {}) {
  if (!result || typeof result !== 'object') return result;
  let view;
  try { view = applyOverrides(buildView(result), result.overrides); } catch (e) { return result; }
  const mid = String(result.id || '');
  // sourceId 按「负责人|动作」取哈希，洞察重跑换了顺序也对得上。0.6.18 前的收据按序号记（legacyId），
  // 只在收件人和这张卡负责人一致时才认，免得把别人的已发挂到这张卡上，也免得真发过的卡被当成没发再发一次
  const own = (x) => { const s = sentState(dataDir, mid, x.sourceId); if (s) return s;
    const l = x.legacyId && sentState(dataDir, mid, x.legacyId); return l && l.person && l.person === x.owner ? l : null; };
  for (const i of view.insights) i.sent = own(i);
  if (view.next) view.next.sent = own(view.next);
  return { ...result, view };
}

// PATCH /asr-relay/archive-edit {id, path, text}：写 enhanced.overrides[path]（text 为空 = 撤掉这条 override）
async function editRoute(req, res, { authed, pipeline, dataDir, log = () => {} }) {
  const reply = (code, j) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(j)); };
  if (!authed) { res.writeHead(401); return res.end('unauthorized'); }
  if (req.method !== 'PATCH') { res.writeHead(405); return res.end('method not allowed'); }
  let raw = '';
  try { for await (const c of req) { raw += c; if (Buffer.byteLength(raw) > 65536) throw Error('内容过长'); } } catch (e) { return reply(400, { ok: false, error: e.message }); }
  let j; try { j = JSON.parse(raw || '{}'); } catch (e) { return reply(400, { ok: false, error: '格式不对' }); }
  const id = String(j.id || '').trim(), p = String(j.path || '').trim();
  if (!okId(id)) return reply(400, { ok: false, error: '会议编号不对' });
  if (!PATH_RE.test(p)) return reply(400, { ok: false, error: '不认识这个位置：' + p.slice(0, 40) });
  if (typeof j.text !== 'string') return reply(400, { ok: false, error: '缺 text' });
  // insights_md 是军师自由 markdown 正文，跟 .answer 一样只 trim 不 oneLine——oneLine 会把换行压成空格，编辑保存后格式就没了（Codex 审计 2026-09-24）
  const text = ((p.endsWith('.answer') || p === 'insights_md') ? j.text.trim() : oneLine(j.text)).slice(0, 2000);
  // 自我进化 1b：改之前这个位置显示的是什么（模型稿或他上次改的），和这次的终稿一起存样本。读不到就只存终稿。
  let before = null;
  try { const cur = pipeline.result(id); if (cur) before = valueAt(applyOverrides(buildView(cur), cur.overrides), p); } catch (e) {}
  try {
    const session = pipeline.patchResult(id, { overrides: { [p]: text || null } });
    log('archive-edit ' + id + ' ' + p + ' ' + (text ? text.length + ' 字' : '撤回'));
    // 原稿读不到（pipeline 没 result() / 视图构建抛错）不静默：标 originalMissing，回放对照时能分出「没原稿」和「原稿为空」（Codex 10-24）
    if (dataDir) editSamples.record(dataDir, { kind: 'archive', meetingId: id, path: p, original: typeof before === 'string' ? before : null, final: text, undo: !text, ...(typeof before === 'string' ? {} : { originalMissing: true }) });
    return reply(200, { ok: true, path: p, text, view: decorate(session, { dataDir }).view });
  } catch (e) { return reply(e.code === 404 ? 404 : 500, { ok: false, error: String(e.message || e).slice(0, 200) }); }
}

module.exports = { buildView, topicTable, TOPIC_STATUS, applyOverrides, valueAt, parseSummary, decorate, editRoute, sentState, PATH_RE };
