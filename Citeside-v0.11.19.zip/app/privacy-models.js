'use strict';
// Max 隐私与模型通道配置（零留存专线 ZDR / 本机离线 ASR+LLM / BYOK / 4 件套隐私锁）。
// 所有字段均为非敏感开关或本地 loopback 地址，绝不保存第三方密钥（密钥走 app/secret-store.js）。
const { execFileSync } = require('child_process');
const http = require('http');

const ZDR_PROVIDERS = Object.freeze([
  Object.freeze({ id: 'vertex', name: 'Google Vertex AI', available: true, region: 'us-central1' }),
  Object.freeze({ id: 'bedrock', name: 'AWS Bedrock', available: false, region: '' }),
  Object.freeze({ id: 'azure', name: 'Azure OpenAI', available: false, region: '' })
]);

const ROUTE_MODES = new Set(['', 'zdr', 'local', 'byok']);
const ZDR_IDS = new Set(['vertex', 'bedrock', 'azure']);
const ASR_ENGINES = new Set(['mac', 'whisper', 'mlx']);
const RETENTION_DAYS = new Set(['0', '7', '30']);

function whichSync(bin) {
  try {
    const out = execFileSync('/usr/bin/which', [bin], { encoding: 'utf8', timeout: 800, stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    return out || '';
  } catch {
    return '';
  }
}

function probeLocalJson(url, timeoutMs = 1500) {
  return new Promise(resolve => {
    let settled = false;
    const done = val => { if (!settled) { settled = true; resolve(val); } };
    try {
      const req = http.get(url, { timeout: timeoutMs }, res => {
        if (res.statusCode < 200 || res.statusCode >= 300) { res.resume(); return done(null); }
        let raw = '';
        res.setEncoding('utf8');
        res.on('data', chunk => { raw += chunk; if (raw.length > 256 * 1024) req.destroy(); });
        res.on('end', () => { try { done(JSON.parse(raw)); } catch { done(null); } });
      });
      req.on('timeout', () => { req.destroy(); done(null); });
      req.on('error', () => done(null));
    } catch {
      done(null);
    }
  });
}

async function scanLocalModels(c = {}, { probe = probeLocalJson, checkBin = whichSync } = {}) {
  const [ollamaRes, lmsRes] = await Promise.all([
    probe('http://127.0.0.1:11434/api/tags'),
    probe('http://127.0.0.1:1234/v1/models')
  ]);
  const ollama = Array.isArray(ollamaRes?.models)
    ? ollamaRes.models.map(m => String(m?.name || m?.model || '').trim()).filter(Boolean)
    : [];
  const lmstudio = Array.isArray(lmsRes?.data)
    ? lmsRes.data.map(m => String(m?.id || '').trim()).filter(Boolean)
    : [];
  const models = [
    ...ollama.map(id => ({ provider: 'ollama', endpoint: 'http://127.0.0.1:11434/v1', id, label: `Ollama · ${id}` })),
    ...lmstudio.map(id => ({ provider: 'lmstudio', endpoint: 'http://127.0.0.1:1234/v1', id, label: `LM Studio · ${id}` }))
  ];
  let macAsr = false;
  try { macAsr = !!require('./mac-asr').available(); } catch {}
  const activeEngine = ASR_ENGINES.has(c.LOCAL_ASR_ENGINE) ? c.LOCAL_ASR_ENGINE : 'mac';
  const asrEngines = [
    { id: 'mac', label: 'Apple Speech (macOS)', installed: macAsr, active: activeEngine === 'mac' },
    { id: 'mlx', label: 'Apple Silicon MLX', installed: !!checkBin('mlx_whisper'), active: activeEngine === 'mlx' },
    { id: 'whisper', label: 'whisper.cpp', installed: !!(checkBin('whisper-cli') || checkBin('whisper-cpp')), active: activeEngine === 'whisper' }
  ];
  return { ok: true, ollama, lmstudio, models, asrEngines, scannedAt: Date.now() };
}

function publicPrivacyState(c = {}) {
  const routeMode = ROUTE_MODES.has(c.PRIVACY_ROUTE_MODE) ? c.PRIVACY_ROUTE_MODE : '';
  const zdrProvider = ZDR_IDS.has(c.ZDR_PROVIDER) ? c.ZDR_PROVIDER : 'vertex';
  const localAsrEngine = ASR_ENGINES.has(c.LOCAL_ASR_ENGINE) ? c.LOCAL_ASR_ENGINE : 'mac';
  const notesRetentionDays = RETENTION_DAYS.has(String(c.NOTES_RETENTION_DAYS || '0')) ? String(c.NOTES_RETENTION_DAYS || '0') : '0';
  return {
    routeMode,
    zdrProvider,
    zdrProviders: ZDR_PROVIDERS,
    localAsrEngine,
    localLlmEndpoint: String(c.LOCAL_LLM_ENDPOINT || ''),
    localLlmModel: String(c.LOCAL_LLM_MODEL || ''),
    forbidShare: c.FORBID_SHARE === 'on',
    notesRetentionDays,
    silentMemory: c.SILENT_MEMORY === 'off'
  };
}

function applyPrivacyPatch(current, patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw Error('隐私配置格式不正确');
  const allowed = new Set(['routeMode', 'zdrProvider', 'localAsrEngine', 'localLlmEndpoint', 'localLlmModel', 'forbidShare', 'notesRetentionDays', 'privateMeeting']);
  for (const k of Object.keys(patch)) {
    if (!allowed.has(k)) throw Error('未知隐私字段: ' + k);
  }
  const next = { ...current };
  if (patch.routeMode !== undefined) {
    const v = String(patch.routeMode || '');
    if (!ROUTE_MODES.has(v)) throw Error('通道模式无效');
    next.PRIVACY_ROUTE_MODE = v;
  }
  if (patch.zdrProvider !== undefined) {
    const v = String(patch.zdrProvider || '');
    if (!ZDR_IDS.has(v)) throw Error('零留存通道无效');
    next.ZDR_PROVIDER = v;
  }
  if (patch.localAsrEngine !== undefined) {
    const v = String(patch.localAsrEngine || '');
    if (!ASR_ENGINES.has(v)) throw Error('本机语音引擎无效');
    next.LOCAL_ASR_ENGINE = v;
  }
  if (patch.localLlmEndpoint !== undefined) {
    const v = String(patch.localLlmEndpoint || '').trim();
    if (v) {
      let u;
      try { u = new URL(v); } catch { throw Error('本机模型地址格式无效'); }
      if (!['http:', 'https:'].includes(u.protocol) || !['127.0.0.1', 'localhost'].includes(u.hostname)) {
        throw Error('本机离线模式仅允许 127.0.0.1 / localhost 地址');
      }
    }
    next.LOCAL_LLM_ENDPOINT = v;
  }
  if (patch.localLlmModel !== undefined) {
    const v = String(patch.localLlmModel || '').trim().slice(0, 120);
    if (/[\r\n]/.test(v)) throw Error('本机模型名称无效');
    next.LOCAL_LLM_MODEL = v;
  }
  if (patch.forbidShare !== undefined) {
    if (typeof patch.forbidShare !== 'boolean') throw Error('禁止分享锁参数无效');
    next.FORBID_SHARE = patch.forbidShare ? 'on' : 'off';
  }
  if (patch.notesRetentionDays !== undefined) {
    const v = String(patch.notesRetentionDays);
    if (!RETENTION_DAYS.has(v)) throw Error('纪要自动清空周期仅支持 0 / 7 / 30 天');
    next.NOTES_RETENTION_DAYS = v;
  }
  if (patch.privateMeeting !== undefined) {
    if (typeof patch.privateMeeting !== 'boolean') throw Error('私密会议开关参数无效');
    // privateMeeting=true maps to SILENT_MEMORY='off' (do not write to cross-meeting memory pool)
    next.SILENT_MEMORY = patch.privateMeeting ? 'off' : 'on';
  }
  return next;
}

async function revokeAllShares(cloudAccount) {
  if (!cloudAccount?.shares || !cloudAccount?.revokeShare) {
    return { ok: true, revoked: 0, total: 0, note: 'local_only' };
  }
  const list = await cloudAccount.shares();
  if (!list?.ok) {
    if (list?.code === 'unauthorized') return { ok: false, code: 'unauthorized', error: '请先登录账号再撤回云端分享链接。' };
    return { ok: false, code: list?.code || 'shares_unavailable', error: '暂时无法读取云端分享列表，请稍后重试。' };
  }
  const active = (Array.isArray(list.shares) ? list.shares : []).filter(s => s && s.token && !s.revokedAt);
  let revoked = 0;
  for (const item of active) {
    const r = await cloudAccount.revokeShare({ token: item.token });
    if (r?.ok) revoked++;
  }
  return { ok: true, revoked, total: active.length };
}

module.exports = { ZDR_PROVIDERS, scanLocalModels, publicPrivacyState, applyPrivacyPatch, revokeAllShares };
