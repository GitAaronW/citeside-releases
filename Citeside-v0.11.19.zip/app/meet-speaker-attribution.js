'use strict';
// Google Meet active-speaker attribution and dual-track Mic/System clock alignment.
// Mechanism references only (permissive MIT; zero third-party code or binaries copied):
// - tmandry/AXSwift https://github.com/tmandry/AXSwift (MIT) and Chromium AXManualAccessibility
// - screenpipe/screenpipe https://github.com/screenpipe/screenpipe (MIT) dual-track Mic/System audio clock alignment
// - recallai/chrome-recording-transcription-extension https://github.com/recallai/chrome-recording-transcription-extension (MIT)
//   Google Meet participant tile and active-speaker DOM/ARIA structure
const crypto = require('crypto');

const SPEAKING_RE = /\bis speaking\b|\bspeaking\b|正在发言|正在讲话|发言中/i;
const BADGE_RE = /voice-level|voice level|active-speaker|active speaker/i;
const CAPTION_RE = /captions|字幕/i;
const MEETING_CODE_RE = /^[a-z]{3}-[a-z]{4}-[a-z]{3}$/i;
const CLOCK_RE = /^\d{1,2}:\d{2}(\s*[AP]M)?$/i;
const PLUS_RE = /^\+\d+$/;
const WINDOW_MS = 10 * 60 * 1000;
const MAX_ENTRIES = 3000;
const MAX_PARTICIPANTS = 40;

const REJECT_EXACT = new Set([
  'you', '你', '(you)', '（你）', 'me',
  'presentation', 'your presentation', '正在演示', '屏幕共享',
  'mute', 'unmute', 'turn on microphone', 'turn off microphone',
  'pin', 'more options', 'raise hand', 'leave call',
  'people', 'chat', 'activities', 'host controls',
  '静音', '取消静音', '置顶', '更多选项', '举手', '退出通话',
  'captions', 'closed captions', 'live captions', '字幕', '实时字幕',
]);

function displayName(value) {
  return String(value == null ? '' : value).normalize('NFKC').replace(/\s+/g, ' ').trim();
}

function normalizeKey(value) {
  return displayName(value).toLowerCase();
}

function isSelfLabel(value) {
  const shown = displayName(value);
  const key = normalizeKey(shown);
  if (!key || REJECT_EXACT.has(key)) return true;
  if (/\((?:you|me)\)$/i.test(key)) return true;
  if (/（(?:你|我)）$/.test(shown)) return true;
  return false;
}

function rejected(value) {
  const shown = displayName(value);
  const key = normalizeKey(shown);
  if (!key || isSelfLabel(shown)) return true;
  if (MEETING_CODE_RE.test(key) || CLOCK_RE.test(shown) || PLUS_RE.test(key)) return true;
  return false;
}

function looksLikeName(value) {
  const shown = displayName(value);
  if (!shown || rejected(shown)) return false;
  if (SPEAKING_RE.test(shown) || BADGE_RE.test(shown)) return false;
  if ([...shown].length > 48) return false;
  if (/[。！？?!.;；]/.test(shown)) return false;
  if (shown.split(' ').length > 6) return false;
  return true;
}

function nameFromSpeakingLabel(value) {
  const shown = displayName(value);
  if (!shown || !SPEAKING_RE.test(shown)) return '';
  const stripped = displayName(shown.replace(SPEAKING_RE, '').replace(/\bis$/i, ''));
  return looksLikeName(stripped) ? stripped : '';
}

function nodeTexts(node) {
  if (!node || typeof node !== 'object') return [];
  const out = [];
  for (const key of ['title', 'description', 'value', 'label']) {
    const text = displayName(node[key]);
    if (text) out.push(text);
  }
  return out;
}

function isGroupNode(node) {
  const role = String(node && (node.role || node.subrole) || '');
  return /group|region/i.test(role);
}

function isBadge(text) {
  return SPEAKING_RE.test(text) || BADGE_RE.test(text);
}

function parseMeetAxTree(rootNode) {
  const activeSpeakers = [];
  const participants = [];
  const seenActive = new Set();
  const seenParticipants = new Set();
  const addParticipant = (name) => {
    const shown = displayName(name);
    const key = normalizeKey(shown);
    if (!looksLikeName(shown) || seenParticipants.has(key)) return;
    seenParticipants.add(key);
    participants.push(shown);
  };
  const addActive = (name) => {
    const shown = displayName(name);
    const key = normalizeKey(shown);
    if (!looksLikeName(shown) || seenActive.has(key)) return;
    seenActive.add(key);
    activeSpeakers.push(shown);
    addParticipant(shown);
  };
  const roots = Array.isArray(rootNode) ? rootNode : (rootNode && typeof rootNode === 'object' ? [rootNode] : []);

  const walk = (node, inCaption) => {
    if (!node || typeof node !== 'object') return;
    const texts = nodeTexts(node);
    const caption = inCaption || (isGroupNode(node) && texts.some(text => CAPTION_RE.test(text)));
    for (const text of texts) {
      const named = nameFromSpeakingLabel(text);
      if (named) addActive(named);
    }
    const children = Array.isArray(node.children) ? node.children : [];
    if (caption) {
      const headers = [];
      const scan = (current, depth) => {
        if (!current || typeof current !== 'object' || depth > 6) return;
        const role = String(current.role || '');
        if (/heading|statictext/i.test(role)) {
          for (const text of nodeTexts(current)) {
            const named = nameFromSpeakingLabel(text);
            if (named) addActive(named);
            else if (looksLikeName(text) && !CAPTION_RE.test(text)) headers.push(displayName(text));
          }
        }
        for (const child of (Array.isArray(current.children) ? current.children : [])) scan(child, depth + 1);
      };
      scan(node, 0);
      if (headers.length) addActive(headers[0]);
    } else if (isGroupNode(node)) {
      const names = [];
      let speaking = texts.some(isBadge);
      const consider = (current) => {
        const local = nodeTexts(current);
        if (local.some(isBadge)) speaking = true;
        for (const text of local) {
          if (nameFromSpeakingLabel(text) || isBadge(text)) speaking = true;
          else if (looksLikeName(text)) names.push(displayName(text));
        }
      };
      consider(node);
      for (const child of children) {
        if (!child || typeof child !== 'object' || isGroupNode(child)) continue;
        consider(child);
      }
      const unique = [];
      const seen = new Set();
      for (const name of names) {
        const key = normalizeKey(name);
        if (seen.has(key)) continue;
        seen.add(key);
        unique.push(name);
      }
      if (speaking && unique.length === 1) addActive(unique[0]);
      else for (const name of unique) addParticipant(name);
    }
    for (const child of children) walk(child, caption);
  };
  for (const root of roots) walk(root, false);
  return { activeSpeakers, participants };
}

function speakerKey(name) {
  const hex = crypto.createHash('sha1').update(normalizeKey(name)).digest('hex').slice(0, 8);
  return 'meet-' + hex;
}

function clampMeConfidence(micRms, sysRms) {
  const gap = Math.max(0, micRms - 0.0035);
  const ratio = sysRms > 0 ? micRms / sysRms : 4;
  const raw = 0.86 + Math.min(0.08, gap * 4) + Math.min(0.04, Math.max(0, ratio - 2.6) * 0.02);
  return Math.max(0.86, Math.min(0.98, raw));
}

function overlapMs(start, end, winStart, winEnd) {
  const left = Math.max(start, winStart);
  const right = Math.min(end, winEnd);
  if (right < left) return 0;
  return right === left ? 1 : right - left;
}

function selfNameSet(opts) {
  let list = [];
  try {
    const source = opts && opts.selfNames;
    const value = typeof source === 'function' ? source() : source;
    if (Array.isArray(value)) list = value;
  } catch (e) { list = []; }
  const keys = new Set();
  for (const name of list) {
    const key = normalizeKey(name);
    if (key) keys.add(key);
  }
  return keys;
}

function createSessionAttribution(opts = {}) {
  const audio = [];
  const meet = [];
  const participantOrder = [];
  const participantSeen = new Set();
  let latest = 0;
  const clock = () => (typeof opts.now === 'function' ? opts.now() : Date.now());

  const prune = (at) => {
    if (Number.isFinite(at)) latest = Math.max(latest, at);
    const cutoff = latest - WINDOW_MS;
    while (audio.length && audio[0].end < cutoff) audio.shift();
    while (meet.length && meet[0].atMs < cutoff) meet.shift();
    while (audio.length > MAX_ENTRIES) audio.shift();
    while (meet.length > MAX_ENTRIES) meet.shift();
  };

  const rememberParticipant = (name) => {
    const shown = displayName(name);
    const key = normalizeKey(shown);
    if (!looksLikeName(shown) || participantSeen.has(key)) return;
    participantSeen.add(key);
    participantOrder.push(shown);
    if (participantOrder.length > MAX_PARTICIPANTS) {
      const dropped = participantOrder.shift();
      participantSeen.delete(normalizeKey(dropped));
    }
  };

  const ingestAudioTrack = (packet = {}) => {
    const capturedAtMs = Number(packet.capturedAtMs);
    if (!Number.isFinite(capturedAtMs)) return;
    const durationMs = Number.isFinite(Number(packet.durationMs)) ? Number(packet.durationMs) : 200;
    const hasSys = Object.prototype.hasOwnProperty.call(packet, 'sysRms') && packet.sysRms !== null && packet.sysRms !== '' && Number.isFinite(Number(packet.sysRms));
    audio.push({
      start: capturedAtMs,
      end: capturedAtMs + Math.max(0, durationMs),
      mic: Number.isFinite(Number(packet.micRms)) ? Number(packet.micRms) : 0,
      sys: hasSys ? Number(packet.sysRms) : 0,
      sysPresent: hasSys,
    });
    prune(capturedAtMs + Math.max(0, durationMs));
  };

  const ingestMeetObservation = (observation = {}) => {
    const atMs = Number(observation.atMs);
    if (!Number.isFinite(atMs) || meet.some(item => item.atMs === atMs)) return;
    const activeSpeakers = (Array.isArray(observation.activeSpeakers) ? observation.activeSpeakers : []).map(displayName).filter(looksLikeName);
    const participants = (Array.isArray(observation.participants) ? observation.participants : []).map(displayName).filter(looksLikeName);
    meet.push({
      atMs,
      activeSpeakers,
      participants,
      accessibilityTrusted: observation.accessibilityTrusted ?? null,
    });
    for (const name of [...activeSpeakers, ...participants]) rememberParticipant(name);
    prune(atMs);
  };

  const attributeRemote = (startWallMs, endWallMs, updatedAt) => {
    const self = selfNameSet(opts);
    const weights = new Map();
    let total = 0;
    for (const item of meet) {
      if (item.atMs < startWallMs - 300 || item.atMs > endWallMs + 300) continue;
      const names = item.activeSpeakers.filter(name => !self.has(normalizeKey(name)));
      if (!names.length) continue;
      const share = 1 / names.length;
      for (const name of names) {
        const key = normalizeKey(name);
        const prev = weights.get(key) || { name, weight: 0 };
        prev.weight += share;
        weights.set(key, prev);
        total += share;
      }
    }
    let best = null;
    for (const item of weights.values()) if (!best || item.weight > best.weight) best = item;
    if (best && total > 0 && best.weight / total >= 0.65) {
      const id = speakerKey(best.name);
      return {
        channel: 'them',
        speaker: id,
        displayName: best.name,
        speakerIdentity: { id, name: best.name, source: 'google_meet_ax' },
        ownerAttribution: { candidate: false, source: 'native_dual_track', confidence: 0.9, correctedByUser: false, updatedAt },
        source: 'google_meet_ax',
      };
    }
    return null;
  };

  const themFallback = (updatedAt) => ({
    channel: 'them',
    speaker: 'them',
    ownerAttribution: { candidate: false, source: 'native_dual_track', confidence: 0.85, correctedByUser: false, updatedAt },
    source: 'native_dual_track',
  });

  const resolveUtterance = ({ startWallMs, endWallMs, echoHit = false } = {}) => {
    const updatedAt = clock();
    if (echoHit) return { channel: 'them', speaker: 'them', confidence: 0.9, source: 'echo_guard' };
    const winStart = Number(startWallMs) - 120;
    const winEnd = Number(endWallMs) + 120;
    let micWeighted = 0;
    let sysWeighted = 0;
    let weight = 0;
    let any = false;
    let allSys = true;
    if (Number.isFinite(winStart) && Number.isFinite(winEnd)) {
      for (const packet of audio) {
        const span = overlapMs(packet.start, packet.end, winStart, winEnd);
        if (span <= 0) continue;
        any = true;
        if (!packet.sysPresent) allSys = false;
        weight += span;
        micWeighted += packet.mic * span;
        sysWeighted += packet.sys * span;
      }
    }
    const micRms = weight ? micWeighted / weight : 0;
    const sysRms = weight ? sysWeighted / weight : 0;
    const sysMissing = !any || !allSys;
    if (!sysMissing && micRms >= 0.0035 && (sysRms < 0.0012 || micRms >= sysRms * 2.6)) {
      return {
        channel: 'me',
        speaker: 'me',
        ownerAttribution: { candidate: true, source: 'native_dual_track', confidence: clampMeConfidence(micRms, sysRms), correctedByUser: false, updatedAt },
        source: 'native_dual_track',
      };
    }
    let channel = 'unknown';
    if (!sysMissing && sysRms >= 0.0028 && (micRms < 0.0018 || sysRms >= micRms * 1.3)) channel = 'them';
    else if (!sysMissing) return { channel: 'unknown', speaker: '', ownerAttribution: null };
    const timeline = channel === 'them' || (channel === 'unknown' && opts.allowTimelineOnly === true && sysMissing);
    if (!timeline) return { channel: 'unknown', speaker: '', ownerAttribution: null };
    const named = Number.isFinite(Number(startWallMs)) && Number.isFinite(Number(endWallMs))
      ? attributeRemote(Number(startWallMs), Number(endWallMs), updatedAt) : null;
    if (named) return named;
    if (channel === 'them') return themFallback(updatedAt);
    return { channel: 'unknown', speaker: '', ownerAttribution: null };
  };

  return {
    ingestAudioTrack,
    ingestMeetObservation,
    resolveUtterance,
    knownParticipants() { return participantOrder.slice(0, MAX_PARTICIPANTS); },
  };
}

module.exports = { parseMeetAxTree, speakerKey, createSessionAttribution };
