'use strict';
const crypto=require('crypto');
const names={question:['问题','Questions'],solution:['方案','Options'],progress:['进展','Progress'],blocker:['阻塞','Blockers'],decision:['决定','Decisions'],action:['待办','To-dos'],risk:['风险','Risks'],notes:['记录','Notes']};
const aliases={question:/^(问题|我们要解决什么|Questions?|Problem)$/i,solution:/^(方案|方案与取舍|当前建议|Options?(?: and trade-offs)?|Solution|Current recommendation)$/i,progress:/^(进展|Progress|Updates?)$/i,blocker:/^(阻塞|阻碍|Blockers?)$/i,decision:/^(决定|决议|Decisions?)$/i,action:/^(待办(?:事项)?|行动项?|验证与下一步|To[ -]?dos?|Actions?|Validation and next steps)$/i,risk:/^(风险|Risks?)$/i};
const text=n=>n.text||(n.content||[]).map(text).join('');
function meetingType(session={}){
 if(session.trial||/^(试音|试听|Trial|Sound check)$/i.test(session.title||'')||/^trial-/.test(session.id||''))return 'trial';
 const frame=String(session.meetingFrame?.type||session.nativeInsights?.understanding?.frame?.type||'');
 const classify=value=>/working[\s_-]*(?:1\s*[:：]\s*1|one.on.one)/i.test(value)?'working-1:1':/面试|招聘|job[ -]?interview|candidate[ -]?interview/i.test(value)?'job-interview':/访谈|interview/i.test(value)?'interview':/1\s*[:：]\s*1|一对一/i.test(value)?'working-1:1':/信息同步|同步|例会|daily|sync/i.test(value)?'sync':/评审|review/i.test(value)?'review':/命题|讨论|discussion|debate/i.test(value)?'discussion':null;
 return classify(frame)||classify([session.title,session.calendar?.event?.title,session.calendar?.title].filter(Boolean).join(' '))||'discussion';
}
function section(module,type){
 const explicit=module.documentSection||module.cardType||module.kind;
 const kinds={task:'action',plan:'solution',conflict:'blocker'};
 if(names[kinds[explicit]||explicit])return kinds[explicit]||explicit;
 const candidates=[String(module.title||''),...String(module.body||'').split('\n').filter(s=>/^#{1,3} /.test(s)).map(s=>s.replace(/^#+\s*/,''))];
 // Meeting type changes only the preference among evidenced sections, never creates empty headings.
 const order=type==='sync'?['progress','blocker','action','decision','risk','question','solution']:type==='review'?['decision','risk','blocker','solution','question','action','progress']:['question','solution','progress','blocker','decision','action','risk'];
 const tagged=order.find(k=>candidates.some(s=>aliases[k].test(s.trim())));if(tagged)return tagged;
 const body=String(module.title||'')+'\n'+String(module.body||'');
 const cues={question:/(?:^|[。\n])(?:问题[：:]|待确认[：:])/,solution:/(?:^|[。\n])(?:方案|建议方案)[：:]/,progress:/(?:^|[。\n])(?:进展[：:]|已完成|已经完成)/,blocker:/(?:^|[。\n])(?:阻塞[：:]|卡在|被.+阻塞)/,decision:/(?:^|[。\n])(?:会上|我们|大家)?(?:已)?决定[：:]?/,action:/(?:^|[。\n])(?:待办|行动项)[：:]/,risk:/(?:^|[。\n])风险[：:]/};
 return order.find(k=>cues[k].test(body))||'notes';
}
function heading(label,sourceRef){return {type:'heading',attrs:{level:2,sourceRef,blockId:'b-'+crypto.randomBytes(8).toString('hex')},content:[{type:'text',text:label}]};}
function evidenceIndex(content){return content.content.findIndex(b=>b.type==='heading'&&(b.attrs?.sourceRef==='solution-section:4'||/^(依据与修订记录|依据|Evidence and revisions|Evidence)$/.test(text(b).trim())));}
function bodyEnd(content){const i=evidenceIndex(content);return i<0?content.content.length:i;}
function parts(block,module){
 const groups=[];let current=null;
 for(const node of block.content||[]){
  const key=node.type==='heading'?Object.keys(aliases).find(k=>aliases[k].test(text(node).trim())):null;
  if(key){current={key,nodes:[]};groups.push(current);}else if(!current){current={key:null,nodes:[]};groups.push(current);}
  current.nodes.push(node);
 }
 const meaningful=groups.filter(g=>g.nodes.some(n=>n.type!=='heading'&&text(n).trim()));
 if(meaningful.filter(g=>g.key).length<2)return [{block,module}];
 return meaningful.map((g,i)=>({module:{...module,...(g.key?{documentSection:g.key}:{})},block:{...block,attrs:{...block.attrs,blockId:i?block.attrs.blockId+'-'+i:block.attrs.blockId},content:g.nodes}}));
}
function insert(content,block,module,record){
 if(!record.contentDriven){content.content.splice(bodyEnd(content),0,block);return;}
 const en=record.lang==='en',key=section(module,module.documentMeetingType||'discussion');
 if(evidenceIndex(content)<0)content.content.push(heading(en?'Evidence':'依据','solution-section:4'),{type:'paragraph'});
 let start=content.content.findIndex(b=>b.type==='heading'&&b.attrs?.sourceRef==='meeting-section:'+key);
 if(start<0){start=bodyEnd(content);content.content.splice(start,0,heading(names[key][en?1:0],'meeting-section:'+key));}
 let end=start+1;while(end<content.content.length&&!(content.content[end].type==='heading'&&content.content[end].attrs.level<=2))end++;
 content.content.splice(end,0,block);
}
module.exports={meetingType,section,insert,bodyEnd,parts};
