'use strict';
// Reads only notes/transcript attachments on the explicitly selected calendar event.
// Calendar Events.get uses existing calendar.events.readonly; Drive auth remains separate.
const {parseDriveSource,readDriveDocument}=require('./google-materials');
async function read(ctx,event){
 if(!ctx.googleCalendar?.readEvent)throw Object.assign(Error('Google calendar is not connected'),{notesState:'unauthorized'});
 const original=await ctx.googleCalendar.readEvent(event.eventId,event.calendarId),notes=[];
 for(const attachment of original.attachments||[]){
  if(!/(?:notes|transcript|minutes|纪要|转写|逐字稿)/i.test(attachment.title||''))continue;
  let source;try{source=parseDriveSource(attachment.fileUrl);}catch{continue;}
  if(source.kind!=='document'||attachment.fileId&&attachment.fileId!==source.id)continue;
  const value=await (ctx.readDriveDocument||readDriveDocument)(ctx.dataDir,source.url);
  if(!value.available)throw Object.assign(Error('Google Drive read connection is not authorized'),{notesState:'unauthorized'});
  if(value.coverage?.complete!==true||!value.version||typeof value.text!=='string'||!value.text.trim()||value.text.length>100000)throw Error('Complete Google notes are not available');
  notes.push({url:source.url,title:attachment.title,text:value.text,reader:'google.docs.read',remoteRevision:value.version,docId:source.id,noteId:source.id,meetingId:original.conferenceData?.conferenceId||'',kind:/transcript|转写|逐字稿/i.test(attachment.title)?'transcript':'notes'});
 }
 const current=await ctx.googleCalendar.readEvent(event.eventId,event.calendarId);
 if(current.etag!==original.etag)throw Error('Google calendar event changed during notes read');
 return notes.map(note=>({...note,eventRevision:original.etag,identity:'user'}));
}
module.exports={read};
