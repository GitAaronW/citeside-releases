'use strict';
// Custom user-configured MCP bridge, not native Zoom OAuth. Only session-selected
// project-compatible sources scoped to the exact chosen calendar event are read.
const sources=require('./context-sources'),mcp=require('./mcp-context-source');
async function read(ctx,event,session){
 const selected=sources.select(ctx.dataDir,{projectId:session.projectId||'',ids:session.contextSourceIds||[]}).sources.filter(s=>s.type==='mcp'&&s.mcp.selectedScope===event.eventId);
 if(!selected.length)throw Object.assign(Error('No session-selected custom MCP notes bridge for this event'),{notesState:'unauthorized'});
 let selectedMeetingId='';try{const join=new URL(event.meetingUrl||event.url||'');if(join.protocol==='https:'&&/(^|\.)zoom\.us$/.test(join.hostname)&&!join.username&&!join.password&&!join.port)selectedMeetingId=join.pathname.match(/^\/j\/(\d{9,11})(?:\/|$)/)?.[1]||'';}catch{}
 const notes=[];
 for(const source of selected){
  const connection=ctx.mcpNotesClient?ctx.mcpNotesClient(source):require('./notion-mcp-bridge').http({url:mcp.endpoint(source.path)});let metadata,key;
  const client={close:()=>connection.close(),async rpc(method,args,notify){const result=await connection.rpc(method,args,notify);if(method==='tools/call'){const next=result?.structuredContent?.metadata,signature=JSON.stringify(next);if(key!==undefined&&signature!==key)throw Error('Notes identity changed during read');key=signature;metadata=next;}return result;}};
  const value=await mcp.readMcpSource(ctx.dataDir,source,{client,signal:ctx.signal});
  if(!value.available)throw Object.assign(Error(value.error||'MCP notes read failed'),{notesState:value.state==='denied'?'unauthorized':'failed'});
  if(!value.text.trim()||value.text.length>100000)throw Error('Complete notes exceed import limit');
  const valid=!!selectedMeetingId&&metadata?.meetingId===selectedMeetingId&&metadata?.provider==='zoom'&&metadata.identity==='user'&&metadata.eventId===event.eventId&&metadata.calendarId===event.calendarId&&typeof metadata.meetingId==='string'&&metadata.meetingId&&typeof metadata.noteId==='string'&&metadata.noteId&&['notes','transcript'].includes(metadata.kind);
  let url;try{url=new URL(metadata?.url);if(url.protocol!=='https:'||url.username||url.password||url.port||!/(^|\.)zoom\.us$/.test(url.hostname))throw Error();}catch{throw Error('Custom MCP notes source URL is missing or invalid');}
  notes.push({url:url.href,title:source.title,text:value.text,reader:'mcp.notes.read',remoteRevision:value.version,identity:valid?'user':'unverified',meetingId:valid?metadata.meetingId:'',noteId:metadata?.noteId||'',kind:metadata?.kind||'notes',provider:'zoom',bridgeSourceId:source.id,bridgeBinding:value.receipt.binding});
 }
 return notes;
}
module.exports={read};
