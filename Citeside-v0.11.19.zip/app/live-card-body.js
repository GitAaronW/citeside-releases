'use strict';
// One wording contract for every live preview; templates resolve these tokens at load time.
const RULES = Object.freeze({
  zh: '首屏正文合计不超过 44 中文字，开头 4 个字以内点出主体（对象或结论），不用「关于」「根据」「会上提到」「发现：」开头，不重复卡片标签；数字用阿拉伯数字，放在前半句；一条只说一件事，完整证据和细节放在展开层。',
  en: 'Keep the first-screen body at most 24 English words (44 Chinese characters). Name the subject (object or conclusion) within the first 2 English words (4 characters in Chinese). Do not open with About, According to, The meeting mentioned, or Finding: (or their Chinese equivalents); do not repeat the card label. Use Arabic numerals in the first half. Convey one thing per card and place full evidence and details in the expansion drawer.'
});
// Trade-off cards compare two or three options. They are longer than a one-fact card and never replace RULES.
const BEST_PRACTICE_RULES = Object.freeze({
  zh: '允许多方案权衡：2–3 个候选方案对比（方案一/方案1 与 方案二/方案2，或权衡利弊并给出推荐做法），最多 4 句，总字数不超过 140 字。',
  en: 'Allow a 2–3 option trade-off (Option 1 and Option 2, or Approach A and Approach B) with the benefit, the limit, and a recommended combination. At most 4 sentences and 80 English words.'
});
const EXPERT_ADVICE_RULES = Object.freeze({
  zh: '第一句是加粗完整结论，中文不超过 28 字，开头 4 个字以内点出主体，不用「关于」「根据」「会上提到」「发现：」开头；第二句给出一句结合本场条件的具体可执行建议或直接影响（本场适用性按待验证假设表达），不超过 44 字；合计不超过 72 字，最多 2 句。',
  en: 'The first sentence is a bold complete conclusion, at most 18 English words, naming the subject within the first 2 words without opening with About, According to, or Finding:. An optional second sentence gives one concrete actionable recommendation or applicability check for this meeting (framed as a hypothesis to test), at most 28 English words; total at most 46 English words and at most 2 sentences.'
});
function renderPrompt(text) {
  return String(text).replaceAll('{{LIVE_CARD_BODY_RULES_ZH}}', RULES.zh).replaceAll('{{LIVE_CARD_BODY_RULES_EN}}', RULES.en);
}
// Protect decimals, URLs, abbreviations and Markdown before locating sentence ends.
function sentences(body) {
  const spans=[];
  const protectedText=String(body).replace(/https?:\/\/\S+|\b(?:[a-z]\.){2,}|\b(?:Mr|Mrs|Ms|Dr|Prof|Jr|Sr|vs|etc)\.|\d+\.\d+/gi, match => {
    spans.push(match);return '\uE000'+(spans.length-1)+'\uE001';
  });
  return (protectedText.match(/[\s\S]+?(?:[。！？!?]+["'”’」』）)*_`]*|\.(?=\s|$|["'”’」』）)*_`])["'”’」』）)*_`]*|\n|$)/g)||[])
    .map(part=>part.replace(/\uE000(\d+)\uE001/g,(_,i)=>spans[Number(i)]).trim())
    .filter(part=>part.replace(/[\s*_`#>]/g,''));
}
const plain = body => body.replace(/[*_`#>]/g,'').trim();
const english = body => /[a-z]/i.test(body)&&! /\p{Script=Han}/u.test(body);
const words = body => (body.match(/\S+/g)||[]).length;
const MAX_ZH_CHARS = 44;
const MAX_EN_WORDS = 24;
function hasPair(body, first, second) {
  return first.test(body)&&second.test(body);
}
// Explicit multi-option structure, not a single-fact card that happens to be long.
function isMultiOptionTradeoff(body) {
  const text=String(body||'');
  if(!text.trim())return false;
  if(hasPair(text,/\boption\s*1\b/i,/\boption\s*2\b/i))return true;
  if(hasPair(text,/\boption\s*a\b/i,/\boption\s*b\b/i))return true;
  if(hasPair(text,/\bapproach\s*a\b/i,/\bapproach\s*b\b/i))return true;
  if(hasPair(text,/方案\s*[一1]/,/方案\s*[二2]/))return true;
  if(/权衡/.test(text)&&/推荐/.test(text))return true;
  return /\btrade-?offs?\b/i.test(text)&&/\brecommend(?:ed|ation)?\b/i.test(text);
}
function validBestPracticeBody(body) {
  if(typeof body!=='string'||!body.trim())return false;
  const parts=sentences(body).map(plain);
  if(!parts.length||parts.length>4)return false;
  if(english(body))return words(parts.join(' '))<=80;
  return [...parts.join('')].length<=140;
}
function validExpertBody(body) {
  if(typeof body!=='string'||!body.trim())return false;
  const parts=sentences(body).map(plain);
  if(!parts.length||parts.length>2)return false;
  if(english(body))return words(parts[0])<=18&&(!parts[1]||words(parts[1])<=28)&&words(parts.join(' '))<=46;
  return [...parts[0]].length<=28&&(!parts[1]||[...parts[1]].length<=44)&&[...parts.join('')].length<=72;
}
function validBody(body, opts) {
  if(opts?.kind==='best_practice')return validBestPracticeBody(body);
  if(opts?.kind==='external_advice')return validExpertBody(body);
  if(typeof body!=='string'||!body.trim())return false;
  const p=plain(body);
  if(!p)return false;
  if(english(p))return words(p)<=MAX_EN_WORDS;
  return [...p].length<=MAX_ZH_CHARS;
}
let droppedOversizedFirstSentence = 0;
function stats() { return { droppedOversizedFirstSentence }; }
function resetStats() { droppedOversizedFirstSentence = 0; }
function validFirstSentence(sentence) {
  return validBody(sentence);
}
// Natural punctuation split for oversized cards (>44 Chinese chars / >24 English words):
// 1) Keep first complete sentence if it fits;
// 2) Otherwise accumulate leading clauses split by semicolon/comma up to the budget;
// Full original text always goes into details so evidence is never lost.
function splitLead(text) {
  const sents = sentences(text);
  if (sents.length && validBody(sents[0])) return sents[0];
  const p = plain(text);
  const isEn = english(p);
  const clauses = p.split(isEn ? /(?<=[;,])\s+/ : /(?<=[；;，,])/).map(c => c.trim()).filter(Boolean);
  if (clauses.length > 1) {
    let acc = '';
    for (const part of clauses) {
      const candidate = acc ? (isEn ? acc + ' ' + part : acc + part) : part;
      const trimmed = candidate.replace(/[，,；;]+$/, isEn ? '.' : '。');
      if (validBody(trimmed)) acc = candidate;
      else break;
    }
    if (acc) {
      const lead = acc.replace(/[，,；;]+$/, isEn ? '.' : '。');
      const minOk = isEn ? words(lead) >= 3 : [...plain(lead)].length >= 6;
      if (minOk && validBody(lead)) return lead;
    }
  }
  return sents[0] || text;
}
// Never cut mid-clause or silently lose evidence when a model misses the budget.
function preview(body, opts) {
  const text=String(body||'').trim();
  if(opts?.kind==='best_practice')return validBestPracticeBody(text)?{text}:{text:sentences(text)[0]||text,details:text};
  if(opts?.kind==='external_advice')return validExpertBody(text)?{text}:{text:sentences(text)[0]||text,details:text};
  return validBody(text)?{text}:{text:splitLead(text),details:text};
}
// Zero-LLM rewrite: split deterministically with preview(); drop only extreme unbreakable >44-char blocks.
async function rewriteCard(card,key) {
  if(!card||typeof card[key]!=='string'||!card[key].trim()||validBody(card[key]))return card;
  const original=card[key];
  const result=preview(original);
  if(!validBody(result.text)){droppedOversizedFirstSentence++;return null;}
  return {...card,[key]:result.text,details:[card.details,original].filter(Boolean).join('\n\n')};
}
async function prepare(parsed) {
  if(!parsed||typeof parsed!=='object')return parsed;
  if(Array.isArray(parsed)){const out=[];for(const item of parsed){const fixed=await rewriteCard(item,'point');if(fixed)out.push(fixed);}return out;}
  let out={...parsed};
  for(const key of ['md','message'])if(typeof out[key]==='string'){const fixed=await rewriteCard(out,key);out=fixed||{...out,[key]:''};}
  for(const key of ['suggestion','currentJudgment'])if(out[key])out[key]=await rewriteCard(out[key],out[key].text!==undefined?'text':'point');
  if(Array.isArray(out.insights)){const items=[];for(const item of out.insights){const fixed=await rewriteCard(item,item?.text!==undefined?'text':'point');if(fixed)items.push(fixed);}out.insights=items;}
  if(typeof out.point==='string'){const fixed=await rewriteCard(out,'point');out=fixed||{...out,point:''};}
  return out;
}
const TRAILING_PUNCT=/[\s.。,，;；:：!！?？、…·\-–—]+$/u;
// Chinese and single-token titles stay within 24 characters. Multi-word English
// titles stay within 10 words and 60 characters. The ellipsis counts toward the cap.
function trimTitle(title,{english=false}={}){
  const raw=String(title??'');
  const trimmed=raw.trim();
  if(!trimmed)return '';
  const words=trimmed.match(/\S+/g)||[];
  const multiEnglish=english===true&&words.length>=2;
  const charLimit=multiEnglish?60:24;
  const wordLimit=multiEnglish?10:0;
  let text=trimmed,shortened=false;
  if(wordLimit&&words.length>wordLimit){text=words.slice(0,wordLimit).join(' ');shortened=true;}
  if(text.length>charLimit){
    let slice=text.slice(0,charLimit);
    if(multiEnglish){const space=slice.lastIndexOf(' ');if(space>0)slice=slice.slice(0,space);}
    text=slice;shortened=true;
  }
  const stripped=text.replace(TRAILING_PUNCT,'');
  if(stripped)text=stripped;
  else{
    const core=trimmed.replace(/^[\s.。,，;；:：!！?？、…·\-–—]+/u,'').replace(TRAILING_PUNCT,'');
    text=(core||trimmed).slice(0,1);
    shortened=true;
  }
  if(!shortened)return text;
  const room=Math.max(1,charLimit-1);
  if(text.length>room){
    let slice=text.slice(0,room);
    if(multiEnglish){const space=slice.lastIndexOf(' ');if(space>0)slice=slice.slice(0,space);}
    slice=slice.replace(TRAILING_PUNCT,'');
    text=slice||text.slice(0,1);
  }
  if(!text)text=trimmed.slice(0,1);
  return text+'…';
}
module.exports={RULES,BEST_PRACTICE_RULES,EXPERT_ADVICE_RULES,renderPrompt,sentences,validBody,validFirstSentence,validBestPracticeBody,validExpertBody,isMultiOptionTradeoff,preview,rewriteCard,prepare,trimTitle,stats,resetStats};
