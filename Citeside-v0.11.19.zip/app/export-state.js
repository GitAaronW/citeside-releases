'use strict';
const fs=require('fs'),path=require('path');
// Parsed file bodies are immutable. Only changed files pay parse/freeze costs.
function freeze(value){if(value&&typeof value==='object'){for(const v of Object.values(value))freeze(v);Object.freeze(value);}return value;}
module.exports=function({pendingDir,liveDir,live,log=()=>{}}){
 const cache=new Map();
 function scan(dir,accept){
  let files;try{files=fs.readdirSync(dir);}catch(e){if(e.code!=='ENOENT')log('export-state scan fail '+e.message);files=[];}
  const present=new Set(),rows=[];
  for(const f of files){if(!accept(f))continue;const file=path.join(dir,f);present.add(file);
   try{const stat=fs.statSync(file);let entry=cache.get(file);
    if(!entry||entry.mtimeMs!==stat.mtimeMs||entry.size!==stat.size){
     const value=freeze(JSON.parse(fs.readFileSync(file,'utf8')));
     entry={mtimeMs:stat.mtimeMs,size:stat.size,value};cache.set(file,entry);
    }
    rows.push({f,updated:stat.mtimeMs,s:entry.value});
   }catch(e){cache.delete(file);log('export-state skip bad file '+f+' '+e.message);}
  }
  for(const file of cache.keys())if(path.dirname(file)===dir&&!present.has(file))cache.delete(file);
  return rows;
 }
 function pending(s,f){return { id: s.id || f, continuationEpoch: s.continuationEpoch || '', recordingSpans: Array.isArray(s.recordingSpans) ? s.recordingSpans : [], title: s.title || '', start: s.start || '', end: s.end || '', mode: s.mode || 'record', source: s.source || '', nativeCapture:!!s.nativeCapture,joinedEvent:s.joinedEvent||null,calendar:s.calendar||null,nativeInsights:s.nativeInsights||null,topicControls:s.topicControls||[],liveConfirmations:s.liveConfirmations||[], lang: s.lang || '', uiLang: s.uiLang || 'zh', notes:s.notes||'',fixes:s.fixes||[],recoveryStatus:s.recoveryStatus||'',names: s.names || {}, transcript: s.transcript || [], highlights: s.highlights || [], todos: s.todos || [], factchecks: s.factchecks || [], summary: s.summary || '', condensed: s.condensed || null, review: s.review || null, shareNote: s.shareNote || '', jev: s.jev || null, stats: s.stats || null, attachments: s.attachments || [] };}
 return function buildExportState(){
  const sessions=scan(pendingDir,f=>/^(sess|offline)-(?!trial-).*\.json(\.done)?$/.test(f)).filter(({s})=>s!=null).map(({s,f,updated})=>({...pending(s,f),_fileUpdated:updated}));
  const ids=new Set(sessions.map(s=>s.id));
  for(const {s} of scan(liveDir,f=>f.endsWith('.json'))){
   if(!s||s.complete||ids.has(s.id))continue;
   sessions.push({...s,start:new Date(s.startTs||s.updated).toISOString(),end:null,mode:'mac',
    recoveryStatus:live.has(s.id)&&!live.get(s.id)?.finalized?'recording':'interrupted',lang:s.lang||'auto',notes:s.notes||'',fixes:s.fixes||[]});ids.add(s.id);
  }
  const unique=new Map();for(const s of sessions){const old=unique.get(s.id);if(!old||(s._fileUpdated||0)>=(old._fileUpdated||0))unique.set(s.id,s);}
  const merged=[...unique.values()].map(({_fileUpdated,...s})=>s);merged.sort((a,b)=>String(a.start).localeCompare(String(b.start)));
  return {v:1,sessions:merged};
 };
};
