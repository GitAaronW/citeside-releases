'use strict';
// 主动智能批 4（需求单 F5）：useful / useless / adopt 反馈按 type（conflict / recheck / answer）计数，
// 「useless 多的那一类少给」——规则只有一条，简单到能测：
//   某一类在本场 useless ≥ DEMOTE_MIN（默认 2）且 useless > useful + adopt → 这一类被降权
//   降权 = 提示词里明说「这一类本轮最多 1 条」+ 服务端归一化后同类只留 1 条（模型不听话也拦得住）
// 反馈记录形状（/view-feedback 写进 state/view-feedback.jsonl 的同一条）：{ rating, type, kind, claim, comment }
// 没带 type 的老记录不参与计数（不猜类型）。
const TYPES = ['conflict', 'recheck', 'answer'];
const DEMOTE_MIN = 2;
const LABEL = { conflict: '对不上（conflict）', recheck: '空转（recheck）', answer: '递答案（answer）' };

function tally(feedback) {
  const out = {};
  for (const t of TYPES) out[t] = { useful: 0, useless: 0, adopt: 0 };
  for (const f of Array.isArray(feedback) ? feedback : []) {
    if (!f || !TYPES.includes(f.type)) continue;
    if (f.rating === 'useful' || f.rating === 'useless' || f.rating === 'adopt') out[f.type][f.rating]++;
  }
  return out;
}

// 返回被降权的 type 列表（按 useless 多到少）
function demotedTypes(feedback, min = DEMOTE_MIN) {
  const t = tally(feedback);
  return TYPES.filter(k => t[k].useless >= min && t[k].useless > t[k].useful + t[k].adopt).sort((a, b) => t[b].useless - t[a].useless);
}

// 提示词里的那一段；没有降权的类就返回空串
function promptBlock(feedback, min = DEMOTE_MIN) {
  const d = demotedTypes(feedback, min);
  if (!d.length) return '';
  const t = tally(feedback);
  return '\n\n【少给】' + d.map(k => `${LABEL[k]} 这场他已标 ${t[k].useless} 条没用，本轮这一类最多 1 条，拿不准就不出`).join('；') + '。';
}

// 归一化之后再过一道：被降权的类每轮只留第一条（保留原顺序）
function capDemoted(insights, feedback, min = DEMOTE_MIN) {
  const d = new Set(demotedTypes(feedback, min));
  if (!d.size) return insights;
  const seen = new Set(); const out = [];
  for (const x of insights || []) {
    const type = x && TYPES.includes(x.type) ? x.type : 'answer';
    if (d.has(type)) { if (seen.has(type)) continue; seen.add(type); }
    out.push(x);
  }
  return out;
}

const fs = require('fs');
const path = require('path');

function loadFeedback(dataDir) {
  if (!dataDir) return [];
  try {
    const file = path.join(dataDir, 'state', 'view-feedback.jsonl');
    if (!fs.existsSync(file)) return [];
    const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
    const out = [];
    for (const line of lines.slice(-500)) {
      try { const row = JSON.parse(line); if (row && typeof row === 'object') out.push(row); } catch {}
    }
    return out;
  } catch { return []; }
}

function charBigrams(text) {
  const s = String(text || '').toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
  const set = new Set();
  for (let i = 0; i < s.length - 1; i++) set.add(s.slice(i, i + 2));
  return set;
}

// 从「没用」反馈中检索最相近的 2–3 条负样本，专供发布门使用（不进主生成）。
function retrieveNegativeExamples(source, queryText, { limit = 3 } = {}) {
  const rows = Array.isArray(source) ? source : loadFeedback(source);
  const useless = rows.filter(r => r && r.rating === 'useless' && String(r.claim || r.text || '').trim());
  if (!useless.length) return [];
  const { conceptFingerprint } = require('./grounded-card-dedupe');
  const qText = String(queryText || '').trim();
  const qBi = charBigrams(qText);
  const qConcepts = conceptFingerprint(qText);
  const seen = new Set();
  const scored = [];
  for (let i = useless.length - 1; i >= 0; i--) {
    const r = useless[i];
    const text = String(r.claim || r.text || '').trim().slice(0, 160);
    if (!text || seen.has(text)) continue;
    seen.add(text);
    let score = 0;
    if (qText) {
      const bi = charBigrams(text);
      if (qBi.size && bi.size) {
        const common = [...qBi].filter(x => bi.has(x)).length;
        score += common / Math.max(1, Math.min(qBi.size, bi.size));
      }
      const concepts = conceptFingerprint(text);
      if (qConcepts.size && concepts.size) {
        const cCommon = [...qConcepts].filter(x => concepts.has(x)).length;
        score += (cCommon / Math.max(1, Math.min(qConcepts.size, concepts.size))) * 1.2;
      }
    }
    scored.push({
      score,
      recency: i,
      example: {
        text,
        ...(r.type ? { type: String(r.type).slice(0, 32) } : {}),
        ...(r.comment ? { comment: String(r.comment).trim().slice(0, 100) } : {}),
      }
    });
  }
  scored.sort((a, b) => b.score - a.score || b.recency - a.recency);
  return scored.slice(0, Math.max(1, Math.min(5, limit))).map(x => x.example);
}

module.exports = { tally, demotedTypes, promptBlock, capDemoted, loadFeedback, retrieveNegativeExamples, TYPES, DEMOTE_MIN };
