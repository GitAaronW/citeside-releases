'use strict';
// Existing live-report snapshots only. No provider, session loading or writes.
const fs=require('node:fs'),path=require('node:path');
const clip=(s,n)=>String(s==null?'':s).replace(/\s+/g,' ').trim().slice(0,n);
const sidOk=v=>typeof v==='string'&&/^[A-Za-z0-9_.-]{1,80}$/.test(v)&&v!=='.'&&v!=='..';
const fail=(status,code,message)=>Object.assign(Error(message),{status,code});
function sourcesOf(rows){const seen=new Set(),out=[];for(const row of rows)for(const source of Array.isArray(row.sources)?row.sources:[]){const key=JSON.stringify(source);if(!seen.has(key)){seen.add(key);out.push(source);}}return out;}
function researchOf(report){
 const named=Array.isArray(report.researchResults)?report.researchResults.filter(r=>r&&String(r.text||'').trim()):[];
 if(named.length)return named.map((r,index)=>({id:String(r.id||'research-'+index).slice(0,80),title:clip(r.title||String(r.text).split('\n')[0],80),at:r.updatedAt||r.at||'',text:String(r.text),sources:sourcesOf([r])})).filter(r=>r.title);
 const groups=new Map();for(const [index,item]of (Array.isArray(report.items)?report.items:[]).entries()){
  if(!item||item.action||item.topic!=='外部研究'||!String(item.text||'').trim())continue;
  // Group by the full saved card identity. A legacy 80-character list-id
  // collision must be ambiguous at read time, never silently merge reports.
  const key=String(item.card||item.id||'research-'+index);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item);
 }
 return [...groups].map(([key,rows])=>({id:key.slice(0,80),title:clip(rows[0].title||String(rows[0].text).split('\n')[0],80),at:rows[0].at||'',text:rows.map(r=>String(r.text)).join('\n\n'),sources:sourcesOf(rows)})).filter(r=>r.title);
}
function snapshot(dataDir,sessionId){
 if(!sidOk(sessionId))throw fail(400,'saved_research_invalid_id','无效会议编号');
 let fd;
 try{
  const root=fs.realpathSync(dataDir),dir=path.join(root,'live-reports'),file=path.join(dir,sessionId+'.json');
  if(fs.lstatSync(dir).isSymbolicLink()||!fs.statSync(dir).isDirectory()||fs.realpathSync(dir)!==dir)throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  const entry=fs.lstatSync(file);if(entry.isSymbolicLink()||!entry.isFile())throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);if(!fs.fstatSync(fd).isFile())throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');
  let report;try{report=JSON.parse(fs.readFileSync(fd,'utf8'));}catch{throw fail(500,'saved_research_invalid_snapshot','已保存研究文件无法读取');}
  if(!report||typeof report!=='object'||Array.isArray(report))throw fail(500,'saved_research_invalid_snapshot','已保存研究文件格式无效');return report;
 }catch(e){if(e.status)throw e;if(e.code==='ENOENT')throw fail(404,'saved_research_not_found','没有这份已保存研究');if(e.code==='ELOOP')throw fail(403,'saved_research_unsafe_path','已保存研究文件路径不可用');throw fail(500,'saved_research_read_failed','已保存研究文件无法读取');}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}
function read({dataDir='',sessionId='',outputId=''}={}){
 if(!sidOk(sessionId)||!String(outputId))throw fail(400,'saved_research_invalid_id','缺少有效的会议或研究编号');
 if(!String(outputId).startsWith('research:'+sessionId+':'))throw fail(404,'saved_research_not_found','没有这份已保存研究');
 const saved=snapshot(dataDir,sessionId),matches=researchOf(saved).filter(r=>'research:'+sessionId+':'+r.id===outputId);
 if(!matches.length)throw fail(404,'saved_research_not_found','没有这份已保存研究');if(matches.length!==1)throw fail(409,'saved_research_ambiguous','研究编号对应多份已保存报告，无法确定目标');
 const row=matches[0];return {id:outputId,sessionId,kind:'research',title:row.title,text:row.text,sources:row.sources,at:row.at||saved.updatedAt||''};
}
module.exports={researchOf,snapshot,read,sidOk};
