'use strict';
// 自我进化闭环第 1 步（总纲「自我进化闭环」1a / 1b，Aaron 2026-10-23 批）：Aaron 改过 AI 产出的地方，原稿→终稿存一行样本。
// 文件 state/edit-samples.jsonl，只追加、只本机、不上云；不参与任何实时判断，用途是以后的回放对照和 M3 / M4 参照。
// 三个来源（kind）：
//   transcript  会中改逐字稿（server.js applyTranscriptEdits）——短词替换还会顺手进词表，见 learnTranscriptEdit
//   archive     会后页 ⌘E 改字（archive-v2 editRoute），path 是改的位置
//   desk        处理台卡改草稿（actions.js save-draft），original 是模型第一版草稿
const fs = require('fs'), path = require('path');

const file = dataDir => path.join(dataDir, 'state', 'edit-samples.jsonl');
const str = v => v == null ? null : (typeof v === 'string' ? v : JSON.stringify(v)).slice(0, 20000);

function record(dataDir, sample) {
  if (!dataDir || !sample || !sample.kind) return false;
  const row = { at: new Date().toISOString(), ...sample, original: str(sample.original), final: str(sample.final) };
  if (row.final == null) return false;
  if (row.original != null && row.original === row.final && !row.undo) return false;   // 没改动的保存不记
  try { fs.mkdirSync(path.dirname(file(dataDir)), { recursive: true, mode: 0o700 }); fs.appendFileSync(file(dataDir), JSON.stringify(row) + '\n'); return true; } catch (e) { return false; }
}

function readAll(dataDir, { since = '' } = {}) {
  let txt = '';
  try { txt = fs.readFileSync(file(dataDir), 'utf8'); } catch (e) { return []; }
  const out = [];
  for (const line of txt.split('\n')) {
    if (!line) continue;
    try { const j = JSON.parse(line); if (!since || String(j.at || '') >= since) out.push(j); } catch (e) {}
  }
  return out;
}

// 1a：人手改逐字稿 = 一条纠正。原词→改词两边都是短词（≤20 字、无空格标点，判据同 goal-metrics.correctionPair）才有资格进词表，
// 下一场的热词和纠名表都读词表；整句重写只存样本。
// 守卫（Explore 子代理 2026-10-23 审出的三条阻塞 + 换词风险）：
//   · 进词表要么 right 是本场名单上的名字（纠名），要么同一组替换在样本里已出现过 ≥2 次（含这次）——「小李→张伟」「Q3→Q4」这种换词一次不学
//   · 词表里已有这个错词：不覆盖别人的 right，也不把它记成这次学的（撤销时就不会误伤）
//   · 改回最初那句 = 撤销：只 drop 这次学到的那条
//   · 客户端 start / end 帧会把全部改动重发：文本没变的改动不记样本不学
// 词表在底栏「它记住的」看得到、能删，所以这里不另做入口。row.lexLearned 记住学的是哪个错词，撤销时用。
const MIN_SEEN = 2;
function learnTranscriptEdit({ dataDir, meetingId, row, before, after, prev, names = [], log = () => {} }) {
  if (!dataDir || !row || typeof before !== 'string' || typeof after !== 'string') return { learned: false };
  if (typeof prev === 'string' && prev === after) return { learned: false, unchanged: true };
  let mem, gm;
  try { mem = require('./memory'); gm = require('./goal-metrics'); } catch (e) { return { learned: false }; }
  const db = mem.open(dataDir);
  // 改回原句 = 撤销。before 是最初识别原句（客户端带的 originalText），所以 before === after 就是改回去了
  if (after === before || after === row.originalText) {
    record(dataDir, { kind: 'transcript', meetingId, seg: row.id, original: prev ?? before, final: after, undo: true });
    if (row.lexLearned && db) {
      try { mem.ensureLexicon(db); db.prepare("UPDATE lexicon SET state='dropped', updated_at=? WHERE wrong=?").run(new Date().toISOString(), row.lexLearned); log('词表撤销 ' + row.lexLearned + '（逐字稿改回原句）'); } catch (e) { log('词表撤销失败 ' + e.message); }
      delete row.lexLearned;
    }
    return { learned: false, undone: true };
  }
  record(dataDir, { kind: 'transcript', meetingId, seg: row.id, original: before, final: after });
  if (!db) return { learned: false };
  const p = gm.correctionPair(before, after);
  if (!p || !p.key) return { learned: false };
  // 整句重写不进词表：改掉的部分要是句子里的一小块（周围至少留 2 字、不超过整句一半），否则只是换了个说法
  if (before.length - p.wrong.length < 2 || p.wrong.length * 2 > before.length) return { learned: false, why: '整句重写' };
  const known = new Set((names || []).flatMap(n => [String(n), ...String(n).split(' ')]).map(x => x.toLowerCase()).filter(Boolean));
  const isName = known.has(p.right.toLowerCase());
  if (!isName) {
    const seen = readAll(dataDir).filter(r => r.kind === 'transcript' && !r.undo && r.original && r.final && (gm.correctionPair(r.original, r.final) || {}).key === p.key).length;
    if (seen < MIN_SEEN) return { learned: false, why: '只见过 ' + seen + ' 次', seen };
  }
  let cur = null;
  try { mem.ensureLexicon(db); cur = db.prepare('SELECT right, state FROM lexicon WHERE wrong=?').get(p.wrong) || null; } catch (e) {}
  if (cur) return { learned: false, why: '词表已有 ' + p.wrong + '→' + cur.right + '（' + cur.state + '），不覆盖' };
  const r = mem.putLex(db, p.wrong, p.right, meetingId);
  if (!r.ok) return { learned: false, why: r.why };
  row.lexLearned = p.wrong;
  log('词表学到 ' + p.wrong + '→' + p.right + '（手改逐字稿' + (isName ? '，名单人名' : '，第 ' + MIN_SEEN + ' 次') + '）');
  return { learned: true, wrong: p.wrong, right: p.right };
}

module.exports = { record, readAll, file, learnTranscriptEdit, MIN_SEEN };
