'use strict';
// Pure synchronization boundary. The host supplies an authoritative Notion snapshot.
// No network, credentials, scheduler or write API is present in this module.
const crypto = require('crypto');
const digest = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
function planSync({confirmed=false,meetingId,ownerId,myActions=[],existingRows=[]}={}) {
  if(confirmed!==true) throw Error('请先确认我的待办，再同步');
  if(!meetingId || !ownerId) throw Error('缺少稳定的会议或本人标识');
  const existing=new Map(),incoming=new Set(),operations=[];
  for(const row of existingRows){
    if(!row.dedupeKey)continue;
    if(existing.has(row.dedupeKey))throw Error('Notion 去重键重复，需人工处理');
    existing.set(row.dedupeKey,row);
  }
  for(const a of myActions){
    if(a.group!=='mine'||!a.attribution?.owner||!a.id||!a.do) throw Error('只接受已确认归属的我的待办');
    const dedupeKey='personal-action:'+digest([String(ownerId),String(meetingId),String(a.id)]);
    if(incoming.has(dedupeKey))throw Error('输入待办标识重复');
    incoming.add(dedupeKey);
    const due=String(a.due||'');
    const properties={title:a.do,owner:a.attribution.owner,due:/^\d{4}-\d{2}-\d{2}$/.test(due)?due:'',dueText:a.dueRaw||(!/^\d{4}-\d{2}-\d{2}$/.test(due)?due:''),background:a.background||'',meetingId:String(meetingId)};
    const sourceHash=digest(properties),prior=existing.get(dedupeKey);
    if(prior && !prior.id)throw Error('Notion 行缺少标识');
    if(!prior){operations.push({op:'create',dedupeKey,properties,sourceHash});continue;}
    if(prior.sourceHash===sourceHash)continue; // Notion edits/status remain authoritative.
    const updates={},conflicts=[];
    for(const [key,value] of Object.entries(properties)){
      if(prior.properties?.[key]===value)continue;
      if(!prior.lastSyncedProperties || prior.properties?.[key]!==prior.lastSyncedProperties[key])conflicts.push(key);
      else updates[key]=value;
    }
    if(conflicts.length){operations.push({op:'conflict',id:prior.id,dedupeKey,fields:conflicts,sourceHash});continue;}
    operations.push({op:'update',id:prior.id,dedupeKey,properties:updates,sourceHash});
  }
  return {confirmed:true,operations}; // Never deletes remote rows when local items disappear.
}
async function planWithClient(input,client) {
  if(input.confirmed!==true)throw Error('请先确认我的待办，再同步');
  const seed=planSync({...input,existingRows:[]});
  const existingRows=await client.findByKeys(seed.operations.map(o=>o.dedupeKey));
  return planSync({...input,existingRows});
}
module.exports={planSync,planWithClient};
