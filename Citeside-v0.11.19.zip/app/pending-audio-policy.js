'use strict';

// Binds encrypted pending-audio chunks to the transcript rows a journal snapshot already
// contains. Release deletes only that frozen id list, and only when the caller passes the
// boolean true returned by a finished fsync. Provider confirm, checkpoint(), and a later
// watermark are not inputs. A chunk is covered only when every byte sent for it sits fully
// inside an explicit stream span. Empty text, missing times, and partial overlap add nothing.

const crypto = require('crypto');

const BYTES_PER_MS = 32;

function createBinder(options = {}) {
  if (!options || typeof options !== 'object' || !options.cache || typeof options.cache.put !== 'function' || typeof options.cache.removeConfirmed !== 'function') {
    throw Object.assign(new Error('需要 pending-audio cache'), { code: 'invalid_cache' });
  }
  if (typeof options.sessionId !== 'string' || !options.sessionId) {
    throw Object.assign(new Error('需要 sessionId'), { code: 'invalid_session' });
  }
  const bytesPerMs = options.bytesPerMs === undefined ? BYTES_PER_MS : options.bytesPerMs;
  if (!Number.isSafeInteger(bytesPerMs) || bytesPerMs <= 0) {
    throw Object.assign(new Error('bytesPerMs 无效'), { code: 'invalid_bytes_per_ms' });
  }
  const cache = options.cache;
  const sessionId = options.sessionId;
  const captures = new Map();
  const links = new Map();
  // Recover the next placement from authenticated cache metadata, even before
  // a live caller rehydrates its provider-specific links. Old chunks have no
  // range; reserving their total length keeps new captures after that prefix.
  const stored = typeof cache.list === 'function' ? cache.list(sessionId) : [];
  let cursor = stored.reduce((at, item) => Math.max(at, item.byteStart === undefined ? 0 : item.byteStart + item.bytes),
    stored.filter(item => item.byteStart === undefined).reduce((bytes, item) => bytes + item.bytes, 0));

  function acceptCapture(pcm, capturedAt, placement) {
    const start = placement && placement.start !== undefined ? placement.start : cursor;
    if (!Number.isSafeInteger(start) || start < 0 || start % 2 !== 0 || !Number.isSafeInteger(start + pcm.length)) {
      throw Object.assign(new Error('capture start 无效'), { code: 'invalid_capture_start' });
    }
    const id = chunkId(sessionId, start, pcm);
    const saved = cache.put({ id, sessionId, capturedAt, pcm, byteStart: start });
    const end = start + pcm.length;
    cursor = Math.max(cursor, end);
    captures.set(id, { id, start, end, capturedAt: saved.capturedAt });
    return {
      id,
      sessionId,
      capturedAt: saved.capturedAt,
      start,
      end,
      bytes: pcm.length,
      idempotent: saved.idempotent === true,
    };
  }

  function linkSent(streamId, chunkIdValue, length) {
    if (typeof streamId !== 'string' || !streamId.trim()) return null;
    if (typeof chunkIdValue !== 'string' || !chunkIdValue) return null;
    if (!Number.isSafeInteger(length) || length <= 0) return null;
    const streamStart = links.has(streamId) ? links.get(streamId).cursor : 0;
    const streamEnd = streamStart + length;
    if (!Number.isSafeInteger(streamEnd)) return null;
    const row = { streamId, chunkId: chunkIdValue, streamStart, streamEnd };
    const state = links.get(streamId) || { cursor: 0, rows: [] };
    state.rows.push(row);
    state.cursor = streamEnd;
    links.set(streamId, state);
    return { streamId, chunkId: chunkIdValue, streamStart, streamEnd };
  }

  function explicitSpan(streamId, startMs, endMs) {
    if (typeof streamId !== 'string' || !streamId.trim()) return [];
    if (!Number.isSafeInteger(startMs) || !Number.isSafeInteger(endMs) || startMs < 0 || endMs <= startMs) return [];
    const startByte = startMs * bytesPerMs;
    const endByte = endMs * bytesPerMs;
    if (!Number.isSafeInteger(startByte) || !Number.isSafeInteger(endByte)) return [];
    const state = links.get(streamId);
    if (!state) return [];
    const seen = new Set();
    const ids = [];
    for (const row of state.rows) {
      if (seen.has(row.chunkId)) continue;
      if (!chunkInside(streamId, row.chunkId, startByte, endByte)) continue;
      seen.add(row.chunkId);
      ids.push(row.chunkId);
    }
    return ids;
  }

  function chunkInside(streamId, chunkIdValue, startByte, endByte) {
    const known = captures.get(chunkIdValue);
    if (!known) return false;
    const ranges = (links.get(streamId) || { rows: [] }).rows.filter((row) => row.chunkId === chunkIdValue);
    if (!ranges.length) return false;
    const ordered = ranges.slice().sort((a, b) => a.streamStart - b.streamStart || a.streamEnd - b.streamEnd);
    let at = ordered[0].streamStart;
    for (const range of ordered) {
      if (range.streamStart !== at) return false;
      if (range.streamStart < startByte || range.streamEnd > endByte) return false;
      at = range.streamEnd;
    }
    return at - ordered[0].streamStart === known.end - known.start;
  }

  function assignRow(row, span) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) return [];
    const existing = Array.isArray(row.pendingChunkIds) ? row.pendingChunkIds.filter((id) => typeof id === 'string') : [];
    const text = typeof row.text === 'string' ? row.text.trim() : '';
    if (!text) return existing.slice();
    const ids = explicitSpan(span && span.streamId, span && span.startMs, span && span.endMs);
    if (!ids.length) return existing.slice();
    const merged = existing.slice();
    for (const id of ids) if (!merged.includes(id)) merged.push(id);
    row.pendingChunkIds = merged;
    return merged.slice();
  }

  function freeze(transcript) {
    const chunkIds = [];
    const seen = new Set();
    const rows = Array.isArray(transcript) ? transcript : [];
    for (const row of rows) {
      const list = row && row.pendingChunkIds;
      if (!Array.isArray(list)) continue;
      for (const id of list) {
        if (typeof id !== 'string' || seen.has(id)) continue;
        seen.add(id);
        chunkIds.push(id);
      }
    }
    return { chunkIds };
  }

  function rehydrate(record) {
    if (!record || typeof record !== 'object' || Array.isArray(record)) {
      throw Object.assign(new Error('rehydrate 无效'), { code: 'invalid_rehydrate' });
    }
    const id = record.id;
    const start = record.start;
    const end = record.end;
    if (typeof id !== 'string' || !id) throw Object.assign(new Error('rehydrate id 无效'), { code: 'invalid_rehydrate' });
    if (!Number.isSafeInteger(start) || start < 0 || !Number.isSafeInteger(end) || end < start) {
      throw Object.assign(new Error('rehydrate 范围无效'), { code: 'invalid_rehydrate' });
    }
    const known = captures.get(id);
    if (known && (known.start !== start || known.end !== end)) {
      throw Object.assign(new Error('rehydrate 冲突'), { code: 'rehydrate_conflict' });
    }
    if (!known) captures.set(id, { id, start, end, capturedAt: record.capturedAt });
    cursor = Math.max(cursor, end);
    return { id, start, end };
  }

  function release(frozen, writeOk) {
    const ids = frozen && Array.isArray(frozen.chunkIds) ? frozen.chunkIds.filter((id) => typeof id === 'string') : [];
    if (writeOk !== true) return { released: [], retained: ids.slice(), stopped: false };
    const released = [];
    const retained = [];
    let stopped = false;
    for (let i = 0; i < ids.length; i++) {
      if (stopped) {
        retained.push(ids[i]);
        continue;
      }
      try {
        cache.removeConfirmed(ids[i], { durableTranscript: true });
        released.push(ids[i]);
      } catch (e) {
        if (e && e.code === 'not_found') {
          released.push(ids[i]);
          continue;
        }
        stopped = true;
        retained.push(ids[i]);
      }
    }
    return { released, retained, stopped };
  }

  return { acceptCapture, linkSent, assignRow, explicitSpan, freeze, release, rehydrate };
}

function chunkId(sessionId, start, pcm) {
  const digest = crypto.createHash('sha256').update(pcm).digest();
  const id = crypto.createHash('sha256');
  id.update(String(sessionId), 'utf8');
  id.update('\0');
  id.update(String(start), 'utf8');
  id.update('\0');
  id.update(digest);
  return 'c' + id.digest('hex').slice(0, 40);
}

module.exports = { createBinder, BYTES_PER_MS, chunkId };
