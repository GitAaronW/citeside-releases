'use strict';
// One read policy for recent/history/detail. Original calendar titles are never
// clipped. Raw session titles and transcript openings are not AI topic titles.
const text = value => typeof value === 'string' ? value.trim() : '';
function calendarTitle(session = {}, source = {}) {
  if (session == null) session = {};
  if (source == null) source = {};
  if (session.calendar?.chosen === 'none') return '';
  const calendar = session.calendar && typeof session.calendar === 'object' ? session.calendar : {};
  const event = calendar.event || session.joinedEvent || source.calendarEvent || {};
  return text(calendar.title) || text(event.title) || text(event.summary);
}
const PLACEHOLDER = /^(?:无有效内容|未命名(?:会议|笔记)?|过短会话|short session|untitled(?:\s+(?:meeting|note))?|no substantive content)$/i;
function isPlaceholder(value) {
  return PLACEHOLDER.test(text(value));
}
function shortTitle(value) {
  const title = text(value);
  return title && !isPlaceholder(title) && !/[\r\n]/.test(title) && [...title].length <= 10 ? title : '';
}
function manualTitle(session = {}, options = {}) {
  if (session == null) session = {};
  if (options == null) options = {};
  const { titleRow = {}, source = {} } = options;
  for (const row of [source, titleRow, session]) {
    if (row == null) continue;
    if (row.titleEdited || row.titleManual || row.titleMethod === 'manual') {
      const manual = row.titleEdited ? text(row.title) : text(row.topicTitle) || text(row.title);
      if (manual) return manual;
    }
  }
  return '';
}
function display(session = {}, options = {}) {
  if (session == null) session = {};
  if (options == null) options = {};
  const titleRow = options.titleRow ?? {};
  const job = options.job ?? {};
  const source = options.source ?? {};
  const manual = manualTitle(session, options);
  if (manual) return manual;
  const calendar = calendarTitle(session, source);
  if (calendar) return calendar;
  if (source.kind === 'note') return text(source.title) || text(session.title) || (session.uiLang === 'en' ? 'Notes' : '笔记');
  for (const value of [titleRow.topicTitle, session.topicTitle, job.topicTitle, source.topicTitle,
    source.titleMethod === 'ai-short-v1' ? source.title : '']) {
    const title = shortTitle(value);
    if (title) return title;
  }
  return session.uiLang === 'en' ? 'Notes' : '会议记录';
}
module.exports = { calendarTitle, shortTitle, isPlaceholder, manualTitle, display };
