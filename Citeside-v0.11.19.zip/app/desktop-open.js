'use strict';
const fs=require('fs'),path=require('path'),os=require('os');
const {execFile,execFileSync,spawn}=require('child_process');

// Menu bar Settings… / Check for Updates… open the main window on that panel.
const PANELS=['settings','update'];
function localUrl({port=47823,sessionId='',setup=false,onboarding=false,panel=''}={}){
  if(panel&&!PANELS.includes(panel))throw Error('invalid_panel');
  if(!Number.isInteger(Number(port))||Number(port)<1||Number(port)>65535)throw Error('invalid_port');
  if(typeof sessionId!=='string'||(sessionId&&!/^[\w-]{1,100}$/.test(sessionId)))throw Error('invalid_meeting_id');
  const query=[sessionId&&'id='+encodeURIComponent(sessionId),panel&&'panel='+panel].filter(Boolean).join('&');
  // 旧 setup 请求也只进入已批准的新引导；配置不足不恢复旧设置界面。
  const page=setup||onboarding?'onboarding.html':'index.html';
  return `http://[::1]:${port}/seatnote/${page}${query?'?'+query:''}`;
}
function findApp(port,{roots=['/Applications',path.join(os.homedir(),'Applications'),path.join(os.homedir(),'Applications','Chrome Apps.localized')],readPlist}={}){
  readPlist ||= file=>JSON.parse(execFileSync('/usr/bin/plutil',['-convert','json','-o','-',file],{encoding:'utf8',timeout:2000}));
  for(const root of roots){let names;try{names=fs.readdirSync(root);}catch{continue;}
    for(const name of names.filter(x=>x.endsWith('.app'))){try{
      const info=readPlist(path.join(root,name,'Contents','Info.plist'));
      const u=new URL(info.CrAppModeShortcutURL);
      if(![`http://127.0.0.1:${port}`,`http://[::1]:${port}`].includes(u.origin)||!u.pathname.startsWith('/seatnote/')||!/^[a-p]{32}$/.test(info.CrAppModeShortcutID||''))continue;
      return {appId:info.CrAppModeShortcutID};
    }catch{}}
  }return null;
}
function launchSpec(options={},env={}){
  const url=localUrl(options),port=Number(options.port||47823),platform=env.platform||process.platform;
  if(platform!=='darwin')throw Error('desktop_open_mac_only');
  const chrome=env.chrome||'/Applications/Google Chrome.app';
  const exists=env.exists||fs.existsSync;
  if(!exists(chrome))return {mode:'browser',url,command:'/usr/bin/open',args:[url]};
  const app=(env.findApp||findApp)(port);
  // Chromium's app shortcuts switch preserves the installed app's identity and
  // overrides its launch URL. No profile, app ID or user name is copied between users.
  // `open -a Chrome --args` drops the switches when Chrome is already running.
  // The executable forwards them through Chromium's existing process singleton.
  return {mode:app?'installed-app':'app-window',url,command:path.join(chrome,'Contents/MacOS/Google Chrome'),args:app?['--app-id='+app.appId,'--app-launch-url-for-shortcuts-menu-item='+url]:['--app='+url]};
}
function sameMeetingWindow(hit,url){
  if(!hit||typeof hit.url!=='string'||!hit.url)return false;
  let wanted,got;
  try{wanted=new URL(url);got=new URL(hit.url);}catch{return false;}
  if(got.origin!==wanted.origin||got.pathname!==wanted.pathname)return false;
  const id=wanted.searchParams.get('id'),gotId=got.searchParams.get('id');
  // The installed shortcut has no meeting id. That window is the one main window.
  // Two explicit ids still have to match, so a different meeting is not reused.
  return !id||!gotId||gotId===id;
}
function chromeWindows(env={}){
  try{
    const raw=(env.execFileSync||execFileSync)('/usr/bin/osascript',['-e','tell application "Google Chrome"\nset out to ""\nrepeat with w in windows\nset wid to id of w as text\nrepeat with t in tabs of w\ntry\nset out to out & wid & tab & (URL of t) & linefeed\nend try\nend repeat\nend repeat\nreturn out\nend tell'],{encoding:'utf8',timeout:1500});
    return String(raw||'').split('\n').map(line=>{const tab=line.indexOf('\t');if(tab<1)return null;return {id:line.slice(0,tab),url:line.slice(tab+1)};}).filter(hit=>hit&&hit.url);
  }catch{return [];}
}
function focusChromeWindow(env,id){
  if(!/^\d+$/.test(String(id)))return;
  (env.execFileSync||execFileSync)('/usr/bin/osascript',['-e','tell application "Google Chrome"\nset index of window id '+id+' to 1\nactivate\nend tell'],{encoding:'utf8',timeout:1500});
}
async function openMain(options={},env={}){
  const spec=launchSpec(options,env);
  const list=typeof env.listWindows==='function'?env.listWindows:(env.allowSystemWindows?()=>chromeWindows(env):()=>[]);
  let windows=[];
  try{windows=await list()||[];}catch{windows=[];}
  if(!Array.isArray(windows))windows=[];
  const hits=windows.filter(item=>sameMeetingWindow(item,spec.url));
  let wantedId='';try{wantedId=new URL(spec.url).searchParams.get('id')||'';}catch{}
  const hit=!wantedId?hits[0]:hits.find(item=>{try{return new URL(item.url).searchParams.get('id')===wantedId;}catch{return false;}})||hits.find(item=>{try{return !new URL(item.url).searchParams.get('id');}catch{return false;}});
  if(hit){
    try{
      if(typeof env.focusWindow==='function')await env.focusWindow(hit);
      else if(env.allowSystemWindows)focusChromeWindow(env,hit.id);
    }catch{}
    return {mode:spec.mode,url:spec.url,reused:true};
  }
  if(spec.mode==='browser')await new Promise((resolve,reject)=>(env.execFile||execFile)(spec.command,spec.args,{timeout:6000},e=>e?reject(e):resolve()));
  else await new Promise((resolve,reject)=>{const child=(env.spawn||spawn)(spec.command,spec.args,{detached:true,stdio:'ignore'});child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});});
  return {mode:spec.mode,url:spec.url,reused:false};
}
// LaunchServices reuses the running native application, without putting auth
// tokens in URLs or launch arguments and without a Chrome fallback.
async function returnToNative(env={}){
  if((env.platform||process.platform)!=='darwin')throw Error('native_app_unavailable');
  await new Promise((resolve,reject)=>(env.execFile||execFile)('/usr/bin/open',['-b','com.citeside.app'],{timeout:6000},error=>error?reject(Error('native_app_unavailable')):resolve()));
  return {ok:true,returnedToApp:true};
}
module.exports={localUrl,findApp,launchSpec,openMain,returnToNative,PANELS};
