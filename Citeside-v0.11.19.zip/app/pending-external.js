'use strict';
// r9：外部信息默认进方案文档的「待定」段。会中卡片不再提供「写进文档」。
// 待定段里只有「采纳」和「深度研究」。已删进最近删除、已不采纳、曾经写入过待定的编号不再写回正文。
// 服务端启动时和每小时扫描全部文档做老化。进行中的会议，或文档最近 10 分钟有打开或写入，这次跳过，下次再扫。
// 未处理的段不论文档打开过没有，一律从写入起保留 30 天再进最近删除。已处理的（采纳、不采纳）直接消失。
// 已结束的会议回看不从这里写入。
const RETAIN_MS=30*24*60*60*1000;
const crypto=require('crypto');
const PENDING_HEADING='solution-section:pending';
const PENDING_BLOCK='pending-external';
const ADOPTED_BLOCK='adopted-external';
const EXTERNAL=new Set(['background','verification','insight','external']);
const clip=(value,n)=>String(value??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').trim().slice(0,n);
function plain(node){
 if(!node)return '';
 if(typeof node.text==='string')return node.text;
 return (node.content||[]).map(plain).join('');
}
function isGlossary(item){
 const text=[item?.title,item?.category,item?.cat,item?.entity].filter(Boolean).join(' ');
 return /名词解释|\bGlossary\b/i.test(text);
}
function normalize(item={}){
 return {id:clip(item.id||item.candidateId,200),kind:clip(item.kind,40),channel:clip(item.channel,40),title:clip(item.title,200),body:clip(item.body||item.text,4000),category:clip(item.category||item.cat,80),sourceLayer:clip(item.sourceLayer,40),actionText:clip(item.actionText,500)};
}
function isExternal(item){
 const value=item?.id?item:normalize(item);
 if(!value?.id)return false;
 if(['action','task','suggestion','note','revision'].includes(value.kind))return false;
 if(isGlossary(value))return false;
 if(value.kind==='plan'||value.kind==='map')return true;
 if(value.sourceLayer==='external')return true;
 return EXTERNAL.has(value.kind)||EXTERNAL.has(value.channel);
}
function pendingIndex(content){
 return content.content.findIndex(b=>b.type==='heading'&&(b.attrs?.sourceRef===PENDING_HEADING||/^(待定|Pending)$/.test(plain(b).trim())));
}
function sectionEnd(content,start){
 let end=start+1;const level=content.content[start]?.attrs?.level||2;
 while(end<content.content.length&&!(content.content[end].type==='heading'&&(content.content[end].attrs?.level||2)<=level))end++;
 return end;
}
function evidenceAt(content){
 return content.content.findIndex(b=>b.type==='heading'&&(b.attrs?.sourceRef==='solution-section:4'||/^(依据与修订记录|依据|Evidence and revisions|Evidence)$/.test(plain(b).trim())));
}
function blockIdFor(id){return 'pend-'+crypto.createHash('sha256').update(String(id)).digest('hex').slice(0,24);}
function paragraph(text){return {type:'paragraph',content:[{type:'text',text}]};}
function makeBlock(item){
 const title=item.title,body=item.body&&item.body!==title?item.body:'';
 const action=item.actionText&&item.actionText!==title&&item.actionText!==body?item.actionText:'';
 const content=[paragraph(title||body||action||item.id)];
 if(title&&body)content.push(paragraph(body));
 if(action)content.push(paragraph(action));
 return {type:'blockquote',attrs:{blockId:blockIdFor(item.id),sourceRef:PENDING_BLOCK,candidateId:item.id,draft:null},content};
}
function insertPoint(content){const at=evidenceAt(content);return at<0?content.content.length:at;}
function ensureHeading(content,lang){
 let start=pendingIndex(content);
 if(start>=0)return start;
 const heading={type:'heading',attrs:{level:2,sourceRef:PENDING_HEADING,blockId:'b-pending-external'},content:[{type:'text',text:lang==='en'?'Pending':'待定'}]};
 content.content.splice(insertPoint(content),0,heading);
 return pendingIndex(content);
}
function blockSlot(content,start){
 let end=sectionEnd(content,start);
 while(end>start+1){
  const node=content.content[end-1];
  if(node.attrs?.sourceRef===PENDING_BLOCK||node.type!=='paragraph'||plain(node).trim())break;
  end--;
 }
 return end;
}
function trimPending(content){
 const start=pendingIndex(content);if(start<0)return;
 const end=sectionEnd(content,start);
 const inside=content.content.slice(start+1,end);
 if(inside.some(b=>b.attrs?.sourceRef===PENDING_BLOCK||(b.type!=='paragraph'&&plain(b).trim())||(b.type==='paragraph'&&plain(b).trim())))return;
 content.content.splice(start,end-start);
}
function idSet(value){
 const list=Array.isArray(value)?value:value instanceof Set?[...value]:[];
 return new Set(list.map(x=>typeof x==='string'?x:x?.candidateId).filter(Boolean));
}
function stage(content,item,opts={}){
 const value=normalize(item);
 if(!isExternal(value))return {staged:false,reason:'not-external'};
 if(!value.id)return {staged:false,reason:'no-id'};
 if(content.content.some(b=>b.attrs?.candidateId===value.id&&(b.attrs?.sourceRef===PENDING_BLOCK||b.attrs?.sourceRef===ADOPTED_BLOCK)))return {staged:false,reason:'exists',candidateId:value.id};
 if(idSet(opts.deleted).has(value.id))return {staged:false,reason:'deleted',candidateId:value.id};
 if(idSet(opts.rejected).has(value.id))return {staged:false,reason:'rejected',candidateId:value.id};
 if(idSet(opts.stagedAt&&typeof opts.stagedAt==='object'&&!Array.isArray(opts.stagedAt)?Object.keys(opts.stagedAt):opts.stagedAt).has(value.id))return {staged:false,reason:'already-staged',candidateId:value.id};
 const start=ensureHeading(content,opts.lang);
 const block=makeBlock(value);
 content.content.splice(blockSlot(content,start),0,block);
 return {staged:true,candidateId:value.id,blockId:block.attrs.blockId};
}
function unstage(content,candidateId){
 const id=clip(candidateId,200);
 const index=content.content.findIndex(b=>b.attrs?.sourceRef===PENDING_BLOCK&&b.attrs?.candidateId===id);
 if(index<0)return {removed:false,candidateId:id};
 const [block]=content.content.splice(index,1);
 trimPending(content);
 return {removed:true,candidateId:id,block};
}
function adopt(content,candidateId){
 const id=clip(candidateId,200);
 const index=content.content.findIndex(b=>b.attrs?.sourceRef===PENDING_BLOCK&&b.attrs?.candidateId===id);
 if(index<0)return {adopted:false};
 const [block]=content.content.splice(index,1);
 block.attrs={...block.attrs,sourceRef:ADOPTED_BLOCK};
 const at=pendingIndex(content);content.content.splice(at<0?insertPoint(content):at,0,block);
 trimPending(content);
 return {adopted:true,candidateId:id,blockId:block.attrs.blockId};
}
function age(content,due){
 const start=pendingIndex(content);
 if(start<0)return {aged:[]};
 const end=sectionEnd(content,start);
 const rows=content.content.slice(start+1,end).filter(b=>b.attrs?.sourceRef===PENDING_BLOCK);
 if(!rows.length){trimPending(content);return {aged:[]};}
 const aged=rows.filter(b=>typeof due!=='function'||due(b.attrs?.candidateId)).map(b=>({candidateId:b.attrs.candidateId,blockId:b.attrs.blockId,text:plain(b).slice(0,500),block:JSON.parse(JSON.stringify(b))}));
 if(!aged.length)return {aged:[]};
 const ids=new Set(aged.map(x=>x.blockId));
 content.content=content.content.filter(b=>!ids.has(b.attrs?.blockId));
 trimPending(content);
 return {aged};
}
function restore(content,items,opts={}){
 let restored=0;
 for(const item of items||[]){
  if(!item?.block||!item.candidateId)continue;
  if(content.content.some(b=>b.attrs?.candidateId===item.candidateId))continue;
  const start=ensureHeading(content,opts.lang);
  const block=JSON.parse(JSON.stringify(item.block));
  block.attrs={...block.attrs,sourceRef:PENDING_BLOCK,candidateId:item.candidateId};
  content.content.splice(blockSlot(content,start),0,block);
  restored++;
 }
 return {restored};
}
module.exports={PENDING_HEADING,PENDING_BLOCK,ADOPTED_BLOCK,RETAIN_MS,normalize,isExternal,isGlossary,stage,unstage,adopt,age,restore,plain,pendingIndex};
