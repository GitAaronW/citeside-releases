'use strict';
const { monitorEventLoopDelay } = require('node:perf_hooks');
function start({ log, thresholdMs = 500, intervalMs = 1000, histogram = monitorEventLoopDelay({ resolution: 20 }) }) {
  const recent = [];
  histogram.enable();
  function mark(task) {
    const name = String(task).slice(0, 160);
    if (recent.at(-1) !== name) recent.push(name);
    if (recent.length > 8) recent.shift();
  }
  function sample() {
    const maxMs = histogram.max / 1e6;
    histogram.reset();
    if (maxMs > thresholdMs) log(`event-loop delay=${maxMs.toFixed(1)}ms recent=${recent.join(' | ') || 'idle'}`);
    recent.length = 0;
    return maxMs;
  }
  const timer = setInterval(sample, intervalMs); timer.unref();
  return { mark, sample, stop() { clearInterval(timer); histogram.disable(); } };
}
module.exports = { start };
