'use strict';
// One explicitly selected HTTP MCP source. No account discovery or credential copying.
const crypto = require('crypto');
const stable = value => JSON.stringify(value && typeof value === 'object' ? Array.isArray(value) ? value.map(x => JSON.parse(stable(x))) : Object.fromEntries(Object.keys(value).sort().map(key => [key, JSON.parse(stable(value[key]))])) : value);
const digest = value => crypto.createHash('sha256').update(stable(value)).digest('hex');
function endpoint(value) {
 const u = new URL(value);
 if (u.username || u.password || u.search || u.hash || !((u.protocol === 'https:') || (u.protocol === 'http:' && ['localhost','127.0.0.1','[::1]'].includes(u.hostname)))) throw Error('invalid_mcp_url');
 if (['169.254.169.254','[fd00:ec2::254]'].includes(u.hostname)) throw Error('invalid_mcp_url');
 return u.href;
}
function schemaSupported(schema, depth = 0) {
 if (!schema || typeof schema !== 'object' || Array.isArray(schema) || depth > 8) return false;
 const types = ['object','array','string','number','integer','boolean','null'];
 const keys = ['type','properties','required','additionalProperties','items','enum','const','description','title','minLength','maxLength','minimum','maximum','minItems','maxItems'];
 if (!types.includes(schema.type) || Object.keys(schema).some(key => !keys.includes(key))) return false;
 for (const key of ['minLength','maxLength','minItems','maxItems']) if (schema[key] !== undefined && (!Number.isInteger(schema[key]) || schema[key] < 0)) return false;
 for (const key of ['minimum','maximum']) if (schema[key] !== undefined && (typeof schema[key] !== 'number' || !Number.isFinite(schema[key]))) return false;
 if (schema.enum !== undefined && (!Array.isArray(schema.enum) || !schema.enum.length)) return false;
 if (schema.type === 'object') {
  if (schema.additionalProperties !== false || !schema.properties || typeof schema.properties !== 'object' || Array.isArray(schema.properties)) return false;
  if (!Object.values(schema.properties).every(child => schemaSupported(child, depth + 1))) return false;
  if (schema.required && (!Array.isArray(schema.required) || !schema.required.every(key => typeof key === 'string' && Object.hasOwn(schema.properties,key)))) return false;
 }
 if (schema.type === 'array' && !schemaSupported(schema.items, depth + 1)) return false;
 return true;
}
function validate(value, schema) {
 if (schema.const !== undefined && stable(value) !== stable(schema.const)) return false;
 if (schema.enum && (!Array.isArray(schema.enum) || !schema.enum.some(x => stable(x) === stable(value)))) return false;
 switch (schema.type) {
  case 'null': return value === null;
  case 'boolean': return typeof value === 'boolean';
  case 'number': case 'integer': return typeof value === 'number' && Number.isFinite(value) && (schema.type !== 'integer' || Number.isInteger(value)) && (schema.minimum === undefined || value >= schema.minimum) && (schema.maximum === undefined || value <= schema.maximum);
  case 'string': return typeof value === 'string' && (schema.minLength === undefined || value.length >= schema.minLength) && (schema.maxLength === undefined || value.length <= schema.maxLength);
  case 'array': return Array.isArray(value) && (schema.minItems === undefined || value.length >= schema.minItems) && (schema.maxItems === undefined || value.length <= schema.maxItems) && value.every(x => validate(x,schema.items));
  case 'object': return !!value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).every(key => Object.hasOwn(schema.properties,key) && validate(value[key],schema.properties[key])) && (schema.required || []).every(key => Object.hasOwn(value,key));
  default: return false;
 }
}
function normalizeConfig(raw) {
 try {
  if (!raw || typeof raw !== 'object' || typeof raw.server !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/.test(raw.server) || typeof raw.tool !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/.test(raw.tool)) return null;
  if (!schemaSupported(raw.inputSchema) || raw.inputSchema.type !== 'object' || typeof raw.selectedScope !== 'string' || !raw.selectedScope.trim() || raw.selectedScope.length > 2000) return null;
  if (!validate(raw.arguments,raw.inputSchema) || raw.arguments.scope !== raw.selectedScope || Object.hasOwn(raw.arguments,'cursor')) return null;
  if (!['scope'].every(key => (raw.inputSchema.required || []).includes(key))) return null;
  const result = {server:raw.server,tool:raw.tool,inputSchema:raw.inputSchema,arguments:raw.arguments,selectedScope:raw.selectedScope};
  if (stable(result).length > 24000) return null;
  return JSON.parse(JSON.stringify(result));
 } catch { return null; }
}
function binding(source) { return digest({path:source.path,mcp:source.mcp}); }
const fail = (state,error) => ({state,available:false,text:'',error});
async function readMcpSource(dataDir,source,{client,signal}={}) {
 let connection;
 const cancelled = () => { if (signal?.aborted) throw Object.assign(Error('cancelled'),{cancelled:true}); };
 try {
  const config = normalizeConfig(source.mcp), url = endpoint(source.path);
  if (!config || source.enabled === false) return fail('disconnected','MCP 来源未启用或配置无效');
  cancelled();
  connection = client || require('./notion-mcp-bridge').http({url});
  const rpc = async (method,params,notify=false) => {
   cancelled();
   let remove = () => {};
   try {
    const operation = connection.rpc(method,params,notify);
    const result = signal ? await Promise.race([operation,new Promise((resolve,reject)=>{ const abort=()=>reject(Object.assign(Error('cancelled'),{cancelled:true}));signal.addEventListener('abort',abort,{once:true});remove=()=>signal.removeEventListener('abort',abort);if(signal.aborted)abort(); })]) : await operation;
    cancelled(); return result;
   } finally { remove(); }
  };
  await rpc('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'citeside-context-source',version:'1.0'}});
  await rpc('notifications/initialized',{},true);
  let cursor, tool, catalogPages=0; const catalogCursors=new Set();
  do {
   if (++catalogPages > 20) throw Error('catalog_incomplete');
   const page = await rpc('tools/list',cursor?{cursor}:{});
   if (!Array.isArray(page?.tools)) throw Error('catalog_incomplete');
   for (const candidate of page.tools) if (candidate.name === config.tool) { if (tool) throw Error('ambiguous_tool'); tool=candidate; }
   cursor = page.nextCursor;
   if (cursor !== undefined && (typeof cursor !== 'string' || !cursor || catalogCursors.has(cursor))) throw Error('catalog_incomplete');
   if(cursor)catalogCursors.add(cursor);
  } while(cursor);
  if (!tool || tool.annotations?.readOnlyHint !== true || tool.annotations?.destructiveHint === true) return fail('denied','所选 MCP 工具未声明只读，未执行');
  if (stable(tool.inputSchema) !== stable(config.inputSchema)) return fail('denied','MCP 工具输入 schema 已变化，请重新确认配置');
  let pages=0, version, text='', next; const cursors=new Set(), pageHashes=[];
  const read = async args => {
   if (!validate(args,config.inputSchema)) throw Error('invalid_arguments');
   const result = await rpc('tools/call',{name:config.tool,arguments:args});
   if (result?.isError) throw Error('tool_failed');
   const value = result?.structuredContent;
   if (!value || typeof value.text !== 'string' || typeof value.version !== 'string' || !value.version || value.scope !== config.selectedScope || value.truncated === true || typeof value.complete !== 'boolean') throw Error('incomplete_or_scope');
   if (version !== undefined && value.version !== version) throw Error('version_changed');
   version = value.version;
   return value;
  };
  do {
   if(++pages>20)throw Error('incomplete_pages');
   const page = await read({...config.arguments,...(next?{cursor:next}:{})});
   text += page.text;pageHashes.push(digest(page.text));
   if(text.length>200000)throw Error('incomplete_size');
   next=page.nextCursor;
   if (page.complete ? next !== undefined && next !== null && next !== '' : typeof next !== 'string' || !next || cursors.has(next)) throw Error('incomplete_pages');
   if(!page.complete)cursors.add(next);
   if(page.complete)break;
  } while(true);
  // Recheck the same selected source after all pages; never cache mixed revisions.
  const check=await read(config.arguments);
  if(digest(check.text)!==pageHashes[0])throw Error('version_changed');
  cancelled();
  return {state:'ready',available:true,text,version,coverage:{kind:'mcp_selected_scope',complete:true,pages},receipt:{binding:binding(source),server:config.server,tool:config.tool,scope:config.selectedScope,schemaHash:digest(config.inputSchema),pageHashes}};
 } catch(error) {
  return error.cancelled || signal?.aborted ? fail('cancelled','MCP 读取已取消，未导入') : fail('failed','MCP 完整读取失败；请检查连接、权限、范围和版本后重试');
 } finally { try { connection?.close(); } catch {} }
}
module.exports={endpoint,normalizeConfig,binding,readMcpSource};
