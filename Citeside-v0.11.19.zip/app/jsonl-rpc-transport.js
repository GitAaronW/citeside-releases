'use strict';

// Tool-free subprocess transport prerequisite. It owns no conversation history,
// credentials, provider selection or retries. A failed connection is never reused.
const { EventEmitter } = require('events');

function failure(code) {
  const error = new Error(code);
  error.code = code;
  return error;
}

class JsonlRpcTransport extends EventEmitter {
  constructor(child, { timeoutMs = 15000, maxPending = 16, maxFrameBytes = 1024 * 1024, killAfterMs = 1000 } = {}) {
    super();
    for (const value of [timeoutMs, maxPending, maxFrameBytes, killAfterMs]) {
      if (!Number.isSafeInteger(value) || value <= 0) throw new TypeError('positive integer limits required');
    }
    this.child = child;
    this.timeoutMs = timeoutMs;
    this.maxPending = maxPending;
    this.maxFrameBytes = maxFrameBytes;
    this.killAfterMs = killAfterMs;
    this.pending = new Map();
    this.sequence = 0;
    this.buffer = Buffer.alloc(0);
    this.closed = false;
    this.exited = false;
    this.reason = '';
    child.stdout.on('data', chunk => this.receive(chunk));
    // Drain diagnostics without storing potentially sensitive model output.
    child.stderr.on('data', () => {});
    child.stderr.on('error', () => this.close('transport_read_failed'));
    child.stdin.on('error', () => this.close('transport_write_failed'));
    child.stdout.on('error', () => this.close('transport_read_failed'));
    child.on('error', () => this.close('transport_spawn_failed'));
    child.once('exit', () => this.didExit());
    child.once('close', () => this.didExit());
  }

  didExit() {
    this.exited = true;
    clearTimeout(this.killTimer);
    this.close('transport_closed');
  }

  request(method, params, { signal, timeoutMs = this.timeoutMs } = {}) {
    if (signal?.aborted) return Promise.reject(failure('cancelled'));
    if (this.closed) return Promise.reject(failure(this.reason));
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) return Promise.reject(failure('invalid_timeout'));
    if (this.pending.size >= this.maxPending) return Promise.reject(failure('transport_busy'));
    let frame;
    const id = ++this.sequence;
    try { frame = this.encode({ id, method, params }); } catch (error) { return Promise.reject(error); }
    return new Promise((resolve, reject) => {
      const settle = (error, result) => {
        if (!this.pending.delete(id)) return;
        clearTimeout(timer);
        signal?.removeEventListener('abort', abort);
        error ? reject(error) : resolve(result);
      };
      // Cancellation/timeout taints the process: close it to stop abandoned work
      // before the caller can recover through the existing independent exec path.
      const abort = () => this.close('cancelled');
      const timer = setTimeout(() => this.close('timeout'), timeoutMs);
      this.pending.set(id, settle);
      signal?.addEventListener('abort', abort, { once: true });
      if (signal?.aborted) return abort();
      this.write(frame);
    });
  }

  notify(method, params) {
    if (this.closed) throw failure(this.reason);
    this.write(this.encode({ method, params }));
  }

  encode(message) {
    const frame = JSON.stringify(message) + '\n';
    if (Buffer.byteLength(frame) > this.maxFrameBytes) throw failure('frame_too_large');
    return frame;
  }

  write(frame) {
    try {
      this.child.stdin.write(frame, error => { if (error) this.close('transport_write_failed'); });
    } catch (_) { this.close('transport_write_failed'); }
  }

  receive(chunk) {
    if (this.closed) return;
    this.buffer = Buffer.concat([this.buffer, Buffer.from(chunk)]);
    let boundary;
    while ((boundary = this.buffer.indexOf(10)) >= 0) {
      if (boundary > this.maxFrameBytes) return this.close('frame_too_large');
      const frame = this.buffer.subarray(0, boundary);
      this.buffer = this.buffer.subarray(boundary + 1);
      if (!frame.length) continue;
      let message;
      try { message = JSON.parse(frame.toString('utf8')); } catch (_) { return this.close('invalid_frame'); }
      if (!message || typeof message !== 'object' || Array.isArray(message)) return this.close('invalid_frame');
      if (typeof message.method === 'string') {
        if (Object.hasOwn(message, 'id')) {
          // No server-initiated tools/approvals are ever executed by this adapter.
          try {
            this.write(this.encode({ id: message.id, error: { code: -32601, message: 'Server requests disabled' } }));
          } catch (_) { return this.close('frame_too_large'); }
        } else {
          this.emit('notification', message);
        }
      } else if (this.pending.has(message.id)) {
        if (!Object.hasOwn(message, 'result') && !Object.hasOwn(message, 'error')) return this.close('invalid_frame');
        this.pending.get(message.id)(message.error ? failure('rpc_failed') : null, message.result);
      }
      if (this.closed) return;
    }
    if (this.buffer.length > this.maxFrameBytes) this.close('frame_too_large');
  }

  close(reason = 'transport_closed') {
    if (this.closed) return;
    this.closed = true;
    this.reason = reason;
    this.buffer = Buffer.alloc(0);
    for (const settle of [...this.pending.values()]) settle(failure(reason));
    if (!this.exited) {
      try { this.child.kill('SIGTERM'); } catch (_) {}
      this.killTimer = setTimeout(() => {
        if (!this.exited) { try { this.child.kill('SIGKILL'); } catch (_) {} }
      }, this.killAfterMs);
      this.killTimer.unref();
    }
    this.emit('closed', reason);
  }
}

module.exports = { JsonlRpcTransport };
