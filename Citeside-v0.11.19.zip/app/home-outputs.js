'use strict';
// Home-rail recent outputs: deep research reports only.
// Meeting notes stay in 会议记录. Scheme documents and drafts stay in the meeting.
// Titles only. Ordinary meeting markdown is not an output.
// Not a new library. Outline (BSL) and AppFlowy (AGPL) are not vendored.
const fs = require('fs');
const path = require('path');

const clip = (s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);
const {researchOf,snapshot,sidOk}=require('./saved-research');

function meetingName(sid, titles, sources) {
  const titled = titles && titles[sid] && titles[sid].topicTitle;
  const source = (sources || []).find(s => s && s.sessionId === sid);
  return clip(titled || (source && source.title) || '', 80);
}

function list({ dataDir = '', sources = [], titles = {}, limit = 8, all = false, deletedIds = [] } = {}) {
  const cap = all===true?Infinity:Math.max(1, Math.min(20, Number(limit) || 8)),gone=new Set(deletedIds.map(String));
  const items = [];
  let files = [];
  try { const dir=path.join(dataDir,'live-reports');if(fs.lstatSync(dir).isSymbolicLink())return [];files = fs.readdirSync(dir).filter(f => f.endsWith('.json') && !f.startsWith('.')); }
  catch (e) {}
  for (const file of files) {
    const sid = file.slice(0, -5);
    if (!sidOk(sid)||gone.has(sid)) continue;
    let report;try{report=snapshot(dataDir,sid);}catch{continue;}
    if (!report || typeof report !== 'object' || Array.isArray(report)) continue;
    const meeting = meetingName(sid, titles, sources);
    const atReport = report.updatedAt || '';
    for (const row of researchOf(report)) {
      items.push({ id: 'research:' + sid + ':' + row.id, sessionId: sid, kind: 'research', title: row.title, meeting, at: row.at || atReport });
    }
  }
  items.sort((a, b) => (Date.parse(b.at) || 0) - (Date.parse(a.at) || 0));
  return items.slice(0, cap).map(({ id, sessionId, kind, title, meeting, at }) => ({ id, sessionId, kind, title, meeting, at }));
}

module.exports = { list };
