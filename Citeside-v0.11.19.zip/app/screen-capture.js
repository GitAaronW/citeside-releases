'use strict';
// 会中 ＋ 菜单「截一张屏」：服务端截主屏，存成会议材料（和「添加文件或照片」同一条存储：assistant-materials.put）。
// 没有屏幕录制权限时 macOS 不报错，只给一张只有桌面壁纸（或全空）的图；所以先用窗口标题探权限，截完再查空图，
// 两道都过才存，不把假图当材料。
const fs=require('fs'),os=require('os'),path=require('path'),crypto=require('crypto'),{execFile}=require('child_process');
const materials=require('./assistant-materials');

const ROUTES=new Set(['/api/screen-capture','/asr-relay/api/screen-capture']);
const HINT='在 系统设置 → 隐私与安全性 → 屏幕录制 里打开Citeside';
const MAX_BYTES=5*1024*1024;
const PNG_SIG=Buffer.from([137,80,78,71,13,10,26,10]);

function permissionError(reason){return Object.assign(Error('screen_permission_missing'),{status:409,code:'screen_permission_missing',reason});}
function run(file,args,timeout=15000){
 return new Promise(resolve=>execFile(file,args,{timeout,maxBuffer:1024*1024},(error,stdout,stderr)=>resolve({error,stdout:String(stdout||''),stderr:String(stderr||'')})));
}

// 没有屏幕录制权限时，CGWindowListCopyWindowInfo 仍列出别的 app 的窗口，但拿不到窗口标题（kCGWindowName 缺失）。
// 有别人的窗口却一个标题都没有 = 没权限；一个窗口都没有 = 判断不了，交给截完后的空图检查。
const PREFLIGHT='ObjC.import("CoreGraphics");var a=ObjC.deepUnwrap(ObjC.castRefToObject($.CGWindowListCopyWindowInfo(1|16,0)))||[];'+
 'var me=$.NSProcessInfo.processInfo.processIdentifier;var w=a.filter(function(x){return x.kCGWindowLayer===0&&x.kCGWindowOwnerPID!==me;});'+
 'JSON.stringify({windows:w.length,named:w.filter(function(x){return typeof x.kCGWindowName==="string";}).length})';
function judgePreflight(j){
 if(!j||!Number.isFinite(j.windows)||!Number.isFinite(j.named))return 'unknown';
 if(j.windows>0&&j.named===0)return 'denied';
 return j.windows>0?'granted':'unknown';
}
async function preflight(){
 const r=await run('/usr/bin/osascript',['-l','JavaScript','-e',PREFLIGHT],8000);
 if(r.error)return 'unknown';
 try{return judgePreflight(JSON.parse(r.stdout.trim()));}catch{return 'unknown';}
}

function pngSize(bytes){
 if(bytes.length<24||!bytes.subarray(0,8).equals(PNG_SIG)||bytes.subarray(12,16).toString('latin1')!=='IHDR')return null;
 return {width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)};
}
// 全屏一个颜色的 PNG 压完每像素远不到 0.003 字节；真实屏幕（文字、界面）高一两个数量级。
function looksBlank(bytes){
 const size=pngSize(bytes);if(!size||!size.width||!size.height)return true;
 return bytes.length<4096||bytes.length/(size.width*size.height)<0.003;
}

async function defaultCapture({tmpDir=os.tmpdir()}={}){
 if(process.platform!=='darwin')throw Object.assign(Error('截屏只支持 macOS'),{status:501,code:'unsupported_platform'});
 if(await preflight()==='denied')throw permissionError('preflight');
 const file=path.join(tmpDir,'tht-shot-'+crypto.randomUUID()+'.png');
 try{
  const r=await run('/usr/sbin/screencapture',['-x','-m','-t','png',file]);
  let bytes=null;try{bytes=fs.readFileSync(file);}catch{}
  if(r.error||!bytes||!bytes.length){
   if(/could not create image|not authori[sz]ed|permission|denied/i.test(r.stderr))throw permissionError('screencapture');
   throw Object.assign(Error('截屏失败：'+(r.stderr.trim()||r.error?.message||'没有生成图片')),{status:500,code:'capture_failed'});
  }
  // 材料上限 5 MB；Retina 全屏 PNG 偶尔超，缩到长边 1920 再存。
  if(bytes.length>MAX_BYTES-64*1024){await run('/usr/bin/sips',['-Z','1920',file,'--out',file]);bytes=fs.readFileSync(file);}
  return bytes;
 }finally{fs.rmSync(file,{force:true});}
}

function stamp(d){
 const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(d).map(x=>[x.type,x.value]));
 return p.year+'-'+p.month+'-'+p.day+' '+p.hour+'.'+p.minute+'.'+p.second;
}

// 截一张、校验、存成材料。capture 可注入（测试不真截屏）。
async function takeShot({dataDir,capture=defaultCapture,now=()=>new Date()}){
 const bytes=await capture();
 if(!Buffer.isBuffer(bytes)||!bytes.length)throw Object.assign(Error('截屏失败：没有生成图片'),{status:500,code:'capture_failed'});
 if(!pngSize(bytes))throw Object.assign(Error('截屏失败：不是 PNG'),{status:500,code:'capture_failed'});
 if(looksBlank(bytes))throw permissionError('blank_image');
 return materials.put(dataDir,{name:'屏幕截图 '+stamp(now())+'.png',base64:bytes.toString('base64')});
}

// ctx: {authed,isLocal,dataDir,hasSession(id)=>bool,capture?,now?}
async function route(req,res,u,ctx){
 if(!ROUTES.has(u.pathname))return false;
 const send=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(j));return true;};
 if(!ctx.authed)return send(401,{error:'unauthorized'});
 if(req.method!=='POST')return send(405,{error:'method not allowed'});
 // 截的是这台电脑的屏幕：只许本机同源页面触发，远程口令也不行。
 if(!ctx.isLocal)return send(403,{error:'截屏仅限本机'});
 try{if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)return send(403,{error:'origin mismatch'});}catch{return send(403,{error:'origin mismatch'});}
 let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>2048)return send(413,{error:'request too large'});}
 let j;try{j=JSON.parse(raw||'{}');}catch{return send(400,{error:'bad_json'});}
 const sessionId=typeof j?.sessionId==='string'?j.sessionId:'';
 if(!/^[a-zA-Z0-9_-]{1,100}$/.test(sessionId)||!ctx.hasSession?.(sessionId))return send(404,{error:'session_not_found'});
 try{return send(200,{material:await takeShot({dataDir:ctx.dataDir,capture:ctx.capture,now:ctx.now})});}
 catch(e){
  if(e.code==='screen_permission_missing')return send(409,{error:'screen_permission_missing',hint:HINT});
  return send(e.status||500,{error:e.code||'capture_failed',message:e.message});
 }
}

module.exports={route,takeShot,defaultCapture,preflight,judgePreflight,looksBlank,HINT,ROUTES};
