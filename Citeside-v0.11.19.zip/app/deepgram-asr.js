'use strict';
// Deepgram 流式转写：给不方便注册火山的人用（邮箱注册即可，官方送额度）。
// 协议：WebSocket 直传 16k 单声道 PCM，服务端回 JSON，is_final 为最终句。
const WebSocket = require('ws');
const LANG = { zh: 'zh-CN', en: 'en-US', id: 'id', pt: 'pt-BR', es: 'es' };
const DEFAULT_MODEL = 'nova-3';
const DEFAULT_ENDPOINT = 'wss://api.deepgram.com/v1/listen';
const KEYTERM_CAP = 100;
const KEYTERM_REFRESH_COOLDOWN_MS = 60000;
const MODEL_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;

// 多词 keyterm 保留单个空格。忽略大小写去重，最多 100 条。返回新数组，调用方之后改原数组不影响这里。
function normalizeKeyterms(list) {
  const out = []; const seen = new Set();
  for (const term of Array.isArray(list) ? list : []) {
    const w = String(term == null ? '' : term).trim().replace(/\s+/g, ' ');
    if (!w) continue;
    const key = w.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key); out.push(w);
    if (out.length >= KEYTERM_CAP) break;
  }
  return out;
}
const CONFIG_TEXT = {
  bad_deepgram_model: 'Deepgram 型号不合法，没有连接，也没有改用默认型号。',
  bad_deepgram_endpoint: 'Deepgram 地址不合法，没有连接，也没有改用默认地址。',
  bad_deepgram_options: 'Deepgram 配置不合法，没有连接。',
};

function failConfig(code) {
  return { ok: false, code, error: CONFIG_TEXT[code] || CONFIG_TEXT.bad_deepgram_options };
}

function loopbackHost(hostname) {
  const host = String(hostname || '').replace(/^\[|\]$/g, '').toLowerCase();
  if (host === 'localhost' || host === '::1') return true;
  const parts = host.split('.');
  return parts.length === 4 && parts[0] === '127' && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255);
}

// 缺省用 nova-3 和现有 wss 地址。显式写了坏型号或坏地址就失败，不改写成默认值。
function resolveDeepgramConfig(options) {
  if (options == null) options = {};
  if (typeof options !== 'object' || Array.isArray(options)) return failConfig('bad_deepgram_options');
  let model;
  if (options.model == null || options.model === '') model = DEFAULT_MODEL;
  else if (typeof options.model !== 'string' || !MODEL_RE.test(options.model.trim())) return failConfig('bad_deepgram_model');
  else model = options.model.trim();
  let endpoint;
  if (options.endpoint == null || options.endpoint === '') endpoint = DEFAULT_ENDPOINT;
  else if (typeof options.endpoint !== 'string') return failConfig('bad_deepgram_endpoint');
  else {
    const text = options.endpoint.trim();
    if (!text || /[\u0000-\u0020\u007f]|[?#@]/.test(text)) return failConfig('bad_deepgram_endpoint');
    let url;
    try { url = new URL(text); } catch (e) { return failConfig('bad_deepgram_endpoint'); }
    if (url.username || url.password || url.search || url.hash) return failConfig('bad_deepgram_endpoint');
    if (url.protocol === 'ws:') { if (!loopbackHost(url.hostname)) return failConfig('bad_deepgram_endpoint'); }
    else if (url.protocol !== 'wss:') return failConfig('bad_deepgram_endpoint');
    endpoint = text;
  }
  return { ok: true, model: String(model), endpoint: String(endpoint) };
}

function listenSearchParams(lang, keyterms, model) {
  const chosen = model == null || model === '' ? DEFAULT_MODEL : String(model).trim();
  if (!MODEL_RE.test(chosen)) throw Object.assign(new Error(CONFIG_TEXT.bad_deepgram_model), { code: 'bad_deepgram_model' });
  const p = new URLSearchParams({
    model: chosen, language: LANG[lang] || lang || 'zh-CN', encoding: 'linear16', sample_rate: '16000',
    channels: '1', punctuate: 'true', smart_format: 'true', interim_results: 'true', endpointing: '800',
  });
  for (const w of normalizeKeyterms(keyterms)) p.append('keyterm', w);
  return p;
}

function buildListenUrl(endpoint, lang, keyterms, model) {
  if (typeof endpoint !== 'string' || !endpoint || /[?#@]/.test(endpoint)) {
    throw Object.assign(new Error(CONFIG_TEXT.bad_deepgram_endpoint), { code: 'bad_deepgram_endpoint' });
  }
  return endpoint + '?' + listenSearchParams(lang, keyterms, model).toString();
}

class DeepgramAsr {
  constructor(lang, key, onResult, log = () => {}, keyterms = [], options = {}) {
    this.env=options?.env||{};this.beforeStart=options.beforeStart;this.canSend=options.canSend;
    this.lang = LANG[lang] || 'zh-CN'; this.key = key; this.onResult = onResult; this.log = log;
    this.keyterms = normalizeKeyterms(keyterms);
    this.sentKeyterms = new Set(); this.lastKeytermRefreshAt = null;
    const refreshOpts = options && typeof options === 'object' && !Array.isArray(options) ? options : {};
    this.allowLiveRefresh = refreshOpts.allowLiveKeytermRefresh === true;
    this.keytermCooldownMs = Number.isFinite(refreshOpts.keytermCooldownMs) ? refreshOpts.keytermCooldownMs : KEYTERM_REFRESH_COOLDOWN_MS;
    this.now = typeof refreshOpts.now === 'function' ? refreshOpts.now : () => Date.now();
    const resolved = resolveDeepgramConfig(options);
    this.model = resolved.ok ? resolved.model : null;
    this.endpoint = resolved.ok ? resolved.endpoint : null;
    this.configError = resolved.ok ? '' : resolved.error;
    this.configErrorCode = resolved.ok ? '' : resolved.code;
    this.ws = null; this.dead = false; this.retries = 0; this.queue = []; this.queued = 0; this.droppedBytes = 0;
  }
  updateKeyterms(list, opts = {}) {
    this.keyterms = normalizeKeyterms(list);
    // 没在听的时候只把词留下，下次 connect 的查询串自然带上。不要为了热词去连一条新的。
    if (!this.ws || this.dead || this.configError) return false;
    if (this.ws.readyState !== WebSocket.OPEN) return false;
    const sent = this.sentKeyterms || new Set();
    const fresh = this.keyterms.some(w => !sent.has(w.toLowerCase()));
    if (!fresh) return false;
    const o = opts && typeof opts === 'object' ? opts : {};
    if (!(this.allowLiveRefresh || o.reconnect === true)) return false;
    const now = this.now();
    if (this.lastKeytermRefreshAt != null && now - this.lastKeytermRefreshAt < this.keytermCooldownMs) return false;
    // 计划内换连接：旧 close 不计入失败。这中间进来的 PCM 走 write() 的 queue，新连接 open 时 flush。
    this.lastKeytermRefreshAt = now;
    const old = this.ws;
    old.__plannedKeytermRefresh = true;
    this.ws = null;
    try { if (old.readyState === WebSocket.OPEN) old.send(JSON.stringify({ type: 'CloseStream' })); } catch (e) {}
    try { old.close(); } catch (e) {}
    this.connect();
    return true;
  }

  start() {
    if (!this.beforeStart) return this.connect();
    if (this.dead || this.startPending) return this.startPending;
    this.startPending=Promise.resolve().then(()=>this.beforeStart()).then(allowed=>{
      if(!allowed){this.stop();return;}
      if(!this.dead)this.connect();
    }).catch(()=>this.stop()).finally(()=>{this.startPending=null;});
    return this.startPending;
  }
  connect() {
    if (this.dead) return;
    if (this.ws) { try { this.ws.removeAllListeners(); this.ws.close(); } catch (e) {} this.ws = null; }   // 防重入：旧连接还开着会导致转写重复落稿
    if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; }
    if (this.configError) { this.dead = true; this.onResult({ type: 'fatal', code: this.configErrorCode, text: this.configError }); return; }
    if (!this.key) { this.onResult({ type: 'fatal', text: 'Deepgram 的 Key 没填。' }); return; }
    let url;
    try { url = buildListenUrl(this.endpoint, this.lang, this.keyterms, this.model); }
    catch (e) { this.dead = true; this.onResult({ type: 'fatal', code: e.code || 'bad_deepgram_endpoint', text: e.message }); return; }
    try { require('./outbound-policy').assertAllowed(this.env,'asr',url); }
    catch(e){this.dead=true;this.onResult({type:'fatal',code:e.code,text:'转写外发被配置阻止（'+e.code+'）；录音保留，请检查配置后重试。'});return;}
    let ws;
    try { ws = new WebSocket(url, { headers: { Authorization: 'Token ' + this.key } }); }
    catch (e) { this.onResult({ type: 'fatal', text: 'Deepgram 连不上：' + e.message }); return; }
    this.ws = ws;
    this.sentKeyterms = new Set(this.keyterms.map(w => w.toLowerCase()));
    ws.on('open', () => { this.log('Deepgram 已连上 ' + this.lang); this.flush(); });   // 重试计数不在这里清零：连上就被拒的场景会变成无限重连
    ws.on('message', d => {
      let j; try { j = JSON.parse(d.toString()); } catch (e) { return; }
      if (j.type === 'Error' || j.error) {
        const msg = String(j.error || j.description || j.message || '').slice(0, 160);
        // 只有鉴权和额度类才是永久的；限流、瞬时网络错误要留着重连，否则一帧就断送整场
        const permanent = /unauthor|forbidden|invalid.*key|quota|credit|payment|suspend/i.test(msg);
        if (permanent) { this.dead = true; try { ws.close(); } catch (e) {} this.onResult({ type: 'fatal', text: 'Deepgram 拒绝了这次请求：' + msg }); }
        else { this.log('Deepgram 可恢复错误，重连：' + msg); try { ws.close(); } catch (e) {} }
        return;
      }
      const alt = j.channel && j.channel.alternatives && j.channel.alternatives[0];
      const text = (alt && alt.transcript || '').trim();
      if (!text) return;
      this.retries = 0;                      // 真收到转写才算这条连接是好的；只在 open 清零会让「连上即被拒」变成无限重连
      this.onResult({ type: j.is_final ? 'final' : 'partial', text });
    });
    ws.on('close', (code) => {
      const planned = ws.__plannedKeytermRefresh === true;
      if (this.ws === ws) this.ws = null;
      if (planned || this.dead) return;
      if (code === 1008 || code === 4001 || code === 401) { this.onResult({ type: 'fatal', text: 'Deepgram 拒绝了这个 Key，请检查。' }); this.dead = true; return; }
      if (this.retries++ < 5) { this.log('Deepgram 断开（' + code + '），重连第 ' + this.retries + ' 次'); this.retryTimer = setTimeout(() => this.start(), 800 * this.retries); }
      else this.onResult({ type: 'fatal', text: 'Deepgram 反复断开，已停止重试。' });
    });
    ws.on('error', e => {
      const m = String(e && e.message || '');
      this.log('Deepgram 错误 ' + m);
      // Key 不对时 ws 库给的是 error 事件里的 401/403，close code 是 1006；
      // 只判 close code 永远等不到，用户会被误导成「反复断开」。
      if (/\b40[13]\b/.test(m)) { this.dead = true; this.onResult({ type: 'fatal', text: 'Deepgram 拒绝了这个 Key，请到设置页检查。' }); }
    });
  }
  flush() { const q = this.queue; this.queue = []; this.queued = 0; for (const b of q) this.write(b); }
  write(pcm) {
    if(this.canSend&&!this.canSend()){this.stop();return;}
    const w = this.ws;
    if (w && w.readyState === WebSocket.OPEN) { try { w.send(pcm); } catch (e) { this.log('Deepgram 发送失败 ' + e.message); } return; }
    if (this.dead) return;
    // TypedArray 直接 Buffer.from 会逐元素 &0xFF，把 16 位样本截成 8 位，重连后那几秒全是乱码
    const buf = Buffer.isBuffer(pcm) ? pcm
      : (ArrayBuffer.isView(pcm) ? Buffer.from(Buffer.from(pcm.buffer, pcm.byteOffset, pcm.byteLength)) : Buffer.from(pcm));   // 真拷贝：排队的音频不能跟上游共享内存
    this.queue.push(buf); this.queued += buf.length;
    // 必须先判队列非空：pcm 可能是 TypedArray，length 与字节数不同，计数会和实际长度脱节，
    // shift() 返回 undefined 再读 .length 会直接打断录音路径。
    while (this.queue.length && this.queued > 32000 * 20) { const b = this.queue.shift(); this.queued -= (b ? b.length : 0); this.droppedBytes += (b ? b.length : 0); }
    if (!this.queue.length) this.queued = 0;
  }
  drain(ms = 6000) {
    return new Promise(res => {
      this.dead = true;
      if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; }
      const w = this.ws;
      if (!w) return res();
      if (w.readyState === WebSocket.CONNECTING) { w.once('open', () => { try { w.send(JSON.stringify({ type: 'CloseStream' })); } catch (e) {} }); }
      else if (w.readyState !== WebSocket.OPEN) { try { w.close(); } catch (e) {} return res(); }
      let done = false, timer = null;
      const fin = () => { if (done) return; done = true; if (timer) clearTimeout(timer); try { w.close(); } catch (e) {} res(); };
      w.once('close', fin); timer = setTimeout(fin, ms);
      try { w.send(JSON.stringify({ type: 'CloseStream' })); } catch (e) { fin(); }   // 让它把最后一句吐完
    });
  }
  stop() { this.dead = true; if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; } try { this.ws && this.ws.close(); } catch (e) {} this.ws = null; }
}
module.exports = { DeepgramAsr, listenSearchParams, buildListenUrl, resolveDeepgramConfig, DEFAULT_MODEL, DEFAULT_ENDPOINT, KEYTERM_REFRESH_COOLDOWN_MS, LANG };
