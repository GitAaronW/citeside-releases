'use strict';
// 会中卡片的覆盖与证据闸。北极星 baseline-v3（2026-10-24，9 场、DeepSeek）判出三类问题：
// ① 漏主线——模型每次只看最后 6 句，回放里六成句子从没给它看过，决定和待办自然漏；
// ② 转写错字当事实——会话里 names / fixes / 参会人全空，MTK 转成「展锐 MDK」、脚本「叶工」被当成人；
// ③ 重复、矛盾、凭空数字——模型看不到自己出过的卡。
// 数据目录里的自定义规则只管卡片措辞；证据范围和响应协议由代码自带（同 native-work-decision 的口径），
// 这样评测沙箱和生产拿到的是同一段。
const KINDS = ['external', 'gap', 'internal'];
// 含决定 / 承诺 / 分工 / 时间点的句子：只是把模型的注意力领过去，不替它判断。
const CUE = /(定了|就这么|就按|确定|决定|拍板|敲定|先这样|负责|牵头|跟进|follow\s?up|截止|deadline|之前(?:给|发|交)|发给|给到|我来|你来|我去|你去|待办|todo|action item|下周|下下周|周[一二三四五六日天]|明天|后天|月底|月初|本周|这周|下个月|[0-9０-９]+\s*(?:月|号|日)|demo|评审|排期|交付|上线|样品)/i;
function cues(rows) { return (rows || []).filter(r => r && CUE.test(String(r.text || ''))).map(r => r.id); }

const prompt = `
覆盖与证据规则（与上面的措辞规则冲突时以这里为准）：
- transcript 是上次调用之后新出现的句子（开头几句是衔接上下文），每句只给你看这一次。这批里真实形成的决定、承诺、分工、时间点，必须本次就出「内部推进」卡（sourceLayer=internal）：新信息只写一句会上刚定的事，动作写成待办草稿（谁、做什么、何时，原话有就写）。逐项判断独立决定的相关性与推进价值，不按卡片数量取舍。漏掉一条真实决定比多出一张卡更糟。cues 列出的是含决定/承诺/分工/时间词的句 id，逐句判断，但不是只看这些句。
- 每张卡必须带 sourceLayer 字段（与 cardType 的问题/决定等类型分开）："external"（外部补充）/ "gap"（遗漏视角）/ "internal"（内部推进）。
- 转写来自语音识别，人名、公司名、芯片与型号名、缩写常被转成同音词。遇到不认识的名字先看上下文：上下文说它是脚本、工具、文档，就不当人、不派活；芯片与平台名优先按本行业常见名理解（联发科 MTK / 天玑、高通 / 骁龙、展锐、三星 Exynos、苹果 A 系列、Whisper、Deepgram、FP4 / FP8 / INT4 等）。拿不准的名字写「转写疑似 X」，不以疑似错字为前提展开外部补充或派待办。
- issuedCards 是你此前已出的卡：同一个点不再出，换个说法也不出。只有会上新说法改变了已出卡的结论时才出，text 以「更新：」开头并说清改了什么；不出与已出卡矛盾的卡。
- 数字：internal / gap 卡里的数字只能是会上说过的，没说过就不写数字；external 卡里凭记忆的数字标「需核实」。不在会上的数字之间自行换算、相加或推时间线。
`;

// 两位以上的数字（1.5、35、2026-10）；单个数字如「3 轮」放行，和评测的硬规则同口径。
const NUM = /\d+(?:[.,]\d+)?/g;
const normNum = n => String(n).replace(/[,，]/g, '').replace(/\.0+$/, '');
// 会上说过的数字按整个数字 token 比，不按子串：原文有 800 不等于说过 8000 或 1800（peer_review 04c30cf9）。
// 转写里的中文数字（三十五台、两千、一百八十）也算说过，模型写成阿拉伯数字时不冤枉它。
const CN_DIGIT = { 零: 0, 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 }, CN_UNIT = { 十: 10, 百: 100, 千: 1000, 万: 10000, 亿: 100000000 };
function cnNumbers(text) {
  const out = [];
  for (const m of String(text || '').match(/[零一二两三四五六七八九十百千万亿]+/g) || []) {
    let total = 0, section = 0, digit = 0;
    for (const ch of m) {
      if (ch in CN_DIGIT) digit = CN_DIGIT[ch];
      // 打头的单位按「一」算：十五、千万、百分之…（peer_review 复审「预算千万」）
      else { const u = CN_UNIT[ch], lead = total === 0 && section === 0 && digit === 0; if (u >= 10000) { total = (total + section + (digit || (lead ? 1 : 0))) * u; section = 0; } else section += (digit || (lead || (ch === '十' && section === 0) ? 1 : 0)) * u; digit = 0; }
    }
    const v = total + section + digit; if (v >= 10) out.push(String(v));
  }
  return out;
}
// 卡片里的中文数字（十五、三十五台）同样要会上说过（peer_review cc2428f8）；十分 / 十足 / 万一这类成语不是数字，先剔掉。
// 千万 / 万万只在后面跟劝诫词时是成语（千万别延期）；「预算千万」是数量，照常比对。
const CN_IDIOM = /百分之|百分百|十分|十足|十全十美|万一|一一|千万(?=别|不|要|记|小心|注意|当心)|万万(?=不|没|别)/g;
function numbersOf(text) {
  const t = String(text || '');
  return [...(t.match(NUM) || []).map(normNum).filter(n => n.replace(/\D/g, '').length >= 2), ...cnNumbers(t.replace(CN_IDIOM, ' '))];
}
function saidNumbers(said) { return new Set([...(String(said || '').match(NUM) || []).map(normNum), ...cnNumbers(said)]); }
const ACTION_LINE = /\n\s*(?:动作|Action)\s*[:：]/i;
function markUnverified(text) {
  if (/需核实/.test(text)) return text;
  const m = text.match(ACTION_LINE);
  return m ? text.slice(0, m.index) + '（需核实）' + text.slice(m.index) : text + '（需核实）';
}
// said：到目前为止的全场转写；issued：这场已出过的卡 [{text, sourceIds}]。
// 内部 / 遗漏卡里出现会上没说过的数字 → 整卡丢（凭空数字比少一张卡更贵）；外部卡补「需核实」；
// 和已出卡相似 → 丢，除非它以「更新：」开头且带一条已出卡没有的新来源。
const KIND_ALIASES = { '外部': 'external', '外部补充': 'external', '外部信息': 'external', '遗漏': 'gap', '遗漏视角': 'gap', '盲区': 'gap', '内部': 'internal', '内部推进': 'internal' };
function normalizeKind(k) {
  const v = typeof k === 'string' ? k.trim() : '';
  const low = v.toLowerCase();
  if (KINDS.includes(low)) return low;
  return KIND_ALIASES[v] || 'external';
}

function guard(parsed, { said = '', issued = [] } = {}) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return parsed;
  const saidSet = saidNumbers(said);
  const { similar } = require('./grounded-card-dedupe');
  const dropped = [];
  const keep = x => {
    if (!x || typeof x !== 'object') return null;
    const cardType = x.cardType || (['question','decision','risk','action','conflict'].includes(x.kind) ? x.kind : undefined);
    // 来源层只认模型明说的值（sourceLayer，或旧协议里本身就是来源层的 kind）；cardType 和 research 都不能证明出处。
    // 缺失或非法一律按 external 兜底，不丢卡（10-25/26 实测 49 张好卡因缺 kind 被丢），仍走 method-source 出处闸（peer_review 698b44fa）。
    const raw = String((x.sourceLayer != null ? x.sourceLayer : x.kind) ?? '').trim();
    const declared = KINDS.includes(raw.toLowerCase()) || KIND_ALIASES[raw] ? raw : '';
    const guessed = !declared;
    const body = typeof x.text === 'string' ? x.text : x.point;
    if (typeof body !== 'string') return null;
    x = { ...x, text: body };
    const kind = x.research === true || guessed ? 'external' : normalizeKind(declared);
    let text = x.text;
    const saidNums = [...saidSet].map(Number).filter(Number.isFinite);
    const isDerivedDiffOrSum = v => {
      const target = Number(v);
      if (!Number.isFinite(target) || target <= 0 || saidNums.length < 2) return false;
      for (let i = 0; i < saidNums.length; i++) {
        for (let j = i + 1; j < saidNums.length; j++) {
          const a = saidNums[i], b = saidNums[j];
          if (Math.abs(Math.abs(a - b) - target) <= 1 || Math.abs((a + b) - target) <= 1) return true;
        }
      }
      return false;
    };
    const isYearAbbrev = v => /^\d{2}$/.test(String(v)) && (saidSet.has('19' + v) || saidSet.has('20' + v));
    const missing = numbersOf(text).filter(n => !saidSet.has(n) && !isYearAbbrev(n) && !isDerivedDiffOrSum(n));
    if (missing.length) {
      // 只有模型明说 external、或带了网页出处（sources 或 refs）的卡才能以「需核实」放行；来源层是兜底猜的、又没出处，编的数字照丢。
      const links = [...(Array.isArray(x.sources) ? x.sources : []), ...(Array.isArray(x.refs) ? x.refs : [])];
      const web = links.some(u => /^https?:\/\//.test(String(u && u.url || u)));
      if (kind !== 'external' || (guessed && !web)) { dropped.push({ why: 'unsupported_number', numbers: missing, text: text.slice(0, 80) }); return null; }
      text = markUnverified(text);
    }
    const ids = Array.isArray(x.sourceIds) ? x.sourceIds : [];
    const twin = issued.find(y => similar({ text, sourceIds: ids }, y));
    if (twin) {
      const update = /^更新[:：]/.test(text.trim()) && ids.some(id => !(twin.sourceIds || []).includes(id));
      if (!update) { dropped.push({ why: 'repeats_issued', text: text.slice(0, 80) }); return null; }
    }
    return { ...x, ...(cardType ? {cardType} : {}), sourceLayer: kind, kind, text };
  };
  const out = { ...parsed, suggestion: keep(parsed.suggestion), insights: (Array.isArray(parsed.insights) ? parsed.insights : []).map(keep).filter(Boolean) };
  Object.defineProperty(out, 'dropped', { value: dropped, enumerable: false });
  return out;
}
module.exports = { prompt, cues, guard, numbersOf, saidNumbers, cnNumbers, markUnverified, normalizeKind, CUE, KINDS };
