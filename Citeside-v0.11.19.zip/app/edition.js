'use strict';
// Opt in only. An explicit environment value (including empty) overrides settings.
function isSelfEdition() {
  if (process.env.THT_SELF_EDITION !== undefined) return process.env.THT_SELF_EDITION === '1';
  try { return require('./config').load().THT_SELF_EDITION === '1'; }
  catch { return false; }
}
module.exports = { isSelfEdition };
