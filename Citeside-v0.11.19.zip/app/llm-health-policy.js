'use strict';
// Request shape, cancellation and a research job's failure do not establish
// that the meeting's shared model service is unavailable.
// Health follows the affected work, not merely the physical model. A user may
// deliberately run live understanding on the slow tier. Conversely the live
// recap retains purpose native-live but is a separate summary operation.
function scopeOf({ purpose = '', operation = '', role = '', route = '', kind } = {}) {
  if (operation === 'discussion-summary') return 'slow';
  if (/^(?:research-|live-research-|memory-|title(?:-|$)|summary(?:-|$)|synthesis$|condense$|meeting-calibration$|one-pager$|replay$|post-meeting-|live-subtitle-)/.test(purpose)) return 'slow';
  if (['summary', 'research', 'lookup', 'draft', 'chat'].includes(role)) return 'slow';
  if (/^(?:native-live(?:-|$)|triage$|insight-fast$|live-card-rewrite$|proactive-gate(?:-|$)|recompute$|revise$)/.test(purpose)) return 'live';
  if (['input-detect', 'understand', 'discovery-edit'].includes(role)) return 'live';
  if (['live', 'quick', 'triage'].includes(kind)) return 'live';
  if (route === 'fast') return 'live';
  if (route === 'slow' || kind !== undefined) return 'slow';
  return 'live'; // Existing callers without metadata retain their prior scope.
}
function countsFailure({ reason = '', purpose = '', status, diagnostic, cancelled = false } = {}) {
  if (cancelled) return false;
  const code = String(reason).toLowerCase();
  if (code === 'no_provider' || code.startsWith('call_budget_')) return false;
  if (/^(?:input_|output_|body_too_large|invalid_request|invalid_json|bad_json)/.test(code)) return false;
  if (/^(?:aborted|cancelled|canceled|superseded|stale_request)$/.test(code)) return false;
  if (/^(?:http_|cloud_http_)(?:400|413|422)$/.test(code)) return false;
  if (status === 413 || status === 422) return false;
  if (/^(?:research-|live-research-)/.test(String(purpose))) return false;
  if (diagnostic?.finishReason === 'length' && diagnostic?.httpStatus === 200) return false;
  return true;
}
module.exports = { countsFailure, scopeOf };
