'use strict';
// One implementation for server exports and browser presentation.
module.exports = require('../web/meeting-time');
