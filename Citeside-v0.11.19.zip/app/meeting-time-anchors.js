'use strict';
// Stored on the meeting source, so ending/reloading a recorder cannot erase anchors.
function add(hub, source, input) {
 if(!source||typeof input.anchorId!=='string'||!/^[a-f0-9-]{36}$/i.test(input.anchorId)||!Number.isFinite(input.atSec)||input.atSec<0||input.atSec>7*86400)throw Error('invalid time anchor');
 const previous=source.timeAnchors;
 const anchors=Array.isArray(previous)?previous:[];
 if(anchors.some(a=>a.id===input.anchorId))return anchors;
 if(anchors.length>=1000)throw Error('too many time anchors');
 const next=[...anchors,{id:input.anchorId,atSec:input.atSec}].sort((a,b)=>a.atSec-b.atSec);
 source.timeAnchors=next;
 try{hub.save();}catch(error){source.timeAnchors=previous;throw error;}
 return next;
}
module.exports={add};
