'use strict';
// Voice memory management on this Mac: see who is remembered, rename, forget,
// pause, clear. Only explicitly registered people exist here; nothing is
// enrolled from meetings. Forgetting is local: a provider-side voiceprint
// (Volcengine deletes softly) must be removed there separately, and we say so.
const fs = require('fs'), path = require('path');
const voiceprints = require('./voiceprints');
const { isSelfEdition } = require('./edition');
const empty = () => ({ paused: false, people: [], providerNote: '' });
const durable = require('./durable-json');
const ID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
const files = dataDir => ({ registry: path.join(dataDir, 'registered-speakers.json'), state: path.join(dataDir, 'state', 'voice-memory.json') });
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function state(dataDir) {
  const raw = readJson(files(dataDir).state, {}), s = raw && typeof raw === 'object' ? raw : {};
  return { paused: s.paused === true, forgotten: Array.isArray(s.forgotten) ? s.forgotten.filter(x => ID.test(x)) : [], consents: s.consents && typeof s.consents === 'object' && !Array.isArray(s.consents) ? s.consents : {}, consentEvents: Array.isArray(s.consentEvents) ? s.consentEvents : [], blockedGroups: Array.isArray(s.blockedGroups) ? s.blockedGroups.filter(x => ID.test(x)) : [] };
}
function saveState(dataDir, next) { fs.mkdirSync(path.dirname(files(dataDir).state), { recursive: true, mode: 0o700 }); durable.write(files(dataDir).state, next); }
function rows(dataDir) { const r = readJson(files(dataDir).registry, []); return Array.isArray(r) ? r : []; }
const rowId = row => String(row?.SpeakID || row?.SpeakId || '').trim().toLowerCase();
// What live matching may use: nothing while paused, never a forgotten person.
function registry(dataDir) {
  if (!isSelfEdition()) return new Map();
  const s = state(dataDir); if (s.paused) return new Map();
  const m = voiceprints.registry(rows(dataDir), s.consents); for (const id of s.forgotten) m.delete(id); return m;
}
function list(dataDir) {
  if (!isSelfEdition()) return empty();
  const s = state(dataDir), all = rows(dataDir), m = new Map();
  for (const row of all) { const key = rowId(row); if (ID.test(key) && typeof row.name === 'string') m.set(key, row.name); }
  for (const id of s.forgotten) m.delete(id);
  return { paused: s.paused, people: [...m].map(([id, name]) => ({ id, name, authorized: voiceprints.validConsent(s.consents[id], id) })), retainedPeople: [...new Map(all.filter(row=>s.forgotten.includes(rowId(row))).map(row=>[rowId(row),{id:rowId(row),name:row.name,authorized:false,revoked:true}])).values()], retainedAssets: all.length, groupEnabled: !!requestGroup(dataDir), providerNote: '这里只撤销本机授权与姓名关联，原登记资产保留供显式重新授权恢复；不代表服务商声纹已删除，服务商及备份需另行删除并验证。'  };
}
function id(value) { const v = String(value || '').trim().toLowerCase(); if (!ID.test(v)) throw Error('voice_memory_unknown_person'); return v; }
function rename(dataDir, personId, name) {
  if (!isSelfEdition()) return empty();
  const target = id(personId), clean = String(name || '').trim();
  if (!clean || clean.length > 80 || /[\x00-\x1f\x7f]/.test(clean)) throw Error('voice_memory_invalid_name');
  const all = rows(dataDir); let hit = false;
  for (const row of all) if (row && rowId(row) === target) { row.name = clean; hit = true; }
  if (!hit || state(dataDir).forgotten.includes(target)) throw Error('voice_memory_unknown_person');
  durable.write(files(dataDir).registry, all); return list(dataDir);
}
// No destructive migration: old registration assets remain, but are never consent.
function requestGroup(dataDir) {
  if (!isSelfEdition()) return '';
  const s = state(dataDir), all = rows(dataDir), group = voiceprints.groupOf(all);
  if (s.paused || !group || s.blockedGroups.includes(group)) return '';
  const allowed = registry(dataDir);
  return all.length && all.every(row => allowed.has(rowId(row))) ? group : '';
}
function grant(dataDir, personId, proof) {
  if (!isSelfEdition()) return empty();
  const target = id(personId);
  if (!rows(dataDir).some(row => rowId(row) === target)) throw Error('voice_memory_unknown_person');
  const receipt = { subjectId: target, scope: proof?.scope, grantedAt: proof?.grantedAt,
    evidenceRef: proof?.evidenceRef, confirmedBySubject: proof?.confirmedBySubject };
  if (proof?.subjectId !== target || !voiceprints.validConsent(receipt, target)) throw Error('voice_memory_consent_required');
  const s = state(dataDir), revokedAt = Math.max(0, Date.parse(s.consents[target]?.revokedAt) || 0, ...s.consentEvents.filter(event => event.action === 'revoke' && event.id === target).map(event => Date.parse(event.at) || 0));
  if (Date.parse(receipt.grantedAt) <= revokedAt) throw Error('voice_memory_fresh_consent_required');
  saveState(dataDir, { ...s, forgotten: s.forgotten.filter(x => x !== target), consents: { ...s.consents, [target]: receipt }, consentEvents: [...s.consentEvents, { action: 'grant', id: target, receipt, recordedAt: new Date().toISOString() }] });
  return list(dataDir);
}
function revokeState(dataDir, targets) {
  const s = state(dataDir), now = new Date().toISOString(), consents = { ...s.consents };
  for (const target of targets) consents[target] = { ...consents[target], subjectId: target, revokedAt: now };
  // A retained provider group may still contain a revoked person's biometrics.
  // Renewed local consent does not certify upstream group deletion/rebuilding.
  const groups = rows(dataDir).filter(row => targets.includes(rowId(row))).map(row => String(row.GroupID ?? row.GroupId ?? '').trim().toLowerCase()).filter(x => ID.test(x));
  saveState(dataDir, { ...s, consents, consentEvents: [...s.consentEvents, ...targets.map(target => ({ action: 'revoke', id: target, at: now, prior: s.consents[target] || null }))], forgotten: [...new Set([...s.forgotten, ...targets])], blockedGroups: [...new Set([...s.blockedGroups, ...groups])] });
}
function forget(dataDir, personId) {
  if (!isSelfEdition()) return empty();
  const target = id(personId);
  if (!rows(dataDir).some(row => rowId(row) === target) || state(dataDir).forgotten.includes(target)) throw Error('voice_memory_unknown_person');
  revokeState(dataDir, [target]); return list(dataDir);
}
function revoke(dataDir, personId) { return forget(dataDir, personId); }
function remove(dataDir, personId) {
  if (!isSelfEdition()) return empty();
  const target=id(personId), all=rows(dataDir);
  if(!all.some(row=>rowId(row)===target))throw Error('voice_memory_unknown_person');
  revokeState(dataDir,[target]);
  durable.write(files(dataDir).registry,all.filter(row=>rowId(row)!==target));
  return list(dataDir);
}
function pause(dataDir, value) {
  if (!isSelfEdition()) return empty();
  saveState(dataDir, { ...state(dataDir), paused: value === true }); return list(dataDir); }
function clear(dataDir) {
  if (!isSelfEdition()) return empty();
  const ids = rows(dataDir).map(rowId).filter(x => ID.test(x));
  revokeState(dataDir, ids);
  return list(dataDir);
}
// Physical deletion for memory-state forget(). forget/revoke/clear stay soft: they keep the registry row.
// This runs when the caller asks for it, including test mode and non-self editions. It never creates a file that was not already there.
function containsNeedle(value, ids, needles) {
  const raw = typeof value === 'string' ? value : JSON.stringify(value);
  const low = String(raw || '').toLowerCase();
  for (const id of ids) if (id && low.includes(id)) return true;
  for (const needle of needles) if (needle.length >= 3 && low.includes(needle)) return true;
  return false;
}
function scrubNode(value, ids, needles) {
  if (typeof value === 'string') return containsNeedle(value, ids, needles) ? undefined : value;
  if (value == null || typeof value !== 'object') return value;
  if (Array.isArray(value)) {
    const out = [];
    for (const item of value) {
      if (containsNeedle(item, ids, needles)) {
        if (item && typeof item === 'object') {
          const child = scrubNode(item, ids, needles);
          if (child !== undefined && !containsNeedle(child, ids, needles)) out.push(child);
        }
        continue;
      }
      out.push(item);
    }
    return out;
  }
  const out = {};
  for (const [key, child] of Object.entries(value)) {
    if (ids.has(String(key).toLowerCase()) || containsNeedle(key, ids, needles)) continue;
    const next = scrubNode(child, ids, needles);
    if (next === undefined) continue;
    if (next && typeof next === 'object' && containsNeedle(next, ids, needles)) continue;
    out[key] = next;
  }
  return out;
}
function purgePerson(dataDir, target) {
  const src = target || {};
  const id = String(src.id || '').trim().toLowerCase();
  const name = String(src.name || '').trim();
  const text = String(src.text || '').trim();
  if (!id && !name && !text) return { ok: false, removed: 0, reason: 'empty_target' };
  const nameLow = name.toLowerCase();
  const textLow = text.toLowerCase();
  const needles = [];
  const addNeedle = raw => {
    const n = String(raw || '').trim();
    if (n.length >= 3 && !needles.includes(n)) needles.push(n);
  };
  addNeedle(nameLow);
  addNeedle(textLow);
  // Evidence fields often store a code from the name, not the whole sentence.
  for (const raw of [nameLow, textLow]) {
    for (const part of raw.split(/\s+/)) if (part.length >= 6) addNeedle(part);
    for (const part of raw.split(/[^\p{L}\p{N}]+/u)) if (part.length >= 6) addNeedle(part);
  }
  const matchRow = row => {
    const rid = rowId(row);
    if (id && rid && rid === id) return true;
    const rlow = String(row && row.name || '').trim().toLowerCase();
    if (!rlow) return false;
    if (nameLow && rlow === nameLow) return true;
    if (nameLow.length >= 3 && rlow.includes(nameLow)) return true;
    if (textLow.length >= 3 && rlow.includes(textLow)) return true;
    return false;
  };
  const locs = files(dataDir);
  const ids = new Set();
  if (id) ids.add(id);
  let removed = 0;
  if (fs.existsSync(locs.registry)) {
    const all = rows(dataDir);
    const keep = [];
    for (const row of all) {
      if (matchRow(row)) {
        removed += 1;
        const rid = rowId(row);
        if (rid) ids.add(rid);
      } else keep.push(row);
    }
    if (keep.length !== all.length) durable.write(locs.registry, keep);
  }
  if (fs.existsSync(locs.state)) {
    const before = readJson(locs.state, {});
    const after = scrubNode(before, ids, needles);
    if (JSON.stringify(before) !== JSON.stringify(after)) {
      durable.write(locs.state, after && typeof after === 'object' ? after : {});
      removed += 1;
    }
  }
  return { ok: true, removed };
}
// Local page only. onChange lets live meetings stop matching a forgotten person at once.
async function route(req, res, u, { dataDir, isLocal, onChange = () => {} }) {
  const p = u.pathname.replace(/^\/asr-relay/, '');
  if (p !== '/voice-memory' && !p.startsWith('/voice-memory/')) return false;
  const send = (code, j) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(j)); return true; };
  if (!isSelfEdition()) return send(200, empty());
  if (!isLocal) return send(403, { error: 'voice_memory_local_only' });
  if (req.method === 'GET' && p === '/voice-memory') return send(200, list(dataDir));
  if (req.method !== 'POST') return send(405, { error: 'method_not_allowed' });
  {
    // A website must not turn a cross-origin, simple POST into biometric consent.
    if (!/^application\/json(?:;|$)/i.test(req.headers?.['content-type'] || '')) return send(415, { error: 'json_required' });
    if (req.headers?.origin) {
      try { if (new URL(req.headers.origin).host !== req.headers.host) return send(403, { error: 'voice_memory_local_only' }); }
      catch { return send(403, { error: 'voice_memory_local_only' }); }
    }
  }
  let j = {};
  try { const chunks = []; let n = 0; for await (const c of req) { n += c.length; if (n > 4000) throw Error('payload_too_large'); chunks.push(c); } j = JSON.parse(Buffer.concat(chunks).toString() || '{}'); }
  catch (e) { return send(400, { error: e.message }); }
  try {
    const action = { '/voice-memory/consent': () => grant(dataDir, j.id, j.proof), '/voice-memory/revoke': () => revoke(dataDir, j.id), '/voice-memory/delete': () => j.confirm === true ? remove(dataDir,j.id) : (()=>{throw Error('voice_memory_confirm_required');})(), '/voice-memory/rename': () => rename(dataDir, j.id, j.name), '/voice-memory/forget': () => forget(dataDir, j.id), '/voice-memory/pause': () => pause(dataDir, j.paused), '/voice-memory/clear': () => j.confirm === true ? clear(dataDir) : (() => { throw Error('voice_memory_confirm_required'); })() }[p];
    if (!action) return send(404, { error: 'not_found' });
    const result = action(); onChange(); return send(200, { ok: true, ...result });
  } catch (e) { return send(e.message === 'voice_memory_unknown_person' ? 404 : 400, { error: e.message }); }
}
module.exports = { registry, requestGroup, grant, revoke, remove, list, rename, forget, pause, clear, purgePerson, route };
