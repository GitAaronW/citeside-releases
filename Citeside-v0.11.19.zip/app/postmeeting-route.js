'use strict';
const {validId} = require('./post-meeting');
const memoryState = require('./memory-state');
const blocks = ['summary','actions','drafts','decisions'];
const terminal = new Set(['done','skipped','failed']);
const MEMORY_DECISION = {memory_confirm:'confirm', memory_reject:'reject', memory_forget:'forget', memory_edit:'edit'};
const fail = (message, status = 400) => {throw Object.assign(Error(message), {status});};
const actionView = a => ({...a, text:a.text ?? a.do ?? ''});
const draftId = d => String(d.id || (d.actionId ? 'draft-' + d.actionId : ''));
function draftView(d, actions) {
  const latest = d.versions?.at(-1) || {};
  const action = actions.all.find(a => a.id === d.actionId);
  return {...d, id:draftId(d), for:d.for || d.actionId,
    title:d.title || latest.task || action?.text || action?.do || d.label || '',
    line:d.line || d.reason || d.label || '', body:d.markdown ?? d.body ?? latest.markdown ?? ''};
}
function presentHeard(state) {
  const heard = state && state.heardMemory;
  if (!heard || typeof heard !== 'object') return {items:[], activeCount:0, pendingCount:0, nonBlocking:true};
  const items = Array.isArray(heard.items) ? heard.items : [];
  return {
    items,
    activeCount: Number.isInteger(heard.activeCount) ? heard.activeCount : items.filter(it => it && it.review_status === 'active').length,
    pendingCount: Number.isInteger(heard.pendingCount) ? heard.pendingCount : items.filter(it => it && it.review_status === 'pending').length,
    nonBlocking: true,
    ...(heard.skipped ? {skipped:true} : {}),
  };
}
function view(state) {
  const progress = state.progress;
  const actions = {...state.actions};
  for (const key of ['mine','possibly_you','all']) actions[key] = actions[key].map(actionView);
  return {...state,
    summary:{...(state.summary || {}), ...progress.summary, text:state.summary?.markdown ?? state.summary?.text ?? ''},
    actions:{...actions,...progress.actions},
    drafts:{...progress.drafts,items:state.drafts.map(d => draftView(d, actions))},
    decisions:{...progress.decisions,items:state.decisions.map(d => ({...d,context:d.context ?? d.evidence ?? ''}))},
    heardMemory: presentHeard(state),
    progress:{...progress,done:blocks.filter(k => terminal.has(progress[k].status)).length,total:blocks.length}};
}
function heardItemsOf(state) {
  const heard = state && state.heardMemory;
  return heard && Array.isArray(heard.items) ? heard.items : [];
}
function knownMemoryItem(service, state, itemId) {
  if (heardItemsOf(state).some(it => it && String(it.id) === itemId)) return true;
  const dataDir = service && service.dataDir;
  if (!dataDir) return false;
  try {
    const db = require('./memory').open(dataDir);
    return !!(db && db.prepare('SELECT 1 AS n FROM cards WHERE id=?').get(itemId));
  } catch (e) { return false; }
}
function mergeHeardItem(prev, card) {
  const src = card || {}, base = prev || {};
  return {
    id: String(src.id || base.id || ''),
    text: src.text != null ? String(src.text) : String(base.text || ''),
    topic: src.topic != null ? String(src.topic) : String(base.topic || ''),
    conflict_key: src.conflict_key != null ? String(src.conflict_key) : String(base.conflict_key || ''),
    memory_class: src.memory_class || base.memory_class || 'slow_changing',
    source_type: src.source_type || base.source_type || 'meeting',
    valid_from: src.effective_at || src.recorded_at || base.valid_from || null,
    valid_until: src.valid_until !== undefined ? (src.valid_until || null) : (base.valid_until || null),
    confidence: typeof src.confidence === 'number' ? src.confidence : (typeof base.confidence === 'number' ? base.confidence : null),
    review_status: src.review_status || base.review_status || 'pending',
    superseded_old_id: src.supersedes_id || base.superseded_old_id || null,
  };
}
function applyMemory(service, id, state, body) {
  const decision = MEMORY_DECISION[body.op];
  const itemId = typeof body.item === 'string' ? body.item.trim() : '';
  if (!itemId || !knownMemoryItem(service, state, itemId)) fail('没有该记忆', 404);
  if (!service || typeof service.replaceHeardMemory !== 'function' || !service.dataDir) fail('没有记忆库', 400);
  const reviewed = memoryState.reviewFact(service.dataDir, itemId, decision, {
    text: body.text,
    valid_until: body.valid_until,
    reason: typeof body.reason === 'string' && body.reason.trim() ? body.reason : decision,
  });
  if (!reviewed || reviewed.ok === false) fail('记忆没有更新', 400);
  const items = heardItemsOf(state);
  const nextItems = decision === 'forget'
    ? items.filter(it => it && String(it.id) !== itemId)
    : items.map(it => it && String(it.id) === itemId ? mergeHeardItem(it, reviewed.item) : it);
  return service.replaceHeardMemory(id, {
    items: nextItems,
    skipped: state.heardMemory && state.heardMemory.skipped,
    nonBlocking: true,
  }, decision === 'forget' ? {purgeItemId: itemId} : {});
}
function patchFor(state, body) {
  if (body.op === 'edit') {
    if (typeof body.text !== 'string' || !body.text.trim()) fail('编辑内容不能为空');
    const target = body.target;
    if (target === 'summary') return {summary:{...(state.summary || {}),markdown:body.text}};
    if (typeof target !== 'string') fail('无效编辑目标');
    const split = target.indexOf(':'), kind = target.slice(0,split), id = target.slice(split+1);
    if (!id) fail('无效编辑目标');
    if (kind === 'action') {
      if (!state.actions.all.some(a => a.id === id)) fail('没有该待办',404);
      return {actions:Object.fromEntries(['mine','possibly_you','all'].map(k => [k,state.actions[k].map(a => a.id === id ? {...a,text:body.text,do:body.text}:a)]))};
    }
    if (kind === 'draft') {
      if (!state.drafts.some(d => draftId(d) === id)) fail('没有该草案',404);
      return {drafts:state.drafts.map(d => draftId(d) === id ? {...d,markdown:body.text,body:body.text,
        versions:[...(d.versions || []),{...(d.versions?.at(-1) || {}),markdown:body.text,source:'user',createdAt:new Date().toISOString()}]}:d)};
    }
    fail('无效编辑目标');
  }
  if (body.op === 'confirm') {
    if (!state.decisions.some(d => d.id === body.item)) fail('没有该拍板事项',404);
    return {decisions:state.decisions.map(d => d.id === body.item ? {...d,status:'agreed',pending:false,confirmation:{decision:'agree',source:'manual'}}:d)};
  }
  if (!['claim','dismiss','undismiss'].includes(body.op)) fail('未知操作');
  const {item:id,op} = body, actions = state.actions;
  const item = actions.all.find(a => a.id === id);
  if (!item) fail('没有该待办',404);
  const possible = actions.possibly_you.some(a => a.id === id);
  const review = item.attributionReview?.decision;
  // Only unclear ownership is eligible. Explicit assignments to someone else cannot be claimed.
  if (!(possible || (op === 'claim' && review === 'claim') || (['dismiss','undismiss'].includes(op) && review === 'dismiss')))
    fail('只能操作可能是你的待办');
  const next = {...item, group:op === 'claim' ? 'mine':op === 'dismiss' ? 'all':'possible',
    attributionReview:{...(item.attributionReview || {}),decision:op === 'undismiss' ? 'pending':op,source:'manual'}};
  if (op === 'claim') {
    next.owner = '我';
    next.attribution = {...(item.attribution || {}),kind:'claimed',source:'manual'};
  }
  const mine = actions.mine.filter(a => a.id !== id), possibly = actions.possibly_you.filter(a => a.id !== id);
  if (op === 'claim') mine.push(next);
  if (op === 'undismiss') possibly.push(next);
  return {actions:{...actions,mine,possibly_you:possibly,all:actions.all.map(a => a.id === id ? next:a)}};
}
async function handle(req, res, url, {authed,service,sessionOf}) {
  const id = url.searchParams.get('id') || '';
  const reply = (code, body) => {res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({meetingId:id,...body}));};
  if (!authed) return reply(401,{error:'unauthorized'});
  try {
    if (!validId(id)) fail('无效会议编号');
    if (!['GET','POST'].includes(req.method)) return reply(405,{error:'method not allowed'});
    if (req.method === 'GET') {
      const state = service.get(id);
      return state ? reply(200,view(state)):reply(404,{error:'没有会后产物'});
    }
    const chunks = []; let size = 0;
    for await (const chunk of req) {
      size += Buffer.byteLength(chunk);
      if (size > 256000) return reply(413,{error:'编辑内容过大'});
      chunks.push(Buffer.from(chunk));
    }
    const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!body || typeof body !== 'object' || Array.isArray(body)) fail('无效请求');
    if (body.meetingId !== undefined && body.meetingId !== id) fail('会议编号不匹配');
    const state = service.get(id);
    // Meetings that ended before post-meeting existed (or whose start was lost) have no state yet:
    // an explicit start — or a retry on such a meeting — prepares it from the saved meeting. GET still never starts work.
    const allSkipped = state && Object.values(state.progress).every(p => p.status === 'skipped');
    if (body.op === 'start' || (body.op === 'retry' && !state)) {
      if (state && !(body.op === 'start' && body.force === true && allSkipped)) return reply(200,view(state));
      let sess;
      try { sess = sessionOf && sessionOf(id); }
      catch (e) { fail(e.message, e.status || (Number.isInteger(e.code) ? e.code:500)); }
      if (!sess || String(sess.id) !== id) fail('没有可整理的会议资料',404);
      return reply(200,view(service.start(sess,{force:body.force === true})));
    }
    if (!state) return reply(404,{error:'没有会后产物'});
    if (MEMORY_DECISION[body.op]) return reply(200, view(applyMemory(service, id, state, body)));
    // A repeated confirmation is a read, including retries with the original version.
    if (body.op === 'confirm' && state.decisions.some(d => d.id === body.item && d.status === 'agreed')) return reply(200,view(state));
    let operationId, operationKey;
    if (body.op === 'edit' && body.operationId !== undefined) {
      if (typeof body.operationId !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(body.operationId)) fail('无效操作编号');
      operationId = body.operationId;
      operationKey = require('crypto').createHash('sha256').update(JSON.stringify([body.op,body.target,body.text,body.baseVersion])).digest('hex');
      const replay = service.replayEdit(id,{operationId,operationKey});
      if (replay) return reply(200,view(replay));
    }
    const command = body.op === 'retry' ? {retry:body.block,sessionOf}: {patch:patchFor(state,body)};
    // Local field history is not an observed server version; never rebase offline edits implicitly.
    if (body.op === 'edit' && !Number.isInteger(body.baseVersion)) fail('请读取最新版后合并本地编辑',409);
    const baseVersion = body.baseVersion === undefined ? state.version:body.baseVersion;
    if (baseVersion !== state.version) fail('版本已变化，请读取最新版后合并',409);
    if (body.op === 'retry' && !blocks.includes(body.block)) fail('无效重试块');
    return reply(200,view(service.edit(id,{baseVersion,...command,operationId,operationKey})));
  } catch (e) {
    if (e.status === 409) {
      const latest = view(service.get(id));
      return reply(409,{...latest,error:String(e.message),state:latest});
    }
    return reply(e.status || (e instanceof SyntaxError ? 400:500),{error:String(e.message)});
  }
}
module.exports = {handle,view};
