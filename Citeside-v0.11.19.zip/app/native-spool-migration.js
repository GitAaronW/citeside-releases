'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
// Only a verified installation binary is inspected. Identifiers are read from the
// real installed artifact, never reconstructed/encoded old branding constants.
function identify({binary,verify,applicationSupport}) {
 if(typeof verify!=='function'||verify(binary)!==true)throw Error('Verified native installation required');
 const r=spawnSync('/usr/bin/strings',['-a',binary],{encoding:'utf8',maxBuffer:32*1024*1024});
 if(r.status!==0)throw Error('Cannot inspect verified native installation');
 const lines=r.stdout.split('\n').map(x=>x.trim());
 const services=[...new Set(lines.filter(x=>/^[A-Za-z][A-Za-z0-9]*PendingSpool$/.test(x)))];
 const roots=[...new Set(lines.filter(x=>/^[A-Za-z][A-Za-z0-9]*\/pending-spool$/.test(x)))];
 if(services.length!==1||roots.length!==1)throw Error('Ambiguous native spool identity');
 return {sourceDir:path.join(applicationSupport,roots[0]),service:services[0],verified:true};
}
function read(service,{bin,env}) {
 const r=spawnSync(bin,['find-generic-password','-s',service,'-a','audio-spool','-w'],{env,timeout:5000});
 if(r.status===44)return null;
 if(r.status!==0)throw Error('Native spool Keychain unavailable');
 const raw=Buffer.from(r.stdout||[]),key=raw.at(-1)===10?raw.subarray(0,-1):raw;
 if(key.length!==32)throw Error('Native spool Keychain key has invalid length');
 return key;
}
function manifest(dir) {
 const rows=[];
 function walk(p,relative=''){for(const name of fs.readdirSync(p).sort()){const r=path.join(relative,name),f=path.join(p,name),st=fs.lstatSync(f);if(st.isSymbolicLink())throw Error('Native spool symlink refused');if(st.isDirectory())walk(f,r);else if(st.isFile())rows.push([r,crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')]);else throw Error('Native spool special file refused');}}
 walk(dir);return rows;
}
function copy({sourceDir,service,verified,destination,bin='/usr/bin/security',env=process.env,keychain,trustedExecutable}={}) {
 if(verified!==true||typeof service!=='string'||!/^[A-Za-z][A-Za-z0-9]*PendingSpool$/.test(service))throw Error('Verified native spool identity required');
 if(!fs.existsSync(sourceDir))return {ok:true,files:0};
 const sourceStat=fs.lstatSync(sourceDir);if(sourceStat.isSymbolicLink()||!sourceStat.isDirectory())throw Error('Native spool requires a regular source directory');
 if(fs.existsSync(destination))throw Error('Native spool destination already exists');
 const before=manifest(sourceDir),nonempty=before.some(([name])=>name.endsWith('.bin'));
 if(!nonempty&&before.length===0)return {ok:true,files:0};
 const api=keychain||{read:s=>read(s,{bin,env}),write:(s,key)=>{if(typeof trustedExecutable!=='string'||!path.isAbsolute(trustedExecutable)||/["\\\r\n]/.test(trustedExecutable))throw Error('Verified incoming native executable required for Keychain access');const r=spawnSync(bin,['-i'],{env,input:`add-generic-password -s "${s}" -a "audio-spool" -X "${key.toString('hex')}" -T "${trustedExecutable}"\n`,encoding:'utf8',timeout:5000});if(r.status!==0)throw Error('Native spool Keychain write failed');}};
 const key=api.read(service);
 if(!Buffer.isBuffer(key)||key.length!==32)throw Error('Existing native spool key unavailable');
 const next='CitesidePendingSpool';let back=api.read(next);
 if(back===null){api.write(next,key);back=api.read(next);}
 if(!Buffer.isBuffer(back)||!back.equals(key))throw Error('Native spool Keychain readback mismatch');
 try{
  fs.cpSync(sourceDir,destination,{recursive:true,force:false,errorOnExist:true});
  if(JSON.stringify(before)!==JSON.stringify(manifest(destination))||JSON.stringify(before)!==JSON.stringify(manifest(sourceDir)))throw Error('Native spool data readback mismatch');
  return {ok:true,files:before.length};
 }catch(e){fs.rmSync(destination,{recursive:true,force:true});throw e;}
}
module.exports={identify,copy};
