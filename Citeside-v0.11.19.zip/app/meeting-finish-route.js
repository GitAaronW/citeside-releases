'use strict';
const fs = require('node:fs');
const path = require('node:path');
// Explicit recovery bypasses the orphan age timer, never a connected recorder.
module.exports = async function finish(req, res, url, deps) {
  if (url.pathname.replace(/^\/asr-relay/, '') !== '/meeting-finish') return false;
  const send = (code, body) => { res.writeHead(code, {'Content-Type':'application/json', 'Cache-Control':'no-store'}); res.end(JSON.stringify(body)); return true; };
  if (!deps.owner) return send(403, {ok:false, error:'需要本机或主口令 / Owner access required'});
  if (req.method !== 'POST') return send(405, {ok:false, error:'POST required'});
  let body = '', value;
  try {
    for await (const chunk of req) { body += chunk; if (Buffer.byteLength(body) > 2000) return send(413, {ok:false, error:'Request too large'}); }
    value = JSON.parse(body);
  } catch { return send(400, {ok:false, error:'Invalid JSON'}); }
  const id = value && value.id;
  if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(id) || deps.isTrial(id)) return send(400, {ok:false, error:'Invalid meeting id'});
  // Even a disconnected browser may hold notes that its normal stop must flush.
  if (deps.sessions.has(id)) return send(409, {ok:false, error:'本场仍在服务中，请使用结束会议保存最后内容 / Use End meeting to save the last edits'});
  const file = path.join(deps.journalDir, id + '.json');
  try {
    const saved = deps.read(file);
    if (!saved || saved.id !== id) return send(404, {ok:false, error:'未找到本场保存内容 / Meeting not found'});
    if (saved.complete) return send(200, {ok:true, status:'already-ended', id});
    const text = Array.isArray(saved.transcript) && saved.transcript.some(row => row && row.text);
    const audio = saved.audioPath && fs.existsSync(saved.audioPath) && fs.statSync(saved.audioPath).size > 3200;
    // The shared recovery routine skips empty recordings. Do not close a notes-only journal.
    if (!text && !audio) return send(409, {ok:false, error:'未找到可整理的转写或录音，原内容已保留 / No transcript or audio; saved content retained'});
    const status = deps.recover(saved, file);
    if (status === 'conflict') return send(409, {ok:false, error:'本场已有另一份保存记录，两份内容均已保留，暂不能自动整理 / Existing saved record conflicts; both copies retained'});
    return send(200, {ok:true, status, id});
  } catch { return send(500, {ok:false, error:'收尾未确认，请重试；已保存内容保留 / Finish unconfirmed; saved content retained'}); }
};
