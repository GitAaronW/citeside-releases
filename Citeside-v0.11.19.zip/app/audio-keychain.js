'use strict';

// Keychain-only master key for the pending-audio cache.
// 32 random bytes, read back before use, and recoverable after restart.
// There is no plaintext settings copy and no file fallback. This module does not
// sweep or delete audio: a fingerprint mismatch or an unverified existing record
// refuses the key instead of adopting one that would make those records unknowable.
//
// open() stays synchronous for existing callers. openCachedAsync() / peekVerified()
// keep the same Keychain contract without busy-waiting the Node event loop.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const ACCOUNT = 'audio-master';
const FINGERPRINT = 'pac1-key-id';
const LOCK_NAME = 'pac1-key.lock';
const RECORD_RE = /^pac1-[0-9a-f]{64}\.bin$/;
const defaultService = 'CitesidePendingAudio';
const DEFAULT_BIN = '/usr/bin/security';
const KEYCHAIN_TIMEOUT_MS = 5000;

const verifiedCache = new Map();
const inflight = new Map();

// Synchronous pause. Atomics.wait blocks this thread without pegging a core, so a
// peer process can finish the Keychain create the waiter is polling for.
const sleepSlot = new Int32Array(new SharedArrayBuffer(4));
function sleepMs(ms) {
  const end = Date.now() + ms;
  try {
    do {
      Atomics.wait(sleepSlot, 0, 0, Math.max(1, end - Date.now()));
    } while (Date.now() < end);
  } catch (e) {
    while (Date.now() < end) {}
  }
}

function pidAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 1) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return !!(e && e.code === 'EPERM');
  }
}

function status(code, message) {
  return { ok: false, recoverable: false, code, message };
}

function asOptions(options) {
  if (!options || typeof options !== 'object' || Array.isArray(options)) return null;
  return options;
}

// Canonical cache identity: resolved dir, explicit service or defaultService, resolved bin.
function canonicalCacheKey(options) {
  const opts = asOptions(options) || {};
  const env = opts.env || process.env;
  const dir = typeof opts.dir === 'string' && opts.dir ? path.resolve(opts.dir) : '';
  const service = opts.service || defaultService;
  const bin = opts.bin || env.THT_AUDIO_KEYCHAIN_BIN || (env.THT_TEST === '1' ? '' : DEFAULT_BIN);
  if (!bin) return '';
  return JSON.stringify([dir, service, bin]);
}

function normalizeOpenOptions(options) {
  const opts = asOptions(options);
  if (!opts) return { error: status('invalid_dir', '需要 { dir }') };
  const env = opts.env || process.env;
  const bin = opts.bin || env.THT_AUDIO_KEYCHAIN_BIN || (env.THT_TEST === '1' ? '' : DEFAULT_BIN);
  if (!bin) return { error: status('keychain_unavailable', '钥匙串不可用，没有把音频密钥写进明文文件') };
  return { env, bin, dir: opts.dir, options: opts };
}

function fingerprintHex(key) {
  return crypto.createHash('sha256').update(key).digest('hex');
}

function successResult(key, created) {
  const hex = key.toString('hex');
  return {
    ok: true,
    key,
    hex,
    source: created ? 'created' : 'keychain',
    created: !!created,
    recoverable: true,
  };
}

function rememberVerified(options, result) {
  const id = canonicalCacheKey(options);
  if (!id) return result;
  if (!result || result.ok !== true || !Buffer.isBuffer(result.key)) {
    verifiedCache.delete(id);
    return result;
  }
  verifiedCache.set(id, {
    key: Buffer.from(result.key),
    hex: result.hex || result.key.toString('hex'),
    source: result.source || (result.created ? 'created' : 'keychain'),
  });
  return result;
}

function peekVerified(opts = {}) {
  const id = canonicalCacheKey(opts);
  if (!id) return { ok: false, miss: true };
  const entry = verifiedCache.get(id);
  if (!entry || !Buffer.isBuffer(entry.key)) return { ok: false, miss: true };
  const options = asOptions(opts) || {};
  const dir = typeof options.dir === 'string' && options.dir ? path.resolve(options.dir) : '';
  if (!dir) return { ok: false, miss: true };
  const fp = readFingerprint(dir);
  const key = Buffer.from(entry.key);
  if (typeof fp !== 'string' || fp !== fingerprintHex(key)) return { ok: false, miss: true };
  if (entry.hex && entry.hex !== key.toString('hex')) return { ok: false, miss: true };
  return { ok: true, key, hex: entry.hex || key.toString('hex'), source: entry.source, cached: true };
}

function presentAsync(result) {
  if (!result || result.ok !== true || !Buffer.isBuffer(result.key)) return result;
  return {
    ok: true,
    key: Buffer.from(result.key),
    hex: result.hex || result.key.toString('hex'),
    source: result.source,
    cached: false,
    created: !!result.created,
    recoverable: true,
  };
}

function openCachedAsync(opts = {}) {
  const options = asOptions(opts) || {};
  if (options.refresh !== true) {
    const peeked = peekVerified(options);
    if (peeked.ok) return Promise.resolve(peeked);
  }
  const key = canonicalCacheKey(options);
  if (!key) return performOpenCached(options, '').then(presentAsync);
  const existing = inflight.get(key);
  if (existing) return existing.then(presentAsync);
  const job = performOpenCached(options, key).finally(() => {
    if (inflight.get(key) === job) inflight.delete(key);
  });
  inflight.set(key, job);
  return job.then(presentAsync);
}

async function performOpenCached(options, key) {
  try {
    const norm = normalizeOpenOptions(options);
    if (norm.error) {
      if (key) verifiedCache.delete(key);
      return norm.error;
    }
    const prepared = prepareDir(norm.dir);
    if (prepared.error) {
      if (key) verifiedCache.delete(key);
      return status(prepared.error, prepared.message);
    }
    const locked = await withKeyLockAsync(prepared.dir, () => driveAsync(prepared.dir, norm.bin, norm.env));
    if (locked === false) {
      if (key) verifiedCache.delete(key);
      return status('key_lock_busy', '音频密钥正在创建，这次没有另写一把钥匙');
    }
    if (!locked || locked.ok !== true) {
      if (key) verifiedCache.delete(key);
      return locked;
    }
    if (key) {
      verifiedCache.set(key, {
        key: Buffer.from(locked.key),
        hex: locked.hex,
        source: locked.source,
      });
    }
    return locked;
  } catch (e) {
    if (key) verifiedCache.delete(key);
    throw e;
  }
}

function clearCache(opts) {
  const options = asOptions(opts);
  if (!options || !options.dir) {
    verifiedCache.clear();
    return;
  }
  const dir = path.resolve(options.dir);
  for (const id of [...verifiedCache.keys()]) {
    try {
      const parsed = JSON.parse(id);
      if (Array.isArray(parsed) && parsed[0] === dir) verifiedCache.delete(id);
    } catch (e) {}
  }
}

function open(options = {}) {
  const norm = normalizeOpenOptions(options);
  if (norm.error) {
    if (asOptions(options)) rememberVerified(options, norm.error);
    return norm.error;
  }
  const prepared = prepareDir(norm.dir);
  if (prepared.error) return rememberVerified(options, status(prepared.error, prepared.message));
  const locked = withKeyLock(prepared.dir, () => driveSync(prepared.dir, norm.bin, norm.env));
  if (locked === false) return rememberVerified(options, status('key_lock_busy', '音频密钥正在创建，这次没有另写一把钥匙'));
  return rememberVerified(options, locked);
}

// Shared open sequence. Yields only Keychain I/O so sync and async drivers stay aligned.
function* openFlow(dir, bin, env) {
  let service;
  try { service = serviceName(dir); } catch (e) {
    return status('invalid_dir', '无法确定缓存目录，没有把音频密钥写进明文文件');
  }
  const fp = readFingerprint(dir);
  const current = yield { op: 'get', bin, service, env };
  if (fp === false) return status('key_mismatch', '密钥指纹无法核对，拒绝覆盖钥匙串，也不会清理音频');
  if (typeof fp === 'string') {
    if (!current.ok) return status('key_mismatch', '密钥指纹与钥匙串不一致，拒绝覆盖，也不会清理音频');
    if (fingerprintHex(current.key) !== fp) return status('key_mismatch', '密钥指纹与钥匙串不一致，拒绝覆盖，也不会清理音频');
    return successResult(current.key, false);
  }
  if (hasRecords(dir)) return status('key_unverified', '缓存目录已有记录但没有可核对的密钥指纹，拒绝采用钥匙串密钥，也不会清理这些文件');
  if (current.ok) {
    if (!publishFingerprint(dir, current.key)) return status('key_mismatch', '密钥指纹与钥匙串不一致，拒绝覆盖，也不会清理音频');
    const back = yield { op: 'get', bin, service, env };
    if (!back.ok || !back.key.equals(current.key)) return status('key_readback_mismatch', '写入后读回不一致，没有把音频密钥写进明文文件');
    return successResult(current.key, false);
  }
  if (!current.missing) return status('keychain_unavailable', '钥匙串不可用，没有把音频密钥写进明文文件');
  const key = crypto.randomBytes(32);
  const hex = key.toString('hex');
  const added = yield { op: 'add', bin, service, env, hex };
  if (!added.ok) {
    const again = yield { op: 'get', bin, service, env };
    if (again.ok && !hasRecords(dir) && publishFingerprint(dir, again.key)) return successResult(again.key, false);
    return status('keychain_unavailable', '钥匙串不可用，没有把音频密钥写进明文文件');
  }
  const back = yield { op: 'get', bin, service, env };
  if (!back.ok || back.hex !== hex) return status('key_readback_mismatch', '写入后读回不一致，没有把音频密钥写进明文文件');
  if (!publishFingerprint(dir, key)) return status('key_mismatch', '密钥指纹与已发布的指纹不一致，拒绝覆盖，也不会清理音频');
  return successResult(key, true);
}

function applyKeychainOp(req) {
  if (req.op === 'add') return kcAdd(req.bin, req.service, req.hex, req.env);
  return kcGet(req.bin, req.service, req.env);
}

async function applyKeychainOpAsync(req) {
  if (req.op === 'add') return kcAddAsync(req.bin, req.service, req.hex, req.env);
  return kcGetAsync(req.bin, req.service, req.env);
}

function driveSync(dir, bin, env) {
  const gen = openFlow(dir, bin, env);
  let step = gen.next();
  while (!step.done) step = gen.next(applyKeychainOp(step.value));
  return step.value;
}

async function driveAsync(dir, bin, env) {
  const gen = openFlow(dir, bin, env);
  let step = gen.next();
  while (!step.done) step = gen.next(await applyKeychainOpAsync(step.value));
  return step.value;
}

function serviceName(dir) {
  const real = fs.realpathSync(dir);
  return 'CitesidePendingAudio.' + crypto.createHash('sha256').update(real).digest('hex').slice(0, 32);
}

function classifyGet(statusCode, stdout, error) {
  if (error) return { ok: false, missing: false };
  if (statusCode === 44) return { ok: false, missing: true };
  if (statusCode !== 0) return { ok: false, missing: false };
  const hex = String(stdout || '').replace(/\n$/, '');
  if (!/^[0-9a-f]{64}$/.test(hex)) return { ok: false, missing: false };
  return { ok: true, missing: false, hex, key: Buffer.from(hex, 'hex') };
}

function classifyAdd(statusCode, error) {
  if (error || statusCode !== 0) return { ok: false };
  return { ok: true };
}

function kcGet(bin, service, env) {
  const r = spawnSync(bin, ['find-generic-password', '-s', service, '-a', ACCOUNT, '-w'], {
    encoding: 'utf8', timeout: KEYCHAIN_TIMEOUT_MS, env,
  });
  return classifyGet(r.status, r.stdout, r.error);
}

function kcAdd(bin, service, hex, env) {
  const input = 'add-generic-password -s "' + service + '" -a "' + ACCOUNT + '" -w "' + hex + '"\n';
  const r = spawnSync(bin, ['-i'], { input, encoding: 'utf8', timeout: KEYCHAIN_TIMEOUT_MS, env });
  return classifyAdd(r.status, r.error);
}

function spawnSecurity(bin, args, env, input) {
  return new Promise((resolve) => {
    let stdout = '';
    let stderr = '';
    let settled = false;
    let child;
    let timer;
    function finish(result) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(result);
    }
    timer = setTimeout(() => {
      try { if (child) child.kill('SIGKILL'); } catch (e) {}
      finish({ error: Object.assign(new Error('keychain timeout'), { code: 'ETIMEDOUT' }), status: null, stdout, stderr });
    }, KEYCHAIN_TIMEOUT_MS);
    try {
      child = spawn(bin, args, { env });
    } catch (error) {
      finish({ error, status: null, stdout: '', stderr: '' });
      return;
    }
    if (child.stdout) {
      child.stdout.setEncoding('utf8');
      child.stdout.on('data', (chunk) => { stdout += chunk; });
    }
    if (child.stderr) {
      child.stderr.setEncoding('utf8');
      child.stderr.on('data', (chunk) => { stderr += chunk; });
    }
    child.on('error', (error) => finish({ error, status: null, stdout, stderr }));
    child.on('close', (statusCode) => finish({ error: null, status: statusCode, stdout, stderr }));
    if (child.stdin) {
      child.stdin.on('error', () => {});
      try {
        if (input != null) child.stdin.end(input);
        else child.stdin.end();
      } catch (e) {}
    }
  });
}

function kcGetAsync(bin, service, env) {
  return spawnSecurity(bin, ['find-generic-password', '-s', service, '-a', ACCOUNT, '-w'], env, null)
    .then((r) => classifyGet(r.status, r.stdout, r.error));
}

function kcAddAsync(bin, service, hex, env) {
  const input = 'add-generic-password -s "' + service + '" -a "' + ACCOUNT + '" -w "' + hex + '"\n';
  return spawnSecurity(bin, ['-i'], env, input).then((r) => classifyAdd(r.status, r.error));
}

function hasRecords(dir) {
  return fs.readdirSync(dir).some((name) => RECORD_RE.test(name));
}

function readFingerprint(dir) {
  const dest = path.join(dir, FINGERPRINT);
  let st;
  try { st = fs.lstatSync(dest); } catch (e) {
    if (e.code === 'ENOENT') return null;
    return false;
  }
  if (st.isSymbolicLink() || !st.isFile() || st.size !== 64) return false;
  let fd;
  try { fd = fs.openSync(dest, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW); } catch (e) { return false; }
  try {
    const buf = Buffer.alloc(64);
    const n = fs.readSync(fd, buf, 0, 64, 0);
    const text = buf.subarray(0, n).toString('utf8');
    if (!/^[0-9a-f]{64}$/.test(text)) return false;
    return text;
  } finally { fs.closeSync(fd); }
}

function publishFingerprint(dir, key) {
  const hex = fingerprintHex(key);
  const dest = path.join(dir, FINGERPRINT);
  const existing = readFingerprint(dir);
  if (existing === hex) return true;
  if (existing) return false;
  const tmp = path.join(dir, 'pac1-key-id.writing');
  const flags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_NOFOLLOW;
  let fd;
  try { fd = fs.openSync(tmp, flags, 0o600); } catch (e) {
    if (e.code !== 'EEXIST') return false;
    try { fs.unlinkSync(tmp); } catch (err) { return false; }
    try { fd = fs.openSync(tmp, flags, 0o600); } catch (err) { return false; }
  }
  try {
    fs.writeSync(fd, hex);
    fs.fchmodSync(fd, 0o600);
    fs.fsyncSync(fd);
  } catch (e) {
    try { fs.closeSync(fd); } catch (err) {}
    try { fs.unlinkSync(tmp); } catch (err) {}
    return false;
  }
  fs.closeSync(fd);
  try { fs.linkSync(tmp, dest); } catch (e) {
    try { fs.unlinkSync(tmp); } catch (err) {}
    if (e.code !== 'EEXIST') return false;
  }
  try { fs.unlinkSync(tmp); } catch (e) {}
  return readFingerprint(dir) === hex;
}

function readLockText(lockPath) {
  let fd;
  try { fd = fs.openSync(lockPath, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW); } catch (e) {
    if (e.code === 'ENOENT') return null;
    return undefined;
  }
  try {
    const buf = Buffer.alloc(64);
    const n = fs.readSync(fd, buf, 0, buf.length, 0);
    return buf.subarray(0, n).toString('utf8').trim();
  } finally { fs.closeSync(fd); }
}

function ownerLive(lockPath) {
  const text = readLockText(lockPath);
  if (text === null) return false;
  if (text === undefined || !text) return true;
  return pidAlive(Number(text));
}

function withKeyLock(dir, fn) {
  const lockPath = path.join(dir, LOCK_NAME);
  const flags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_NOFOLLOW;
  function hold() {
    let fd;
    try { fd = fs.openSync(lockPath, flags, 0o600); } catch (e) {
      if (e.code !== 'EEXIST') return false;
      return null;
    }
    try {
      fs.writeSync(fd, String(process.pid));
      try { fs.fsyncSync(fd); } catch (e) {}
    } finally { fs.closeSync(fd); }
    try { return fn(); } finally {
      try { fs.unlinkSync(lockPath); } catch (e) {}
    }
  }
  for (let attempt = 0; attempt < 300; attempt++) {
    const held = hold();
    if (held !== null) return held;
    if (!ownerLive(lockPath)) {
      try { fs.unlinkSync(lockPath); } catch (e) { if (e.code !== 'ENOENT') return false; }
      continue;
    }
    sleepMs(20);
  }
  const text = readLockText(lockPath);
  if (text !== undefined && text !== null && !pidAlive(Number(text || '0'))) {
    try { fs.unlinkSync(lockPath); } catch (e) {}
    const held = hold();
    if (held !== null) return held;
  }
  return false;
}

async function withKeyLockAsync(dir, fn) {
  const lockPath = path.join(dir, LOCK_NAME);
  const flags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_NOFOLLOW;
  async function hold() {
    let fd;
    try { fd = fs.openSync(lockPath, flags, 0o600); } catch (e) {
      if (e.code !== 'EEXIST') return false;
      return null;
    }
    try {
      fs.writeSync(fd, String(process.pid));
      try { fs.fsyncSync(fd); } catch (e) {}
    } finally { fs.closeSync(fd); }
    try { return await fn(); } finally {
      try { fs.unlinkSync(lockPath); } catch (e) {}
    }
  }
  for (let attempt = 0; attempt < 50; attempt++) {
    const held = await hold();
    if (held !== null) return held;
    if (!ownerLive(lockPath)) {
      try { fs.unlinkSync(lockPath); } catch (e) { if (e.code !== 'ENOENT') return false; }
      continue;
    }
    await new Promise((r) => setTimeout(r, 25));
  }
  const text = readLockText(lockPath);
  if (text !== undefined && text !== null && !pidAlive(Number(text || '0'))) {
    try { fs.unlinkSync(lockPath); } catch (e) {}
    const held = await hold();
    if (held !== null) return held;
  }
  return false;
}

function prepareDir(dir) {
  if (typeof dir !== 'string' || dir.length === 0 || dir.includes('\0')) return { error: 'invalid_dir', message: '需要专用缓存目录路径' };
  const resolved = path.resolve(dir);
  let st;
  try { st = fs.lstatSync(resolved); } catch (e) {
    if (e.code !== 'ENOENT') return { error: 'invalid_dir', message: '无法检查缓存目录' };
    st = null;
  }
  if (st && st.isSymbolicLink()) return { error: 'symlink_rejected', message: '缓存目录不能是符号链接' };
  if (!st) {
    const parent = path.dirname(resolved);
    let parentStat;
    try { parentStat = fs.lstatSync(parent); } catch (e) { return { error: 'invalid_dir', message: '缓存目录的上级不存在或不是目录' }; }
    if (!parentStat || parentStat.isSymbolicLink() || !parentStat.isDirectory()) return { error: 'invalid_dir', message: '缓存目录的上级不存在或不是目录' };
    try { fs.mkdirSync(resolved, { mode: 0o700 }); } catch (e) {
      if (e.code !== 'EEXIST') return { error: 'invalid_dir', message: '无法创建缓存目录' };
    }
    try { st = fs.lstatSync(resolved); } catch (e) { return { error: 'invalid_dir', message: '无法检查缓存目录' }; }
  }
  if (st.isSymbolicLink()) return { error: 'symlink_rejected', message: '缓存目录不能是符号链接' };
  if (!st.isDirectory()) return { error: 'invalid_dir', message: '缓存路径不是目录' };
  try { fs.chmodSync(resolved, 0o700); } catch (e) { return { error: 'invalid_dir', message: '无法收紧缓存目录权限' }; }
  return { dir: resolved };
}

// Migration copies a verified existing key; it never replaces a different key.
function importKey(dir, key, {bin = '/usr/bin/security', env = process.env, fingerprint} = {}) {
  const cacheOpts = { dir, bin, env };
  const cacheKey = canonicalCacheKey(cacheOpts);
  try {
    if (!Buffer.isBuffer(key) || key.length !== 32 || fingerprintHex(key) !== fingerprint) throw Error('Audio migration fingerprint mismatch');
    let parent = path.dirname(path.resolve(dir));
    while (!fs.existsSync(parent)) parent = path.dirname(parent);
    if (fs.realpathSync(parent) !== parent) throw Error('Audio migration requires a canonical destination');
    const svc = 'CitesidePendingAudio.' + crypto.createHash('sha256').update(path.resolve(dir)).digest('hex').slice(0, 32);
    let back = kcGet(bin, svc, env);
    if (!back.ok) {
      if (!back.missing || !kcAdd(bin, svc, key.toString('hex'), env).ok) throw Error('Audio migration Keychain unavailable');
      back = kcGet(bin, svc, env);
    }
    if (!back.ok || !back.key.equals(key)) throw Error('Audio migration Keychain readback mismatch');
    if (cacheKey) {
      verifiedCache.set(cacheKey, {
        key: Buffer.from(key),
        hex: key.toString('hex'),
        source: 'import',
      });
    }
    return true;
  } catch (e) {
    try { if (cacheKey) verifiedCache.delete(cacheKey); } catch (err) {}
    throw e;
  }
}

module.exports = { open, importKey, ACCOUNT, openCachedAsync, peekVerified, clearCache };
