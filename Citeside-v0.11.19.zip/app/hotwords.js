'use strict';
// 热词合并（纯函数，server.js sendConfig 调用）。三道闸，顺序固定：
//   ① 单词：去首尾空白，内部连续空白折成一个空格（多词术语不拆）；空的丢。
//      超过本条字符上限的丢。默认仍是 MAX_WORD_CHARS；只有 allowPhrases 或显式 maxWordChars 才放宽。
//   ② 去重：忽略英文大小写，先来的写法保留。顺序由调用方决定。
//   ③ 总量：条数 ≤ cap；所有词字符数之和 ≤ maxTotal，超出从后面按顺序截掉。
// 热词只来自调用方已经选好的字符串。本模块不读记忆库、项目文档或团队名单。
const HOTWORD_CAP = 15;           // 火山当前接受的条数，验证过再谈扩容
const DEEPGRAM_KEYTERM_CAP = 100; // Nova-3 keyterm，Deepgram 文档 2026-10-24：一条流最多 100 个
const MAX_WORD_CHARS = 20;        // 单个热词最多 20 字符（中文按字算）
const DEEPGRAM_MAX_WORD_CHARS = 40; // Nova-3 keyterm 允许多词短语；只在显式放宽时使用
const MAX_TOTAL_CHARS = 1500;     // 全部热词字符总和上限（15 × 20 = 300 远在其下；防未来扩 cap 时忘了总量）
const TITLE_STOP = new Set(['会议', '评审', '讨论', '同步', '对阵', '更新', '纪要', '周会', '今天', '明天', '本周', '项目']);
// 会议套话。不要把 Agenda 放进来：议程编号测试依赖它整词保留。
const EN_STOP = new Set(['meeting', 'sync', 'weekly', 'daily', 'standup', 'review', 'discussion', 'call', 'kickoff', 'notes']);
const TECH_TAIL = new Set(['cache', 'adapter', 'graph', 'attention', 'kernel', 'embedding', 'embeddings', 'buffer', 'pipeline', 'runtime', 'router', 'checkpoint', 'quantization', 'inference', 'decoding', 'prefill']);
const TECH_ACRONYM = new Set('AEC VAD BAA LLM ASR TTS STT RAG GPU CPU TPU NPU API SDK NLP OCR SSL TLS SQL IAM VPC SLA SLO CDN RPC'.split(' '));
const STANDARD_PREFIX = new Set(['ISO', 'IEC', 'NIST', 'PCI', 'IEEE', 'RFC', 'FIPS', 'SOC', 'HIPAA']);
// 经典专名，外加带点、加号、斜杠的技术标识。先匹配带后缀的，避免 Next.js 被切成 Next。
const LATIN_RE = /[A-Za-z][A-Za-z0-9]*(?:(?:\+\+|[./-][A-Za-z0-9]+)[A-Za-z0-9]*)+|[A-Za-z][A-Za-z0-9-]{1,39}/g;
const WORD_RE = /[A-Za-z0-9][A-Za-z0-9.+/-]*/g;

function chars(w) { return [...w].length; }

function wordLimit(opts) {
  if (Number.isFinite(opts.maxWordChars)) return opts.maxWordChars;
  if (opts.allowPhrases === true) return DEEPGRAM_MAX_WORD_CHARS;
  return MAX_WORD_CHARS;
}

function mergeHotwords(lists, opts = {}) {
  const cap = Number.isFinite(opts.cap) ? opts.cap : HOTWORD_CAP;
  const maxWord = wordLimit(opts);
  const maxTotal = Number.isFinite(opts.maxTotalChars) ? opts.maxTotalChars : MAX_TOTAL_CHARS;
  const out = [], seen = new Set(); let total = 0;
  for (const list of Array.isArray(lists) ? lists : []) {
    for (const x of Array.isArray(list) ? list : []) {
      const w = String(x == null ? '' : x).trim().replace(/\s+/g, ' ');
      if (!w) continue;
      const len = chars(w);
      if (len > maxWord) continue;
      const key = w.toLowerCase();
      if (seen.has(key)) continue;
      if (out.length >= cap || total + len > maxTotal) return out;
      seen.add(key); out.push(w); total += len;
    }
  }
  return out;
}

function isYear(n) { return /^19\d{2}$/.test(n) || /^20\d{2}$/.test(n); }
function isTitleWord(w) { return /^[A-Z][a-z]{2,}$/.test(w); }
function isTechHead(w) { return /^[A-Z]{2,8}$/.test(w) || /^[A-Z][a-z]*[A-Z][A-Za-z0-9]*$/.test(w); }
function isCamelIdent(w) { return /^[A-Z][a-z]+(?:[A-Z][a-z0-9]*)+$/.test(w); }
function isScale(w) { return /^\d+(?:\.\d+)?[BbMm]$/.test(w); }
function stoppedWord(w) { return TITLE_STOP.has(w) || EN_STOP.has(String(w).toLowerCase()); }

// 英文标题里的多词技术专名。纯函数，不碰调用方没交过来的文本。
function technicalPhrases(text) {
  const s = String(text == null ? '' : text);
  const words = [];
  for (const m of s.matchAll(WORD_RE)) words.push({ w: m[0], start: m.index, end: m.index + m[0].length });
  const joined = (i, n) => {
    for (let k = 1; k < n; k++) {
      if (!/^\s+$/.test(s.slice(words[i + k - 1].end, words[i + k].start))) return '';
    }
    const phrase = words.slice(i, i + n).map(part => part.w).join(' ');
    if (!phrase || chars(phrase) > DEEPGRAM_MAX_WORD_CHARS) return '';
    if (phrase.split(' ').some(stoppedWord)) return '';
    return phrase;
  };
  const found = [];
  // rank 1 是有结构的技术短语；rank 2 是三词专名；rank 3 是普通双词。重叠时先留更具体的。
  const push = (i, n, rank) => {
    const phrase = joined(i, n);
    if (!phrase) return;
    found.push({ start: words[i].start, end: words[i + n - 1].end, w: phrase, rank });
  };
  for (let i = 0; i < words.length; i++) {
    const a = words[i].w;
    const b = words[i + 1] && words[i + 1].w;
    const c = words[i + 2] && words[i + 2].w;
    if (b && /^[A-Z][A-Za-z]{1,30}$/.test(a) && /^\d+\.\d+$/.test(b)) {
      if (c && isScale(c)) push(i, 3, 1);
      push(i, 2, 1);
    }
    if (b && /^[A-Z]{2,8}$/.test(a) && /^\d{1,2}$/.test(b)) push(i, 2, 1);
    if (b && STANDARD_PREFIX.has(a) && /^\d{3,6}$/.test(b) && !isYear(b)) push(i, 2, 1);
    if (b && isTechHead(a) && TECH_TAIL.has(b.toLowerCase())) push(i, 2, 1);
    if (c && isCamelIdent(a) && isTechHead(b) && TECH_TAIL.has(c.toLowerCase())) push(i, 3, 1);
    if (b && /^[A-Z][A-Za-z0-9]{1,30}$/.test(a) && TECH_ACRONYM.has(b)) push(i, 2, 1);
    if (b && c && isTitleWord(a) && isTitleWord(b) && isTitleWord(c)) push(i, 3, 2);
    // 「Vertex AI」要留。紧跟着技术核心词的缩写属于下一条，例如 Cloud | KV cache，不要收成 Cloud KV。
    if (b && isTitleWord(a) && /^[A-Z]{2}$/.test(b) && !(c && isTechHead(b) && TECH_TAIL.has(c.toLowerCase()))) push(i, 2, 1);
    if (b && isTitleWord(a) && isTitleWord(b)) push(i, 2, 3);
  }
  found.sort((a, b) => a.rank - b.rank || (b.end - b.start) - (a.end - a.start) || a.start - b.start);
  const chosen = []; const seen = new Set();
  for (const item of found) {
    if (chosen.some(prev => item.start < prev.end && prev.start < item.end)) continue;
    const key = item.w.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key); chosen.push(item);
  }
  chosen.sort((a, b) => a.start - b.start);
  return chosen.map(item => item.w);
}

// 从标题、项目名里抽出能当热词的专名。整句标题常常超过 20 字，直接送会被闸丢掉。
// includePhrases 时把多词技术专名附在单词后面；默认不附，避免把「Chansey CDCP」粘成一条。
function properNameTokens(text, opts = {}) {
  const s = String(text == null ? '' : text);
  const latin = (s.match(LATIN_RE) || []).filter(w => chars(w) >= 2 && chars(w) <= DEEPGRAM_MAX_WORD_CHARS);
  const codes = (s.match(/\d{4,8}/g) || []).filter(n => !isYear(n));
  const cjk = s.match(/[\u4e00-\u9fff]{2,6}/g) || [];
  const base = [...latin, ...codes, ...cjk].filter(w => !stoppedWord(w));
  if (!opts || opts.includePhrases !== true) return base;
  const seen = new Set(base.map(w => w.toLowerCase()));
  const extra = [];
  for (const phrase of technicalPhrases(s)) {
    const key = phrase.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key); extra.push(phrase);
  }
  return [...base, ...extra];
}

// 上一场里反复出现的专名。同一句里重复只算一次，至少 minCount 句才留下。
function frequentTerms(lines, opts = {}) {
  const min = Number.isFinite(opts.minCount) ? opts.minCount : 2;
  const counts = new Map();
  for (const line of Array.isArray(lines) ? lines : []) {
    for (const w of new Set(properNameTokens(line))) counts.set(w, (counts.get(w) || 0) + 1);
  }
  return [...counts.entries()]
    .filter(([, n]) => n >= min)
    .sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0))
    .map(([w]) => w);
}

module.exports = {
  mergeHotwords, properNameTokens, frequentTerms, technicalPhrases,
  HOTWORD_CAP, DEEPGRAM_KEYTERM_CAP, MAX_WORD_CHARS, DEEPGRAM_MAX_WORD_CHARS, MAX_TOTAL_CHARS,
};
