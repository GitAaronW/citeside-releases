'use strict';
// Configuration and task snapshots only. Execution stays in llm.js.
const { createHash } = require('node:crypto');
const outboundPolicy = require('./outbound-policy');
const ROLES = Object.freeze(['input-detect', 'understand', 'lookup', 'research', 'draft', 'discovery-edit', 'chat', 'summary']);
const MODEL_KINDS = Object.freeze(['live', 'post', 'quick', 'think', 'triage', 'verify', 'insight-deep', 'postFallback']);
const tasks = new WeakMap();
const stageContexts = new WeakMap();
const LEGACY_STAGE_FIELDS = Object.freeze(['CLOUD_AI', 'ACTIVE_INTELLIGENCE_MODE', 'LLM_QUICK_ROUTE', 'LLM_PROVIDER', 'LLM_MODEL_QUICK', 'LLM_MODEL_POST']);
function invalid(code) { throw Object.assign(new Error(code), { code }); }
const object = x => x && typeof x === 'object' && !Array.isArray(x);
function freeze(x) { if (object(x) || Array.isArray(x)) { Object.values(x).forEach(freeze); Object.freeze(x); } return x; }
function stable(x) { return JSON.stringify(x, (_, v) => object(v) ? Object.fromEntries(Object.keys(v).sort().map(k => [k, v[k]])) : v); }
function positive(n, code, max) { if (!Number.isSafeInteger(n) || n < 1 || n > max) invalid(code); return n; }
// Optional call-count policy. This is independent of research's existing limits.
function compileCallBudget(input){
 if(input===undefined||input===null||input==='')return null;
 if(typeof input==='string'){try{input=JSON.parse(input);}catch{invalid('call_budget_config_invalid');}}
 if(!object(input)||Object.keys(input).some(k=>!['meetingCalls','propositionCalls','meetingSearches','propositionSearches','meetingFetches','propositionFetches'].includes(k)))invalid('call_budget_config_invalid');
 for(const n of Object.values(input))if(!Number.isSafeInteger(n)||n<0)invalid('call_budget_config_invalid');
 return Object.keys(input).length?freeze({...input}):null;
}
function callBudget(env={}){return compileCallBudget(env.LLM_CALL_BUDGET??env.LLM_ROUTING?.callBudget);}
function compile(input) {
  if (!object(input) || input.schemaVersion !== 1 || !object(input.connections) || !object(input.profiles) || !object(input.roles)) invalid('routing_schema_invalid');
  const config = structuredClone(input);
  outboundPolicy.validate(config.externalServices);
  if(config.callBudget!==undefined)config.callBudget=compileCallBudget(config.callBudget);
  for (const [id, c] of Object.entries(config.connections)) {
    if (!id || !object(c) || !['openai', 'cli', 'cloud-trial'].includes(c.protocol) || !c.region || !c.dataScope) invalid('routing_connection_invalid');
    if (c.protocol === 'openai' || c.protocol === 'cloud-trial') {
      let u; try { u = new URL(c.endpoint); } catch { invalid('routing_endpoint_invalid'); }
      if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password || u.search || u.hash) invalid('routing_endpoint_invalid');
      if (u.protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(u.hostname)) invalid('routing_endpoint_insecure');
      if (c.protocol === 'openai' && (typeof c.credentialRef !== 'string' || !c.credentialRef)) invalid('routing_credential_ref_required');
      if (c.protocol === 'cloud-trial' && c.credentialRef !== undefined) invalid('routing_trial_credential_forbidden');
    } else if (c.kind === 'custom') {
      // bin/args/stdin/promptArg/outputJson must stay explicit so llm.normalize cannot invent them.
      if (typeof c.bin !== 'string' || !c.bin.trim()) invalid('routing_cli_invalid');
      if (!Array.isArray(c.args) || c.args.some(item => typeof item !== 'string')) invalid('routing_cli_invalid');
      if (c.stdin !== 'prompt' && c.stdin !== 'none') invalid('routing_cli_invalid');
      if (typeof c.promptArg !== 'string' || typeof c.outputJson !== 'string') invalid('routing_cli_invalid');
    } else if (!['codex', 'claude'].includes(c.kind)) invalid('routing_cli_unsupported');
    // Credentials belong to the environment/key store, never configuration.
    if ('key' in c || 'token' in c || 'password' in c || 'keyFrom' in c) invalid('routing_inline_credential_forbidden');
  }
  for (const [id, p] of Object.entries(config.profiles)) {
    const c = config.connections[p?.connection];
    if (!id || !object(p) || !c || typeof p.modelId !== 'string' || !object(p.capabilities)) invalid('routing_profile_invalid');
    if ('key' in p || 'token' in p || 'password' in p || 'keyFrom' in p) invalid('routing_inline_credential_forbidden');
    // An empty CLI model is the tool's own default. An API model still has to name one.
    if (c.protocol === 'cli' ? (p.modelId !== '' && !p.modelId.trim()) : !p.modelId.trim()) invalid('routing_profile_invalid');
    // An explicit table uses provider.models / pickModel semantics, including missing and empty entries.
    // modelId remains the representative/display model; older profiles without a table stay fixed-model.
    if (p.models !== undefined) {
      if (!object(p.models) || Object.entries(p.models).some(([kind, model]) => !MODEL_KINDS.includes(kind) || typeof model !== 'string' || (model !== '' && !model.trim()))) invalid('routing_models_invalid');
      if (p.modelFallback !== undefined) invalid('routing_model_fallback_invalid');
    }
    // Same-provider retry model. A second profile would let noFallback, live stages and skip drop it.
    if (p.modelFallback !== undefined) {
      if (typeof p.modelFallback !== 'string' || !p.modelFallback.trim() || p.modelFallback === p.modelId) invalid('routing_model_fallback_invalid');
    }
    if (p.label !== undefined && (typeof p.label !== 'string' || !p.label)) invalid('routing_profile_invalid');
    for (const k of ['json', 'tools', 'vision']) if (typeof p.capabilities[k] !== 'boolean') invalid('routing_capability_required');
    // Native web execution is the only tool protocol implemented in this adapter.
    // General API tool loops remain a separate, explicit integration.
    if (p.capabilities.tools && !(c.protocol === 'cli' && c.kind === 'claude')) invalid('routing_tool_adapter_unavailable');
    if (c.protocol === 'cli' && c.kind !== 'codex' && p.capabilities.json) invalid('routing_json_adapter_unavailable');
    const o = p.options || {};
    if (!object(o) || Object.keys(o).some(k => !['temperature', 'thinking', 'reasoningEffort'].includes(k))) invalid('routing_options_invalid');
    if (o.temperature !== undefined && (!Number.isFinite(o.temperature) || o.temperature < 0 || o.temperature > 2)) invalid('routing_temperature_invalid');
    if (o.thinking !== undefined && !['enabled', 'disabled'].includes(o.thinking)) invalid('routing_thinking_invalid');
    if (o.reasoningEffort !== undefined && !['low', 'medium', 'high', 'xhigh'].includes(o.reasoningEffort)) invalid('routing_effort_invalid');
    if (c.protocol === 'cli' && Object.keys(o).length) invalid('routing_cli_options_unavailable');
    if (c.protocol === 'cloud-trial' && (!['fast','slow'].includes(p.modelId) || (p.models && Object.values(p.models).some(m => !['fast','slow'].includes(m))) || p.modelFallback !== undefined || (p.capabilities.vision && p.modelId !== 'fast') || Object.keys(o).some(k => k !== 'temperature'))) invalid('routing_trial_profile_invalid');
    if (p.maxInput !== undefined) positive(p.maxInput, 'routing_input_limit_invalid', 10000000);
  }
  if (Object.keys(config.roles).some(r => !ROLES.includes(r))) invalid('routing_role_unknown');
  for (const role of ROLES) {
    const policy = config.roles[role];
    if (!object(policy) || !config.profiles[policy.primary] || !Array.isArray(policy.fallback)) invalid('routing_policy_invalid');
    const ids = [policy.primary, ...policy.fallback];
    if (policy.legacyStage !== undefined) {
      const stage = policy.legacyStage;
      if (!object(stage) || Object.keys(stage).some(k => !['version','environment','explicitChain','proactiveProfile'].includes(k)) || stage.version !== 1 || typeof stage.explicitChain !== 'boolean' || !object(stage.environment) || Object.keys(stage.environment).some(k => !LEGACY_STAGE_FIELDS.includes(k)) || LEGACY_STAGE_FIELDS.some(k => typeof stage.environment[k] !== 'string' || stage.environment[k].length > 512)) invalid('routing_legacy_stage_invalid');
      const gate = config.profiles[stage.proactiveProfile], connection = config.connections[gate?.connection];
      if (!gate || connection?.protocol !== 'cli' || connection.kind !== 'codex' || gate.models?.quick !== 'gpt-5.6-luna') invalid('routing_legacy_gate_invalid');
    }
    if (new Set(ids).size !== ids.length || ids.some(id => !config.profiles[id])) invalid('routing_fallback_invalid');
    positive(policy.deadlineMs, 'routing_deadline_invalid', 1800000);
    const first = config.connections[config.profiles[policy.primary].connection];
    // The account service owns the paid upstream. Never turn a trial outage into
    // an undeclared local-key call or silently mix the two transports.
    if (ids.some(id => config.connections[config.profiles[id].connection].protocol === 'cloud-trial') && (first.protocol !== 'cloud-trial' || policy.fallback.length || policy.legacyStage)) invalid('routing_trial_fallback_unavailable');
    const regions = policy.allowedRegions || [first.region], scopes = policy.allowedDataScopes || [first.dataScope];
    if (!Array.isArray(regions) || !regions.length || !Array.isArray(scopes) || !scopes.length) invalid('routing_boundary_invalid');
    for (const id of [...ids, ...(policy.legacyStage ? [policy.legacyStage.proactiveProfile] : [])]) {
      const c = config.connections[config.profiles[id].connection];
      if (!outboundPolicy.within(c, regions, scopes)) invalid('routing_fallback_boundary');
    }
  }
  return freeze({ config, routeVersion: createHash('sha256').update(stable(config)).digest('hex').slice(0, 24) });
}
function createTask(compiled, role, env = {}, now = Date.now()) {
  if (!compiled?.config || !ROLES.includes(role)) invalid('routing_role_required');
  const { config, routeVersion } = compiled, policy = config.roles[role];
  const buildProvider = id => {
    const p = config.profiles[id], c = config.connections[p.connection];
    const models = p.models !== undefined ? { ...p.models } : Object.fromEntries(['live', 'post', 'quick', 'think', 'triage', 'verify'].map(k => [k, p.modelId]));
    if (p.models === undefined && typeof p.modelFallback === 'string' && p.modelFallback !== p.modelId) models.postFallback = p.modelFallback;
    const name = typeof p.label === 'string' && p.label ? p.label : id;
    let raw;
    if (c.protocol === 'openai') {
      const key = env[c.credentialRef];
      if (typeof key !== 'string' || !key) invalid('routing_credential_unavailable');
      raw = { type: 'openai', baseUrl: c.endpoint, key, name, maxInput: p.maxInput, models, vision: p.capabilities.vision };
    } else if (c.protocol === 'cloud-trial') {
      raw = { type: 'cloud-trial', baseUrl: c.endpoint, name, models, maxInput: p.maxInput };
    } else {
      raw = { type: 'cli', kind: c.kind, name, models, vision: p.capabilities.vision };
      if (c.kind === 'custom') {
        raw.bin = c.bin;
        raw.args = c.args.slice();
        raw.stdin = c.stdin;
        raw.promptArg = c.promptArg;
        raw.outputJson = c.outputJson;
      }
    }
    return { raw, capabilities: p.capabilities, options: p.options || {}, profileId: id };
  };
  const providers = [policy.primary, ...policy.fallback].map(buildProvider);
  const task = Object.freeze({ role, routeVersion, deadlineAt: now + policy.deadlineMs,callBudget:config.callBudget });
  tasks.set(task, freeze(providers));
  if (policy.legacyStage) stageContexts.set(task, freeze({ environment: {...policy.legacyStage.environment, LLM_CHAIN: policy.legacyStage.explicitChain ? [true] : []}, proactive: buildProvider(policy.legacyStage.proactiveProfile) }));
  return task;
}
function providers(task) { const p = tasks.get(task); if (!p) invalid('routing_snapshot_invalid'); return p; }
function hasNativeWebTools(provider) { return !!(provider?.raw?.type === 'cli' && provider.raw.kind === 'claude' && provider.capabilities?.tools); }
function stageContext(task) { providers(task); return stageContexts.get(task) || null; }
function registry(initial) {
  let active = initial ? compile(initial) : null;
  return { update(input) { try { const next = compile(input); active = next; return { ok: true, routeVersion: next.routeVersion }; }
    catch (e) { return { ok: false, errorCode: e.code || 'routing_config_invalid', routeVersion: active?.routeVersion || null }; } },
  task(role, env, now) { if (!active) invalid('routing_config_missing'); return createTask(active, role, env, now); } };
}
module.exports = { compileCallBudget,callBudget,ROLES, MODEL_KINDS, compile, createTask, providers, hasNativeWebTools, stageContext, registry };
