'use strict';
const crypto=require('node:crypto');
const norm=s=>String(s||'').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');
function edit(session,{action,id,title,sourceIds=[]}){
 if(!session||session.finalized||session.end)throw Error('Meeting is not active');
 const topics=[...(session.topicControls||[])];
 if(action==='add'||action==='dismiss'){
  if(typeof title!=='string'||!norm(title)||title.length>120)throw Error('Topic title must contain 1–120 characters');
  let topic=topics.find(t=>t.id===id||norm(t.title)===norm(title));
  if(!topic){if(topics.length>=100)throw Error('Too many topics');topic={id:crypto.randomUUID(),title:title.trim(),manual:action==='add',sourceIds:[]};topics.push(topic);}
  const known=new Set((session.transcript||[]).map(r=>String(r.id||r.segId)));
  topic={...topic,dismissed:action==='dismiss',sourceIds:[...new Set([...topic.sourceIds,...(Array.isArray(sourceIds)?sourceIds:[]).filter(x=>typeof x==='string'&&known.has(x))])]};
  topics[topics.findIndex(t=>t.id===topic.id)]=topic;
 }else if(action==='restore'){
  const i=topics.findIndex(t=>t.id===id);if(i<0)throw Error('Topic not found');topics[i]={...topics[i],dismissed:false};
 }else throw Error('Unsupported topic action');
 session.topicControls=topics;session.topicControlRevision=(session.topicControlRevision||0)+1;
 if(action==='dismiss')session.flushProperNames?.();
 session.checkpoint?.();session.broadcast?.({type:'topics',sessionId:session.id,topics});return topics;
}
function blocked(session,item){
 if(!item)return false;
 const ids=[...(item.sourceIds||[]),...(item.sourceRefs||[]).map(r=>typeof r==='string'?r:r.segId||r.id)];
 const text=norm([item.topic,item.title,item.entity,item.text,item.point,item.claim,item.quote,item.md].filter(Boolean).join(' '));
 return (session?.topicControls||[]).some(t=>t.dismissed&&(ids.some(id=>t.sourceIds.includes(id))||text.includes(norm(t.title))));
}
function filter(session,parsed){
 if(!parsed||typeof parsed!=='object')return parsed;
 if(Array.isArray(parsed))return parsed.filter(x=>!blocked(session,x));
 const out={...parsed};
 for(const k of ['suggestion','insight','currentJudgment','research','deliverable','confirmation'])if(blocked(session,out[k]))delete out[k];
 for(const k of ['insights','background'])if(Array.isArray(out[k]))out[k]=out[k].filter(x=>!blocked(session,x));
 return out;
}
function context(session){return {instruction:'User topic controls: do not track or generate cards, research, drafts or suggestions for dismissed topics, including paraphrases. Active manually added topics are user interests, not meeting facts or decisions.',topics:session.topicControls||[]};}
module.exports={edit,blocked,filter,context};
