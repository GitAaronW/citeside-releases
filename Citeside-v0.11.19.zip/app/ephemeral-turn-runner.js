'use strict';

function failure(code) { const error = new Error(code); error.code = code; return error; }

// Serial bounded turns on a reusable, tool-free transport. Only the transport
// process is reused: every job starts a fresh ephemeral thread and unsubscribes.
// Production use is restricted by the caller's explicit default-off gate switch.
class EphemeralTurnRunner {
  constructor({ createTransport, model, cwd, instructions, effort = 'low', maxQueue = 2, maxOutputBytes = 1024 * 1024 }) {
    if (typeof createTransport !== 'function' || !model || !cwd || !instructions) throw new TypeError('explicit isolated configuration required');
    if (!Number.isSafeInteger(maxQueue) || maxQueue < 0 || !Number.isSafeInteger(maxOutputBytes) || maxOutputBytes <= 0) throw new TypeError('invalid limits');
    Object.assign(this, { createTransport, model, cwd, instructions, effort, maxQueue, maxOutputBytes });
    this.queue = [];
    this.active = null;
    this.transport = null;
    this.closed = false;
  }

  run(text, { signal, timeoutMs = 15000 } = {}) {
    if (this.closed) return Promise.reject(failure('runner_closed'));
    if (signal?.aborted) return Promise.reject(failure('cancelled'));
    if (typeof text !== 'string' || !text.trim() || !Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) return Promise.reject(failure('invalid_request'));
    if (this.active && this.queue.length >= this.maxQueue) return Promise.reject(failure('transport_busy'));
    return new Promise((resolve, reject) => {
      const job = { text, controller: new AbortController(), deadline: Date.now() + timeoutMs, done: false };
      job.settle = (error, result) => {
        if (job.done) return;
        job.done = true;
        clearTimeout(job.timer);
        signal?.removeEventListener('abort', abort);
        error ? reject(error) : resolve(result);
      };
      const cancel = code => {
        if (job.done) return;
        job.controller.abort(failure(code));
        if (this.active === job) this.transport?.close(code);
        else this.queue = this.queue.filter(entry => entry !== job);
        job.settle(failure(code));
      };
      const abort = () => cancel('cancelled');
      job.timer = setTimeout(() => cancel('timeout'), timeoutMs);
      signal?.addEventListener('abort', abort, { once: true });
      if (signal?.aborted) return abort();
      this.queue.push(job);
      this.pump();
    });
  }

  async pump() {
    if (this.active || this.closed) return;
    const job = this.queue.shift();
    if (!job) return;
    this.active = job;
    try { job.settle(null, await this.execute(job)); }
    catch (error) {
      // Retire failed work before admitting the next job; an independent
      // fallback must never race abandoned work on the previous connection.
      this.transport?.close('turn_failed');
      job.settle(error);
    }
    finally { this.active = null; this.pump(); }
  }

  async execute(job) {
    const check = () => {
      if (job.controller.signal.aborted) throw job.controller.signal.reason;
      if (this.closed) throw failure('runner_closed');
      const remaining = job.deadline - Date.now();
      if (remaining <= 0) throw failure('timeout');
      return remaining;
    };
    if (!this.transport || this.transport.closed) {
      check();
      // Factory is synchronous (spawn + transport construction), never an
      // unbounded asynchronous connection promise outside the job deadline.
      this.transport = this.createTransport();
      if (!this.transport || ['request', 'notify', 'close', 'on', 'removeListener'].some(method => typeof this.transport[method] !== 'function')) {
        if (typeof this.transport?.close === 'function') this.transport.close('invalid_transport');
        this.transport = null;
        throw failure('invalid_transport');
      }
      try {
        await this.transport.request('initialize', {
          clientInfo: { name: 'meeting_semantic_transport', version: '0.1' },
          capabilities: { experimentalApi: true },
        }, { signal: job.controller.signal, timeoutMs: check() });
        this.transport.notify('initialized', {});
      } catch (error) { this.transport.close('initialize_failed'); throw error; }
    }
    const transport = this.transport;
    const rpc = (method, params) => transport.request(method, params, { signal: job.controller.signal, timeoutMs: check() });
    let threadId = null, turnId = null, early = [], outputBytes = 0, usage;
    const messages = new Map();
    let resolveCompleted, rejectCompleted;
    const completed = new Promise((resolve, reject) => { resolveCompleted = resolve; rejectCompleted = reject; });
    // Handle immediate failure notifications while an RPC response is pending.
    completed.catch(() => {});
    const fail = code => { rejectCompleted(failure(code)); transport.close(code); };
    const consume = event => {
      const params = event.params || {};
      if (!threadId || params.threadId !== threadId) return;
      if (!['item/completed', 'turn/completed', 'thread/tokenUsage/updated'].includes(event.method)) return;
      if (!turnId) {
        // A completion can beat the turn/start response. Bound that race buffer.
        if (early.length >= 64) return fail('notification_overflow');
        early.push(event);
        return;
      }
      if (event.method === 'thread/tokenUsage/updated' && params.turnId === turnId) {
        const last = params.tokenUsage?.last;
        // Official per-turn counters only; never infer zero or use another
        // thread/turn's cumulative usage. Missing/invalid remains unavailable.
        if (last && [last.inputTokens, last.outputTokens, last.cachedInputTokens].every(value => Number.isSafeInteger(value) && value >= 0) && last.cachedInputTokens <= last.inputTokens) {
          usage = { in: last.inputTokens, out: last.outputTokens, cache: last.cachedInputTokens };
        }
      }
      if (event.method === 'item/completed' && params.turnId === turnId && params.item?.type === 'agentMessage') {
        const item = params.item;
        if (typeof item.id !== 'string' || typeof item.text !== 'string' || messages.has(item.id)) return;
        outputBytes += Buffer.byteLength(item.text);
        if (outputBytes > this.maxOutputBytes) return fail('output_too_large');
        messages.set(item.id, item.text);
      }
      if (event.method === 'turn/completed' && params.turn?.id === turnId) {
        if (params.turn.status !== 'completed') return rejectCompleted(failure('turn_failed'));
        resolveCompleted();
      }
    };
    const closed = reason => rejectCompleted(failure(reason));
    transport.on('notification', consume);
    transport.on('closed', closed);
    try {
      const started = await rpc('thread/start', {
        model: this.model, cwd: this.cwd, baseInstructions: this.instructions,
        allowProviderModelFallback: false, approvalPolicy: 'never', sandbox: 'read-only',
        ephemeral: true, environments: [], dynamicTools: [],
      });
      threadId = started?.thread?.id;
      if (typeof threadId !== 'string' || !threadId || started.thread.ephemeral !== true) {
        transport.close('invalid_thread');
        throw failure('invalid_thread');
      }
      const startedTurn = await rpc('turn/start', {
        threadId, model: this.model, effort: this.effort, environments: [],
        input: [{ type: 'text', text: job.text, text_elements: [] }],
      });
      turnId = startedTurn?.turn?.id;
      if (typeof turnId !== 'string' || !turnId) { transport.close('invalid_turn'); throw failure('invalid_turn'); }
      for (const event of early) consume(event);
      early = [];
      await completed;
      check();
      const text = [...messages.values()].join('\n');
      if (!text.trim()) throw failure('empty');
      return { text, threadId, turnId, ...(usage ? { usage } : {}) };
    } finally {
      transport.removeListener('notification', consume);
      transport.removeListener('closed', closed);
      if (threadId && !transport.closed && !job.controller.signal.aborted) {
        // Cleanup is within the original deadline, not an extra timeout budget.
        try { await rpc('thread/unsubscribe', { threadId }); }
        catch (_) { transport.close('cleanup_failed'); }
      }
    }
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    this.transport?.close('runner_closed');
    if (this.active) {
      this.active.controller.abort(failure('runner_closed'));
      this.active.settle(failure('runner_closed'));
    }
    for (const job of this.queue.splice(0)) job.settle(failure('runner_closed'));
  }
}

module.exports = { EphemeralTurnRunner };
