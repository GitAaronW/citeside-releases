'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const durable = require('./durable-json');

const SAFE_CHARS = /[^\p{L}\p{N}_ .-]/gu;

function homeRoot(homeDir = os.homedir()) {
  return fs.realpathSync(path.resolve(String(homeDir || os.homedir())));
}

function defaultDir(homeDir = os.homedir()) {
  const h = homeRoot(homeDir);
  const icloud = path.join(h, 'Library', 'Mobile Documents', 'com~apple~CloudDocs');
  if (fs.existsSync(icloud)) return path.join(icloud, 'Citeside');
  return path.join(h, 'Documents', 'Citeside');
}

function expandHome(raw, homeDir = os.homedir()) {
  const text = String(raw || '').trim();
  const h = path.resolve(String(homeDir || os.homedir()));
  if (!text || text === '~') return h;
  if (text.startsWith('~/') || text.startsWith('~\\')) return path.join(h, text.slice(2));
  return text;
}

function validateDir(raw, homeDir = os.homedir()) {
  const expanded = expandHome(raw || defaultDir(homeDir), homeDir);
  if (!expanded) throw Error('请选择本机镜像目录');
  const resolved = path.resolve(expanded);
  const home = homeRoot(homeDir);
  if (resolved === home) throw Error('镜像目录不能直接设为用户主目录，请选择子目录');
  // Walk up until an existing ancestor is found to reject symlink escapes outside homeDir.
  const segments = [];
  let cursor = resolved;
  while (!fs.existsSync(cursor)) {
    const parent = path.dirname(cursor);
    if (parent === cursor) break;
    segments.unshift(path.basename(cursor));
    cursor = parent;
  }
  const realBase = fs.existsSync(cursor) ? fs.realpathSync(cursor) : cursor;
  const target = path.join(realBase, ...segments);
  if (target === home) throw Error('镜像目录不能直接设为用户主目录，请选择子目录');
  const rel = path.relative(home, target);
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) {
    throw Error('镜像目录必须位于当前用户主目录内（例如 ~/Documents/Citeside 或 iCloud Drive/Citeside）');
  }
  return target;
}

function safeName(title, id = '') {
  const base = String(title || 'citeside-output')
    .replace(SAFE_CHARS, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60) || 'citeside-output';
  const suffix = String(id || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(-12);
  return suffix ? `${base}-${suffix}` : base;
}

function status(settings, homeDir = os.homedir()) {
  const cur = settings.load();
  const enabled = String(cur.LOCAL_MIRROR_ENABLED || '') === '1';
  const folder = String(cur.LOCAL_MIRROR_DIR || '').trim() || defaultDir(homeDir);
  return { ok: true, enabled, folder };
}

function configure(settings, payload = {}, homeDir = os.homedir()) {
  const cur = settings.load();
  const nextEnabled = payload.enabled !== undefined ? Boolean(payload.enabled) : String(cur.LOCAL_MIRROR_ENABLED || '') === '1';
  const rawFolder = payload.folder !== undefined ? String(payload.folder || '') : (cur.LOCAL_MIRROR_DIR || defaultDir(homeDir));
  const folder = nextEnabled ? validateDir(rawFolder, homeDir) : (rawFolder ? validateDir(rawFolder, homeDir) : defaultDir(homeDir));
  if (nextEnabled) fs.mkdirSync(folder, { recursive: true, mode: 0o700 });
  settings.save({
    ...cur,
    LOCAL_MIRROR_ENABLED: nextEnabled ? '1' : '',
    LOCAL_MIRROR_DIR: folder,
  });
  return { ok: true, enabled: nextEnabled, folder };
}

function writeOutput(settings, payload = {}, homeDir = os.homedir()) {
  const cur = settings.load();
  const enabled = payload.force === true || String(cur.LOCAL_MIRROR_ENABLED || '') === '1';
  if (!enabled) return { ok: true, skipped: true, files: [] };
  const folder = validateDir(cur.LOCAL_MIRROR_DIR || defaultDir(homeDir), homeDir);
  fs.mkdirSync(folder, { recursive: true, mode: 0o700 });
  const stem = safeName(payload.title, payload.id);
  const files = [];
  if (typeof payload.markdown === 'string' && payload.markdown.trim()) {
    const mdPath = path.join(folder, stem + '.md');
    durable.writeText(mdPath, payload.markdown, { mode: 0o600 });
    files.push(mdPath);
  }
  if (typeof payload.html === 'string' && payload.html.trim()) {
    const htmlPath = path.join(folder, stem + '.html');
    durable.writeText(htmlPath, payload.html, { mode: 0o600 });
    files.push(htmlPath);
  }
  if (!files.length) throw Error('没有可写入的产出内容');
  return { ok: true, folder, files };
}

module.exports = { defaultDir, validateDir, safeName, status, configure, writeOutput };
