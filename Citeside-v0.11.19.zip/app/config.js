'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const dataDir=path.resolve(process.env.THT_DATA_DIR||path.join(os.homedir(),'Library/Application Support/Citeside'));
process.env.THT_DATA_DIR=dataDir;
process.umask(0o077);fs.mkdirSync(dataDir,{recursive:true,mode:0o700});
const file=path.join(dataDir,'settings.json');
const defaults={THT_SELF_EDITION:'',MEETING_FRAME:'on',developerPreviewEnabled:false,PRESET_VERSION:'',ASR_PROVIDER:'',DEEPGRAM_API_KEY:'',DEEPGRAM_MODEL:'nova-3',DEEPGRAM_ENDPOINT:'wss://api.deepgram.com/v1/listen',MEMORY_PROJECTION_DIR:'',LOCAL_MIRROR_ENABLED:'',LOCAL_MIRROR_DIR:'',LLM_PROVIDER:'',LLM_PROVIDER_AUTO:'',CLOUD_AI:'on',CLOUD_ACCOUNT_URL:'',THT_CLOUD_TRIAL:'',FREE_AI_URL:'',FREE_AI_TOKEN:'',VOLC_APP_KEY:'',VOLC_ACCESS_KEY:'',VOLC_RESOURCE_ID:'volc.seedasr.sauc.duration',DEEPSEEK_API_KEY:'',NOTION_TOKEN:'',NOTION_DISCONNECTED:'',SLACK_BOT_TOKEN:'',SLACK_USER_TOKEN:'',NOTION_DOCUMENT_PARENT:'',GOOGLE_DRIVE_PATHS:'',GOOGLE_OAUTH_CLIENT_ID:'',GOOGLE_OAUTH_CLIENT_SECRET:'',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-chat',LLM_MODEL_QUICK:'',LLM_MODEL_CHAT:'',LLM_CHAT_EFFORT:'',LLM_QUICK_ROUTE:'auto',LLM_MODEL_LIVE:'sonnet',LLM_MODEL_POST:'fable',LLM_MODEL_POST_FALLBACK:'opus',LLM_LIVE_THINKING:'0',LLM_MODEL_THINK:'opus',VERIFY_LIVE:'on',VERIFY_THINKING:'8000',THINK_PASS:'on',TRIAGE_CONTEXT_DELTA:'0',ACTIVE_INTELLIGENCE_MODE:'rapid',ACTIVE_INTELLIGENCE_FAST_MS:'5000',ACTIVE_INTELLIGENCE_SWEEP_MS:'60000',ACTIVE_INTELLIGENCE_SLOW_MS:'60000',ACTIVE_INTELLIGENCE_SLOW_GAP_MS:'180000',ARCHIVE_TARGET:'local',THT_ARCHIVE_OWNER_ID:'',AUDIO_RETENTION_DAYS:'30',JEV_API_KEY:'',JEV_ENDPOINT:'',JEV_MODEL:'',JEV_GATE:'on',JEV_THRESHOLD:'0.25',JEV_MIN_GAP_MS:'2000',LOCAL_GATE:'on',DECISION_BOARD_DIR:'',MEETING_TIER:'auto',MEETING_PUSH:'off',MEETING_PUSH_SELF_NAMES:'',MEETING_PUSH_MIN_GAP_MS:'120000',MEETING_PUSH_TO:'',MEETING_DM_PUSH:'on',UI_MODE:'full',LITE_PINNED:'off',LITE_STEALTH:'off',SILENT_MEMORY:'on',PRIVACY_ROUTE_MODE:'',ZDR_PROVIDER:'vertex',LOCAL_ASR_ENGINE:'mac',LOCAL_LLM_ENDPOINT:'',LOCAL_LLM_MODEL:'',FORBID_SHARE:'off',NOTES_RETENTION_DAYS:'0'};   // DECISION_BOARD_DIR：决策板夜间导出目录（app/decision-board.js，默认 <PROJECT_CONTEXT_DIR>/kb_backup）；MEETING_PUSH*：会中飞书提醒白名单推送（app/push-whitelist.js，THT-R4：默认 off = 零推送，分诊照跑）   // LLM_LIVE_THINKING：会中分诊（live 档）走 claude 命令行时的思考预算。默认不带思考（'0'；实测分诊 2,000 多输出 token 大半是思考，回放中位 15.2 s → 5.1 s、条目数没少），设 '1' 或更大恢复思考（值 = 预算上限），'' = 不干预沿用命令行默认   // TRIAGE_CONTEXT_DELTA：项目背景「hash 不变只给占位」，默认 '0' 关（claude -p 每次新进程，模型看不见「上一次」，占位那轮没有背景可对照），'1' 启用   // JEV_*：逐句门卫（app/jev-gate.js），JEV_GATE=on 且有密钥才调；密钥只在 settings.json（2026-09-22 Aaron 确认上云链路）   // AUDIO_RETENTION_DAYS：录音保留天数，0 = 不清理；文字永不删（2026-09-22 Aaron 定）
// JEV_REALTIME 是 JEV_GATE 的别名（批 5，2026-09-22）：老设置 / 需求单里写的是 JEV_REALTIME，读进来当 JEV_GATE 用；两个都写了以 JEV_GATE 为准。
function aliasJev(j){const out={...j};if(out.JEV_GATE===undefined||out.JEV_GATE==='') {if(out.JEV_REALTIME!==undefined&&out.JEV_REALTIME!=='') out.JEV_GATE=out.JEV_REALTIME;} return out;}
// TENANT-SECURITY：第三方密钥在钥匙串里（app/secret-store.js），文件里只留空值和清单；load 补回，save 搬走。
const secrets=require('./secret-store');
const routingStore=require('./model-routing-store');
const routing=routingStore.create({dataDir});
const routingFile=path.join(dataDir,routingStore.FILE_NAME||'model-routing.json');
let configCache=null,routingGeneration=0;
const routingUpdate=routing.update;
routing.update=function(input){
  routingGeneration++;configCache=null;
  return routingUpdate(input);
};
function fileStamp(p){try{const s=fs.statSync(p,{bigint:true});return `${s.ino}:${s.size}:${s.mtimeNs}:${s.ctimeNs}`;}catch(e){if(e&&e.code==='ENOENT')return 'missing';throw e;}}
function configCacheKey(){
  return fileStamp(file)+'\n'+fileStamp(routingFile)+'\n'+JSON.stringify([process.env.LIVE_RESEARCH,process.env.LIVE_RESEARCH_BUDGET,process.env.LIVE_RESEARCH_TIER,process.env.LIVE_RESEARCH_COPY_AUTO,process.env.THT_CLOUD_ACCOUNT_URL,process.env.THT_CLOUD_TRIAL,process.env.THT_SELF_EDITION])+'\n'+routingGeneration;
}
function withRouting(env){
  routing.load();
  const status=routing.status(),config=routing.document();
  if(config)return {...env,LLM_ROUTING:config};
  return status.state==='invalid'?{...env,LLM_ROUTING_ERROR:status.errorCode}:env;
}
function loadFresh(){const j=JSON.parse(fs.readFileSync(file,'utf8'));if(!j.RELAY_TOKEN)throw Error('本机配置不完整，请恢复 settings.json');return withRouting({...defaults,...aliasJev(secrets.hydrate(j,dataDir)),...(process.env.LIVE_RESEARCH!==undefined?{LIVE_RESEARCH:process.env.LIVE_RESEARCH}:{}),...(process.env.LIVE_RESEARCH_BUDGET!==undefined?{LIVE_RESEARCH_BUDGET:process.env.LIVE_RESEARCH_BUDGET}:{}),LIVE_RESEARCH_TIER:process.env.LIVE_RESEARCH_TIER||j.LIVE_RESEARCH_TIER||'pro',LIVE_RESEARCH_COPY_AUTO:process.env.LIVE_RESEARCH_COPY_AUTO??j.LIVE_RESEARCH_COPY_AUTO??'on',...(process.env.THT_CLOUD_ACCOUNT_URL!==undefined?{CLOUD_ACCOUNT_URL:process.env.THT_CLOUD_ACCOUNT_URL}:{}),...(process.env.THT_CLOUD_TRIAL!==undefined?{THT_CLOUD_TRIAL:process.env.THT_CLOUD_TRIAL}:{}),...(process.env.THT_SELF_EDITION!==undefined?{THT_SELF_EDITION:process.env.THT_SELF_EDITION}:{})});}
function load(){const key=configCacheKey();if(configCache&&configCache.key===key)return {...configCache.value};const value=loadFresh();configCache={key,value};return {...value};}
function save(j){configCache=null;if(routing.status().configured||j.LLM_ROUTING_ERROR){j={...j};delete j.LLM_ROUTING;delete j.LLM_ROUTING_ERROR;}let prev={};try{prev=JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){}if(process.env.THT_CLOUD_ACCOUNT_URL!==undefined){j={...j};if(Object.prototype.hasOwnProperty.call(prev,'CLOUD_ACCOUNT_URL'))j.CLOUD_ACCOUNT_URL=prev.CLOUD_ACCOUNT_URL;else delete j.CLOUD_ACCOUNT_URL;}if(process.env.THT_CLOUD_TRIAL!==undefined){j={...j};if(Object.prototype.hasOwnProperty.call(prev,'THT_CLOUD_TRIAL'))j.THT_CLOUD_TRIAL=prev.THT_CLOUD_TRIAL;else delete j.THT_CLOUD_TRIAL;}j=secrets.persist(j,dataDir,process.env,prev);require('./durable-json').write(file,j,{space:2});configCache=null;}
// 首次启动：如果安装包里带了 preset.json（Aaron 给家人预配好的凭据），就用它开箱即用。
// preset 只读一次，读完不删原文件（重装还能用），但凭据只会落进本机 settings.json（权限 600）。
function readPreset(){
  // Disposable UI previews must never import a family package's credentials.
  if(process.env.THT_PREVIEW_ISOLATED==='1')return {};
  for(const dir of [path.join(__dirname,'..'), __dirname]){
    const f=path.join(dir,'preset.json');
    try{ if(fs.existsSync(f)){ const j=JSON.parse(fs.readFileSync(f,'utf8')); const out={};
      for(const k of Object.keys(defaults)) if(typeof j[k]==='string'&&j[k]) out[k]=j[k];
      return out; } }catch(e){}
  }
  return {};
}
// 升级仅填空白，版本变化也不覆盖用户已有的模型、语音或 JEV 设置。
function presetPatch(cur,preset){
  const patch={};
  for(const [k,v] of Object.entries(preset)) if(k!=='PRESET_VERSION'&&!cur[k]) patch[k]=v;
  if(preset.PRESET_VERSION&&cur.PRESET_VERSION!==preset.PRESET_VERSION) patch.PRESET_VERSION=preset.PRESET_VERSION;
  return Object.keys(patch).length?patch:null;
}
// 注销本机数据后（PRESET_OPTOUT=1）不再从安装包预置里补回凭据。
function applyPreset(cur){return cur&&cur.PRESET_OPTOUT==='1'?null:presetPatch(cur,readPreset());}
if(!fs.existsSync(file)){
  const p=readPreset(); const ver=p.PRESET_VERSION||''; delete p.PRESET_VERSION;
  // Only a genuinely new installation opts into the hosted trial. A supplied
  // personal provider/preset or retained routing document keeps its own route.
  const personalPreset=['ASR_PROVIDER','LLM_PROVIDER','DEEPGRAM_API_KEY','VOLC_APP_KEY','VOLC_ACCESS_KEY','DEEPSEEK_API_KEY','FREE_AI_URL'].some(k=>!!p[k]);
  const freshTrial=process.env.THT_CLOUD_TRIAL===undefined&&!personalPreset&&!fs.existsSync(path.join(dataDir,'model-routing.json'))?{CLOUD_ACCOUNT_URL:'https://account-production-48d5.up.railway.app',THT_CLOUD_TRIAL:'1'}:{};
  save({...defaults,...freshTrial,...p,...(ver?{PRESET_VERSION:ver}:{}),RELAY_TOKEN:crypto.randomBytes(32).toString('hex')});
}else{
  try{
    const cur=JSON.parse(fs.readFileSync(file,'utf8'));
    const patch=applyPreset(cur);
    // Preserve the old implicit mode on upgrades; only a fresh install defaults to rapid.
    let migrated=false;
    for(const [key,value] of Object.entries({ACTIVE_INTELLIGENCE_MODE:'legacy',ACTIVE_INTELLIGENCE_FAST_MS:'7000',JEV_GATE:aliasJev(cur).JEV_GATE||'on',JEV_THRESHOLD:'0.5'})){
      if(!cur[key]){cur[key]=value;migrated=true;}
    }
    // Aaron 2026-11-20：所有用户默认用上 Jev 快速判断（自己的密钥或登录账号后由 Citeside 提供）。
    // 旧版迁移曾把空值写成 off，分不清是不是用户自己关的，这里只改一次；改过后用户再关不会被改回。
    if(cur.JEV_DEFAULT_REV!=='2026-11-20'){if(String(cur.JEV_GATE||'').toLowerCase()==='off')cur.JEV_GATE='on';cur.JEV_DEFAULT_REV='2026-11-20';migrated=true;}
    // 启动器开了钥匙串而还有密钥没复制过去：整份保存一次，persist 复制进钥匙串并回读校验；文件里的原值保留（10-26 版只复制不搬走）。
    if(!patch&&!migrated&&secrets.enabled(cur)&&secrets.pendingCopy(cur).length)migrated=true;   // 有没复制进钥匙串的密钥就补一次（原值留在文件里）
    if(patch||migrated)save({...secrets.hydrate(cur,dataDir),...patch});
  }catch(e){}
}
module.exports={dataDir,file,load,save,defaults,aliasJev,presetPatch,readPreset,routing};
