'use strict';
// 后处理 python 用 flock 独占 <key>.job.lock；这里非阻塞试锁，拿不到说明它还在跑。
// dir 必须是数据目录下的 state/meeting-pipeline（和 server.js 里 meetingPipeline 同一处）；10-23 前误用程序目录，永远判成没锁。
const fs = require('fs'), path = require('path');
function locked(dir, key) {
  const lock = path.join(dir, key + '.job.lock');
  if (!fs.existsSync(lock)) return false;
  try {
    const out = require('child_process').spawnSync('/usr/bin/python3', ['-c',
      'import fcntl,sys\nf=open(sys.argv[1],"a")\ntry:\n fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)\n print("free")\nexcept OSError:\n print("held")', lock],
      { encoding: 'utf8', timeout: 4000 });
    return String(out.stdout||'').trim() === 'held';
  } catch (e) { return false; }
}
module.exports = { locked };
