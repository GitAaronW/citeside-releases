'use strict';
// Recording silence defaults to ten minutes; explicit pauses reset the clock.
const minutes = n => n * 60000;
const positive = (name, fallback) => Number.isFinite(Number(process.env[name])) && Number(process.env[name]) > 0 ? Number(process.env[name]) : fallback;
const limits = () => ({ idleMs: positive('THT_IDLE_MS', minutes(10)), graceMs: process.env.THT_TEST ? positive('THT_IDLE_GRACE_MS', 0) : 0 });
// 宽限只在测试里非 0；为 0 时不能参与取小，否则生产会变成 20ms 一跳。
const tickMs = () => { const { idleMs, graceMs } = limits(); return Math.max(20, Math.min(60000, Math.floor((graceMs ? Math.min(idleMs, graceMs) : idleMs) / 4))); };

class IdleWatch {
  // seenRows：已经算过的转写条数。转写变多 = 有新动静（不用 lastFinalTs，它在开场 / 重启时被设成当下）。
  constructor({ activityTs = 0, promptAt = 0, seenRows = 0 } = {}) { this.activityTs = Number(activityTs) || 0; this.promptAt = Number(promptAt) || 0; this.seenRows = Number(seenRows) || 0; }
  // 用户点「继续」：算一次动静，收起提示。
  keep(now) { this.activityTs = Math.max(this.activityTs, now); this.promptAt = 0; }
  // 返回 'none' | 'prompt' | 'clear' | 'end'。rows = 当前转写条数，lastAudibleTs = 最后一次有电平的音频。
  step({ now, rows = 0, lastAudibleTs = 0, paused = false }) {
    const { idleMs, graceMs } = limits();
    if (paused) { const prompted = !!this.promptAt; this.keep(now); return prompted ? 'clear' : 'none'; }
    if (rows > this.seenRows) { this.seenRows = rows; this.activityTs = Math.max(this.activityTs, now); }
    this.activityTs = Math.max(this.activityTs, Number(lastAudibleTs) || 0);
    if (now - this.activityTs < idleMs) { if (this.promptAt) { this.promptAt = 0; return 'clear'; } return 'none'; }
    if (!graceMs) return 'end';
    if (!this.promptAt) { this.promptAt = now; return 'prompt'; }
    return now - this.promptAt >= graceMs ? 'end' : 'none';
  }
  snapshot() { return { activityTs: this.activityTs, promptAt: this.promptAt }; }
}
// 恢复时的起点：journal 里存过的最后动静；没存过（旧 journal）就用最后一条转写的时间，再没有就用开场时间。
function restoredActivity(recovered, startTs) {
  if (!recovered) return 0;
  const saved = Number(recovered.idle?.activityTs) || 0;
  const rows = Array.isArray(recovered.transcript) ? recovered.transcript : [];
  const last = rows.length ? (Number(startTs) || 0) + (Number(rows[rows.length - 1].at) || 0) * 1000 : 0;
  return Math.max(saved, last, Number(startTs) || 0);
}
module.exports = { IdleWatch, limits, tickMs, restoredActivity };
