'use strict';
// Reuse the existing minutes job; a research report is never meeting minutes.
async function read(pipeline, session, {now=Date.now,sleep=ms=>new Promise(resolve=>{const timer=setTimeout(resolve,ms);timer.unref?.();}),timeoutMs=110000,pollMs=250}={}) {
 const fail=code=>Object.assign(Error(session?.uiLang==='en'?'Meeting minutes are not ready. The original record is retained.':'会议总结尚未完成，原始记录已保留。'),{code});
 if(!session?.id||typeof pipeline?.list!=='function'||typeof pipeline?.result!=='function')throw fail('invalid_summary_source');
 const deadline=now()+Math.min(110000,Math.max(1,Number(timeoutMs)||110000));
 const interval=Math.min(1000,Math.max(250,Number(pollMs)||250));
 while(true){
  let job,result;
  try{
   job=pipeline.list().find(row=>row.sessionId===session.id);
   if(job)result=pipeline.result(session.id,job);
  }catch{throw fail('meeting_summary_unavailable');}
  const activeJob=['queued','running'].includes(job?.status);
  if((!activeJob&&job?.summaryWarning)||['failed','error'].includes(job?.status))throw fail('meeting_summary_unavailable');
  if(job?.summaryGenerated===true&&result?.id===session.id&&String(result.continuationEpoch||'')===String(session.continuationEpoch||'')&&typeof result.summary==='string'&&result.summary.trim())
   return {markdown:result.summary,source:'meeting-pipeline',items:[]};
  const remaining=deadline-now();
  if(remaining<=0)throw fail('meeting_summary_pending');
  await sleep(Math.min(interval,remaining));
 }
}
module.exports={read};
