'use strict';
// Node entry. The browser bundle injects the same file; the public package keeps web/live-card-format.js.
module.exports=require('../web/live-card-format.js');
