'use strict';
const fs=require('fs'),path=require('path'),notion=require('./tools/notion');
const queues=new Map(),TITLE='Citeside 会议文档',LEGACY_TITLES=['Seatnote 会议文档','听会台 会议文档'];
async function ensure(ctx){
 if(!ctx.dataDir)throw Error('无法记住文档保存位置');
 const file=path.join(ctx.dataDir,'state','notion-document-parent.json');
 if(queues.has(file))return queues.get(file);
 const work=(async()=>{
  let saved;try{saved=JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw Error('文档保存位置待核对');}
  if(saved?.id)return saved.id;
  const relay=notion.relayFor(ctx),hasRelay=!!(relay&&await relay.available());
  let transport=hasRelay?relay:null;
  if(!transport){
   const auth=await require('./notion-auth').resolve(ctx);
   if(!auth?.token)throw Error('未检测到 Notion 授权，请完成标准 OAuth 连接');
   transport={request:(method,endpoint,body)=>notion.api(ctx,method,endpoint,body)};
  }
  const candidates=new Map();
  for(const title of [TITLE,...LEGACY_TITLES]){
   const found=await transport.request('POST','search',{query:title,page_size:100});
   if(!found.ok||found.json.has_more)throw Error('文档保存位置待核对');
   for(const page of found.json.results)if([TITLE,...LEGACY_TITLES].includes(notion.titleOf(page)))candidates.set(page.id,page);
  }
  const matches=[TITLE,...LEGACY_TITLES].map(title=>[...candidates.values()].filter(page=>notion.titleOf(page)===title)).find(pages=>pages.length)||[];
  if(matches.length>1)throw Error('有多个同名文档保存位置，请先核对');
  const persist=value=>{fs.mkdirSync(path.dirname(file),{recursive:true});require('./durable-json').write(file,value);};
  if(matches.length){persist({id:matches[0].id});return matches[0].id;}
  if(!hasRelay){
   // Standard Notion OAuth bots can write only under user-shared pages (not workspace root).
   const anyPage=await transport.request('POST','search',{filter:{property:'object',value:'page'},page_size:20});
   const firstPage=anyPage.ok&&Array.isArray(anyPage.json?.results)?anyPage.json.results[0]:null;
   if(!firstPage?.id)throw Error('未找到已授权的 Notion 父页面，请在授权页勾选至少一个页面');
   persist({id:firstPage.id});return firstPage.id;
  }
  if(saved?.pending)throw Error('文档尚未同步，请稍后重试');
  persist({pending:true});
  const created=await transport.request('POST','pages',{properties:{title:{type:'title',title:[{type:'text',text:{content:TITLE}}]}},children:[]});
  if(!created.ok){if(!created.uncertain)fs.unlinkSync(file);throw Error('文档保存位置待核对');}
  if(!created.json?.id)throw Error('文档尚未同步，请稍后重试');
  persist({id:created.json.id});return created.json.id;
 })();queues.set(file,work);try{return await work;}finally{queues.delete(file);}
}
// Serialize the durable library journal across all documents in this data directory.
// A persisted intent survives restart; uncertain creates are reconciled, never replayed.
async function library(ctx, provider, run) {
 if(!ctx.dataDir)throw Error('文档尚未同步，请稍后重试');
 const file=path.join(ctx.dataDir,'state','cloud-document-library.json');
 const prior=queues.get(file)||Promise.resolve();
 const work=prior.catch(()=>{}).then(async()=>{
  let state;try{state=JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;state={providers:{}};}
  const index=state.providers[provider.name]||(state.providers[provider.name]={pages:{}});
  const save=()=>{fs.mkdirSync(path.dirname(file),{recursive:true});require('./durable-json').write(file,state);};
  const root=await provider.root();
  if(index.root&&index.root!==root)throw Error('文档保存位置有变化，请先核对');
  index.root=root;save();
  async function ensurePage(key,parentId,title,blocks=[]){
   let row=index.pages[key];
   if(row?.id){if(row.parentId!==parentId)throw Error('文档保存位置有变化，请先核对');return row;}
   const pages=await provider.listPages(parentId);
   if(row?.pending){
    const candidates=pages.filter(p=>!(row.before||[]).includes(p.id)&&p.title===row.title);
    // Compare the initial body before claiming a page whose create response was lost.
    const matches=[];
    for(const p of candidates){const actual=await provider.readBlocks(p.id);if(actual.length===row.blocks.length&&actual.every((b,i)=>b.text===row.blocks[i].text))matches.push(p);}
    if(matches.length!==1)throw Error('文档尚未同步，请稍后重试');
    row={...row,...matches[0],pending:false};index.pages[key]=row;save();return row;
   }
   row={parentId,title,blocks,before:pages.map(p=>p.id),pending:true};index.pages[key]=row;save();
   let page;
   try{page=await provider.createPage(parentId,title,blocks);}
   catch(e){if(!e.uncertain){delete index.pages[key];save();}throw e;}
   row={...row,...page,pending:false};index.pages[key]=row;save();return row;
  }
  return run({root,ensurePage,index,save});
 });
 queues.set(file,work);try{return await work;}finally{if(queues.get(file)===work)queues.delete(file);}
}
async function readLibrary(ctx,provider){
 let state;try{state=JSON.parse(fs.readFileSync(path.join(ctx.dataDir,'state','cloud-document-library.json'),'utf8'));}catch(e){if(e.code==='ENOENT')return {ok:true,markdown:'',coverage:{complete:true},url:''};throw e;}
 const root=state.providers[provider.name]?.root;
 if(!root)return {ok:true,markdown:'',coverage:{complete:true},url:''};
 return {...await provider.readLibrary(root),url:provider.url(root)};
}
module.exports={ensure,library,readLibrary};
