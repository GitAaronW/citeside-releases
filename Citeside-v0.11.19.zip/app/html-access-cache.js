'use strict';
// Short-lived cache for local HTML page switches (index <-> lite <-> work) so window
// transitions never stall on upstream /v1/me or bounce on transient Railway blips.
// Strict entitlement checks for LLM, ASR, recording, and research remain uncached.
const HTML_ACCESS_FRESH_MS = 60_000;
const HTML_ACCESS_OFFLINE_GRACE_MS = 300_000;

function create({ freshMs = HTML_ACCESS_FRESH_MS, offlineGraceMs = HTML_ACCESS_OFFLINE_GRACE_MS, now = () => Date.now() } = {}) {
  let cache = null;
  function clear() { cache = null; }
  async function check({ dataDir, env = {}, requireProductAccess, loadSession } = {}) {
    const currentNow = now();
    const session = typeof loadSession === 'function' ? loadSession(dataDir, env, currentNow) : null;
    if (!session || !session.url || !session.token) {
      cache = null;
      return requireProductAccess({ dataDir, env, resource: 'any' });
    }
    const key = session.url + '|' + session.token;
    if (cache && cache.ok === true && cache.key === key && currentNow - cache.verifiedAt < freshMs) {
      return { ok: true, cached: true };
    }
    const access = await requireProductAccess({ dataDir, env, resource: 'any' });
    if (access && access.ok === true) {
      cache = { key, verifiedAt: now(), ok: true };
      return access;
    }
    if (access && access.offline === true && cache && cache.ok === true && cache.key === key && currentNow - cache.verifiedAt < offlineGraceMs) {
      return { ok: true, offlineGrace: true };
    }
    cache = null;
    return access || { ok: false, code: 'account_login_required' };
  }
  check.clear = clear;
  return check;
}

module.exports = { create, HTML_ACCESS_FRESH_MS, HTML_ACCESS_OFFLINE_GRACE_MS };
