'use strict';
// CONSENT-RECORDING / AI-DEFAULT-DEEPSEEK：开始录音前，用户要知道声音和文字分别发给谁，并确认已告知参会人。
// 接收方一变（换转写、换模型）就重新问一次；选「只在本机」则本机转写 + 不调任何云端 AI，录音和文字照常保存。
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const VERSION=1;
const file=dataDir=>path.join(dataDir,'state','recording-consent.json');

function hostOf(url){try{return new URL(url).host;}catch{return '';}}
function deepgramHost(env){
 const connection=require('./deepgram-asr').resolveDeepgramConfig({model:env.DEEPGRAM_MODEL,endpoint:env.DEEPGRAM_ENDPOINT});
 return connection.ok?hostOf(connection.endpoint):'';
}
function jevHost(env){try{return hostOf(require('./jev-gate').connectionOf(env).endpoint);}catch{return '';}}
function receivers(env){
 // 没选过转写又没有云端凭据时，点开始会直接切本机转写（23-control.js），这里按本机算，确认后不会因切换再问一次
 const local=env.ASR_PROVIDER==='mac'||(!env.ASR_PROVIDER&&!(env.VOLC_APP_KEY&&env.VOLC_ACCESS_KEY));
 const asr=local?{kind:'local',label:'本机转写 / On-device',host:''}
  :env.ASR_PROVIDER==='deepgram'?{kind:'cloud',label:'Deepgram',host:deepgramHost(env)}
  :{kind:'cloud',label:'火山引擎 / Volcano Engine',host:hostOf(env.VOLC_WS_URL||'wss://openspeech.bytedance.com')};
 let ai={kind:'none',label:'不调用 AI / No AI',host:''};
 if(env.CLOUD_AI!=='off'){
  const p=require('./llm').chainOf(env)[0];
  if(p?.type==='openai')ai={kind:'cloud',label:p.label,host:hostOf(p.baseUrl)};
  else if(p?.type==='cli')ai={kind:'cloud',label:p.label+'（本机命令行，用你自己的账号）',host:''};   // 牌子名已在 label 里，这里不认厂商
 }
 const jev=env.CLOUD_AI!=='off'&&env.JEV_GATE==='on'&&!!env.JEV_API_KEY;
 return {audio:asr,text:ai,jev:jev?{kind:'cloud',label:'JEV',host:jevHost(env)}:null,localOnly:asr.kind==='local'&&ai.kind==='none'&&!jev};
}
function fingerprint(r){return crypto.createHash('sha256').update(JSON.stringify([VERSION,r.audio.label,r.audio.host,r.text.label,r.text.host,r.jev?.host||''])).digest('hex').slice(0,16);}
function read(dataDir){try{return JSON.parse(fs.readFileSync(file(dataDir),'utf8'));}catch{return null;}}
// v5（2026-10-25 Aaron「开始了就开始了，跟 Granola 一样」）：开会前不再弹确认框。
// 路由与审计不变：新开一场时把这一刻的接收方（声音 / 文字 / 逐句筛选各发给谁）记进 recording-consent.json，
// 接收方变了就把旧的挪进 history（留时间），how 标明是自动记录还是人点过确认。required 恒为 false，保留字段给旧客户端。
function status(dataDir,env){
 const r=receivers(env),fp=fingerprint(r),saved=read(dataDir),known=!!(saved&&saved.version===VERSION);
 return {version:VERSION,fingerprint:fp,receivers:r,required:false,recorded:known,changed:!known||saved.fingerprint!==fp,acceptedAt:known?saved.acceptedAt:''};
}
function accept(dataDir,env,fp,how='confirmed'){
 const s=status(dataDir,env),saved=read(dataDir);
 if(fp!==s.fingerprint)throw Object.assign(Error('接收方已变化，请重新确认 / Receivers changed, confirm again'),{status:409});
 fs.mkdirSync(path.dirname(file(dataDir)),{recursive:true});
 const now=new Date().toISOString();
 const history=[...(Array.isArray(saved?.history)?saved.history:[]),...(saved?.fingerprint&&saved.fingerprint!==fp?[{fingerprint:saved.fingerprint,receivers:saved.receivers,acceptedAt:saved.acceptedAt,replacedAt:now}]:[])].slice(-50);
 require('./durable-json').write(file(dataDir),{version:VERSION,fingerprint:fp,acceptedAt:saved?.version===VERSION&&how==='auto'?saved.acceptedAt:now,participantsInformed:how!=='auto'||!!saved?.participantsInformed,how,receivers:s.receivers,...(how==='auto'?{receiversRecordedAt:now}:{}),history},{space:2});
 return status(dataDir,env);
}
// 「只在本机」：本机转写、不调云端 AI 与 JEV。返回要写回 settings 的字段。
function localOnlyPatch(){return {ASR_PROVIDER:'mac',CLOUD_AI:'off',JEV_GATE:'off'};}
const REQUIRED_MESSAGE='开始录音前请先确认录音告知（打开Citeside主窗口点「开始」即可看到） / Confirm the recording notice in the main window before starting';
function assertAccepted(dataDir,env){const s=status(dataDir,env);if(s.changed)accept(dataDir,env,s.fingerprint,'auto');}
module.exports={VERSION,receivers,fingerprint,status,accept,localOnlyPatch,assertAccepted,REQUIRED_MESSAGE};
