'use strict';

// Pending-ASR storage foundation only.
// Encrypts caller-supplied PCM that is not yet durably transcribed.
// Does not choose capture policy, does not play or export audio, and does not
// treat a provider or native ACK as a durable transcript receipt.
// Expiry is the original capturedAt plus 24h, including a meeting that is still open.
// Restart and mtime never move capturedAt. A sealed record is published by hard link so an
// existing name is never replaced. Sweep stays inside this namespace: authenticated records
// go at capturedAt+24h against the newest observed clock in pac1-clock, so a later rollback
// cannot revive a moment this process already saw. Owned names that fail authentication go
// immediately because their age is unknowable. A pac1-tmp file is in flight only while
// 0 <= observedNow - mtime < TEMP_ORPHAN_MS; a future or non-finite mtime is discarded, and an
// extra hard link is discarded. Symlinks, pac1-clock, and unrelated names are left alone.
// mtime is not a sealed record's lifetime. Time that passes while the process is down, during
// a rollback that nobody observed, is not visible here.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAX_AGE_MS = 24 * 60 * 60 * 1000;
const MAX_PCM_BYTES = 32 * 1024 * 1024;
const MAX_AAD_BYTES = 2048;
const MAX_FILE_BYTES = 8 + 12 + 4 + MAX_AAD_BYTES + 4 + MAX_PCM_BYTES + 16;
const MAGIC = Buffer.from('THTPAC01');
const ID_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const RECORD_RE = /^pac1-[0-9a-f]{64}\.bin$/;
const TEMP_RE = /^pac1-tmp-[0-9a-f]{32}\.tmp$/;
const TEMP_ORPHAN_MS = 60 * 60 * 1000;
const CLOCK_MAX = 8_640_000_000_000_000;
const CLOCK_FILE = 'pac1-clock';
const CLOCK_LOCK = 'pac1-clock.lock';

class PendingAudioCacheError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'PendingAudioCacheError';
    this.code = code;
  }
}

function fail(code, message) {
  throw new PendingAudioCacheError(code, message);
}

function sleepMs(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {}
}

function pidAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 1) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return !!(e && e.code === 'EPERM');
  }
}

function wipe(buf) {
  if (Buffer.isBuffer(buf)) buf.fill(0);
}

function assertClock(value, code, message) {
  if (!Number.isSafeInteger(value) || value < 0 || value > CLOCK_MAX) fail(code, message);
}

function assertId(value, field) {
  if (typeof value !== 'string' || !ID_RE.test(value)) {
    fail('invalid_id', field + ' 无效：只能用字母、数字、点、下划线和短横线，不能是路径');
  }
}

function canonicalAad(meta) {
  return Buffer.from(
    '{"v":' + (meta.byteStart === undefined ? 1 : 2) + ',"id":' + JSON.stringify(meta.id) +
    ',"sessionId":' + JSON.stringify(meta.sessionId) +
    ',"capturedAt":' + meta.capturedAt +
    ',"bytes":' + meta.bytes + (meta.byteStart === undefined ? '' : ',"byteStart":' + meta.byteStart) + '}',
    'utf8'
  );
}

function recordName(id) {
  return 'pac1-' + crypto.createHash('sha256').update(id, 'utf8').digest('hex') + '.bin';
}

function metadata(rec) {
  return { id: rec.id, sessionId: rec.sessionId, capturedAt: rec.capturedAt, bytes: rec.pcm.length,
    ...(rec.byteStart === undefined ? {} : { byteStart: rec.byteStart }) };
}

function create(options = {}) {
  if (!options || typeof options !== 'object' || Array.isArray(options)) fail('invalid_options', '需要 { dir, key }');
  const key = options.key;
  if (!Buffer.isBuffer(key) || key.length !== 32) {
    fail('invalid_key', '密钥必须是调用方传入的 32 字节 Buffer，模块不生成也不保存密钥');
  }
  const nowFn = options.now === undefined ? Date.now : options.now;
  if (typeof nowFn !== 'function') fail('invalid_now', 'now 必须是返回毫秒时间戳的函数');
  const keyCopy = Buffer.alloc(32);
  key.copy(keyCopy);
  const syncWrites = options.sync === true;
  const dir = prepareDir(options.dir);
  let memoryHigh = 0;
  let resolvedDir = '';

  function clock() {
    let value;
    try { value = nowFn(); } catch (e) { fail('invalid_now', '无法读取当前时间'); }
    assertClock(value, 'invalid_now', '当前时间必须是 0 到时钟上限之间的整数毫秒');
    return observe(value);
  }

  function readDiskHigh() {
    const file = path.join(dir, CLOCK_FILE);
    let st;
    try { st = fs.lstatSync(file); } catch (e) {
      if (e.code === 'ENOENT') return 0;
      throw e;
    }
    if (st.isSymbolicLink() || !st.isFile() || st.size <= 0 || st.size > 32) return 0;
    let fd;
    try { fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW); } catch (e) { return 0; }
    try {
      const buf = Buffer.alloc(st.size);
      const n = fs.readSync(fd, buf, 0, st.size, 0);
      const text = buf.subarray(0, n).toString('utf8').trim();
      if (!/^[0-9]+$/.test(text)) return 0;
      const parsed = Number(text);
      if (!Number.isSafeInteger(parsed) || parsed < 0 || parsed > CLOCK_MAX) return 0;
      return parsed;
    } finally { fs.closeSync(fd); }
  }

  function writeClock(value) {
    const dest = path.join(dir, CLOCK_FILE);
    const tmp = path.join(dir, 'pac1-clock.writing');
    const flags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_TRUNC | fs.constants.O_NOFOLLOW;
    const fd = fs.openSync(tmp, flags, 0o600);
    try {
      const text = Buffer.from(String(value), 'utf8');
      writeAll(fd, text);
      fs.fchmodSync(fd, 0o600);
      if (syncWrites) fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, dest);
    if (syncWrites) syncDir();
  }

  function lockOwnerAlive(lockPath) {
    let text = '';
    try {
      const fd = fs.openSync(lockPath, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      try {
        const buf = Buffer.alloc(64);
        const n = fs.readSync(fd, buf, 0, buf.length, 0);
        text = buf.subarray(0, n).toString('utf8').trim();
      } finally { fs.closeSync(fd); }
    } catch (e) {
      if (e.code === 'ENOENT') return false;
      return true;
    }
    if (!text) return true;
    return pidAlive(Number(text));
  }

  function withClockLock(fn) {
    const lockPath = path.join(dir, CLOCK_LOCK);
    const flags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_NOFOLLOW;
    for (let attempt = 0; attempt < 30; attempt++) {
      let fd;
      try { fd = fs.openSync(lockPath, flags, 0o600); } catch (e) {
        if (e.code !== 'EEXIST') return false;
        if (!lockOwnerAlive(lockPath)) {
          try { fs.unlinkSync(lockPath); } catch (err) { if (err.code !== 'ENOENT') return false; }
          continue;
        }
        sleepMs(10);
        continue;
      }
      try {
        fs.writeSync(fd, String(process.pid));
        try { if (syncWrites) fs.fsyncSync(fd); } catch (e) {}
      } finally { fs.closeSync(fd); }
      try { return fn(); } finally {
        try { fs.unlinkSync(lockPath); } catch (e) {}
      }
    }
    if (lockAbandoned(lockPath)) {
      try { fs.unlinkSync(lockPath); } catch (e) { return false; }
      let fd;
      try { fd = fs.openSync(lockPath, flags, 0o600); } catch (e) { return false; }
      try {
        fs.writeSync(fd, String(process.pid));
        try { if (syncWrites) fs.fsyncSync(fd); } catch (e) {}
      } finally { fs.closeSync(fd); }
      try { return fn(); } finally {
        try { fs.unlinkSync(lockPath); } catch (e) {}
      }
    }
    return false;
  }

  function lockAbandoned(lockPath) {
    let text = '';
    try {
      const fd = fs.openSync(lockPath, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      try {
        const buf = Buffer.alloc(64);
        const n = fs.readSync(fd, buf, 0, buf.length, 0);
        text = buf.subarray(0, n).toString('utf8').trim();
      } finally { fs.closeSync(fd); }
    } catch (e) {
      return false;
    }
    if (!text) return true;
    return !pidAlive(Number(text));
  }

  function observe(raw) {
    if (raw > memoryHigh) memoryHigh = raw;
    const disk = readDiskHigh();
    if (disk > memoryHigh) memoryHigh = disk;
    if (memoryHigh > disk) {
      const wrote = withClockLock(() => {
        const again = readDiskHigh();
        const next = Math.max(memoryHigh, again, raw);
        memoryHigh = next;
        if (next > again) writeClock(next);
        return next;
      });
      if (wrote === false) {
        const latest = readDiskHigh();
        if (latest > memoryHigh) memoryHigh = latest;
      } else if (typeof wrote === 'number' && wrote > memoryHigh) memoryHigh = wrote;
    }
    return memoryHigh;
  }

  function baseDir() {
    const st = fs.lstatSync(dir);
    if (st.isSymbolicLink()) fail('symlink_rejected', '缓存目录不能是符号链接');
    if (!st.isDirectory()) fail('invalid_dir', '缓存路径不是目录');
    // realpath of this directory is stable while lstat still proves it is not a symlink.
    if (!resolvedDir) resolvedDir = fs.realpathSync(dir);
    return resolvedDir;
  }

  function assertInside(file) {
    const base = baseDir();
    const parent = path.dirname(path.resolve(file));
    // Children are path.join(dir, name). Skip the extra realpath when the parent is dir itself.
    if (parent !== dir && fs.realpathSync(parent) !== base) fail('path_rejected', '路径越出缓存目录');
    const name = path.basename(file);
    if (name !== path.basename(name) || name === '.' || name === '..') fail('path_rejected', '文件名无效');
  }

  function syncDir() {
    if (!syncWrites) return;
    const fd = fs.openSync(dir, 'r');
    try {
      try { fs.fsyncSync(fd); } catch (e) {
        if (e.code !== 'EINVAL' && e.code !== 'ENOTSUP' && e.code !== 'EPERM') throw e;
      }
    } finally { fs.closeSync(fd); }
  }

  function location(id) {
    assertId(id, 'id');
    const name = recordName(id);
    const file = path.join(dir, name);
    assertInside(file);
    return file;
  }

  function lstatOrNull(file) {
    try { return fs.lstatSync(file); } catch (e) {
      if (e.code === 'ENOENT') return null;
      throw e;
    }
  }

  function readExact(file) {
    const st = fs.lstatSync(file);
    if (st.isSymbolicLink()) fail('symlink_rejected', '缓存记录不能是符号链接');
    if (!st.isFile()) fail('not_cache_record', '缓存记录不是普通文件');
    if (st.size < MAGIC.length + 12 + 4 + 4 + 16 || st.size > MAX_FILE_BYTES) {
      fail('not_cache_record', '不是本缓存的加密记录，拒绝按明文读取');
    }
    const fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
    try {
      const buf = Buffer.alloc(st.size);
      let off = 0;
      while (off < buf.length) {
        const n = fs.readSync(fd, buf, off, buf.length - off, off);
        if (n === 0) fail('not_cache_record', '缓存记录读取不完整');
        off += n;
      }
      return buf;
    } finally { fs.closeSync(fd); }
  }

  function openRecord(file) {
    const buf = readExact(file);
    try {
      if (!buf.subarray(0, MAGIC.length).equals(MAGIC)) fail('not_cache_record', '不是本缓存的加密记录，拒绝按明文读取');
      let off = MAGIC.length;
      const nonce = buf.subarray(off, off + 12); off += 12;
      const aadLen = buf.readUInt32BE(off); off += 4;
      if (aadLen === 0 || aadLen > MAX_AAD_BYTES || off + aadLen + 4 + 16 > buf.length) {
        fail('not_cache_record', '缓存记录结构无效');
      }
      const aad = buf.subarray(off, off + aadLen); off += aadLen;
      const ctLen = buf.readUInt32BE(off); off += 4;
      if (ctLen <= 0 || ctLen > MAX_PCM_BYTES || off + ctLen + 16 !== buf.length) {
        fail('not_cache_record', '缓存记录结构无效');
      }
      const ct = buf.subarray(off, off + ctLen);
      const tag = buf.subarray(off + ctLen);
      let pcm;
      try {
        const decipher = crypto.createDecipheriv('aes-256-gcm', keyCopy, nonce, { authTagLength: 16 });
        decipher.setAAD(aad);
        decipher.setAuthTag(tag);
        pcm = Buffer.concat([decipher.update(ct), decipher.final()]);
      } catch (e) {
        if (e instanceof PendingAudioCacheError) throw e;
        fail('decrypt_failed', '无法校验这条缓存，拒绝当作明文读取');
      }
      let parsed;
      try { parsed = JSON.parse(aad.toString('utf8')); } catch (e) {
        wipe(pcm);
        fail('decrypt_failed', '无法校验这条缓存，拒绝当作明文读取');
      }
      const again = canonicalAad({
        id: parsed && parsed.id,
        sessionId: parsed && parsed.sessionId,
        capturedAt: parsed && parsed.capturedAt,
        bytes: parsed && parsed.bytes,
        byteStart: parsed && parsed.byteStart,
      });
      if (again.length !== aad.length || !crypto.timingSafeEqual(again, aad)) {
        wipe(pcm);
        fail('decrypt_failed', '无法校验这条缓存，拒绝当作明文读取');
      }
      if (parsed.v !== (parsed.byteStart === undefined ? 1 : 2) ||
          (parsed.byteStart !== undefined && (!Number.isSafeInteger(parsed.byteStart) || parsed.byteStart < 0 || parsed.byteStart % 2 !== 0 || !Number.isSafeInteger(parsed.byteStart + pcm.length))) ||
          !Number.isSafeInteger(parsed.capturedAt) || parsed.bytes !== pcm.length || pcm.length % 2 !== 0) {
        wipe(pcm);
        fail('decrypt_failed', '无法校验这条缓存，拒绝当作明文读取');
      }
      try {
        assertId(parsed.id, 'id');
        assertId(parsed.sessionId, 'sessionId');
      } catch (e) {
        wipe(pcm);
        throw e;
      }
      if (path.basename(file) !== recordName(parsed.id)) {
        wipe(pcm);
        fail('not_cache_record', '记录文件名与身份不一致');
      }
      return { id: parsed.id, sessionId: parsed.sessionId, capturedAt: parsed.capturedAt, pcm,
        ...(parsed.byteStart === undefined ? {} : { byteStart: parsed.byteStart }) };
    } finally { wipe(buf); }
  }

  function expired(capturedAt, now) {
    return now - capturedAt >= MAX_AGE_MS;
  }

  function loadOptional(file) {
    if (!lstatOrNull(file)) return null;
    return openRecord(file);
  }

  function validateNew(input, now) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) fail('invalid_id', '需要 id、sessionId、capturedAt 和 pcm');
    assertId(input.id, 'id');
    assertId(input.sessionId, 'sessionId');
    assertClock(input.capturedAt, 'invalid_captured_at', 'capturedAt 必须是原始采集时间的整数毫秒');
    if (input.capturedAt > now) fail('capture_in_future', 'capturedAt 晚于当前时间，拒绝写入');
    if (expired(input.capturedAt, now)) fail('capture_expired', '已经超过原始采集时间 24 小时，拒绝写入，重试不会延长');
    const pcm = input.pcm;
    if (!Buffer.isBuffer(pcm) || pcm.length === 0 || pcm.length % 2 !== 0) {
      fail('invalid_pcm', 'PCM 必须是非空、偶数长度的 Buffer');
    }
    if (input.byteStart !== undefined && (!Number.isSafeInteger(input.byteStart) || input.byteStart < 0 || input.byteStart % 2 !== 0 || !Number.isSafeInteger(input.byteStart + pcm.length))) {
      fail('invalid_capture_start', 'byteStart 必须是安全的非负偶数字节位置');
    }
    if (pcm.length > MAX_PCM_BYTES) fail('invalid_pcm', 'PCM 超过单条上限 ' + MAX_PCM_BYTES + ' 字节');
    return pcm;
  }

  function seal(meta, pcm) {
    const aad = canonicalAad(meta);
    if (aad.length > MAX_AAD_BYTES) fail('invalid_id', '身份元数据过长');
    const nonce = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', keyCopy, nonce, { authTagLength: 16 });
    cipher.setAAD(aad);
    const ct = Buffer.concat([cipher.update(pcm), cipher.final()]);
    if (pcm.length >= 16 && ct.includes(pcm)) {
      wipe(ct);
      fail('plaintext_leak', '加密结果异常，已拒绝写入');
    }
    const tag = cipher.getAuthTag();
    const aadLen = Buffer.alloc(4); aadLen.writeUInt32BE(aad.length);
    const ctLen = Buffer.alloc(4); ctLen.writeUInt32BE(ct.length);
    const payload = Buffer.concat([MAGIC, nonce, aadLen, aad, ctLen, ct, tag]);
    wipe(ct);
    return payload;
  }

  function writeAll(fd, payload) {
    let off = 0;
    while (off < payload.length) {
      const n = fs.writeSync(fd, payload, off, payload.length - off, off);
      if (n <= 0) fail('write_failed', '写入缓存记录不完整');
      off += n;
    }
  }

  function publishNew(dest, payload) {
    const tmp = path.join(dir, 'pac1-tmp-' + crypto.randomBytes(16).toString('hex') + '.tmp');
    assertInside(tmp);
    assertInside(dest);
    const flags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_NOFOLLOW;
    let fd;
    try { fd = fs.openSync(tmp, flags, 0o600); } catch (e) { fail('write_failed', '无法独占创建临时文件'); }
    let linked = false;
    try {
      try {
        writeAll(fd, payload);
        fs.fchmodSync(fd, 0o600);
        if (syncWrites) fs.fsyncSync(fd);
      } finally { fs.closeSync(fd); }
      try {
        fs.linkSync(tmp, dest);
        linked = true;
      } catch (e) {
        if (e.code !== 'EEXIST') fail('write_failed', '无法原子发布缓存记录');
        return false;
      }
      if (syncWrites) {
        const fd2 = fs.openSync(dest, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
        try { fs.fsyncSync(fd2); } finally { fs.closeSync(fd2); }
        syncDir();
      }
      return true;
    } finally {
      wipe(payload);
      try { fs.unlinkSync(tmp); } catch (e) {
        if (e.code !== 'ENOENT' && !linked) throw e;
      }
    }
  }

  function adopt(file, input, pcm, now) {
    const st = lstatOrNull(file);
    if (!st) return null;
    if (st.isSymbolicLink()) fail('symlink_rejected', '目标位置是符号链接，拒绝替换');
    if (!st.isFile()) fail('refusing_overwrite', '目标位置不是本缓存记录，拒绝替换');
    let existing;
    try { existing = openRecord(file); } catch (e) {
      if (e instanceof PendingAudioCacheError) fail('refusing_overwrite', '同 ID 已有无法校验的文件，拒绝覆盖');
      throw e;
    }
    try {
      if (expired(existing.capturedAt, now)) fail('capture_expired', '这条音频已超过原始采集时间 24 小时，重试不会延长');
      // A legacy retry may supply a newly known range, but must not rewrite or
      // claim that range was authenticated in the old record.
      const sameMeta = existing.sessionId === input.sessionId && existing.capturedAt === input.capturedAt &&
        (existing.byteStart === undefined || existing.byteStart === input.byteStart);
      const samePcm = existing.pcm.length === pcm.length && crypto.timingSafeEqual(existing.pcm, pcm);
      if (sameMeta && samePcm) return { ...metadata(existing), idempotent: true };
      fail('id_conflict', '同一 ID 的音频或采集元数据与已存记录不一致');
    } finally { wipe(existing.pcm); }
  }

  function put(input) {
    const now = clock();
    const pcm = validateNew(input, now);
    const file = location(input.id);
    const published = () => {
      const payload = seal({ id: input.id, sessionId: input.sessionId, capturedAt: input.capturedAt, bytes: pcm.length, byteStart: input.byteStart }, pcm);
      return publishNew(file, payload);
    };
    const fresh = { ...metadata({ ...input, pcm }), idempotent: false };
    if (!lstatOrNull(file) && published()) return fresh;
    const adopted = adopt(file, input, pcm, now);
    if (adopted) return adopted;
    if (published()) return fresh;
    const again = adopt(file, input, pcm, now);
    if (again) return again;
    fail('write_failed', '记录在发布时消失，请重试');
  }

  function list(sessionId) {
    assertId(sessionId, 'sessionId');
    const now = clock();
    const names = fs.readdirSync(dir);
    const items = [];
    for (const name of names) {
      if (!RECORD_RE.test(name)) continue;
      const file = path.join(dir, name);
      assertInside(file);
      const st = lstatOrNull(file);
      if (!st || st.isSymbolicLink() || !st.isFile()) continue;
      let rec;
      try { rec = openRecord(file); } catch (e) {
        if (e instanceof PendingAudioCacheError) continue;
        throw e;
      }
      try {
        if (rec.sessionId !== sessionId || expired(rec.capturedAt, now)) continue;
        items.push(metadata(rec));
      } finally { wipe(rec.pcm); }
    }
    // Legacy records have no recoverable byte position. Keep their deterministic old
    // order before new ranged captures; never infer a position from a hash or mtime.
    items.sort((a, b) => {
      const rangedA = a.byteStart !== undefined, rangedB = b.byteStart !== undefined;
      if (rangedA !== rangedB) return rangedA ? 1 : -1;
      return (rangedA ? a.byteStart - b.byteStart : 0) || a.capturedAt - b.capturedAt || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    });
    return items;
  }

  function read(id) {
    const file = location(id);
    if (!lstatOrNull(file)) fail('not_found', '没有这条待转写音频');
    const rec = openRecord(file);
    try {
      if (rec.id !== id) fail('not_cache_record', '记录身份与请求不一致，拒绝读取');
      if (expired(rec.capturedAt, clock())) fail('capture_expired', '已超过原始采集时间 24 小时，不能再读取');
      return Buffer.from(rec.pcm);
    } finally { wipe(rec.pcm); }
  }

  function removeConfirmed(id, receipt) {
    if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt) || receipt.durableTranscript !== true) {
      fail('durable_transcript_required', '删除需要 { durableTranscript: true }；识别服务或本机 ACK 不是成稿回执');
    }
    const file = location(id);
    const st = lstatOrNull(file);
    if (!st) fail('not_found', '没有这条待转写音频');
    if (st.isSymbolicLink()) fail('symlink_rejected', '缓存记录不能是符号链接，拒绝删除');
    const rec = openRecord(file);
    try {
      if (rec.id !== id) fail('not_cache_record', '记录身份与请求不一致，拒绝删除');
    } finally { wipe(rec.pcm); }
    const again = fs.lstatSync(file);
    if (again.isSymbolicLink() || !again.isFile()) fail('symlink_rejected', '缓存记录不能是符号链接，拒绝删除');
    fs.unlinkSync(file);
    syncDir();
    return { id, removed: true };
  }

  function unlinkRegular(file) {
    let st;
    try { st = fs.lstatSync(file); } catch (e) {
      if (e.code === 'ENOENT') return false;
      throw e;
    }
    if (st.isSymbolicLink() || !st.isFile()) return false;
    try { fs.unlinkSync(file); return true; } catch (e) {
      if (e.code === 'ENOENT') return false;
      throw e;
    }
  }

  function sweep() {
    const now = clock();
    const removed = [];
    const discarded = [];
    const skipped = [];
    let changed = false;
    for (const name of fs.readdirSync(dir)) {
      const owned = RECORD_RE.test(name);
      const temp = TEMP_RE.test(name);
      if (!owned && !temp) continue;
      const file = path.join(dir, name);
      const st = lstatOrNull(file);
      if (!st || st.isSymbolicLink() || !st.isFile()) {
        skipped.push({ file: name, code: st && st.isSymbolicLink() ? 'symlink_rejected' : 'not_regular' });
        continue;
      }
      if (temp) {
        const alias = st.nlink > 1;
        if (!alias) {
          const age = now - st.mtimeMs;
          if (!Number.isFinite(st.mtimeMs) || !Number.isFinite(age) || age < 0) {
            if (unlinkRegular(file)) {
              discarded.push({ file: name, reason: 'future_mtime' });
              changed = true;
            }
            continue;
          }
          if (age < TEMP_ORPHAN_MS) {
            skipped.push({ file: name, code: 'in_flight_temp' });
            continue;
          }
        }
        if (unlinkRegular(file)) {
          discarded.push({ file: name, reason: alias ? 'temp_alias' : 'orphan_temp' });
          changed = true;
        }
        continue;
      }
      let rec;
      try { rec = openRecord(file); } catch (e) {
        if (!(e instanceof PendingAudioCacheError)) throw e;
        if (unlinkRegular(file)) {
          discarded.push({ file: name, reason: 'unknowable_age', code: e.code });
          changed = true;
        }
        continue;
      }
      const meta = metadata(rec);
      const stale = expired(rec.capturedAt, now);
      wipe(rec.pcm);
      if (!stale) continue;
      if (unlinkRegular(file)) {
        removed.push({ ...meta, reason: 'capture_expired' });
        changed = true;
      }
    }
    if (changed) syncDir();
    removed.sort((a, b) => a.capturedAt - b.capturedAt || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
    return { removed, discarded, skipped };
  }

  return { put, list, read, removeConfirmed, sweep };
}

function prepareDir(dir) {
  if (typeof dir !== 'string' || dir.length === 0 || dir.includes('\0')) fail('invalid_dir', '需要专用缓存目录路径');
  const resolved = path.resolve(dir);
  let st = lstatQuiet(resolved);
  if (st && st.isSymbolicLink()) fail('symlink_rejected', '缓存目录不能是符号链接');
  if (!st) {
    const parent = path.dirname(resolved);
    const parentStat = lstatQuiet(parent);
    if (!parentStat || parentStat.isSymbolicLink() || !parentStat.isDirectory()) fail('invalid_dir', '缓存目录的上级不存在或不是目录');
    try { fs.mkdirSync(resolved, { mode: 0o700 }); } catch (e) {
      if (e.code !== 'EEXIST') fail('invalid_dir', '无法创建缓存目录');
    }
    st = fs.lstatSync(resolved);
  }
  if (st.isSymbolicLink()) fail('symlink_rejected', '缓存目录不能是符号链接');
  if (!st.isDirectory()) fail('invalid_dir', '缓存路径不是目录');
  fs.chmodSync(resolved, 0o700);
  return resolved;
}

function lstatQuiet(file) {
  try { return fs.lstatSync(file); } catch (e) {
    if (e.code === 'ENOENT') return null;
    fail('invalid_dir', '无法检查缓存目录');
  }
}

module.exports = { create, MAX_AGE_MS, MAX_PCM_BYTES, TEMP_ORPHAN_MS, PendingAudioCacheError };
