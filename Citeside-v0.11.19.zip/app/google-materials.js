'use strict';
// Full native Slides text plus original element identities and image references.
// Image references are not a claim that the image pixels were understood.
function textOf(container){return (container?.textElements||[]).map(e=>e.textRun?.content||'').join('');}
function elements(rows,lines,images){for(const e of rows||[]){
 if(e.shape)lines.push(textOf(e.shape.text));
 if(e.table)for(const row of e.table.tableRows||[])lines.push((row.tableCells||[]).map(c=>textOf(c.text)).join(' | '));
 if(e.image)images.push({objectId:e.objectId,contentUrl:e.image.contentUrl||'',sourceUrl:e.image.sourceUrl||'',title:e.title||'',description:e.description||'',contentRead:false});
 if(e.elementGroup)elements(e.elementGroup.children,lines,images);
}}
async function readCompletePresentation(dataDir,id,{read=require('./codex-app-bridge').readPresentation}={}){
 const body=await read(dataDir,id);
 if(body.presentationId!==id||!Array.isArray(body.slides)||!body.revisionId||body.truncated===true)throw Error('Google Slides 正文或版本不完整');
 const check=await read(dataDir,id,'presentationId,revisionId');
 if(check.revisionId!==body.revisionId)throw Error('Google Slides 在读取期间已更新，请重试');
 const pages=body.slides.map((slide,index)=>{const lines=[],images=[];elements(slide.pageElements,lines,images);const notes=[];elements(slide.slideProperties?.notesPage?.pageElements,notes,images);return {objectId:slide.objectId,pageIndex:index+1,text:lines.join('\n'),notes:notes.join('\n'),images};});
 return {text:pages.map(p=>'## Slide '+p.pageIndex+' · '+p.objectId+'\n'+p.text+(p.notes?'\n### Speaker notes\n'+p.notes:'')).join('\n\n'),version:body.revisionId,title:body.title||'',pages,coverage:{kind:'presentation_text',complete:true,pageCount:pages.length,imagesRead:false},nativeBody:body};
}
// Only explicit native Docs/Slides URLs are accepted; links in documents are
// reference text and never cause additional reads.
function parseDriveSource(value){
 let url;try{url=new URL(String(value));}catch{throw Error('请填写 Google Docs 或 Slides 文档链接');}
 const match=url.pathname.match(/^\/(document|presentation)\/d\/([A-Za-z0-9_-]+)(?:\/|$)/);
 if(url.protocol!=='https:'||url.hostname!=='docs.google.com'||url.port||url.username||url.password||!match)throw Error('请填写 Google Docs 或 Slides 文档链接');
 return {id:match[2],kind:match[1],url:'https://docs.google.com/'+match[1]+'/d/'+match[2]+'/edit'};
}
async function connectionStatus(dataDir,{status=require('./codex-app-bridge').driveStatus}={}){
 try{return await status(dataDir);}catch{return {state:'disconnected',available:false,kinds:[]};}
}
function documentText(body){
 const lines=[];
 const content=rows=>{for(const row of rows||[]){
  if(row.paragraph)lines.push((row.paragraph.elements||[]).map(e=>e.textRun?.content||'').join(''));
  for(const r of row.table?.tableRows||[])for(const cell of r.tableCells||[])content(cell.content);
  if(row.sectionBreak)continue;
  if(row.tableOfContents)content(row.tableOfContents.content);
 }};
 const tabs=rows=>{for(const tab of rows||[]){
  if(tab.tabProperties?.title)lines.push('## '+tab.tabProperties.title+'\n');
  content(tab.documentTab?.body?.content||tab.body?.content||tab.content);
  tabs(tab.childTabs);
 }};
 // A tab-aware response can also include a legacy first-tab body; avoid duplicates.
 if(Array.isArray(body.tabs)&&body.tabs.length)tabs(body.tabs);else content(body.body?.content);
 return lines.join('\n');
}
async function readDriveDocument(dataDir,value,options={}){
 const source=parseDriveSource(value),status=await connectionStatus(dataDir,options);
 if(!status.available||!status.kinds?.includes(source.kind))return {state:'disconnected',available:false,text:'',...source};
 try{
 if(source.kind==='presentation'){
  const material=await readCompletePresentation(dataDir,source.id,{read:options.readPresentation||require('./codex-app-bridge').readPresentation});
  return {state:'ready',available:true,...source,text:material.text,title:material.title,version:material.version,coverage:material.coverage};
 }
 const read=options.readDocument||require('./codex-app-bridge').readDocument;
 const body=await read(dataDir,source.id);
 if(body.documentId!==source.id||!body.revisionId||body.truncated===true||(!Array.isArray(body.body?.content)&&!Array.isArray(body.tabs)))throw Error('Google Docs 正文或版本不完整');
 const check=await read(dataDir,source.id,'documentId,revisionId');
 if(check.revisionId!==body.revisionId)throw Error('Google Docs 在读取期间已更新，请重试');
 return {state:'ready',available:true,...source,text:documentText(body),title:body.title||'',version:body.revisionId,coverage:{kind:'document_text',complete:true,imagesRead:false}};
 }catch(error){
  if(error.code==='DRIVE_NOT_CONNECTED'||error.sourceReadHttpStatus===401)return {state:'disconnected',available:false,text:'',...source};
  throw error;
 }
}
module.exports={readCompletePresentation,textOf,parseDriveSource,connectionStatus,readDriveDocument,documentText};
