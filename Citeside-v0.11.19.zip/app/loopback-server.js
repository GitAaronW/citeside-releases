'use strict';
const http=require('http');
// Two explicit loopback binds: never :: (which would expose a LAN listener).
// Forward to the original HTTP/WS handlers so both entries share auth and state.
function listen(server,port,ready){
 const ipv6=http.createServer((req,res)=>server.emit('request',req,res));
 ipv6.requestTimeout=server.requestTimeout;ipv6.headersTimeout=server.headersTimeout;
 ipv6.on('upgrade',(...args)=>server.emit('upgrade',...args));
 let failed=false;
 const fail=error=>{if(failed)return;failed=true;server.close();ipv6.close();server.emit('error',error);};
 ipv6.on('error',fail);
 server.listen(port,'127.0.0.1',()=>{ipv6.listen({port:server.address().port,host:'::1',ipv6Only:true},()=>{if(!failed)ready();});});
 return ipv6;
}
module.exports={listen};
