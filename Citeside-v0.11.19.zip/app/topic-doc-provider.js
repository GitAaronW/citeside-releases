'use strict';
const notion = require('./tools/notion');

// Explicit provider only. Existing token-only configurations remain Lark.
function target(config) {
  const provider = config.provider || 'lark';
  if (!['lark', 'notion'].includes(provider)) throw Error('不支持的主题文档来源');
  let id = String(config.doc || '').trim();
  if (provider === 'notion' && id) {
    if (/^https:\/\//.test(id)) {
      const url = new URL(id);
      if (!/(^|\.)(notion\.so|notion\.site|notion\.com)$/.test(url.hostname) || url.username || url.password || url.port) throw Error('Notion 目标链接无效');
      id = (url.pathname.match(/([a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\/?$/i) || [])[1] || '';
    }
    if (!/^(?:[a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})$/i.test(id)) throw Error('需要明确的 Notion 页面编号');
    id = id.replace(/-/g, '').toLowerCase();
  }
  return { provider, id };
}
// Last top-level block of the page's own heading for this section, or '' when
// the page has no plain (non-toggle) heading with exactly this text.
function sectionEnd(snapshots, pageId, section) {
  const canonical=id=>/^[a-f0-9-]{32,36}$/i.test(String(id))?String(id).replace(/-/g,'').toLowerCase():String(id||'');
  const same = id => canonical(id) === canonical(pageId);
  const rows = (snapshots || []).filter(b => same(b.parentId));
  const level = b => /^heading_([123])$/.exec(b.type)?.[1];
  const start = rows.findIndex(b => level(b) && !b.hasChildren && b.text.trim() === section);
  if (start < 0) return '';
  let end = start;
  while (end + 1 < rows.length && !(level(rows[end + 1]) && level(rows[end + 1]) <= level(rows[start]))) end++;
  return rows[end].id;
}
function create({ lark, larkOptions, env, notionOptions = {}, cloudDocumentProvider }) {
  const context = () => ({ ...notionOptions, cloudDocumentProvider, env: typeof env === 'function' ? env() : env || process.env });
  const resolve = config => cloudDocumentProvider && config.provider === cloudDocumentProvider.name
    ? {provider: config.provider, id: String(config.doc || '').trim()} : target(config);
  const attempt = async run => { try { return {ok:true,...await run()}; } catch(e) { return {ok:false,uncertain:!!e.uncertain,error:'文档暂时无法同步，内容已保留，请稍后重试'}; } };
  return {
    target: resolve,
    async read(config) {
      const t = resolve(config);
      if (t.provider === 'lark') return typeof lark.docFetchMarkdown === 'function' ? lark.docFetchMarkdown(t.id, larkOptions) : null;
      return attempt(async()=>{const r=await cloud(context()).readLibrary(t.id);return {...r,markdown:r.markdown ?? r.text};});
    },
    async readBlock(config, id) {
      if (resolve(config).provider === 'lark') throw Error('该来源尚不支持段落修订');
      return attempt(async()=>({json:await cloud(context()).readBlock(id)}));
    },
    async insertRevision(config, after, text) {
      const t=resolve(config);
      if (t.provider === 'lark') throw Error('该来源尚不支持段落修订');
      return attempt(async()=>({json:{results:await cloud(context()).appendBlocks(t.id,[{type:'paragraph',text}],after)}}));
    },
    async archive(config, id, archived = true) {
      if (resolve(config).provider === 'lark') throw Error('该来源尚不支持段落修订');
      return attempt(async()=>({json:await cloud(context()).archiveBlock(id,archived)}));
    },
    async append(config, item, record, xml, snapshots) {
      const t=resolve(config);
      if (t.provider === 'lark') return lark.docValidateAppend({ token:t.id,content:xml },larkOptions);
      const body=[{type:'paragraph',text:item.text},{type:'paragraph',text:'来源：会议 '+record.meetingId+' '+record.date}];
      const after=sectionEnd(snapshots,t.id,item.section);
      return attempt(async()=>{
        const blocks=await cloud(context()).appendBlocks(t.id,after?body:[{type:'heading_2',text:item.section},...body],after);
        const created=blocks.map(b=>b.id);
        return {blockId:created[after?0:1]||'',created,after:after||'',revision:'',provider:t.provider};
      });
    },
  };
}
// Cloud document contract: provider-specific IDs, payloads and transport stay here.
// A second provider implements these operations without emulating the Notion API.
const hash = value => require('crypto').createHash('sha256').update(JSON.stringify(value)).digest('hex');
function cloud(options = {}) {
  if (options.cloudDocumentProvider) return options.cloudDocumentProvider;
  const ctx = { ...options, env: typeof options.env === 'function' ? options.env() : options.env || {} };
  const rich = text => [{ type: 'text', text: { content: text } }];
  const encode = b => { const type=b.type||'paragraph'; return {object:'block',type,[type]:{rich_text:b.text?Array.from({length:Math.ceil(b.text.length/1800)},(_,i)=>({type:'text',text:{content:b.text.slice(i*1800,(i+1)*1800)},...(b.heading?{annotations:{bold:true}}:{})})):[]}}; };
  const decode = b => ({ id: b.id, type: b.type, text: notion.blockText(b), heading: !!b[b.type]?.rich_text?.[0]?.annotations?.bold,
    richText:b[b.type]?.rich_text||[],color:b[b.type]?.color||'default',hasChildren:!!b.has_children, fingerprint: hash(b[b.type] || {}), archived: !!(b.archived || b.in_trash) });
  async function request(method, endpoint, body) {
    const r = await notion.api(ctx, method, endpoint, body);
    if (!r.ok) throw Object.assign(Error('文档尚未同步，已保存在本机，请稍后重试'), { uncertain: !!r.uncertain });
    return r.json;
  }
  return {
    name: 'notion',
    connected: () => notion.connected(ctx) && !!(ctx.env.NOTION_DOCUMENT_PARENT || notion.relayFor(ctx)?.connected()),
    available: async () => !!(ctx.env.NOTION_DOCUMENT_PARENT || notion.relayFor(ctx)?.connected()) && await notion.available(ctx),
    root: () => ctx.env.NOTION_DOCUMENT_PARENT ? target({provider:'notion',doc:ctx.env.NOTION_DOCUMENT_PARENT}).id : require('./notion-document-parent').ensure(ctx),
    url: id => 'https://www.notion.so/' + id.replace(/-/g, ''),
    async listPages(parentId) {
      const pages = []; let cursor = ''; const seen = new Set();
      do {
        const r = await request('GET', 'blocks/' + encodeURIComponent(parentId) + '/children?page_size=100' + (cursor ? '&start_cursor=' + encodeURIComponent(cursor) : ''));
        for (const b of r.results || []) if (b.type === 'child_page') pages.push({ id: b.id, title: b.child_page.title });
        const next = r.has_more ? r.next_cursor : '';
        if (r.has_more && (!next || seen.has(next))) throw Error('文档尚未读完，请稍后重试');
        if (next) seen.add(next); cursor = next;
      } while (cursor);
      return pages;
    },
    async createPage(parentId, title, blocks = []) {
      const p = await request('POST', 'pages', { parent: { page_id: parentId }, properties: { title: { type: 'title', title: rich(title) } }, children: blocks.map(encode) });
      if (!p?.id) throw Object.assign(Error('文档同步结果待确认，请稍后重试'), { uncertain: true });
      return { id: p.id, title, url: p.url || this.url(p.id) };
    },
    async readPage(id) {
      const p = await request('GET', 'pages/' + encodeURIComponent(id));
      return { id: p.id, title: notion.titleOf(p), url: p.url || this.url(id) };
    },
    async renamePage(id, title) { await request('PATCH', 'pages/' + encodeURIComponent(id), { properties: { title: { type: 'title', title: rich(title) } } }); },
    async readBlocks(id) {
      const blocks = []; let cursor = ''; const seen = new Set();
      do {
        const r = await request('GET', 'blocks/' + encodeURIComponent(id) + '/children?page_size=100' + (cursor ? '&start_cursor=' + encodeURIComponent(cursor) : ''));
        blocks.push(...(r.results || []).map(decode));
        const next = r.has_more ? r.next_cursor : '';
        if (r.has_more && (!next || seen.has(next))) throw Error('文档尚未读完，请稍后重试');
        if (next) seen.add(next); cursor = next;
      } while (cursor);
      return blocks;
    },
    async readBlock(id) { return decode(await request('GET', 'blocks/' + encodeURIComponent(id))); },
    async archiveBlock(id, archived=true) { return decode(await request('PATCH','blocks/'+encodeURIComponent(id),{archived})); },
    async updateBlock(id, block) { return decode(await request('PATCH', 'blocks/' + encodeURIComponent(id), encode(block))); },
    async appendBlocks(id, blocks, after) {
      const r = await request('PATCH', 'blocks/' + encodeURIComponent(id) + '/children', { ...(after ? { after } : {}), children: blocks.map(encode) });
      if (r.results?.length !== blocks.length) throw Object.assign(Error('文档同步结果待确认，请稍后重试'), { uncertain: true });
      return r.results.map(decode);
    },
    async linkPage(parentId, pageId) {
      // A link is an ordinary user-facing URL, so the reader can follow it too.
      const text = this.url(pageId), existing = await this.readBlocks(parentId);
      if (existing.some(b => b.text === text)) return;
      await this.appendBlocks(parentId, [{ text }]);
    },
    async readLibrary(id) {
      const r = await notion.readCompletePage(ctx, id);
      if (!r.ok) throw Error('文档尚未读完，请稍后重试');
      return { ...r, markdown: r.text };
    },
  };
}
module.exports = { target, create, sectionEnd, cloud };
