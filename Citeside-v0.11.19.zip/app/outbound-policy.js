'use strict';
// Configuration guard for existing transports; labels are declared by the user,
// not inferred from DNS or a vendor name. No second router or network client.
const CHANNELS = ['jev', 'asr', 'search', 'fetch'];
const object = x => x && typeof x === 'object' && !Array.isArray(x);
function fail(code) { throw Object.assign(Error(code), { code }); }
function within(connection, regions, scopes) {
  return regions.includes(connection.region) && scopes.includes(connection.dataScope);
}
function validate(services) {
  if (services === undefined) return;
  if (!object(services) || Object.keys(services).some(k => !CHANNELS.includes(k))) fail('outbound_config_invalid');
  for (const policy of Object.values(services)) {
    const labels = a => Array.isArray(a) && a.length && a.every(x => typeof x === 'string' && x.trim());
    if (!object(policy) || !labels(policy.allowedRegions) || !labels(policy.allowedDataScopes) || !Array.isArray(policy.destinations)) fail('outbound_config_invalid');
    const seen = new Set();
    for (const destination of policy.destinations) {
      let url; try { url = new URL(destination?.origin); } catch { fail('outbound_config_invalid'); }
      if (!['https:', 'wss:', 'http:', 'ws:'].includes(url.protocol) || url.origin !== destination.origin || url.username || url.password || seen.has(url.origin)) fail('outbound_config_invalid');
      if (!within(destination, policy.allowedRegions, policy.allowedDataScopes)) fail('outbound_boundary_blocked');
      seen.add(url.origin);
    }
  }
}
function assertAllowed(env, channel, endpoint) {
  const services = env?.LLM_ROUTING?.externalServices;
  if (services === undefined) return;
  validate(services);
  const policy = services[channel];
  if (!policy) fail('outbound_channel_unconfigured');
  let origin; try { origin = new URL(endpoint).origin; } catch { fail('outbound_destination_unknown'); }
  const destination = policy.destinations.find(x => x.origin === origin);
  if (!destination) fail('outbound_destination_unknown');
  if (!within(destination, policy.allowedRegions, policy.allowedDataScopes)) fail('outbound_boundary_blocked');
}
module.exports = { within, validate, assertAllowed };
