'use strict';
// 方法论实验在会中链路上的接点（native-meeting.js run()）：
//   payload(all, recent) → 加进模型输入的字段；apply(parsed) → guard 之后对卡片做的标注（同步）；
//   applyWith(parsed, ask, log) → 同 apply，但超限的卡先让模型重写一次（异步，只在 brief 开着时才会调模型）。
// 开关在 method-flags.js；开关都关时这几个函数什么都不做，生产行为不变（needsModel() 为 false，调用方走同步 apply）。
// apply 的顺序：先按 lens / 基准用语贴方法标签（看的是全文），再过出处闸（source 开着时外部卡没出处整张不出），最后做篇幅兜底（标签和来源行不计入字数）。
const { flags } = require('./method-flags');
function payload(all, recent) {
  const f = flags(), out = {};
  if (f.hats) { const hats = require('./method-hats'); const stat = hats.hatsOf(all); out.hats = { share: stat.share, missing: hats.missing(stat) }; }
  if (f.refclass) out.forecastClaims = require('./method-refclass').claims(recent);
  return out;
}
function tag(parsed, f) {
  let p = parsed;
  if (f.hats) p = require('./method-hats').tagLens(p);
  if (f.refclass) p = require('./method-refclass').tagRef(p);
  return p;
}
function apply(parsed, log) {
  const f = flags(); let p = tag(parsed, f);
  if (f.source) p = require('./method-source').requireSource(p, log);
  if (f.brief) p = require('./method-brief').brief(p, log);
  return p;
}
function needsModel() { return !!flags().brief; }
async function applyWith(parsed, ask, log) {
  const f = flags(); let p = tag(parsed, f);
  if (f.source) p = require('./method-source').requireSource(p, log);
  if (f.brief) { const b = require('./method-brief'); p = await b.rewrite(p, ask, log); p = b.brief(p, log); }
  return p;
}
function systemPrompt() {
  const f = flags();
  return (f.hats ? require('./method-hats').prompt : '') + (f.refclass ? require('./method-refclass').prompt : '') + (f.brief ? require('./method-brief').prompt : '') + (f.source ? require('./method-source').prompt : '');
}
module.exports = { payload, apply, applyWith, needsModel, systemPrompt };
