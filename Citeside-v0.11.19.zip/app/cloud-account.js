'use strict';
// Cloud identity is separate from personal service keys. Resolving the public
// account endpoint does not change trial routing, settings, or start a request.
// Product LLM/ASR calls and recording starts require a valid product login;
// personal service keys do not exempt that requirement.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const DEFAULT_ACCOUNT_URL = 'https://account-production-48d5.up.railway.app';
function accountBase(env) {
  const value = String((env && env.CLOUD_ACCOUNT_URL) || '').trim() || DEFAULT_ACCOUNT_URL;
  const u = new URL(value);
  if (u.username || u.password || u.search || u.hash || (u.protocol !== 'https:' && !(u.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname)))) throw Error('invalid_cloud_url');
  return u.href.replace(/\/$/, '');
}
function loadSession(dataDir, env, now = Date.now()) {
  const url = accountBase(env);
  if (!url) return null;
  try {
    const j = JSON.parse(fs.readFileSync(path.join(dataDir, 'cloud-account-session.json'), 'utf8'));
    if (j && j.url === url && typeof j.token === 'string' && /^[A-Za-z0-9_-]{43}$/.test(j.token) && Number.isFinite(j.expiresAt) && j.expiresAt > now) return { url, token: j.token, expiresAt: j.expiresAt };
  } catch {}
  return null;
}
function create({ dataDir, env = () => ({}), fetchImpl = globalThis.fetch, now = () => Date.now() } = {}) {
  const file = () => path.join(dataDir, 'cloud-account-session.json');
  let pending = Promise.resolve();
  const serial = fn => { const r = pending.then(fn, fn); pending = r.catch(() => {}); return r; };
  function base() { return accountBase(typeof env === 'function' ? env() : env); }
  const read = url => {
    try { const j = JSON.parse(fs.readFileSync(file(), 'utf8')); return j && j.url === url && typeof j.token === 'string' && /^[A-Za-z0-9_-]{43}$/.test(j.token) && Number.isFinite(j.expiresAt) ? j : null; }
    catch { return null; }
  };
  const remove = () => fs.rmSync(file(), { force: true });
  function write(j) {
    fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
    require('./durable-json').write(file(), j);
  }
  async function request(url, endpoint, body, session) {
    try {
      const r = await fetchImpl(url + endpoint, { method: body === undefined ? 'GET' : 'POST', redirect: 'error', signal: AbortSignal.timeout(12000),
        headers: { 'Content-Type': 'application/json', ...(session ? { Authorization: 'Bearer ' + session.token } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
      const j = await r.json();
      if (!j || typeof j !== 'object' || typeof j.ok !== 'boolean') throw Error('invalid_response');
      if (r.status >= 500) return { ok: false, status: 'offline', code: endpoint.startsWith('/v1/payments/') && typeof j.code === 'string' ? j.code : 'offline', httpStatus: r.status };
      return { ...j, ok: r.ok && j.ok, ...(r.ok ? {} : { httpStatus: r.status }) };
    } catch { return { ok: false, status: 'offline', code: 'offline' }; }
  }
  async function authConfig() {
    try {
      const response = await fetchImpl(base() + '/config.js', {redirect:'error', credentials:'omit', signal:AbortSignal.timeout(12000), headers:{Accept:'application/javascript'}});
      if (!response.ok) throw Error('config_unavailable');
      let text;
      if (response.body && typeof response.body.getReader === 'function') {
        const reader=response.body.getReader(), chunks=[];let size=0;
        try {
          while (true) {
            const part=await reader.read();if(part.done)break;
            size+=part.value.byteLength;if(size>16384){await reader.cancel();throw Error('config_too_large');}
            chunks.push(Buffer.from(part.value));
          }
          text=Buffer.concat(chunks).toString('utf8');
        } finally {reader.releaseLock();}
      } else {text=await response.text();if(Buffer.byteLength(text)>16384)throw Error('config_too_large');}
      // The existing public endpoint is a JSON assignment. Parse the data only;
      // never evaluate the server script or return other configuration fields.
      const match=/^\s*window\.ACCOUNT_CONFIG\s*=\s*(\{[\s\S]*\})\s*;?\s*$/.exec(text);
      if(!match)throw Error('invalid_config');const config=JSON.parse(match[1]);
      return {ok:true,enabled:true,googleAvailable:config.google===true};
    } catch {return {ok:false,enabled:true,googleAvailable:false,code:'auth_config_unavailable'};}
  }
  const publicAccount = j => ({ email: j.email, plan: j.plan, planUntil: j.planUntil, aiHoursLimit: j.aiHoursLimit, aiHoursUsed: j.aiHoursUsed, usageAuthority: j.usageAuthority, paidAllowance: j.paidAllowance, aiCredits: j.aiCredits, researchLimit: j.researchLimit, researchUsed: j.researchUsed, ...(typeof j.tier === 'string' && j.tier ? { tier: j.tier } : {}), ...(j.subscription && typeof j.subscription === 'object' ? { subscription: j.subscription } : {}), ...(Array.isArray(j.zdrProviders) ? { zdrProviders: j.zdrProviders } : {}), ...(Array.isArray(j.shareHours) ? { shareHours: j.shareHours } : {}), ...(Array.isArray(j.shareTtlOptions) ? { shareTtlOptions: j.shareTtlOptions } : {}), ...(j.loginGrant ? {loginGrant:{granted:j.loginGrant.granted===true,meetingHours:j.loginGrant.meetingHours,researchCount:j.loginGrant.researchCount}} : {}), invite: j.invite, isAdmin: j.isAdmin === true });
  function saveAuthenticatedSession(url, result) {
    if (typeof result.token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(result.token) || !Number.isFinite(result.expiresAt) || result.expiresAt <= now()) throw Error('invalid_session');
    write({ url, token: result.token, expiresAt: result.expiresAt });
    return { ok: true, enabled: true, status: 'signed_in', ...publicAccount(result) };
  }
  const authCodes = new Set(['invalid_credentials','invalid_email','invalid_password','account_exists','invalid_callback','mail_unavailable','rate_limited','offline']);
  function authFailure(result) {
    return { ok: false, enabled: true, status: result.status === 'offline' ? 'offline' : 'error', code: authCodes.has(result.code) ? result.code : 'account_unavailable' };
  }
  const claimPayload = body => {
    if (!body || typeof body !== 'object') return {};
    const code = body.inviteCode;
    if (code === undefined || code === null || code === '') return {};
    return { inviteCode: code };
  };
  async function run(action, body = {}) {
    const url = base();
    if (!url) return { ok: false, enabled: false, status: 'disabled', code: 'disabled' };
    if (action === 'passwordLogin') {
      if (typeof body.email !== 'string' || typeof body.password !== 'string' || !body.password || body.password.length > 128 || Buffer.byteLength(body.password) > 512) return authFailure({code:'invalid_credentials'});
      const result = await request(url, '/v1/auth/login', { email: body.email, password: body.password });
      return result.ok ? saveAuthenticatedSession(url, result) : authFailure(result);
    }
    if (action === 'register') {
      if (body.from !== undefined && (body.from !== 'app' || !Number.isInteger(body.port) || body.port < 1024 || body.port > 65535)) return authFailure({code:'invalid_callback'});
      const callback = body.from === 'app' ? { from:'app', port:body.port } : {};
      const result = await request(url, '/v1/auth/register', { email:body.email, password:body.password, ...(body.inviteCode ? {inviteCode:body.inviteCode} : {}), lang:body.lang, ...callback });
      return result.ok && ['verification_sent','cooldown'].includes(result.status) ? {ok:true,enabled:true,status:result.status} : authFailure(result);
    }
    if (action === 'forgotPassword') {
      const result = await request(url, '/v1/auth/password/forgot', {email:body.email,lang:body.lang});
      return result.ok && ['reset_requested','cooldown'].includes(result.status) ? {ok:true,enabled:true,status:result.status} : authFailure(result);
    }
    if (action === 'start') {
      if (body.from !== undefined && (body.from !== 'app' || !Number.isInteger(body.port) || body.port < 1024 || body.port > 65535)) {
        return { ok: false, enabled: true, code: 'invalid_callback' };
      }
      const callback = body.from === 'app' ? { from: 'app', port: body.port } : {};
      return { ...(await request(url, '/v1/auth/magic-link', { email: body.email, inviteCode: body.inviteCode, lang: body.lang, ...callback })), enabled: true };
    }
    if (action === 'verify') {
      const r = await request(url, '/v1/auth/verify', { token: body.token, ...(body.appLink ? { appLink: true } : {}) });
      if (!r.ok) { const { token: ignored, ...safe } = r; return { ...safe, enabled: true }; }
      return saveAuthenticatedSession(url, r);
    }
    const session = read(url);
    if (action === 'logout') {
      const r = session ? await request(url, '/v1/auth/logout', {}, session) : { ok: true };
      remove();
      return { ok: true, enabled: true, status: r.status === 'offline' ? 'offline' : 'signed_out', remoteRevoked: r.ok || r.code === 'unauthorized' };
    }
    if (!session || session.expiresAt <= now()) {
      if (session) remove();
      return { ok: action === 'status', enabled: true, ...(action === 'status' ? { cloudUrl: url } : {}), status: 'signed_out', ...(action === 'status' ? {} : { code: 'unauthorized' }) };
    }
    // 服务端墙钟打开时，时长以 /v1/me 为准。这里不提交客户端秒数，避免打到仍拒绝该请求的 /v1/usage。
    if (action === 'usage') {
      const me = await request(url, '/v1/me', undefined, session);
      if (me.code === 'unauthorized') { remove(); return { ok: false, enabled: true, status: 'signed_out', code: me.code }; }
      if (me.usageAuthority === 'server') {
        const { token: ignored, ...safe } = me;
        return { ...safe, ok: me.ok === true, enabled: true, status: me.ok ? 'server_metered' : (me.status || 'error') };
      }
    }
    const endpoint = { meetingActivity: '/v1/meeting/activity', consumeResearch: '/v1/research/consume', status: '/v1/me', claim: '/v1/invites/claim', mine: '/v1/invites/mine', usage: '/v1/usage', adminMfaStatus: '/v1/admin/mfa/status', adminMfaSetup: '/v1/admin/mfa/setup', adminMfaConfirm: '/v1/admin/mfa/confirm', adminMfaVerify: '/v1/admin/mfa/verify', adminMfaLock: '/v1/admin/mfa/lock', adminService: '/v1/admin/service', saveAdminService: '/v1/admin/service', adminInvites: '/v1/admin/invites', createAdminInvite: '/v1/admin/invites', feedbackPreview: '/v1/feedback/preview', feedbackSubmit: '/v1/feedback/submit', adminFeedback: '/v1/admin/feedback', approveAdminFeedback: '/v1/admin/feedback/approve', declineAdminFeedback: '/v1/admin/feedback/decline', createShare: '/v1/shares', shares: '/v1/shares', revokeShare: '/v1/shares/' + encodeURIComponent(body.token || '') + '/revoke' }[action];
    if (!endpoint) throw Error('invalid_action');
    const payload = action === 'meetingActivity' ? {connectionId:body.connectionId,active:body.active} : action === 'consumeResearch' ? {operationId:body.operationId} : action === 'adminMfaSetup' || action === 'adminMfaLock' ? {} : action === 'adminMfaConfirm' ? {code:body.code} : action === 'adminMfaVerify' ? (typeof body.recoveryCode === 'string' ? {recoveryCode:body.recoveryCode} : {code:body.code}) : action === 'usage' ? { meetingId: body.meetingId, seconds: body.seconds } : action === 'claim' ? claimPayload(body) : action === 'saveAdminService' ? { fastModel: body.fastModel, slowModel: body.slowModel, chatModel: body.chatModel, ...(body.apiKey ? { apiKey: body.apiKey } : {}) } : action === 'createAdminInvite' || action === 'revokeShare' ? {} : action === 'createShare' ? { snapshot: body.snapshot, hours: body.hours } : action === 'feedbackPreview' ? { text: body.text, ...(body.previewId ? { previewId: body.previewId } : {}), ...(body.refineNote ? { refineNote: body.refineNote } : {}) } : action === 'feedbackSubmit' ? { mode: body.mode, text: body.text, ...(body.previewId ? { previewId: body.previewId } : {}), attachments: body.attachments, includeLog: body.includeLog, diagnostics: body.diagnostics } : action === 'approveAdminFeedback' || action === 'declineAdminFeedback' ? { key: body.key } : undefined;
    const r = await request(url, endpoint, payload, session);
    if (r.code === 'unauthorized') { remove(); return { ok: false, enabled: true, ...(action === 'status' ? { cloudUrl: url } : {}), status: 'signed_out', code: r.code }; }
    const { token: ignored, ...safe } = r;
    return { ...safe, ...(['createShare', 'shares', 'revokeShare'].includes(action) && r.token ? { token: r.token } : {}), enabled: true, ...(action === 'status' ? { cloudUrl: url } : {}), status: r.status || (r.ok ? 'signed_in' : 'error') };
  }
  // Payment requests use the existing private session. No cloud bearer reaches web content.
  async function payment(action, body = {}) {
    const session = loadSession(dataDir, typeof env === 'function' ? env() : env, now());
    if (!session) return {ok:false,code:'unauthorized'};
    const endpoints = {catalog:'/v1/payments/catalog',checkout:'/v1/payments/checkout',subscription:'/v1/payments/subscription',cancel:'/v1/payments/subscription/cancel',orders:'/v1/payments/orders',order:'/v1/payments/orders/'};
    let endpoint=endpoints[action]; if (!endpoint) return {ok:false,code:'not_found'};
    if (action === 'checkout' && (typeof body.sku !== 'string' || !/^[a-z0-9_-]{1,64}$/.test(body.sku))) return {ok:false,code:'invalid_sku'};
    if (action === 'order') { if(typeof body.id !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(body.id))return {ok:false,code:'invalid_order'}; endpoint+=encodeURIComponent(body.id); }
    if (action === 'orders') { const q=new URLSearchParams({limit:'20'});if(body.before){if(!/^[a-zA-Z0-9_-]{1,128}$/.test(body.before))return {ok:false,code:'invalid_order_pagination'};q.set('before',body.before);}endpoint+='?'+q; }
    const result=await request(session.url,endpoint,action==='checkout'?{sku:body.sku}:action==='cancel'?{}:undefined,session);
    if(result.code==='unauthorized')remove();
    // Only the documented payment response fields can cross this bridge.
    return Object.fromEntries(['ok','code','configured','reason','environment','model','rollover','catalog','order','orders','nextBefore','subscription','confirmed','checkoutUrl'].filter(k=>Object.hasOwn(result,k)).map(k=>[k,result[k]]));
  }
  const call = (action, body) => serial(async () => {
    try { const result = await run(action, body); return action === 'status' ? { ...result, access: productAccess(result, Date.now(), 'any') } : result; }
    catch { return { ok: false, enabled: true, status: 'offline', code: 'account_unavailable' }; }
    finally { if (action === 'logout') remove(); }
  });
  return { payment, authConfig, meetingActivity: b => call('meetingActivity', b), consumeResearch: b => call('consumeResearch', b), adminMfaStatus: () => call('adminMfaStatus'), adminMfaSetup: () => call('adminMfaSetup'), adminMfaConfirm: b => call('adminMfaConfirm', b), adminMfaVerify: b => call('adminMfaVerify', b), adminMfaLock: () => call('adminMfaLock'), passwordLogin: b => call('passwordLogin', b), register: b => call('register', b), forgotPassword: b => call('forgotPassword', b), createShare: b => call('createShare', b), shares: () => call('shares'), revokeShare: b => call('revokeShare', b), status: () => call('status'), start: b => call('start', b), verify: b => call('verify', b), logout: () => call('logout'), claim: b => call('claim', b), mine: () => call('mine'), usage: b => call('usage', b), adminService: () => call('adminService'), saveAdminService: b => call('saveAdminService', b), adminInvites: () => call('adminInvites'), createAdminInvite: () => call('createAdminInvite'), feedbackPreview: b => call('feedbackPreview', b), feedbackSubmit: b => call('feedbackSubmit', b), adminFeedback: () => call('adminFeedback'), approveAdminFeedback: b => call('approveAdminFeedback', b), declineAdminFeedback: b => call('declineAdminFeedback', b) };
}
// Personal provider keys select a transport; they do not grant product access.
async function requireSignedIn({ dataDir, env = {}, fetchImpl = globalThis.fetch } = {}) {
  const denied = { ok: false, code: 'account_login_required' };
  if (!dataDir) return denied;
  try {
    const currentEnv = typeof env === 'function' ? env() : env;
    const session = loadSession(dataDir, currentEnv);
    if (!session) return denied;
    const status = await create({ dataDir, env: currentEnv, fetchImpl }).status();
    if (status.ok === true && status.status === 'signed_in' && loadSession(dataDir, currentEnv)?.token === session.token) return { ok: true, account: status };
    if (status && (status.status === 'offline' || status.code === 'offline' || status.code === 'account_unavailable')) return { ok: false, code: 'account_login_required', offline: true };
    return denied;
  } catch { return denied; }
}
function validAiCredits(value) {
  return value && value.version === 'weighted-v1' && value.unit === 'points' && value.tokensPerPoint === 1000
    && ['limit','used','held','remaining'].every(k => typeof value[k] === 'number' && Number.isFinite(value[k]) && value[k] >= 0)
    && value.used + value.held + value.remaining <= value.limit + 0.0000001;
}
function productAccess(status, now = Date.now(), resource = 'meeting') {
  if (!status || status.ok !== true || status.status !== 'signed_in') return { allowed: false, code: 'account_login_required' };
  const entitled = status.plan === 'trial' || (status.plan === 'pro' && Number.isFinite(status.planUntil) && status.planUntil > now);
  const time = entitled && Number.isFinite(status.aiHoursLimit) && Number.isFinite(status.aiHoursUsed) && status.aiHoursLimit >= 0 && status.aiHoursUsed >= 0 && (status.aiHoursLimit - status.aiHoursUsed) * 3600 >= 1;
  const weighted = status.aiCredits != null;
  const ai = validAiCredits(status.aiCredits) && status.aiCredits.remaining > 0;
  const research = weighted ? ai : Number.isInteger(status.researchLimit) && Number.isInteger(status.researchUsed) && status.researchUsed >= 0 && status.researchLimit > status.researchUsed;
  if (resource === 'research' || resource === 'ai' && weighted) return {allowed:research,code:research?'':weighted?'ai_credits_exhausted':'research_quota_exhausted'};
  if (time || (resource === 'any' && research)) return { allowed: true, code: '' };
  return { allowed: false, code: entitled ? 'quota_exhausted' : 'entitlement_required' };
}
async function requireProductAccess(options = {}) {
  const login = await requireSignedIn(options);
  if (!login.ok) return login.offline === true ? { ok: false, code: login.code, offline: true } : { ok: false, code: login.code };
  if (options.resource === 'research' && options.operationId && login.account.aiCredits == null) {
    const result = await create(options).consumeResearch({operationId:options.operationId});
    return result.ok ? {ok:true} : {ok:false,code:result.code||'research_quota_unavailable'};
  }
  const access = productAccess(login.account, Date.now(), options.resource);
  return access.allowed ? { ok: true } : { ok: false, code: access.code };
}
module.exports = { create, accountBase, loadSession, requireSignedIn, productAccess, requireProductAccess, DEFAULT_ACCOUNT_URL };
