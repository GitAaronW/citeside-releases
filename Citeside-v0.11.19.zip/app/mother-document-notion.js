'use strict';
// Only blocks created by this mirror are revised; extra Notion blocks remain human-owned.
const {yDocToProsemirrorJSON}=require('./mother-document-runtime');
function lines(node){
 if(node.type==='image')return '[图片] '+(node.attrs?.alt||'');
 if(node.type==='meetingGraph'){const g=node.attrs?.graph||{};return (g.nodes||[]).map(n=>n.label+(n.detail?'：'+n.detail:'')).join('\n')+'\n'+(g.edges||[]).map(e=>e.from+' → '+e.to+(e.label?'：'+e.label:'')).join('\n');}
 if(node.type==='text')return node.text||'';
 return (node.content||[]).map(lines).join(['paragraph','heading'].includes(node.type)?'':'\n');
}
function blocks(doc){
 const result=[];
 for(const n of yDocToProsemirrorJSON(doc,'default').content){const text=lines(n).trim();if(!text)continue;
  // Stable paragraph blocks permit safe in-place updates when the local block type changes.
  const type='paragraph';
  for(let i=0;i<text.length;i+=1800)result.push({type,text:text.slice(i,i+1800),heading:n.type==='heading'});
 }
 return result;
}
const same=(a,b)=>a?.text===b?.text&&!!a?.heading===!!b?.heading;
const message='文档尚未同步，已保存在本机，请稍后重试';
function configuration(ctx){return {...ctx,env:typeof ctx.env==='function'?ctx.env():ctx.env||{}};}
const cloud=ctx=>require('./topic-doc-provider').cloud(ctx);
function receiptFor(record,name){return record.cloudDocuments?.[name]||((record.notion?.provider||'notion')===name?record.notion:{})||{};}
async function sync(store,id,options){
 const ctx=configuration(options),provider=cloud(ctx),entry=store.read(id),r=entry.record;
 const save=patch=>{const current=store.read(id);const next={...receiptFor(current.record,provider.name),...patch};const record={...current.record,notion:next,cloudDocuments:{...current.record.cloudDocuments,[provider.name]:next}};store.persist(record);current.record=record;};
 try{
  if(!await provider.available())return {state:'local'};
  return await require('./notion-document-parent').library(ctx,provider,async library=>{
   let receipt={...receiptFor(r,provider.name)};
   if(receipt.provider&&receipt.provider!==provider.name)throw Error(message);
   if(receipt.rootId&&receipt.rootId!==library.root)throw Error(message);
   const desired=blocks(entry.doc),revision=r.revision,title=r.title;
   // Old mirrors may have committed a create before their receipt was saved.
   // Reconcile those pages before introducing the library hierarchy.
   if(!receipt.rootId&&receipt.parentId&&receipt.parentId!==library.root)throw Error(message);
   if(receipt.pendingCreate&&!receipt.pageId){
    const matches=[];
    for(const p of await provider.listPages(receipt.parentId||library.root))if(p.title===title){
     const actual=await provider.readBlocks(p.id);
     if(actual.length===desired.length&&actual.every((b,i)=>same(b,desired[i])))matches.push({...p,blocks:actual});
    }
    if(matches.length!==1)throw Error(message);
    const p=matches[0];receipt={...receipt,pageId:p.id,title,url:provider.url(p.id),blocks:p.blocks,pendingCreate:false};save(receipt);
   }
   if(receipt.pageId&&!receipt.rootId&&receipt.revision==null&&!receipt.blocks?.length){
    const actual=await provider.readBlocks(receipt.pageId);
    if(actual.length!==desired.length||!actual.every((b,i)=>same(b,desired[i])))throw Error(message);
    receipt.blocks=actual;save(receipt);
   }
   const topicKey=r.topic?'topic:'+r.topic:r.projectId?'project:'+r.projectId:'unfiled';
   const topic=await library.ensurePage('topic:'+topicKey,library.root,r.topic||ctx.getTopic?.(r.projectId)?.title||ctx.getTopic?.(r.projectId)?.name||'未分类');
   const meetings=[];
   for(const meetingId of r.meetings?.length?r.meetings:['unbound:'+id]){
    const info=ctx.getMeeting?.(meetingId)||{};
    meetings.push(await library.ensurePage('meeting:'+topicKey+':'+meetingId,topic.id,info.title||info.name||(meetingId.startsWith('unbound:')?'待关联会议':'会议记录')));
   }
   // Library metadata is checked even when content revision has not changed.
   if(receipt.revision===revision&&receipt.state==='synced'&&receipt.rootId===library.root)return receipt;
   save({state:'syncing'});
   if(!receipt.pageId){
    const page=await library.ensurePage('output:'+id,meetings[0].id,title);
    receipt={...receipt,pageId:page.id,url:page.url||provider.url(page.id),parentId:meetings[0].id,title,blocks:[],provider:provider.name,rootId:library.root,libraryUrl:provider.url(library.root)};
    save(receipt);
   }
   for(const meeting of meetings)if(meeting.id!==receipt.parentId)await provider.linkPage(meeting.id,receipt.pageId);
   const commit=()=>{save(receipt);};
   let owned=(receipt.blocks||[]).map(b=>({...b,fingerprint:b.fingerprint||b.remoteHash}));
   // Recover an acknowledged or response-lost update before checking for human edits.
   if(receipt.pendingUpdate){
    const p=receipt.pendingUpdate,remote=await provider.readBlock(p.id);
    if(same(remote,p.block)&&!remote.archived){owned[p.index]=remote;receipt.blocks=owned;receipt.pendingUpdate=null;commit();}
    else if(remote.fingerprint===owned[p.index]?.fingerprint){receipt.pendingUpdate=null;commit();}
    else throw Error(message);
   }
   if(receipt.pendingAppend){
    const p=receipt.pendingAppend;
    if(typeof p!=='object')throw Error(message);
    const actual=await provider.readBlocks(receipt.pageId);
    const at=p.after?actual.findIndex(b=>b.id===p.after)+1:0;
    const added=actual.slice(at,at+p.blocks.length);
    if(p.after&&at===0||added.length!==p.blocks.length||!added.every((b,i)=>!p.before.includes(b.id)&&same(b,p.blocks[i])))throw Error(message);
    owned.push(...added);receipt.blocks=owned;receipt.pendingAppend=null;commit();
   }
   // Preflight all managed blocks; never overwrite remote human edits.
   for(const old of owned){
    const remote=await provider.readBlock(old.id);
    if(remote.archived||!same(remote,old)||old.fingerprint&&remote.fingerprint!==old.fingerprint)throw Error(message);
   }
   const page=await provider.readPage(receipt.pageId);
   if(receipt.pendingTitle){
    if(page.title===receipt.pendingTitle){receipt.title=page.title;receipt.pendingTitle=null;commit();}
    else if(page.title===receipt.title){receipt.pendingTitle=null;commit();}
    else throw Error(message);
   }
   if(page.title!==receipt.title)throw Error(message);
   if(title!==receipt.title){receipt.pendingTitle=title;commit();await provider.renamePage(receipt.pageId,title);receipt.title=title;receipt.pendingTitle=null;commit();}
   for(let i=0;i<owned.length;i++){
    const block=desired[i]||{type:'paragraph',text:''};
    if(!same(owned[i],block)){
     receipt.pendingUpdate={index:i,id:owned[i].id,block};commit();
     owned[i]=await provider.updateBlock(owned[i].id,block);
     receipt.blocks=[...owned];receipt.pendingUpdate=null;commit();
    }
   }
   while(desired.length>owned.length){
    const next=desired.slice(owned.length,owned.length+100),before=await provider.readBlocks(receipt.pageId);
    receipt.pendingAppend={after:owned.at(-1)?.id||before.at(-1)?.id||'',blocks:next,before:before.map(b=>b.id)};commit();
    let added;
    try{added=await provider.appendBlocks(receipt.pageId,next,receipt.pendingAppend.after);}
    catch(e){if(!e.uncertain){receipt.pendingAppend=null;commit();}throw e;}
    owned.push(...added);receipt.blocks=[...owned];receipt.pendingAppend=null;commit();
   }
   // Verify every write before acknowledging this local revision.
   for(const b of owned){const remote=await provider.readBlock(b.id);if(remote.archived||!same(remote,b)||remote.fingerprint!==b.fingerprint)throw Error(message);}
   receipt={...receipt,provider:provider.name,rootId:library.root,libraryUrl:provider.url(library.root),revision,state:'synced',error:''};
   save(receipt);return store.read(id).record.notion;
  });
 }catch(e){save({state:'failed',error:message});return store.read(id).record.notion;}
}
function statusContext(options){
 if(!options)return null;
 const provider=cloud(configuration(options));
 return {provider,connected:!!provider.connected()};
}
function status(record,options,precomputed){
 const ctx=precomputed===undefined?statusContext(options):precomputed;
 if(!ctx||!ctx.connected)return {state:'local'};
 const n=receiptFor(record,ctx.provider.name);
 return {state:n.state==='failed'?'failed':n.state==='synced'&&n.revision===record.revision?'synced':'syncing',
  ...(n.libraryUrl?{url:n.libraryUrl}:{}),...(n.state==='failed'?{message}:{})};
}
module.exports={sync,status,statusContext,blocks,lines};
