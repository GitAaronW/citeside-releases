'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto');
function dataDirectoryId(dir) {
  let canonical = path.resolve(dir);
  try { canonical = fs.realpathSync(canonical); } catch {}
  return crypto.createHash('sha256').update(canonical).digest('hex');
}
function writePid(dir, pid = process.pid) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'server.pid');
  require('./durable-json').writeText(file, String(pid));
}
function clearPid(dir, pid = process.pid) {
  const file = path.join(dir, 'server.pid');
  try { if (fs.readFileSync(file, 'utf8').trim() === String(pid)) fs.unlinkSync(file); } catch {}
}
function registerPid(dir) {
  writePid(dir);
  process.once('exit', () => clearPid(dir));
}
module.exports = { dataDirectoryId, writePid, clearPid, registerPid };
