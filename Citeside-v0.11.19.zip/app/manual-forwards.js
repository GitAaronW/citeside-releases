'use strict';
// 自我进化闭环 1c（总纲「自我进化闭环」步 1c，Aaron 2026-10-24 口头「开做」）：会后他在 Notion / Slack 自己做了什么，对回处理台的卡。
// 口径（Aaron 2026-10-24 原话「我会后在 Slack 发的消息，跟卡片有什么区别？也是我自己手动输的」）：会后他自己敲的、跟这场会有关的，
// 对得上卡还是对不上卡都算 M4 搬运。对得上卡 = Citeside出了卡他没用（派发没赢）；对不上卡 = Citeside该出卡没出（同时是 M2 漏报候选）。
// 做法：会后 72 小时窗口内，用他自己的只读授权（app/tools 的 slack.search「from:me」、notion.search）：
//   ① 逐卡搜：命中（时间在窗口内 + 卡词 ≥ MIN_SCORE 出现在消息里）就在卡上记 manualForward={source, ref, url, at, score}；
//   ② 整场搜：他窗口内发的其余消息 / 改的页面，词条有 ≥ MIN_SCORE 落在这场会的词里（标题 + 总结 + 卡文），记进 doc.manualScan.uncarded；
// 文档上记 manualScan。M4 manualForwards = 命中的卡 + uncarded 条数。
// 只读、只本机：不发任何东西，不写 Notion / Slack；没有授权就记 scan 失败原因，M4 照旧算 null。
// 词重合用字面 bigram，不调模型：这是记账不是判断，宁可漏（score 低不算）不可错算成「他搬运了」。
const fs = require('fs'), path = require('path');

const WINDOW_MS = 72 * 3600e3;          // 会后多久内算「这场会的搬运」
const LEAD_MS = 60 * 60e3;              // 会还没结束就先发出去的也算（提前 1 小时）
const SCAN_TTL_MS = 24 * 3600e3;        // 同一场会两次扫描至少隔多久
const MIN_SCORE = 0.5;                  // 卡片词条里至少一半出现在那条消息 / 页面标题里
const PER_CARD_LIMIT = 8;
const STOP = new Set(['的', '了', '是', '在', '和', '与', '把', '对', '给', '到', '就', '都', '会', '要', '去', '来', '这个', '那个', '我们', '他们', '一下', '一个', '然后', '以及', '或者', 'the', 'and', 'for', 'with', 'that', 'this', 'from', 'about', 'will', 'should']);

// 词条：中文按双字切，拉丁按整词（≥3 字母）；数字保留。去停用词。
function terms(s) {
  const out = new Set(); const str = String(s || '').toLowerCase();
  for (const m of str.match(/[a-z][a-z'-]{2,}|\d[\d.%]*/g) || []) if (!STOP.has(m)) out.add(m);
  const cjk = str.replace(/[^一-鿿]+/g, ' ').split(' ').filter(Boolean);
  for (const seg of cjk) { const ch = [...seg]; for (let i = 0; i + 1 < ch.length; i++) { const bg = ch[i] + ch[i + 1]; if (!STOP.has(bg) && !STOP.has(ch[i]) && !STOP.has(ch[i + 1])) out.add(bg); } }
  return out;
}
function score(cardTerms, text) {
  if (!cardTerms.size) return 0;
  const t = terms(text); let hit = 0;
  for (const k of cardTerms) if (t.has(k)) hit++;
  return hit / cardTerms.size;
}
// 卡片的「说法」：卡文 + 他改过的草稿标题 / 正文（草稿是他要发出去的话，命中率最高）
function cardText(card) {
  const d = card && card.draft && typeof card.draft === 'object' ? card.draft : null;
  return [card && card.text, d && d.title, d && (d.description || d.body || d.text)].filter(x => typeof x === 'string' && x.trim()).join('\n');
}
// 这场会的「说法」：标题 + 会后总结 + 全部卡文。整场搜用它判断一条消息是不是关于这场会。
function meetingText(sess, doc) {
  const parts = [sess && sess.title, sess && sess.topicTitle, sess && typeof sess.summary === 'string' && sess.summary.slice(0, 4000)];
  for (const c of (doc && doc.cards) || []) parts.push(cardText(c));
  for (const h of (sess && sess.highlights) || []) parts.push(typeof h === 'string' ? h : h && h.text);
  return parts.filter(x => typeof x === 'string' && x.trim()).join('\n');
}
// 反向覆盖：消息自己的词有多少落在会议词里（消息短、会议长，正向算会被会议长度稀释）。词太少的消息（≤3 条）不判，避免「好的」「收到」误算。
const MIN_MSG_TERMS = 4;
function coverage(meetingTerms, text) {
  const t = terms(text); if (t.size < MIN_MSG_TERMS || !meetingTerms.size) return 0;
  let hit = 0; for (const k of t) if (meetingTerms.has(k)) hit++;
  return hit / t.size;
}
// Notion 本人 id：OAuth 绑定里的 workspaceId:ownerUserId 后半段，或 env NOTION_USER_ID（内部集成令牌没有授权人）。拿不到就不算 Notion 的任何一页。
function notionMe(env, dataDir) {
  if (env && env.NOTION_USER_ID) return String(env.NOTION_USER_ID);
  try { const ext = require('./tools/oauth-link').boundExternalId('notion', dataDir); return ext ? ext.split(':').slice(1).join(':') : ''; } catch (e) { return ''; }
}
// Slack 搜索已经 from:me；Notion 页要核对 last_edited_by（没有就 created_by）等于本人。核不了的不算，并在 sources.notion.skippedAuthor 计数。
function mine(src, it, me) {
  if (src !== 'notion') return true;
  if (!me) return false;
  const who = it.editedBy || it.createdBy || '';
  return !!who && who === me;
}
// 写回只合并自己这两样（卡上的 manualForward、文档的 manualScan）到磁盘上最新的那份，不整篇替换：扫描跑着的时候他可能正在改卡草稿。
function commit(file, ours) {
  let fresh = null; try { fresh = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) {}
  if (!fresh || !Array.isArray(fresh.cards)) fresh = ours;
  else {
    const byId = new Map(); for (const c of ours.cards || []) if (c && c.id && c.manualForward) byId.set(c.id, c.manualForward);
    for (const c of fresh.cards) if (c && c.id && byId.has(c.id) && !c.manualForward) c.manualForward = byId.get(c.id);
    fresh.manualScan = ours.manualScan;
  }
  writeDoc(file, fresh);
  return fresh;
}
function readSession(dataDir, sessionId) {
  try { return JSON.parse(fs.readFileSync(path.join(dataDir, 'pending', 'sess-' + sessionId + '.json'), 'utf8')); } catch (e) { return null; }
}
// 搜索词：草稿标题优先，否则卡文第一句前 24 字（Slack / Notion 的搜索都是全文匹配，短句命中稳）
function queryFor(card) {
  const d = card && card.draft && typeof card.draft === 'object' ? card.draft : null;
  const base = (d && typeof d.title === 'string' && d.title.trim()) || String((card && card.text) || '').split(/[\n。！？!?；;]/)[0];
  return [...base.trim()].slice(0, 24).join('').replace(/["“”]/g, '').trim();
}
// 草稿标题和卡文第一句各搜一次（去重）：只用标题会漏掉只在正文里出现的说法（Codex r5）
function queriesFor(card) {
  const out = [], push = q => { q = q && q.trim(); if (q && !out.includes(q)) out.push(q); };
  push(queryFor(card));
  push(queryFor({ text: card && card.text }));
  return out;
}
const dayOf = iso => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? '' : d.toISOString().slice(0, 10); };
function inWindow(at, endedAt) {
  const t = Date.parse(at || ''), e = Date.parse(endedAt || '');
  if (!t || !e) return false;
  return t >= e - LEAD_MS && t <= e + WINDOW_MS;
}
function due(doc, endedAt, now = Date.now()) {
  const e = Date.parse(endedAt || ''); if (!e) return { ok: false, why: '没有结束时间' };
  if (now > e + WINDOW_MS + SCAN_TTL_MS) return { ok: false, why: '窗口已过' };
  const last = Date.parse((doc && doc.manualScan && doc.manualScan.at) || '');
  if (last && now - last < SCAN_TTL_MS) return { ok: false, why: '上次扫描不到 24 小时' };
  return { ok: true };
}

// tools：{ call(name,args,ctx) }（默认 app/tools）；ctx 带 env / dataDir / fetchImpl。返回 { scanned, matched, slack, notion } 或 { skipped, why }。
async function scan({ actionsDir, dataDir, sessionId, endedAt, env = {}, log = () => {}, tools, fetchImpl, now = Date.now(), force = false, session }) {
  const actions = require('./actions');
  const doc = actions.read(actionsDir, sessionId);
  if (!doc || !Array.isArray(doc.cards)) return { skipped: true, why: '这场会没有处理台' };
  if (!force) { const d = due(doc, endedAt, now); if (!d.ok) return { skipped: true, why: d.why }; }
  const T = tools || require('./tools');
  const ctx = { env, dataDir, caller: 'manual-forwards', log, ...(fetchImpl ? { fetchImpl } : {}) };
  const me = notionMe(env, dataDir);
  const sources = { slack: { ok: true, calls: 0, hits: 0 }, notion: { ok: true, calls: 0, hits: 0, skippedAuthor: 0, ...(me ? {} : { authorUnknown: '拿不到 Notion 授权人 id，Notion 的页一律不算' }) } };
  const after = dayOf(new Date(Date.parse(endedAt) - LEAD_MS).toISOString());
  const candidates = doc.cards.filter(c => c && c.state !== 'sent' && !c.manualForward && cardText(c));   // 全部候选卡都搜，不截断（Codex r5）
  let matched = 0; const seen = new Set();   // 已对上卡的消息 ref，整场搜时跳过
  for (const card of candidates) {
    const qs = queriesFor(card); if (!qs.length) continue;
    const ct = terms(cardText(card));
    let best = null;
    const plan = [];
    for (const q of qs) plan.push(['slack', { query: q + ' from:me' + (after ? ' after:' + after : ''), limit: PER_CARD_LIMIT }], ['notion', { query: q, limit: PER_CARD_LIMIT }]);
    for (const [src, args] of plan) {
      if (!sources[src].ok) continue;
      let r; try { r = await T.call(src + '.search', args, ctx); } catch (e) { r = { ok: false, error: String(e.message || e) }; }
      sources[src].calls++;
      if (!r || !r.ok) { sources[src].ok = false; sources[src].error = String((r && r.error) || '未知').slice(0, 160); continue; }
      for (const it of r.items || []) {
        if (!inWindow(it.at, endedAt)) continue;
        if (!mine(src, it, me)) { sources.notion.skippedAuthor++; continue; }
        const s = score(ct, [it.text, it.title].filter(Boolean).join('\n'));
        if (s < MIN_SCORE) continue;
        if (it.ref) seen.add(it.ref);   // 够分的都算「在说某张卡」，哪怕不是这张卡的最佳：整场搜时不再当无卡内容（Codex r3）
        if (!best || s > best.score) best = { source: src, ref: it.ref || '', url: it.url || '', at: it.at || '', score: +s.toFixed(2), where: it.channel || it.title || '' };
      }
    }
    if (best) { card.manualForward = { ...best, matchedAt: new Date(now).toISOString() }; sources[best.source].hits++; matched++; if (best.ref) seen.add(best.ref); }
    if (!sources.slack.ok && !sources.notion.ok) break;   // 两边都没授权 / 都挂了：别再一张张空转
  }
  for (const c of doc.cards) if (c && c.manualForward && c.manualForward.ref) seen.add(c.manualForward.ref);
  // ② 整场搜：他窗口内自己发的其余内容，有没有在说这场会
  const sess = session || (dataDir ? readSession(dataDir, sessionId) : null);
  const mt = terms(meetingText(sess, doc));
  const uncarded = [];
  const title = String((sess && (sess.topicTitle || sess.title)) || '').trim();
  const sweeps = [['slack', { query: 'from:me' + (after ? ' after:' + after : ''), limit: 20 }]];
  if (title.length >= 2) sweeps.push(['notion', { query: [...title].slice(0, 40).join(''), limit: 8 }]);
  if (mt.size) for (const [src, args] of sweeps) {
    if (!sources[src].ok) continue;
    let r; try { r = await T.call(src + '.search', args, ctx); } catch (e) { r = { ok: false, error: String(e.message || e) }; }
    sources[src].calls++;
    if (!r || !r.ok) { sources[src].ok = false; sources[src].error = String((r && r.error) || '未知').slice(0, 160); continue; }
    for (const it of r.items || []) {
      const ref = it.ref || (it.id ? 'notion:' + it.id : '');
      if (!ref || seen.has(ref) || !inWindow(it.at, endedAt)) continue;
      if (!mine(src, it, me)) { sources.notion.skippedAuthor++; continue; }
      const body = [it.title, it.text].filter(Boolean).join('\n');
      const s = coverage(mt, body);
      if (s < MIN_SCORE) continue;
      seen.add(ref); sources[src].hits++;
      uncarded.push({ source: src, ref, url: it.url || '', at: it.at || '', score: +s.toFixed(2), where: it.channel || it.title || '', text: [...body.replace(/\s+/g, ' ')].slice(0, 80).join('') });
    }
  }
  doc.manualScan = { at: new Date(now).toISOString(), endedAt: endedAt || '', candidates: candidates.length, matched, uncarded, slack: sources.slack, notion: sources.notion };
  commit(actions.fileOf(actionsDir, sessionId), doc);
  log('手动转发扫描 ' + sessionId + '：候选 ' + candidates.length + ' 对上卡 ' + matched + ' 无卡 ' + uncarded.length + (sources.slack.ok ? '' : '；Slack ' + sources.slack.error) + (sources.notion.ok ? '' : '；Notion ' + sources.notion.error));
  return { scanned: true, candidates: candidates.length, matched, uncarded: uncarded.length, slack: sources.slack, notion: sources.notion };
}
function writeDoc(file, obj) { fs.mkdirSync(path.dirname(file), { recursive: true }); require('./durable-json').write(file, obj, { space: 2 }); }

// pending 里已经结束（end ≤ now）、结束不超过 maxAgeMs 的会。end 在未来的是还没开完或时间写错，不扫。
function recentEnded(pendingDir, maxAgeMs, now = Date.now()) {
  const out = []; let names = [];
  try { names = fs.readdirSync(pendingDir); } catch (e) { return out; }
  for (const f of names) {
    if (!/^sess-(?!trial-).*\.json$/.test(f)) continue;
    let x; try { x = JSON.parse(fs.readFileSync(path.join(pendingDir, f), 'utf8')); } catch (e) { continue; }
    const end = (x && x.end) || ''; const t = Date.parse(end) || 0;
    if (!t || t > now || now - t > maxAgeMs) continue;
    out.push({ id: String((x && x.id) || f.replace(/^sess-|\.json$/g, '')), endedAt: end });
  }
  return out;
}
// 定时扫：pending 里最近结束、还在窗口内的会。sessions = [{id, endedAt}]
async function sweep({ sessions, ...rest }) {
  const out = [];
  for (const s of sessions || []) { if (!s || !s.id) continue; try { out.push({ id: s.id, ...(await scan({ ...rest, sessionId: s.id, endedAt: s.endedAt })) }); } catch (e) { out.push({ id: s.id, error: String(e.message || e) }); } }
  return out;
}

module.exports = { scan, sweep, recentEnded, commit, mine, queriesFor, terms, score, coverage, meetingText, queryFor, cardText, inWindow, due, WINDOW_MS, SCAN_TTL_MS, MIN_SCORE, MIN_MSG_TERMS };
