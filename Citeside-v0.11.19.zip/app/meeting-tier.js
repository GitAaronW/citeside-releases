'use strict';
// 会议产出分档：skip / light / deep（Aaron 2026-10-24「生成的文档要按 task 难度和对用价值判断，匹配 Effort 和等待时间」）。
// 门槛来自本机 153 场真实会话的特征分布（交接笔记「产出分档方案」§二）：skip 113 / deep 34 / light 6，三场金标准会都落 deep
// （「像不像会」规则加入后只有 mvcaywvl6h4w 一场 deep → skip，replays/tier/tier-split-v3.txt）。
// 校准（2026-10-24，16 场各跑两条链、盲判）：light 链只省 9% 时间，deep 在 14/16 场更好、自动判 light 的 6 场 deep 全赢，
// 所以会后链把 light 当 deep 跑（meeting-pipeline.chain_tier），这里的 light 只剩会中「只升不降」的中间态和回看页标签。
// 这里只做判断，不调模型、不碰文件。

const THRESHOLDS = Object.freeze({
  skipChars: 800,          // 转写不足 800 字：试音、误启动（153 场里 112 场）
  skipShortMin: 5, skipShortChars: 1500,   // 不到 5 分钟且不到 1500 字也算
  entities: 5, entitiesLatin: 15, latinRatio: 80,   // 拉丁专名数；英文为主的转写句首大写词多，门槛抬高
  decisions: 3, numbers: 8, absolutes: 3,
  // 像不像会（见 unlikeMeeting）：占比 ≥ 30% 的语言各自要像对话——中文每千汉字「你 / 我们」≥ 10（真实 30 场中文会最低 30.3）；
  // 英文每百个小写单词 you / we ≥ 4（12 场英文会最低 8.0），不足 40 个小写单词不判（中文会里的 OPPO / SM7750 这类名字不是英文对话）。
  // 念稿 / 放视频 / 报数：mvcaywvl6h4w 中文旁白 1.5、报数 0。
  questions: 3, questionShare: 0.08,   // 有来有回的问答：问句行数 / 占全部行的比例
  talkShare: 0.3, talkZh: 10, talkEn: 4, talkEnWords: 40,
});
const ETA_SEC = Object.freeze({ skip: 0, light: 300, deep: 300 });   // 预计等待的默认值；有 usage.jsonl 的 p50 时由调用方传入覆盖。light 会后按 deep 跑，等待同 deep

const ENTITY = /\b[A-Z][A-Za-z0-9]{2,}(?:[ -][A-Z0-9][A-Za-z0-9]{1,})*\b/g;
// 中文专名：没有大写可认，用词表（厂商 / 产品 / 平台 / 芯片，153 场扫描里命中的在前：苹果 51 次、高通 46、豆包 28、飞书 23、谷歌、传音、华为、微信、小米…）。
// 审核 5461e47f：只认拉丁专名会漏判中文会；通用词（智能体 / 大模型 / 手机）不进词表，后缀模式（X手机 / X方案）在真实转写里全是噪音。
const ZH_ENTITY = /华为|荣耀|小米|红米|一加|真我|魅族|传音|联想|中兴|努比亚|苹果|三星|谷歌|微软|亚马逊|英伟达|英特尔|高通|联发科|紫光|展锐|海思|麒麟|天玑|骁龙|昇腾|寒武纪|地平线|歌尔|立讯|舜宇|京东方|富士康|比亚迪|字节|抖音|豆包|腾讯|微信|阿里|通义|千问|百度|文心|智谱|月之暗面|讯飞|商汤|旷视|阶跃|百川|面壁|美团|滴滴|快手|小红书|微博|钉钉|飞书|元宝|混元|盘古|鸿蒙|澎湃|索尼|诺基亚|特斯拉|蔚来|理想汽车|小鹏/g;
const ENTITY_STOP = new Set(['The', 'This', 'That', 'And', 'But', 'What', 'How', 'Why', 'When', 'Okay', 'Yes', 'API', 'APP', 'App', 'Agent', 'Agents', 'Demo', 'Skill', 'Model', 'Phone', 'Email', 'Chat', 'Web', 'Cloud', 'Mac', 'PC', 'Google', 'Apple', 'Microsoft', 'Nothing', 'OK']);
const DECISION = /(定了|决定|拍板|敲定|延期|推迟|提前到|改到|截止|deadline|排期|上线|发布|立项|评审|负责人|谁来|下周[一二三四五]?|本周[一二三四五]?|月底|季度)/g;
const ABSOLUTE = /(?:市面上|业界|行业[里内]?|国内|国外|全球|世界上|目前|现在)(?:还?没有|不存在|没人|无人|没有人)|没有?(?:人|厂商|公司|家|别人)(?:做|在做|做过|能|会|有)|不存在|唯一(?!的?(?:问题|区别|差别|担心|风险|难点|麻烦|办法))|首个|首创|首款|第一[个家款批]|(?:全球|行业|业内|国内|世界)(?:首[个家款批]?|第一[个家款批]?|最早|最大)|最早|独家|只有我们|only one|first ever|first to/gi;
const NUM = /(?<![\d:.])\d{2,}(?:\.\d+)?%?(?![\d:])/g;   // 两位以上的数，排除 10:30 这种时间
const TEST_TEXT = /^(测试|喂|哈喽|hello|hi|一二三|1 ?2 ?3|试一下|听得到吗|test)/i;
// 对话词：会是人跟人说话，中文满篇「你 / 我们」，英文满篇 you / we；念稿、播放的视频、报数里没有。
const TALK_ZH = /我们|咱们|大家|你们|您|你|我/g;
const TALK_EN = /\b(?:you|we|i|us|let's|our|your|me|my)\b/gi;
const EN_WORD = /\b[a-z][a-z']+\b/g;   // 小写英文单词：说出来的英文；大写 / 带数字的（OPPO、SM7750）是名字
const DEEP_TITLE = /(评审|review|决策|kickoff|启动会|交流|对标|复盘|谈判|汇报)/i;
const TIERS = ['skip', 'light', 'deep'];

// 专名：句首的英文大写词（Friday / Yeah / Can）不算，除非全大写、带数字或多词（OPPO、ESP32、Meta Muse Gadgets）；中文按词表。
function countEntities(text) {
  const seen = new Set();
  for (const m of text.matchAll(ZH_ENTITY)) seen.add(m[0]);
  for (const m of text.matchAll(ENTITY)) {
    const e = m[0]; if (ENTITY_STOP.has(e)) continue;
    const prev = text.slice(0, m.index).replace(/[\s"“「(（]+$/, '').slice(-1);
    const strong = /^[A-Z0-9]{2,}$/.test(e) || /\d/.test(e) || /[ -]/.test(e);
    if (!strong && (!prev || /[.!?。！？\n]/.test(prev))) continue;
    seen.add(e);
  }
  return seen.size;
}

// rows: 转写行 {at(秒), speaker, text}；minutes 可由调用方按 start/end 传入，否则用最后一行的 at。
function featuresOf(rows, { minutes } = {}) {
  const rs = (rows || []).filter(r => r && String(r.text || '').trim());
  const text = rs.map(r => String(r.text)).join('\n');
  const latin = (text.match(/[A-Za-z]/g) || []).length, han = (text.match(/[一-鿿]/g) || []).length;
  const lastAt = rs.reduce((m, r) => Math.max(m, Number(r.at) || 0), 0);
  const perK = (n, base) => Math.round(10000 * n / Math.max(1, base)) / 10;
  const enWords = (text.match(EN_WORD) || []).length;
  return {
    chars: text.replace(/\s/g, '').length, rows: rs.length,
    minutes: Number.isFinite(minutes) ? minutes : lastAt / 60,
    speakers: new Set(rs.map(r => String(r.speaker || r.name || ''))).size,
    entities: countEntities(text), numbers: (text.match(NUM) || []).length,
    decisions: (text.match(DECISION) || []).length, absolutes: (text.match(ABSOLUTE) || []).length,
    latinRatio: Math.round(100 * latin / Math.max(1, latin + han)),
    han, latin, enWords,   // 汉字数 / 拉丁字母数 / 小写英文单词数：对话词密度按各自语言算
    talkZh: perK((text.match(TALK_ZH) || []).length, han),   // 每千汉字的「你 / 我们」
    talkEn: Math.round(1000 * (text.match(TALK_EN) || []).length / Math.max(1, enWords)) / 10,   // 每百个小写英文单词的 you / we
    questions: rs.filter(r => /[?？]|吗[。！!]?$/.test(String(r.text).trim())).length,   // 带问句的行：人跟人之间有来有回
    testText: rs.length > 0 && rs.slice(0, 3).every(r => TEST_TEXT.test(String(r.text).trim())),
  };
}

// 像不像会（Aaron 2026-10-24「不是会的录音被判成 deep」）：占比 ≥ talkShare 的语言各自要像对话，有一种不像就不像。
// 校准 16 场里 mvcaywvl6h4w 是中文旁白 + 英文电影音轨：中文部分每千字「你 / 我们」1.5，英文对白 36.9 过线，所以要每种语言各自过；
// 中文会里夹的英文多是术语（OCR / workspace），占比不到 30% 不看。手工建的特征对象没有 han / latin 时不判。
function unlikeMeeting(f, t) {
  const total = (f.han || 0) + (f.latin || 0); if (!total) return '';
  if (f.han / total >= t.talkShare && (f.talkZh || 0) < t.talkZh) return `不像会：中文每千字「你 / 我们」${f.talkZh || 0} < ${t.talkZh}`;
  if (f.latin / total >= t.talkShare && (f.enWords || 0) >= t.talkEnWords && (f.talkEn || 0) < t.talkEn) return `不像会：英文每百词 you / we ${f.talkEn || 0} < ${t.talkEn}`;
  return '';
}

// 判档。override（本场手动）> env.MEETING_TIER（全局）> 自动。返回 {tier, reason[], etaSec, features}。
function classify(features, { title = '', calTitle = '', override = '', env = {}, eta = ETA_SEC } = {}) {
  const f = features || {}, t = THRESHOLDS, reason = [];
  const done = tier => ({ tier, reason, etaSec: Number.isFinite(eta[tier]) ? eta[tier] : ETA_SEC[tier], features: f });
  if (TIERS.includes(override)) { reason.push('手动：' + override); return done(override); }
  const forced = String(env.MEETING_TIER || '').toLowerCase();
  if (forced === 'deep' || forced === 'light') { reason.push('设置 MEETING_TIER=' + forced); return done(forced); }
  if (f.testText) reason.push('前三句是试音语');
  const heading = `${title} ${calTitle}`;
  // 有会的信号（日历上有这场会、标题像评审、决策词过线、两人以上有来有回地问答）就不看人称词（审核 INTEL-01）
  const dialog = (f.speakers || 0) >= 2 && (f.questions || 0) >= t.questions && f.questions >= t.questionShare * (f.rows || 0);
  const meetingSignal = String(calTitle || '').trim() || DEEP_TITLE.test(heading) || (f.decisions || 0) >= t.decisions || dialog;
  if ((f.chars || 0) < t.skipChars) reason.push(`转写 ${f.chars || 0} 字 < ${t.skipChars}`);
  // 短会规则只拦没有会的信号的录音：10-26 一场 3.5 分钟、6 人有问有答的真会（1014 字）被它整场跳过。
  else if (!meetingSignal && (f.minutes || 0) < t.skipShortMin && f.chars < t.skipShortChars) reason.push(`${Math.round(f.minutes || 0)} 分钟且 ${f.chars} 字`);
  // 复审 f76204b：人称词少、没问句、说话人没分开（大众版没有身份识别）都只是「缺信号」，不足以认定不是会。
  // 所以它只能存疑、不能单独跳过：判 light（会后按 deep 跑），回看页手动改 skip。代价是放视频那类录音（153 场里 1 场）多跑一次分析，
  // 换来不会有一场真会没产出。真跳过只留独立依据：字数太少、时长太短、开头是试音语。
  const unlike = meetingSignal ? '' : unlikeMeeting(f, t);
  if (reason.length) { if (unlike) reason.push(unlike); return done('skip'); }
  if (unlike) { reason.push(unlike + '，存疑继续分析'); return done('light'); }
  if (DEEP_TITLE.test(heading)) reason.push('标题：' + heading.match(DEEP_TITLE)[0]);
  const entMin = (f.latinRatio || 0) >= t.latinRatio ? t.entitiesLatin : t.entities;
  if ((f.entities || 0) >= entMin) reason.push(`专名 ${f.entities}`);
  if ((f.decisions || 0) >= t.decisions) reason.push(`决策词 ${f.decisions}`);
  if ((f.numbers || 0) >= t.numbers) reason.push(`数字 ${f.numbers}`);
  if ((f.absolutes || 0) >= t.absolutes) reason.push(`绝对化断言 ${f.absolutes}`);
  if (reason.length) return done('deep');
  reason.push('没有深度触发');
  return done('light');
}

// 会中用：只升不降（skip → light → deep），升到 deep 那一刻才该建研报器。
function upgrade(current, next) { return TIERS.indexOf(next) > TIERS.indexOf(current) ? next : current; }

module.exports = { featuresOf, classify, upgrade, countEntities, unlikeMeeting, THRESHOLDS, ETA_SEC, TIERS };

// 命令行：会后管线（meeting-pipeline.py）用同一份判据，不在 Python 里再抄一遍正则。
// stdin JSON {transcript, title, calTitle, override, minutes, env, eta} → stdout 一行 {tier, reason, etaSec, features}。
if (require.main === module) {
  let buf = ''; process.stdin.setEncoding('utf8');
  process.stdin.on('data', d => { buf += d; });
  process.stdin.on('end', () => {
    try {
      const j = JSON.parse(buf || '{}');
      const f = featuresOf(j.transcript || j.rows || [], { minutes: Number(j.minutes) });
      process.stdout.write(JSON.stringify(classify(f, { title: j.title || '', calTitle: j.calTitle || '', override: j.override || '', env: j.env || {}, eta: j.eta || ETA_SEC })) + '\n');
    } catch (e) { process.stdout.write(JSON.stringify({ error: String(e && e.message || e) }) + '\n'); process.exitCode = 1; }
  });
}
