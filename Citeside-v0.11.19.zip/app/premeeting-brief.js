'use strict';
const {loadMeetings,terms}=require('./tools/local');
const clean=(v,n=240)=>String(v==null?'':v).replace(/\s+/g,' ').trim().slice(0,n);
const genericTitleTerms=new Set('catch up catchup meeting sync review weekly notes discussion 会议 周会 讨论 评审 材料'.split(' '));
const wordSet=v=>new Set(terms(clean(v,240)).filter(t=>!genericTitleTerms.has(t.toLowerCase())));
const overlap=(a,b)=>{let n=0;for(const x of a)if(b.has(x))n++;return n;};
const meetingUrl=id=>'/seatnote/archive.html?id='+encodeURIComponent(id);
function normalizeEvent(event={}){
 let description=String(event.description||event.agendaText||'');
 // Captured calendar matches may embed the full occurrence in dayEvents.
 // Never borrow another occurrence or choose between conflicting snapshots.
 if(!description.trim()&&event.calendarId&&event.eventId&&Number.isFinite(Date.parse(event.start))){
  const candidates=(Array.isArray(event.dayEvents)?event.dayEvents:[]).filter(e=>e&&e.calendarId===event.calendarId&&e.eventId===event.eventId&&Date.parse(e.start)===Date.parse(event.start));
  const descriptions=[...new Set(candidates.map(e=>String(e.description||e.agendaText||'')).filter(s=>s.trim()))];
  if(descriptions.length===1)description=descriptions[0];
 }
 return {...event,description};
}
function calendarText(value){
 return String(value||'').replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'')
  .replace(/<a\b[^>]*href=["'](https:\/\/[^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi,(_,url,label)=>'['+label.replace(/<[^>]*>/g,'')+']('+url+')')
  .replace(/<br\s*\/?\s*>|<\/(?:p|div|li|h[1-6]|tr)>/gi,'\n').replace(/<[^>]*>/g,'')
  .replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi,(all,key)=>{const names={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:' '};if(key[0]!=='#')return names[key.toLowerCase()]||all;const n=parseInt(key.slice(key[1].toLowerCase()==='x'?2:1),key[1].toLowerCase()==='x'?16:10);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';});
}
function agendaOf(calendar){const raw=calendarText(normalizeEvent(calendar).description).trim();if(!raw)return[];const m=raw.match(/(?:议程|agenda)\s*[：:]\s*([\s\S]+)/i),body=m?m[1]:raw;return body.split(/\n|[；;]/).map(x=>clean(x.replace(/^\s*(?:[-*•]|\d+[.)、])\s*/,''),Number.MAX_SAFE_INTEGER)).filter(x=>x&&!/^(?:https:\/\/\S+|\[[^\]]+\]\(https:\/\/[^)]+\))$/i.test(x));}
function calendarAttendees(calendar={}){return Array.isArray(calendar.attendees)?calendar.attendees:Array.isArray(calendar.attendeeList)?calendar.attendeeList:[];}
function selectPrevious(meetings,current={}){const titleTerms=wordSet((current.calendar&&current.calendar.title)||current.topicTitle||current.title||''),people=new Set(calendarAttendees(current.calendar||{}).map(x=>clean(x&&(x.name||x),80).toLowerCase()).filter(Boolean)),currentStart=Date.parse(current.start||'')||Number(current.start)||Date.now();let best=null;for(const m of meetings){if(!m||m.id===current.id)continue;const at=Date.parse(m.date||'')||0;if(at>=currentStart)continue;const topicHit=overlap(titleTerms,wordSet(m.title));if(!topicHit)continue;const participantHit=(m.participants||[]).filter(x=>people.has(clean(x,80).toLowerCase())).length,score=topicHit*4+participantHit*3;if(!best||score>best.score||(score===best.score&&at>best.at))best={m,score,at};}return best&&best.score>0?best.m:null;}
function readHubFile(dataDir){
 const fs=require('fs'),path=require('path'),local=path.join(dataDir,'state','work-hub','work-hub.json');
 let file=local;
 try{fs.accessSync(local);}catch{if(!process.env.THT_HUB_DIR)return null;file=path.join(process.env.THT_HUB_DIR,'work-hub.json');}
 try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return null;}
}
function eventIdentity(current){const cal=current.calendar||{},ev=cal.event&&cal.event.eventId?cal.event:(cal.eventId?cal:null);return ev&&ev.eventId!=null&&ev.eventId!==''?ev:null;}
function sameEvent(a,b){if(!a||!b||String(a.eventId)!==String(b.eventId))return false;if(a.calendarId&&b.calendarId&&String(a.calendarId)!==String(b.calendarId))return false;return true;}
function matterMembers(hub,current){
 const sources=(hub&&hub.sources)||[],ev=eventIdentity(current),mine=sources.find(s=>s.sessionId&&(s.sessionId===current.id||s.id===current.id));
 let matter=current.matterId||(mine&&mine.matterId)||'';
 if(!matter&&ev){const peer=sources.find(s=>s.sessionId&&s.calendarEvent&&sameEvent(s.calendarEvent,ev)&&s.matterId);matter=peer&&peer.matterId||'';}
 if(!matter&&ev)return sources.filter(s=>s.sessionId&&!s.archived&&s.calendarEvent&&sameEvent(s.calendarEvent,ev));
 if(!matter)return [];
 return sources.filter(s=>s.sessionId&&!s.archived&&(s.matterId===matter||s.sessionId===matter));
}
function parseRefs(raw){if(Array.isArray(raw))return raw;try{const j=JSON.parse(raw||'[]');return Array.isArray(j)?j:[];}catch{return [];}}
function quoteOf(card){const hit=parseRefs(card.source_refs).find(r=>r&&String(r.text||'').trim());return hit?String(hit.text):String(card.text||'');}
function matterLines(dataDir,current){
 const hub=readHubFile(dataDir),members=matterMembers(hub,current),ids=[...new Set(members.map(s=>s.sessionId).filter(Boolean))].slice(0,40),lines=[];
 let cards=[];
 if(ids.length){try{const db=require('./memory').open(dataDir);if(db)cards=db.prepare(`SELECT kind,state,text,meeting_id,source_refs,recorded_at FROM cards WHERE meeting_id IN (${ids.map(()=>'?').join(',')}) ORDER BY recorded_at DESC`).all(...ids);}catch{}}
 const refOf=(meetingId,quote)=>({meetingId:meetingId||'',url:meetingId?meetingUrl(meetingId):'',quote:clean(quote,180)});
 let n=0;
 for(const c of cards){if(c.kind!=='decision'||c.state!=='active')continue;if(n>=3)break;const quote=quoteOf(c);lines.push({kind:'decision',label:'还在生效的决定',text:clean(c.text,180),ref:refOf(c.meeting_id,quote)});n++;}
 const open=new Set(['inbox','proposed','draft','todo','doing','blocked','submitted','parked']),memberIds=new Set(members.map(s=>s.id)),matterIds=new Set(members.map(s=>s.matterId).filter(Boolean));
 for(const t of ((hub&&hub.tasks)||[]).filter(t=>t&&open.has(t.status||'inbox')&&(matterIds.has(t.matterId)||(t.sourceIds||[]).some(id=>memberIds.has(id)))).slice(0,3)){
  const host=members.find(s=>(t.sourceIds||[]).includes(s.id)),quote=((t.sourceRefs||[]).find(r=>r&&r.text)||{}).text||t.text;
  lines.push({kind:'todo',label:'还没做完的待办',text:clean(t.text,180),ref:refOf((host&&host.sessionId)||t.matterId,quote)});
 }
 n=0;
 for(const c of cards){if(c.kind!=='question'||c.state!=='open')continue;if(n>=3)break;const quote=quoteOf(c);lines.push({kind:'open',label:'还没回答的问题',text:clean(c.text,180),ref:refOf(c.meeting_id,quote)});n++;}
 return lines;
}
function build(dataDir,current={}){
 const {meetings,skipped}=loadMeetings(dataDir,{max:80}),previous=selectPrevious(meetings,current),lines=matterLines(dataDir,current);
 const selected=require('./context-pack').selectedContext(dataDir,current,6000);
 for(const doc of (selected.documents||[]).slice(0,6))lines.push({kind:'material',label:doc.title,text:clean(doc.text,300),ref:{url:/^https:\/\//.test(doc.source)?doc.source:'#',path:doc.source,version:doc.version}});
 return{lines,agenda:agendaOf(current.calendar||{}),previous:previous?{id:previous.id,title:previous.title,date:previous.date,url:meetingUrl(previous.id)}:null,scanned:meetings.length,skipped};
}
// Preparation uses existing Hub records and explicit calendar links; no network or model call.
function materials(hub,current,event,options={}){
 // A captured meeting can retain only the calendar identity, without its description.
 // Recover links from that exact occurrence, never from a similar title or another date.
 if(!normalizeEvent(event).description.trim()&&event.calendarId&&event.eventId&&Number.isFinite(Date.parse(event.start))){
  const peers=(hub.sources||[]).filter(s=>s.id!==current.id&&!s.archived&&s.knowledgeRole!=='archive'&&
   !(current.projectId&&s.projectId&&current.projectId!==s.projectId)&&
   s.calendarEvent?.calendarId===event.calendarId&&s.calendarEvent.eventId===event.eventId&&
   Date.parse(s.calendarEvent.start)===Date.parse(event.start)&&normalizeEvent(s.calendarEvent).description.trim());
  // Conflicting snapshots need an explicit refresh rather than an arbitrary winner.
  const descriptions=[...new Set(peers.map(s=>normalizeEvent(s.calendarEvent).description))];
  if(descriptions.length===1)event={...event,description:descriptions[0]};
 }
 const {canonical}=require('./work-hub'),start=Date.parse(event.start),currentWork=options.purpose==='current-work',asOf=Date.parse(options.asOf||new Date().toISOString()),byUrl=new Map(),items=[];
 const safe=v=>{try{const u=new URL(String(v).replace(/\\([_~*])/g,'$1'));return u.protocol==='https:'&&!u.username&&!u.password?u.href:'';}catch{return '';}};
 const sources=hub.sources||[],explicit=new Set(current.relatedIds||[]),reused=new Map();
 // Reuse only a user's confirmed project boundary and a previous explicit material link.
 // Titles and automatic project guesses never establish a cross-meeting relationship.
 if(current.projectManual&&current.projectId){
  for(const prior of sources){
   const priorAt=Date.parse(prior.calendarEvent?.start||prior.date||'');
   if(prior.id===current.id||prior.knowledgeRole==='archive'||!prior.projectManual||prior.projectId!==current.projectId||!prior.calendarEvent||!Number.isFinite(priorAt)||priorAt>=start)continue;
   for(const id of prior.relatedIds||[]){const material=sources.find(s=>s.id===id);if(!material||material.calendarEvent||material.knowledgeRole==='archive'||(material.projectId&&material.projectId!==current.projectId))continue;
    const previous=reused.get(id);if(!previous||priorAt>previous.at)reused.set(id,{sourceId:prior.id,title:clean(prior.title,200),at:priorAt});
   }
  }
 }
 const description=calendarText(normalizeEvent(event).description),linkTitles=new Map();
 for(const row of require('./calendar-material-links').links(description)){const url=safe(row.url);if(url&&canonical(url)!==canonical(event.meetingUrl)){byUrl.set(canonical(url),url);if(!linkTitles.has(canonical(url)))linkTitles.set(canonical(url),row.title);}}
 const calendarUrls=new Set(byUrl.keys());
 for(const s of sources){
  if(s.id===current.id||s.knowledgeRole==='archive')continue;
  const url=safe(s.url),key=canonical(url),linked=explicit.has(s.id)||reused.has(s.id)||(key&&calendarUrls.has(key))||(current.projectManual&&current.projectId&&s.projectManual&&s.projectId===current.projectId);
  if(!linked)continue;
  const at=Date.parse(s.fetchedAt||s.readReceipt?.fetchedAt||s.date||s.created||''),afterMeeting=Number.isFinite(at)&&at>start,eligible=currentWork?(!Number.isFinite(at)||at<=asOf):!afterMeeting;
  const access=require('./task-context-snapshot').sourceProvenance(s).coverage,readBlocked=['inaccessible','refresh_failed'].includes(access);
  const role=({master:'正式主稿 / Master',report:'报告 / Report',evidence:'原始证据 / Evidence',reference:'参考 / Reference'})[s.knowledgeRole]||'';
  items.push({materialPurpose:s.materialPurpose||'unknown',meetingRecord:!!s.sessionId&&s.kind!=='file'&&!!(s.calendarEvent||s.kind==='meeting'||s.summary),sourceId:s.id,title:clean(s.title,200),url:url||'/seatnote/?id='+encodeURIComponent(s.sessionId||s.id),revision:s.revision||0,role,usage:({master:'对照主稿',report:'查阅报告',evidence:'核对原始证据',reference:'讨论参考'})[s.knowledgeRole]||'用途待确认',provenance:key&&calendarUrls.has(key)?'来自本场日历':explicit.has(s.id)?'本场已关联':reused.has(s.id)?'沿用「'+reused.get(s.id).title+'」资料':'来自已确认项目',association:reused.get(s.id)||null,date:s.date||'',access,read:!readBlocked&&!!s.body&&eligible&&s.bodyCoverage?.complete!==false&&s.bodyState!=='partial',bodyState:s.bodyState||null,bodyCoverage:s.bodyCoverage||null,bodyContinuation:s.bodyContinuation||null,afterMeeting,eligible,purpose:currentWork?'current-work':'meeting-evidence',readReceipt:!readBlocked&&s.readReceipt?.bodyFingerprint===require('crypto').createHash('sha256').update(String(s.body||'')).digest('hex').slice(0,24)&&s.readReceipt?.url===s.url?s.readReceipt:null});if(key)byUrl.delete(key);
 }
 for(const url of byUrl.values())items.push({sourceId:'',title:clean(linkTitles.get(canonical(url)),100)||new URL(url).hostname,url,revision:null,role:'',usage:'用途待确认',provenance:'来自本场日历',date:'',read:false});
 // A known internal URL must not reappear as an unclassified calendar fallback.
 // Explicit business duplicates remain visible; conflicting unknown duplicates
 // stay available in structured evidence but are conservatively hidden here.
 const internalUrls=new Set(items.filter(r=>require('./material-purpose').internal(r.materialPurpose)).map(r=>canonical(r.url)).filter(Boolean));
 return items.map(r=>({...r,preparationVisible:!require('./material-purpose').internal(r.materialPurpose)&&!(internalUrls.has(canonical(r.url))&&r.materialPurpose!=='business'),...(internalUrls.has(canonical(r.url))&&r.materialPurpose!=='business'?{displayExclusion:require('./material-purpose').internal(r.materialPurpose)?'internal-material':'conflicting-internal-url'}:{})}));
}
function preparationModule(hub,current,event,options={}){
 const rows=materials(hub,current,event,options),escape=v=>String(v).replace(/[\\\[\]*`]/g,'\\$&').replace(/\s+/g,' '),body=[];
 // The body is for people. Retrieval roles, read receipts and evidence windows stay
 // in Hub sources and the structured materials lookup, never in the default reading surface.
 const visible=rows.filter(r=>r.preparationVisible!==false).filter(r=>/^https:\/\//.test(r.url)||r.meetingRecord);
 // Calendar descriptions may repeat material links inside agenda prose. Remove
 // only explicitly internal URLs there as well; keep the original event intact.
 const {canonical}=require('./work-hub'),{trimUrl,removeLinks}=require('./calendar-material-links');
 const businessUrls=new Set(rows.filter(r=>r.materialPurpose==='business').map(r=>canonical(r.url)));
 const hiddenUrls=new Set(rows.filter(r=>r.preparationVisible===false&&!businessUrls.has(canonical(r.url))).map(r=>canonical(r.url)).filter(Boolean));
 const isHidden=url=>hiddenUrls.has(canonical(trimUrl(url)));
 const agenda=agendaOf(event).map(line=>removeLinks(line,isHidden).trim()).filter(Boolean);

 if(agenda.length)body.push('### 议程',...agenda.map(x=>'- '+escape(x)));
 // People read a title, where it came from and, when known, what it is for:
 // no markup, no file extension, no "purpose unknown" placeholder.
 const readable=r=>clean(String(r.title||'').replace(/<[^>]*>/g,' ').replace(/&nbsp;/g,' ').replace(/\.(?:md|markdown|html?|txt)$/i,'').replace(/[_]+/g,' '),100)||(r.meetingRecord?'会议记录':new URL(r.url).hostname);
 if(visible.length)body.push('### 资料',...visible.map(r=>'- ['+escape(readable(r))+']('+r.url.replace(/\(/g,'%28').replace(/\)/g,'%29')+') — '+[r.usage==='用途待确认'?'':r.usage,r.provenance].filter(Boolean).map(escape).join(' · ')));

 if(!body.length)return null;
 return {id:'premeeting-materials',kind:'note',title:options.purpose==='current-work'?'工作资料':'会前准备',body:body.join('\n'),edited:false,sourceRefs:rows.filter(r=>r.eligible!==false).map(r=>r.sourceId).filter(Boolean)};
}
module.exports={build,agendaOf,selectPrevious,calendarAttendees,materials,preparationModule,normalizeEvent,calendarText};
