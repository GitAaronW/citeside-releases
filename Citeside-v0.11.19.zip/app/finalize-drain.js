'use strict';
// F-02（2026-10-25）：finalize 里等本机转写（mac）/ Deepgram（dg）吐完最后一句。
// 以前是裸 await this.mac.drain()：drain 的 Promise 永不 resolve 时，finalize 卡在这里，
// 后面的 closeAudio / SESSIONS.delete 永远到不了，试听 discard 的 finally 也到不了。
// 现在每一路有界等待：超时或抛错都记一条回执，强制 stop 那一路，然后继续收尾。
// 各实现自己的超时是 6–8 s，外层默认 10 s 只兜「实现自己的超时也没生效」的情况。
const DEFAULT_TIMEOUT_MS = 10000;
const STREAMS = ['mac', 'dg'];
const message = e => String(e?.message || e || 'unknown');

// 只等 timeoutMs；返回 {name, ok, reason?, error?, ms}。永远 resolve，不抛。
function bounded(name, run, timeoutMs) {
  const started = Date.now();
  return new Promise(resolve => {
    let done = false, timer = null;
    const finish = r => { if (done) return; done = true; if (timer) clearTimeout(timer); resolve({ name, ...r, ms: Date.now() - started }); };
    timer = setTimeout(() => finish({ ok: false, reason: 'timeout' }), timeoutMs);
    let p;
    try { p = Promise.resolve(run()); } catch (e) { finish({ ok: false, reason: 'error', error: message(e) }); return; }
    p.then(() => finish({ ok: true }), e => finish({ ok: false, reason: 'error', error: message(e) }));
  });
}

function timeoutOf(session, env = process.env) {
  const own = Number(session?.drainTimeoutMs);
  if (own > 0) return own;
  const fromEnv = Number(env.THT_DRAIN_TIMEOUT_MS);
  if (env.THT_TEST && fromEnv > 0) return fromEnv;
  return DEFAULT_TIMEOUT_MS;
}

// 依次 drain session.mac / session.dg；每一路收完（成功、失败、超时）都置 null，
// 所以重复调用不会再等同一路。返回本次的回执数组，失败的同时追加到 session.drainReceipts。
async function drainStreams(session, { timeoutMs, log = () => {} } = {}) {
  const ms = timeoutMs > 0 ? timeoutMs : timeoutOf(session);
  const receipts = [];
  for (const name of STREAMS) {
    const src = session[name];
    if (!src) continue;
    const r = await bounded(name, () => src.drain(), ms);
    session[name] = null;
    if (!r.ok) {
      // 卡住或抛错的那一路强制放掉（关 socket / 进程），失败只记日志
      try { src.stop?.(); } catch (e) { log(`finalize ${name} stop failed ${session.id} ${message(e)}`); }
      log(`finalize ${name} drain ${r.reason}${r.error ? ' ' + r.error : ''} after ${r.ms}ms ${session.id}`);
    }
    receipts.push(r);
  }
  const failed = receipts.filter(r => !r.ok);
  if (failed.length) session.drainReceipts = [...(session.drainReceipts || []), ...failed];
  return receipts;
}

module.exports = { drainStreams, bounded, timeoutOf, DEFAULT_TIMEOUT_MS };
