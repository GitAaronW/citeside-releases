'use strict';
// 日历内容由本机直连 Google；未配本机密钥时仅授权码、刷新和撤销经过换取服务。
// 桌面应用 OAuth：授权页在 Google 官方页面，回调落在本机 127.0.0.1 的临时端口，PKCE 防截获；
// 令牌只存 dataDir/google-calendar.json（600）。日历只读：列出日历让用户勾选，拉今天起 7 天的日程，
// 转成和飞书 calendar +agenda 一样的原始形状，交给现有的日历匹配。撤销 = 通知 Google 吊销 + 删本机令牌和缓存。
const fs=require('fs'),path=require('path'),crypto=require('crypto'),http=require('http');
const AUTH='https://accounts.google.com/o/oauth2/v2/auth',TOKEN='https://oauth2.googleapis.com/token',REVOKE='https://oauth2.googleapis.com/revoke',API='https://www.googleapis.com/calendar/v3';
// 最小只读：日历列表 + 日程只读，外加登录身份（显示连的是哪个账号）
const SCOPES=['openid','email','https://www.googleapis.com/auth/calendar.calendarlist.readonly','https://www.googleapis.com/auth/calendar.events.readonly'];
const AUTH_TIMEOUT_MS=10*60e3,CACHE_MS=60e3;
const b64url=buf=>buf.toString('base64').replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');

function create({dataDir,env=()=>({}),fetchImpl=(...a)=>fetch(...a),now=()=>Date.now(),open=url=>require('child_process').execFile('/usr/bin/open',[url],()=>{})}={}){
 const file=path.join(dataDir,'google-calendar.json');
 let pending=null,cache=null,authError='',accountConfigured=false,accountConfigCheckedAt=0,verificationError='';
 const read=()=>{try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return null;}};
 const write=v=>{require('./durable-json').write(file,v);};
 const client=()=>{const e=env()||{};return {id:String(e.GOOGLE_OAUTH_CLIENT_ID||'').trim(),secret:String(e.GOOGLE_OAUTH_CLIENT_SECRET||'').trim()};};
 const exchangeUrl=()=>{const e=env()||{};return String(e.OAUTH_EXCHANGE_URL||e.THT_OAUTH_EXCHANGE_URL||process.env.THT_OAUTH_EXCHANGE_URL||'').replace(/\/+$/,'');};
 const useExchange=()=>!client().secret&&!!exchangeUrl();
 const configured=()=>!!client().id||useExchange()||accountConfigured;
 function issuer(){return useExchange()?{issuer:'exchange',exchangeUrl:exchangeUrl()}:{issuer:'local'};}
 async function exchange(endpoint,body,base=exchangeUrl()){
  let url;
  try{url=new URL(base);}catch{throw Error('Google 换取服务地址无效，请检查配置');}
  const loopback=['localhost','127.0.0.1','[::1]'].includes(url.hostname);
  if(url.username||url.password||url.search||url.hash||!(url.protocol==='https:'||(url.protocol==='http:'&&loopback)))throw Error('Google 换取服务地址必须使用 HTTPS（仅回环地址允许 HTTP）');
  const r=await fetchImpl(base.replace(/\/+$/,'')+endpoint,{redirect:'error',method:body?'POST':'GET',headers:{'Content-Type':'application/json'},...(body?{body:JSON.stringify({provider:'google',...body})}:{}),signal:AbortSignal.timeout(15000)});
  const j=await r.json();
  if(!r.ok||!j.ok)throw Object.assign(Error(j.error||'Google 令牌换取失败'),{status:r.status,code:j.code||''});
  return j;
 }
 async function token(form,origin){
  if(origin.issuer==='account'){const j=await accountRequest('/v1/calendar/google/refresh',{refreshToken:form.refresh_token},origin.accountUrl);const t=j.token||{};return {access_token:t.accessToken,refresh_token:t.refreshToken,expires_in:t.expiresIn,scope:t.scope};}
  if(origin.issuer!=='exchange')return post(TOKEN,form);
  if(!origin.exchangeUrl)throw Error('Google 换取服务地址缺失，请重新连接');
  const j=await exchange('/v1/token',{grant:form.grant_type,code:form.code,redirectUri:form.redirect_uri,codeVerifier:form.code_verifier,refreshToken:form.refresh_token},origin.exchangeUrl);
  const t=j.token;
  return {access_token:t.accessToken,refresh_token:t.refreshToken,expires_in:t.expiresIn,scope:t.scope,id_token:t.idToken};
 }
 async function post(url,form){
  const r=await fetchImpl(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(form).toString(),signal:AbortSignal.timeout(15000)});
  const j=await r.json().catch(()=>({}));
  if(!r.ok)throw Object.assign(Error(j.error_description||j.error||('Google '+r.status)),{status:r.status,code:j.error||''});
  return j;
 }
 async function accountRequest(endpoint,body,origin){
  const e=env()||{},cloud=require('./cloud-account'),session=cloud.loadSession(dataDir,e,now());
  const base=origin||cloud.accountBase(e);
  if(body!==undefined&&(!session||session.url!==base))throw Object.assign(Error('请先登录 Citeside，再单独连接 Google 日历'),{status:401,code:'account_signin_required'});
  const r=await fetchImpl(base+endpoint,{redirect:'error',method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(body!==undefined?{Authorization:'Bearer '+session.token}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
  const j=await r.json();if(!r.ok||j.ok!==true)throw Object.assign(Error('Google 日历授权服务暂不可用'),{status:r.status,code:j.code||'calendar_authorization_unavailable'});return j;
 }
 async function discoverAccount(){
  if(client().id||useExchange())return;
  if(accountConfigured&&accountConfigCheckedAt&&now()-accountConfigCheckedAt<60000)return;
  accountConfigCheckedAt=now();
  try{const j=await accountRequest('/v1/calendar/google/config');accountConfigured=j.configured===true;}catch{accountConfigured=false;}
 }
 async function connectAccount(){
  if(pending)pending.close();
  const verifier=b64url(crypto.randomBytes(32)),challenge=b64url(crypto.createHash('sha256').update(verifier).digest());
  const server=http.createServer();await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  let flow,finished=false,pollTimer,timeoutTimer,settling=false,resolveDone;
  const done=new Promise(resolve=>{resolveDone=resolve;});
  const finish=r=>{if(finished)return;finished=true;clearTimeout(pollTimer);clearTimeout(timeoutTimer);server.close();if(pending?.server===server)pending=null;authError=r.ok?'':String(r.code||r.error||'calendar_authorization_failed');resolveDone(r);};
  pending={server,close:()=>finish({ok:false,error:'cancelled'}),done};
  const complete=async()=>{
   if(finished||settling)return;settling=true;
   try{const j=await accountRequest('/v1/calendar/google/exchange',{flowId:flow.flowId,verifier}),t=j.token||{};
    if(finished)return;
    const allowed=SCOPES.filter(x=>x.startsWith('https://www.googleapis.com/auth/calendar.'));
    if(!t.accessToken||!t.refreshToken||!allowed.every(x=>String(t.scope||'').split(' ').includes(x)))throw Error('calendar_scope_missing');
    write({issuer:'account',accountUrl:require('./cloud-account').accountBase(env()||{}),refreshToken:t.refreshToken,accessToken:t.accessToken,expiresAt:now()+(Number(t.expiresIn)||3600)*1000,scope:t.scope,email:'',calendars:[],selected:[],connectedAt:now()});cache=null;
    try{await listCalendars();}catch{}finish({ok:true});
   }catch{finish({ok:false,error:'calendar_authorization_failed'});}
  };
  server.on('request',(req,res)=>{const u=new URL(req.url,'http://127.0.0.1');res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Cache-Control','no-store');
   if(u.pathname!=='/oauth/callback/google'||u.searchParams.get('accountCalendar')!=='1'||!flow||u.searchParams.get('flowId')!==flow.flowId){res.writeHead(400);res.end('授权回调无效，请回到 Citeside 重试。');return;}
   res.end('<!doctype html><meta charset="utf-8"><title>Citeside</title><p style="font:16px -apple-system;padding:40px">Google 日历授权已返回，请切回 Citeside 查看连接结果。</p>');void complete();
  });
  try{flow=await accountRequest('/v1/calendar/google/start',{challenge,port:server.address().port});
   const url=new URL(flow.authorizationUrl),base=new URL(require('./cloud-account').accountBase(env()||{}));
   if(!flow.flowId||url.origin!==base.origin||url.username||url.password)throw Error('invalid_authorization_url');
   const poll=async()=>{if(finished)return;try{const j=await accountRequest('/v1/calendar/google/poll',{flowId:flow.flowId});if(finished)return;if(j.status==='ready'){await complete();return;}if(['denied','failed'].includes(j.status)){finish({ok:false,error:j.status==='denied'?'access_denied':'calendar_authorization_failed'});return;}}catch{}if(!finished)pollTimer=setTimeout(poll,5000);};
   pending.pollNow=async()=>{if(finished)return;clearTimeout(pollTimer);await poll();};
   timeoutTimer=setTimeout(()=>finish({ok:false,error:'timeout'}),AUTH_TIMEOUT_MS);timeoutTimer.unref?.();open(url.href);pollTimer=setTimeout(poll,5000);return {ok:true,url:url.href,done};
  }catch(e){finish({ok:false,error:'calendar_authorization_unavailable'});throw e;}
 }
 function status(){
  const s=read();
  const failure=s?.error?require('./calendar-failure').classify({code:'invalid_grant'}):verificationError?require('./calendar-failure').classify(verificationError):null;
  const verified=!!s?.refreshToken&&!!s.verifiedAt&&!failure;
  const connectorState=pending?'authorizing':failure?.reason==='reauth'?'reauthorize':failure?'error':verified?'connected':s?.refreshToken?'error':configured()?'disconnected':'unconfigured';
  return {state:connectorState,selectedCount:s?.selected?.length||0,lastSyncAt:s?.lastSyncAt||null,lastVerifiedAt:s?.verifiedAt||null,errorCode:failure?.reason||'',configured:configured(),connected:verified,email:s?.email||'',calendars:s?.calendars||[],selected:s?.selected||[],
   pending:!!pending,authorization:'independent-readonly',configuration:configured()?'ready':'unavailable',action:!configured()?'google-unconfigured':!s?.refreshToken?'google-connect':s?.error?'google-reauthorize':null,authError,error:authError||s?.error||'',...(s?.error?require('./calendar-failure').classify({code:'invalid_grant'}):{})};
 }
 // 点「连接 Google 日历」：起回环监听，打开官方授权页；回调换到令牌后关掉监听
 async function connect(){
  await discoverAccount();
  if(!client().id&&!useExchange()&&accountConfigured)return connectAccount();
  const c=client(),origin=issuer();
  if(origin.issuer==='exchange'){const j=await exchange('/v1/providers',undefined,origin.exchangeUrl);c.id=j.providers?.google?.clientId||'';}
  if(!c.id)throw Object.assign(Error('还没有配置 Google OAuth 客户端'),{status:409});
  if(pending)pending.close();
  authError='';
  const verifier=b64url(crypto.randomBytes(32)),challenge=b64url(crypto.createHash('sha256').update(verifier).digest()),state=b64url(crypto.randomBytes(16));
  const server=http.createServer();
  await new Promise((res,rej)=>{server.once('error',rej);server.listen(0,'127.0.0.1',res);});
  const callbackPath=origin.issuer==='exchange'?'/oauth/callback/google':'/';
  const redirect='http://127.0.0.1:'+server.address().port+(callbackPath==='/'?'':callbackPath);
  let cancel=()=>{};
  const done=new Promise(resolve=>{
   server.on('request',async(req,res)=>{
    const u=new URL(req.url,redirect),reply=(code,msg)=>{res.writeHead(code,{'Content-Type':'text/html; charset=utf-8'});res.end('<!doctype html><meta charset="utf-8"><title>Citeside</title><p style="font:16px -apple-system;padding:40px">'+msg+'</p>');};
    if(u.pathname!==callbackPath){reply(404,'');return;}
    if(u.searchParams.get('state')!==state){reply(400,'授权已过期，请回到Citeside重新点「连接 Google 日历」。');return;}
    if(u.searchParams.get('error')){reply(200,'已取消授权，可以关掉这个页面。');finish({ok:false,error:u.searchParams.get('error')});return;}
    try{
     const t=await token({code:u.searchParams.get('code')||'',client_id:c.id,client_secret:c.secret,redirect_uri:redirect,grant_type:'authorization_code',code_verifier:verifier},origin);
     if(!t.refresh_token)throw Error('Google 没有返回长期令牌');
     const email=idEmail(t.id_token);
     write({...origin,refreshToken:t.refresh_token,accessToken:t.access_token,expiresAt:now()+(Number(t.expires_in)||3600)*1000,scope:t.scope||'',email,calendars:[],selected:[],connectedAt:now()});
     cache=null;
     try{await listCalendars();}catch(e){}
     reply(200,'已连接 Google 日历，可以关掉这个页面回到Citeside。');finish({ok:true});
    }catch(e){reply(200,'连接失败：'+String(e.message).replace(/[<>&]/g,'')+'。请回到Citeside重试。');finish({...require('./calendar-failure').classify(e),code:e.code||'',error:require('./calendar-failure').classify(e).message});}
   });
   const timer=setTimeout(()=>finish({ok:false,error:'timeout'}),AUTH_TIMEOUT_MS);timer.unref?.();
   cancel=()=>finish({ok:false,error:'cancelled'});
   function finish(r){authError=r.ok?'':String(r.code||r.error||'');clearTimeout(timer);server.close();if(pending?.server===server)pending=null;resolve(r);}
  });
  pending={server,close:()=>cancel(),done};
  const url=AUTH+'?'+new URLSearchParams({client_id:c.id,redirect_uri:redirect,response_type:'code',scope:SCOPES.join(' '),code_challenge:challenge,code_challenge_method:'S256',state,access_type:'offline',prompt:'select_account consent'});
  open(url);
  return {ok:true,url,done};
 }
 function idEmail(idToken){try{return JSON.parse(Buffer.from(String(idToken).split('.')[1],'base64url').toString()).email||'';}catch{return '';}}
 async function accessToken(){
  const s=read();if(!s?.refreshToken)return '';
  if(s.accessToken&&s.expiresAt-now()>60e3)return s.accessToken;
  const c=client();
  try{
   const t=await token({refresh_token:s.refreshToken,client_id:c.id,client_secret:c.secret,grant_type:'refresh_token'},s);
   write({...s,accessToken:t.access_token,expiresAt:now()+(Number(t.expires_in)||3600)*1000,error:''});
   return t.access_token;
  }catch(e){
   // 测试模式下长期令牌 7 天过期，或用户在 Google 账号里撤了授权：标出来，让用户重新连接
   if(e.code==='invalid_grant'){write({...s,accessToken:'',error:'Google 授权已失效，请重新连接'});cache=null;return '';}
   throw e;
  }
 }
 async function api(p){
  const tok=await accessToken();if(!tok)throw Object.assign(Error('需要重新授权'),{status:401});
  const r=await fetchImpl(API+p,{headers:{Authorization:'Bearer '+tok},signal:AbortSignal.timeout(15000)});
  const j=await r.json().catch(()=>({}));
  if(!r.ok)throw Object.assign(Error(j.error?.message||('Google Calendar '+r.status)),{status:r.status});
  return j;
 }
 async function listCalendars(){
  const j=await api('/users/me/calendarList?minAccessRole=reader&maxResults=100');if(!j)return [];
  const list=(j.items||[]).map(c=>({id:c.id,name:c.summaryOverride||c.summary||c.id,primary:!!c.primary,timeZone:c.timeZone||''}));
  const s=read();if(!s)return list;
  // 第一次默认只勾主日历；之后保留用户的选择，删掉已经不存在的日历
  const ids=new Set(list.map(c=>c.id));
  const selected=(s.calendars?.length?s.selected:list.filter(c=>c.primary).map(c=>c.id)).filter(id=>ids.has(id));
  write({...s,calendars:list,selected,verifiedAt:now(),error:''});verificationError='';cache=null;
  return list;
 }
 function select(ids){
  const s=read();if(!s?.refreshToken)throw Object.assign(Error('还没有连接 Google 日历'),{status:409});
  const known=new Set((s.calendars||[]).map(c=>c.id));
  write({...s,selected:[...new Set((ids||[]).map(String))].filter(id=>known.has(id))});cache=null;
  return status();
 }
 // 转成飞书 +agenda 的原始形状：现有匹配、会前准备、首页列表都不用分来源
 function toAgenda(ev,cal){
  const start=ev.start?.dateTime||'',end=ev.end?.dateTime||'';
  if(!start||!end)return null; // 全天日程不是会议
  const me=(ev.attendees||[]).find(a=>a.self);
  const video=(ev.conferenceData?.entryPoints||[]).find(p=>p.entryPointType==='video')?.uri||ev.hangoutLink||'';
  return {event_id:'google:'+ev.id,organizer_calendar_id:'google:'+cal,summary:ev.summary||'',description:String(ev.description||'').slice(0,4000),
   start_time:{datetime:new Date(start).toISOString()},end_time:{datetime:new Date(end).toISOString()},
   self_rsvp_status:me?.responseStatus==='declined'?'decline':'accept',location:{name:ev.location||''},vchat:{meeting_url:video},
   event_organizer:{display_name:ev.organizer?.displayName||ev.organizer?.email||''},
   attendees:(ev.attendees||[]).filter(a=>!a.resource).slice(0,60).map(a=>({name:a.displayName||a.email||'',declined:a.responseStatus==='declined'})),
   source:'google'};
 }
 async function agenda(start,end){
  const s=read();if(!s?.refreshToken)return [];
  if(s.error)throw Object.assign(Error('需要重新授权'),{status:401});
  if(!s.selected?.length)return [];
  const key=start.toISOString()+end.toISOString()+s.selected.join(',');
  if(cache&&cache.key===key&&now()-cache.at<CACHE_MS)return cache.items;
  const out=[];
  for(const id of s.selected){
   const q=new URLSearchParams({timeMin:start.toISOString(),timeMax:end.toISOString(),singleEvents:'true',orderBy:'startTime',maxResults:'100'});
   const seenPages=new Set();
   for(;;){
    const j=await api('/calendars/'+encodeURIComponent(id)+'/events?'+q);
    for(const ev of j?.items||[])if(ev.status!=='cancelled'){const a=toAgenda(ev,id);if(a)out.push(a);}
    if(!j?.nextPageToken)break;
    if(typeof j.nextPageToken!=='string'||seenPages.has(j.nextPageToken))throw Error('Calendar pagination did not advance');
    seenPages.add(j.nextPageToken);q.set('pageToken',j.nextPageToken);
   }
  }
  const latest=read();if(!latest||latest.refreshToken!==s.refreshToken||JSON.stringify(latest.selected)!==JSON.stringify(s.selected))return [];
  write({...latest,lastSyncAt:now()});cache={key,at:now(),items:out};
  return out;
 }
 async function readEvent(eventId,calendarId){
  const event=String(eventId||'').replace(/^google:/,''),calendar=String(calendarId||'').replace(/^google:/,'');
  const s=read();
  if(!s?.selected?.includes(calendar))throw Object.assign(Error('Google calendar is not selected'),{status:403});
  if(!event||!calendar)throw Error('Calendar event identity required');
  const value=await api('/calendars/'+encodeURIComponent(calendar)+'/events/'+encodeURIComponent(event));
  if(value.id!==event||value.status==='cancelled'||!value.etag)throw Error('Calendar event identity or version cannot be verified');
  return value;
 }
 async function disconnect(){
  const s=read();if(pending){pending.close();pending=null;}
  try{fs.rmSync(file,{force:true});}catch(e){}
  cache=null;authError='';verificationError='';
  return {...status(),disconnectedLocally:true,revokeConfirmed:false};
 }
 async function route(req,res,u,isLocal){
  const p=u.pathname;if(!p.startsWith('/google/calendar'))return false;
  const send=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(j));return true;};
  if(!isLocal)return send(403,{ok:false,error:'local_only'});
  try{
   if(req.method==='GET'&&p==='/google/calendar'){if(u.searchParams.get('poll')==='1'&&pending?.pollNow){try{await pending.pollNow();}catch{}}await discoverAccount();const s=read();if(s?.refreshToken&&(!s.verifiedAt||now()-s.verifiedAt>60000)){try{await listCalendars();}catch(e){verificationError={code:e.code,status:e.status};}}return send(200,status());}
   if(req.method==='GET'&&p==='/google/calendar/calendars'){await listCalendars();return send(200,status());}
   if(req.method!=='POST')return send(405,{ok:false,error:'method'});
   if(!String(req.headers['content-type']||'').includes('application/json'))return send(415,{ok:false,error:'json_required'});
   let body='';for await(const c of req){body+=c;if(body.length>8192)return send(413,{ok:false,error:'too_large'});}
   let j;try{j=JSON.parse(body||'{}');}catch{return send(400,{ok:false,error:'bad_json'});}
   if(p==='/google/calendar/connect'){const r=await connect();return send(200,{ok:true,url:r.url});}
   if(p==='/google/calendar/cancel'){if(pending)pending.close();return send(200,{ok:true,...status()});}
   if(p==='/google/calendar/refresh'){if(pending?.pollNow){try{await pending.pollNow();}catch{}}try{await listCalendars();const start=new Date(now());await agenda(start,new Date(start.getTime()+7*86400000));}catch(e){verificationError={code:e.code,status:e.status};}return send(200,{ok:true,...status()});}
   if(p==='/google/calendar/select')return send(200,select(j.ids));
   if(p==='/google/calendar/disconnect')return send(200,await disconnect());
   return send(404,{ok:false,error:'not_found'});
  }catch(e){return send(e.status&&e.status<600?e.status:500,{...require('./calendar-failure').classify(e),error:require('./calendar-failure').classify(e).message});}
 }
 // 会前准备要参会人：Google 的名单在拉日程时已经带回来了，不再单独请求
 function attendeesOf(eventId){const ev=(cache?.items||[]).find(x=>x.event_id===eventId);return ev?ev.attendees.map(a=>({name:a.name,open_id:'',declined:a.declined})):null;}
 return {status,connect,readEvent,attendeesOf,listCalendars,select,agenda,disconnect,route,toAgenda,accessToken,SCOPES,connected:()=>!!read()?.refreshToken};
}
module.exports={create,SCOPES};
