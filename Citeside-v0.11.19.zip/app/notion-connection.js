'use strict';
// Shared synchronous status: only a verified relay counts, never CLI presence alone.
const link = require('./tools/oauth-link');
const auth = require('./notion-auth');
const bridge = require('./notion-mcp-bridge');
const tokenOf = env => String(env?.NOTION_TOKEN || '').trim();
function relayFor(ctx = {}) {
  if (ctx.env?.NOTION_DISCONNECTED === '1' || ctx.notionRelay === false || ctx.notionMcpNative ||
      (!ctx.notionRelay && (ctx.fetchImpl || tokenOf(ctx.env) || link.hasBinding('notion', ctx.dataDir)))) return null;
  return ctx.notionRelay || {
    connected: () => bridge.cliCached(ctx).length > 0 || require('./notion-relay').connected(),
    available: async () => (await bridge.cliDetect(ctx)).length > 0,
    request: (method, endpoint, body) => bridge.cliRequest(ctx, method, endpoint, body),
  };
}
function state(ctx = {}) {
  const relayConnected = !!relayFor(ctx)?.connected?.();
  const mcpConnected = bridge.connected(ctx);
  const oauthConnected = link.hasBinding('notion', ctx.dataDir);
  const tokenConfigured = !!tokenOf(ctx.env);
  const connected = relayConnected || mcpConnected || auth.configured(ctx);
  const cli = bridge.cliStatus(ctx);
  if (oauthConnected || tokenConfigured || ctx.env?.NOTION_DISCONNECTED === '1' || !relayFor(ctx)) { cli.cliProvider = ''; cli.cliEffectiveKey = ''; }
  return { connected, ...cli, relayConnected, mcpConnected, oauthConnected, tokenConfigured };
}
module.exports = { relayFor, state };
