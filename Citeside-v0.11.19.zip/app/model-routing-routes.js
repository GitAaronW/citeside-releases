'use strict';
// The existing local-origin and relay-token checks protect this configuration API.
module.exports = async function route(req, res, url, { isLocal, tokenOk, settings }) {
  if (url.pathname !== '/setup/model-routing') return false;
  const send = (code, body) => {
    res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(body)); return true;
  };
  if (!isLocal || !tokenOk(req.headers['x-tht-token'])) return send(403, { errorCode: 'routing_local_token_required' });
  const store = settings.routing;
  if (req.method === 'GET') { store.load(); return send(200, { ...store.status(), config: store.document() }); }
  if (req.method !== 'PUT') return send(405, { errorCode: 'method_not_allowed' });
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body) > 262144) return send(413, { errorCode: 'routing_config_too_large' });
  }
  let input; try { input = JSON.parse(body); } catch { return send(400, { errorCode: 'routing_config_invalid' }); }
  const result = store.update(input);
  return send(result.ok ? 200 : 400, result);
};
