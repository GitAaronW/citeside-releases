'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
function allowed(executable,home,dev){
 if(dev==='1')return true;
 const base=path.join(home,'Library/Application Support/Citeside/program');
 const resolve=p=>{try{return fs.realpathSync(p);}catch{return path.resolve(p);}};
 return resolve(executable).startsWith(resolve(base)+path.sep);
}
// node --test 下的子进程（启动器回归测试从临时目录起）放行，也不弹系统对话框。
function enforce(file){if(process.env.NODE_TEST_CONTEXT||allowed(file,os.homedir(),process.env.THT_DEV))return;
 const message='这份Citeside不在正式安装目录，已停止启动。请打开正式安装版；开发调试需显式设置 THT_DEV=1。';
 console.error(message);
 if(process.platform==='darwin')try{require('node:child_process').execFileSync('/usr/bin/osascript',['-e','display alert "Citeside启动已拦截" message '+JSON.stringify(message)],{stdio:'ignore'});}catch{}
 process.exit(78);
}
module.exports={allowed,enforce};
