'use strict';
// Selection rides on the existing judgement call. No extra model or inferred edges.
const policy=' For an exact quantitative comparison you may use {kind:"numeric-comparison",metric:"exact metric",unit:"ms",sourceId:"cited-id",quote:"the complete original source row",points:[{label:"exact label",valueText:"120"},{label:"other exact label",valueText:"300"}]}. The whole source row must state metric: label value unit, label value unit (same unit repeated). No estimates, ranges, conversions or missing units; otherwise use text. Optional currentJudgment.presentation: omit or {kind:"text"} for an independent conclusion. Use {kind:"comparison"} only when contrasting the prior and current routes clarifies a real tradeoff; the host shows both alternatives without implying sequence. ' + require('./live-card-body').RULES.en + ' Keep card text relevant; never include transcript line numbers in card text. Use brief text for dependencies or conditions. Do not request relationship graphs. This choice does not create a new judgement or authorize changing human content.';
function select(raw,rows,allowed){
 const text={kind:'text',nodes:[],edges:[]};
 if(raw?.kind==='numeric-comparison')return require('./numeric-comparison').select(raw,rows,allowed);
 if(raw?.kind==='comparison')return {kind:'comparison',nodes:[],edges:[]};
 return text;
}
module.exports={policy,select};
