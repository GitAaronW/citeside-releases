'use strict';
// L2 Zero-Anti-Bot Official Open API Sources:
// Direct structured JSON APIs (Wikipedia EN/ZH, GitHub, Hacker News Algolia)
// that never trigger Cloudflare/403/TLS anti-bot blocks and return authoritative
// public excerpts in ~300-600ms at $0 cost.
const { assertAllowed } = require('./outbound-policy');

const DEFAULT_TIMEOUT_MS = 3500;
const USER_AGENT = 'Citeside/1.0 (+https://citeside.com)';

function cleanText(s, max = 3000) {
  return String(s || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}

function hasCjk(s) {
  return /[\u4e00-\u9fff]/.test(String(s || ''));
}

function isFinanceQuery(s) {
  return /\b(?:revenue|earnings|eps|guidance|quarter|q[1-4]\s*20\d{2}|margin|capex|valuation|gdp|fiscal|tariff|stock|dividend)\b|营收|财报|季度|利润|毛利率|股价|估值|增速|税改|财政/i.test(String(s || ''));
}

function isTechQuery(s) {
  if (isFinanceQuery(s)) return false;
  return /\b(?:github|api|sdk|rfc|cve|k8s|kubernetes|docker|react|node\.?js|python|rust|golang|sqlite|postgres|redis|vllm|mcp|cuda|transformer|benchmark|open[\s-]?source|framework|library|database)\b|开源|框架|数据库|算法|接口|协议/i.test(String(s || ''));
}

async function fetchJson(url, { env, fetchImpl, timeoutMs = DEFAULT_TIMEOUT_MS, headers = {} }) {
  assertAllowed(env, 'search', url);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetchImpl(url, {
      redirect: 'follow',
      signal: controller.signal,
      headers: { Accept: 'application/json', 'User-Agent': USER_AGENT, ...headers }
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function searchWikipedia(query, lang, limit, opts) {
  const host = lang === 'zh' ? 'zh.wikipedia.org' : 'en.wikipedia.org';
  const searchUrl = `https://${host}/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=${limit}&format=json&utf8=1`;
  const data = await fetchJson(searchUrl, opts);
  const hits = data?.query?.search;
  if (!Array.isArray(hits) || !hits.length) return [];
  const pageIds = hits.slice(0, limit).map(h => h.pageid).filter(Boolean);
  if (!pageIds.length) return [];
  const extractUrl = `https://${host}/w/api.php?action=query&prop=extracts|info&inprop=url&explaintext=1&exintro=1&exchars=1600&pageids=${pageIds.join('|')}&format=json&utf8=1`;
  const detail = await fetchJson(extractUrl, opts);
  const pages = detail?.query?.pages || {};
  const out = [];
  for (const h of hits.slice(0, limit)) {
    const p = pages[String(h.pageid)];
    const url = p?.fullurl || `https://${host}/wiki/${encodeURIComponent(String(h.title || '').replace(/\s+/g, '_'))}`;
    const excerpt = cleanText(p?.extract || '', 2000);
    const snippet = cleanText(h.snippet || excerpt, 400);
    if (!/^https:\/\//.test(url)) continue;
    out.push({
      title: cleanText(h.title || p?.title || '', 200) + (lang === 'zh' ? ' - 维基百科' : ' - Wikipedia'),
      url,
      snippet,
      ...(excerpt.length >= 80 ? { excerpt, officialApi: true } : {})
    });
  }
  return out;
}

async function searchGitHub(query, limit, opts) {
  const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&per_page=${limit}&sort=stars`;
  const data = await fetchJson(url, { ...opts, headers: { Accept: 'application/vnd.github+json' } });
  const items = data?.items;
  if (!Array.isArray(items) || !items.length) return [];
  return items.slice(0, limit).map(repo => {
    const desc = cleanText(repo.description || '', 400);
    const topics = Array.isArray(repo.topics) && repo.topics.length ? ` Topics: ${repo.topics.slice(0, 6).join(', ')}.` : '';
    const lang = repo.language ? ` Primary language: ${repo.language}.` : '';
    const stars = Number.isFinite(repo.stargazers_count) ? ` Stars: ${repo.stargazers_count}.` : '';
    const updated = repo.pushed_at ? ` Last updated: ${String(repo.pushed_at).slice(0, 10)}.` : '';
    const excerpt = cleanText(`${repo.full_name}: ${desc}${lang}${stars}${updated}${topics}`, 1200);
    return {
      title: cleanText(`${repo.full_name} (GitHub)`, 200),
      url: String(repo.html_url || ''),
      snippet: desc || excerpt,
      ...(excerpt.length >= 80 ? { excerpt, officialApi: true } : {})
    };
  }).filter(r => /^https:\/\//.test(r.url));
}

async function searchHackerNews(query, limit, opts) {
  const url = `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=${limit}`;
  const data = await fetchJson(url, opts);
  const hits = data?.hits;
  if (!Array.isArray(hits) || !hits.length) return [];
  return hits.slice(0, limit).map(h => {
    const targetUrl = String(h.url || `https://news.ycombinator.com/item?id=${h.objectID}`);
    return {
      title: cleanText(h.title || '', 200),
      url: targetUrl,
      snippet: cleanText(`${h.title || ''} (${h.points || 0} points, ${h.num_comments || 0} comments on Hacker News)`, 400)
    };
  }).filter(r => /^https:\/\//.test(r.url));
}

async function search(query, limit = 3, options = {}) {
  const q = String(query || '').trim();
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (!q || typeof fetchImpl !== 'function') return [];
  const opts = { env: options.env || {}, fetchImpl, timeoutMs: Math.min(DEFAULT_TIMEOUT_MS, options.timeoutMs || DEFAULT_TIMEOUT_MS) };
  const tasks = [];
  if (hasCjk(q)) {
    tasks.push(searchWikipedia(q, 'zh', Math.min(2, limit), opts));
  } else {
    tasks.push(searchWikipedia(q, 'en', Math.min(2, limit), opts));
  }
  if (isTechQuery(q)) {
    tasks.push(searchGitHub(q, 2, opts));
  }
  const settled = await Promise.all(tasks.map(p => p.catch(() => [])));
  const seen = new Set();
  const merged = [];
  for (const list of settled) {
    for (const row of list || []) {
      if (!row?.url || seen.has(row.url)) continue;
      seen.add(row.url);
      merged.push(row);
      if (merged.length >= limit) return merged;
    }
  }
  return merged;
}

module.exports = { search, searchWikipedia, searchGitHub, searchHackerNews, hasCjk, isTechQuery };
