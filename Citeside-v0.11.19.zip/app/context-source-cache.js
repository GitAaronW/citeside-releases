'use strict';
// Local snapshots of explicitly selected Drive documents. Never derive a path
// from an external id; bind every snapshot to both source id and document URL.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const file=(dataDir,source)=>path.join(dataDir,'state','context-drive',crypto.createHash('sha256').update(source.id+'\n'+source.path+(source.type==='mcp'?'\n'+require('./mcp-context-source').binding(source):'')).digest('hex')+'.json');
function read(dataDir,source){try{const row=JSON.parse(fs.readFileSync(file(dataDir,source),'utf8'));return row.sourcePath===source.path&&typeof row.text==='string'&&(source.type!=='mcp'||row.sourceBinding===require('./mcp-context-source').binding(source)&&(row.state!=='ready'||(row.coverage?.complete===true&&row.receipt?.binding===row.sourceBinding)))?row:null;}catch{return null;}}
function save(dataDir,source,result){
 const target=file(dataDir,source);fs.mkdirSync(path.dirname(target),{recursive:true,mode:0o700});
 const row={...(source.type==='mcp'?{sourceBinding:require('./mcp-context-source').binding(source),receipt:result.receipt||null,error:result.error||''}:{}),state:result.state,text:result.text||'',title:result.title||source.title,version:result.version||'',coverage:result.coverage||null,sourcePath:source.path,fetchedAt:new Date().toISOString()};
 require('./durable-json').write(target,row);return row;
}
function remove(dataDir,source){try{fs.unlinkSync(file(dataDir,source));}catch(e){if(e.code!=='ENOENT')throw e;}}
module.exports={read,save,remove};
