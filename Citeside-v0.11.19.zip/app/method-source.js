'use strict';
// 外部事实必须带出处（Aaron 10-25 投四张会中卡：「第 2 张最有感觉」= 行业多年没人解决的具名老问题 + 可查的出处；
// 「第 3 张没感觉」= 众所周知的失败案例。总控结论：没有带出处的外部事实就不出卡；「未解决的行业老问题」排在「著名失败案例」前面）。
// 只管 kind === 'external' 的卡（guard 之后 kind 一定在）：出处取 source 字段，没有就取 text 里的「来源：」行；
// 为空 / 占位（无、需核实、凭记忆…）/ 超过 SOURCE_MAX 字 → 整张卡不出（suggestion 置 null、insight 从列表里删）并记一行日志；
// 否则统一成 text 末尾一行「来源：<发布方 年份>」。
// 出处必须进 text：native-meeting 的 cards() 只透传 text / sourceIds / title，模型的 source 字段到不了网页端；网页端 mdHtml 按行渲染，末尾一行刚好。
// 在 tag 之后、brief 之前跑：标签和字数上限都不算这一行（method-brief.split 会把它剥出来）；guard 的数字闸在这之前跑完，年份不会被当成会上没说的数字。
const SOURCE_MAX = 24;
const SOURCE_LINE = /\n\s*来源\s*[:：]\s*/;
const PLACEHOLDER = /^(?:无|没有|不详|未知|不明|需核实|待核实|待查|凭记忆|记忆|常识|n\/?a|none|null|unknown|tbd|-+|—+|…+)$/i;
const chars = s => Array.from(String(s || ''));
const DROP = Symbol('method-source drop');

// 取出处并把 text 里的「来源：」行剥掉（source 字段优先，text 里的行只在字段为空时用）。
function sourceOf(card) {
  let s = typeof card.source === 'string' ? card.source : '';
  const t = String(card.text || ''), i = t.search(SOURCE_LINE);
  let text = t;
  if (i >= 0) {
    const tail = t.slice(i).replace(SOURCE_LINE, ''), nl = tail.indexOf('\n');
    const inline = (nl < 0 ? tail : tail.slice(0, nl)).trim();
    text = t.slice(0, i) + (nl < 0 ? '' : tail.slice(nl));
    if (!s.trim()) s = inline;
  }
  // 先去尾部标点，再剥括号，再去一次尾部标点：模型常写「（IDC 2025 年报告）。」，括号外还有句号。
  const TAIL = /[。.;；,，\s]+$/;
  s = s.trim().replace(TAIL, '').replace(/^[（(【\[「\s]+|[）)】\]」\s]+$/g, '').replace(TAIL, '').trim();
  return { source: s, text: text.replace(/\s+$/, '') };
}
function reject(source) {
  if (!source) return 'no source';
  if (PLACEHOLDER.test(source)) return 'placeholder source';
  if (chars(source).length > SOURCE_MAX) return 'source too long';
  return '';
}
function requireSource(parsed, log) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return parsed;
  const one = c => {
    if (!c || typeof c.text !== 'string' || String(c.kind || '').toLowerCase() !== 'external') return c;
    const { source, text } = sourceOf(c);
    const why = reject(source);
    if (why) { if (typeof log === 'function') log('method-source dropped (' + why + ') ' + c.text.replace(/\n/g, ' / ')); return DROP; }
    const out = text + '\n来源：' + source;
    return out === c.text && c.source === source ? c : { ...c, text: out, source };
  };
  const suggestion = one(parsed.suggestion);
  const insights = (Array.isArray(parsed.insights) ? parsed.insights : []).map(one).filter(c => c !== DROP);
  return { ...parsed, suggestion: suggestion === DROP ? null : suggestion, insights };
}
const prompt = `
外部事实必须有出处（硬规则）：kind 为 external 的卡要带 source 字段，写可查的出处 = 发布方 + 年份（或年月），不超过 16 个字，如「IDC 2025 年报告」「The Verge 2024-11」「Counterpoint 2026Q1」。凭记忆、说不出出处、只能写「需核实」的外部事实，这张卡不出，改出 gap 或 internal 卡。source 不写进 text，系统会加。
外部卡的价值排序（高 → 低）：① 行业多年没人解决的具名老问题——点名是什么问题、从哪年起、谁试过没成；② 新数据 + 头部厂商对它的做法；③ 众所周知的失败案例——默认会上的人都知道，只有能补一层新东西才出。不管哪种，正文都要落到对这场会意味着什么，动作一句。
`;
module.exports = { SOURCE_MAX, SOURCE_LINE, PLACEHOLDER, sourceOf, reject, requireSource, prompt };
