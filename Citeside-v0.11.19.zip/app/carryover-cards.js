'use strict';
// 会中「遗留卡」：上一场同系列会议留下的待办 / 未决事项，本场还没谈到就出一张「上次说过 X，本场还没提到」，
// 转写里有人谈到（X 的有效关键词在相邻几句里覆盖过半）就撤回。纯函数：不读盘、不联网、不调模型，措辞固定不改写。
// 低噪声靠判据本身：只取 todo / open、占位文案不出卡、同文去重、撤回后不再出；不设数量预算或冷却。
const crypto = require('crypto');
const { terms } = require('./tools/local');

const KINDS = new Set(['todo', 'open']);
// premeeting-brief 在上一场没有记录时填的占位文案，不是真事项
const PLACEHOLDER = /^上次没有/;
// 含虚词的二字切片（「的续」「案并」「发给」）跨了词边界，转写里几乎不会原样出现，留着只会压低覆盖率
const FUNCTION_CHAR = /[的了和与并及或把被将在是也就都还要给对从向让]/u;
// 会上随口就会说的通用词：只命中它们不算谈到这件事
const GENERIC = new Set(('确认 跟进 推进 同步 对齐 讨论 沟通 处理 完成 准备 安排 落实 负责 输出 整理 更新 评估 检查 汇报 反馈 '
  + '问题 事情 事项 方案 情况 进展 进度 计划 结论 待办 未决 下次 上次 本周 下周 今天 明天 时间 需要 一下 一个 这个 那个 我们 大家 '
  + '可以 是否 怎么 什么 还是 已经 目前 现在 后续 相关 内容 部分 一起 然后 因为 所以 但是 如果 '
  + 'todo follow sync check update plan issue next week').split(/\s+/));
const WINDOW = 4;          // 相邻几句一起看：一件事常跨两三句说完，但不让整场零散的词凑成「谈到」
const COVER = 0.5;         // 有效词覆盖过半
const MIN_HITS = 2;        // 有效词 ≥2 个时至少命中 2 个，单个词不撤卡

const GENERIC_HAN = [...GENERIC].filter(w => /^[\p{Script=Han}]+$/u.test(w)).sort((a, b) => b.length - a.length);
// 先把通用词和虚词挖掉再切词：避免「跟进一下」切出「进一」、「方案并发」切出「案并」这类跨词碎片
function keyTerms(text) {
  let s = String(text || '');
  for (const w of GENERIC_HAN) s = s.split(w).join(' ');
  s = s.replace(new RegExp(FUNCTION_CHAR.source, 'gu'), ' ');
  return terms(s).filter(t => !GENERIC.has(t) && !/^[\p{Script=Han}]$/u.test(t));
}
const norm = s => String(s || '').replace(/\s+/g, '').toLowerCase();
const subject = s => String(s || '').trim().replace(/[。．.!！?？；;，,、\s]+$/u, '');
const idOf = (line, x) => 'co_' + crypto.createHash('sha1').update([line.kind, line.ref && line.ref.meetingId || '', norm(x)].join('|')).digest('hex').slice(0, 12);

// 这条事项需要几个有效词命中才算谈到；返回 0 = 没法判（全是通用词），不出卡
function needed(n) { if (!n) return 0; if (n === 1) return 1; return Math.min(n, Math.max(MIN_HITS, Math.ceil(n * COVER))); }
function covered(ts, hay) { let hit = 0; for (const t of ts) if (hay.includes(t)) hit++; return hit >= needed(ts.length); }

// 专家人设：带「你可以问 / 我认为 / 我建议」的遗留项整条丢掉，不改写（Aaron 2026-10-25）
const PERSONA_BAN = /你可以问|我认为|我建议/;
function items(briefLines) {
  const out = [], seen = new Set();
  for (const line of Array.isArray(briefLines) ? briefLines : []) {
    if (!line || !KINDS.has(line.kind)) continue;
    const x = subject(line.text);
    if (!x || PLACEHOLDER.test(x) || PERSONA_BAN.test(x)) continue;
    const key = norm(x); if (seen.has(key)) continue;
    const ts = keyTerms(x); if (!needed(ts.length)) continue;
    seen.add(key);
    out.push({ id: idOf(line, x), kind: line.kind, text: '上次说过' + x + '，本场还没提到', ref: line.ref || null, terms: ts });
  }
  return out;
}

// transcript：转写行（{text}）或字符串数组。state：上一次的结果（{resolved, scanned}），撤回是粘性的，只扫新句子。
function evaluate({ briefLines, transcript, state } = {}) {
  const rows = (Array.isArray(transcript) ? transcript : []).map(r => String(r && typeof r === 'object' ? r.text || '' : r || '').toLowerCase());
  const resolved = new Set(Array.isArray(state && state.resolved) ? state.resolved : []);
  const from = Math.max(0, Math.min(rows.length, Number(state && state.scanned) || 0));
  const all = items(briefLines), open = all.filter(x => !resolved.has(x.id));
  for (let i = from; i < rows.length && open.length; i++) {
    const hay = rows.slice(Math.max(0, i - WINDOW + 1), i + 1).join(' ');
    for (let k = open.length - 1; k >= 0; k--) if (covered(open[k].terms, hay)) { resolved.add(open[k].id); open.splice(k, 1); }
  }
  return { pending: open.map(({ terms: _t, ...x }) => x), resolved: [...resolved], scanned: rows.length };
}

module.exports = { evaluate, keyTerms, items, WINDOW, COVER, MIN_HITS };
