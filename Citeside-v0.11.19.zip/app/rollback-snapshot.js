'use strict';
// Recover only a permission-loss copy in a disposable snapshot. The original
// receipt remains the authority: no mode exception or replacement receipt.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const native=require('./native-update');
const failed=reason=>Object.assign(Error('回退快照来源校验失败，当前程序和旧快照未改动（'+reason+'）'),{code:'PREV_PROOF_FAILED'});
const digest=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function localFile(root,relative,directory=false){
 const parts=relative.split('/');let current=root;
 if(!fs.lstatSync(root).isDirectory()||fs.lstatSync(root).isSymbolicLink())throw failed('snapshot root');
 for(let i=0;i<parts.length;i++){
  current=path.join(current,parts[i]);const stat=fs.lstatSync(current);
  const expectDirectory=i<parts.length-1||directory;
  if(stat.isSymbolicLink()||(expectDirectory?!stat.isDirectory():!stat.isFile()))throw failed('unexpected snapshot entry');
 }
 return current;
}
function inputs(root,receipt){
 if(receipt?.schemaVersion!==1||!/^[a-f0-9]{40}$/.test(receipt.sourceSha||'')||!/^[a-f0-9]{64}$/.test(receipt.helperSha256||''))throw failed('receipt schema');
 for(const name of [...native.INPUTS,native.HELPER+'/Contents/Info.plist']){
  const expected=receipt.inputSha256?.[name];
  if(!/^[a-f0-9]{64}$/.test(expected||'')||digest(localFile(root,name))!==expected)throw failed('input hash');
 }
 localFile(root,native.HELPER,true);
}
function normalizeHelper(bundle){
 const stat=fs.lstatSync(bundle),mode=stat.mode&0o7777;
 // Symlink targets and modes are fingerprinted as-is. Never chmod or traverse them.
 if(stat.isSymbolicLink())return;
 if(stat.isDirectory()){
  if(![0o700,0o755].includes(mode))throw failed('unknown directory modes');
  for(const name of fs.readdirSync(bundle))normalizeHelper(path.join(bundle,name));
  fs.chmodSync(bundle,0o755);return;
 }
 if(!stat.isFile()||![0o600,0o644,0o700,0o755].includes(mode))throw failed('unknown file modes');
 fs.chmodSync(bundle,mode&0o100?0o755:0o644);
}
function withSnapshot(previous,use,{verifySignature=native.verify}={}){
 const receiptFile=path.join(previous,native.PROVENANCE);
 // Retain the prior treatment of receipt-less legacy/source snapshots. Their
 // existing preservation/migration preflight still decides whether they work.
 try{fs.lstatSync(receiptFile);}catch(error){if(error.code==='ENOENT')return use(previous);throw error;}
 let temporary;
 try{
  localFile(previous,native.PROVENANCE);
  const original=fs.readFileSync(receiptFile),receipt=JSON.parse(original.toString('utf8'));
  inputs(previous,receipt);
  const helper=path.join(previous,native.HELPER);
  if(native.fingerprint(helper)===receipt.helperSha256){
   native.provenance(previous);verifySignature(helper);
   if(!fs.readFileSync(receiptFile).equals(original))throw failed('receipt changed');
   return use(previous);
  }
  temporary=fs.mkdtempSync(previous+'.proof-');
  const staged=path.join(temporary,'snapshot');
  fs.cpSync(previous,staged,{recursive:true,verbatimSymlinks:true,dereference:false});
  normalizeHelper(path.join(staged,native.HELPER));
  const stagedReceipt=path.join(staged,native.PROVENANCE);
  if(!fs.readFileSync(stagedReceipt).equals(original))throw failed('receipt changed');
  inputs(staged,receipt);
  // provenance checks the entire bundle fingerprint, including every mode,
  // file byte, entry type and symlink target, against the untouched old receipt.
  native.provenance(staged);verifySignature(path.join(staged,native.HELPER));
  if(!fs.readFileSync(stagedReceipt).equals(original)||!fs.readFileSync(receiptFile).equals(original))throw failed('receipt changed');
  return use(staged);
 }finally{if(temporary)fs.rmSync(temporary,{recursive:true,force:true,maxRetries:3});}
}
module.exports={withSnapshot};
