'use strict';
const fs=require('fs'),path=require('path'),readline=require('readline'),rules=require('./meeting-detect-rules');
function create({dataDir,spawn=require('child_process').spawn,binary=path.join(__dirname,'native-detect','MeetingNotice'),exists=fs.existsSync,platform=process.platform,env=process.env,now=Date.now,setTimer=setTimeout,clearTimer=clearTimeout,every=setInterval,cancelEvery=clearInterval,calendar=()=>[],status=()=>({}),startRecording,stopRecording,openMeeting=()=>{},language=()=> 'zh',log=()=>{}}){
 const file=path.join(dataDir,'state','meeting-detect.json');let prefs={enabled:true,mutedApps:[]};
 try{const p=JSON.parse(fs.readFileSync(file,'utf8'));prefs={enabled:p.enabled!==false,mutedApps:(p.mutedApps||[]).filter(id=>rules.APPS.some(a=>a.id===id))};}catch{}
 let state=rules.initial(),child=null,reader=null,closed=false,retry=null,timer=null,backoff=1000,events=[],lastCalendar=-Infinity,launchedAt=0,micKnown=false,pendingOrigin=null,requested=false,generation=0;
 const view=()=>({...prefs,mutedApps:prefs.mutedApps.map(id=>({id,name:rules.APPS.find(a=>a.id===id).name}))});
 function save(){fs.mkdirSync(path.dirname(file),{recursive:true});require('./durable-json').write(file,prefs,{space:2});}
 function update(p){const next={...prefs};if(typeof p.enabled==='boolean')next.enabled=p.enabled;if(p.restoreApp)next.mutedApps=next.mutedApps.filter(id=>id!==p.restoreApp);const old=prefs;prefs=next;let persistenceError;try{save();}catch(e){if(!e.published){prefs=old;throw e;}persistenceError=e;}if(old.enabled!==prefs.enabled){if(!prefs.enabled)stopHelper();else if(requested)start();}dispatch();if(persistenceError)throw persistenceError;return view();}
 function send(x){try{if(child?.stdin?.writable)child.stdin.write(JSON.stringify(x)+'\n');}catch(e){log('meeting notice write: '+e.message);}}
 // Explicit IPC allowlist: event, attendees, description and join URL stay here.
 function show(n){send({type:'show',id:n.id,kind:n.kind,title:n.title,subtitle:n.subtitle,language:language(),app:n.app?{name:n.app.name}:null,...(Number.isFinite(n.countdownSec)?{countdownSec:n.countdownSec}:{})});}
 function dispatch(input={}){
  if(closed||!prefs.enabled)return;
  if(now()-lastCalendar>=30000){lastCalendar=now();try{events=calendar()||[];}catch{events=[];}}
  const live=status(),recording=!!(live.active||live.starting);
  const rawId=live.active&&!live.starting&&live.captureMode!=='browser'?String(live.sessionId||''):'';
  const sessionId=rawId&&!rawId.startsWith('trial-')?rawId:'';
  const result=rules.step(state,input,{now:now(),events,recording,sessionId,enabled:prefs.enabled,mutedApps:prefs.mutedApps});state=result.state;
  for(const e of result.effects){
   if(e.type==='show')show(e.notice);
   if(e.type==='hide')send({type:'hide'});
   if(e.type==='mute'){prefs.mutedApps=[...new Set([...prefs.mutedApps,e.app])];try{save();}catch(err){log('meeting detect settings: '+err.message);}}
   if(e.type==='open')Promise.resolve().then(()=>openMeeting(e.sessionId)).catch(err=>log('meeting detect open: '+err.message));
   if(e.type==='start')Promise.resolve().then(()=>{if(status().active||status().starting)throw Error('recording already active');return startRecording(e.event,e.app);}).then(r=>{if(r?.active&&r.sessionId){dispatch({type:'started',sessionId:r.sessionId,app:e.app,event:e.event});void Promise.resolve().then(()=>openMeeting(r.sessionId)).catch(err=>log('meeting detect open: '+err.message));return;}if(!r?.starting)throw Error('recording did not start');pendingOrigin={...e,at:now()};}).catch(err=>{log('meeting detect start: '+err.message);dispatch({type:'start_failed',notice:e.notice});});
   if(e.type==='stop')Promise.resolve().then(()=>stopRecording(e.sessionId)).then(result=>{if(result===false)throw Error('recording stop rejected');}).catch(err=>{log('meeting detect stop: '+err.message);dispatch({type:'stop_failed'});});
  }
 }
 function launch(){
  if(closed||!prefs.enabled||!requested||child||!exists(binary))return;
  let proc;try{proc=spawn(binary,[],{stdio:['pipe','pipe','ignore']});}catch{schedule();return;}
  child=proc;launchedAt=now();micKnown=false;
  reader=readline.createInterface({input:proc.stdout});reader.on('line',line=>{if(child!==proc||!prefs.enabled||line.length>65536)return;let e;try{e=JSON.parse(line);}catch{return;}if(e.type==='mic'&&Array.isArray(e.apps)&&e.apps.every(x=>typeof x==='string')){micKnown=true;dispatch(e);}else if(e.type==='mic_unavailable'){micKnown=false;dispatch(e);}else if(e.type==='action')dispatch(e);});
  let failed=false;const lost=()=>{if(failed||closed||child!==proc)return;failed=true;reader?.close();if(child===proc)child=null;micKnown=false;state.apps={};if(state.recording){state.recording.leftAt=null;state.recording.endShown=false;}if(state.notice?.kind==='end')state.notice=null;if(now()-launchedAt>60000)backoff=1000;schedule();};proc.once('exit',lost);proc.once('error',lost);
  if(state.notice)show(state.notice);
 }
 function schedule(){if(closed||!prefs.enabled||retry)return;const gen=generation;retry=setTimer(()=>{if(gen!==generation)return;retry=null;launch();},backoff);retry?.unref?.();backoff=Math.min(60000,backoff*2);}
 function tick(){
  if(closed||!prefs.enabled)return;
  if(pendingOrigin){const live=status(),origin=pendingOrigin;if(live.active&&live.sessionId){pendingOrigin=null;dispatch({type:'started',sessionId:live.sessionId,app:origin.app,event:origin.event});Promise.resolve().then(()=>openMeeting(live.sessionId)).catch(err=>log(err.message));}else if(!live.starting||now()-origin.at>=120000){pendingOrigin=null;dispatch({type:'start_failed',notice:origin.notice});}}
  // A dead detector is unknown, never evidence that a meeting ended.
  if(!micKnown&&state.recording){state.recording.leftAt=null;state.recording.endShown=false;if(state.notice?.kind==='end'){state.notice=null;send({type:'hide'});}const watch=state.recording.watch;state.recording.watch=false;dispatch();if(state.recording)state.recording.watch=watch;}else dispatch();
 }
 function start(){requested=true;if(!prefs.enabled||platform!=='darwin'||env.THT_TEST==='1'||env.NODE_TEST_CONTEXT||closed||timer||!exists(binary))return false;launch();timer=every(tick,1000);timer?.unref?.();return true;}
 function stopHelper(){generation++;cancelEvery(timer);timer=null;clearTimer(retry);retry=null;reader?.close();reader=null;const proc=child;child=null;proc?.kill();micKnown=false;state.apps={};state.notice=null;if(state.recording)state.recording.leftAt=null;backoff=1000;}
 function close(){closed=true;requested=false;stopHelper();}
 async function route(req,res,u,allowed){if(u.pathname.replace(/^\/asr-relay/,'')!=='/meeting-detect')return false;const reply=(code,x)=>{res.writeHead(code,{'Content-Type':'application/json'});res.end(JSON.stringify(x));};if(!allowed){reply(403,{error:'unauthorized'});return true;}if(req.method==='GET'){reply(200,view());return true;}if(req.method!=='POST'){reply(405,{error:'method'});return true;}let body='';try{for await(const c of req){body+=c;if(body.length>4096)throw Error('too large');}reply(200,update(JSON.parse(body)));}catch(e){reply(400,{error:e.message});}return true;}
 return {start,close,route,settings:view,update,tick};
}
module.exports={create};
