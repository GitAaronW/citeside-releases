'use strict';
// TENANT-SECURITY：写进 events.log 之前把密钥打码。两层：本进程读到过的真实密钥值逐个替换；
// 再按常见密钥形状（sk-、xoxb-、ntn_、secret_、Bearer、URL 里的 token=）兜底，防止没登记过的密钥漏进日志。
const store = require('./secret-store');

const PATTERNS = [
  [/\bsk-[A-Za-z0-9_-]{16,}/g, 'sk-***'],
  [/\bxox[abpr]-[A-Za-z0-9-]{10,}/g, 'xox*-***'],
  [/\bntn_[A-Za-z0-9]{20,}/g, 'ntn_***'],
  [/\bsecret_[A-Za-z0-9]{20,}/g, 'secret_***'],
  [/\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{16,}/gi, '$1 ***'],
  [/([?&](?:token|key|api_key|access_token)=)[^&\s"']{8,}/gi, '$1***'],
  [/("(?:[A-Za-z_]*(?:api_?key|token|secret|password)[A-Za-z_]*)"\s*:\s*")[^"]{8,}"/gi, '$1***"'],
];

function redact(text, secrets = store.knownSecrets()) {
  let s = String(text);
  for (const v of secrets) if (v && v.length >= 8 && s.includes(v)) s = s.split(v).join('***');
  for (const [re, to] of PATTERNS) s = s.replace(re, to);
  return s;
}

module.exports = { redact, PATTERNS };
