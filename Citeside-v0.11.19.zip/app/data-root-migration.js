'use strict';
// The controller must stop the verified installation and provide its public API.
// No legacy identifier, directory scanning, untrusted require(), or secret logging.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), os = require('node:os');
const secrets = require('./secret-store'), audio = require('./audio-keychain');
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const skip = new Set(['program','runtime','node-path','server.pid','launcher.log','python-path']);
// cli-llm.codexHome owns this exact absolute pointer and recreates it on demand.
// Omit the pointer, never follow it or copy another client's authentication data.
function managedAuthLink(file, relative) {
  return relative === path.join('state','codex-home','auth.json') && fs.lstatSync(file).isSymbolicLink()
    && fs.readlinkSync(file) === path.join(os.homedir(),'.codex','auth.json');
}
function tree(root) {
  const out = new Map();
  function walk(dir, rel = '') {
    for (const name of fs.readdirSync(dir).sort()) {
      if (!rel && skip.has(name)) continue;
      const r = path.join(rel, name), f = path.join(dir, name), st = fs.lstatSync(f);
      if (st.isSymbolicLink() && managedAuthLink(f,r)) continue;
      if (st.isSymbolicLink() || (!st.isFile() && !st.isDirectory())) throw Error('Migration requires regular data files');
      if (st.isDirectory()) walk(f, r); else out.set(r, crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex'));
    }
  }
  walk(root); return out;
}
function same(a,b) { return a.size === b.size && [...a].every(([k,v])=>b.get(k)===v); }
function migrate({sourceDir, targetDir, legacy, stopped = false, env = process.env, audioBin, nativeSpool} = {}) {
  if (!stopped || legacy?.verified !== true || typeof legacy.secrets?.hydrate !== 'function') throw Error('Verified stopped installation API required');
  const source = fs.realpathSync(sourceDir), target = path.resolve(targetDir);
  if (source === target || target.startsWith(source + path.sep) || source.startsWith(target + path.sep)) throw Error('Distinct sibling data roots required');
  if (fs.existsSync(target)) {
    const receipt = path.join(target, '.data-root-migration.json');
    if (fs.existsSync(receipt) && json(receipt).sourceId === crypto.createHash('sha256').update(source).digest('hex')) return {ok:true, alreadyMigrated:true};
    throw Error('Destination already exists; current data preserved');
  }
  if (fs.realpathSync(path.dirname(target)) !== path.dirname(target)) throw Error('Destination parent must be canonical');
  const raw = json(path.join(source,'settings.json')), original = tree(source);
  env = {...env, THT_SECRET_STORE:'keychain'};
  const hydrated = legacy.secrets.hydrate(raw, source, env);
  if ((raw.SECRET_KEYS_IN_KEYCHAIN || []).some(k => !hydrated[k])) throw Error('Existing Keychain credential unavailable');
  const stage = fs.mkdtempSync(path.join(path.dirname(target), '.citeside-data-stage-'));
  try {
    for (const name of fs.readdirSync(source)) if (!skip.has(name)) fs.cpSync(path.join(source,name),path.join(stage,name),{recursive:true,errorOnExist:true,force:false,mode:fs.constants.COPYFILE_EXCL,filter:file=>!managedAuthLink(file,path.relative(source,file))});
    if (!same(original,tree(stage))) throw Error('Staged data readback mismatch');
    const next = secrets.persist(hydrated,target,env,raw);
    if (secrets.status().errors.length) throw Error('Destination Keychain write failed');
    const back = secrets.hydrate(next,target,env);
    for (const k of raw.SECRET_KEYS_IN_KEYCHAIN || []) if (back[k] !== hydrated[k]) throw Error('Destination Keychain readback mismatch');
    // Keep settings byte-for-byte: persist() only copies keys, never reserializes private config.
    const accountFile = path.join(source,'account.json');
    if (fs.existsSync(accountFile)) {
      const account = json(accountFile);
      for (const b of account.bindings || []) {
        if (!['lark','notion'].includes(b.provider)) continue;
        if (!/^[a-z]+-[a-f0-9]{16}$/.test(b.key) || !/^u_[a-f0-9]{32}$/.test(account.userId)) throw Error('Invalid credential binding');
        const relative = path.join('accounts',account.userId,b.key,'token.json'), name='OAUTH_'+b.key;
        const value = legacy.secrets.getBlob(source,name,{useKeychain:true,fallbackFile:path.join(source,relative)},env);
        if (!value) throw Error('Bound OAuth credential unavailable');
        const opts={useKeychain:true,requireKeychain:true,fallbackFile:path.join(stage,'.oauth-migration-fallback')};
        if (secrets.putBlob(target,name,value,opts,env).where !== 'keychain') throw Error('OAuth Keychain migration failed');
        const result=secrets.getBlob(target,name,{useKeychain:true,fallbackFile:path.join(target,relative)},env);
        if (JSON.stringify(result)!==JSON.stringify(value)) throw Error('OAuth Keychain readback mismatch');
      }
    }
    const relative='state/pending-audio', oldAudio=path.join(source,relative), fp=path.join(oldAudio,'pac1-key-id');
    if (fs.existsSync(fp)) {
      const opened=legacy.audio?.open({dir:oldAudio,env});
      if (!opened?.ok || !opened.recoverable) throw Error('Existing audio key unavailable');
      audio.importKey(path.join(target,relative),opened.key,{env,bin:audioBin || env.THT_AUDIO_KEYCHAIN_BIN || '/usr/bin/security',fingerprint:fs.readFileSync(fp,'utf8').trim()});
    } else if (fs.existsSync(oldAudio) && fs.readdirSync(oldAudio).some(x=>/^pac1-.*\.bin$/.test(x))) throw Error('Unverified pending audio; migration refused');
    if (nativeSpool) require('./native-spool-migration').copy({...nativeSpool,destination:path.join(stage,'pending-spool'),env});
    if (!same(original,tree(source))) throw Error('Source changed during migration');
    fs.writeFileSync(path.join(stage,'.data-root-migration.json'),JSON.stringify({schema:1,sourceId:crypto.createHash('sha256').update(source).digest('hex')}),{mode:0o600});
    fs.renameSync(stage,target);
    return {ok:true,alreadyMigrated:false,files:original.size};
  } finally { fs.rmSync(stage,{recursive:true,force:true}); }
}
module.exports={migrate};
