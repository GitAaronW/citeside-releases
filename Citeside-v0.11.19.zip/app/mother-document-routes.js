'use strict';
module.exports=async function(req,res,u,ctx){
 if(u.pathname.replace(/^\/asr-relay/,'')!=='/mother-documents')return false;
 const send=(s,v)=>{res.writeHead(s,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(v));};
 if(!ctx.authed){send(401,{error:'unauthorized'});return true;}
 if(!ctx.hub){send(503,{error:'Workspace unavailable'});return true;}
 try{
  if(!['GET','POST'].includes(req.method)){send(405,{error:'method not allowed'});return true;}
  if(req.method==='POST'&&req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host){send(403,{error:'origin'});return true;}
  let j={};if(req.method==='POST'){const chunks=[];let length=0;for await(const c of req){length+=Buffer.byteLength(c);if(length>12000000){send(413,{error:'too large'});return true;}chunks.push(c);}j=JSON.parse(Buffer.concat(chunks.map(c=>Buffer.from(c))).toString()||'{}');}
  const store=require('./mother-documents').get(ctx.dataDir);
  store.configureNotion({dataDir:ctx.dataDir,env:ctx.env,fetchImpl:ctx.fetchImpl,cloudDocumentProvider:ctx.cloudDocumentProvider,getTopic:projectId=>ctx.hub.data.projects?.find(p=>p.id===projectId),getMeeting:meetingId=>ctx.hub.data.sources.find(s=>s.key==='session:'+meetingId||s.id===meetingId)});
  const id=String(j.id||u.searchParams.get('id')||''),meetingId=String(j.meetingId||u.searchParams.get('meetingId')||'');
  const source=ctx.hub.data.sources.find(s=>s.key==='session:'+meetingId||s.id===meetingId);
  const fileSource=()=>{if(!source||!ctx.hub.root)return;const revision=source.revision;
   require('./meeting-frame-document').sync(store,source,ctx.session?.(meetingId));
   // V1.6: opening/saving a note keeps frame content and existing sync, without automatic project filing.
   if(source.revision!==revision)ctx.hub.save();
  };
  const meetingType=require('./meeting-document-layout').meetingType({...source,...(ctx.session?.(meetingId)||{})});
  const meetingModule=m=>({...m,documentMeetingType:meetingType});
  // A -> B -> A is still a new binding: delayed work belongs to the old choice.
  const bindingRevision=Number(source?.motherDocumentBindingRevision)||0;
  if(req.method==='GET'){
   if(u.searchParams.has('library')){
    try{const provider=require('./topic-doc-provider').cloud(store.notionOptions);send(200,await require('./notion-document-parent').readLibrary({dataDir:ctx.dataDir},provider));}
    catch(e){send(503,{error:'文档暂时无法读取，请稍后重试'});}return true;
   }
   if(u.searchParams.has('forkChoices')){if(!source)throw Object.assign(Error('Open a saved meeting first'),{status:404});send(200,require('./meeting-fork').choices(ctx,store,source,{fromDocumentId:u.searchParams.get('fromDocumentId')||'',fromMeetingId:u.searchParams.get('fromMeetingId')||''}));return true;}
   if(!id){send(200,{documents:store.list().filter(d=>!u.searchParams.has('projectId')||d.projectId===u.searchParams.get('projectId')),current:source?.motherDocumentId||''});return true;}
   if(u.searchParams.has('history')){send(200,{history:store.history(id)});return true;}
   if(u.searchParams.has('revision')){send(200,store.preview(id,u.searchParams.get('revision')));return true;}
   if(source?.motherDocumentId===id)fileSource();store.queueNotion(id);send(200,store.state(id,u.searchParams.get('vector')));return true;
  }
  if(j.action==='fork'){
   if(!source)throw Object.assign(Error('Open a saved meeting first'),{status:404});
   const doc=require('./meeting-fork').fork(ctx,store,source,j);
   if(source.motherDocumentId!==doc.id)ctx.hub.update('sources',source.id,{motherDocumentId:doc.id},j.sourceRevision);
   send(200,store.state(doc.id));return true;
  }
  if(j.action==='create'||j.action==='bind'){
   if(!source)throw Object.assign(Error('Open a saved meeting first'),{status:404});
   // Automatic open/retry must never create another document or replace a newer binding.
   if(j.action==='create'&&j.automatic===true&&source.motherDocumentId){fileSource();send(200,{...store.state(source.motherDocumentId),sourceRevision:source.revision});return true;}
   if(source.revision!==Number(j.sourceRevision))throw Object.assign(Error('Meeting changed; refresh and retry'),{status:409});
   const projectId=source.projectManual?source.projectId||'':'';
   let created;if(j.action==='create'){
    // Continue the explicitly selected calendar preparation document before a
    // fresh recording opens its editor. Existing links are never replaced.
    const preparation=typeof j.preparedEventId==='string'&&j.preparedEventId.length<=500?ctx.hub.data.sources.find(s=>s.kind==='note'&&s.calendarEvent?.eventId===j.preparedEventId):null;
    const prepared=preparation?.motherDocumentId?store.state(preparation.motherDocumentId):null;
    const continuing=!source.motherDocumentId&&prepared&&prepared.projectId===projectId;
    if(continuing)created=prepared;
    else created=store.create({title:j.title,projectId,topic:typeof j.topic==='string'?j.topic.slice(0,160):'',meetingId,...(j.template==='solution'?{content:require('./solution-document-template')(j.lang),contentDriven:true,lang:j.lang}:{})});
    if(j.inherit&&!continuing)for(const m of source.board?.modules||[])if(['note','plan','map','task'].includes(m.kind)&&(m.body||m.graph?.nodes?.length||m.nodes?.length))store.importModule(created.id,meetingModule(require('./generated-preparation-module')(ctx.hub.data,source,m)),meetingId);
    created=store.state(created.id);
   }else{store.read(id);created=store.state(id);if(created.projectId!==projectId)throw Object.assign(Error('This document belongs to another project'),{status:409});}
   ctx.hub.update('sources',source.id,{motherDocumentId:created.id},j.sourceRevision);store.bind(created.id,meetingId);fileSource();send(200,{...store.state(created.id),sourceRevision:source.revision});return true;
  }
  if(j.action==='noteOpened'){send(200,store.noteOpened(id));return true;}
  if(j.action==='stagePending'||j.action==='adoptPending'||j.action==='restorePending'||j.action==='rejectPending'||j.action==='clearPendingRejection'){
   if(!source||source.motherDocumentId!==id)throw Object.assign(Error('Meeting is no longer linked to this document'),{status:409});
   const lang=j.lang==='en'?'en':'zh',view=ctx.session?.(meetingId)||{},ended=!!(view.end||view.finalized);
   if(j.action==='stagePending'){send(200,store.stagePending(id,j.item||{},lang,{ended}));return true;}
   if(j.action==='rejectPending'){send(200,store.rejectPending(id,j.candidateId));return true;}
   if(j.action==='clearPendingRejection'){send(200,store.clearPendingRejection(id,j.candidateId,lang));return true;}
   if(j.action==='adoptPending'){send(200,store.adoptPending(id,j.candidateId));return true;}
   const ids=Array.isArray(j.candidateIds)?j.candidateIds:null;
   send(200,store.restorePending(id,ids,lang));return true;
  }
  if(j.action==='rename'){send(200,store.rename(id,j.title,j.author));return true;}
  if(j.action==='update'){send(200,store.update(id,j.update,j.author));return true;}
  if(j.action==='restore'){send(200,store.restore(id,j.revision,j.expectedRevision,j.author));return true;}
  if(j.action==='propose'){
   const controller=new AbortController();res.on('close',()=>{if(!res.writableEnded)controller.abort();});
   let modelMeta={};const editContext=require('./document-model-context')(ctx,{model:j.model||'',onModel:meta=>{modelMeta=meta;}});
   send(200,{...await store.propose(id,{...j,signal:controller.signal},editContext),...modelMeta});return true;
  }
  if(j.action==='organizeCollection'){
   if(!source||source.motherDocumentId!==id)throw Object.assign(Error('Meeting is no longer linked to this document'),{status:409});
   const controller=new AbortController();res.on('close',()=>{if(!res.writableEnded)controller.abort();});
   const editContext=require('./document-model-context')(ctx,{model:j.model||''});
   send(200,await store.organizeCollection(id,{meetingId,moduleId:j.moduleId,operationId:j.operationId,lang:j.lang,question:j.question,signal:controller.signal,beforeApply:()=>{const latest=ctx.hub.data.sources.find(s=>s.id===source.id);if(!latest||latest.motherDocumentId!==id||(Number(latest.motherDocumentBindingRevision)||0)!==bindingRevision)throw Object.assign(Error('Meeting is no longer linked to this document'),{status:409});}},editContext));return true;
  }
  if(j.action==='resolveCollection'){if(!source||source.motherDocumentId!==id)throw Object.assign(Error('Meeting is no longer linked to this document'),{status:409});send(200,store.resolveCollection(id,{...j,meetingId:j.collectionMeetingId||meetingId}));return true;}
  if(j.action==='apply'){send(200,store.apply(id,j.token));return true;}
  if(j.action==='collect'||j.action==='undoCollection'){
   if(!source||source.motherDocumentId!==id)throw Object.assign(Error('Meeting is no longer linked to this document'),{status:409});
   if(j.action==='undoCollection'){send(200,store.undoCollection(id,meetingId,j.moduleId,j.operationId));return true;}
   const recovered=store.recoverCollection(id,meetingId,j.moduleId,j.operationId);if(recovered){send(200,recovered);return true;}
   if(source.revision!==Number(j.sourceRevision))throw Object.assign(Error('Meeting changed; refresh and retry'),{status:409});
   if([j.chatSelection,j.artifactSelection,j.candidateSelection].filter(Boolean).length>1)throw Object.assign(Error('Choose one saved result'),{status:400});
   let module=j.artifactSelection?require('./artifact-document-selection')(ctx,source,j.moduleId,j.artifactSelection):j.chatSelection?require('./chat-document-selection')(ctx,meetingId,j.moduleId,j.chatSelection):source.board?.modules?.find(m=>m.id===j.moduleId);
   if(module&&!j.chatSelection&&!j.artifactSelection&&(j.candidateSelection||source.candidateRevisions?.[module.id])){
    const candidates=require('./meeting-candidates'),current=candidates.snapshot(source,ctx.session?.(meetingId)||{},module.id);
    if(j.candidateSelection&&(j.candidateSelection.id!==module.id||j.candidateSelection.revision!==current.revision))throw Object.assign(Error('Candidate changed; review the current draft before collecting'),{status:409});
    // Read canonical fresh revisions; never accept draft content from the caller.
    module={...module,body:current.body,sourceRefs:current.sourceRefs,...(current.nodes?{nodes:current.nodes,edges:current.edges,graph:{nodes:current.nodes,edges:current.edges}}:{})};
   }
   if(!module||(!['note','plan','map','task','action'].includes(module.kind)&&!module.actionText?.trim()))throw Error('No editable meeting draft');
   send(200,store.collectModule(id,meetingModule(require('./generated-preparation-module')(ctx.hub.data,source,module)),meetingId,j.expectedRevision,j.operationId,j.chapterId));return true;
  }
  if(j.action==='import'){
   if(!source||source.motherDocumentId!==id)throw Object.assign(Error('Meeting is no longer linked to this document'),{status:409});
   // Explicit continuations contain only the user's selection. Opening an
   // editor must not expand it; adding more remains an explicit collect action.
   if(store.read(id).record.fork){send(200,{unchanged:true});return true;}
   const module=source.board?.modules?.find(m=>m.id===j.moduleId);if(!module||!['note','plan','map','task'].includes(module.kind))throw Error('No editable meeting draft');const upgrade=require('./generated-preparation-module'),result=store.importModule(id,meetingModule(upgrade(ctx.hub.data,source,module)),meetingId);const orphan=module.id==='premeeting-materials'?upgrade.orphanCandidate(ctx.hub.data,source,store.read(id).record,meetingId):null;const refreshed=orphan?store.importModule(id,meetingModule(orphan),meetingId):null;send(200,result?.conflict||refreshed?.conflict?{conflict:true}:(refreshed||result||{unchanged:true}));return true;
  }
  throw Error('Unknown document action');
 }catch(e){send(e.status||400,{error:e.message});return true;}
};
