'use strict';
// 产品默认专名与用户词表分开，绝不向用户库写入默认行或个人姓名。
const DEFAULT_LEXICON = Object.freeze([
  { right: 'CDCP', wrong: ['cccp', 'CCP', 'C D C P', '西迪西皮'] },
  { right: 'PDCP', wrong: [] },
  { right: 'ADCP', wrong: [] },
  { right: 'PDT', wrong: [] },
].map(row => Object.freeze({ right: row.right, wrong: Object.freeze(row.wrong) })));

function defaultHotwords() { return DEFAULT_LEXICON.map(row => row.right); }

const escape = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const han = /\p{Script=Han}/u;
// 英文词可紧邻中文句子，但不能嵌在英文单词、数字或标识符中。
// 中文错写保守地要求两侧都是词界，避免误改更长的姓名 / 中文词。
const boundary = s => han.test(s) ? '[\\p{L}\\p{N}\\p{M}_]' : '[\\p{Script=Latin}\\p{N}\\p{M}_]';

function buildRules(rows = [], opts = {}) {
  const targets = new Map();
  const ignore = new Set((opts.ignore || []).map(s => String(s).toLowerCase()));
  const add = (wrong, right) => {
    const from = String(wrong || '').trim(), to = String(right || '').trim();
    if ([...from].length < 2 || from.length > 40 || !to || to.length > 40 || from === to) return;
    const key = from.toLowerCase();
    if (!targets.has(key)) targets.set(key, { from, to });
  };
  // 显式用户纠错优先；不自动推断别名，不依赖参会人名单。
  for (const row of rows) if (row && row.state === 'active' && !(row.harm_count >= 3)) add(row.wrong, row.right);
  for (const row of opts.defaults ?? DEFAULT_LEXICON) for (const wrong of row.wrong) add(wrong, row.right);
  const entries = [...targets.values()].sort((a, b) => b.from.length - a.from.length);
  const patterns = entries.map(({ from }) => '(?<!' + boundary(from) + ')' + escape(from) + '(?!' + boundary(from) + ')');
  return { targets, ignore, re: patterns.length ? new RegExp(patterns.join('|'), 'giu') : null };
}

function fix(text, rules) {
  const original = String(text ?? ''), changes = [];
  if (!rules?.re) return { text: original, changes };
  // 一次扫描原文，替换产生的文本不再成为另一条规则的输入。
  const out = original.replace(rules.re, from => {
    const to = rules.targets.get(from.toLowerCase()).to;
    if (from === to || rules.ignore.has((from + '→' + to).toLowerCase())) return from;
    changes.push({ from, to }); return to;
  });
  return { text: out, changes };
}

module.exports = { DEFAULT_LEXICON, defaultHotwords, buildRules, fix };
