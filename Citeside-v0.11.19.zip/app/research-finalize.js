'use strict';
// Called only after ASR drain. No model/storage adapters of its own.
async function finalizeResearch(session, { getProvider = () => require('./research-report').current, log = () => {}, timeoutMs = 120000 } = {}) {
 const p=getProvider();if(typeof p!=='function')return null;
 try {
  const work=(async()=>{
   for(let attempt=0;attempt<3;attempt++){
    const snap=p(session,{final:true,startFinal:true});
    if(!snap?.pending)return snap;
    const settled=await p.settled(session.id);
    if(settled?.final||!settled?.incomplete)return settled;
   }
   return {final:false,incomplete:true};
  })();
  let timer;
  const final=await Promise.race([work,new Promise(resolve=>{timer=setTimeout(()=>resolve({final:false,incomplete:true,reason:'timeout'}),timeoutMs);})]).finally(()=>clearTimeout(timer));
  if(final?.incomplete)log('research final incomplete '+session.id);
  return final;
 } catch(e) {log('research final failed '+session.id+' '+e.message);return {final:false,incomplete:true};}
}
module.exports={finalizeResearch};
