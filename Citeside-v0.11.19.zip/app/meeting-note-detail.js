'use strict';
// Read the actual saved note. Opening this view must not create, bind, file,
// synchronize or rewrite a document.
const fail=(message,status=409)=>Object.assign(Error(message),{status});
const ID=/^[A-Za-z0-9_.-]{1,100}$/;
function read({dataDir,hub,id,getSession=()=>null,getPending=()=>({}),titleFor,ensureTitle}={}){
 if(!ID.test(id||''))throw fail('无效会议编号。',400);
 const source=hub?.data?.sources?.find(value=>value.sessionId===id||value.key==='session:'+id),session=getSession(id);
 if(!source&&!session)throw fail('未找到这场会议。',404);
 const title=titleFor?titleFor(session||{id},source):source?.title||session?.title||'';
 const result={id,title,start:session?.start??session?.startTs??source?.date??null,end:session?.end??(session?.finalized?session?.endTs:null)??null,document:null};
 if(ensureTitle&&session&&source?.kind!=='note')result.titleJob=ensureTitle(session,source);
 if(!source?.motherDocumentId){
  const saved=require('./legacy-meeting-note').build({id,title,session:session||{},pending:getPending(id)||{},source:source||{}});
  if(saved){
   result.savedNote={...saved,shareable:true,shareReason:''};
   try{require('./meeting-cloud-share').snapshot({...saved,title},null,id);}
   catch(error){result.savedNote.shareable=false;result.savedNote.shareReason=error.message;}
  }
  return result;
 }
 const {record,doc}=require('./mother-documents').get(dataDir).read(source.motherDocumentId);
 if(!(record.meetings||[]).some(value=>(typeof value==='string'?value:value?.id||value?.meetingId)===id))throw fail('笔记绑定已变化，请重新打开这场会议。');
 const content=require('./mother-document-runtime').yDocToProsemirrorJSON(doc,'default');
 require('./mother-document-schema').validate(content);
 result.document={id:record.id,revision:record.revision,meetingIds:record.meetings,content};
 return result;
}
async function route(req,res,url,context={}){
 const pathname=url.pathname.replace(/^\/asr-relay/,'');
 if(!['/meeting-note-detail','/meeting-title-status'].includes(pathname))return false;
 const send=(status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));return true;};
 if(!context.authed)return send(401,{error:'unauthorized'});
 if(req.method!=='GET')return send(405,{error:'method not allowed'});
 if(pathname==='/meeting-title-status'){const id=url.searchParams.get('id');if(!ID.test(id||''))return send(400,{error:'无效会议编号。'});return send(200,{id,job:context.titleStatus?.(id)||null});}
 try{return send(200,read({...context,id:url.searchParams.get('id')}));}
 catch(error){return send(error.status||503,{error:error.status?error.message:'已保存的笔记暂时无法读取，请稍后重试。'});}
}
function savedForShare(options,request={}){
 if(request.noteVersion!==undefined){
  const detail=read({...options,ensureTitle:undefined});
  if(detail.document||!detail.savedNote||detail.savedNote.hash!==request.noteVersion)throw fail('笔记版本或关联已变化，请关闭详情后重新打开。');
  if(!detail.savedNote.shareable)throw fail(detail.savedNote.shareReason||'这份笔记暂不支持云分享。');
  const out={...detail.savedNote,title:detail.title,noteVersion:detail.savedNote.hash};
  if(options.dataDir)Object.defineProperty(out,'dataDir',{value:options.dataDir,enumerable:false});
  return out;
 }
 return require('./meeting-cloud-share').savedNote({dataDir:options.dataDir,hub:options.hub,meetingId:options.id,...request,titleFor:(_,source)=>options.titleFor?options.titleFor(options.getSession?.(options.id)||{id:options.id},source):source.title});
}
module.exports={read,route,savedForShare};
