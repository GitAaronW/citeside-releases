'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const QUESTION_STATES = new Set(['open', 'partial', 'resolved', 'deferred']);

function cleanDisplayName(value) {
  const name = String(value || '').trim().slice(0, 80);
  return name || '我';
}

// Names are recognition vocabulary, never evidence that a speaker is the owner.
const nameListeners = new Set();
function profileNames(profile) {
  return [...new Set([profile && profile.displayName, ...(Array.isArray(profile && profile.names) ? profile.names : [])]
    .filter(n => typeof n === 'string').map(n => n.trim()).filter(n => n && n !== '我'))];
}
function profileRoleKeywords(profile) {
  const out = [], seen = new Set();
  for (const raw of Array.isArray(profile && profile.roleKeywords) ? profile.roleKeywords : []) {
    if (typeof raw !== 'string') continue;
    const kw = raw.trim();
    if (kw.length < 2 || kw.length > 80 || /[\r\n\x00-\x1f<>]/.test(kw)) continue;
    const key = kw.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key); out.push(kw);
    if (out.length >= 16) break;
  }
  return out;
}
function onNameChange(listener) { nameListeners.add(listener); return () => nameListeners.delete(listener); }

function loadOwnerProfile(dataDir) {
  const file = path.join(dataDir, 'owner-profile.json');
  let profile = null;
  try { profile = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) {}
  if (!profile || !/^owner-[0-9a-f-]{36}$/.test(String(profile.id || ''))) {
    profile = { id: 'owner-' + crypto.randomUUID(), displayName: cleanDisplayName(profile && profile.displayName), createdAt: Date.now() };
    require('./durable-json').write(file, profile, { space: 2 });
  } else {
    profile = { ...profile, displayName: cleanDisplayName(profile.displayName) };
  }
  fs.chmodSync(file, 0o600);
  return {...profile, names: profileNames(profile), roleKeywords: profileRoleKeywords(profile), needsName: profile.displayName === '我' && !profile.namePromptSkippedAt};
}

function saveOwnerName(dataDir, value, names, roleKeywords) {
  if (names !== undefined && (!Array.isArray(names) || names.length > 20 || names.some(n => typeof n !== 'string' || n.length > 80 || /[\r\n\x00-\x1f<>]/.test(n)))) throw Error('Invalid names / 姓名格式不正确');
  if (roleKeywords !== undefined && (!Array.isArray(roleKeywords) || roleKeywords.length > 16 || roleKeywords.some(n => typeof n !== 'string' || n.length > 80 || /[\r\n\x00-\x1f<>]/.test(n)))) throw Error('Invalid role keywords / 岗位关键词格式不正确');
  if (typeof value !== 'string' || value.length > 80 || /[\r\n\x00-\x1f<>]/.test(value)) throw Error('姓名格式不正确 / Invalid display name');
  const profile = { ...loadOwnerProfile(dataDir), displayName: cleanDisplayName(value), needsName: cleanDisplayName(value)==='我', namePromptSkippedAt: 0, updatedAt: Date.now() };
  profile.names = profileNames({displayName: profile.displayName, names: names === undefined ? profile.names : names});
  profile.roleKeywords = profileRoleKeywords({roleKeywords: roleKeywords === undefined ? profile.roleKeywords : roleKeywords});
  const file = path.join(dataDir, 'owner-profile.json');
  require('./durable-json').write(file, profile, { space: 2 });
  for (const listener of nameListeners) { try { listener(dataDir, profile); } catch (_) {} }
  return profile;
}

function skipOwnerName(dataDir) {
  const profile = {...loadOwnerProfile(dataDir), namePromptSkippedAt: Date.now(), needsName: false};
  const file = path.join(dataDir, 'owner-profile.json');
  require('./durable-json').write(file, profile, { space: 2 });
  return profile;
}

// Model answers remain suggestions with original evidence; user status corrections always win.
function applyQuestionAnswers(questions, updates, rows, now = Date.now()) {
  if (!Array.isArray(updates) || !Array.isArray(questions)) return 0;
  const ids = new Map(rows.map((r, i) => [String(r.segId || r.id || 'segment-' + i), i])); let changed = 0;
  for (const update of updates.slice(0, 20)) {
    const q = questions.find(q => q.id === update.id);
    if (!q || !q.sourceRefs?.length || q.statusEdited || !['partial', 'resolved'].includes(update.status)) continue;
    const at = Math.max(...q.sourceRefs.map(r => ids.get(String(r.id)) ?? Infinity));
    const refs = Array.isArray(update.answerRefs) ? [...new Set(update.answerRefs.map(String))].filter(id => ids.has(id) && ids.get(id) > at).slice(0, 20) : [];
    if (!refs.length || refs.length !== new Set(update.answerRefs.map(String)).size) continue;
    if (q.status === update.status && JSON.stringify(q.answerRefs) === JSON.stringify(refs)) continue;
    q.status = update.status; q.answerRefs = refs; q.updatedAt = now; q.answerSource = 'AI suggestion'; changed++;
  }
  return changed;
}

function clampConfidence(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0;
}

function signalAttribution(who, confidence, now = Date.now()) {
  if (who !== 'me' && who !== 'them') return null;
  return { candidate: who === 'me', source: 'split_track', confidence: clampConfidence(confidence), correctedByUser: false, updatedAt: now };
}

function manualAttribution(verdict, now = Date.now()) {
  if (!['me', 'not_me', 'unknown'].includes(verdict)) return null;
  return { candidate: verdict === 'unknown' ? null : verdict === 'me', source: 'manual', confidence: verdict === 'unknown' ? 0 : 1, correctedByUser: true, updatedAt: now };
}

// Provider speaker numbers are local to a recognition connection, not a person identity.
function verdictKey(row) {
  const speaker = String(row && (row.speaker || row.who) || '');
  const streamId = String(row && (row.recognitionStreamId || row.sourceTiming && row.sourceTiming.streamId) || '');
  return streamId ? '$recognition:' + JSON.stringify([streamId, speaker]) : speaker;
}

function applyManualAttribution(rows, speaker, verdict, now = Date.now()) {
  const attribution = manualAttribution(verdict, now);
  if (!attribution || !speaker || !Array.isArray(rows)) return 0;
  let changed = 0;
  for (const row of rows) {
    if (String(row.speaker || row.who || '') !== String(speaker)) continue;
    row.ownerAttribution = { ...attribution };
    changed++;
  }
  return changed;
}

function looksLikeQuestion(text) {
  const value = String(text || '').trim();
  return /[?？]\s*$/.test(value) || /(?:吗|呢|怎么|如何|为什么|是否|哪(?:个|些|里)|谁|什么|多少|多久)/u.test(value) || /\b(?:when|where|who|what|why|how)\b/iu.test(value);
}

function questionId(row) {
  return 'oq-' + crypto.createHash('sha256').update(String(row.id || row.seg || '') + '\n' + String(row.text || '')).digest('hex').slice(0, 16);
}

function addOwnerQuestion(questions, row, now = Date.now()) {
  if (!Array.isArray(questions) || !row || !row.ownerAttribution || row.ownerAttribution.candidate !== true || !looksLikeQuestion(row.text)) return null;
  const ref = String(row.id || row.seg || '').trim();
  if (!ref) return null;
  const id = questionId(row);
  const existing = questions.find(q => q && q.id === id);
  if (existing) return existing;
  const question = { id, text: String(row.text || '').trim().slice(0, 1000), status: 'open', sourceRefs: [{ type: 'utterance', id: ref }], answerRefs: [], confidence: clampConfidence(row.ownerAttribution.confidence), humanEdited: row.ownerAttribution.source === 'manual', createdAt: now, updatedAt: now };
  questions.push(question);
  return question;
}

function pruneOwnerQuestions(questions, rows) {
  if (!Array.isArray(questions) || !Array.isArray(rows)) return 0;
  const ineligible = new Set(rows
    .filter(row => row && row.ownerAttribution && row.ownerAttribution.candidate !== true)
    .map(row => String(row.id || row.seg || '').trim()).filter(Boolean));
  if (!ineligible.size) return 0;
  const before = questions.length;
  const kept = questions.filter(question => !(question && Array.isArray(question.sourceRefs)
    && question.sourceRefs.some(ref => ref && ref.type === 'utterance' && ineligible.has(String(ref.id || '')))));
  questions.splice(0, questions.length, ...kept);
  return before - questions.length;
}

function updateOwnerQuestion(questions, patch, validUtteranceIds, now = Date.now()) {
  if (!Array.isArray(questions) || !patch || !QUESTION_STATES.has(patch.status)) return null;
  const question = questions.find(q => q && q.id === patch.id);
  if (!question) return null;
  const valid = validUtteranceIds instanceof Set ? validUtteranceIds : new Set(validUtteranceIds || []);
  const refs = Array.isArray(patch.answerRefs) ? [...new Set(patch.answerRefs.map(String).filter(id => valid.has(id)))].slice(0, 50) : question.answerRefs;
  question.status = patch.status;
  question.answerRefs = refs;
  question.humanEdited = true;
  question.statusEdited = true;
  question.updatedAt = now;
  return question;
}

module.exports = { QUESTION_STATES, profileNames, profileRoleKeywords, onNameChange, loadOwnerProfile, saveOwnerName, skipOwnerName, applyQuestionAnswers, signalAttribution, manualAttribution, verdictKey, applyManualAttribution, addOwnerQuestion, pruneOwnerQuestions, updateOwnerQuestion, looksLikeQuestion };
