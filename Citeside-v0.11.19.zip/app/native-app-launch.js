'use strict';
const path=require('path');
const fs=require('fs');
const REGISTER='/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister';
// Register the verified installed copy before dispatching through LaunchServices.
// Registration changes neither the signed bundle nor its recording permissions.
// An unchanged bundle skips codesign and lsregister; open failure or any bundle edit verifies again.
function create({app,execute=require('child_process').execFile}) {
  if(!path.isAbsolute(app)||!app.endsWith('.app'))throw Error('native_app_absolute_path_required');
  let verifiedStamp=null;
  function bundleStamp(){
    const macDir=path.join(app,'Contents','MacOS');
    const sigFile=path.join(app,'Contents','_CodeSignature','CodeResources');
    const plist=path.join(app,'Contents','Info.plist');
    const stampOf=p=>{const s=fs.statSync(p);return `${s.ino}:${s.size}:${s.mtimeMs}:${s.ctimeMs}`;};
    try{
      const parts=[stampOf(app),stampOf(macDir),stampOf(sigFile)];
      const entries=fs.readdirSync(macDir).sort();
      if(!entries.length)return null;
      for(const name of entries)parts.push(stampOf(path.join(macDir,name)));
      try{parts.push(stampOf(plist));}catch{parts.push('0');}
      return parts.join('|');
    }catch{return null;}
  }
  return (args,done)=>{
    const options={timeout:6000,maxBuffer:256*1024};
    const openOnly=()=>execute('/usr/bin/open',['-g','-n','-a',app,'--args',...args],options,err=>{if(err)verifiedStamp=null;done(err);});
    const stamp=bundleStamp();
    if(stamp&&verifiedStamp===stamp)return openOnly();
    verifiedStamp=null;
    execute('/usr/bin/codesign',['--verify','--deep','--strict',app],options,error=>{
      if(error)return done(Error('native_app_signature_invalid'));
      execute(REGISTER,['-f',app],options,error=>{
        if(error)return done(Error('native_app_registration_failed'));
        verifiedStamp=bundleStamp();
        openOnly();
      });
    });
  };
}
module.exports={create,REGISTER};
