'use strict';
// 主动智能批 4（需求单 F5）：每场结束会后台那块小统计——四个数，全部从账本和场次文件算出来，不另存一份计数器。
//   jevCalls     = usage.jsonl 里 sessionId 相同且 provider === 'jev' 的行数（每次门卫调用记一行，失败也记；app/jev-gate.js）
//   sonnetCalls  = usage.jsonl 里 sessionId 相同、provider !== 'jev'、tier 属于 live 档（live / triage / quick）的行数
//                  ——「Sonnet」是会中分诊的 live 档模型（settings 的 LLM_MODEL_LIVE 默认 sonnet）；这里按档位数，换了模型也不用改
//   insights     = 场次 factchecks（看法卡）条数 + nativeInsights.history 里没被顶掉的卡（按 key 去重）
//                  ——10-22 起会中卡走 nativeInsights，只数 factchecks 时每场都是「洞察 0」（会后问题单 2026-10-24）
//   adopted      = 看法卡里被采纳的：rating === 'adopt'，或者那一个按钮已经执行完（actionState.status === 'done'）——点按钮 = 批准 = 采纳；
//                  再加账本 state/card-signals.jsonl 里本场 adopt / copy 过的卡（同一张卡只算一次）
//   seen         = 账本里本场记过 shown 的卡数（采纳率的分母；老版本没埋点时为 0）
//   post         = 会后行动卡按卡取最后一个状态再计数 { mine, dispatch, done, dismiss }：同一张卡点两次只算一张，先「不要」后「我来做」记「我来做」
//   sourceHit    = {hit, miss}：按钮执行时出处 / 承诺卡查到没有（卡片字段 sourceHit 'hit' | 'miss'，路由写；Aaron 2026-09-22 拍板用它量一周再决定要不要前置核对）
// 账本只读一遍：先按 sessionId 子串粗筛再 JSON.parse，usage.jsonl.1（滚过的那份）一起看。
const fs = require('fs'), path = require('path');

const LIVE_TIERS = new Set(['live', 'triage', 'quick']);

function readUsageRows(dataDir, sessionId) {
  const sid = String(sessionId || '');
  if (!dataDir || !sid) return [];
  const needle = JSON.stringify(sid);
  const rows = [];
  for (const name of ['usage.jsonl.1', 'usage.jsonl']) {
    let txt = '';
    try { txt = fs.readFileSync(path.join(dataDir, 'state', name), 'utf8'); } catch (e) { continue; }
    for (const line of txt.split('\n')) {
      if (!line || !line.includes(needle)) continue;
      try { const j = JSON.parse(line); if (j && String(j.sessionId || '') === sid) rows.push(j); } catch (e) {}
    }
  }
  return usageFacts(rows);
}

// New attempt facts and legacy successful rows share the same ledger. An
// attemptId counts once even across rotated copies; old rows remain unchanged.
function usageFacts(rows,{modelOnly=false}={}){
 const out=[],positions=new Map();
 for(const row of Array.isArray(rows)?rows:[]){
  if(!row)continue;
  if(!row.attemptId){out.push(row);continue;}
  if(!positions.has(row.attemptId)){positions.set(row.attemptId,out.length);out.push(row);continue;}
  const index=positions.get(row.attemptId),previous=out[index];
  if(row.eventKind==='result'||previous.eventKind!=='result')out[index]={...previous,...row};
 }
 return out.filter(row=>row.status!=='not-sent'&&(!modelOnly||!row.resource||row.resource==='model'));
}

function compute(sess, usageRows, signals) {
  const rows = usageFacts(usageRows,{modelOnly:true});
  const sigs = Array.isArray(signals) ? signals : [];
  // 同一张卡按 id（没 id 按 claim）只算一张：合并 / 重复回流 / 老数据里同卡出现两次，不多算（Codex 9f54c7ad 初审）
  const byKey = new Map();
  for (const c of Array.isArray(sess && sess.factchecks) ? sess.factchecks : []) {
    if (!c || typeof c !== 'object') continue;
    const key = c.id ? 'id:' + c.id : 'claim:' + String(c.claim || '');
    const prev = byKey.get(key) || { adopted: false, sourceHit: '' };
    prev.adopted = prev.adopted || c.rating === 'adopt' || !!(c.actionState && c.actionState.status === 'done');
    if (!prev.sourceHit && (c.sourceHit === 'hit' || c.sourceHit === 'miss')) prev.sourceHit = c.sourceHit;
    byKey.set(key, prev);
  }
  const ni = sess && sess.nativeInsights;
  for (const h of ni && Array.isArray(ni.history) ? ni.history : []) {
    if (!h || h.superseded || !h.key) continue;
    const key = 'ni:' + h.key;
    if (!byKey.has(key)) byKey.set(key, { adopted: false, sourceHit: '' });
  }
  // 账本：会中卡带 key 的对回 history；对不上的（会议页候选等）按 cardId 单算一张，保证 adopted ≤ insights
  const seenIds = new Set(), postLast = new Map(), post = { mine: 0, dispatch: 0, done: 0, dismiss: 0 };
  for (const g of sigs) {
    if (!g || !g.cardId) continue;
    const id = String(g.cardId);
    if (g.source === 'post') { if (g.action in post) postLast.set(id, g.action); continue; }   // 账本按写入顺序读，后写的盖前面的
    if (g.action === 'shown') { seenIds.add(g.key ? 'ni:' + g.key : id); continue; }
    if (g.action !== 'adopt' && g.action !== 'copy') continue;
    const key = g.key && byKey.has('ni:' + g.key) ? 'ni:' + g.key : byKey.has('id:' + id) ? 'id:' + id : 'sig:' + id;
    const prev = byKey.get(key) || { adopted: false, sourceHit: '' };
    prev.adopted = true; byKey.set(key, prev);
  }
  for (const a of postLast.values()) post[a]++;
  const jevCalls = rows.filter(r => r && r.provider === 'jev').length;
  const sonnetCalls = rows.filter(r => r && r.provider !== 'jev' && LIVE_TIERS.has(String(r.tier || ''))).length;
  const adopted = [...byKey.values()].filter(x => x.adopted).length;
  const sourceHit = { hit: [...byKey.values()].filter(x => x.sourceHit === 'hit').length, miss: [...byKey.values()].filter(x => x.sourceHit === 'miss').length };
  return { jevCalls, sonnetCalls, insights: byKey.size, adopted, sourceHit, seen: seenIds.size, post, at: Date.now() };
}

// goal = 核心目标四个数的本场快照（app/goal-metrics.js）；M3 要跨场比，单场只给纠正明细，重复数看全量报告
function forSession(dataDir, sess) {
  let sigs = [];
  try { sigs = (dataDir && sess && sess.id && require('./card-signals').bySession(dataDir).get(String(sess.id))) || []; } catch (e) { sigs = []; }
  const st = compute(sess, readUsageRows(dataDir, sess && sess.id), sigs);
  try { const gm = require('./goal-metrics'); st.goal = gm.forSession(sess, gm.ctxFor(gm.loadContext(dataDir), sess)); } catch (e) { st.goal = null; }
  return st;
}

module.exports = { compute, readUsageRows, forSession, usageFacts, LIVE_TIERS };
