'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const fail = (message, status = 409) => { throw Object.assign(new Error(message), { status }); };
const hasText = s => [s?.transcript, s?.fullTranscript].some(rows => Array.isArray(rows) && rows.some(r => String(r.text || '').trim()));
function rowText(row) { return String(row?.text || '').trim(); }
function baseRows(session) {
  const primary = Array.isArray(session?.transcript) ? session.transcript : [];
  if (primary.some(rowText)) return primary;
  if (Array.isArray(session?.fullTranscript) && session.fullTranscript.some(rowText)) return session.fullTranscript;
  return primary;
}
function replayRows(session) {
  return [session?.transcript, session?.fullTranscript].flatMap(rows => Array.isArray(rows) ? rows : []);
}
function savedReplay(session, input) {
  // This marks an atomically saved replay result, not ASR coverage of its audio.
  return !!input && replayRows(session).some(row => row?.pendingReplay?.input === input && row.pendingReplay.resultSaved === true);
}
// Keep all repeated speech. Only the same source batch and row position identify
// a retry; matching words, speaker labels or timestamps do not prove overlap.
function mergeTail(session, rows, input = '') {
  const base = baseRows(session).slice();
  const seen = new Set(replayRows(session)
    .filter(row => input && row?.pendingReplay?.input === input)
    .map(row => row.pendingReplay.index));
  let lastAt = 0;
  for (const row of base) if (Number.isFinite(row?.at)) lastAt = Math.max(lastAt, row.at);
  const hasKept = base.some(rowText);
  const added = [];
  for (const [index, row] of (rows || []).entries()) {
    const text = rowText(row);
    if (!text || (input && seen.has(index))) continue;
    const rel = Number.isFinite(row?.at) ? row.at : 0;
    added.push({ ...row, text, at: hasKept ? lastAt + rel : rel,
      ...(input ? { id: 'rt-' + input + '-' + index, pendingReplay: { input, index, resultSaved: true } } : {}) });
  }
  return base.concat(added);
}
function pendingKey(pending) {
  if (!pending || !Array.isArray(pending.ids) || !pending.ids.length) return '';
  return JSON.stringify(pending.ids.map((id, i) => [id, pending.capturedAt[i], pending.bytes[i]]));
}
function describePending(cache, sessionId, selectedIds) {
  if (!cache || typeof cache.list !== 'function' || typeof sessionId !== 'string' || !sessionId) return null;
  let items = cache.list(sessionId);
  if (selectedIds) {
    const selected = new Set(selectedIds);
    items = items.filter(item => selected.has(item.id));
    if (items.length !== selected.size) fail('待转写音频已到期或不可用');
  }
  if (!items.length) return null;
  return {
    ids: items.map(item => item.id),
    capturedAt: items.map(item => item.capturedAt),
    bytes: items.map(item => item.bytes),
    byteLength: items.reduce((sum, item) => sum + item.bytes, 0),
    open() {
      const iterable = {
        byteLength: items.reduce((sum, item) => sum + item.bytes, 0),
        // Provider adapters without segment times can identify only the original
        // capture position sent when a result arrived, not exact speech alignment.
        captureAt(byte) {
          let remaining = Math.max(0, byte);
          for (const item of items) {
            if (remaining < item.bytes) return item.capturedAt + remaining / 32;
            remaining -= item.bytes;
          }
          const last = items.at(-1);
          return last.capturedAt + last.bytes / 32;
        },
        async *[Symbol.asyncIterator]() {
          for (const item of items) {
            const pcm = cache.read(item.id); // Recheck the original 24h deadline on every chunk.
            if (pcm.length !== item.bytes) fail('待转写音频已变化');
            for (let offset = 0; offset < pcm.length; offset += 6400) yield pcm.subarray(offset, offset + 6400);
          }
        },
      };
      return iterable;
    },
  };
}
function releaseConfirmed(cache, sessionId, ids) {
  const binder = require('./pending-audio-policy').createBinder({ cache, sessionId });
  const result = binder.release({ chunkIds: ids }, true);
  if (result.stopped) throw Object.assign(Error('转写已保存，部分待转写音频未能删除'), { status: 500, retained: result.retained });
  return result;
}
function openAudio(file, source) {
  if (source && typeof source[Symbol.asyncIterator] === 'function') return source;
  if (source && typeof source[Symbol.iterator] === 'function') return (async function* () { for (const chunk of source) yield chunk; })();
  if (typeof file === 'string' && file) return fs.createReadStream(file, { highWaterMark: 6400 });
  throw Object.assign(Error('没有可重放的音频'), { status: 409 });
}
// A replay owns no recorder, never opens PCM for writing, and publishes only a final result.
function create({ audioDir, load, save, active, transcribe, readPending }) {
  const jobs = new Map();
  function loadTail(session) {
    if (typeof readPending !== 'function' || !session) return null;
    try {
      const found = readPending(session);
      if (!found || !Array.isArray(found.ids) || !found.ids.length || typeof found.open !== 'function') return null;
      return found;
    } catch (e) { return null; }
  }
  function inspect(id) {
    if (!/^[A-Za-z0-9_-]{1,80}$/.test(id)) fail('会议编号不对', 400);
    const session = load(id);
    if (!session) fail('找不到这场会议', 404);
    const file = path.join(audioDir, id + '.pcm');
    let audio = null;
    try { const s = fs.lstatSync(file); if (s.isFile() && s.size > 0 && s.size % 2 === 0) audio = { size: s.size, mtimeMs: s.mtimeMs }; } catch {}
    const pending = loadTail(session);
    const input = pending ? crypto.createHash('sha256').update(JSON.stringify([session.id, pendingKey(pending)])).digest('hex') : '';
    const replaySaved = savedReplay(session, input);
    const idle = !!session.end && !active(id);
    const eligible = idle && ((!!pending && !replaySaved) || (!pending && !hasText(session) && !!audio));
    return { session, file, audio, pending, input, replaySaved, idle, eligible };
  }
  function status(id) {
    const state = inspect(id), job = jobs.get(id);
    return { id, eligible: state.eligible, status: state.replaySaved ? 'done' : job?.status || 'idle', error: state.replaySaved ? '' : job?.error || '',
      ...(state.pending ? { pendingAudioCoverage: 'unproven', pendingAudioRetained: true } : {}) };
  }
  function start(id) {
    if (jobs.get(id)?.status === 'running') return status(id);
    const original = inspect(id);
    // The identity lives on saved rows, so a process restart or repeated POST
    // cannot launch the same input again or overwrite a later human edit.
    if (original.idle && original.replaySaved) return status(id);
    if (!original.eligible) fail('仅已结束、没有转写且保留音频的会议可重新转写');
    const job = { status: 'running', error: '' }; jobs.set(id, job);
    job.done = Promise.resolve().then(async () => {
      const rows = await transcribe(original.pending ? original.pending.open() : original.file, original.session);
      if (!Array.isArray(rows) || !rows.some(rowText)) fail('没有识别到文字，请检查音频或转写设置后重试');
      const current = inspect(id);
      if (!current.eligible || JSON.stringify(current.session) !== JSON.stringify(original.session) || JSON.stringify(current.audio) !== JSON.stringify(original.audio) || pendingKey(current.pending) !== pendingKey(original.pending)) fail('会议已变化，请重新打开后再试');
      const before = original.pending ? baseRows(current.session).length : 0;
      const transcript = original.pending ? mergeTail(current.session, rows, original.input) : rows;
      if (original.pending && transcript.length === before) fail('没有识别到文字，请检查音频或转写设置后重试');
      // load/check/save are synchronous: no continuation or edit can interleave here.
      save(id, { ...current.session, transcript, retranscribedAt: new Date().toISOString() });
      // Current replay adapters return text and a stream final ACK, but no
      // authenticated chunk-to-recognition coverage. Keep the ciphertext for
      // its original 24h window; a final ACK alone cannot authorize deletion.
      job.status = 'done';
    }).catch(e => { job.status = 'failed'; job.error = e.status ? e.message : '重新转写未完成，请检查转写设置后重试。音频仍保留。'; });
    return status(id);
  }
  return { status, start, wait: id => jobs.get(id)?.done };
}
async function handle(req, res, url, { authed, service }) {
  const reply = (code, value) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value)); };
  if (!authed) return reply(401, { error: '请先连接Citeside' });
  const id = String(url.searchParams.get('id') || '');
  try {
    if (req.method === 'GET') return reply(200, service.status(id));
    if (req.method === 'POST') return reply(202, service.start(id));
    return reply(405, { error: '不支持的操作' });
  } catch (e) { const code = Number(e.status || e.code); return reply(Number.isInteger(code) && code >= 400 && code <= 599 ? code : 500, { error: e.message }); }
}
// The caller supplies the existing ASR wire protocol and config. Testable without sockets.
function replay({ socket, file, source, configure, audioFrame, parse, timeoutMs = 120000, paceMs = 100 }) {
  return new Promise((resolve, reject) => {
    const rows = new Map(); let done = false, sentEnd = false, stream, seq = 2;
    const finish = (error) => {
      if (done) return; done = true; clearTimeout(deadline);
      try { if (typeof stream?.destroy === 'function') stream.destroy(); else if (typeof stream?.return === 'function') stream.return(); } catch {}
      try { socket.close(); } catch {}
      if (error) reject(error); else resolve([...rows.values()].sort((a,b) => a.at-b.at));
    };
    const deadline = setTimeout(() => finish(Error('ASR timeout')), timeoutMs);
    socket.on('error', e => finish(e));
    socket.on('close', () => finish(Error('ASR closed before final acknowledgement')));
    socket.on('message', bytes => {
      if (done) return;
      try {
        const result = parse(bytes);
        if (result.msgType === 15) return finish(Error('ASR rejected request'));
        const final = result.msgType === 9 && !!(result.flags & 2);
        for (const u of result.json?.result?.utterances || []) {
          if ((!u.definite && !final) || !String(u.text || '').trim()) continue;
          const at = Math.max(0, Number(u.start_time || 0) / 1000), key = String(u.start_time ?? '') + ':' + String(u.end_time ?? '');
          rows.set(key, { id: 'rt-' + key, at, speaker: String(u.additions?.speaker_id ?? u.additions?.speaker ?? u.speaker_id ?? u.speaker ?? ''), text: u.text.trim() });
        }
        if (final) finish(sentEnd ? null : Error('Premature ASR final acknowledgement'));
      } catch (e) { finish(e); }
    });
    socket.on('open', async () => {
      try {
        configure(socket);
        stream = openAudio(file, source);
        for await (const bytes of stream) {
          while (!done && socket.bufferedAmount > 64000) await new Promise(r => setTimeout(r, paceMs || 1));
          if (done) return;
          socket.send(audioFrame(bytes, seq++, false));
          if (paceMs) await new Promise(r => setTimeout(r, paceMs));
        }
        if (!done) { sentEnd = true; socket.send(audioFrame(Buffer.alloc(0), -seq, true)); }
      } catch (e) { finish(e); }
    });
  });
}
// Reuse local/alternative streaming adapters without their lossy pre-ready queues.
async function replayRecognizer({ file, source, make, ready, watchEnd = () => {}, paceMs = 200, readyTimeoutMs = 15000, signal, timeoutMs }) {
  const rows = []; let failure, ending = false, confirmed = false, bytesSent = 0;
  let cancel, timer, transport, client;
  const interrupted = new Promise((_, reject) => { cancel = () => reject(Error('ASR replay cancelled')); });
  // No wait (including a stuck drain) can outlive cancellation or the batch deadline.
  const step = promise => Promise.race([promise, interrupted]);
  signal?.addEventListener('abort', cancel, { once: true });
  if (signal?.aborted) cancel();
  timer = setTimeout(cancel, timeoutMs ?? Math.max(120000, (source?.byteLength || 0) / 32 * 1.5 + 30000));
  const sleep = () => new Promise(r => setTimeout(r, paceMs || 1));
  try {
    if (signal?.aborted) await step(Promise.resolve());
    client = make(result => {
      if (result.type === 'fatal') failure = Error('ASR unavailable');
      if (result.type === 'final' && String(result.text || '').trim()) {
        const capturedAt = source?.captureAt?.(bytesSent);
        rows.push({ id: 'rt-' + rows.length, at: Math.max(0, bytesSent / 32000), speaker: result.speaker || '', text: result.text.trim(),
          ...(Number.isFinite(capturedAt) ? { capturedAt, timingBasis: 'capture-send-position' } : {}) });
        if (ending) confirmed = true;
      }
    });
    client.start(); const deadline = Date.now() + readyTimeoutMs;
    while (!ready(client) && !failure && Date.now() < deadline) await step(sleep());
    if (failure || !ready(client)) throw failure || Error('ASR not ready');
    transport = client.sock || client.ws;
    for await (const bytes of openAudio(file, source)) {
      if (signal?.aborted || failure || !ready(client) || (transport && (client.sock || client.ws) !== transport)) throw failure || Error('ASR disconnected');
      bytesSent += bytes.length; client.write(bytes); await step(sleep());
    }
    if (failure || !ready(client) || client.droppedBytes || (transport && (client.sock || client.ws) !== transport)) throw failure || Error('ASR audio gap');
    watchEnd(client, () => { if (ending) confirmed = true; });
    ending = true; await step(client.drain());
    if (failure || !confirmed) throw failure || Error('ASR final unconfirmed');
    return rows;
  } finally { clearTimeout(timer); signal?.removeEventListener('abort', cancel); client?.stop(); }
}
module.exports = { create, handle, replay, replayRecognizer, hasText, describePending, releaseConfirmed, mergeTail };
