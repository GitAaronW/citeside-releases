'use strict';
const fs=require('fs'),path=require('path'),outbox=require('./notion-outbox'),content=require('./minutes-content'),share=require('./share');
const validId=/^[A-Za-z0-9_-]{1,80}$/,validUrl=/^https:\/\/(?:www\.|app\.)?notion\.(?:so|com)\/[^\s<>"']+$/;
const plainSession=(ctx,id)=>{
 const enhanced=ctx.session(id);let pending=null;try{pending=JSON.parse(fs.readFileSync(path.join(ctx.dataDir,'pending','sess-'+id+'.json'),'utf8'));}catch{}
 if(!pending&&!enhanced)return null;
 const s={...(pending||{}),...(enhanced||{})};
 s.transcript=require('./transcript-pick').pickTranscript(pending,enhanced);s.title=enhanced?.topicTitle||pending?.topicTitle||enhanced?.title||pending?.title||'';
 s.condensed=pending?.condensed||enhanced?.condensed||null;s.review=pending?.review||enhanced?.review||null;
 return s;
};
function noteOf(s,dataDir){
 if(s.brief?.overview){const cards=require('./actions').read(path.join(dataDir,'state/meeting-pipeline'),s.id)?.cards;return share.briefNote(s,cards);}
 const condensed=s.condensed||Object.fromEntries(Object.entries({highlights:15,todos:10,factchecks:8}).map(([k,n])=>[k,(s[k]||[]).slice(0,n)]));
 return require('./review').shareNote({...s,__noHead:true,calendarEvent:s.calendar?.event||null},s.review?.decisions||[],condensed);
}
function payloadOf(s,note){
 const v=content.view(s,note);
 return {meetingId:s.id,title:v.title,layout:'simple-v1',meta:v.meta.text,summary:content.summaryMarkdown(v),todos:content.todosMarkdown(v),includeTranscript:true,
  transcript:(s.transcript||[]).map(r=>({t:require('./meeting-time').meetingClock(r.at??r.atSec??r.t,s.start??s.startTs),who:share.who(s,r.speaker),text:r.text||''}))};
}
function stateOf(dataDir,id,desired){
 const job=outbox.read(dataDir).jobs.find(j=>j.kind==='meeting-minutes'&&j.key===id),current=job?.payload?.layout==='simple-v1';
 const fields=p=>JSON.stringify([p.title,p.meta,p.summary,p.todos,p.transcript]);
 const stale=!!(current&&desired&&fields(job.payload)!==fields(desired));
 const synced=!!(current&&!stale&&job.status==='done'&&validUrl.test(job.page?.url||''));
 return {ok:true,status:stale&&job.status==='done'?'none':current||['queued','running'].includes(job?.status)?job.status:'none',synced,url:synced?job.page.url:''};
}
async function route(req,res,u,ctx){
 const name=u.pathname.replace(/^\/asr-relay/,'');
 if(!['/meeting-board/minutes','/meeting-board/minutes-client.js'].includes(name))return false;
 const send=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(j));return true;};
 // Static code carries no meeting data or credential and has the same visibility as /seatnote/*.js.
 if(name.endsWith('-client.js')){if(req.method!=='GET')return send(405,{error:'method'});res.writeHead(200,{'Content-Type':'application/javascript; charset=utf-8','Cache-Control':'no-cache'});res.end(fs.readFileSync(path.join(__dirname,'../web/meeting-minutes.js'),'utf8'));return true;}
 if(!ctx.authed)return send(401,{error:'unauthorized'});
 if(!['GET','POST'].includes(req.method))return send(405,{error:'method'});
 const id=u.searchParams.get('id')||'';if(!validId.test(id))return send(400,{error:'会议编号不对'});
 if(req.method==='GET'){
  try{const s=plainSession(ctx,id);if(!s)return send(404,{error:'找不到这场会议'});return send(200,stateOf(ctx.dataDir,id,payloadOf(s,noteOf(s,ctx.dataDir))));}
  catch{return send(500,{error:'读取纪要失败，请重试'});}
 }
 if(req.headers.origin&&req.headers.origin!==u.origin){let same=false;try{same=new URL(req.headers.origin).host===req.headers.host;}catch{}if(!same)return send(403,{error:'origin'});}
 try{
  let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>4000)return send(413,{error:'too large'});}
  const j=JSON.parse(raw||'{}');if(j.confirmed!==true)return send(400,{error:'请先点击发到 Notion'});
  const s=plainSession(ctx,id);if(!s)return send(404,{error:'找不到这场会议'});
  if(!s.end&&!s.finalized)return send(409,{error:'请先结束会议'});
  const existing=outbox.read(ctx.dataDir).jobs.find(j=>j.kind==='meeting-minutes'&&j.key===id);
  if(['queued','running'].includes(existing?.status))return send(202,stateOf(ctx.dataDir,id));
  const payload=payloadOf(s,noteOf(s,ctx.dataDir)),{job,changed}=outbox.enqueue(ctx.dataDir,{kind:'meeting-minutes',key:id,payload});
  // Failed sends can be explicitly retried without changing saved meeting data.
  if(job.status==='failed'){const st=outbox.read(ctx.dataDir),cur=st.jobs.find(x=>x.id===job.id);cur.status='queued';cur.attempts=0;cur.error='';require('./durable-json').write(path.join(ctx.dataDir,'state','notion-outbox.json'),st);}
  if(changed||job.status==='failed'){
   if(ctx.minutesDrain)await ctx.minutesDrain();
   else void outbox.drain(ctx.dataDir,{runner:(prompt,o)=>require('./cli-llm').connector(prompt,o),parentId:(typeof ctx.env==='function'?ctx.env():ctx.env||{}).NOTION_MINUTES_PARENT||''}).catch(()=>{});
  }
  return send(job.status==='done'?200:202,stateOf(ctx.dataDir,id));
 }catch(e){return send(400,{error:e instanceof SyntaxError?'格式不对':e.message});}
}
module.exports={route,payloadOf,stateOf};
