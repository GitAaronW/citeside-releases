'use strict';
// Explicit cloud-trial transport. It never reads or forwards a personal provider key.
const { accountBase, loadSession } = require('./cloud-account');
function trialOn(env) {
  if (env && Object.prototype.hasOwnProperty.call(env, 'THT_CLOUD_TRIAL')) return String(env.THT_CLOUD_TRIAL) === '1';
  return String(process.env.THT_CLOUD_TRIAL || '') === '1';
}
function applyVolc(env, dataDir, role, local, language) {
  if (!trialOn(env)) return { ok: true, trial: false, url: local.url, headers: local.headers };
  let session;
  try { session = loadSession(dataDir, env); }
  catch { return { ok: false, error: '云试用地址无效，已停止，不会改用本机模型密钥' }; }
  if (!session) return { ok: false, error: '云试用未登录，已停止，不会改用本机模型密钥' };
  if (!['live', 'backfill', 'replay'].includes(role)) return { ok: false, error: '云试用转写角色无效' };
  const root = session.url.replace(/^http/, 'ws');
  const lang = ({ zh: 'zh-CN', en: 'en-US', 'zh-CN': 'zh-CN', 'en-US': 'en-US' })[language];
  return { ok: true, trial: true, url: root + '/v1/trial/asr?role=' + role + (lang ? '&lang=' + encodeURIComponent(lang) : ''), headers: { Authorization: 'Bearer ' + session.token, 'X-Api-Connect-Id': local.headers['X-Api-Connect-Id'], 'X-Api-Sequence': '-1' } };
}
function trialRoute(kind, stage, operation) {
  if (kind === 'post' || kind === 'think' || kind === 'insight-deep' || kind === 'verify' || stage === 'meeting-calibration') return 'slow';
  return 'fast';
}
// Explicit provisioning document, not an automatic replacement for a user's
// local routes. The operator declares the service boundary before activation.
function routingConfig({ endpoint, region, dataScope, roles, callBudget } = {}) {
  const routing = require('./model-routing');
  const config = { schemaVersion: 1,
    connections: { trial: { protocol: 'cloud-trial', endpoint: accountBase({ CLOUD_ACCOUNT_URL: endpoint }), region, dataScope } },
    profiles: Object.fromEntries(['fast','slow'].map(modelId => [modelId, { connection: 'trial', modelId, capabilities: { json: true, tools: false, vision: modelId === 'fast' } }])),
    roles: Object.fromEntries(routing.ROLES.map(role => [role, { primary: roles?.[role], fallback: [], deadlineMs: 90000 }])),
    ...(callBudget === undefined ? {} : { callBudget }) };
  return routing.compile(config).config;
}
function safeDiagnostic(value) {
  const kinds = ['http_error', 'invalid_json', 'empty_content', 'response_too_large', 'timeout', 'transport_error'];
  const codes = ['invalid_request_error', 'insufficient_balance', 'rate_limit_exceeded', 'context_length_exceeded', 'invalid_api_key', 'authentication_error', 'api_error', 'server_error', 'model_not_found'];
  const finishes = ['stop', 'length', 'content_filter', 'tool_calls', 'insufficient_system_resource'];
  return { ...(kinds.includes(value.kind) ? { kind: value.kind } : {}),
    ...(Number.isInteger(value.httpStatus) && value.httpStatus >= 100 && value.httpStatus <= 599 ? { httpStatus: value.httpStatus } : {}),
    ...(Number.isSafeInteger(value.latencyMs) && value.latencyMs >= 0 ? { latencyMs: value.latencyMs } : {}),
    ...(codes.includes(value.providerCode) ? { providerCode: value.providerCode } : {}),
    ...(finishes.includes(value.finishReason) ? { finishReason: value.finishReason } : {}) };
}
function safeUsage(usage) {
  if (!usage || typeof usage !== 'object') return null;
  const valid = n => Number.isSafeInteger(n) && n >= 0;
  const input = usage.prompt_tokens ?? usage.input_tokens, output = usage.completion_tokens ?? usage.output_tokens;
  if (!valid(input) || !valid(output)) return null;
  const nested = usage.completion_tokens_details?.reasoning_tokens ?? usage.output_tokens_details?.reasoning_tokens;
  const thinking = nested ?? usage.reasoning_tokens;
  const cached = usage.prompt_cache_hit_tokens ?? usage.prompt_tokens_details?.cached_tokens ?? usage.input_tokens_details?.cached_tokens;
  // Separate reasoning is additive only when the supplier total proves it.
  const out = nested == null && valid(thinking) && thinking > 0 && usage.total_tokens === input + output + thinking ? output + thinking : output;
  return { in: input, out, ...(valid(thinking) ? {thinking} : {}), ...(valid(cached) && cached <= input ? {cachedInput:cached} : {}) };
}
async function researchTask({ env, dataDir, fetchImpl = globalThis.fetch, ...body }) {
  let session;
  try { session = loadSession(dataDir, env); } catch {}
  if (!session) throw Object.assign(Error('cloud_trial_signed_out'), { code: 'cloud_trial_signed_out' });
  const response = await fetchImpl(session.url + '/v1/research/billing', {
    method: 'POST', redirect: 'error', signal: AbortSignal.timeout(10000),
    headers: { Authorization: 'Bearer ' + session.token, 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  const result = await response.json();
  if (!response.ok || result?.ok !== true) throw Object.assign(Error(result?.code || 'research_billing_unavailable'), { code: result?.code || 'research_billing_unavailable' });
  return result;
}
async function complete({ env, dataDir, system, user, images, maxTokens, temperature, json, fetchImpl, signal, path, kind, stage, operation, operationId, researchOperationId, billingTaskId, requireFullInput, route, endpoint }) {
  if (!trialOn(env)) return { ok: false, errorCode: 'cloud_trial_disabled' };
  let base; try { base = accountBase(env); } catch { return { ok: false, errorCode: 'cloud_trial_unavailable' }; }
  if (!base) return { ok: false, errorCode: 'cloud_trial_unavailable' };
  if (endpoint && accountBase({ CLOUD_ACCOUNT_URL: endpoint }) !== base) return { ok: false, errorCode: 'routing_trial_endpoint_mismatch' };
  if (route !== undefined && !['fast','slow'].includes(route)) return { ok: false, errorCode: 'routing_trial_model_invalid' };
  const session = loadSession(dataDir, env);
  if (!session) return { ok: false, errorCode: 'cloud_trial_signed_out' };
  let userContent = String(user || '');
  if (Array.isArray(images) && images.length) {
    if (images.length > 1) return { ok: false, errorCode: 'cloud_trial_single_image_only' };
    const img = images[0];
    const dataUrl = typeof img?.dataUrl === 'string' ? img.dataUrl : '';
    if (!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(dataUrl)) return { ok: false, errorCode: 'invalid_request' };
    userContent = [{ type: 'text', text: userContent }, { type: 'image_url', image_url: { url: dataUrl } }];
  }
  const body = { messages: [{ role: 'system', content: String(system || '') }, { role: 'user', content: userContent }], max_tokens: maxTokens || 512, temperature: temperature == null ? 0.2 : temperature, stream: false, route: route || trialRoute(kind, stage, operation) };
  if (operationId) body.operationId = operationId;
  if (researchOperationId) body.researchOperationId = researchOperationId;
  if (billingTaskId) body.billingTaskId = billingTaskId;
  if (kind === 'chat' || stage === 'workspace-chat') body.kind = 'chat';
  if (requireFullInput) body.require_full_input = true;
  if (json) body.response_format = { type: 'json_object' };
  const bodyJson = JSON.stringify(body);
  if (Array.isArray(images) && images.length && Buffer.byteLength(bodyJson, 'utf8') > 8 * 1024 * 1024) return { ok: false, errorCode: 'body_too_large' };
  try {
    const response = await (fetchImpl || globalThis.fetch)(base + path, {
      method: 'POST', redirect: 'error', signal: signal || AbortSignal.timeout(90000),
      headers: { Authorization: 'Bearer ' + session.token, 'Content-Type': 'application/json' }, body: bodyJson
    });
    const payload = await response.json();
    if (!response.ok || !payload || payload.ok === false) return { ok: false, errorCode: payload && payload.code || 'cloud_trial_unavailable', status: response.status,
      ...Object.fromEntries(['inputChars', 'inputLimit', 'outputTokens', 'outputLimit'].filter(k => Number.isSafeInteger(payload?.[k]) && payload[k] >= 0).map(k => [k, payload[k]])),
      ...(payload?.diagnostic ? { diagnostic: safeDiagnostic(payload.diagnostic) } : {}) };
    const text = payload.choices && payload.choices[0] && payload.choices[0].message && payload.choices[0].message.content;
    if (typeof text !== 'string' || !text) return { ok: false, errorCode: 'cloud_trial_empty' };
    const usage = payload.usage;
    return { ok: true, status: response.status, text, finishReason: payload.choices[0].finish_reason ?? null, outputTruncated: payload.choices[0].finish_reason === 'length', model: typeof payload.model === 'string' ? payload.model : '', usage: safeUsage(usage) };
  } catch { return { ok: false, errorCode: 'cloud_trial_unavailable' }; }
}
module.exports = { trialRoute, trialOn, applyVolc, complete, routingConfig, researchTask };
