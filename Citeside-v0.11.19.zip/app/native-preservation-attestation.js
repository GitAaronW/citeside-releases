'use strict';
// Evidence for retaining exact installed bytes. This never attests build source.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const {execFileSync} = require('node:child_process');
const OWNER = 'd6d982ef-f8a3-4b01-becc-1e7ccd5c52c6';
const TARGET = path.join(os.homedir(), 'Library/Application Support/Citeside/program');
const digest = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function signatureIdentity(app) {
  const result = require('node:child_process').spawnSync('/usr/bin/codesign', ['-dv', '--verbose=4', app], {encoding: 'utf8', timeout: 6000});
  if (result.error || result.status !== 0) throw Error('Cannot inspect installed signature');
  const output = result.stderr + result.stdout;
  const identifier = /^Identifier=(.+)$/m.exec(output)?.[1];
  const cdhash = /^CDHash=([a-f0-9]{40,64})$/m.exec(output)?.[1];
  if (!identifier || !cdhash) throw Error('Installed signature identity missing');
  return {identifier, cdhash};
}
function candidateCommit(root) {
  const stampFile = path.join(root, 'app/build-identity.json');
  const stamp = fs.existsSync(stampFile) ? JSON.parse(fs.readFileSync(stampFile, 'utf8')).commit : null;
  if (stamp !== null && !/^[a-f0-9]{40}$/.test(stamp || '')) throw Error('Invalid candidate stamp');
  if (!fs.existsSync(path.join(root, '.git'))) return stamp;
  const head = execFileSync('git', ['rev-parse', 'HEAD'], {cwd:root, encoding:'utf8', stdio:['ignore','pipe','pipe']}).trim();
  if (stamp !== null && stamp !== head) throw Error('Candidate Git HEAD and stamp mismatch');
  return head;
}
function filterProgramDiff(output, installedRoot) {
  const retained = new Set([
    'Files app/native-capture/build-provenance.json and ' + path.join(installedRoot, 'app/native-capture/build-provenance.json') + ' differ',
    'Only in ' + path.join(installedRoot, 'app/native-capture') + ': build-provenance.json',
  ]);
  return output.split('\n').filter(line => !retained.has(line)).join('\n');
}
function inspect(current, incoming, {localTarget = TARGET, identify = signatureIdentity} = {}) {
  const native = require('./native-update');
  if (fs.realpathSync(current) !== fs.realpathSync(localTarget)) throw Error('Preservation is limited to the local installed target');
  const candidateSha = candidateCommit(incoming);
  if (!/^[a-f0-9]{40}$/.test(candidateSha || '')) throw Error('Preservation candidate SHA missing');
  const helper = path.join(current, native.HELPER);
  const inputs = [...native.INPUTS, native.HELPER + '/Contents/Info.plist'];
  const currentInputs = Object.fromEntries(inputs.map(name => [name, digest(path.join(current, name))]));
  const incomingInputs = Object.fromEntries(inputs.map(name => [name, digest(path.join(incoming, name))]));
  if (inputs.some(name => currentInputs[name] !== incomingInputs[name])) throw Error('Preservation native inputs changed');
  return {
    schemaVersion: 1,
    kind: 'local-installed-preservation',
    buildSourceUnknown: true,
    installedRoot: fs.realpathSync(current),
    candidateSha,
    helperSha256: native.fingerprint(helper),
    signature: identify(helper),
    originalProvenanceSha256: digest(path.join(current, native.PROVENANCE)),
    currentInputs,
    incomingInputs,
  };
}
function validate(current, incoming, receiptFile, options = {}) {
  const native = require('./native-update');
  const verify = options.verifySignature || native.verify;
  verify(path.join(current, native.HELPER));
  verify(path.join(incoming, native.HELPER));
  const receipt = JSON.parse(fs.readFileSync(receiptFile, 'utf8'));
  const expected = inspect(current, incoming, options);
  const canonical = value => JSON.stringify(value && typeof value === 'object'
    ? Object.fromEntries(Object.keys(value).sort().map(key => [key, JSON.parse(canonical(value[key]))])) : value);
  for (const [key, value] of Object.entries(expected)) {
    if (canonical(receipt[key]) !== canonical(value)) throw Error('Preservation attestation mismatch: ' + key);
  }
  const auth = receipt.authorization;
  if (receipt.ownerThread !== OWNER || !auth?.quote?.trim() || !/^claude:\/\/sessions\/d6d982ef-f8a3-4b01-becc-1e7ccd5c52c6(?:$|[/?#])/.test(auth.source || '')) {
    throw Error('Preservation requires current quality owner authorization');
  }
  return {preserve: true, reason: 'exact-local-installed-artifact', helperSha256: expected.helperSha256, buildSourceUnknown: true};
}
module.exports = {inspect, validate, signatureIdentity, candidateCommit, filterProgramDiff, OWNER};
if (require.main === module) {
  if (process.argv[2] !== 'filter-diff' || !process.argv[3]) throw Error('Expected filter-diff INSTALLED_ROOT');
  process.stdout.write(filterProgramDiff(fs.readFileSync(0, 'utf8'), process.argv[3]));
}
