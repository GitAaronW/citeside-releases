'use strict';
// M1-IMPLICIT-SIGNAL（2026-10-23）：卡片上的三个动作就是信号，每点一次一条事件。
//   adopt   = 采纳（会中洞察卡「加进待办 / 记进要点」）
//   copy    = 复制（会中洞察卡「你可以问」复制到剪贴板、会议页候选「复制」）
//   dismiss = 关掉（会议页候选「不用」；会后行动卡「不要」）
// 会后问题单（2026-10-24）加四个：
//   shown    = 卡片在可视区停留 ≥1 秒（同一张卡同一界面只记一次）——采纳率的分母
//   mine     = 会后行动卡「我来做」
//   dispatch = 会后行动卡派出去（飞书任务 / 日程发出）
//   done     = 会后行动卡标完成
//   expand   = 展开看：会议页实际展开详情或来源；原生卡已全文显示，其 click/旧 expand 不计（同一张卡同一界面只记一次）；只留痕，不进 M1、不调权
// 会中卡 cardId 是界面上的候选 id（native:… / fact:…），另带 key = nativeInsights 里那条的 key，方便和 history 对上。
// 账本 state/card-signals.jsonl 只追加；app/goal-metrics.js 的 M1 按场读它：adopt / copy 算用上，dismiss 算负反馈。
const fs = require('fs'), path = require('path');

const ACTIONS = ['adopt', 'copy', 'dismiss', 'shown', 'mine', 'dispatch', 'done', 'expand'];
const FILE = dataDir => path.join(dataDir, 'state', 'card-signals.jsonl');
const clip = (s, n) => String(s == null ? '' : s).slice(0, n);

// 请求体 → 一行账本；不合格返回 null
function record(j, at = new Date()) {
  const action = String(j && j.action || '');
  const sessionId = clip(j && j.sessionId, 80), cardId = clip(j && j.cardId, 120);
  if (!ACTIONS.includes(action) || !sessionId || !cardId) return null;
  const rec = { at: at.toISOString(), sessionId, cardId, action, source: clip(j.source, 20), kind: clip(j.kind, 20), text: clip(j.text, 120) };
  if (j.key) rec.key = clip(j.key, 40);
  return rec;
}

function readAll(dataDir) {
  let t = ''; try { t = fs.readFileSync(FILE(dataDir), 'utf8'); } catch (e) { return []; }
  const out = [];
  for (const l of t.split('\n')) { if (!l) continue; try { const r = JSON.parse(l); if (r && ACTIONS.includes(r.action)) out.push(r); } catch (e) {} }
  return out;
}

// 服务端自己记一条（会后行动卡状态变了时 app/actions.js 调）；写不进去不影响主流程
function append(dataDir, j, at) {
  const rec = record(j, at); if (!rec || !dataDir) return null;
  try { fs.mkdirSync(path.dirname(FILE(dataDir)), { recursive: true }); fs.appendFileSync(FILE(dataDir), JSON.stringify(rec) + '\n'); return rec; } catch (e) { return null; }
}

function bySession(dataDir) {
  const m = new Map();
  for (const r of readAll(dataDir)) { const k = String(r.sessionId || ''); if (!m.has(k)) m.set(k, []); m.get(k).push(r); }
  return m;
}

module.exports = { ACTIONS, FILE, record, append, readAll, bySession };
