'use strict';
// MODEL-PROVIDERS：每家 AI 在citeside里真实能怎么接。只写本应用实际走得通的路；
// 「会员订阅」和「API 额度」分开写，做不到一键授权的不写一键。
// verified=true 只表示本机真实调用过（usage.jsonl 有成功记录），其余按各家公开文档，未逐家实测。
const MATRIX = [
  { id: 'codex', name: 'OpenAI Codex（ChatGPT 会员）', how: 'cli-login', inApp: true, verified: true,
    connect: '本机装 Codex 命令行后运行 codex login，用 ChatGPT 账号登录；Citeside调用本机命令行，不经手密码或令牌。',
    billing: '用 ChatGPT 会员额度，不另收 API 费用；会员额度用完即失败，不自动改走 API。' },
  { id: 'claude', name: 'Claude Code（Claude 会员）', how: 'cli-login', inApp: true, verified: true,
    connect: '本机装 Claude Code 后运行 claude 并登录 Claude 账号；Citeside调用本机命令行。',
    billing: '用 Claude 会员额度；与 Anthropic API 额度是两套账。' },
  { id: 'deepseek', name: 'DeepSeek', how: 'api-key', inApp: true, verified: true, baseUrl: 'https://api.deepseek.com',
    connect: '在 DeepSeek 开放平台建 API Key，填进设置页「自己的模型」。',
    billing: '按 API 用量计费，与网页版会员无关。' },
  { id: 'openai-api', name: 'OpenAI API', how: 'api-key', inApp: true, verified: false, baseUrl: 'https://api.openai.com/v1',
    connect: '在 OpenAI Platform 建 API Key，按 OpenAI 兼容接口填入。',
    billing: 'API 额度单独充值；ChatGPT 会员不能用于 API。' },
  { id: 'anthropic-api', name: 'Anthropic API', how: 'api-key', inApp: true, verified: false, baseUrl: 'https://api.anthropic.com/v1',
    connect: '在 Anthropic Console 建 API Key，走其 OpenAI 兼容接口。',
    billing: 'API 额度单独计费；Claude 会员不能用于 API。' },
  { id: 'gemini-api', name: 'Google Gemini API', how: 'api-key', inApp: true, verified: false, baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
    connect: '在 Google AI Studio 建 API Key，走其 OpenAI 兼容接口。', billing: '按 API 用量计费，与 Gemini 会员无关。' },
  { id: 'qwen', name: '通义千问（阿里云百炼）', how: 'api-key', inApp: true, verified: false, baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    connect: '在百炼控制台建 API Key，走兼容模式接口。', billing: '按 API 用量计费。' },
  { id: 'kimi', name: 'Kimi（Moonshot）', how: 'api-key', inApp: true, verified: false, baseUrl: 'https://api.moonshot.cn/v1',
    connect: '在 Moonshot 开放平台建 API Key。', billing: '按 API 用量计费，与 Kimi 会员无关。' },
  { id: 'glm', name: '智谱 GLM', how: 'api-key', inApp: true, verified: false, baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    connect: '在智谱开放平台建 API Key。', billing: '按 API 用量计费。' },
  { id: 'doubao', name: '豆包（火山方舟）', how: 'api-key', inApp: true, verified: false, baseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    connect: '在火山方舟建 API Key 和推理接入点，模型名填接入点 ID。', billing: '按 API 用量计费。' },
  { id: 'custom-cli', name: '其他本机命令行', how: 'cli-custom', inApp: true, verified: false,
    connect: '在 LLM_CHAIN 里写 type:"cli", kind:"custom"，给出可执行文件和参数。', billing: '取决于该命令行自己的账号。' },
  { id: 'oauth-third-party', name: '用第三方账号一键授权（OAuth）', how: 'none', inApp: false, verified: false,
    connect: '目前没有一家公开允许第三方应用用会员账号 OAuth 调模型；Citeside不提供这条路，也不假装提供。',
    billing: '—' },
];

const keyed = p => p.type === 'openai' ? (p.keyFrom ? `环境项 ${p.keyFrom}` : '配置内密钥') : '';
// 逐条检查用户配置的供应商：认不出来的照实列出，不改名、不映射到别家。不输出密钥本身。
function inspect(env = {}) {
  const raw = Array.isArray(env.LLM_CHAIN) && env.LLM_CHAIN.length ? env.LLM_CHAIN : null;
  if (!raw) return { source: 'legacy', entries: [] };
  const entries = raw.map((p, i) => {
    const label = String(p && (p.name || p.kind || p.type) || `第 ${i + 1} 项`).slice(0, 60);
    if (!p || typeof p !== 'object') return { index: i, label, ok: false, reason: '不是有效的配置项' };
    if (p.type === 'cli') {
      if (p.kind === 'custom') return p.bin ? { index: i, label, ok: true, how: 'cli-custom' } : { index: i, label, ok: false, reason: '自定义命令行缺少 bin（可执行文件路径）' };
      if (['claude', 'codex'].includes(p.kind)) return { index: i, label, ok: true, how: 'cli-login' };
      return { index: i, label, ok: false, reason: `不认识的命令行「${String(p.kind || '').slice(0, 40)}」，未改用其他供应商` };
    }
    if (p.type === 'openai') {
      if (!p.baseUrl) return { index: i, label, ok: false, reason: '缺少接口地址 baseUrl' };
      if (!(p.keyFrom ? env[p.keyFrom] : p.key)) return { index: i, label, ok: false, reason: `缺少密钥（${keyed(p)}为空）` };
      let host = ''; try { host = new URL(p.baseUrl).hostname; } catch { return { index: i, label, ok: false, reason: '接口地址不是有效网址' }; }
      return { index: i, label, ok: true, how: 'api-key', recipient: host };
    }
    return { index: i, label, ok: false, reason: `不认识的供应商类型「${String(p.type || '').slice(0, 40)}」，已跳过，未映射到其他供应商` };
  });
  return { source: 'LLM_CHAIN', entries };
}

// 默认路线失败、要换备用路线时，先按实际顺序说出本场内容接下来会发给谁（备用链里可能还有本机 Codex 命令行）。
function recipientNotice(labels, lang = 'zh') {
  const list = [...new Set((labels || []).filter(Boolean))];
  if (!list.length) return lang === 'en' ? 'Codex unavailable; no other AI is configured' : 'Codex 暂不可用，也没有配置其他 AI';
  return lang === 'en'
    ? `Codex app unavailable; trying the backup route. This request and meeting context go to ${list.join(', then ')}`
    : `Codex 主助手暂不可用，改走备用路线——本次提问和本场上下文会依次发给：${list.join(' → ')}`;
}

module.exports = { MATRIX, inspect, recipientNotice };
