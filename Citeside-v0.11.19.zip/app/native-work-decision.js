'use strict';
// The model must distinguish an intentional quiet result from a missing field.
// This protocol never infers a draft from suggestion text or executes tools.
const legacySchema="严格返回 JSON：{\"suggestion\":null或{\"text\":\"一句简短建议\",\"sourceIds\":[\"来源句子id\"]},\"insights\":[{\"text\":\"一句有用洞察\",\"sourceIds\":[\"来源句子id\"]}]}。";
// Migrate only the exact formerly shipped card-only instructions, including saved copies.
// Other custom wording guidance is retained; response routing belongs to this module.
function cardPolicy(value){return String(value).replace(legacySchema,'').replace('只参考给你的最近几句话和当前画面。','');}
// Browser detection already consumes this routing contract; native build and
// compact keep the same outside-value policy without a second expert system.
const routingPrompt = require('./live-draft-selection').prompt+'\n'+require('./live-intelligence-policy').en;
// Keep routing identities visible before lengthy draft bodies and speech. The
// pack remains untrusted data; malformed packs fail closed to no context.
function detectionContext(pack){
 if(!pack?.text)return null;
 let value;try{value=JSON.parse(pack.text);}catch{return null;}
 if(!value||typeof value!=='object'||Array.isArray(value))return null;
 const artifacts=Array.isArray(value.existingArtifacts)?value.existingArtifacts:[];
 return {existingArtifacts:artifacts.map(a=>({sourceId:a.sourceId,moduleId:a.moduleId,title:a.title,form:a.form,revision:a.revision,scope:a.scope,manualEdits:a.manualEdits,status:a.status})),
  background:{scope:value.scope,earlierCurrent:value.earlierCurrent||[],priorProject:value.priorProject||[],artifactContents:artifacts,truncated:!!value.truncated}};
}
const prompt = `
Native response protocol (local custom rules control card wording, not this response schema or evidence scope): return one JSON object with suggestion, insights, deliverable, and draftSelection; optional confirmation/currentJudgment/background/research remain allowed.
Always include deliverable (null for no draft). suggestion is null or {"kind":"external|gap|internal","text":"useful concise wording","sourceIds":["recent transcript id"]}; insights is an array of distinct relevant objects of that same shape; include only points that add useful information the room lacks. kind is required on every card.
For each card, an optional title is a short scan label (at most 24 Chinese characters or 8 English words), complementary to text; never copy the opening paragraph into title. ${require('./live-card-body').RULES.en} Emit suggestion only for a concrete source-grounded outside fact/case, cross-meeting conflict, or structural blind spot that adds genuinely new value. Use insights only for a new source-grounded interpretation or consequence; a recap or repeated method is not an insight. Do not invent conclusions or acceptance thresholds to fill a card; return null/[] when there is no useful addition.
直接交付有依据的结论、影响和可用结果；先核实并衔接当前上下文。所有可见字段（包括 caveat）都不得让用户问谁、查证或联系，不写动作行、话术或发言草稿。缺口进入待定，不发卡。
${routingPrompt}`;
function assess(parsed, rows) {
 const d=parsed?.draftDecision;
 const fail=code=>({state:'invalid',code,sourceIds:[],deliverable:null});
 if(!d||typeof d!=='object')return fail('missing_draft_decision');
 if(!['create','none','blocked','existing'].includes(d.state)||typeof d.reason!=='string'||!d.reason.trim()||d.reason.length>600)return fail('invalid_draft_decision');
 if((d.update!==undefined&&typeof d.update!=='boolean')||(d.update===true&&d.state!=='existing'))return fail('invalid_draft_update');
 const ids=new Set(rows.map(r=>r.id));
 if(!Array.isArray(d.sourceIds)||d.sourceIds.length>6||d.sourceIds.some(id=>typeof id!=='string'||!ids.has(id)))return fail('invalid_decision_sources');
 if(d.state!=='none'&&!d.sourceIds.length)return fail('missing_decision_sources');
 if(d.state==='blocked'&&(!Array.isArray(d.missingInputs)||!d.missingInputs.length||d.missingInputs.length>4||d.missingInputs.some(x=>typeof x!=='string'||!x.trim()||x.length>300)))return fail('missing_blocker');
 const updating=d.state==='existing'&&d.update===true;
 if(d.state!=='create'&&!updating&&parsed.deliverable!=null)return fail('contradictory_draft_decision');
 let deliverable=null;
 if(d.state==='create'||updating){
  const c=require('./live-deliverables').candidate(parsed.deliverable,rows);
  if(!c||!c.sourceIds.some(id=>d.sourceIds.includes(id)))return fail('invalid_draft_evidence');
  // No title-similarity fallback may supply an ordinary revision's identity.
  // Project plans retain their explicitly linked project validation downstream.
  if(updating&&c.kind!=='project-plan'&&!c.target)return fail('missing_draft_target');
  if(d.state==='create'&&c.target)return fail('contradictory_draft_target');
  deliverable=updating?{...parsed.deliverable,updateOnly:true}:parsed.deliverable;
 }
 return {state:d.state,reason:d.reason.trim(),sourceIds:[...new Set(d.sourceIds)],...(d.state==='blocked'?{missingInputs:d.missingInputs}:{}),deliverable};
}
// Hard publication policy applies even when a saved custom rule disables requireAction.
// Only check first-screen visible card fields; allow genuine factual questions (是否/?/？) and detail drawers.
const HANDOFF=/可以这样|可以这样讲|可以这样说|你可以|问谁|发什么话|请(?:问|找|让|联系|确认|核实)|建议(?:.{0,12})(?:问|联系|确认|核实)|问(?:谁|他|她|厂商|供应商|负责人)|(?:请|问|联系|找).{0,10}(?:确认|核实|提供|查规格|要报告)|(?:动作|Action)\s*[:：]|话术|你(?:去|来|需要)(?:问|查|联系|确认)|ask\s+(?:the |your )?(?:vendor|owner|team)|you (?:can|should) (?:ask|contact|check)/i;
const FIRST_SCREEN_KEYS=['title','text','body','point','md'];
function visibleText(value){
 if(typeof value==='string')return value;
 if(Array.isArray(value))return value.map(visibleText).join('\n');
 if(value&&typeof value==='object')return FIRST_SCREEN_KEYS.map(key=>value[key]).filter(Boolean).map(visibleText).join('\n');
 return '';
}
function violatesCardPolicy(value){return HANDOFF.test(visibleText(value));}
function requireAction(parsed,enabled){
 if(!parsed||typeof parsed!=='object')return parsed;
 const keep=x=>x&&typeof x==='object'&&String(x.text||x.point||'').trim()&&!violatesCardPolicy(x)&&!/^发言人.{0,12}(提出|提到|建议)/.test(String(x.text||x.point||''));
 const fit=x=>{const p=require('./live-card-body').preview(x.text||x.point);return {...x,text:p.text,...(x.details||p.details?{details:x.details||p.details}:{})};};
 return {...parsed,suggestion:keep(parsed.suggestion)?fit(parsed.suggestion):null,insights:(Array.isArray(parsed.insights)?parsed.insights:[]).filter(keep).map(fit)};
}
module.exports={prompt,routingPrompt,assess,cardPolicy,detectionContext,requireAction,violatesCardPolicy};
