'use strict';
const link=require('./tools/oauth-link');
const bridge=require('./notion-mcp-bridge');
const home=ctx=>ctx.notionHome||ctx.env?.HOME||require('os').homedir();
const user=ctx=>String(ctx.env?.NOTION_TOKEN||'').trim();
function configured(ctx={}) {
 if(user(ctx))return true;
 if(ctx.dataDir&&link.hasBinding('notion',ctx.dataDir))return true;
 if(ctx.env?.NOTION_DISCONNECTED==='1')return false;
 return !!bridge.reusedBearer(home(ctx)).token;
}
async function resolve(ctx={}) {
 if(user(ctx))return {token:user(ctx),source:'user'};
 let oauth=null;try{if(ctx.dataDir)oauth=await link.accessToken('notion',ctx);}catch{}
 if(oauth?.token)return {token:oauth.token,source:'oauth'};
 if(ctx.env?.NOTION_DISCONNECTED==='1')return {token:'',source:'none'};
 const reused=bridge.reusedBearer(home(ctx));
 return reused.token?reused:{token:'',source:'none'};
}
async function status(ctx={}) {
 const {source}=await resolve(ctx);
 return {source,authorized:source!=='none',message:source.startsWith('reused:')?'已沿用 '+(source==='reused:codex'?'Codex':'Claude')+' 的授权':''};
}
module.exports={resolve,status,configured};
