#!/usr/bin/env python3
"""为已有历史场次补生成主题标题，写入 state/meeting-titles.json。只读会议数据，不改原件。
用法：python3 backfill-titles.py [--dry-run] [--limit N]
"""
import argparse, importlib.util, json, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('mp', ROOT / 'meeting-pipeline.py')
# 独立版：数据目录来自 THT_DATA_DIR（config.js 同款默认值）
import os; os.environ.setdefault('THT_DATA_DIR', str(pathlib.Path.home()/'Library/Application Support/Citeside'))
mp = importlib.util.module_from_spec(spec); spec.loader.exec_module(mp)

def candidates():
    seen = {}
    for job_path in sorted((mp.STATE).glob('*.job.json')):
        job = mp.read(job_path, {}) or {}
        sid = str(job.get('sessionId') or '')
        if not sid: continue
        enhanced = mp.read(job_path.with_suffix('.enhanced.json')) or mp.read(pathlib.Path(job.get('input', '')), {}) or {}
        if enhanced: seen[sid] = enhanced
    pending = mp.ROOT / 'pending'
    if pending.is_dir():
        for f in sorted(pending.iterdir()):
            if not (f.name.startswith(('sess-', 'offline-')) and '.json' in f.name): continue
            try: s = json.loads(f.read_text())
            except Exception: continue
            sid = str(s.get('id') or '')
            if sid and sid not in seen: seen[sid] = s
    return seen

def title_one(payload):
    """Only the explicitly requested meeting; no archive/summary/history scan."""
    session = payload.get('session') if isinstance(payload, dict) else None
    if not isinstance(session, dict) or not mp.re.fullmatch(r'[A-Za-z0-9_.-]{1,80}', str(session.get('id') or '')):
        return {'ok': False, 'errorCode': 'invalid_request'}
    source = payload.get('source') if isinstance(payload.get('source'), dict) else {}
    if source.get('titleEdited') or source.get('titleManual') or source.get('titleMethod') == 'manual':
        return {'ok': True, 'skipped': True, 'title': str(source.get('title') or source.get('topicTitle') or ''), 'titleMethod': 'manual'}
    sid = str(session['id'])
    row = (mp.read(mp.TITLES, {}) or {}).get(sid) or {}
    if not mp.title_needs_refresh(session, row):
        title = row.get('topicTitle') or (session.get('title') if session.get('titleEdited') or session.get('titleManual') else '') or session.get('topicTitle') or mp.cal_title(session)
        return {'ok': bool(title), 'skipped': True, 'title': title or '', 'titleMethod': row.get('titleMethod') or session.get('titleMethod') or '', **({} if title else {'errorCode': 'no_title_content'})}
    calendar = mp.cal_title(session)
    if calendar:
        title, method = calendar, 'calendar'
    else:
        with mp.ModelTask(session):
            title = mp.title_for(session, session.get('summary', ''))
        method = 'ai-short-v1'
    saved = mp.save_title(sid, title, method=method, only_if_needed=session)
    return {'ok': True, 'title': saved['topicTitle'], 'titleMethod': saved.get('titleMethod') or method}

def single_stdin():
    import signal
    def stopped(*_): raise SystemExit(1)
    signal.signal(signal.SIGTERM, stopped)
    try:
        result = title_one(json.load(sys.stdin))
    except Exception as error:
        message = str(error)
        safe_codes = ['account_login_required', 'entitlement_required', 'quota_exhausted', 'call_budget_exhausted', 'output_budget_exhausted', 'input_too_large', 'no_provider', 'routing_deadline']
        code = next((code for code in safe_codes if code in message), 'title_invalid' if '标题须' in message else 'title_generation_failed')
        result = {'ok': False, 'errorCode': code}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result.get('ok') else 1

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--dry-run', action='store_true'); ap.add_argument('--limit', type=int, default=0)
    a = ap.parse_args()
    titles = mp.read(mp.TITLES, {}) or {}
    todo = [(sid, s) for sid, s in candidates().items() if mp.title_needs_refresh(s, titles.get(sid) or {})]
    print(f'已有标题 {len(titles)}，待生成 {len(todo)}')
    if a.dry_run:
        for sid, s in todo: print(' ', sid, str(s.get('start'))[:16], (s.get('title') or '')[:24])
        return
    ok = fail = 0
    for sid, s in (todo[:a.limit] if a.limit else todo):
        try:
            t = mp.title_for(s, s.get('summary', '')); method = 'calendar' if mp.cal_title(s) else 'ai-short-v1'; mp.save_title(sid, t, method=method); ok += 1; print('  ✓', sid, t)
        except Exception as e:
            fail += 1; print('  ✗', sid, e, file=sys.stderr)
    print(f'完成：成功 {ok}，失败 {fail}')

if __name__ == '__main__':
    if sys.argv[1:] == ['--session-stdin']: raise SystemExit(single_stdin())
    main()
