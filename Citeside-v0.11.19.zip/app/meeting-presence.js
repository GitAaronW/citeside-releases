'use strict';
// Presentation only. No recording, navigation or session finalization is controlled here.
function create({now=Date.now,ttl=6000}={}){
 let current=null,dismissedSession='';const main=new Map();
 return {
  // Only a foreground main owns presentation; a visible background main leaves the mini available.
  touch(clientId,foreground){
   if(typeof clientId!=='string'||!/^[a-zA-Z0-9-]{8,100}$/.test(clientId)||typeof foreground!=='boolean')throw Error('native_presence_invalid');
   const prev=main.get(clientId),t=now();
   // since = when this window came to the front; an explicit 收成小窗 only beats windows already in front before it.
   main.set(clientId,{foreground,at:t,since:foreground&&prev?.foreground?prev.since:t});for(const [k,v] of main)if(now()-v.at>=ttl)main.delete(k);
  },
  mainVisible(after=-Infinity){for(const v of main.values())if(v.foreground&&now()-v.at<ttl&&v.since>after)return true;return false;},
  clock(){return now();},
  update(clientId,sessionId,foreground){
   if(typeof clientId!=='string'||!/^[a-zA-Z0-9-]{8,100}$/.test(clientId)||typeof sessionId!=='string'||!sessionId||sessionId.length>200||typeof foreground!=='boolean')throw Error('native_presence_invalid');
   // A background/history tab cannot displace the focused meeting page.
   if(current&&current.sessionId===sessionId&&current.clientId!==clientId&&now()-current.at<ttl&&(!foreground||current.foreground))return false;
   current={clientId,sessionId,foreground,at:now()};return true;
  },
  known(){return current!==null;},
  // A closed or crashed page stops renewing its lease. It must not leave the capsule hidden.
  visible(sessionId){return current&&current.sessionId===sessionId?(now()-current.at<ttl?current.foreground:false):null;},
  dismiss(sessionId){dismissedSession=sessionId;},
  reopen(sessionId){if(dismissedSession===sessionId)dismissedSession='';},
  dismissed(sessionId){return !!sessionId&&dismissedSession===sessionId;}
 };
}
module.exports={create};
