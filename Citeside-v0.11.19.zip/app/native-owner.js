'use strict';
// An explicit Quit capability belongs to one native main window. A lost
// heartbeat, a page navigation, or an unrelated browser never invokes it.
function create({isAlive = pid => { try { process.kill(pid, 0); return true; } catch (e) { return e.code !== 'ESRCH'; } }, active = () => false, now = () => Date.now()} = {}) {
  const owners = new Map();
  const mainRestoreEpoch = require('node:crypto').randomUUID();
  const valid = token => typeof token === 'string' && /^[a-f0-9]{64}$/.test(token);
  function get(token) {
    if (!valid(token) || !owners.has(token)) throw Error('native_owner_unknown');
    const owner = owners.get(token);
    if (owner.mainRestorePending && now() >= owner.mainRestoreDeadline) {
      owner.mainRestorePending = false; owner.mainRestoreAckPid = 0; owner.mainRestoreRequestId = ''; owner.mainForeground = false;
    }
    return owner;
  }
  return {
    register(token, mainPid = 0) {
      if (!valid(token)) throw Error('native_owner_invalid');
      if (mainPid && (!Number.isSafeInteger(mainPid) || mainPid < 1)) throw Error('native_main_pid_invalid');
      if (!owners.has(token)) {
        // Reclaim only an explicitly identified, exited main window with no
        // live helper and no pending/current meeting. Never infer Quit from age.
        for (const [key, value] of owners) {
          if (value.mainPid && !isAlive(value.mainPid) && (!value.helperPid || !isAlive(value.helperPid)) && !active(key)) owners.delete(key);
        }
        if (owners.size >= 8) throw Error('native_owner_capacity');
        owners.set(token, { mainPid, helperPid: 0, quitRequested: false, readyToQuit: false, error: '', openSerial:0, openSessionId:'', openPanel:'', mainForeground:null, dismissedSessionId:'', mainRestoreSerial:0, mainRestorePending:false, mainRestoreAckPid:0, mainRestoreRequestId:'', mainRestoreDeadline:0, mainRestoreEpoch });
      }
      const owner=owners.get(token);
      if(mainPid){
        if(owner.mainPid&&owner.mainPid!==mainPid&&isAlive(owner.mainPid))throw Error('native_main_owner_conflict');
        owner.mainPid=mainPid;
      }
      return this.status(token);
    },
    has(token) { return valid(token) && owners.has(token); },
    helperReady(token, pid) {
      const owner = get(token);
      if (!Number.isSafeInteger(pid) || pid < 1) throw Error('native_helper_pid_invalid');
      if (owner.helperPid && owner.helperPid !== pid && (isAlive(owner.helperPid) || active(token))) throw Error('native_helper_owner_conflict');
      if (owner.helperPid !== pid && owner.mainRestorePending) owner.mainRestoreAckPid = 0;
      owner.helperPid = pid;
      return this.status(token);
    },
    requestQuit(token) { const owner = get(token); owner.quitRequested = true; owner.error = ''; return this.status(token); },
    failed(token, error) {
      const owner = get(token); owner.quitRequested = false; owner.readyToQuit = false;
      owner.error = String(error || 'native_save_unconfirmed').slice(0, 200);
    },
    saved(token) { const owner = get(token); if (!owner.quitRequested) throw Error('native_quit_not_requested'); owner.readyToQuit = true; },
    openMain(token, sessionId, panel='') { const owner=get(token);owner.openSerial++;owner.openSessionId=String(sessionId||'').slice(0,200);owner.openPanel=['settings','update','lite'].includes(panel)?panel:''; },
    mainAlive(token) { const owner=get(token); return !!owner.mainPid && isAlive(owner.mainPid); },
    visibility(token, foreground) {
      if (typeof foreground !== 'boolean') throw Error('native_visibility_invalid');
      get(token).mainForeground=foreground;return this.status(token);
    },
    beginMainRestore(token, requestId) { const o=get(token);if(typeof requestId!=='string'||!requestId||requestId.length>100)throw Error('native_main_restore_request_invalid');if(o.mainRestorePending) throw Error('native_main_restore_pending');o.mainRestoreSerial++;o.mainRestoreRequestId=requestId;o.mainRestorePending=true;o.mainRestoreDeadline=now()+8000;o.mainRestoreAckPid=0;o.helperViewAt=0;return this.mainRestoreStatus(token,o.mainRestoreSerial); },
    // The running helper confirms a hide with its own POST. That POST is skipped
    // when a stop command returns first, or when the panel's visibility flag lags
    // orderOut. A heartbeat view of hidden is the same helper saying the mini is
    // already in the concealed mode. A later visible view withdraws that inference.
    noteHelperView(token, view) {
      const o=get(token);
      if(!['hidden','expanded','compact','capsule','transcript'].includes(view)) return false;
      o.helperView=view;o.helperViewAt=now();
      if(!o.mainRestorePending||!o.helperPid||!isAlive(o.helperPid)) return false;
      if(view==='hidden'){const changed=o.mainRestoreAckPid!==o.helperPid;o.mainRestoreAckPid=o.helperPid;return changed;}
      if(o.mainRestoreAckPid){o.mainRestoreAckPid=0;return false;}
      return false;
    },
    mainRestoreStatus(token, serial) { const o=get(token);if(!o.mainRestorePending||serial!==o.mainRestoreSerial)throw Error('native_main_restore_stale');const pid=o.helperPid;return {serial,helperPid:pid,ready:!pid||!isAlive(pid)||o.mainRestoreAckPid===pid}; },
    ackMainRestore(token, serial, pid) { const o=get(token);if(!o.mainRestorePending||serial!==o.mainRestoreSerial||!pid||pid!==o.helperPid)throw Error('native_main_restore_stale');o.mainRestoreAckPid=pid;return this.mainRestoreStatus(token,serial); },
    finishMainRestore(token, serial) { const o=get(token),s=this.mainRestoreStatus(token,serial);if(!s.ready)throw Error('native_main_restore_unconfirmed');o.mainForeground=true;o.mainRestorePending=false;return this.status(token); },
    cancelMainRestore(token, requestId) { const o=get(token);if(requestId&&requestId===o.mainRestoreRequestId){o.mainRestorePending=false;o.mainRestoreAckPid=0;o.mainForeground=false;o.mainRestoreRequestId='';}return this.status(token); },
    dismissPanel(token, sessionId) { get(token).dismissedSessionId=String(sessionId||'').slice(0,200); },
    reopenPanel(token, sessionId) { const owner=get(token);if(owner.dismissedSessionId===sessionId)owner.dismissedSessionId=''; },
    panelPolicy(token, sessionId, activeMeeting) {
      const owner=get(token),id=String(sessionId||'');
      return {managed:typeof owner.mainForeground==='boolean',sessionId:id,
        show:!!activeMeeting&&!!id&&owner.mainForeground===false&&!owner.quitRequested&&owner.dismissedSessionId!==id};
    },
    status(token) { const owner = get(token); return { ...owner }; },
    release(token) {
      const owner = get(token);
      if (active(token)) throw Error('native_meeting_not_saved');
      if (owner.helperPid && !owner.readyToQuit) throw Error('native_helper_not_saved');
      owners.delete(token);
    }
  };
}
module.exports = { create };
