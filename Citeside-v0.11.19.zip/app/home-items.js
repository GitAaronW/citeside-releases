'use strict';
// 首页事项三页签（UI-REFERENCE，10-23 原型）：等你的 / 在跟进 / 已处理。
// 只读：把各场会后处理台（app/actions.js 的 <key>.actions.json）的卡汇成一张表，不写文件、不外发。
// 动作（发出 / 我来做 / 打叉）仍回那场会的处理台做，首页只负责「哪里有事、事到哪一步了」。
//   等你的 = 还没处理的卡（open）
//   在跟进 = 我来做了、工作台里还没完成（claimed）；派给别人的飞书任务（delegate 已发）
//   已处理 = 已发的会议邀请、打叉的、我来做且工作台里已完成的
const fs = require('fs'), path = require('path');

const FINISHED = new Set(['done', 'verified', 'cancelled', 'dismissed']);
const personal = require('./personal-actions');
const DAY = 86400000;

function readJSON(file) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return null; } }
const clip = (s, n) => String(s == null ? '' : s).slice(0, n);
// 首页是给 Aaron 看的待办清单：会上原话里的「我会 / 我来…」是发言人的第一人称，去掉主语只留动作。
const FIRST_PERSON = /^\s*(?:那|好的?|嗯|OK|ok)?[，, ]*(?:我们|我)(?:这边|这里)?(?:会|来|去|要|将|得|再|先|就|可以|负责)+(?:去|来|把)?\s*/;
const actionText = s => { const t = String(s == null ? '' : s).trim(); const r = t.replace(FIRST_PERSON, ''); return r.length >= 2 ? r : t; };
// 公众版没有身份识别：S1 / spk_2 / 说话人 3 这类声音分组号不是人，负责人显示「未指定」。
const owner = o => { const v = String(o == null ? '' : o).trim(); return !v || /^(?:S|spk_?|speaker\s*|说话人\s*)\d+$/i.test(v) ? '' : v; };

function waitNote(c) {
  if (c.kind === 'meeting') return '要发会议邀请';
  if (c.kind === 'delegate') return '派给 ' + (owner(c.owner) || '未指定');
  if (c.kind === 'research') return '预研究';
  return '你自己做';
}

function place(c, hubById) {
  if (c.state === 'open') return { tab: 'wait', note: waitNote(c), at: '' };
  if (c.state === 'dismissed') return { tab: 'done', note: '不用了', at: c.dismissedAt };
  if (c.state === 'sent') {
    if (c.kind === 'delegate') return { tab: 'track', note: '已派给 ' + (owner(c.owner) || '未指定'), at: c.sentAt };
    return { tab: 'done', note: '已发会议邀请', at: c.sentAt };
  }
  if (c.state === 'claimed') {
    const task = c.hubTaskId && hubById.get(c.hubTaskId);
    if (task && FINISHED.has(task.status)) return { tab: 'done', note: '已完成', at: task.doneAt || task.updatedAt || c.claimedAt };
    return { tab: 'track', note: c.claimFailed ? '我来做 · 没进「我的待办」' : '我来做', at: c.claimedAt };
  }
  return null;
}

// days：只看最近这么多天生成的处理台，免得几个月前没处理的卡一直堆在「等你的」里。
function list({ dir, titles = {}, hubTasks = [], days = 14, limit = 20, at = Date.now(), dataDir = '' }) {
  let files = [];
  try { files = fs.readdirSync(dir).filter(f => f.endsWith('.actions.json')); } catch (e) {}
  const hubById = new Map((hubTasks || []).map(t => [t.id, t]));
  const items = [];
  for (const f of files) {
    let data = readJSON(path.join(dir, f));
    if (!data || !Array.isArray(data.cards)) continue;
    if(dataDir) {
      const names=require('./context-pack').actionIdentity(dataDir,{selfNames:data.selfNames||[]});
      data = {...data,cards:data.cards.filter(c=>c.state==='claimed'||personal.confirmed(c,names))};
    }
    const generated = Date.parse(data.generatedAt || '') || 0;
    if (generated && at - generated > days * DAY) continue;
    const sid = String(data.sessionId || '');
    const meeting = clip(((titles[sid] || {}).topicTitle) || '', 80);
    for (const c of data.cards) {
      const p = place(c, hubById); if (!p) continue;
      items.push({
        id: c.id, sessionId: sid, meeting, text: clip(actionText(c.text), 300), kind: c.kind || 'self',
        tab: p.tab, note: p.note, at: p.at || data.generatedAt || '', url: (c.sentRef && c.sentRef.url) || '',
      });
    }
  }
  // Personal drafts exist at the end hook, before the slower legacy desk generator.
  if(dataDir) {
    let reports=[];try{reports=fs.readdirSync(path.join(dataDir,'live-reports')).filter(f=>f.endsWith('.json'));}catch(_){}
    for(const file of reports) {
      const report=readJSON(path.join(dataDir,'live-reports',file));
      const sid=file.slice(0,-5), generated=Date.parse(report?.myActions?.[0]?.draft?.versions?.at(-1)?.createdAt||'')||0;
      if(generated && at-generated>days*DAY)continue;
      const names=require('./context-pack').actionIdentity(dataDir,{selfNames:report?.selfNames||[]});
      for(const a of (report?.myActions||[]).filter(a=>personal.confirmed(a,names))) {
        const id='act:'+sid+':'+a.id;
        if(items.some(i=>i.sessionId===sid&&i.text===a.do))continue;
        items.push({id,sessionId:sid,meeting:clip(titles[sid]?.topicTitle||'',80),text:a.do,kind:'self',tab:a.draft?.status==='preparing'?'track':'wait',note:a.draft?.label||'你自己做',at:generated?new Date(generated).toISOString():'',url:''});
      }
    }
  }
  items.sort((a, b) => (Date.parse(b.at) || 0) - (Date.parse(a.at) || 0));
  const count = { wait: 0, track: 0, done: 0 };
  return items.filter(i => ++count[i.tab] <= limit);
}

module.exports = { list, place, actionText, owner };
