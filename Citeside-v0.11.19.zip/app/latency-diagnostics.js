'use strict';
// Separate from Session serialization, journal, audio buffers and provider payloads.
const create=require('../web/latency-diagnostics');
function createRelay(now=()=>Number(process.hrtime.bigint())/1e6){
 const ring=create(now,256,'hrtime'),states=new WeakMap();let seq=0;
 function receive(session,meta){
  // Startup probe only: later packets cannot be matched to a specific ASR
  // hypothesis. Per-result speechEndToArriveMs is measured separately below.
  const valid=meta&&Number.isSafeInteger(meta.seq)&&meta.seq>0&&typeof meta.key==='string'&&/^[a-zA-Z0-9:._-]{1,140}$/.test(meta.key);
  const previous=states.get(session);
  if(previous){
    const at=now();
    // Independent ongoing upload-queue sample; never relabel it as an ASR match.
    if(valid&&Number.isFinite(meta.captureToSendMs)&&meta.captureToSendMs>=0&&at-previous.queueAt>=1000){
      ring.mark(session.id,meta.key,'packet_queue',{seq:meta.seq,captureToSendMs:meta.captureToSendMs});previous.queueAt=at;
    }
    return;
  }
  const key=valid?meta.key:'relay:'+ ++seq;
  const trace={key,seq:valid?meta.seq:seq,probe:'first_audio'};
  if(valid&&Number.isFinite(meta.captureToSendMs)&&meta.captureToSendMs>=0)trace.captureToSendMs=meta.captureToSendMs;
  if(valid&&['performance','uptime'].includes(meta.clock)&&Number.isFinite(meta.captureMonoMs)&&meta.captureMonoMs>=0&&Number.isFinite(meta.sendMonoMs)&&meta.sendMonoMs>=meta.captureMonoMs){ring.mark(session.id,key,'capture',{seq:trace.seq,clock:meta.clock,monoMs:meta.captureMonoMs});ring.mark(session.id,key,'packet_send',{seq:trace.seq,clock:meta.clock,monoMs:meta.sendMonoMs,captureToSendMs:meta.sendMonoMs-meta.captureMonoMs});}
  const row=ring.mark(session.id,key,'relay_receive',trace);states.set(session,{trace,receiveAt:row.monoMs,queueAt:row.monoMs});
 }
 function sent(session,stream){const s=states.get(session);if(!s||s.sentAt!==undefined)return;const r=ring.mark(session.id,s.trace.key,'upstream_send',{...s.trace,receiveToSendMs:now()-s.receiveAt});s.sentAt=r.monoMs;s.stream=stream;}
 function partial(session,stream){const s=states.get(session);if(!s||s.sentAt===undefined||s.done||s.stream!==stream)return null;s.done=true;return ring.mark(session.id,s.trace.key,'first_partial',{...s.trace,sendToPartialMs:now()-s.sentAt});}
 // 每句 ASR 结果到达中转的时刻。arrivedAt 用这条诊断环的单调钟；speechEndToArriveMs 基于送入识别流的音频时间映射，不包含采集端上传前排队；后者独立看 packet_queue。
 function arrive(session, meta = {}) {
  if (!session || session.id == null) return null;
  const raw = typeof meta.key === 'string' ? meta.key : '';
  const key = /^[a-zA-Z0-9:._-]{1,140}$/.test(raw) ? raw : 'asr:' + (++seq);
  const seqNo = Number.isSafeInteger(meta.seq) && meta.seq > 0 ? meta.seq : seq;
  const arrivedAt = now();
  const values = { seq: seqNo, arrivedAt, monoMs: arrivedAt };
  if (Number.isFinite(meta.speechEndToArriveMs) && meta.speechEndToArriveMs >= 0) values.speechEndToArriveMs = meta.speechEndToArriveMs;
  return ring.mark(session.id, key, 'asr_arrive', values);
 }
 function route(req,res,url,local){if(url.pathname!=='/diagnostics/latency')return false;res.writeHead(local&&req.method==='GET'?200:403,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(local&&req.method==='GET'?{clock:'process.hrtime; compare durations only',records:ring.snapshot(url.searchParams.get('sessionId')||undefined)}:{error:'local_only'}));return true;}
 return {receive,sent,partial,arrive,route,snapshot:ring.snapshot};
}
module.exports=createRelay();module.exports.createRelay=createRelay;
