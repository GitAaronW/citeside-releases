'use strict';
// Opt-in authority. Legacy sources are read-only migration inputs, never mirrors.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { TextDecoder } = require('util');
const FILE = '长期记忆.md', MAX_BYTES = 65536;
const file = dir => dir ? path.join(dir, FILE) : '';
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function fail(message, status = 500, extra = {}) { return Object.assign(Error(message), { status, ...extra }); }
function textBytes(text) {
  if (typeof text !== 'string' || !text.isWellFormed()) throw fail('invalid_profile', 400);
  const bytes = Buffer.from(text, 'utf8');
  if (bytes.length > MAX_BYTES) throw fail('profile_too_large', 413);
  return bytes;
}
function readBytes(name, max = MAX_BYTES) {
  let fd;
  try { fd = fs.openSync(name, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK); }
  catch (e) { if (e.code === 'ENOENT') return null; throw e; }
  try {
    const st = fs.fstatSync(fd);
    if (!st.isFile()) throw fail('profile_not_regular');
    if (st.size > max) throw fail('profile_too_large', 413);
    const bytes = Buffer.alloc(max + 1); let n = 0, count;
    while (n < bytes.length && (count = fs.readSync(fd, bytes, n, bytes.length - n, null)) > 0) n += count;
    if (n > max) throw fail('profile_too_large', 413);
    return bytes.subarray(0, n);
  } finally { fs.closeSync(fd); }
}
function decode(bytes) {
  try { return new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes); }
  catch { throw fail('profile_invalid_utf8'); }
}
function result(bytes) { return { ok: true, text: decode(bytes), revision: digest(bytes), maxBytes: MAX_BYTES }; }
function readExisting(dir) {
  if (!dir) return null;
  const bytes = readBytes(file(dir));
  return bytes === null ? null : result(bytes);
}
// Read-only SQLite connection: do not call the normal store opener, which creates
// tables and changes PRAGMAs. Projects and independently revocable MCP grants stay out.
function structuredSnapshot(dir) {
  const stateDir = path.join(dir, 'state'), dbFile = path.join(stateDir, 'memory.db');
  let stat;
  try {
    if (!fs.lstatSync(stateDir).isDirectory()) throw fail('profile_not_regular');
    stat = fs.lstatSync(dbFile);
  } catch (e) { if (e.code === 'ENOENT') return ''; throw e; }
  if (!stat.isFile() || stat.isSymbolicLink()) throw fail('profile_not_regular');
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(dbFile, { readOnly: true });
  try {
    const after = fs.lstatSync(dbFile);
    if (stat.dev !== after.dev || stat.ino !== after.ino || after.isSymbolicLink()) throw fail('profile_conflict', 409);
    db.exec('BEGIN'); // lengths and contents must belong to the same read snapshot.
    if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='user_profile_v2'").get()) return '';
    const columns = ['name', 'role', 'domain', 'preferences', 'custom_notes'];
    const lengths = db.prepare('SELECT ' + columns.map(k => 'length(CAST(' + k + ' AS BLOB)) AS ' + k).join(',') + " FROM user_profile_v2 WHERE id='default'").get();
    if (!lengths) return '';
    if (Object.values(lengths).reduce((n, v) => n + Number(v || 0), 0) > MAX_BYTES) throw fail('profile_too_large', 413);
    const row = db.prepare('SELECT ' + columns.join(',') + " FROM user_profile_v2 WHERE id='default'").get();
    return columns.filter(k => row[k] !== '' && row[k] != null).map(k => '### ' + k + '\n\n' + row[k]).join('\n\n');
  } finally { db.close(); }
}
function migration(dir) {
  const sections = [], legacy = readBytes(path.join(dir, '对我的记忆.md'));
  // Exact historical sample only. Never invoke profile.read(), which creates it.
  const sample = '# 对我的记忆\n\n## 我是谁\n\n我在 Nothing 工作。\n\n## 项目与产品对应\n\n## 专有名词纠正\n\n- CM3 pro → CMF Phone 3 Pro\n';
  if (legacy !== null) {
    const raw = decode(legacy);
    if (raw && raw !== sample) sections.push('## 来源：对我的记忆.md\n\n' + raw);
  }
  const brief = readBytes(path.join(dir, 'my-ai-brief.json'), MAX_BYTES * 6 + 4096);
  if (brief !== null) {
    let parsed;
    try { parsed = JSON.parse(decode(brief)); } catch { throw fail('profile_migration_invalid_json'); }
    if (parsed.items !== undefined && !Array.isArray(parsed.items)) throw fail('profile_migration_invalid_json');
    const items = (parsed.items || []).map(item => {
      if (typeof item === 'string') return item;
      if (!item || typeof item !== 'object') return JSON.stringify(item);
      // No parser limits, trimming, kind filtering or MAX_ITEMS during migration.
      return Object.entries(item).map(([key, value]) => '### ' + key + '\n\n' + (typeof value === 'string' ? value : JSON.stringify(value))).join('\n\n');
    });
    if (items.length) sections.push('## 来源：my-ai-brief.json\n\n' + items.join('\n\n'));
  }
  const structured = structuredSnapshot(dir);
  if (structured) sections.push('## 来源：结构化长期画像\n\n' + structured);
  return textBytes(sections.join('\n\n'));
}
function tempFile(dir, bytes) {
  const tmp = file(dir) + '.' + crypto.randomBytes(12).toString('hex') + '.tmp';
  const fd = fs.openSync(tmp, fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_NOFOLLOW, 0o600);
  try { fs.writeFileSync(fd, bytes); fs.fsyncSync(fd); }
  catch (e) { fs.closeSync(fd); fs.unlinkSync(tmp); throw e; }
  fs.closeSync(fd); return tmp;
}
function syncDirectory(dir) { const fd = fs.openSync(dir, fs.constants.O_RDONLY); try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); } }
function initialize(dir) {
  const current = readExisting(dir); if (current) return current;
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const bytes = migration(dir), tmp = tempFile(dir, bytes);
  try {
    // Publish only a complete file; unlike rename, link never replaces a winner.
    try { fs.linkSync(tmp, file(dir)); syncDirectory(dir); }
    catch (e) { if (e.code !== 'EEXIST') throw e; }
  } finally { fs.unlinkSync(tmp); }
  return readExisting(dir);
}
function read(dir) {
  if (!dir) throw fail('missing_data_dir');
  return readExisting(dir) || locked(dir, () => initialize(dir));
}
function locked(dir, fn) {
  if (!dir) throw fail('missing_data_dir');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  // SQLite owns only the mutex, never the document. The OS releases it on exit.
  // A foreign legacy lock is not safe to steal.
  if (fs.existsSync(file(dir) + '.lock')) throw fail('profile_busy', 503);
  const name = file(dir) + '.lock.sqlite';
  let fd, db, active = false;
  try {
    fd = fs.openSync(name, fs.constants.O_RDWR | fs.constants.O_CREAT | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK, 0o600);
    const before = fs.fstatSync(fd);
    if (!before.isFile()) throw fail('profile_not_regular');
    const { DatabaseSync } = require('node:sqlite');
    db = new DatabaseSync(name);
    const after = fs.lstatSync(name);
    if (after.isSymbolicLink() || before.dev !== after.dev || before.ino !== after.ino) throw fail('profile_not_regular');
    db.exec('PRAGMA busy_timeout=0');
    try { db.exec('BEGIN IMMEDIATE'); active = true; }
    catch (e) { if (/locked|busy/i.test(e.message)) throw fail('profile_busy', 503); throw e; }
    return fn();
  } finally {
    if (active) db.exec('ROLLBACK');
    if (db) db.close();
    if (fd !== undefined) fs.closeSync(fd);
  }
}
function replace(dir, bytes) {
  const tmp = tempFile(dir, bytes);
  try { fs.renameSync(tmp, file(dir)); syncDirectory(dir); }
  finally { try { fs.unlinkSync(tmp); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
  return result(bytes);
}
function save(dir, text, baseRevision) {
  const bytes = textBytes(text);
  if (typeof baseRevision !== 'string' || !/^[a-f0-9]{64}$/.test(baseRevision)) throw fail('invalid_profile_revision', 400);
  return locked(dir, () => {
    const current = initialize(dir);
    if (baseRevision !== current.revision) throw fail('profile_conflict', 409, { revision: current.revision });
    return replace(dir, bytes);
  });
}
const itemId = (kind, text) => crypto.createHash('sha1').update(kind + '\n' + text).digest('hex').slice(0, 10);
function importBlocks(text) {
  const out = [];
  const re = /\n\n<!-- citeside-ai-brief:([a-z]+):([0-9a-f]{10}) -->\n### 来源：AI 连接导入\n\n([\s\S]*?)\n<!-- \/citeside-ai-brief:\2 -->/g;
  for (const m of text.matchAll(re)) if (itemId(m[1], m[3]) === m[2]) out.push({ id: m[2], kind: m[1], text: m[3], block: m[0] });
  return out;
}
function importedItems(dir) { const current = readExisting(dir); return current ? importBlocks(current.text).map(({ block, ...item }) => item) : []; }
function appendImports(dir, items, legacyWrite) {
  return locked(dir, () => {
    const current = readExisting(dir);
    if (!current && legacyWrite) return legacyWrite();
    if (!current) throw fail('profile_document_missing');
    const ids = new Set(importBlocks(current.text).map(i => i.id));
    const added = items.filter(i => !ids.has(i.id));
    const suffix = added.map(i => '\n\n<!-- citeside-ai-brief:' + i.kind + ':' + i.id + ' -->\n### 来源：AI 连接导入\n\n' + i.text + '\n<!-- /citeside-ai-brief:' + i.id + ' -->').join('');
    return replace(dir, textBytes(current.text + suffix));
  });
}
function removeImport(dir, id, legacyWrite) {
  return locked(dir, () => {
    const current = readExisting(dir);
    if (!current && legacyWrite) return legacyWrite();
    if (!current) throw fail('profile_document_missing');
    let text = current.text;
    for (const item of importBlocks(text)) if (item.id === id) text = text.replace(item.block, '');
    return replace(dir, textBytes(text));
  });
}
function appendMeetingProfile(dir, fields) {
  if (!readExisting(dir)) return;
  return locked(dir, () => {
    const current = readExisting(dir);
    const labels = { name:'姓名', role:'职位', domain:'领域', preferences:'偏好', customNotes:'补充' };
    const entries = Object.entries(fields).filter(([key, value]) => labels[key] && typeof value === 'string' && value);
    if (!entries.length) return;
    const block = '\n\n### 会后自动补充\n\n' + entries.map(([key,value]) => labels[key] + '：' + value).join('\n\n');
    if (current.text.includes(block)) return;
    return replace(dir, textBytes(current.text + block));
  });
}

module.exports = { FILE, MAX_BYTES, file, read, readExisting, save, importedItems, appendImports, removeImport, appendMeetingProfile };
