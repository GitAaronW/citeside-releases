'use strict';
// Exact source binding is checked again at ingestion and revision boundaries.
const {normalizeChart}=require('../web/meeting-graph');
function select(raw,rows,allowed){
 if(!Array.isArray(rows)||!(allowed instanceof Set)||!allowed.has(raw?.sourceId))return {kind:'text'};
 const matches=rows.filter(row=>row.id===raw.sourceId);
 if(matches.length!==1||matches[0].stale||typeof raw.quote!=='string'||String(matches[0].text||'').trim()!==raw.quote.trim())return {kind:'text'};
 try{return normalizeChart(raw)||{kind:'text'};}catch{return {kind:'text'};}
}
module.exports={select};
