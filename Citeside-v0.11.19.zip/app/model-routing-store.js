'use strict';
// Persist the last valid role-routing document. Snapshots and execution stay in model-routing.js.
const fs = require('node:fs');
const path = require('node:path');
const { write } = require('./durable-json');
const { compile, registry } = require('./model-routing');

const FILE_NAME = 'model-routing.json';

function create({ dataDir, env } = {}) {
  if (typeof dataDir !== 'string' || !dataDir) {
    throw Object.assign(new Error('routing_data_dir_required'), { code: 'routing_data_dir_required' });
  }
  const file = path.join(dataDir, FILE_NAME);
  // registry.task freezes a createTask snapshot. This store only decides which compiled config is active.
  const memory = registry();
  let configured = false;
  let routeVersion = null;
  let errorCode = null;
  let document = null;

  function status() {
    const state = errorCode ? 'invalid' : (configured ? 'ready' : 'empty');
    return {
      state,
      ok: state !== 'invalid',
      configured,
      routeVersion,
      errorCode,
      schemaVersion: configured ? 1 : null,
    };
  }

  function activate(config) {
    const applied = memory.update(config);
    if (!applied.ok) return { ok: false, errorCode: applied.errorCode || 'routing_config_invalid', routeVersion };
    document = structuredClone(config);
    configured = true;
    routeVersion = applied.routeVersion;
    errorCode = null;
    return { ok: true, errorCode: null, routeVersion };
  }

  function rejectRead(code) {
    if (!configured) {
      errorCode = code;
      routeVersion = null;
      return status();
    }
    // A later unreadable file does not replace the in-process snapshot and does not select a provider.
    return { ...status(), ok: false, errorCode: code };
  }

  function load() {
    let text;
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch (e) {
      if (e.code === 'ENOENT') {
        if (!configured) errorCode = null;
        return configured ? { ...status(), ok: false, errorCode: 'routing_file_missing' } : status();
      }
      return rejectRead('routing_file_unreadable');
    }
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      return rejectRead('routing_file_invalid');
    }
    let compiled;
    try {
      compiled = compile(json);
    } catch (e) {
      return rejectRead(e.code || 'routing_config_invalid');
    }
    const applied = activate(compiled.config);
    if (!applied.ok) return rejectRead(applied.errorCode || 'routing_config_invalid');
    return status();
  }

  function update(input) {
    let compiled;
    try {
      compiled = compile(input);
    } catch (e) {
      return { ok: false, errorCode: e.code || 'routing_config_invalid', routeVersion };
    }
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      write(file, compiled.config);
      fs.chmodSync(file, 0o600);
    } catch {
      return { ok: false, errorCode: 'routing_persist_failed', routeVersion };
    }
    return activate(compiled.config);
  }

  function task(role, taskEnv = env, now) {
    return memory.task(role, taskEnv || {}, now);
  }

  return { load, status, update, task, document: () => document && structuredClone(document) };
}

module.exports = { create, FILE_NAME };
