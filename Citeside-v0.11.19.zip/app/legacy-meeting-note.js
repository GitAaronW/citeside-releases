'use strict';
// Read-only projection of saved legacy notes. Markdown remains literal text;
// neither the lossy Markdown importer nor a summarizer participates here.
const crypto = require('node:crypto');
const FORMATTER_VERSION = 'legacy-meeting-note/1';
const MAX_JSON = 6000000, MAX_NODES = 16000;
const HEADINGS = {'笔记':'Notes','总结':'Summary','笔记（手工补充）':'Notes (manual addition)','讨论（目录）':'Discussion (outline)','结论':'Conclusions','待办':'To-dos','待办（原有提及）':'To-dos (saved mentions)','讨论':'Discussion','讨论（待确认）':'Discussion (open questions)','讨论（原有核对）':'Discussion (saved review)','讨论（原有洞察）':'Discussion (saved insights)','讨论（原有洞察摘要）':'Discussion (saved insight summary)','讨论（原有说明）':'Discussion (saved note)','讨论（原有范围与缺口）':'Discussion (saved scope and gaps)','讨论（原有洞察来源）':'Discussion (saved insight sources)','讨论（待核查）':'Discussion (claims to verify)'};
const fail = (code, path) => Object.assign(Error(code + (path ? ': ' + path : '')), { code, status: code === 'legacy_note_too_large' ? 413 : 422 });
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const nonempty = value => typeof value === 'string' && !!value.trim();
const LABELS = {
 text:'内容', claim:'待核查', what:'事项', title:'主题', scope:'范围', conclusion:'结论', decision:'保存的讨论状态', points:'要点', open:'未决',
 owner:'负责人', ownerSuggested:'负责人建议', due:'日期', dueText:'日期原文', note:'说明', verdict:'保存的核查判断', speaker:'说话人', who:'说话人',
 at:'时间', from:'开始', to:'结束', said:'原话', kind:'保存的类型', topic:'议题', ownerSource:'负责人来源', everyone:'全员', why:'原因',
 question:'问题', answer:'回答', detail:'详情', action:'已有行动', label:'名称', evidence:'已有依据', quote:'原话', source:'已有来源', sources:'已有来源',
 url:'链接', date:'日期', options:'选项', ask:'待确认问题', recommend:'保存的推荐序号', affects:'关联', goal:'目标', status:'保存的状态', result:'保存的结果',
 errors:'原有纠错', facts:'原有补充', alignment:'原有目标核对', advice:'原有建议', checked:'原有核查', owners:'负责人建议', todo:'待办序号',
 confidence:'保存的置信判断', web:'保存的联网标志', gaps:'保存的缺口说明', seconds:'秒数', minutes:'分钟数', start:'开始', end:'结束', gap:'缺口',
 body:'正文', content:'正文', summary:'总结', reason:'原因', warning:'说明', heading:'主题'
};
// These are provenance/storage bookkeeping, not the saved note's prose.
const META = new Set(['id','n','seg','refs','sourceRefs','sourceIds','edited','revision','version','v','hash','fingerprint','created','updated','generatedAt','recordedAt','contextLoaded','fromLive','dropped','tier','insightsMeta']);
function render(value, path, active = new Set(), depth = 0, english = false) {
 if (value == null) return '';
 if (typeof value === 'string') {if(value.length>MAX_JSON)throw fail('legacy_note_too_large',path);return value;}
 if (typeof value === 'number' && Number.isFinite(value) || typeof value === 'boolean') return String(value);
 if (depth > 30 || typeof value !== 'object' || active.has(value)) throw fail('legacy_note_unsupported', path);
 active.add(value);
 try {
  if (Array.isArray(value)) return value.map((item,index)=>render(item,path+'['+index+']',active,depth+1,english)).join('\n\n');
  if (!object(value)) throw fail('legacy_note_unsupported', path);
  const out=[];
  for (const key of Object.keys(value).sort()) {
   if (META.has(key)) continue;
   if (key==='from'&&Array.isArray(value[key])&&value[key].every(n=>Number.isInteger(n)&&n>=0)) continue;
   if (!Object.hasOwn(LABELS,key)) throw fail('legacy_note_unsupported',path+'.'+key);
   const text=render(value[key],path+'.'+key,active,depth+1,english);
   if(nonempty(text))out.push((english?key:LABELS[key])+(english?':\n':'：\n')+text);
  }
  return out.join('\n');
 } finally { active.delete(value); }
}
function stringField(current, pending, key) {
 for(const row of [current,pending]) {
  const value=row[key];
  if(value==null)continue;
  if(typeof value!=='string')throw fail('legacy_note_unsupported',key);
  if(nonempty(value))return value;
 }
 return '';
}
function hasMaterial(value, key = '', active = new Set(), depth = 0) {
 if(META.has(key)||['v','at','duration','source','skipped','failed','reason'].includes(key))return false;
 if(typeof value==='string')return !!value.trim();
 if(value==null||typeof value!=='object')return false;
 if(depth>30||active.has(value))throw fail('legacy_note_unsupported',key);
 active.add(value);
 try {
  if(Array.isArray(value))return value.some(item=>hasMaterial(item,'',active,depth+1));
  if(object(value))return Object.entries(value).some(([field,item])=>hasMaterial(item,field,active,depth+1));
  throw fail('legacy_note_unsupported',key);
 }finally{active.delete(value);}
}
function structuredField(current,pending,key) {
 for(const row of [current,pending]) {
  const value=row[key];
  if(value==null)continue;
  if(!object(value))throw fail('legacy_note_unsupported',key);
  if(hasMaterial(value))return value;
  // Unknown structures must not masquerade as an empty saved note.
  if(key==='brief')assertKeys(value,['v','at','duration','meta','fromLive','overview','topics','questions','review','reviewWarning','insights','insights_md','insightsBrief','insightsMeta','insightsWarning','tier','modelNote','contextLoaded','dropped'],'brief');
  else assertKeys(value,['highlights','todos','factchecks','at','source','skipped','failed','reason'],'condensed');
 }
 return null;
}
function reviewOf(current,pending) {
 for(const row of [current,pending]) {
  if(row.review==null)continue;
  if(!object(row.review))throw fail('legacy_note_unsupported','review');
  if(row.review.decisions!==undefined){if(!Array.isArray(row.review.decisions))throw fail('legacy_note_unsupported','review.decisions');return row.review.decisions;}
 }
 return [];
}
function assertKeys(value, keys, path) {
 if(!object(value))throw fail('legacy_note_unsupported',path);
 for(const key of Object.keys(value))if(!keys.includes(key))throw fail('legacy_note_unsupported',path+'.'+key);
}
function array(value,path) { if(value==null)return [];if(!Array.isArray(value))throw fail('legacy_note_unsupported',path);return value; }
function reviewed(condensed,decisions) {
 assertKeys(condensed,['highlights','todos','factchecks','at','source','skipped','failed','reason'],'condensed');
 for(const kind of ['highlights','todos','factchecks'])array(condensed[kind],'condensed.'+kind);
 for(const decision of decisions) {
  if(!object(decision)||!['highlights','todos','factchecks'].includes(decision.kind)||!['keep','edit','drop'].includes(decision.action)||!Number.isInteger(decision.index)||decision.index<0||decision.index>=array(condensed[decision.kind],decision.kind).length)throw fail('legacy_note_review_mismatch','review.decisions');
  for(const key of ['text','owner','due','note'])if(decision[key]!=null&&typeof decision[key]!=='string')throw fail('legacy_note_unsupported','review.'+key);
 }
 const out={};
 for(const kind of ['highlights','todos','factchecks'])out[kind]=array(condensed[kind],kind).map((item,index)=>{
  if(!object(item))throw fail('legacy_note_unsupported','condensed.'+kind+'['+index+']');
  // Same first-decision, explicit drop and nonempty edit precedence as the
  // existing review.shareNote pick, without normalizeDecision's text caps.
  const decision=decisions.find(d=>d.kind===kind&&d.index===index);
  if(decision?.action==='drop')return null;
  const row={...item};for(const key of ['owner','due','note'])if(decision?.[key])row[key]=decision[key];
  if(decision?.text){if(!row.text&&Object.hasOwn(row,'claim'))row.claim=decision.text;else row.text=decision.text;}
  return row;
 }).filter(Boolean);
 return out;
}
function briefAsCondensed(brief) {
 if(!object(brief.overview))throw fail('legacy_note_review_mismatch','brief.overview');
 const conclusions=array(brief.overview.conclusions,'brief.overview.conclusions'),todos=array(brief.overview.todos,'brief.overview.todos');
 return {highlights:conclusions.map(text=>{if(typeof text!=='string')throw fail('legacy_note_unsupported','brief.conclusions');return {text};}),todos:todos.map(todo=>{
  if(!object(todo)||typeof todo.what!=='string')throw fail('legacy_note_unsupported','brief.todos');
  return {text:todo.what,owner:todo.ownerSource==='meeting'?(todo.owner||''):'',due:todo.due||''};
 }),factchecks:[]};
}
function briefSections(brief,add,format) {
 assertKeys(brief,['v','at','duration','meta','fromLive','overview','topics','questions','review','reviewWarning','insights','insights_md','insightsBrief','insightsMeta','insightsWarning','tier','modelNote','contextLoaded','dropped'],'brief');
 if(brief.overview!=null) {
  assertKeys(brief.overview,['topics','conclusions','todos','mentions'],'brief.overview');
  for(const key of ['topics','todos','mentions'])for(const item of array(brief.overview[key],'brief.overview.'+key))if(!object(item))throw fail('legacy_note_unsupported','brief.overview.'+key);
  for(const item of array(brief.overview.conclusions,'brief.overview.conclusions'))if(typeof item!=='string')throw fail('legacy_note_unsupported','brief.overview.conclusions');
  for(const [key,label] of [['topics','讨论（目录）'],['conclusions','结论'],['todos','待办'],['mentions','待办（原有提及）']])add(label,format(array(brief.overview[key],'brief.overview.'+key),'brief.overview.'+key));
 }
 for(const topic of array(brief.topics,'brief.topics'))if(!object(topic))throw fail('legacy_note_unsupported','brief.topics');
 for(const [key,label] of [['topics','讨论'],['questions','讨论（待确认）'],['review','讨论（原有核对）'],['insights','讨论（原有洞察）'],['insights_md','讨论（原有洞察）'],['insightsBrief','讨论（原有洞察摘要）'],['reviewWarning','讨论（原有说明）'],['insightsWarning','讨论（原有说明）'],['modelNote','讨论（原有说明）']])if(brief[key]!=null)add(label,format(brief[key],'brief.'+key));
 if(brief.meta!=null)add('讨论（原有范围与缺口）',format(brief.meta,'brief.meta'));
 if(brief.insightsMeta?.sources!=null)add('讨论（原有洞察来源）',format(brief.insightsMeta.sources,'brief.insightsMeta.sources'));
}
function build({id,title='',session={},pending={},source={}}={}) {
 session=session??{};pending=pending??{};source=source??{};
 for(const [key,row]of Object.entries({session,pending,source}))if(!object(row))throw fail('legacy_note_unsupported',key);
 if(typeof id!=='string'||!id||typeof title!=='string')throw fail('legacy_note_unsupported','identity');
 const english=(session.uiLang||pending.uiLang)==='en';
 const format=(value,path)=>render(value,path,new Set(),0,english);
 const sections=[],add=(label,text)=>{if(nonempty(text))sections.push((english?HEADINGS[label]:label)+'\n'+text);};
 const notes=stringField(session,pending,'notes'),summary=stringField(session,pending,'summary');
 add('笔记',notes);add('总结',summary);
 if(source.notes!=null&&typeof source.notes!=='string')throw fail('legacy_note_unsupported','source.notes');
 if(nonempty(source.notes)&&source.notes!==notes)add('笔记（手工补充）',source.notes);
 if(!nonempty(notes)&&!nonempty(summary)) {
  const brief=structuredField(session,pending,'brief'),condensed=structuredField(session,pending,'condensed'),decisions=reviewOf(session,pending);
  if(decisions.length&&(condensed||brief)) {
   const selected=reviewed(condensed||briefAsCondensed(brief),decisions);
   for(const [key,label]of [['highlights','结论'],['todos','待办'],['factchecks','讨论（待核查）']])add(label,format(selected[key],'condensed.'+key));
  } else if(brief)briefSections(brief,add,format);
  else if(condensed){const selected=reviewed(condensed,[]);for(const [key,label]of [['highlights','结论'],['todos','待办'],['factchecks','讨论（待核查）']])add(label,format(selected[key],'condensed.'+key));}
 }
 // Only a dedicated unbound note body is prose. A meeting source body is
 // commonly a concatenated transcript and must never become a legacy note.
 if(!sections.length&&source.kind==='note'&&!source.motherDocumentId){
  if(source.body!=null&&typeof source.body!=='string')throw fail('legacy_note_unsupported','source.body');
  add('笔记',source.body);
 }
 if(!sections.length)return null;
 const text=sections.join('\n\n'),content={type:'doc',content:[]};let nodes=1;
 if(text.length>MAX_JSON)throw fail('legacy_note_too_large','content');
 let offset=0;
 while(true) {
  const next=text.indexOf('\n',offset),line=next<0?text.substring(offset):text.substring(offset,next);
  nodes+=line.length?2:1;if(nodes>MAX_NODES)throw fail('legacy_note_too_large','nodes');
  content.content.push(line.length?{type:'paragraph',content:[{type:'text',text:line}]}:{type:'paragraph'});
  if(next<0)break;offset=next+1;
 }
 if(JSON.stringify(content).length>MAX_JSON)throw fail('legacy_note_too_large','content');
 const hash=crypto.createHash('sha256').update(JSON.stringify({formatterVersion:FORMATTER_VERSION,id,title,content})).digest('hex');
 return {kind:'legacy',text,content,hash,meetingIds:[id]};
}
module.exports={build,FORMATTER_VERSION,MAX_JSON,MAX_NODES};
