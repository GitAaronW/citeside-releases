'use strict';
// Pure reducer: milliseconds and snapshots come from the caller, never I/O.
const APPS=[
 ['Zoom',['us.zoom.xos']],['Teams',['com.microsoft.teams2','com.microsoft.teams']],
 ['飞书',['com.electron.lark','com.larksuite.larkApp']],
 ['腾讯会议',['com.tencent.meeting','com.tencent.tencentmeeting']],['Slack',['com.tinyspeck.slackmacgap']],
 ['微信',['com.tencent.xinWeChat','com.tencent.xinwechat']],['钉钉',['com.alibaba.DingTalkMac']],
 ['FaceTime',['com.apple.FaceTime']],['WhatsApp',['net.whatsapp.WhatsApp']],['Discord',['com.hnc.Discord']],
 ['Chrome',['com.google.Chrome']],['Safari',['com.apple.Safari']],['Edge',['com.microsoft.edgemac']],
 ['Brave',['com.brave.Browser']],['Arc',['company.thebrowser.Browser']],['Firefox',['org.mozilla.firefox']]
].map(([name,prefixes])=>({id:prefixes[0],name,prefixes}));
const END_COUNTDOWN_MS=15000;
function appOf(bundle){return APPS.find(a=>a.prefixes.some(p=>bundle.startsWith(p))) || null;}
const eventKey=e=>String(e.calendarId||'')+'|'+e.eventId+'|'+e.start;
const clock=t=>{const d=new Date(t);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');};
const timeRange=e=>clock(e.start)+' – '+clock(e.end);
function eligible(e){return !!e.eventId&&Number.isFinite(Date.parse(e.start))&&Date.parse(e.end)>Date.parse(e.start)&&!e.cancelled&&e.status!=='cancelled'&&e.self_rsvp_status!=='decline'&&(e.attendeeList||e.attendees||[]).filter(p=>p?.type!=='resource'&&!p?.declined&&p?.rsvp_status!=='decline').length>=2;}
function initial(){return {apps:{},dismissedApps:[],seenApps:[],seenEvents:[],dismissedEvents:[],notice:null,recording:null,pending:false,serial:0};}
function step(previous,input={},ctx={}){
 const s=structuredClone(previous),effects=[],now=ctx.now??0;
 const hide=()=>{if(s.notice){effects.push({type:'hide'});s.notice=null;}};
 const show=n=>{s.notice={...n,id:++s.serial,at:now};effects.push({type:'show',notice:s.notice});};
 const events=(ctx.events||[]).filter(eligible);
 const associated=()=>events.filter(e=>now>=Date.parse(e.start)&&(now-Date.parse(e.start)<=900000||(now<Date.parse(e.end)&&s.seenEvents.includes(eventKey(e))))).sort((a,b)=>Date.parse(b.start)-Date.parse(a.start))[0];
 if(input.type==='mic'){
  const ids=[...new Set((input.apps||[]).map(x=>appOf(typeof x==='string'?x:x.bundleId||'')?.id).filter(Boolean))];
  s.apps=Object.fromEntries(ids.map(id=>[id,s.apps[id]??now]));
  s.dismissedApps=s.dismissedApps.filter(id=>ids.includes(id));s.seenApps=s.seenApps.filter(id=>ids.includes(id));
 }
 if(input.type==='mic_unavailable'){s.apps={};if(s.recording){s.recording.leftAt=null;s.recording.endShown=false;}if(s.notice?.kind==='end')hide();}
 if(input.type==='started'){s.pending=false;s.recording={app:input.app||null,event:input.event||null,sessionId:input.sessionId,start:now,watch:true,leftAt:null,endShown:false,autoStops:0,fromNotice:true,stoppedByNotice:false};hide();}
 if(input.type==='stop_failed'&&s.recording){s.recording.stopping=false;s.recording.endShown=false;}
 if(input.type==='start_failed'){s.pending=false;if(input.notice)show(input.notice);}
 if(ctx.recording===false&&s.recording&&!s.pending){const id=s.recording.sessionId,shouldOpen=!!(s.recording.fromNotice||s.recording.stoppedByNotice);s.recording=null;hide();if(shouldOpen&&id)effects.push({type:'open',sessionId:id});}
 // Active manual native recordings are adopted only when the caller names a real session.
 if(ctx.recording&&ctx.sessionId&&!s.pending&&(!s.recording||(s.recording.sessionId&&s.recording.sessionId!==ctx.sessionId))){
  s.recording={app:null,event:associated()||null,sessionId:ctx.sessionId,start:now,watch:true,leftAt:null,endShown:false,autoStops:0,fromNotice:false,stoppedByNotice:false};hide();
 }
 if(input.type==='action'&&s.notice&&input.id===s.notice.id){
  const n=s.notice;
  if(input.action==='start'&&n.kind==='start'&&!ctx.recording&&!s.pending){s.pending=true;hide();effects.push({type:'start',app:n.app,event:n.event,notice:n});}
  if(input.action==='dismiss'&&n.kind==='start'){if(n.app)s.dismissedApps.push(n.app.id);if(n.event)s.dismissedEvents.push(eventKey(n.event));hide();}
  if(input.action==='mute'&&n.kind==='start'&&n.app){s.dismissedApps.push(n.app.id);effects.push({type:'mute',app:n.app.id});hide();}
  if(input.action==='stop'&&n.kind==='end'){if(s.recording){s.recording.stopping=true;s.recording.stoppedByNotice=true;}hide();effects.push({type:'stop',sessionId:s.recording?.sessionId});}
  if(input.action==='continue'&&n.kind==='end'){if(s.recording){s.recording.watch=false;s.recording.leftAt=null;s.recording.endShown=false;}hide();}
 }
 if(ctx.enabled===false){hide();return {state:s,effects};}
 if(s.recording){
  const r=s.recording;
  if(r.stopping)return {state:s,effects};
  // Notice-started and manual sessions both bind a call app after 3s of mic use.
  if(!r.app&&r.watch){const id=Object.keys(s.apps).find(id=>now-s.apps[id]>=3000);if(id)r.app=APPS.find(a=>a.id===id);}
  if(r.app&&r.watch){
   if(s.apps[r.app.id]!==undefined){r.leftAt=null;r.autoStops=0;if(r.endShown){r.endShown=false;hide();}}
   else {r.leftAt=r.leftAt??now;if(now-r.leftAt>=10000&&!r.endShown){r.endShown=true;const sec=Math.round(END_COUNTDOWN_MS/1000);show({kind:'end',app:r.app,countdownSec:sec,title:'会议结束了',subtitle:r.app.name+' 已退出通话 · '+sec+' 秒后自动生成纪要'});}}
  }
  if(s.notice?.kind==='end'&&r.watch&&(r.autoStops||0)<2&&now-s.notice.at>=END_COUNTDOWN_MS){r.autoStops=(r.autoStops||0)+1;r.stopping=true;r.stoppedByNotice=true;hide();effects.push({type:'stop',sessionId:r.sessionId});return {state:s,effects};}
  if(s.notice?.kind==='end'&&now-s.notice.at>=120000)hide();
  return {state:s,effects};
 }
 if(ctx.recording||s.pending){hide();return {state:s,effects};}
 if(s.notice&&now-s.notice.at>=120000)hide();
 if(s.notice?.app&&s.apps[s.notice.app.id]===undefined)hide();
 if(s.notice)return {state:s,effects};
 for(const id of Object.keys(s.apps)){
  if(now-s.apps[id]<3000||s.dismissedApps.includes(id)||s.seenApps.includes(id)||(ctx.mutedApps||[]).includes(id))continue;
  const app=APPS.find(a=>a.id===id),event=associated();s.seenApps.push(id);
  if(event&&(s.seenEvents.includes(eventKey(event))||s.dismissedEvents.includes(eventKey(event))))continue;
  if(event)s.seenEvents.push(eventKey(event));
  const title=event?.title||(app.name==='Slack'?'检测到语音通话':['微信','FaceTime','WhatsApp'].includes(app.name)?'检测到通话':'检测到会议');
  show({kind:'start',app,event:event||null,title,subtitle:event?timeRange(event)+' · '+app.name:app.name});break;
 }
 if(!s.notice)for(const e of events){
  const key=eventKey(e),delta=Date.parse(e.start)-now;
  if(delta<0||delta>60000||s.seenEvents.includes(key)||s.dismissedEvents.includes(key))continue;
  s.seenEvents.push(key);show({kind:'start',event:e,app:null,title:e.title,subtitle:timeRange(e)});break;
 }
 return {state:s,effects};
}
module.exports={APPS,END_COUNTDOWN_MS,appOf,eligible,eventKey,initial,step};
