'use strict';
// Presentation only: never generate, persist, or infer meeting conclusions.
const clean=v=>String(v??'').replace(/\*\*|`/g,'').trim();
const list=v=>Array.isArray(v)?v:[];
const sentence=v=>[...new Intl.Segmenter('zh-CN',{granularity:'sentence'}).segment(String(v||''))].map(s=>s.segment.trim()).filter(Boolean);
const dueDate=v=>clean(v).replace(/^\d{4}-(\d{2})-(\d{2})$/,(_,m,d)=>Number(m)+' 月 '+Number(d)+' 日');
function sections(note){
 const result=[];let current={title:'',level:0,lines:[]};result.push(current);
 for(const line of String(note||'').split('\n')){const h=line.match(/^(#{1,4})\s+(.*)$/);if(h){current={title:clean(h[2]).replace(/^\d+(?:\.\d+)*[.、]?\s*/,''),level:h[1].length,lines:[]};result.push(current);}else current.lines.push(line);}
 return result;
}
function noteParts(note){
 const groups=sections(note),topics=[],todos=[];
 const hasSpecificTopics=groups.some(g=>/^(议题|核心要点|Topics)$/i.test(g.title));let inTopics=false,inTodos=false,hasTodos=false;
 for(const g of groups){
  if(/待办|To-?dos?|Action items/i.test(g.title)){inTodos=true;inTopics=false;hasTodos=true;}
  else if(g.level<=2&&g.title){inTodos=false;inTopics=/^(议题|总结|核心要点|Summary|Topics)$/i.test(g.title)&&!(hasSpecificTopics&&/^(总结|Summary)$/i.test(g.title));}
  if(inTodos){
   for(const line of g.lines){
    if(/^\|.*\|$/.test(line)){const c=line.slice(1,-1).split('|').map(clean);if(c.length>=4&&!/^#|^-/.test(c[0]))todos.push({text:c[1],owner:c[2]==='—'?'':c[2],due:c[3]==='—'?'':c[3]});}
    else if(/^[-*]\s+/.test(line)){const t=clean(line.replace(/^[-*]\s+/,'')),m=t.match(/^(.*?)（([^（）]*?)(?:\s*·\s*([^（）]*))?）$/);todos.push(m?{text:m[1],owner:!m[3]&&/^\d{4}-\d{2}-\d{2}$/.test(m[2])?'':m[2],due:m[3]||(/^\d{4}-\d{2}-\d{2}$/.test(m[2])?m[2]:'')}:{text:t,owner:'',due:''});}
   }
  }else if(inTopics){
   const lines=g.lines.map(l=>clean(l.replace(/^[-*]\s+/,''))).filter(Boolean);
   const conclusion=lines.find(l=>/^结论[：:]/.test(l));
   if(conclusion){const rest=lines.filter(l=>l!==conclusion&&!/^未决[：:]/.test(l)).map(l=>l.replace(/\s*\d{1,2}:\d{2}(?::\d{2})?\s*$/,''));topics.push({conclusion:conclusion.replace(/^结论[：:]\s*/,''),detail:rest.flatMap(sentence).slice(0,2).join('')});}
   else for(const l of lines){if(!/^_.*_$|^\||^这一场 \d|^从会中记下的/.test(l))topics.push({conclusion:l,detail:''});}
  }
 }
 return {topics:topics.slice(0,5),todos,hasTodos};
}
const knownName=v=>{const s=clean(v);return s&&!/^(S\d+|speaker\s*\d+|spk\s*\d+|说话人\s*\d+|未认人|未指定|待定负责人|待定|—)$/i.test(s)?s:'';};
function metadata(session){
 const valid=v=>{if(v===null||v===undefined||v==='')return null;const d=new Date(v);return Number.isNaN(+d)?null:d;},start=valid(session.start??session.startTs),end=valid(session.end);
 const hh=d=>d.toLocaleTimeString('zh-CN',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',hour12:false});
 const date=start?start.toLocaleDateString('zh-CN',{timeZone:'Asia/Shanghai',month:'numeric',day:'numeric'}).replace(/(\d+)\/(\d+)/,'$1 月 $2 日'):'';
 const duration=start&&end&&end>=start?Math.round((end-start)/60000):null;
 const attendees=[...list(session.participants),...list(session.attendees),...list((session.calendarEvent||session.calendar?.event)?.attendees)].map(p=>typeof p==='string'?p:p?.name||p?.displayName||'');
 const participants=[...new Set([...attendees,...Object.values(session.names||{})].map(knownName).filter(Boolean))];
 return {participants,text:[start?date+' '+hh(start)+(end?'–'+hh(end):''):'',duration!==null?duration+' 分钟':'',participants.join('、')].filter(Boolean).join(' · ')};
}
function view(session,note){
 const parsed=noteParts(note),brief=session.brief||{};
 const topics=list(brief.topics).filter(t=>clean(t?.conclusion)).slice(0,5).map(t=>({conclusion:clean(t.conclusion),detail:list(t.points).map(p=>typeof p==='string'?p:p.text).flatMap(sentence).slice(0,2).join('')}));
 // Do not pad a short meeting to three topics or manufacture explanations.
 const fallback=list(brief.overview?.conclusions).map(c=>({conclusion:clean(c),detail:''})).filter(t=>t.conclusion).slice(0,5);
 const summary=parsed.topics.length?parsed.topics:topics.length?topics:fallback;
 const sourceTodos=parsed.hasTodos?parsed.todos:list(brief.overview?.todos).map(t=>({text:clean(t.what),owner:clean(t.owner),due:clean(t.due)}));
 const seen=new Set(),todos=sourceTodos.filter(t=>{const key=JSON.stringify([t.text,t.owner,t.due]);if(!t.text||seen.has(key))return false;seen.add(key);return true;}).map(t=>({...t,owner:knownName(t.owner),due:dueDate(t.due)}));
 return {title:clean(session.title||session.topicTitle)||'会议 '+(session.id||''),meta:metadata(session),topics:summary,todos};
}
const summaryMarkdown=v=>v.topics.map(t=>'**'+t.conclusion+'**'+(t.detail?'\n\n'+t.detail:'')).join('\n\n');
const todosMarkdown=v=>v.todos.map(t=>'- [ ] '+t.text+'（'+(t.owner||'未指定')+' · '+(t.due||'未定日期')+'）').join('\n');
module.exports={view,metadata,noteParts,summaryMarkdown,todosMarkdown};
