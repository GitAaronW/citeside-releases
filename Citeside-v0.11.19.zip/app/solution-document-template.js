'use strict';
// The title lives in document metadata. Sections grow only when content arrives.
module.exports=function solutionDocument(){return {type:'doc',content:[{type:'paragraph'}]};};
