'use strict';
// Durable tasks: model work is serialized per meeting. Confirmed tool work is
// recorded before dispatch and never replayed automatically after a restart.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const stores=new Map(),ACTIVE=['queued','running','planning','retrieving','syncing','thinking','awaiting_confirmation','executing','uncertain','stopping'];
const IDLE_TIMEOUT_MS=10*60*1000;
const error=(message,status=409)=>Object.assign(Error(message),{status});
const retryableChat = j => j.meetingId==='assistant:global'&&j.actor==='owner'&&j.request?.actor==='owner'&&j.action==='chat'&&j.request?.action==='chat'&&j.state==='failed'&&!!j.finished&&!j.request.candidateId&&!j.request.taskEntry&&!j.assignmentSourceId&&!j.request.pageContext?.motherDocumentId&&!j.request.pageContext?.range?.length&&!j.confirmedAt&&!j.pendingProposal&&!j.actionKey&&!j.artifact&&!j.motherEdit&&!j.motherRange&&!j.resultIds?.length&&!(j.events||[]).some(e=>['executing','awaiting_confirmation'].includes(e.state));
function publicJob({request,pendingProposal,actionKey,...j}){return {...j,...(request?.retryOf?{retryOf:request.retryOf}:{}),...(request?.taskEntry?{taskId:request.taskEntry.id,taskRevision:request.taskEntry.revision}:{}),...(request?.requestId?{requestId:request.requestId}:{}),...(request?.candidateId?{candidateId:request.candidateId,candidateHash:request.candidateHash}:{}),...(request?.materials?.length?{materials:request.materials}:request?.materialIds?.length?{materialIds:request.materialIds}:{}),...(pendingProposal?{proposal:pendingProposal}:{})};}
// BOARD-JOBS-ACTOR：每条任务记下是谁触发的。owner = 本人在界面上点 / 提问（经本人才能过的 POST 路由），auto = 会中会后管线自动起的；
// 调用方没写就记 unknown，不猜。goal-metrics 的 M2 只数 actor === 'owner'。
const actorOf=a=>a==='owner'||a==='auto'?a:'unknown';
class Jobs {
 constructor(dir,{idleTimeoutMs=IDLE_TIMEOUT_MS}={}){
  this.idleTimeoutMs=idleTimeoutMs;
  this.file=path.join(dir,'meeting-board-jobs.json');this.items=[];this.controllers=new Map();this.listeners=new Set();this.tails=new Map();this.parallelLimit=3;this.parallelRunning=0;this.parallelQueue=[];
  try{const j=JSON.parse(fs.readFileSync(this.file,'utf8'));if(Array.isArray(j))this.items=j;}catch(e){if(e.code!=='ENOENT')throw e;}
  let dirty=false;for(const j of this.items){
   const installed=j.action==='develop'&&require('./development-preview').installed(j.request?.requestId,dir);
   if(installed&&['queued','running','thinking','retrieving','interrupted','preview'].includes(j.state)){j.state='completed';j.reply='开发修改已'+(installed.reviewMode==='self'?'完成自审':installed.reviewMode==='grok'?'通过 Grok 审核':'核对安装回执')+'并安装本机 '+installed.version+'。';j.deployment={commit:installed.head,reviewReceipt:installed.reviewReceipt,version:installed.version};j.finished=new Date().toISOString();delete j.error;dirty=true;continue;}
   if(['executing','stopping'].includes(j.state)){j.state='uncertain';j.error='执行时服务重启，请先到对方核对结果 / Service restarted during execution; check the destination';dirty=true;}
   else if(['queued','running','planning','retrieving','syncing','thinking'].includes(j.state)){j.state='interrupted';j.error='服务已重启，任务未完成 / Service restarted; task unfinished';j.finished=new Date().toISOString();dirty=true;}
  }if(dirty)this.save();
 }
 // Runtime ownership is never restored from disk; a persisted state is not a live worker.
 snapshot(job){return {...publicJob(job),...(retryableChat(job)&&!this.controllers.has(job.id)?{retryable:true}:{}),inFlight:this.controllers.has(job.id)&&!this.controllers.get(job.id).signal.aborted};}
 emit(job){for(const fn of this.listeners)try{fn(this.snapshot(job));}catch{}}
 subscribe(fn){this.listeners.add(fn);return ()=>this.listeners.delete(fn);}
 save(){fs.mkdirSync(path.dirname(this.file),{recursive:true});require('./durable-json').write(this.file,this.items);for(const j of this.items)if(ACTIVE.includes(j.state))this.emit(j);}
 list(id){const all=this.items.filter(j=>j.meetingId===id);return all.filter((j,i)=>ACTIVE.includes(j.state)||i>=all.length-80).map(j=>this.snapshot(j));}
 notify(key,meta){
  if(!/^assigned:[a-f0-9]{24}$/.test(key))throw error('Invalid intake notification',400);
  const oldItems=this.items.slice(),existing=this.items.find(j=>j.intakeKey===key),before=existing&&{...existing};
  const stamp=new Date().toISOString(),job=existing||{id:crypto.randomUUID(),meetingId:'assistant:global',contextId:'',action:'draft',comment:'',actor:'auto',intakeKey:key,created:stamp,events:[]};
  Object.assign(job,{reply:String(meta.reply||''),error:String(meta.error||''),origin:meta.origin,resultUrl:meta.resultUrl||'',assignmentSourceId:meta.assignmentSourceId||'',state:meta.state==='failed'?'failed':'completed',finished:stamp});
  if(!existing)this.items.push(job);if(this.items.length>1000)this.items=this.items.filter(j=>ACTIVE.includes(j.state)).concat(this.items.filter(j=>!ACTIVE.includes(j.state)).slice(-900));
  try{this.save();}catch(e){this.items=oldItems;if(existing)Object.assign(existing,before);throw e;}this.emit(job);return this.snapshot(job);
 }
 assistantList(){return this.items.filter(j=>j.meetingId==='assistant:global'||(['comment','task','run','draft','project-draft'].includes(j.action)&&j.comment)).slice(-100).map(j=>this.snapshot(j));}
 find(id,jobId){const j=this.items.find(j=>j.meetingId===id&&j.id===jobId);if(!j)throw error('任务不存在 / Task not found',404);return j;}
 public(id,jobId){return this.snapshot(this.find(id,jobId));}
 // 按内部 request 查同场在跑的任务；list() 返回的 publicJob 已去掉 request，不能拿来判 final（Codex FINAL-01）。
 activeWhere(id,pred){const j=this.items.find(j=>j.meetingId===id&&ACTIVE.includes(j.state)&&pred(j));return j?this.snapshot(j):null;}
 enqueue(id,request,run,{parallel=false}={}){
  const duplicate=request.requestId&&this.items.find(j=>j.meetingId===id&&j.request?.requestId===request.requestId);if(duplicate)return this.snapshot(duplicate);
  if(this.items.filter(j=>['queued','running','planning','retrieving','syncing','thinking','stopping'].includes(j.state)).length>=20)throw error('任务队列已满，请稍后再试 / Task queue full',429);
  const job={id:crypto.randomUUID(),meetingId:id,contextId:request.contextId||id,state:'queued',action:request.action,moduleId:request.moduleId||'',comment:request.comment||'',quote:request.selection?.original||request.pageContext?.quote||'',lang:request.lang==='en'?'en':'zh',actor:actorOf(request.actor),created:new Date().toISOString(),expiresAt:new Date(Date.now()+this.idleTimeoutMs).toISOString(),request,events:[]};
  const oldItems=this.items.slice();this.items.push(job);if(this.items.length>1000)this.items=this.items.filter(j=>ACTIVE.includes(j.state)).concat(this.items.filter(j=>!ACTIVE.includes(j.state)).slice(-900));try{this.save();}catch(e){this.items=oldItems;throw e;}
  const controller=new AbortController();this.controllers.set(job.id,controller);
  // A missing/ignoring worker must not retain the composer or a queue slot forever.
  let timer;
  const watch=()=>{clearTimeout(timer);job.expiresAt=new Date(Date.now()+this.idleTimeoutMs).toISOString();timer=setTimeout(()=>{
   job.state='interrupted';job.error='任务长时间没有进展，已停止 / Task timed out and was stopped';job.finished=new Date().toISOString();
   controller.abort();this.controllers.delete(job.id);try{this.save();}catch(e){job.persistenceError=e.message;}this.emit(job);
  },this.idleTimeoutMs);timer.unref?.();};
  controller.signal.addEventListener('abort',()=>clearTimeout(timer),{once:true});watch();
  const work=async()=>{
   if(controller.signal.aborted){this.controllers.delete(job.id);return;}
   let savedAt=0;
   const report=(state,message,meta={})=>{
    if(controller.signal.aborted)return;
    if(meta.model)job.model=meta.model;if(meta.effort)job.effort=meta.effort;if(meta.threadId)job.codexThreadId=meta.threadId;if(typeof meta.reply==='string')job.reply=meta.reply;
    job.state=state;job.updated=new Date().toISOString();watch();
    if(!meta.stream&&job.events.at(-1)?.message!==message){job.events.push({at:job.updated,state,message});job.events=job.events.slice(-12);}
    this.emit(job);if(!meta.stream||Date.now()-savedAt>1000){this.save();savedAt=Date.now();}
   };
   job.state=request.action==='run'?'planning':'running';job.started=new Date().toISOString();watch();job.events.push({at:job.started,state:job.state,message:request.action==='run'?'正在拆解任务':'正在处理请求'});
   let onAbort;
   const aborted=new Promise((_,reject)=>{onAbort=()=>reject(Object.assign(Error('已停止'),{cancelled:true}));controller.signal.addEventListener('abort',onAbort,{once:true});});
   try{this.save();const running=Promise.resolve().then(()=>{if(controller.signal.aborted)throw Object.assign(Error('已停止'),{cancelled:true});return run(request,report,controller.signal);});
   // An unconfirmed remote interrupt can still refine the receipt after we free the UI.
   running.then(result=>{
    if(!controller.signal.aborted||!result)return;
    // A late result is evidence, not authorization to revive the job or apply
    // an action. Keep it separate from the normal completed reply.
    const retained={};for(const key of ['reply','artifact','motherEdit','motherRange','resultIds','resultContextId','codexThreadId','codexTurnId'])if(result[key]!==undefined)retained[key]=result[key];
    if(typeof retained.reply==='string')retained.reply=retained.reply.slice(0,40000);
    if(Object.keys(retained).length){job.retainedOutput=retained;this.save();this.emit(job);}
   }).catch(()=>{});
   running.catch(e=>{if(controller.signal.aborted){
    let changed=false;
    if(e.uncertain){job.state='uncertain';job.error=e.message;changed=true;}
    else if(e.remoteInterrupted&&job.state==='interrupted'){job.state='failed';job.error='任务超时，远端已确认停止；输入和产物已保留，可重试 / Task timed out; remote interruption confirmed';changed=true;}
    if(typeof e.draft==='string'&&e.draft.trim()){job.reply=e.draft.slice(0,40000);if(e.draftFormat==='unparsed')job.replyFormat='unparsed';changed=true;}
    if(e.threadId){job.codexThreadId=e.threadId;changed=true;}if(e.turnId){job.codexTurnId=e.turnId;changed=true;}
    if(changed){this.save();this.emit(job);}
   }}).catch(()=>{});
   const result=await Promise.race([running,aborted]);
    if(controller.signal.aborted)throw Object.assign(Error('已停止'),{cancelled:true});
    if(result.artifact)job.artifact=result.artifact;if(result.codexTurnId)job.codexTurnId=result.codexTurnId;if(result.motherEdit)job.motherEdit=result.motherEdit;if(result.motherRange)job.motherRange=result.motherRange;job.reply=result.reply||'已保存到本场工作台 / Saved to this workspace';job.resultRevision=result.source?.revision;job.resultIds=result.resultIds||[];if(result.resultContextId)job.resultContextId=result.resultContextId;if(result.model)job.model=result.model;if(result.effort)job.effort=result.effort;if(result.codexThreadId)job.codexThreadId=result.codexThreadId;if(result.codexSyncError)job.codexSyncError=result.codexSyncError;
    if(result.proposal){if(result.attribution)job.attribution=result.attribution;job.pendingProposal=result.proposal;job.actionKey=result.actionKey;job.state='awaiting_confirmation';}
    else job.state=result.preview?'preview':request.action==='run'&&!result.artifact?'planned':'completed';
   }catch(e){if(!controller.signal.aborted){job.state=e.uncertain?'uncertain':e.cancelled?'cancelled':'failed';job.error=e.cancelled?'':e.message;if(typeof e.draft==='string'&&e.draft){job.reply=e.draft.slice(0,40000);if(e.draftFormat==='unparsed')job.replyFormat='unparsed';}if(e.threadId)job.codexThreadId=e.threadId;if(e.turnId)job.codexTurnId=e.turnId;}}finally{clearTimeout(timer);controller.signal.removeEventListener('abort',onAbort);this.controllers.delete(job.id);job.finished=new Date().toISOString();job.events.push({at:job.finished,state:job.state,message:job.state==='cancelled'?'已停止':job.error?'任务未完成':'结果已保存'});this.save();this.emit(job);}
  };
  if(parallel){this.parallelQueue.push(work);this.pumpParallel();}
  else {const previous=this.tails.get(id)||Promise.resolve();const chained=previous.catch(()=>{}).then(work);this.tails.set(id,chained);chained.catch(()=>{}).finally(()=>{if(this.tails.get(id)===chained)this.tails.delete(id);});}
  return this.snapshot(job);
 }
 pumpParallel(){while(this.parallelRunning<this.parallelLimit&&this.parallelQueue.length){const work=this.parallelQueue.shift();this.parallelRunning++;Promise.resolve().then(work).catch(()=>{}).finally(()=>{this.parallelRunning--;this.pumpParallel();});}}

 cancel(id,jobId){
  const j=this.find(id,jobId);if(['cancelled','stopping','failed','completed','interrupted','preview','planned'].includes(j.state))return this.snapshot(j);
  const controller=this.controllers.get(jobId),previous=j.state,finished=j.finished;
  if(previous!=='awaiting_confirmation'&&!controller&&!['queued','running','planning','retrieving','syncing','thinking','executing'].includes(previous))throw error('这条任务不能停止 / This task cannot be stopped');
  j.state=previous==='executing'&&controller?'uncertain':'cancelled';j.finished=new Date().toISOString();
  try{this.save();}catch(e){j.state=previous;if(finished===undefined)delete j.finished;else j.finished=finished;throw e;}
  controller?.abort();this.controllers.delete(jobId);this.emit(j);return this.snapshot(j);
 }
 confirm(id,jobId,confirmed,validate,run){
  if(confirmed!==true)throw error('请核对后点击确认 / Confirm after reviewing',400);
  const j=this.find(id,jobId);
  if(['executing','completed'].includes(j.state))return this.snapshot(j);
  if(j.state!=='awaiting_confirmation'||!j.pendingProposal)throw error('提案已失效或结果待核对 / Proposal expired or outcome needs checking');
  validate(j); // No await between checking the target and persisting executing.
  j.state='executing';j.confirmedAt=new Date().toISOString();
  try{this.save();}catch(e){j.state='awaiting_confirmation';delete j.confirmedAt;throw e;}
  Promise.resolve().then(()=>run(j)).then(result=>{
   j.state=result?.ok?'completed':result?.uncertain?'uncertain':'failed';j.reply=result?.text||'';
   if(!result?.ok)j.error=result?.error||result?.reason||'工具未返回成功回执 / No successful tool receipt';
   if(result?.url)j.resultUrl=result.url;
   if(result?.note)j.resultNote=result.note;
   if(result?.ok)j.executedAt=new Date().toISOString();
  },e=>{j.state='uncertain';j.error=e.message;}).finally(()=>{j.finished=new Date().toISOString();this.save();this.emit(j);}).catch(()=>{});
  return this.snapshot(j);
 }
}
function get(dir){const key=path.resolve(dir);if(!stores.has(key))stores.set(key,new Jobs(key));return stores.get(key);}
module.exports={get,Jobs,IDLE_TIMEOUT_MS};
