'use strict';
// 用本机已经装好、已经登录的 AI 命令行来跑分析，用户不用申请 API Key、不用充值。
// 支持 Codex（ChatGPT 登录）和 Claude Code（Claude 订阅）。两者都是只读沙箱，只让它读本场材料。
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const CANDIDATES = {
  codex: [
    '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex',
    '/Applications/ChatGPT.app/Contents/Resources/codex',
    path.join(process.env.HOME || '', '.local/bin/codex'),
    '/opt/homebrew/bin/codex', '/usr/local/bin/codex',
  ],
  claude: [
    path.join(process.env.HOME || '', '.local/bin/claude'),
    '/opt/homebrew/bin/claude', '/usr/local/bin/claude',
  ],
};

function findBin(kind) {
  // THT_CODEX_BIN / THT_CLAUDE_BIN：指定用哪个可执行文件。测试拿它挂假命令行，
  // 装在别处的人也能靠它指路（不设就按下面的常见位置找）。
  const forced = String(process.env['THT_' + kind.toUpperCase() + '_BIN'] || '').trim();
  if (forced) { try { fs.accessSync(forced, fs.constants.X_OK); return forced; } catch (e) { return ''; } }
  for (const p of CANDIDATES[kind] || []) { try { fs.accessSync(p, fs.constants.X_OK); return p; } catch (e) {} }
  return '';
}

// —— Codex 净室 ——
// Claude 那条早就是净室启动了（--setting-sources ''、--strict-mcp-config、工具只留 Read）。
// Codex 这条原来只有 --sandbox read-only，它会把 $CODEX_HOME/config.toml 里配的 MCP 全连上、
// 把 $CODEX_HOME/AGENTS.md（Aaron 那份几千字的全局规则）当成系统指令带进去。
// 那就违反了「模型知道的一切只来自引擎递给它的那份输入」：同一段会议材料，换台机器结果不一样，
// 而且它凭什么看到那些东西没人说得清。所以给它一个干净的家。
// 依据 codex-cli 0.155.0-alpha.9.2 的 `codex exec --help`：
//   --ignore-user-config  不读 $CODEX_HOME/config.toml（MCP 就配在那儿），auth 仍然从 CODEX_HOME 取
//   --ignore-rules        不读用户 / 项目的 execpolicy .rules
//   --ephemeral           不往盘上写会话文件
//   -c project_doc_max_bytes=0   项目文档（AGENTS.md）一个字都不带（这是 config.toml 里的真实键，默认 32768）
// 全局 AGENTS.md 读的是 CODEX_HOME 底下那份，--ignore-user-config 管不着它，所以还要换家：
// <数据目录>/state/codex-home 里只软链一个 auth.json，别的什么都没有。
function codexHome(dataDir) {
  if (!dataDir) return '';
  try {
    const real = path.join(os.homedir(), '.codex', 'auth.json');
    if (!fs.existsSync(real)) return '';        // 没有这份凭证就别换家，不然直接登不上
    const dir = path.join(dataDir, 'state', 'codex-home');
    fs.mkdirSync(dir, { recursive: true });
    const link = path.join(dir, 'auth.json');
    let cur = null; try { cur = fs.readlinkSync(link); } catch (e) {}
    if (cur !== real) { try { fs.rmSync(link, { force: true }); } catch (e) {} fs.symlinkSync(real, link); }
    return dir;
  } catch (e) { return ''; }                    // 建不出来就退回原来的家，宁可带上规则也别调不起来
}
// —— 第三种命令行（kind:'custom'）——
// 只从配置来：bin / args / stdin / promptArg / outputJson（见 app/llm.js 的 normalize）。
// 加第三家不改代码，改设置就行（Aaron 2026-09-22：「我现在优先调用 Claude 和 codex 不代表以后我不调用别的」）。
// 净室同样适用：cwd 是数据目录，环境变量只留下面这三个——别的（AI 厂商的 key、代理设置、
// 各种 *_HOME）都不传，不然「模型知道的一切只来自引擎递给它的那份输入」这条就破了。
const CUSTOM_ENV_KEYS = ['PATH', 'HOME', 'LANG'];
function customEnv() {
  const e = {};
  for (const k of CUSTOM_ENV_KEYS) if (process.env[k] != null) e[k] = process.env[k];
  return e;
}
const slot = (s, prompt, model) => String(s).split('{prompt}').join(prompt).split('{model}').join(model || '');
function customArgs(spec, { prompt, model }) {
  const a = (spec.args || []).map(x => slot(x, prompt, model));
  if (spec.promptArg) a.push(slot(spec.promptArg, prompt, model));
  return a;
}
// outputJson:'a.b.0.c' —— stdout 是 JSON 时按点号路径取正文；取不到就当没拿到。
function digPath(obj, route) {
  let cur = obj;
  for (const k of String(route).split('.')) {
    if (cur == null) return null;
    cur = Array.isArray(cur) && /^\d+$/.test(k) ? cur[Number(k)] : cur[k];
  }
  if (cur == null) return null;
  return typeof cur === 'string' ? cur : JSON.stringify(cur);   // 有的命令行把答案直接放成 JSON 对象，不是字符串
}

// 装了不等于能用：没登录的话调用会失败。检测只回「装没装」，能不能用由一次真实试跑决定。
function detect() {
  const out = {};
  for (const kind of Object.keys(CANDIDATES)) { const bin = findBin(kind); if (bin) out[kind] = bin; }
  return out;
}

// 不给 --system-prompt 的话 claude 会加载它自己那套默认系统提示词 + 全部工具 + 用户设置，
// 实测 2026-09-20：默认 60,971 token / 次，换成下面这套 1,222 token / 次，同一句 READY 回答一致。
const MIN_SYSTEM = '你是会议记录分析助手。只输出被要求的内容，不解释、不寒暄。';

// Codex 按用途给推理强度（M1，09-25）：会中要快、会后要稳、思考档要深。和 Claude 那条「live 关思考、think 给预算」同一个意思。
// codex exec 没有 --effort，推理强度是 config 键 model_reasoning_effort（-c 覆盖），模型走 -m。
const CODEX_EFFORT = { live: 'low', quick: 'low', triage: 'low', post: 'medium', think: 'high', verify: 'medium', 'insight-deep': 'high' };
function args(kind, { model = '', system = '', tools, purpose = '', images = [], signal, stage = '', dataDir = '' } = {}) {
  if (kind === 'codex') {
    const a = ['exec', '--sandbox', 'read-only', '--skip-git-repo-check',
      '--ignore-user-config', '--ignore-rules', '--ephemeral', '-c', 'project_doc_max_bytes=0'];
    if (['native-live','proactive-gate'].includes(stage)) a.push('--json');
    if (stage === 'proactive-gate') {
      a.push('-c', 'model_instructions_file=' + JSON.stringify(path.join(__dirname, 'proactive-gate-instructions.txt')));
      // This classifier uses only supplied evidence. Do not load unused agent,
      // connector or memory tool descriptions into every sentence decision.
      for (const feature of ['apps','plugins','multi_agent','memories','code_mode_host']) a.push('-c', 'features.' + feature + '=false');
    }
    if (model) a.push('-m', model);
    if (CODEX_EFFORT[purpose]) a.push('-c', 'model_reasoning_effort="' + CODEX_EFFORT[purpose] + '"');
    if (tools === false) a.push('-c', 'features.shell_tool=false', '-c', 'features.view_image=false', '-c', 'web_search="disabled"');
    for (const image of images) a.push('-i', image.path);
    a.push('-');
    return a;
  }
  const a = ['-p', '--output-format', 'json'];
  if (model) a.push('--model', model);
  a.push(
    '--setting-sources', '',          // 不读 ~/.claude 的 settings、CLAUDE.md、skill
    '--strict-mcp-config',            // 不连任何 MCP
    '--disable-slash-commands',       // 不加载 skill
    // 工具表：默认只留 Read（工具描述是大头）；tools === false → 一个都不给（会中分诊用：09-24 回放实测模型会去 Read 文件，
    // 一次分诊 1,971 输出 token 里正文只有 271 字、耗时 35 s，全是多轮工具调用；分诊只要读 prompt 里的资料，不该翻盘）
    // tools === 'web'：只给会中核查 / 思考档（M6，09-25 Aaron 定联网核查）：多给 WebSearch、WebFetch，其余照旧禁。
    ...(tools === false ? ['--tools', ''] : tools === 'web' ? ['--tools', 'Read,WebSearch,WebFetch', '--allowedTools', 'Read,WebSearch,WebFetch'] : ['--tools', 'Read', '--allowedTools', 'Read']),
    '--disallowedTools', tools === 'web' ? 'Bash,Edit,Write' : 'Bash,Edit,Write,WebFetch,WebSearch',
    '--system-prompt', system || MIN_SYSTEM,
    // 会中外部核实：每次搜索发出前过去敏闸（setting-sources 为空时 --settings 仍生效）。
    ...(tools === 'web' && stage === 'live-expert-check' ? ['--settings', require('./live-search-guard').settings(dataDir)] : []),
  );
  return a;
}

// 返回 { ok, text, reason, usage, model }。reason 是失败原因码，给红条和日志用，不给用户看原文。
// 失败原因码：not_installed / spawn_failed / timeout / proc_error / cli_exit_<码> / cli_is_error / empty / bad_json
// thinking：claude 命令行的思考预算，走 MAX_THINKING_TOKENS 环境变量；0 = 关掉思考（批 5 提速：会中分诊用）。undefined = 不设，沿用命令行默认。
//   实测 2026-09-22（haiku 同一题）：MAX_THINKING_TOKENS=0 → thinking 0 / api 1.2 s；不设 → thinking 107 / api 2.3 s。
//   会中分诊那 2,000 多输出 token 里大半是思考（一次 4 条要点、正文 212 字，output_tokens 2,278），所以 max_tokens 砍不到它。
// ⚠️ 没走 CLAUDE_CODE_MAX_OUTPUT_TOKENS 限输出：实测超限时 claude -p 直接 is_error「exceeded the N output token maximum」，
//   整次调用报废而不是截断——比原来「截断 + 抢救」更糟，而且思考 token 也算在里面。输出上限只对接口那条路（app/llm.js openai）生效。
// Experimental gate transport only. Absent/exactly-off switch keeps the existing
// exec implementation untouched. No UI setting, model routing or tool expansion.
let persistentGate = null;
function retirePersistentGate(entry) {
  clearTimeout(entry.idle);
  entry.retired = true;
  entry.runner.close();
  if (!entry.children.size) fs.rmSync(entry.root, { recursive: true, force: true });
  if (persistentGate === entry) persistentGate = null;
}
function closePersistentGate() {
  if (persistentGate) retirePersistentGate(persistentGate);
}
function gateRunner(bin, { dataDir, model, purpose }) {
  const auth = path.join(os.homedir(), '.codex', 'auth.json');
  // Never start app-server with the user's ordinary home/config as a fallback.
  if (!fs.existsSync(auth)) throw Object.assign(new Error('isolated_auth_missing'), { code: 'isolated_auth_missing' });
  const instructions = fs.readFileSync(path.join(__dirname, 'proactive-gate-instructions.txt'), 'utf8');
  const effort = CODEX_EFFORT[purpose] || 'low';
  const key = JSON.stringify([bin, path.resolve(dataDir), auth, model, effort, instructions]);
  if (persistentGate && persistentGate.key !== key) {
    // Do not kill another in-flight caller or create an unbounded process pool.
    if (persistentGate.users) throw Object.assign(new Error('transport_busy'), { code: 'transport_busy' });
    retirePersistentGate(persistentGate);
  }
  if (!persistentGate) {
    const { JsonlRpcTransport } = require('./jsonl-rpc-transport');
    const { EphemeralTurnRunner } = require('./ephemeral-turn-runner');
    const state = path.join(dataDir, 'state');
    fs.mkdirSync(state, { recursive: true });
    const root = fs.mkdtempSync(path.join(state, 'gate-transport-'));
    fs.chmodSync(root, 0o700);
    const cwd = path.join(root, 'work'); fs.mkdirSync(cwd);
    const entry = { key, root, users: 0, children: new Set(), retired: false, idle: null };
    entry.runner = new EphemeralTurnRunner({ model, cwd, instructions, effort, createTransport() {
      const home = fs.mkdtempSync(path.join(root, 'home-'));
      let child;
      try {
        fs.symlinkSync(auth, path.join(home, 'auth.json'));
        const argv = ['app-server', '--listen', 'stdio://'];
        const config = { project_doc_max_bytes: 0, web_search: 'disabled',
          model_instructions_file: path.join(__dirname, 'proactive-gate-instructions.txt') };
        for (const feature of ['apps','plugins','multi_agent','memories','code_mode_host','shell_tool','view_image']) config['features.' + feature] = false;
        for (const [name, value] of Object.entries(config)) argv.push('-c', name + '=' + JSON.stringify(value));
        child = spawn(bin, argv, { cwd, env: { ...customEnv(), CODEX_HOME: home }, stdio: ['pipe','pipe','pipe'] });
      } catch (error) { fs.rmSync(home, { recursive: true, force: true }); throw error; }
      entry.children.add(child);
      child.once('close', () => {
        entry.children.delete(child);
        fs.rmSync(home, { recursive: true, force: true });
        if (entry.retired && !entry.children.size) fs.rmSync(root, { recursive: true, force: true });
      });
      return new JsonlRpcTransport(child);
    } });
    persistentGate = entry;
  }
  clearTimeout(persistentGate.idle);
  persistentGate.users++;
  return persistentGate;
}
async function askPersistentGate(kind, prompt, options) {
  const { boundedTurnFallback } = require('./bounded-turn-fallback');
  const started = performance.now();
  const timeoutMs = options.timeoutMs ?? 180000;
  let entry;
  const primary = { run(text, limits) {
    entry = gateRunner(findBin(kind), options);
    return entry.runner.run(text, limits);
  } };
  try {
    const full = options.system ? options.system + '\n\n' + prompt : prompt;
    const result = await boundedTurnFallback(primary, async (_, limits) => {
      const answer = await askExecDetailed(kind, prompt, { ...options, ...limits });
      if (!answer.ok) throw Object.assign(new Error(answer.reason), { code: answer.reason });
      return answer;
    }, full, { signal: options.signal, timeoutMs,
      // Reserve half the original deadline for one independent existing exec.
      primaryTimeoutMs: Math.max(1, Math.floor(timeoutMs / 2)) });
    const timing = { ...result.timing, elapsedMs: Math.round(performance.now() - started),
      transport: result.transport, degraded: result.degraded,
      ...(result.fallbackReason ? { fallbackReason: result.fallbackReason } : {}) };
    options.log?.('cli-llm gate transport ' + JSON.stringify(timing));
    // IDs and raw notifications never escape into the model gateway receipt.
    return { ok: true, text: result.text, model: result.model || options.model,
      ...(result.usage ? { usage: result.usage } : {}), timing };
  } catch (error) {
    const reason = options.signal?.aborted ? (options.signal.reason?.name === 'TimeoutError' ? 'timeout' : 'cancelled') : error.code || 'transport_failed';
    return { ok: false, reason, timing: { elapsedMs: Math.round(performance.now() - started) } };
  } finally {
    if (entry && --entry.users === 0 && !entry.retired) {
      // Bounded lifetime without requiring a new application shutdown path.
      entry.idle = setTimeout(() => retirePersistentGate(entry), 30000);
      entry.idle.unref?.();
    }
  }
}
// Live Claude pool: two in-flight requests, one idle prestarted process.
// Each process receives exactly ONE prompt and exits; never reuse conversation
// history across meetings. Admission is immediate, so a hung turn cannot queue
// unrelated live work behind it. The gateway can fall back on transport_busy.
const claudeWarm = new Map();
let claudeActive = 0;
function stopChild(child) {
  try { child.kill('SIGTERM'); } catch {}
  const timer = setTimeout(() => { try { child.kill('SIGKILL'); } catch {} }, 2000);
  timer.unref?.();
  child.once('close', () => clearTimeout(timer));
}
function closeClaudePool() {
  for (const entry of claudeWarm.values()) { clearTimeout(entry.idle); stopChild(entry.child); }
  claudeWarm.clear();
}
function startClaude(bin, argv, opts) {
  const entry = { child: spawn(bin, argv, opts), started: performance.now(), spawned: null, dead: false };
  entry.child.once('spawn', () => { entry.spawned = performance.now(); });
  entry.child.once('error', () => { entry.dead = true; });
  entry.child.once('close', () => { entry.dead = true; });
  // A warm child may exit before anybody attaches request handlers.
  entry.child.stdin.on('error', () => {});
  return entry;
}
function takeClaude(bin, argv, opts) {
  const key = JSON.stringify([bin, argv, opts]);
  let entry = claudeWarm.get(key);
  if (entry) { clearTimeout(entry.idle); claudeWarm.delete(key); }
  const warm = !!entry && !entry.dead;
  if (!warm) entry = startClaude(bin, argv, opts);
  claudeActive++;
  entry.child.once('close', () => { claudeActive--; });
  return { ...entry, warm, replenish() {
    if (claudeWarm.size || claudeActive >= 2) return;
    try {
      const spare = startClaude(bin, argv, opts);
      claudeWarm.set(key, spare);
      const remove = () => { if (claudeWarm.get(key) === spare) claudeWarm.delete(key); clearTimeout(spare.idle); };
      spare.child.once('close', remove);
      spare.child.once('error', remove);
      spare.idle = setTimeout(() => { remove(); stopChild(spare.child); }, 15000);
      spare.idle.unref?.();
    } catch {} // Warming is optional; never turn a completed answer into failure.
  } };
}
function askDetailed(kind, prompt, options = {}) {
  if (process.env.THT_PERSISTENT_GATE === '1' && kind === 'codex' &&
      options.stage === 'proactive-gate' && options.tools === false &&
      options.dataDir && options.model && !(options.images || []).length &&
      Number.isSafeInteger(options.timeoutMs ?? 180000) && (options.timeoutMs ?? 180000) > 0 && findBin(kind)) {
    return askPersistentGate(kind, prompt, options);
  }
  return askExecDetailed(kind, prompt, options);
}
function askExecDetailed(kind, prompt, { dataDir, timeoutMs = 180000, log = () => {}, model = '', system = '', custom = null, thinking, tools, purpose = '', images = [], signal, stage = '' } = {}) {
  if(signal?.aborted)return Promise.resolve({ok:false,reason:signal?.reason?.name==='TimeoutError'?'timeout':'cancelled'});
  const spec = kind === 'custom' ? custom : null;
  if (kind === 'custom' && !spec) return Promise.resolve({ ok: false, reason: 'not_configured' });
  let bin = spec ? spec.bin : findBin(kind);
  if (spec) { try { fs.accessSync(bin, fs.constants.X_OK); } catch (e) { bin = ''; } }
  if (!bin) return Promise.resolve({ ok: false, reason: 'not_installed' });
  const pooled = kind === 'claude' && tools === false && (['live','quick','triage'].includes(purpose) || ['native-live','live-draft','insight-fast','live-signal'].includes(stage));
  if (pooled && claudeActive >= 2) return Promise.resolve({ ok: false, reason: 'transport_busy', timing: { queueMs: 0 } });
  const full = system ? system + '\n\n' + prompt : prompt;
  return new Promise(resolve => {
    const started = performance.now();
    const eventMode = kind === 'codex' && ['native-live','proactive-gate'].includes(stage);
    const events = eventMode ? codexEvents() : null;
    const timing = { spawnMs:null, firstStdoutMs:null, firstStderrMs:null, stdoutBytes:0, stderrBytes:0, queueMs:0, promptChars:String(prompt).length, systemChars:String(system || MIN_SYSTEM).length };
    let done = false, abortHandler, killTimer, cleanupTimer;
    const elapsed = () => Math.round(performance.now() - started);
    const finish = v => { if (!done) { done = true; signal?.removeEventListener('abort',abortHandler); clearTimeout(killTimer);
      const receipt = { ...timing, ...(v.timing || {}), elapsedMs:elapsed(), ...(events ? { events:events.receipt() } : {}) };
      log('cli-llm timing ' + kind + ' ' + JSON.stringify({ ...receipt, result:v.ok?'ok':v.reason }));
      resolve({ ...v, timing:receipt }); } };
    let p, lease;
    const home = kind === 'codex' ? codexHome(dataDir) : '';
    try {
      const argv = spec ? customArgs(spec, { prompt: full, model }) : args(kind, { model, system, tools, purpose, images, stage, dataDir });
      const opts = spec ? { cwd: dataDir || process.cwd(), env: customEnv() }
        : { cwd: dataDir || process.cwd(), env: { ...process.env, CLAUDECODE: '', ...(home ? { CODEX_HOME: home } : {}),
          ...(kind === 'claude' && Number.isFinite(Number(thinking)) && thinking !== undefined && thinking !== null && thinking !== '' ? { MAX_THINKING_TOKENS: String(Math.max(0, Math.floor(Number(thinking)))) } : {}) } };
      if (pooled) {
        lease = takeClaude(bin, argv, opts); p = lease.child;
        timing.prewarmed = lease.warm;
        timing.warmAgeMs = lease.warm ? Math.round(performance.now() - lease.started) : 0;
        if (lease.spawned !== null) timing.spawnMs = 0;
      } else p = spawn(bin, argv, opts);
    }
    catch (e) { log('cli-llm spawn 失败 ' + e.message); return finish({ ok: false, reason: 'spawn_failed' }); }
    p.once('spawn', () => { timing.spawnMs = elapsed(); });
    let out = '', err = '';
    const timer = setTimeout(() => { log('cli-llm 超时 ' + kind); finish({ ok: false, reason: 'timeout' }); stopChild(p); }, timeoutMs);
    // 取消要等子进程真退出再回（最多 250ms），否则调用方以为停了、进程还在跑。
    abortHandler=()=>{ clearTimeout(timer); const r={ok:false,reason:signal?.reason?.name==='TimeoutError'?'timeout':'cancelled'}; const cap=setTimeout(()=>finish(r),250); cap.unref?.(); p.once('close',()=>{clearTimeout(cap);finish(r);}); stopChild(p); };
    signal?.addEventListener('abort',abortHandler,{once:true});
    if(signal?.aborted)abortHandler();
    p.stdout.on('data', d => {
      if(done)return;
      if(timing.firstStdoutMs===null)timing.firstStdoutMs=elapsed(); timing.stdoutBytes+=d.length;
      if(events)events.write(d,elapsed());else out+=d;
      // A read-only classifier is complete at the protocol's turn.completed.
      // Do not keep the meeting waiting for unrelated CLI teardown after it.
      // native-live too: 10-21..23 events.log, 11 of 21 live timeouts had turn.completed at 12-24 s
      // but the CLI exited after the 25 s budget; successful calls waited a further p50 2.5 s / p90 6.7 s.
      if(['proactive-gate','native-live'].includes(stage)&&tools===false&&events&&!signal?.aborted){
        const result=events.result();
        if(result.ok){
          try{JSON.parse(result.text);}catch{return;}
          timing.completionSource='turn.completed';clearTimeout(timer);finish(result);
          // Usually exits naturally; bound cleanup if the CLI hangs after success.
          cleanupTimer=setTimeout(()=>{try{p.kill('SIGTERM');}catch{}killTimer=setTimeout(()=>{try{p.kill('SIGKILL');}catch{}},2000);killTimer.unref?.();},2000);
          cleanupTimer.unref?.();
        }
      }
    });
    p.stderr.on('data', d => { if(timing.firstStderrMs===null)timing.firstStderrMs=elapsed(); timing.stderrBytes+=d.length; err+=d; });
    p.on('error', e => { clearTimeout(timer); log('cli-llm 出错 ' + e.message); finish({ ok: false, reason: 'proc_error' }); });
    p.on('close', (code, exitSignal) => {
      clearTimeout(timer);clearTimeout(cleanupTimer);clearTimeout(killTimer);
      if(done)return; // Timeout already has a receipt; do not relabel it as a CLI exit.

      timing.exitCode = code; timing.exitSignal = exitSignal || null;
      if(events)events.end(elapsed());
      if(signal?.aborted)return finish({ok:false,reason:signal?.reason?.name==='TimeoutError'?'timeout':'cancelled'});
      if(events){
        if(code!==0)return finish({ok:false,reason:'cli_exit_'+code});
        return finish(events.result());
      }
      if (code !== 0) { log('cli-llm 退出码 ' + code + ' ' + err.slice(0, 200)); return finish({ ok: false, reason: 'cli_exit_' + code, stderr: err.slice(0, 200) }); }
      if (!out.trim()) return finish({ ok: false, reason: 'empty' });
      if (spec) return finish(parseCustom(spec, out, log));
      const result = parseOut(kind, out, log);
      finish(result);
      if (result.ok && lease) lease.replenish();
    });
    p.stdin.on('error', () => {}); // EPIPE is reported by the process outcome, never an uncaught event.
    if (done) return;
    // 系统提示词走 --system-prompt，stdin 只放本场材料；codex 和第三家命令行没有这个参数，拼进正文。
    try {
      if (spec && spec.stdin === 'none') p.stdin.end();
      else { p.stdin.write(spec || kind === 'codex' ? (system ? full : prompt) : prompt); p.stdin.end(); }
    } catch (e) {}
  });
}

// Native-live uses the CLI's JSONL lifecycle, never event envelopes/reasoning as an answer.
// Receipts contain only allowlisted event names and timing, never IDs or message text.
function codexEvents() {
  const { StringDecoder } = require('string_decoder');
  const decoder = new StringDecoder('utf8');
  let pending='', text='', completed=false, failed=false, parseErrors=0, tooLarge=false, usage;
  const milestones={};
  const allowed=new Set(['thread.started','turn.started','turn.completed','turn.failed','error','item.started','item.updated','item.completed']);
  const line=(raw,ms)=>{
    if(!raw.trim())return;
    let e;try{e=JSON.parse(raw);}catch{parseErrors++;return;}
    if(!allowed.has(e?.type))return;
    if(milestones[e.type]===undefined)milestones[e.type]=ms;
    if(e.type==='turn.failed')failed=true;
    if(e.type==='error'||e.type==='turn.failed'){
      const message=String(e.message||e.error?.message||'');
      const category=/429|rate.?limit|usage limit|quota/i.test(message)?'rate_limit':/401|403|unauthori|authenticat|token expired/i.test(message)?'authentication':/reconnect|stream disconnect|timed? out|network|connection/i.test(message)?'transport':'other';
      if(milestones[category]===undefined)milestones[category]=ms;
    }
    if(e.type==='turn.completed'){completed=true;if(e.usage)usage={in:Number(e.usage.input_tokens)||0,out:Number(e.usage.output_tokens)||0,cache:Number(e.usage.cached_input_tokens)||0};}
    if(e.type==='item.completed'&&e.item?.type==='agent_message'&&typeof e.item.text==='string'){
      text=e.item.text;
      if(milestones.agentMessage===undefined)milestones.agentMessage=ms;
    }
  };
  const consume=(chunk,ms)=>{
    if(tooLarge)return;
    pending+=chunk;
    let pos;while((pos=pending.indexOf('\n'))>=0){line(pending.slice(0,pos),ms);pending=pending.slice(pos+1);}
    if(pending.length>4*1024*1024){pending='';tooLarge=true;}
  };
  return {
    write(d,ms){consume(decoder.write(d),ms);},
    end(ms){consume(decoder.end(),ms);if(pending){line(pending,ms);pending='';}},
    receipt(){return {...milestones,parseErrors,tooLarge};},
    result(){
      if(failed)return {ok:false,reason:'cli_turn_failed'};
      if(parseErrors||tooLarge)return {ok:false,reason:'bad_event_json'};
      if(!completed)return {ok:false,reason:'incomplete_turn'};
      return text.trim()?{ok:true,text:text.trim(),...(usage?{usage}:{})}:{ok:false,reason:'empty'};
    }
  };
}

// 一次调用的 modelUsage 里可能同时有主模型和它内部借用的小模型（如 Haiku）；
// 记账要记花得最多的那个，取第一个键会把 Sonnet 的调用记成 Haiku。
function mainModel(modelUsage) {
  let best = '', bestCost = -1;
  for (const [name, u] of Object.entries(modelUsage || {})) {
    const cost = Number(u && u.costUSD) || 0;
    const tokens = (Number(u && u.inputTokens) || 0) + (Number(u && u.outputTokens) || 0) + (Number(u && u.cacheReadInputTokens) || 0) + (Number(u && u.cacheCreationInputTokens) || 0);
    const score = cost > 0 ? cost * 1e9 : tokens;
    if (score > bestCost) { best = name; bestCost = score; }
  }
  return best;
}

// 第三家命令行的输出：默认整个 stdout 就是回答；配了 outputJson 就按路径从 JSON 里取正文。
// 用量它不回（各家格式不一样，不猜），账本按字符数估，和其他命令行同一口径。
function parseCustom(spec, out, log) {
  if (!spec.outputJson) { const t = String(out || '').trim(); return t ? { ok: true, text: t } : { ok: false, reason: 'empty' }; }
  let d;
  try { d = JSON.parse(String(out).trim()); }
  catch (e) { log('cli-llm 第三家命令行的输出不是 JSON'); return { ok: false, reason: 'bad_json' }; }
  const t = (digPath(d, spec.outputJson) || '').trim();
  return t ? { ok: true, text: t } : { ok: false, reason: 'empty' };
}

function parseOut(kind, out, log) {
  if (kind === 'codex') { const t = clean(kind, out); return t ? { ok: true, text: t } : { ok: false, reason: 'empty' }; }
  let d;
  try { d = JSON.parse(out); }
  catch (e) {
    // CLI 换了输出格式也不能整条链路哑掉：有正文就降级当纯文本用，并把原因记进日志
    const t = String(out || '').trim();
    log('cli-llm 输出不是 JSON，降级按文本处理');
    return t ? { ok: true, text: t, reason: 'bad_json_fallback' } : { ok: false, reason: 'bad_json' };
  }
  if (d && d.is_error) { log('cli-llm is_error: ' + String(d.result || '').slice(0, 200)); return { ok: false, reason: 'cli_is_error', detail: String(d.result || '').slice(0, 200) }; }
  const text = String((d && d.result) || '').trim();
  if (!text) return { ok: false, reason: 'empty' };
  const u = (d && d.usage) || {};
  return {
    ok: true, text,
    model: mainModel(d && d.modelUsage),
    timing: { ...(Number.isFinite(d.duration_ms) ? { cliDurationMs: d.duration_ms } : {}),
      ...(Number.isFinite(d.duration_api_ms) ? { apiDurationMs: d.duration_api_ms } : {}) },
    usage: {
      in: (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0),
      out: u.output_tokens || 0,
      // 批 5：思考 token 和轮数也记下来——分诊慢在哪（思考 / 多轮工具调用 / 正文）以后账本上能直接看
      thinking: Number((u.output_tokens_details && u.output_tokens_details.thinking_tokens) || 0),
      turns: Number(d.num_turns || 0),
    },
  };
}

// 返回模型回复的纯文本；失败或超时返回 null，调用方自己退回 API 那条路。
function ask(kind, prompt, opts = {}) { return askDetailed(kind, prompt, opts).then(r => (r.ok ? r.text : null)); }

// Notion 中继（app/notion-outbox.js 用）：Citeside没有 NOTION_TOKEN，借本机 Claude 命令行登录的 claude.ai Notion 连接器写。
// 和上面的分析调用不同：要用账号里的连接器，所以不加 --strict-mcp-config；工具只给调用方写死的那几个 Notion 工具，
// 本机文件、命令、联网一律禁。返回 { ok, json, cost, reason }，json = 输出里最后一个 JSON 对象。
function connector(prompt, { allowedTools = [], timeoutMs = 300000, model = 'sonnet', spawnImpl = spawn, strictJson = false } = {}) {
  const bin = findBin('claude');
  if (!bin) return Promise.resolve({ ok: false, reason: 'not_installed' });
  const tools = allowedTools.filter(t => /^mcp__[A-Za-z0-9_-]+__[A-Za-z0-9_-]+$/.test(t));
  if (!tools.length) return Promise.resolve({ ok: false, reason: 'no_tools' });
  const argv = ['-p', '--model', model, '--output-format', 'json', '--allowedTools', tools.join(','),
    '--disallowedTools', 'Bash,Edit,Write,Read,Glob,Grep,WebFetch,WebSearch,NotebookEdit,Task'];
  return new Promise(resolve => {
    let child, out = '', done = false;
    const finish = r => { if (!done) { done = true; clearTimeout(timer); resolve(r); } };
    try { child = spawnImpl(bin, argv, { cwd: os.tmpdir(), stdio: ['pipe', 'pipe', 'pipe'] }); } catch (e) { return resolve({ ok: false, reason: 'spawn_failed' }); }
    const timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch (e) {} finish({ ok: false, reason: 'timeout' }); }, timeoutMs);
    child.stdout.on('data', d => { out += d; });
    child.on('error', () => finish({ ok: false, reason: 'proc_error' }));
    child.on('close', code => {
      if (code !== 0) return finish({ ok: false, reason: 'cli_exit_' + code });
      let res; try { res = JSON.parse(out); } catch (e) { return finish({ ok: false, reason: 'bad_json' }); }
      if (res.is_error) return finish({ ok: false, reason: 'cli_is_error', cost: res.total_cost_usd });
      const all = String(res.result || '').match(/\{[\s\S]*\}/);
      let json = null; try { json = strictJson ? JSON.parse(String(res.result || '').trim()) : all && JSON.parse(all[0]); } catch (e) {}
      finish(json ? { ok: true, json, cost: res.total_cost_usd } : { ok: false, reason: 'empty', cost: res.total_cost_usd });
    });
    child.stdin.end(prompt);
  });
}

// codex exec 会在正文前后带上自己的运行日志，把它剥掉只留模型说的话
function clean(kind, out) {
  let s = String(out || '').trim();
  if (kind === 'codex') {
    s = s.replace(/^warning:[^\n]*\n/gm, '');
    const i = s.lastIndexOf('tokens used');
    if (i > 0) s = s.slice(0, i);
    s = s.replace(/^codex\s*$/gm, '').trim();
  }
  return s.trim() || null;
}

// 一次真实试跑，用来在设置页告诉用户「能用 / 不能用，为什么」
async function probe(kind, dataDir) {
  const bin = findBin(kind);
  if (!bin) return { ok: false, reason: 'not_installed' };
  const r = await askDetailed(kind, '只回这一行，不要别的：READY', { dataDir, timeoutMs: 120000 });
  if (!r.ok) return { ok: false, reason: r.reason || 'not_logged_in_or_failed', bin };
  const t = r.text || '';
  return { ok: /READY/i.test(t), reason: /READY/i.test(t) ? '' : 'unexpected_reply', bin, sample: t.slice(0, 80) };
}

// 卡片对话框（app/card-thread.js）要起的是能用工具的那家命令行；牌子只在这里认，那边不写厂商名。
const agentBin = () => findBin('claude');
// 开箱自动选模型（2026-09-25，Aaron：「一定要保证试用的是能用」）：
// 全新安装时降级链是空的——会中不出卡、会后没有想法，用户还得自己找到设置页点一下。
// 启动时如果一个模型都没配（没选命令行、没 DeepSeek Key、没 LLM_CHAIN），就按 Claude Code → Codex 的顺序
// 真跑一次 probe，第一个跑通（装了且已登录）的写进 LLM_PROVIDER。都不通就什么也不写，首页照旧提示去设置页。
// 已经配过的一律不碰（用户的选择优先）。
async function autopick({ settings, cli = module.exports, log = () => {} }) {
  const c = settings.load();
  if (c.LLM_PROVIDER || c.DEEPSEEK_API_KEY || c.CLOUD_AI === 'off' || (Array.isArray(c.LLM_CHAIN) && c.LLM_CHAIN.length)) return { skipped: 'configured' };
  let found = {};
  try { found = cli.detect() || {}; } catch (e) { return { skipped: 'detect_failed' }; }
  for (const kind of ['claude', 'codex']) {
    if (!found[kind]) continue;
    let r = null;
    try { r = await cli.probe(kind, settings.dataDir); } catch (e) { r = { ok: false }; }
    if (r && r.ok) {
      const now = settings.load();
      if (now.LLM_PROVIDER) return { skipped: 'configured' };   // probe 期间用户自己选了
      now.LLM_PROVIDER = kind; now.LLM_PROVIDER_AUTO = '1'; settings.save(now);   // 标记自动选：用户之后自己填了 DeepSeek Key 就让位，不静默跨供应商 log(`开箱自动选模型：${kind}`);
      return { picked: kind };
    }
  }
  log('开箱自动选模型：本机没有已登录的 Claude Code / Codex');
  return { picked: '' };
}
module.exports = { CODEX_EFFORT, autopick, detect, findBin, connector, codexHome, ask, askDetailed, closePersistentGate, closeClaudePool, probe, mainModel, agentBin, args, codexEvents };
