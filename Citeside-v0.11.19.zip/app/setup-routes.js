'use strict';
// TENANT-SECURITY：设置页口令定长比较，不用 !==（按字节提前退出会泄露比较时长）。
const sameToken=(a,b)=>{const h=x=>require('crypto').createHash('sha256').update(String(x||'')).digest();return !!a&&!!b&&require('crypto').timingSafeEqual(h(a),h(b));};
module.exports=async function(req,res,u,{isLocal,localReason,settings,active,testModel,tokenOk,notionContext={}}){
 const bootstrap=u.pathname==='/seatnote/bootstrap.js',setup=u.pathname==='/setup';
 const notionMcp=u.pathname==='/setup/notion-mcp';
 const detect=u.pathname==='/setup/detect',agent=u.pathname==='/setup/agent';
 if(!notionMcp&&!bootstrap&&!setup&&!detect&&!agent&&u.pathname!=='/setup/test'&&u.pathname!=='/setup/owner'&&u.pathname!=='/setup/startup'&&u.pathname!=='/setup/jev-probe'&&u.pathname!=='/setup/consent'&&u.pathname!=='/setup/diagnostics'&&u.pathname!=='/setup/onboarding'&&u.pathname!=='/setup/my-ai'&&u.pathname!=='/setup/ui-mode'&&u.pathname!=='/setup/local-models'&&u.pathname!=='/setup/privacy'&&u.pathname!=='/setup/privacy/revoke-shares')return false;
 const json=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(j));return true;};
 // 非本机一律 403（跨站页面连 bootstrap.js 都不该拿到）；原因写在 403 的正文里，
 // 首页自己 fetch('/setup') 就能读到并展示，跨站页面因为没有 CORS 读不到。
 // 手机 / 外网页面（funnel 进来）拿不到 bootstrap.js，也就没有 boot 状态，「开始听会」会被
 // asrConfigured/macAsrAvailable 全空卡住（09-22 手机复现）。只读的就绪状态（不含任何密钥）
 // 允许带口令的远端 GET /setup 读到；写操作和 bootstrap.js 仍然只认本机。
 const remoteRead=!isLocal&&setup&&req.method==='GET'&&typeof tokenOk==='function'&&tokenOk(req.headers['x-tht-token']||u.searchParams.get('token'));
 if(!isLocal&&!remoteRead){const why=(typeof localReason==='function'?localReason():'')||'页面来源不是本机';return json(403,{error:'设置只能在本机打开：'+why});}
 let c=settings.load();
 const notionBridge=require('./notion-mcp-bridge');
 const notionCtx={...notionContext,env:c,dataDir:settings.dataDir};
 if(notionMcp&&req.method==='GET')await notionBridge.cliDetect(notionCtx);
 const notionConnection=require('./notion-connection').state(notionCtx);
 const notionAuth=await require('./notion-auth').status(notionCtx);
 if(notionMcp&&req.method==='GET')return json(200,{...notionAuth,candidates:notionBridge.detect(notionCtx),...notionConnection});
 if(notionMcp&&req.method==='POST'){
  if(!sameToken(req.headers['x-tht-token'],c.RELAY_TOKEN))return json(403,{error:'请从本机设置页面操作'});
  if(active())return json(409,{error:'正在录音，请结束本场后再连接 Notion'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>2000)return json(413,{error:'请求过长'});}
  let key;try{key=JSON.parse(body).key;}catch{return json(400,{error:'连接参数无效'});}
  const connectCtx={...notionCtx,env:{...c,NOTION_DISCONNECTED:''}};
  if(typeof key!=='string'||!notionBridge.detect(connectCtx).some(x=>x.key===key))return json(400,{error:'未找到此连接，请刷新并检查原客户端配置'});
  const r=await notionBridge.connect(connectCtx,key);if(r.ok&&c.NOTION_DISCONNECTED==='1'){settings.save({...settings.load(),NOTION_DISCONNECTED:''});}return json(r.ok?200:409,r);
 }
 const macAsr=(()=>{try{return require('./mac-asr').available();}catch(e){return false;}})();
 const asrLocal=c.ASR_PROVIDER==='mac';
 const asrDg=c.ASR_PROVIDER==='deepgram';
 const ownerProfile=typeof settings.dataDir==='string'?require('./owner-tracking').loadOwnerProfile(settings.dataDir):{id:'',displayName:'我'};
 const freeAi=!!(c.FREE_AI_URL&&c.FREE_AI_TOKEN);
 // A8：空白家庭 preset 的 api 只是路线，不代表已填写自己的 key。
 const cloudTrialOn=require('./cloud-inference').trialOn(c);
 let cloudTrial={enabled:cloudTrialOn,status:'disabled',asrReady:false,modelReady:false};
 if(cloudTrialOn&&(setup||bootstrap)){
  // A stored token proves neither entitlement nor service configuration. Reuse
  // the account status endpoint, which returns only safe capability booleans.
  const account=await require('./cloud-account').create({dataDir:settings.dataDir,env:c}).status();
  cloudTrial={enabled:true,status:account.status||'offline',asrReady:account.ok===true&&account.status==='signed_in'&&account.trial?.asrReady===true,modelReady:c.CLOUD_AI!=='off'&&account.ok===true&&account.status==='signed_in'&&account.trial?.modelReady===true};
 }
 const modelConfigured=cloudTrialOn?cloudTrial.modelReady:!!(c.DEEPSEEK_API_KEY||freeAi||(c.LLM_PROVIDER&&!['api','deepseek'].includes(c.LLM_PROVIDER)));
 // 内置 Key（Aaron 给家人 / Roy 打包的 preset）：本机用的模型 Key 就是包里带的那把，设置页不再让人填
 const builtinAi=(()=>{try{const k=settings.readPreset?.().DEEPSEEK_API_KEY;return !!k&&k===c.DEEPSEEK_API_KEY;}catch(e){return false;}})();
 const onboarding=require('./onboarding-state').load(settings.dataDir);
 const notionRelayConnected=notionConnection.relayConnected;
 const asrConfigured=cloudTrialOn?cloudTrial.asrReady:!!(asrLocal||(asrDg&&c.DEEPGRAM_API_KEY)||(c.VOLC_APP_KEY&&c.VOLC_ACCESS_KEY));
 const publicState={uiMode:c.UI_MODE==='lite'?'lite':'full',litePinned:c.LITE_PINNED==='on',liteStealth:c.LITE_STEALTH==='on',silentMemory:c.SILENT_MEMORY!=='off',privacy:require('./privacy-models').publicPrivacyState(c),cloudTrial,edition:(process.env.THT_SELF_EDITION!==undefined?process.env.THT_SELF_EDITION==='1':c.THT_SELF_EDITION==='1')?'self':'standard',providerAuto:c.LLM_PROVIDER_AUTO==='1'||!c.LLM_PROVIDER,onboarding,llmRoutes:require('./llm').routeLabels(c),providers:{matrix:require('./provider-matrix').MATRIX,configured:require('./provider-matrix').inspect(c)},account:(()=>{try{return require('./product-account').publicView(settings.dataDir);}catch(e){return {error:String(e.message||e).slice(0,200)};}})(),secretStore:(()=>{const st=require('./secret-store');let raw={};try{raw=JSON.parse(require('fs').readFileSync(settings.file,'utf8'));}catch(e){}return {...st.status(),plaintext:st.plaintextKeys(raw)};})(),activeIntelligenceMode:c.ACTIVE_INTELLIGENCE_MODE||'legacy',freeAiConfigured:freeAi,builtinAi,ownModelConfigured:!!c.DEEPSEEK_API_KEY,jevConfigured:!!c.JEV_API_KEY,jevEnabled:c.JEV_GATE==='on',jevStatus:(()=>{try{const g=require('./jev-gate');let sl='';try{sl=require('./llm').chainForStage(c,{stage:'semantic-gate'})[0]?.label||'';}catch{}const a=g.availability(c,{semanticLabel:sl});return {status:a.status,path:a.path,reason:a.reason,quality:a.quality||'',checkedAt:a.probe.at||0,ms:a.probe.ms||0};}catch{return null;}})(),agentLabel:'MyAgent',provider:c.LLM_PROVIDER||'',asrProvider:c.ASR_PROVIDER||'',volcConfigured:!!(c.VOLC_APP_KEY&&c.VOLC_ACCESS_KEY),macAsrAvailable:macAsr,deepgramConfigured:!!c.DEEPGRAM_API_KEY,notionRelayConnected,notionConfigured:notionConnection.connected,notionDocumentParent:c.NOTION_DOCUMENT_PARENT||'',googleDrivePaths:c.GOOGLE_DRIVE_PATHS||'',ready:asrConfigured&&modelConfigured,asrConfigured,modelConfigured,base:c.LLM_BASE_URL,model:c.LLM_MODEL,resource:c.VOLC_RESOURCE_ID,archive:c.ARCHIVE_TARGET,ownerProfile,cloudAi:c.CLOUD_AI!=='off',consent:typeof settings.dataDir==='string'?require('./recording-consent').status(settings.dataDir,c):null};
 // X2（2026-09-22）：bootstrap.js 把 RELAY_TOKEN 当全局变量吐出来，原来只靠 isLocal 拦。
 // 漏洞：<script src> 是 no-cors 请求，不带 Origin；同机别的端口（旧中转 3101、deck 3102、任何本地 dev server）
 // 上的页面算 same-site 不算 cross-site，isLocal 全部通过 → 一行 script 标签就把全权口令读进它的 window。
 // 现在：被当成脚本加载（Sec-Fetch-Dest: script）时必须 same-origin。自家页面都是 <script src="bootstrap.js">
 // 相对路径同源加载，Chrome/Safari 给的就是 same-origin，不受影响。不发 Sec-Fetch-* 的老浏览器维持原行为。
 if(bootstrap&&req.method==='GET'){
  const dest=String(req.headers['sec-fetch-dest']||''),site=String(req.headers['sec-fetch-site']||'');
  if(dest==='script'&&site&&site!=='same-origin')return json(403,{error:'bootstrap.js 只能由本机同源页面加载（当前 '+site+'）'});
  res.writeHead(200,{'Content-Type':'application/javascript','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end('window.THT_BOOT='+JSON.stringify({...publicState,relayToken:c.RELAY_TOKEN})+';');return true;}
 // 远端只给就绪状态这几个字段（Codex 09-22 审核意见）：base / model / resource / archive 这类内部配置只留本机
 if(setup&&req.method==='GET'&&remoteRead){const {ready,asrConfigured,asrProvider,macAsrAvailable,modelConfigured,agentLabel}=publicState;return json(200,{ready,asrConfigured,asrProvider,macAsrAvailable,modelConfigured,agentLabel});}
 if(setup&&req.method==='GET')return json(200,publicState);
 const consent=require('./recording-consent');
 if(u.pathname==='/setup/consent'&&req.method==='GET')return json(200,consent.status(settings.dataDir,c));
 if(u.pathname==='/setup/onboarding'&&req.method==='GET')return json(200,onboarding);
 if(u.pathname==='/setup/my-ai'&&req.method==='GET')return json(200,require('./my-ai-brief').load(settings.dataDir));
 if(u.pathname==='/setup/local-models'&&req.method==='GET')return json(200,await require('./privacy-models').scanLocalModels(c));
 if(u.pathname==='/setup/privacy'&&req.method==='GET')return json(200,{ok:true,privacy:require('./privacy-models').publicPrivacyState(c)});
 // SUPPORT-FEEDBACK：只本机能读（上面非本机已 403），内容见 app/diagnostics.js
 if(u.pathname==='/setup/diagnostics'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(require('./diagnostics').build({dataDir:settings.dataDir,env:c,version:require('../package.json').version,macAsrAvailable:macAsr,consent:consent.status(settings.dataDir,c)}));return true;}
 if(u.pathname==='/setup/startup'&&req.method==='GET')return json(200,require('./local-startup').create({dataDir:settings.dataDir}).status());
 // 本机装没装 AI 命令行：装了就不用申请 API Key
 if(detect&&req.method==='GET'){const found=require('./cli-llm').detect();return json(200,{found:Object.keys(found),provider:c.LLM_PROVIDER||''});}
 if(agent&&req.method==='POST'){
  if(active())return json(409,{error:'正在录音，请结束本场后再切换 MyAgent 后台'});
  if(!sameToken(req.headers['x-tht-token'],c.RELAY_TOKEN))return json(403,{error:'请从本机设置页面操作'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>2000)return json(413,{error:'请求过长'});}
  let kind='';try{kind=String(JSON.parse(body||'{}').kind||'');}catch{}
  if(kind==='auto'){
   for(const candidate of ['codex','claude']){const probe=await require('./cli-llm').probe(candidate,settings.dataDir);if(probe.ok){c={...settings.load(),LLM_PROVIDER:candidate,LLM_PROVIDER_AUTO:'1'};settings.save(c);return json(200,{ok:true,provider:candidate});}}
   if(!c.DEEPSEEK_API_KEY&&!(c.FREE_AI_URL&&c.FREE_AI_TOKEN))return json(409,{ok:false,error:'没有可用的 AI，请先在高级中配置'});
   c={...settings.load(),LLM_PROVIDER:'deepseek',LLM_PROVIDER_AUTO:'1'};settings.save(c);return json(200,{ok:true,provider:'deepseek'});
  }
  if(!['codex','claude','deepseek'].includes(kind))return json(400,{ok:false,error:'不认识这个 MyAgent 后台'});
  if(kind==='deepseek'){
   if(!c.DEEPSEEK_API_KEY)return json(409,{ok:false,error:'请先配置 DeepSeek API Key'});
   c.LLM_PROVIDER='deepseek';c.LLM_PROVIDER_AUTO='';settings.save(c);return json(200,{ok:true,agentLabel:'MyAgent',provider:kind});
  }
  const r=await require('./cli-llm').probe(kind,settings.dataDir);
  if(!r.ok)return json(409,{ok:false,error:r.reason==='not_installed'?'这台电脑没有安装该后台':'该后台尚未登录或暂时不可用',reason:r.reason||''});
  c={...settings.load(),LLM_PROVIDER:kind,LLM_PROVIDER_AUTO:''};settings.save(c);return json(200,{ok:true,agentLabel:'MyAgent',provider:kind});
 }
 if(detect&&req.method==='POST'){
  if(active())return json(409,{error:'正在录音，请结束本场后再改设置'});
  if(!sameToken(req.headers['x-tht-token'],c.RELAY_TOKEN))return json(403,{error:'请从本机设置页面操作'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>2000)return json(413,{error:'请求过长'});}
  let kind='';try{kind=String(JSON.parse(body||'{}').kind||'');}catch{}
  if(!['codex','claude'].includes(kind))return json(400,{ok:false,error:'不认识这个工具'});
  const r=await require('./cli-llm').probe(kind,settings.dataDir);
  if(r.ok){c={...settings.load(),LLM_PROVIDER:kind,LLM_PROVIDER_AUTO:''};settings.save(c);}
  const msg=r.ok?({codex:'Codex 已就绪，用的是你 ChatGPT 账号的额度，不用另外付钱。',claude:'Claude Code 已就绪，用的是你的 Claude 订阅，不用另外付钱。'})[kind]
    :(r.reason==='not_installed'?'没在这台电脑上找到它。':({codex:'找到了 Codex，但还没登录。打开「终端」，输入 codex 回车，按提示用 ChatGPT 账号登录，再回来点这里。',claude:'找到了 Claude Code，但还没登录。打开「终端」，输入 claude 回车，按提示登录 Claude 账号，再回来点这里。'})[kind]);
  return json(r.ok?200:200,{ok:!!r.ok,message:msg,reason:r.reason||''});
 }
 if(req.method!=='POST'||req.headers['content-type']!=='application/json'||!sameToken(req.headers['x-tht-token'],c.RELAY_TOKEN))return json(403,{error:'请从本机设置页面操作'});
 // JEV 实测（JEV-AVAILABILITY）：发两句固定合成句，回实际可用性；不带会议内容
 if(u.pathname==='/setup/jev-probe'){
  const g=require('./jev-gate');await g.probe({env:c});let sl='';try{sl=require('./llm').chainForStage(c,{stage:'semantic-gate'})[0]?.label||'';}catch{}
  const a=g.availability(c,{semanticLabel:sl});return json(200,{status:a.status,path:a.path,reason:a.reason,quality:a.quality||'',checkedAt:a.probe.at||0,ms:a.probe.ms||0});
 }
 // 首次引导进度：录音中也能存（只是一份进度，不碰转写配置）
 if(u.pathname==='/setup/onboarding'){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>500)return json(413,{error:'请求过长'});}
  try{return json(200,require('./onboarding-state').patch(settings.dataDir,JSON.parse(body||'{}')));}catch{return json(400,{error:'引导进度格式不正确'});}
 }
 // 界面模式、钉住、隐身和静默记忆：录音中也能改。上面已要求本机、JSON 和口令，这里不再被 active() 拦住。
 if(u.pathname==='/setup/ui-mode'){
  let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>500)return json(413,{error:'请求过长'});}
  let j;try{j=JSON.parse(body||'{}');}catch{return json(400,{error:'界面模式格式不正确'});}
  if(!j||typeof j!=='object'||Array.isArray(j))return json(400,{error:'界面模式格式不正确'});
  if(Object.keys(j).some(k=>!['uiMode','litePinned','liteStealth','silentMemory'].includes(k)))return json(400,{error:'界面模式格式不正确'});
  const onOff=v=>{if(typeof v==='boolean'||v==='on'||v==='off')return v;throw Error('bad flag');};
  try{
   c={...settings.load()};
   if(j.uiMode!==undefined){if(j.uiMode!=='lite'&&j.uiMode!=='full')throw Error('bad ui mode');c.UI_MODE=j.uiMode;}
   if(j.litePinned!==undefined){onOff(j.litePinned);c.LITE_PINNED=(j.litePinned===true||j.litePinned==='on')?'on':'off';}
   if(j.liteStealth!==undefined){onOff(j.liteStealth);c.LITE_STEALTH=(j.liteStealth===true||j.liteStealth==='on')?'on':'off';}
   if(j.silentMemory!==undefined){onOff(j.silentMemory);c.SILENT_MEMORY=(j.silentMemory===false||j.silentMemory==='off')?'off':'on';}
  }catch{return json(400,{error:'界面模式格式不正确'});}
  settings.save(c);
  return json(200,{ok:true,uiMode:c.UI_MODE==='lite'?'lite':'full',litePinned:c.LITE_PINNED==='on',liteStealth:c.LITE_STEALTH==='on',silentMemory:c.SILENT_MEMORY!=='off'});
 }
 // 隐私与模型 4 件套（Max）：录音中也能开关禁止分享锁与单场私密会议。
 if(u.pathname==='/setup/privacy'){
  let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>2000)return json(413,{error:'请求过长'});}
  try{
   const pm=require('./privacy-models');
   const next=pm.applyPrivacyPatch(settings.load(),JSON.parse(body||'{}'));
   settings.save(next);
   return json(200,{ok:true,privacy:pm.publicPrivacyState(next),silentMemory:next.SILENT_MEMORY!=='off'});
  }catch(e){return json(400,{error:e.message||'隐私配置格式不正确'});}
 }
 if(u.pathname==='/setup/privacy/revoke-shares'){
  const pm=require('./privacy-models');
  const cloud=require('./cloud-account').create({dataDir:settings.dataDir,env:settings.load()});
  const result=await pm.revokeAllShares(cloud);
  return json(result.ok?200:(result.code==='unauthorized'?401:502),result);
 }
 // 「连接你的 AI」：存本机；{text} 合并新贴的内容，{deleteId} 删一条（「我读了什么」里的删除）
 if(u.pathname==='/setup/my-ai'){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>25000)return json(413,{error:'内容太长，删掉一些再贴'});}
  try{const j=JSON.parse(body||'{}'),b=require('./my-ai-brief');
   if(typeof j.deleteId==='string')return json(200,b.remove(settings.dataDir,j.deleteId));
   if(typeof j.text!=='string')throw Error('invalid');
   return json(200,b.save(settings.dataDir,j.text));
  }catch{return json(400,{error:'内容格式不正确'});}
 }
 if(u.pathname==='/setup/owner'){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>1000)return json(413,{error:'称呼过长'});}
  try { const j=JSON.parse(body), owner=require('./owner-tracking');
   if(Object.keys(j).some(k=>!['displayName','names','roleKeywords','skip'].includes(k))||('skip' in j&&j.skip!==true)||('skip' in j&&('displayName' in j||'names' in j||'roleKeywords' in j)))throw Error('invalid owner');
   const profile=j.skip===true?owner.skipOwnerName(settings.dataDir):owner.saveOwnerName(settings.dataDir,typeof j.displayName==='string'?j.displayName:ownerProfile.displayName,j.names,j.roleKeywords);
   return json(200,{ownerProfile:profile,identity:require('./my-ai-brief').extractIdentity(settings.dataDir)});
  }catch{return json(400,{error:'称呼格式不正确'});}
 }
 if(active())return json(409,{error:'正在录音，请结束本场后再改设置'});
 if(u.pathname==='/setup/consent'){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>1000)return json(413,{error:'请求过长'});}
  try{const j=JSON.parse(body||'{}');
   if(j.localOnly===true&&Object.keys(j).length===1){
    if(!require('./mac-asr').available())return json(409,{error:'这台电脑用不了本机转写 / On-device transcription is unavailable'});
    Object.assign(c,consent.localOnlyPatch());settings.save(c);
    const s=consent.status(settings.dataDir,c);return json(200,consent.accept(settings.dataDir,c,s.fingerprint));
   }
   if(j.accept!==true||j.participantsInformed!==true||typeof j.fingerprint!=='string'||Object.keys(j).length!==3)throw Error('invalid consent');
   return json(200,consent.accept(settings.dataDir,c,j.fingerprint));
  }catch(e){return json(e.status||400,{error:e.status?e.message:'确认格式不正确'});}
 }
 if(u.pathname==='/setup/startup'){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>1000)return json(413,{error:'请求过长'});}
  try{const j=JSON.parse(body),startup=require('./local-startup').create({dataDir:settings.dataDir});
   if(j.action==='desktop'&&Object.keys(j).length===1)return json(200,startup.desktop());
   if(j.action==='login'&&Object.keys(j).length===2&&typeof j.enabled==='boolean')return json(200,startup.set(j.enabled));
   throw Error('invalid startup action');
  }catch(e){return json(400,{error:e.message});}
 }
 if(u.pathname==='/setup/test'){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>12000)return json(413,{error:'配置过长'});}
  let draft={};try{draft=JSON.parse(body||'{}');const allowed=['DEEPSEEK_API_KEY','LLM_BASE_URL','LLM_MODEL'];for(const k of Object.keys(draft))if(!allowed.includes(k)||typeof draft[k]!=='string'||draft[k].length>4000||/[\r\n]/.test(draft[k]))throw Error('bad field');if(draft.LLM_BASE_URL){const base=new URL(draft.LLM_BASE_URL);if(base.protocol!=='https:'||base.username||base.password||base.search||base.hash)throw Error('bad url');}}catch{return json(400,{error:'测试配置格式不正确'});}
  const result=await testModel(draft);return json(result?200:502,{ok:!!result,message:result?'模型已连通。语音服务请用30秒试录验证。':'模型未连通，请检查API Key、余额、模型名与网络。'});
 }
 let body='';for await(const chunk of req){body+=chunk;if(body.length>12000)return json(413,{error:'配置过长'});}
 try{const j=JSON.parse(body);
 c={...settings.load()}; // Validate a detached candidate before committing any field.
 if(typeof j.ASR_PROVIDER==='string'){const v=j.ASR_PROVIDER.trim();if(!['','volc','mac','deepgram'].includes(v))throw Error('转写方式取值不对');c.ASR_PROVIDER=v;}
 for(const k of Object.keys(settings.defaults)){if(k==='ASR_PROVIDER')continue;if(j[k]===undefined||['ARCHIVE_TARGET','THT_ARCHIVE_OWNER_ID','LLM_PROVIDER','LLM_PROVIDER_AUTO','FREE_AI_URL','FREE_AI_TOKEN'].includes(k))continue;if(typeof j[k]!=='string'||j[k].length>4000||/[\r\n]/.test(j[k]))throw Error('字段格式不正确');if(['VOLC_APP_KEY','VOLC_ACCESS_KEY','DEEPSEEK_API_KEY','DEEPGRAM_API_KEY','NOTION_TOKEN','JEV_API_KEY'].includes(k)&&!j[k])continue;c[k]=j[k].trim();}
 if(j.NOTION_TOKEN)c.NOTION_DISCONNECTED='';
 // 自动选中的本机命令行只是开箱兜底；用户自己填了 DeepSeek Key，就用他填的，不再先走命令行（AI-DEFAULT-DEEPSEEK：无静默跨供应商）
 if(j.DEEPSEEK_API_KEY&&c.LLM_PROVIDER_AUTO==='1'){c.LLM_PROVIDER='deepseek';c.LLM_PROVIDER_AUTO='';}
 if(j.CLOUD_AI!==undefined&&!['on','off'].includes(c.CLOUD_AI))throw Error('invalid cloud ai');
 if(j.ACTIVE_INTELLIGENCE_MODE!==undefined&&!['rapid','legacy'].includes(c.ACTIVE_INTELLIGENCE_MODE))throw Error('invalid live mode');
 if(j.LLM_QUICK_ROUTE!==undefined&&!['auto','primary','api'].includes(c.LLM_QUICK_ROUTE))throw Error('invalid quick route');
 if(j.LLM_CHAT_EFFORT!==undefined&&!['','none','minimal','low','medium','high','xhigh','max','ultra'].includes(c.LLM_CHAT_EFFORT))throw Error('invalid chat effort');
 if(j.JEV_GATE!==undefined&&!['on','off'].includes(c.JEV_GATE))throw Error('invalid gate');
 if(j.MEETING_TIER!==undefined&&!['auto','light','deep'].includes(c.MEETING_TIER))throw Error('invalid meeting tier');
 if(j.UI_MODE!==undefined&&!['lite','full'].includes(c.UI_MODE))throw Error('invalid ui mode');
 if(j.LITE_PINNED!==undefined&&!['on','off'].includes(c.LITE_PINNED))throw Error('invalid lite pinned');
 if(j.LITE_STEALTH!==undefined&&!['on','off'].includes(c.LITE_STEALTH))throw Error('invalid lite stealth');
 if(j.SILENT_MEMORY!==undefined&&!['on','off'].includes(c.SILENT_MEMORY))throw Error('invalid silent memory');
 const base=new URL(c.LLM_BASE_URL);if(base.protocol!=='https:'||base.username||base.password||base.search||base.hash)throw Error('模型地址须为不含密钥的 HTTPS 地址');
 if(j.ownerDisplayName!==undefined)require('./owner-tracking').saveOwnerName(settings.dataDir,j.ownerDisplayName,j.ownerNames);
 settings.save(c);
 // 选了本机转写就先把那个 .app 拉起来一次：系统的语音识别授权弹窗只认 GUI 会话，
 // 不先弹一次，用户开会时会以为坏了。它读不到 stdin 会自己退出。
 if(c.ASR_PROVIDER==='mac'){ try{ const {APP}=require('./mac-asr'); require('child_process').execFile('/usr/bin/open',['-a',APP,'--args','0','probe','zh-CN'],()=>{}); }catch(e){} }
 return json(200,{ok:true});}catch{return json(400,{error:'配置格式不正确，请检查模型地址与字段'});}
};
