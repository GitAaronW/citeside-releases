'use strict';
// 会中断网恢复（火山流式识别）。server.js 原有「断线期间排队、重连后 4 倍速回灌」只管断线之后进来的音频；
// 故障注入（scripts/fault-inject-offline.js）测出两处缺口：
//   1. 断网那一刻已经发给火山、但还没等到 final 的那段音频（正在说的那句，以及 TCP 黑洞时缓冲区里的几十秒）
//      随旧连接一起没了 —— 每次断网至少丢一句，黑洞两分钟丢一分半钟。
//   2. 补回来的句子 at 用的是「结果到达时刻」，断线期间说的话被记到重连之后。
// 这里记一本账：每条火山连接（按 X-Api-Connect-Id）发出去的每块音频、它在流里的字节偏移、采集时刻。
// final 的 end_time 到了，这之前的音频算确认；连接死掉（close 事件之后不会再有结果）时，
// 没确认的那段原样退回队列头，在新连接上重识别。确认点之前的不重发，所以不会重复；
// 确认点之后的旧连接不会再出结果，所以重发也不会重复。
//
// 队列里的 Buffer 用不可枚举属性带上采集时刻，切块时按字节推算剩余部分的时刻。
const BYTES_PER_MS = 32;   // 16 kHz、16 bit、单声道

const AT = Symbol.for('tht.captureAt');
function stamp(buf, wallMs) { Object.defineProperty(buf, AT, { value: wallMs, enumerable: false, configurable: true }); return buf; }
function stampOf(buf) { return buf && typeof buf[AT] === 'number' ? buf[AT] : null; }
function sliceFrom(buf, n) { const at = stampOf(buf), rest = buf.subarray(n); return at === null ? rest : stamp(rest, at + n / BYTES_PER_MS); }
function sliceTo(buf, n) { const at = stampOf(buf), head = buf.subarray(0, n); return at === null ? head : stamp(head, at); }

function createLedger({ maxBytes = 32000 * 600 } = {}) {
  const streams = new Map();   // streamId -> { sentBytes, confirmedBytes, entries: [{off,len,buf,at}], heldBytes }
  function get(id) { let s = streams.get(id); if (!s) streams.set(id, s = { sentBytes: 0, confirmedBytes: 0, entries: [], heldBytes: 0 }); return s; }
  function trim(s) {
    while (s.entries.length && s.entries[0].off + s.entries[0].len <= s.confirmedBytes) s.heldBytes -= s.entries.shift().len;
    // 一直没有 final（长时间静音）也不能无限攒：超过上限的最旧部分放弃重发权
    while (s.heldBytes > maxBytes && s.entries.length > 1) { const e = s.entries.shift(); s.heldBytes -= e.len; s.confirmedBytes = Math.max(s.confirmedBytes, e.off + e.len); }
  }
  return {
    sent(id, buf, wallMs) {
      if (!id || !buf || !buf.length) return;
      const s = get(id), at = stampOf(buf) ?? wallMs ?? Date.now();
      s.entries.push({ off: s.sentBytes, len: buf.length, buf, at }); s.sentBytes += buf.length; s.heldBytes += buf.length; trim(s);
    },
    // 火山 end_time 是流内毫秒；definite 之前的音频不会再出结果
    confirm(id, endMs) {
      const s = streams.get(id); if (!s || !Number.isFinite(endMs) || endMs < 0) return;
      const b = Math.min(s.sentBytes, Math.round(endMs * BYTES_PER_MS)); if (b <= s.confirmedBytes) return;
      s.confirmedBytes = b; trim(s);
    },
    // 流内毫秒 -> 采集时刻（ms since epoch）。查不到返回 null，调用方退回 Date.now()
    wallAt(id, ms) {
      const s = streams.get(id); if (!s || !Number.isFinite(ms) || ms < 0) return null;
      const b = Math.round(ms * BYTES_PER_MS);
      for (const e of s.entries) if (b >= e.off && b <= e.off + e.len) return e.at + (b - e.off) / BYTES_PER_MS;
      return null;
    },
    // 连接已死：取出没确认的音频（按发送顺序、带采集时刻），这本账作废
    release(id) {
      const s = streams.get(id); streams.delete(id); if (!s) return [];
      const out = [];
      for (const e of s.entries) {
        const skip = Math.max(0, s.confirmedBytes - e.off);
        if (skip >= e.len) continue;
        out.push(stamp(Buffer.from(skip ? e.buf.subarray(skip) : e.buf), e.at + skip / BYTES_PER_MS));
      }
      return out;
    },
    pendingBytes(id) { const s = streams.get(id); return s ? s.sentBytes - s.confirmedBytes : 0; },
    forget(id) { streams.delete(id); },
  };
}

// TCP 黑洞（Wi-Fi 掉线但连接没被重置）时 socket 一直 OPEN，现有看门狗要等 90 秒无结果才断。
// 心跳：每 interval 发 ping；只有这条连接回过至少一次 pong 才启用超时判断——上游不回 pong 也不会被误杀。
function heartbeat(socket, { onDead, interval = 5000, timeout = 15000, now = Date.now, setIntervalFn = setInterval, clearIntervalFn = clearInterval } = {}) {
  let lastPong = 0, dead = false;
  const onPong = () => { lastPong = now(); };
  socket.on('pong', onPong);
  const timer = setIntervalFn(() => {
    if (dead || socket.readyState !== 1) return;
    if (lastPong && now() - lastPong > timeout) { dead = true; stop(); onDead && onDead(); return; }
    try { socket.ping(); } catch (e) {}
  }, interval);
  if (timer && timer.unref) timer.unref();
  function stop() { clearIntervalFn(timer); try { socket.off ? socket.off('pong', onPong) : socket.removeListener('pong', onPong); } catch (e) {} }
  return { stop };
}

module.exports = { BYTES_PER_MS, stamp, stampOf, sliceFrom, sliceTo, createLedger, heartbeat };
