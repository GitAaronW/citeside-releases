'use strict';
// 核心目标的四个数（《citeside开发需求总纲》「核心目标与四个指标」，Aaron 2026-10-23 定）：
//   M1 有用率   = Aaron 用上的卡 ÷ citeside出的卡（看法卡 factchecks + 原生主动卡 nativeInsights.history）
//                 用上 = 评 adopt / useful、按钮执行完、收录进会议文档；评 useless 记负反馈
//                 M1-IMPLICIT-SIGNAL（10-23）：卡上「采纳 / 复制」各点一次就算用上，「关掉」算负反馈（账本 state/card-signals.jsonl，app/card-signals.js）
//   M2 漏报     = 会中 Aaron 自己向助手提问 / 起草（meeting-board-jobs 里 actor === 'owner' 的 chat / draft，时间落在本场内）
//                 ——这是候选漏报，上限口径，不全是citeside该提的。actor 'auto'（会中管线自动起草等）不算，数进 autoExcluded。
//                 draftBinding.manual 是「项目是手动选的」，跟谁发起无关，不看它（BOARD-JOBS-ACTOR 3a7a10c）。
//                 3a7a10c 之前的旧任务没有 actor、或 actor 'unknown'：数进 asksUnverified，只有它们没有 owner 行时 value 写 null
//   M3 重复犯错 = Aaron 纠正过的同一处（转写里 原词→改词）在后面的会里又被他纠正一次
//   view-feedback 的 kind 是被评那张 AI 卡的类型（fix / add / link…），不是他的动作：整行只当 M1 的评分用
//   M4 会后搬运 = 会后处理台的卡：发出前改过草稿几张、发出几张、没发出几张（其中改过草稿的另列）；手动转发 = 会后 72 小时他自己在 Slack / Notion 敲的、跟这场会有关的条数，对得上卡（manualForwardCards）和对不上卡（manualUncarded，同时是 M2 漏报候选）都算（Aaron 2026-10-24 口径；app/manual-forwards.js）；这场会没扫过就记 null
// 规矩：只读现有账本和场次文件，不另存计数器；信号没接上的写 null 并在 gaps 里说明，不能写成 0。
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const norm = s => String(s || '').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu, '');
const ms = v => typeof v === 'number' ? v : (Date.parse(v || '') || 0);
const readJson = (file, dflt) => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return dflt; } };
const readJsonl = file => { let t = ''; try { t = fs.readFileSync(file, 'utf8'); } catch (e) { return []; } const out = []; for (const l of t.split('\n')) { if (!l) continue; try { out.push(JSON.parse(l)); } catch (e) {} } return out; };
// 和 app/actions.js 的 keyOf 同一算法：一场会一份 <key>.actions.json
const actionsKey = id => crypto.createHash('sha256').update(String(id)).digest('hex').slice(0, 16);

// 原文→改后：去掉相同的头尾，剩下中间那段就是「原词→改词」。改动太长（整句重写）只算一次纠正，不参与重复判断。
function correctionPair(before, after) {
  const a = String(before || ''), b = String(after || '');
  if (!a || !b || a === b) return null;
  let i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++;
  let j = 0; while (j < a.length - i && j < b.length - i && a[a.length - 1 - j] === b[b.length - 1 - j]) j++;
  // 英文按整词取：Sean→Shaw 不能取成 ean→haw
  const W = /[A-Za-z0-9]/;
  while (i > 0 && W.test(a[i - 1])) i--;
  while (j > 0 && W.test(a[a.length - j]) && W.test(b[b.length - j])) j--;
  const wrong = a.slice(i, a.length - j).trim(), right = b.slice(i, b.length - j).trim();
  // 一个词 / 一个短语才参与重复判断；夹着空格标点的是整段重写或一次改多处
  const term = s => s && s.length <= 20 && !/[\s\p{P}]/u.test(s);
  const key = term(wrong) && term(right) ? norm(wrong) + '→' + norm(right) : '';
  return { wrong, right, key };
}

// 本场 Aaron 亲手做的纠正：转写段落改字（originalText 只由手改 / 一句话纠错写入，自动纠名写的是 rawText）、
// 会中确认里选「更正」的。
function corrections(sess) {
  const out = [];
  for (const r of Array.isArray(sess && sess.transcript) ? sess.transcript : []) {
    if (!r || typeof r !== 'object' || typeof r.originalText !== 'string') continue;
    const p = correctionPair(r.originalText, r.text);
    if (p) out.push({ source: 'transcript', ...p });
  }
  for (const c of Array.isArray(sess && sess.liveConfirmations) ? sess.liveConfirmations : []) if (c && c.responseAction === 'correct') out.push({ source: 'confirmation', wrong: '', right: String(c.response || '').slice(0, 80), key: '' });
  return out;
}

function cardsM1(sess, viewFeedback, collected, signals = []) {
  const byKey = new Map();
  for (const c of Array.isArray(sess && sess.factchecks) ? sess.factchecks : []) {
    if (!c || typeof c !== 'object') continue;
    const key = c.id ? 'fc:' + c.id : 'claim:' + String(c.claim || '');
    const prev = byKey.get(key) || { used: false, rejected: false };
    prev.used = prev.used || c.rating === 'adopt' || c.rating === 'useful' || !!(c.actionState && c.actionState.status === 'done');
    prev.rejected = prev.rejected || c.rating === 'useless';
    byKey.set(key, prev);
  }
  const ni = sess && sess.nativeInsights;
  for (const h of ni && Array.isArray(ni.history) ? ni.history : []) {
    if (!h || h.superseded || !h.key) continue;
    if (!byKey.has('ni:' + h.key)) byKey.set('ni:' + h.key, { used: false, rejected: false });
  }
  for (const f of viewFeedback) {
    if (!f) continue;
    const k = byKey.get('fc:' + f.id); if (!k) continue;
    if (f.rating === 'adopt' || f.rating === 'useful') k.used = true; else if (f.rating === 'useless') k.rejected = true;
  }
  // 点了动作的卡一定展示过：对不上已知卡（会议页候选）就按它自己的 id 补一张，保证 used ≤ shown
  const counts = { adopt: 0, copy: 0, dismiss: 0 };
  for (const g of signals) {
    if (!g || !(g.action in counts)) continue;
    counts[g.action]++;
    const id = String(g.cardId || ''); if (!id) continue;
    const key = byKey.has('fc:' + id) ? 'fc:' + id : g.key && byKey.has('ni:' + g.key) ? 'ni:' + g.key : byKey.has('ni:' + id) ? 'ni:' + id : 'sig:' + id;
    const k = byKey.get(key) || { used: false, rejected: false }; byKey.set(key, k);
    if (g.action === 'dismiss') k.rejected = true; else k.used = true;
  }
  const vals = [...byKey.values()];
  const shown = vals.length, used = vals.filter(v => v.used).length + collected, rejected = vals.filter(v => v.rejected && !v.used).length;
  return { shown, used, rejected, collected, signals: counts, value: shown ? +(Math.min(used, shown) / shown).toFixed(3) : null, feedbackCoverage: shown ? +((Math.min(used, shown) + rejected) / shown).toFixed(3) : null };
}

const manualAsk = j => j.action === 'chat' || j.action === 'draft';
function missesM2(sess, boardJobs) {
  const id = String(sess && sess.id || ''), start = ms(sess && sess.start), end = ms(sess && sess.end) || start;
  const inMeeting = boardJobs.filter(j => j && (j.meetingId === id || j.contextId === id) && start && ms(j.created) >= start && ms(j.created) <= end);
  const cand = inMeeting.filter(manualAsk);
  const asks = cand.filter(j => j.actor === 'owner').length, autoExcluded = cand.filter(j => j.actor === 'auto').length, asksUnverified = cand.length - asks - autoExcluded;
  return { asks, asksUnverified, autoExcluded, value: asks || !asksUnverified ? asks : null };
}

function carryM4(actionsDoc) {
  const cards = actionsDoc && Array.isArray(actionsDoc.cards) ? actionsDoc.cards : null;
  if (!cards) return { cards: 0, sent: 0, editedBeforeSend: 0, dismissed: 0, notSent: 0, editedNotSent: 0, manualForwards: null, manualForwardCards: null, manualUncarded: null, manualScanned: false, value: null };
  // 扫过 = 扫描跑过且至少一边读得到。两边都没授权时什么都没量到，记 null，不能记 0 冒充「没搬运」
  const ms = actionsDoc.manualScan || null;
  const scanned = !!(ms && ms.at && ((ms.slack && ms.slack.ok) || (ms.notion && ms.notion.ok)));
  const manualForwardCards = scanned ? cards.filter(c => c && c.manualForward).length : null;   // 他已经自己搬过一次就是一次，这张卡后来从处理台发出也不抹掉（Codex r2）
  const manualUncarded = scanned ? (Array.isArray(actionsDoc.manualScan.uncarded) ? actionsDoc.manualScan.uncarded.length : 0) : null;
  const manualForwards = scanned ? manualForwardCards + manualUncarded : null;
  const sent = cards.filter(c => c.state === 'sent'), open = cards.filter(c => c.state !== 'sent' && c.state !== 'dismissed');
  // cards = sent + dismissed + notSent；notSent 里改过草稿还没发的另列 editedNotSent
  return { cards: cards.length, sent: sent.length, editedBeforeSend: sent.filter(c => c.draftEditedAt).length, dismissed: cards.filter(c => c.state === 'dismissed').length, notSent: open.length, editedNotSent: open.filter(c => c.draftEditedAt).length, manualForwards, manualForwardCards, manualUncarded, manualScanned: scanned, value: sent.filter(c => c.draftEditedAt).length };
}

// 单场：ctx = { boardJobs, viewFeedback（本场的行）, collected（收录回执数）, actionsDoc }
function forSession(sess, ctx = {}) {
  const vf = Array.isArray(ctx.viewFeedback) ? ctx.viewFeedback : [];
  return {
    m1: cardsM1(sess, vf, ctx.collected || 0, Array.isArray(ctx.cardSignals) ? ctx.cardSignals : []),
    m2: missesM2(sess, Array.isArray(ctx.boardJobs) ? ctx.boardJobs : []),
    corrections: corrections(sess),
    m4: carryM4(ctx.actionsDoc || null),
  };
}

// 收录回执在 state/mother-documents/*.json 的 collections 里，键是「会议 id:模块 id」；inserted 且没撤销才算
function collectedByMeeting(dataDir) {
  const out = new Map(), dir = path.join(dataDir, 'state', 'mother-documents');
  let names = []; try { names = fs.readdirSync(dir).filter(n => n.endsWith('.json')); } catch (e) {}
  for (const n of names) {
    const d = readJson(path.join(dir, n), null);
    for (const [k, v] of Object.entries(d && d.collections || {})) {
      if (!v || !v.inserted || v.undone) continue;
      const meetingId = k.split(':')[0]; out.set(meetingId, (out.get(meetingId) || 0) + 1);
    }
  }
  return out;
}

function loadContext(dataDir) {
  const jobsRaw = readJson(path.join(dataDir, 'meeting-board-jobs.json'), []);
  const boardJobs = Array.isArray(jobsRaw) ? jobsRaw : Array.isArray(jobsRaw && jobsRaw.items) ? jobsRaw.items : [];
  const vfBySession = new Map();
  for (const f of readJsonl(path.join(dataDir, 'state', 'view-feedback.jsonl'))) { const k = String(f.sessionId || ''); if (!vfBySession.has(k)) vfBySession.set(k, []); vfBySession.get(k).push(f); }
  return { boardJobs, vfBySession, signals: require('./card-signals').bySession(dataDir), collected: collectedByMeeting(dataDir), pipelineDir: path.join(dataDir, 'state', 'meeting-pipeline') };
}

function ctxFor(base, sess) {
  const id = String(sess && sess.id || '');
  const meetingKey = id.replace(/^sess-/, '');
  return {
    boardJobs: base.boardJobs, viewFeedback: base.vfBySession.get(id) || [],
    cardSignals: [...((base.signals && base.signals.get(id)) || []), ...(meetingKey !== id ? (base.signals && base.signals.get(meetingKey)) || [] : [])],
    collected: (base.collected.get(id) || 0) + (meetingKey !== id ? base.collected.get(meetingKey) || 0 : 0),
    actionsDoc: readJson(path.join(base.pipelineDir, actionsKey(id) + '.actions.json'), null),
  };
}

// 全量：按开始时间排序，M3 跨场判断——同一个「原词→改词」在更早的会里纠正过，这次又纠正 = 重复犯错一次
function forAll(dataDir, opts = {}) {
  const base = loadContext(dataDir), since = ms(opts.since);
  const dir = path.join(dataDir, 'pending');
  let names = []; try { names = fs.readdirSync(dir).filter(n => n.endsWith('.json')); } catch (e) {}
  // 同一场会可能有两份文件（offline-* 与 sess-* 同一个 id）：按 id 只留转写最长的那份，免得同一场自己跟自己比出「重复犯错」
  const byId = new Map();
  for (const s of names.map(n => readJson(path.join(dir, n), null))) {
    if (!s || !s.id || (since && ms(s.start) < since)) continue;
    const prev = byId.get(s.id), len = x => Array.isArray(x.transcript) ? x.transcript.length : 0;
    if (!prev || len(s) > len(prev)) byId.set(s.id, s);
  }
  const sessions = [...byId.values()].sort((a, b) => ms(a.start) - ms(b.start));
  const seen = new Map(), rows = [];
  for (const s of sessions) {
    const r = forSession(s, ctxFor(base, s));
    let repeats = 0;
    const keys = new Set(r.corrections.map(c => c.key).filter(Boolean));
    for (const k of keys) { if (seen.has(k)) repeats++; else seen.set(k, s.id); }
    rows.push({ id: s.id, title: s.title || '', start: s.start || '', m1: r.m1, m2: r.m2, m3: { corrections: r.corrections.length, repeats, value: repeats, examples: r.corrections.filter(c => c.key).slice(0, 3).map(c => c.wrong + '→' + c.right) }, m4: r.m4 });
  }
  const sum = (f) => rows.reduce((a, r) => a + (f(r) || 0), 0);
  const shown = sum(r => r.m1.shown), used = sum(r => Math.min(r.m1.used, r.m1.shown)), rated = sum(r => Math.min(r.m1.used, r.m1.shown) + r.m1.rejected);
  const withCards = rows.filter(r => r.m4.cards);
  const summary = {
    meetings: rows.length,
    M1: { shown, used, value: shown ? +(used / shown).toFixed(3) : null, feedbackCoverage: shown ? +(rated / shown).toFixed(3) : null, signals: { adopt: sum(r => r.m1.signals && r.m1.signals.adopt), copy: sum(r => r.m1.signals && r.m1.signals.copy), dismiss: sum(r => r.m1.signals && r.m1.signals.dismiss) } },
    M2: { asks: sum(r => r.m2.asks), asksUnverified: sum(r => r.m2.asksUnverified), autoExcluded: sum(r => r.m2.autoExcluded), perMeeting: rows.length && !rows.some(r => r.m2.value === null) ? +(sum(r => r.m2.value) / rows.length).toFixed(2) : null },
    M3: { corrections: sum(r => r.m3.corrections), repeats: sum(r => r.m3.repeats) },
    M4: { meetingsWithDesk: withCards.length, cards: sum(r => r.m4.cards), sent: sum(r => r.m4.sent), editedBeforeSend: sum(r => r.m4.editedBeforeSend), notSent: sum(r => r.m4.notSent), editedNotSent: sum(r => r.m4.editedNotSent), manualScanned: rows.filter(r => r.m4.manualScanned).length, manualForwards: rows.some(r => r.m4.manualScanned) ? sum(r => r.m4.manualForwards) : null, manualForwardCards: rows.some(r => r.m4.manualScanned) ? sum(r => r.m4.manualForwardCards) : null, manualUncarded: rows.some(r => r.m4.manualScanned) ? sum(r => r.m4.manualUncarded) : null },
  };
  const gaps = [];
  if (summary.M1.feedbackCoverage !== null && summary.M1.feedbackCoverage < 0.1) gaps.push('M1：Aaron 对卡片表态（采纳 / 复制 / 关掉 / 有用 / 没用 / 收录）不到一成，有用率主要反映「没表态」，不能当成卡片没用');
  if (summary.M2.asksUnverified) gaps.push('M2：' + summary.M2.asksUnverified + ' 次会中提问 / 起草是没有操作者字段的旧任务，认不出是不是 Aaron 本人，暂不计入');
  gaps.push('M2：事后在别处补问的没接上；也没法区分「Citeside该提而没提」和「他本来就想自己问」');
  if (!summary.M3.corrections) gaps.push('M3：这段时间没有他亲手纠正的记录，重复犯错无从判断');
  if (summary.M4.manualForwards === null) gaps.push('M4：手动转发没有任何记录，记 null——会后 72 小时的 Slack / Notion 扫描没有一次读到东西（设置里要有带 search:read 的 Slack 用户授权，或连接 Notion）');
  else if (withCards.length && summary.M4.manualScanned < withCards.length) gaps.push('M4：' + (withCards.length - summary.M4.manualScanned) + ' 场有处理台的会没扫过手动转发，manualForwards 只覆盖扫过的 ' + summary.M4.manualScanned + ' 场');
  if (summary.M4.manualUncarded) gaps.push('M2 候选：' + summary.M4.manualUncarded + ' 条他会后自己发的内容对不上任何一张卡——Citeside该出卡没出');
  if (summary.M4.cards && summary.M4.sent + summary.M4.editedBeforeSend < summary.M4.cards * 0.1) gaps.push('M4：会后处理台的卡大多没人处理，改了几处只覆盖极少数卡');
  return { generatedAt: new Date().toISOString(), since: opts.since || null, summary, gaps, meetings: rows };
}

module.exports = { forSession, forAll, correctionPair, corrections, loadContext, ctxFor, actionsKey, norm };
