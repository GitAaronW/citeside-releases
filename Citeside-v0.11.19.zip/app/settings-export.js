'use strict';
// Export user-created artifacts, including audio. Credentials and transport state are excluded.
const fs=require('fs'),path=require('path');
const ROOTS=['pending','audio','exports','live-reports','act-for-me','memory','context.md','对我的记忆.md','owner-profile.json','registered-speakers.json',
 'state/work-hub','state/mother-documents','state/live-sessions','state/meeting-pipeline','state/assistant-materials','state/topic-diff','state/memory.db','state/my-tasks-notion-read.json','state/assigned-work.json','state/name-aliases.json','state/meeting-titles.json'];
function files(dataDir){
 const base=fs.realpathSync(dataDir),out=[];
 function visit(relative){
  const file=path.join(base,relative);let st;try{st=fs.lstatSync(file);}catch(e){if(e.code==='ENOENT')return;throw e;}
  if(st.isSymbolicLink())return; // Never follow a library folder outside the application.
  if(st.isDirectory()){for(const name of fs.readdirSync(file).sort())visit(path.join(relative,name));}
  else if(st.isFile())out.push(relative);
 }
 for(const root of ROOTS)visit(root);
 return out;
}
function stream(dataDir,res,{spawn=require('child_process').spawn}={}){
 const entries=files(dataDir);
 // --files-from avoids command-line length limits, --null preserves spaces and newlines.
 const child=spawn('/usr/bin/tar',['-cf','-','-C',dataDir,'--null','-T','-'],{stdio:['pipe','pipe','pipe']});
 res.writeHead(200,{'Content-Type':'application/gzip','Content-Disposition':'attachment; filename="Citeside-data.tar.gz"','Cache-Control':'no-store'});
 const gzip=require('zlib').createGzip();gzip.on('error',()=>res.destroy());child.stdout.pipe(gzip).pipe(res);child.stderr.resume();child.stdin.on('error',()=>{});
 child.stdin.end(entries.map(p=>p+'\0').join(''));
 child.on('error',()=>res.destroy());child.on('exit',code=>{if(code)res.destroy();});
 res.on('close',()=>{if(!child.killed)child.kill();});
 return child;
}
module.exports={ROOTS,files,stream};
