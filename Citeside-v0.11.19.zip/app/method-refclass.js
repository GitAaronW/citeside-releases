'use strict';
// 参考类预测 + 置信度用语（Kahneman / Tetlock；ICD 203）。会上报出排期、销量、良率、成本这类数字或日期时，
// 先问「同类事情一般结果如何」（外部视角），再按这次的特殊性调整；可能性只用七档固定用语，每档对应固定概率区间。
const CLAIM = /(排期|交付|上线|发布|量产|试产|样品|良率|销量|出货|成本|预算|报价|毛利|转化|留存|日活|月活|DAU|MAU|工期|人天|人月|年底|月底|Q[1-4]|[一二三四]季度|[0-9０-９]+\s*(?:月|号|日|周|天|个月|年|%|％|万|亿|k|台|部|美金|美元|元|块))/i;
function claims(rows) { return (rows || []).filter(r => r && CLAIM.test(String(r.text || ''))).map(r => r.id); }

// ICD 203 的七档；中文用语固定，括号里是对应概率区间。
const ICD = ['几乎确定（95–99%）', '很可能（80–95%）', '可能性较大（55–80%）', '五五开（45–55%）', '不太可能（20–45%）', '很不可能（5–20%）', '几乎不可能（1–5%）'];
const ICD_RE = /几乎确定|很可能|可能性较大|五五开|不太可能|很不可能|几乎不可能/;
function confidenceOf(text) { const m = String(text || '').match(ICD_RE); return m ? m[0] : ''; }

const prompt = `
参考类预测与置信度用语（实验）：forecastClaims 列出本批里报出排期、数量、比例、成本的句 id。
- 对其中最值得查的一条（最多一条）出 external 卡：用外部视角给同类基准（同类项目 / 同类产品一般结果如何），再说这次的可能性。text 第一行一句话写完，必须以「同类一般」开头：「同类一般 Y，这次 X 的可能性：<用语>」，凭记忆的基准加「需核实」。不复述会上的原话。
- 可能性只能用这七档固定用语，不自造措辞：${ICD.join(' / ')}。
- 基准和会上说法差不多、或对当前决定没影响，就不出；不对会上的数字做换算。不在 text 里写方法名，标签由系统加。
`;
// 卡片标签 = 方法名（括号白话），Aaron 10-25 第 6 组评论「参考类预测、同类基准，感觉是在重复说一样的话」→ 去掉同义子名，只留「参考类预测（对比同类案例）」。含同类基准（或七档用语且提到同类 / 基准 / 案例）的卡，text 前加标签。
const REF_TAG = '「参考类预测（对比同类案例）」';
const REF_HIT = /同类.{0,12}基准|基准看|同类基准|同类(?:项目|产品|案例|情况|做法|团队|公司)|同类一般/;
const REF_CTX = /同类|基准|案例|参考类/;
// 七档用语后面跟着对应的概率区间（如「很不可能（5–20%）」）也算：这个区间写法只有参考类提示词会要，模型压缩到 30 字时常把「同类一般」丢掉。
const ICD_BAND = /[（(]\s*(?:95\s*[–-]\s*99|80\s*[–-]\s*95|55\s*[–-]\s*80|45\s*[–-]\s*55|20\s*[–-]\s*45|5\s*[–-]\s*20|1\s*[–-]\s*5)\s*[%％]/;
// 模型自己写进 text 的「参考类预测·同类基准（…）」这类变体，一律换成 REF_TAG（原位、只留一个）；幂等。
const MODEL_TAG = /^((?:「(?!参考类预测)[^」\n]*」)*)「参考类预测[^」\n]*」/;   // 同 method-hats：前面的标签串里不能再含参考类标签
function tagRef(parsed) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return parsed;
  const tag = c => {
    if (!c || typeof c.text !== 'string') return c;
    let text = c.text, pre = '', had = false;
    for (let m = text.match(MODEL_TAG); m; m = text.match(MODEL_TAG)) { had = true; pre += m[1]; text = text.slice(m[0].length); }
    const hit = had || REF_HIT.test(text) || (ICD_RE.test(text) && (REF_CTX.test(text) || ICD_BAND.test(text)));
    const out = pre + (hit ? REF_TAG : '') + text;
    return out === c.text ? c : { ...c, text: out };
  };
  return { ...parsed, suggestion: tag(parsed.suggestion), insights: (Array.isArray(parsed.insights) ? parsed.insights : []).map(tag) };
}
module.exports = { CLAIM, ICD, ICD_RE, ICD_BAND, REF_TAG, REF_HIT, claims, confidenceOf, tagRef, prompt };
