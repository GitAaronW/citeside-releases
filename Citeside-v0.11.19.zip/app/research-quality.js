'use strict';
// Calendar calculations use the meeting's Asia/Shanghai day, never the host TZ.
const dayOf = iso => {const t=typeof iso==='number'?iso:Date.parse(iso);return Number.isFinite(t)?new Date(t+8*3600e3).toISOString().slice(0,10):'';};
// Share explicit calendar dates across stale checks and normalization. Dotted
// versions/decimals are not dates; slash dates require surrounding date context.
function explicitDates(raw) {
 const text=String(raw||''),dates=[];
 for(const m of text.matchAll(/(?<![\w.\d/-])(?:(20\d{2})[-/年])?(\d{1,2})([-/月])(\d{1,2})日?(?![\d./]|\s*(?!前|后|之|以|或|和|至|到)[\p{Script=Han}])/gu)){
  const before=text.slice(0,m.index), after=text.slice(m.index+m[0].length);
  if (!m[1] && m[3] === '-' && m[0].endsWith('日')) continue;
  if (/(?:版本|版|v)\s*$/i.test(before) || /^\s*(?:版本|版|v)/i.test(after)) continue;
  if(!m[1] && m[3]==='/' && !/(?:截止|日期|期限|定于|截至)\s*(?:为|是|在|：|:)?\s*$/.test(before) && !/^\s*(?:日|之前|以前|前|截止|到期)/.test(after))continue;
  dates.push(m);
 }
 return dates;
}
// Keep the raw deadline unless it is a model suggestion before the meeting day.
function staleDue(due, iso) {
 const day=dayOf(iso); if(!day)return false;
 return explicitDates(due).some(m=>{
  const y=+(m[1]||day.slice(0,4)),month=+m[2],d=+m[4],t=new Date(Date.UTC(y,month-1,d));
  return t.getUTCFullYear()===y && t.getUTCMonth()===month-1 && t.getUTCDate()===d && t.toISOString().slice(0,10)<day;
 });
}
function normalizeActionDue(raw, meetingStart) {
 if(!meetingStart)return raw;
 const iso=meetingStart;
 if(!dayOf(iso) || !/^\s*建议/.test(String(raw||'')))return raw;
 return staleDue(raw,iso) || normalizeDue(raw,iso).reason==='past' ? '' : raw;
}
const plus = (day,n) => new Date(Date.parse(day)+n*864e5).toISOString().slice(0,10);
function normalizeDue(raw, iso) {
 const day=dayOf(iso),text=String(raw||'').trim();
 if(!day)return {due:'待定',raw:text,reason:'missing-meeting-date'};
 const fallback=reason=>({due:'建议 '+plus(day,3),raw:text,reason});
 if(!text||/^待定/.test(text))return fallback('missing');
 const dates=[]; let invalid=false;
 for(const m of explicitDates(text)){
  let y=+(m[1]||day.slice(0,4)); const mo=+m[2],d=+m[4]; let t=new Date(Date.UTC(y,mo-1,d));
  if(!m[1] && Date.parse(day)-t.getTime()>60*864e5){y++;t=new Date(Date.UTC(y,mo-1,d));}
  if(t.getUTCFullYear()!==y||t.getUTCMonth()!==mo-1||t.getUTCDate()!==d)invalid=true;
  else dates.push(t.toISOString().slice(0,10));
 }
 const dow=(new Date(day).getUTCDay()+6)%7;
 const lower=text.toLowerCase();
 if (/\bday after tomorrow\b/.test(lower)) dates.push(plus(day,2));
 else if (/\btomorrow\b/.test(lower)) dates.push(plus(day,1));
 else if (/\btoday\b/.test(lower)) dates.push(day);
 if (/\byesterday\b/.test(lower)) dates.push(plus(day,-1));
 const weekdays=['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
 for (const m of lower.matchAll(/\b(?:(next|this|last)\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/g)) {
   const target=weekdays.indexOf(m[2]);
   const offset=target-dow+({next:7,last:-7,this:0})[m[1]];
   dates.push(plus(day,Number.isFinite(offset)?offset:target-dow+(target<dow?7:0)));
 }
 for(const m of text.matchAll(/(今天|今日|明天|明日|后天|昨天|昨日|前天)|([本这下上]?)周([一二三四五六日天])|(\d+)\s*天后/g)){
  let offset;
  if(m[1])offset=({今天:0,今日:0,明天:1,明日:1,后天:2,昨天:-1,昨日:-1,前天:-2})[m[1]];
  else if(m[4])offset=+m[4];
  else {const target='一二三四五六日'.indexOf(m[3]==='天'?'日':m[3]);offset=target-dow+({下:7,上:-7,本:0,这:0,'':target<dow?7:0})[m[2]];}
  dates.push(plus(day,offset));
 }
 if(invalid)return fallback('invalid');
 const unique=[...new Set(dates)];
 if(unique.length>1)return fallback('conflicting');
 if(!unique.length)return fallback('unresolved');
 if(unique[0]<day)return fallback('past');
 // Keep precise time/qualifier and full original separately; never truncate a date.
 const hanTime = text.replace(/([零一二三四五六七八九十两]+)点/g, (_,h) => {
   const digits={零:0,一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9};
   const parts=h.split('十');const n=parts.length===2?(parts[0]?digits[parts[0]]:1)*10+(parts[1]?digits[parts[1]]:0):digits[h];
   return Number.isFinite(n)?n+'点':h+'点';
 });
 // Bare N点 is ambiguous. Accept a period prefix or explicit clock suffix only.
 const period='上午|下午|晚上|早上|中午|凌晨';
 const time=hanTime.match(new RegExp('('+period+')?\\s*(\\d{1,2}):([0-9]{2})(?![0-9])')) ||
   hanTime.match(new RegExp('('+period+')\\s*(\\d{1,2})点(半|[0-9]{1,2}分?|钟|整|:[0-9]{2})?')) ||
   hanTime.match(/()(?<![第\d])(\d{1,2})点(半|[0-9]{1,2}分|钟|整|:[0-9]{2})/);
 let suffix='';
 if(time){
   let h=+time[2], token=time[3]||'00';
   let min=token==='半'?30:/^(钟|整)$/.test(token)?0:Number(token.replace(/^:|分$/g,''));
   if(time[1]==='晚上' && h===12 && min===0) h=24;
   else if(/下午|晚上/.test(time[1])&&h<12)h+=12;
   else if(/凌晨|上午|早上/.test(time[1])&&h===12)h=0;
   if(h>24 || (h===24 && min!==0) || min>59)return fallback('invalid-time');
   suffix=' '+String(h).padStart(2,'0')+':'+String(min).padStart(2,'0');
 }
 const qualifier=text.match(/下班前|中午前|下午前|晚上前|月底前/)?.[0];
 return {due:(/建议/.test(text)?'建议 ':'')+unique[0]+suffix+(qualifier?' '+qualifier:/之前|以前|前$/.test(text)?' 前':''),raw:text,reason:''};
}
// Normalize numeral runs before a following unit without a unit whitelist.
function numericText(text) {
 const digits={零:0,〇:0,一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9};
 const units={十:10,百:100,千:1000,万:10000,亿:100000000};
 const number=h=>{
   if([...h].every(c=>c in digits))return [...h].map(c=>digits[c]).join('');
   let total=0,section=0,n=0;
   for(const c of h){if(c in digits)n=digits[c];else if(units[c]<10000){section+=(n||1)*units[c];n=0;}else {section+=n;total=(total+section)*units[c];section=0;n=0;}}
   return String(total+section+n);
 };
 // 单独的「一」多半是词的一部分（统一、确认一下、整理一份），只在时间 / 计数单位前才当数字。
 return String(text||'').replace(/[零〇一二两三四五六七八九十百千万亿]+(?=\s*([\p{L}%％]))/gu,(h,_u,off,all)=>{
   if(h==='一' && !/^\s*(?:周|天|日|月|年|季度|小时|分钟|秒|个|次|轮|版|台|部|款|项|条|页|组|批|人|位|家|周内|天内)/u.test(all.slice(off+1)))return h;
   if(h.length===2 && h[0] in digits && h[1] in digits && digits[h[0]]>0 && digits[h[1]]>digits[h[0]])return digits[h[0]]+'-'+digits[h[1]];
   return number(h);
 }).replace(/\s+/g,'');
}
const anonymousOwner = name => /^(?:(?:说话人|发言人|speaker)[_\s]*|S)?\d+$/i.test(name);
function ownerName(raw, known = []) {
 const name=String(raw||'').replace(/[（(][^）)]*[）)]/g,'').trim();
 if(!name || anonymousOwner(name))return '';
 return known.some(n=>String(n).trim()===name)?name:'';
}
module.exports={normalizeActionDue,staleDue,normalizeDue,dayOf,numericText,ownerName,anonymousOwner};
