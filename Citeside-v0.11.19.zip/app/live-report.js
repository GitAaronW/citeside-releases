'use strict';
// 会中研报（2026-10-23 总控派 dev-ui）：会议进行中随时拼出一份「研报」，会议结束那一刻已经成形。
// 形状与北极星评测底座一致：report = { markdown, items: [{ text, sources, action: { do, owner, due } | null }] }，
// 另加 version（内容指纹，变了才重画）、updatedAt、final（会议已结束）。
// 现在是基线：把这场已有的会中看法 / 核查卡（factchecks）、主动智能卡（nativeInsights.history）和待办（todos）拼起来。
// dev-intel 的研报模块好了以后 setProvider(fn) 换掉生成器，界面不用改：fn(sess) 返回同形状（可只给 markdown + items）。
const crypto = require('crypto');
const { ownerName } = require('./research-quality');
// 日历邀请里没拒绝的人也算在场：会中还没开口的人，待办写到他名下时也认得出（10-26 会中负责人全是「待定负责人」）。
const attendees = sess => { const c = sess.calendar || {}, ev = c.event || {}; return [c.attendees, ev.attendees, ev.attendeeList].flatMap(l => Array.isArray(l) ? l : []).filter(a => a && !a.declined).map(a => typeof a === 'string' ? a : a.name).filter(n => typeof n === 'string' && n.trim()); };
const roster = sess => [...(sess.participants || []), ...attendees(sess), ...(sess.transcript || sess.segments || []).map(r => r.speaker || r.name)].filter(n=>typeof n==='string');

const clip = (s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);
const shownOwner = o => { const v = String(o || '').trim(); return !v || v === '待定负责人' ? '未指定' : v; };
const reportSources = list => [...new Set((list || []).map(u => String(u || '').trim()).filter(u => /^(?:https?:\/\/|memory:\/\/)/i.test(u)))].slice(0, 5);
const norm = s => String(s || '').replace(/^AI\s*(解读|interpretation)\s*[:：]\s*/i, '').replace(/[\s，。,.!！?？:：;；、"'“”‘’()（）*#>-]/g, '').toLowerCase();

let provider = null;
function setProvider(fn) { provider = typeof fn === 'function' ? fn : null; }

function cardSources(x) {
  return reportSources([
    ...((x.refs || []).map(r => typeof r === 'string' ? r : r && r.url)),
    ...(((x.verify && x.verify.sources) || []).map(r => r && r.url)),
    ...((x.sources || []).map(r => typeof r === 'string' ? r : r && r.url)),
  ]);
}

function baseline(sess) {
  const items = [], seen = new Set();
  const add = (text, sources, action) => {
    const t = clip(text, 600), k = norm(t);
    if (!t || !k || seen.has(k)) return;
    seen.add(k); items.push({ text: t, sources: sources || [], action: action || null });
  };
  for (const x of sess.factchecks || []) {
    if (!x || x.stale || x.supersededBy || x.verdict === 'false') continue;
    add(x.point || x.claim || x.md, cardSources(x), null);
  }
  for (const x of ((sess.nativeInsights && sess.nativeInsights.history) || [])) {
    if (!x || x.superseded) continue;
    add(x.text, cardSources(x), null);
  }
  for (const t of sess.todos || []) {
    if (!t || t.done || t.stale) continue;
    const text = clip(t.text, 300); if (!text) continue;
    add(text, [], { do: text, owner: ownerName(t.owner, roster(sess)) || '待定负责人', due: String(t.due || '').trim() });
  }
  return { items };
}

function markdownOf(title, items) {
  const facts = items.filter(i => !i.action), acts = items.filter(i => i.action);
  const lines = ['# ' + (title || '会中研报')];
  if (facts.length) { lines.push('', '## 分析'); for (const i of facts) lines.push('- ' + i.text + (i.sources.length ? ' ' + i.sources.map((u, n) => `[${n + 1}](${u})`).join(' ') : '')); }
  if (acts.length) { lines.push('', '## 待办'); for (const i of acts) lines.push('- ' + i.action.do + (i.action.owner ? ' @' + i.action.owner : '') + (i.action.due ? ' · ' + i.action.due : '')); }
  return lines.join('\n');
}

// sess：会中 Session 对象或 pending/<id>.json；final：会议已结束
function build(sess, { final = false, now = Date.now } = {}) {
  if (!sess) return null;
  let got = null;
  if (provider) { try { got = provider(sess, { final: !!final }); } catch (e) { got = null; } }
  const base = got && Array.isArray(got.items) ? got : baseline(sess);
  const personal=require('./personal-actions'), pack=require('./context-pack'), sessionForNames={...sess,selfNames:base.selfNames||sess.selfNames};
  const names=pack.actionIdentity('',sessionForNames), named=Array.isArray(names)?names.slice():[];
  named.roleKeywords=pack.actionRoleKeywords('',sessionForNames);
  const rawActions=[...(base.allActions||[])];
  for (const [index,i] of base.items.entries()) if(i?.action && !rawActions.some(a=>i.id ? a.id===i.id : (a.do||a.text)===i.action.do))
    rawActions.push({...i.action,id:i.id||'item-'+index,evidence:i.evidence||i.action.evidence||'',background:i.background||''});
  const grouped=personal.groupActions(rawActions,sess.transcript||sess.segments||[],named);
  const classification=i=>i?.action ? grouped.allActions.find(a=>i.id ? a.id===i.id : a.do===i.action.do) : null;
  const items = base.items.map(i => ({ ...(i && i.id ? {id:i.id} : {}), mine: classification(i)?.group === 'mine', group:classification(i)?.group||'all', ...(i?.background ? {background:clip(i.background,500)} : {}), ...(i?.draft ? {draft:i.draft} : {}), text: clip(i && i.text, 600), sources: reportSources(i && i.sources), action: i && i.action ? { do: clip(i.action.do, 300), owner: shownOwner(ownerName(i.action.owner, base === got ? [...roster(sess), ...(base.participants || [])] : roster(sess))), due: String(i.action.due || '').trim(), ...(i.action.due_raw != null ? {due_raw: String(i.action.due_raw), due_issue: String(i.action.due_issue || '')} : {}), ...(typeof i.action.said === 'boolean' ? { said: i.action.said } : {}), ...(i.action.done_when ? { done_when: clip(i.action.done_when, 160) } : {}) } : null, ...(i && ['会上', '网页', '推断'].includes(i.basis) ? { basis: i.basis } : {}), ...(i && i.at ? { at: clip(i.at, 20) } : {}) })).filter(i => i.text);
  const markdown = got && typeof got.markdown === 'string' && got.markdown.trim() ? got.markdown : markdownOf(sess.title, items);
  // 收尾轮还在跑（provider 给 pending）：先不标已成形，界面继续轮询，等收尾稿出来
  const done = !!final && !(got && got.pending);
  // Full research output is separate from the intentionally clipped live-card preview.
  const researchGroups = new Map();
  for(const [index,item] of base.items.entries()){
    if(item?.action||item?.topic!=='外部研究'||!String(item.text||'').trim())continue;
    const id=String(item.card||item.id||'research-'+index);
    const group=researchGroups.get(id)||{id,title:item.title||String(item.text).split('\n')[0].slice(0,60),text:'',sources:[]};
    group.text+=(group.text?'\n\n':'')+String(item.text);
    group.sources=[...new Set([...group.sources,...reportSources(item.sources)])];researchGroups.set(id,group);
  }
  const researchResults=[...researchGroups.values()];
  const version = crypto.createHash('sha256').update(JSON.stringify([markdown, items, researchResults, base.pendingVerification, base.researchJobs, done])).digest('hex').slice(0, 12);
  return { researchResults, researchJobs: Array.isArray(base.researchJobs)?base.researchJobs:[], markdown, items, myActions: grouped.myActions.map(a=>({...a,draft:base.myActions?.find(m=>m.id===a.id)?.draft||a.draft})), possibleActions:grouped.possibleActions, allActions:grouped.allActions, actForMeIncomplete:!!base.actForMeIncomplete, ...(Array.isArray(base.pendingVerification) ? { pendingVerification: base.pendingVerification } : {}), version, updatedAt: new Date(now()).toISOString(), final: done, source: base === got ? 'provider' : 'baseline' };
}

module.exports = { reviewAction:(...args)=>{if(!provider?.reviewAction)throw Error('待办审核尚未接入');return provider.reviewAction(...args);}, build, setProvider, baseline, markdownOf, attendees };
