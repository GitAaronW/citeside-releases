'use strict';
// Native capture permissions belong to the installed signed helper, not the
// JavaScript release version. Keep that identity for compatible program updates.
const fs=require('fs'),path=require('path'),{execFileSync}=require('child_process'),crypto=require('crypto');
const HELPER='app/native-capture/CitesideCapture.app';
const INPUTS=['app/native-capture/CitesideCapture.swift','app/native-capture/ArtifactPreview.swift','scripts/build-artifact-preview.sh'];
const PROVENANCE='app/native-capture/build-provenance.json';
const LEGACY_BUILDS=require('./native-capture/legacy-build-provenance.json');
const LEGACY_NATIVE=require('./legacy-native.json');
const digest=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const codesign=app=>execFileSync('/usr/bin/codesign',['--verify','--deep','--strict',app],{stdio:'pipe',timeout:6000});
// iCloud 桌面（File Provider）会给仓库里的 .app 反复挂 FinderInfo 扩展属性，--strict 判为 detritus。
// 扩展属性不在签名范围内：只在这一种报错时，拿去掉扩展属性的临时副本重验，签名内容一字不改。
function verify(app){
 try{return codesign(app);}catch(e){
  if(!/detritus/.test(String(e.stderr||'')))throw e;
  const tmp=fs.mkdtempSync(path.join(require('os').tmpdir(),'tht-verify-')),copy=path.join(tmp,path.basename(app));
  try{execFileSync('/usr/bin/ditto',['--norsrc','--noextattr','--noqtn','--noacl',app,copy],{stdio:'pipe',timeout:20000});return codesign(copy);}
  finally{fs.rmSync(tmp,{recursive:true,force:true});}
 }
}
function fingerprint(root){
 const hash=crypto.createHash('sha256');
 function visit(rel){const file=path.join(root,rel),stat=fs.lstatSync(file);hash.update(JSON.stringify([rel,stat.mode&0o777,stat.isSymbolicLink()?'link':stat.isDirectory()?'dir':'file'])+'\n');
  if(stat.isSymbolicLink())hash.update(fs.readlinkSync(file));else if(stat.isDirectory())for(const name of fs.readdirSync(file).sort())visit(path.join(rel,name));else if(stat.isFile())hash.update(fs.readFileSync(file));else throw Error('Unsupported native bundle entry');
 }
 visit('');return hash.digest('hex');
}
function sameFile(a,b){try{return fs.lstatSync(a).isFile()&&fs.lstatSync(b).isFile()&&fs.readFileSync(a).equals(fs.readFileSync(b));}catch{return false;}}
function provenance(root){
 const file=path.join(root,PROVENANCE);
 if(!fs.existsSync(file))return null;
 const data=JSON.parse(fs.readFileSync(file,'utf8'));
 if(data.schemaVersion!==1||!/^[a-f0-9]{40}$/.test(data.sourceSha||'')||data.helperSha256!==fingerprint(path.join(root,HELPER)))throw Error('Invalid native build provenance');
 for(const name of [...INPUTS,HELPER+'/Contents/Info.plist']){
  const expected=data.inputSha256?.[name],actual=path.join(root,name);
  if(name===HELPER+'/Contents/Info.plist'&&!fs.existsSync(actual))throw Error('Native bundle metadata missing');
  if(!/^[a-f0-9]{64}$/.test(expected||'')||(fs.existsSync(actual)&&digest(actual)!==expected))throw Error('Native build provenance input mismatch');
 }
 return data;
}
function writeProvenance(root,sourceSha,{verifySignature=verify}={}){
 if(!/^[a-f0-9]{40}$/.test(sourceSha||''))throw Error('Native provenance requires fixed source SHA');
 verifySignature(path.join(root,HELPER));
 const data={schemaVersion:1,sourceSha,helperSha256:fingerprint(path.join(root,HELPER)),inputSha256:Object.fromEntries([...INPUTS,HELPER+'/Contents/Info.plist'].map(name=>[name,digest(path.join(root,name))]))};
 fs.writeFileSync(path.join(root,PROVENANCE),JSON.stringify(data,null,2)+'\n');
 return data;
}
function inputDigest(root,name,receipt){
 const file=path.join(root,name);
 if(fs.existsSync(file))return digest(file);
 return receipt?.inputSha256?.[name]||null;
}
// Fixed legacy artifacts are bound to immutable package/build evidence. This is
// an allowlist of complete signed bundles, never a version-label exception.
function legacyEvidence(current,incoming,helperSha256,builds){
 return builds.some(receipt=>{
  try{
   if(receipt.schemaVersion!==1||! /^[a-f0-9]{40}$/.test(receipt.sourceSha)||receipt.helperSha256!==helperSha256)return false;
   return [...INPUTS,HELPER+'/Contents/Info.plist'].every(name=>{
    const expected=receipt.inputSha256?.[name];
    if(!/^[a-f0-9]{64}$/.test(expected||'')||digest(path.join(incoming,name))!==expected)return false;
    const old=path.join(current,name);
    return fs.existsSync(old)?digest(old)===expected:name==='scripts/build-artifact-preview.sh';
   });
  }catch{return false;}
 });
}
function plan(current,incoming,{verifySignature=verify,legacyBuilds=LEGACY_BUILDS,preservationAttestation,attestationOptions}={}){
 const old=path.join(current,HELPER),next=path.join(incoming,HELPER);
 const explicitProof=preservationAttestation!==undefined;
 if(explicitProof&&(typeof preservationAttestation!=='string'||!preservationAttestation.trim()))throw Error('Preservation attestation must be a non-empty path');
 if(explicitProof&&!fs.existsSync(old))throw Error('Preservation attestation requires an installed helper');
 if(!fs.existsSync(old)){
  if(fs.existsSync(path.join(current,LEGACY_NATIVE.captureParent)) && fs.readdirSync(path.join(current,LEGACY_NATIVE.captureParent)).some(name=>name.endsWith(LEGACY_NATIVE.captureBundleSuffix)&&name!==LEGACY_NATIVE.currentCaptureBundle))throw Object.assign(Error('采音组件需要完成Citeside名称迁移；旧组件和权限尚未改动'),{code:'HELPER_CHANGED'});
  return {preserve:false,reason:'first-install'};
 }
 if(!fs.existsSync(next))throw Error('更新包缺少录音组件，未更新');
 for(const [role,app] of [['current',old],['incoming',next]]){
  try{verifySignature(app);}catch(e){throw Error(`录音组件签名校验失败（${role}：${app}）：${String(e.stderr||e.message||e).trim().slice(0,300)}；未更新`);}
 }
 if(explicitProof) return require('./native-preservation-attestation').validate(current,incoming,preservationAttestation,{...attestationOptions,verifySignature});
 const inputs=[...INPUTS,HELPER+'/Contents/Info.plist'];
 const helperSha256=fingerprint(old);
 let currentReceipt,incomingReceipt;
 try{currentReceipt=provenance(current);incomingReceipt=provenance(incoming);}catch{throw Error('录音组件构建来源清单校验失败，当前程序和权限未改动');}
 const matching=inputs.every(name=>{
  if(sameFile(path.join(current,name),path.join(incoming,name)))return true;
  const before=inputDigest(current,name,currentReceipt),after=inputDigest(incoming,name,incomingReceipt);
  return before!==null&&before===after;
 });
 const attested=!matching&&legacyEvidence(current,incoming,helperSha256,legacyBuilds);
 if(!matching&&!attested)
  throw Object.assign(Error('新版需要更换录音组件或旧安装缺少构建来源凭据；请使用已核验的恢复入口，当前版本和录音权限已保留，未更新（权限迁移）'),{code:'HELPER_CHANGED'});
 return {preserve:true,reason:attested?'attested-legacy-installed-helper':'compatible-installed-helper',helperSha256};
}
// User-consented helper replacement: keep the incoming signed helper. macOS may
// ask for recording permissions again because the signed bytes change.
function migrate(current,staged,{verifySignature=verify}={}){
 const next=path.join(staged,HELPER);
 if(!fs.existsSync(next))throw Error('更新包缺少录音组件，未更新');
 try{verifySignature(next);}catch(e){throw Error(`录音组件签名校验失败（incoming：${next}）：${String(e.stderr||e.message||e).trim().slice(0,300)}；未更新`);}
 return {preserve:false,reason:'helper-migration'};
}
// Restore exact source modes after cpSync applies the service umask.
function restoreModes(source,destination){
 const stat=fs.lstatSync(source);
 if(stat.isSymbolicLink()){
  if((fs.lstatSync(destination).mode&0o777)!==(stat.mode&0o777))fs.lchmodSync(destination,stat.mode&0o777);
  return;
 }
 if(stat.isDirectory())for(const name of fs.readdirSync(source))restoreModes(path.join(source,name),path.join(destination,name));
 fs.chmodSync(destination,stat.mode&0o777);
}
function preserve(current,staged,options){
 if(options?.preservationAttestation!==undefined)throw Error("Local preservation attestation cannot rewrite staged build provenance");
 const result=plan(current,staged,options);
 if(result.preserve){
  const target=path.join(staged,HELPER);
  fs.rmSync(target,{recursive:true,force:true});
  fs.cpSync(path.join(current,HELPER),target,{recursive:true,verbatimSymlinks:true});
  // cpSync applies the service umask to new directories. Restore the installed
  // modes without following symlinks before checking the complete identity.
  restoreModes(path.join(current,HELPER),target);
  (options?.verifySignature||verify)(target);
  if(fingerprint(target)!==result.helperSha256)throw Error('保留录音组件的文件校验失败，未更新');
  // The staged manifest must describe the retained signed bytes after copying.
  const manifest=path.join(staged,PROVENANCE);
  if(fs.existsSync(manifest)){
   const data=JSON.parse(fs.readFileSync(manifest,'utf8'));
   data.helperSha256=result.helperSha256;
   fs.writeFileSync(manifest,JSON.stringify(data,null,2)+'\n');
   provenance(staged);
  }
 }
 return result;
}
module.exports={HELPER,INPUTS,PROVENANCE,verify,plan,preserve,migrate,fingerprint,writeProvenance,provenance,restoreModes};
if(require.main===module){
 try{const [action,current,incoming,...flags]=process.argv.slice(2);
  const preservationFlag=flags.find(value=>value.startsWith('--preservation-attestation='));
  if(flags.length>1||flags.some(value=>value!==preservationFlag))throw Error('Unknown native-update argument');
  const options=preservationFlag?{preservationAttestation:preservationFlag.slice('--preservation-attestation='.length)}:{};
  if(action==='fingerprint'&&current){console.log(fingerprint(path.join(path.resolve(current),HELPER)));process.exit(0);}
  if(action==='write-provenance'&&current&&incoming){console.log(JSON.stringify(writeProvenance(path.resolve(current),incoming)));process.exit(0);}
  if(!['plan','preserve','migrate'].includes(action)||!current||!incoming)throw Error('Usage: native-update.js plan|preserve|migrate CURRENT STAGED; write-provenance ROOT SOURCE_SHA; fingerprint ROOT');
  console.log(JSON.stringify(({plan,preserve,migrate})[action](path.resolve(current),path.resolve(incoming),options)));
 }catch(error){console.error(error.message);process.exitCode=error.code==='HELPER_CHANGED'?3:1;}
}
