'use strict';
// Existing meeting-board Jobs are durable user-visible artifacts with three
// parallel slots; title backfill only needs a bounded single-slot adapter around
// the retained Python generator. Only explicit ensure() calls enter this queue.
const path = require('node:path');
const { execFile } = require('node:child_process');
const titles = require('./meeting-title');
const safeCodes = new Set(['invalid_request','account_login_required','entitlement_required','quota_exhausted','call_budget_exhausted','output_budget_exhausted','input_too_large','no_provider','routing_deadline','title_invalid','title_generation_failed','no_title_content']);
const codeOf = value => safeCodes.has(value) ? value : 'title_generation_failed';
function runSingle({ dataDir, session, source = {}, python = process.env.THT_PYTHON || 'python3', timeoutMs = 180000 }) {
  return new Promise((resolve, reject) => {
    const child = execFile(python, [path.join(__dirname, 'backfill-titles.py'), '--session-stdin'], {
      env: { ...process.env, THT_DATA_DIR: dataDir, THT_PIPELINE_DIR: path.join(dataDir, 'state', 'meeting-pipeline'), THT_NODE: process.execPath },
      timeout: timeoutMs, maxBuffer: 65536
    }, (error, stdout) => {
      let result; try { result = JSON.parse(stdout); } catch {}
      if (error || !result?.ok) return reject(Object.assign(Error(codeOf(result?.errorCode)), { code: codeOf(result?.errorCode) }));
      resolve(result);
    });
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify({ session, source: { title: source.title, titleEdited: source.titleEdited, titleManual: source.titleManual, titleMethod: source.titleMethod } }));
  });
}
function create({ dataDir, generate = input => runSingle({ dataDir, ...input }), now = Date.now, cooldownMs = 30000, limit = 20, onChange = () => {} } = {}) {
  limit = Math.max(1, Math.min(20, Math.floor(Number(limit) || 20)));
  const entries = new Map(), waiting = [];
  let active = false;
  const publicJob = job => ({ sessionId: job.id, state: job.state, ...(job.title ? { title: job.title } : {}), ...(job.errorCode ? { errorCode: job.errorCode, retryAt: job.retryAt } : {}) });
  const notify = job => { try { onChange(publicJob(job)); } catch {} };
  async function drain() {
    if (active) return; active = true;
    try {
      while (waiting.length) {
        const job = waiting.shift(); job.state = 'running'; notify(job);
        try {
          const beforeManual = titles.manualTitle(job.input.session, { source: job.source });
          const result = beforeManual ? { ok: true, title: beforeManual, titleMethod: 'manual' } : await generate(job.input);
          if (!result?.ok) throw Object.assign(Error('title_generation_failed'), { code: result?.errorCode });
          const latestManual = titles.manualTitle(job.input.session, { source: job.source });
          const title = latestManual || (result.titleMethod === 'manual' || result.titleMethod === 'calendar' ? result.title : titles.shortTitle(result.title));
          if (!title) throw Object.assign(Error('title_invalid'), { code: 'title_invalid' });
          job.title = title; job.state = 'completed'; delete job.errorCode; delete job.retryAt;
        } catch (error) {
          job.state = 'failed'; job.errorCode = codeOf(error.code); job.retryAt = now() + cooldownMs;
        } finally { delete job.input; delete job.source; notify(job); job.resolve(publicJob(job)); }
      }
    } finally { active = false; }
  }
  return {
    ensure(session, context = {}) {
      const id = String(session?.id || '');
      if (!/^[A-Za-z0-9_.-]{1,80}$/.test(id)) return { sessionId: id, state: 'unavailable', errorCode: 'invalid_request' };
      const manual = titles.manualTitle(session, context), calendar = titles.calendarTitle(session, context.source);
      if (context.source?.kind === 'note' && !calendar) return { sessionId: id, state: 'ready', title: titles.display(session, context) };
      const cached = [context.titleRow?.topicTitle, session.topicTitle, context.job?.topicTitle, context.source?.topicTitle].map(titles.shortTitle).find(Boolean);
      if (manual || calendar || cached) return { sessionId: id, state: 'ready', title: manual || calendar || cached };
      if (!String(session.summary || '').trim() && !(session.transcript || []).some(row => String(row.text || '').trim())) return { sessionId: id, state: 'unavailable', errorCode: 'no_title_content' };
      const previous = entries.get(id);
      if (previous && (previous.state === 'queued' || previous.state === 'running' || previous.state === 'completed' || previous.retryAt > now())) return publicJob(previous);
      if ([...entries.values()].filter(job => job.state === 'queued' || job.state === 'running').length >= limit) return { sessionId: id, state: 'deferred' };
      for (const [key, job] of entries) { if (entries.size < 200) break; if (!['queued','running'].includes(job.state)) entries.delete(key); }
      let resolve; const done = new Promise(r => { resolve = r; });
      // Live Session owns capture timers and transports. Queue its existing data
      // snapshot, then detach nested data so later recording cannot change input.
      const snapshot = typeof session.snapshot === 'function' ? session.snapshot().session : session;
      const titleData = { ...snapshot };
      for (const key of ['title','titleEdited','titleManual','titleMethod','topicTitle']) if (session[key] !== undefined) titleData[key] = session[key];
      const job = { id, state: 'queued', input: { session: JSON.parse(JSON.stringify(titleData)), source: { title: context.source?.title, titleEdited: context.source?.titleEdited, titleManual: context.source?.titleManual, titleMethod: context.source?.titleMethod } }, source: context.source, done, resolve };
      entries.set(id, job); waiting.push(job); notify(job); void drain(); return publicJob(job);
    },
    status(id) { const job = entries.get(String(id)); return job ? publicJob(job) : null; },
    wait(id) { return entries.get(String(id))?.done || Promise.resolve(null); }
  };
}
module.exports = { create, runSingle };
