'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const notion = require('./tools/notion');
const notionAuth = require('./notion-auth');
const oauthLink = require('./tools/oauth-link');
const durable = require('./durable-json');

const UUID_RE = /^[0-9a-f]{8}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{12}$/i;
const UUID_EXTRACT_RE = /([0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;
const KEY_RE = /^[\w:.-]{1,160}$/;
const PREFERRED_PARENTS = ['Citeside · 会议与研报', 'Citeside 会议文档', 'Citeside · 会议纪要'];
const queues = new Map();

function stateFile(dataDir) {
  return path.join(path.resolve(dataDir), 'state', 'notion-output-sync.json');
}

function readState(dataDir) {
  const file = stateFile(dataDir);
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!raw || typeof raw !== 'object') throw Error('Notion 同步索引格式无效');
    return {
      version: 1,
      parentId: String(raw.parentId || ''),
      parentTitle: String(raw.parentTitle || ''),
      outputs: raw.outputs && typeof raw.outputs === 'object' ? { ...raw.outputs } : {},
    };
  } catch (e) {
    if (e.code === 'ENOENT') return { version: 1, parentId: '', parentTitle: '', outputs: {} };
    throw e;
  }
}

function saveState(dataDir, state) {
  const file = stateFile(dataDir);
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  durable.write(file, state, { mode: 0o600 });
}

function enqueue(dataDir, fn) {
  const key = path.resolve(dataDir);
  const prev = queues.get(key) || Promise.resolve();
  const next = prev.catch(() => {}).then(fn);
  queues.set(key, next);
  return next.finally(() => {
    if (queues.get(key) === next) queues.delete(key);
  });
}

function chunkRichText(text, url = '') {
  const s = String(text == null ? '' : text);
  if (!s) return [];
  const safeLink = typeof url === 'string' && /^https?:\/\//i.test(url) ? url : '';
  const out = [];
  for (let i = 0; i < s.length && out.length < 100; i += 1800) {
    const content = s.slice(i, i + 1800);
    out.push({
      type: 'text',
      text: safeLink ? { content, link: { url: safeLink } } : { content },
    });
  }
  return out;
}

function textBlock(type, text, url = '') {
  return { object: 'block', type, [type]: { rich_text: chunkRichText(text, url) } };
}

function richBlock(type, richText) {
  return { object: 'block', type, [type]: { rich_text: richText.slice(0, 100) } };
}

function batchBlocks(blocks, size = 100) {
  const out = [];
  for (let i = 0; i < blocks.length; i += size) out.push(blocks.slice(i, i + size));
  return out;
}

function parseParentInput(raw) {
  const text = String(raw || '').trim();
  if (!text) return '';
  if (UUID_RE.test(text)) return text;
  try {
    const u = new URL(text);
    const seg = u.pathname.split('/').filter(Boolean).pop() || '';
    const m = seg.match(UUID_EXTRACT_RE);
    return m ? m[1] : '';
  } catch {
    return '';
  }
}

function blocksFromOutput({ key = '', title = '', conclusion = '', sections = [], rows = [], sources = [], markdown = '' } = {}) {
  const blocks = [];
  if (String(conclusion || '').trim()) {
    blocks.push({
      object: 'block',
      type: 'callout',
      callout: {
        icon: { type: 'emoji', emoji: '✦' },
        rich_text: chunkRichText('核心结论：' + String(conclusion).trim()),
      },
    });
  }

  const listSections = Array.isArray(sections) ? sections.filter(s => s && (s.title || (Array.isArray(s.bullets) && s.bullets.length))) : [];
  if (listSections.length) {
    for (const sec of listSections) {
      if (String(sec.title || '').trim()) blocks.push(textBlock('heading_2', String(sec.title).trim().slice(0, 200)));
      for (const b of Array.isArray(sec.bullets) ? sec.bullets : []) {
        const clean = String(b || '').trim();
        if (clean) blocks.push(textBlock('bulleted_list_item', clean));
      }
    }
  } else if (String(markdown || '').trim()) {
    for (const rawLine of String(markdown).split('\n')) {
      const line = rawLine.trim();
      if (!line) continue;
      if (/^#{1,3}\s+/.test(line)) blocks.push(textBlock('heading_2', line.replace(/^#{1,6}\s+/, '').slice(0, 200)));
      else if (/^[-*+]\s+/.test(line)) blocks.push(textBlock('bulleted_list_item', line.replace(/^[-*+]\s+/, '')));
      else blocks.push(textBlock('paragraph', line));
    }
  }

  const listRows = Array.isArray(rows) ? rows.filter(r => r && Array.isArray(r.cells) && r.cells.length) : [];
  if (listRows.length) {
    blocks.push(textBlock('heading_2', '对比摘要'));
    for (const r of listRows) {
      const line = r.cells.map(c => String(c || '').trim()).filter(Boolean).join(' · ') + (r.cred ? ` [${r.cred}]` : '');
      if (line.trim()) blocks.push(textBlock('bulleted_list_item', line));
    }
  }

  const listSources = Array.isArray(sources) ? sources.filter(s => s && (s.name || s.title || s.url)) : [];
  if (listSources.length) {
    blocks.push(textBlock('heading_2', '依据来源'));
    for (const s of listSources) {
      const label = String(s.name || s.title || s.url || '来源').trim().slice(0, 400);
      const url = typeof s.url === 'string' && /^https?:\/\//i.test(s.url) ? s.url : '';
      const segs = [...chunkRichText(label, url)];
      const extra = [s.credibility ? ` [${s.credibility}]` : '', s.quote ? ` — 「${String(s.quote).trim()}」` : ''].join('');
      if (extra) segs.push(...chunkRichText(extra));
      if (segs.length) blocks.push(richBlock('bulleted_list_item', segs));
    }
  }

  if (key) blocks.push(textBlock('paragraph', `Citeside-Output-Key: ${key}`));
  return blocks;
}

async function listAuthorizedPages(ctx) {
  const res = await notion.api(ctx, 'POST', 'search', {
    filter: { property: 'object', value: 'page' },
    sort: { direction: 'descending', timestamp: 'last_edited_time' },
    page_size: 20,
  });
  if (!res.ok) return { ok: false, error: res.error || '读取 Notion 页面列表失败', pages: [] };
  const pages = (res.json?.results || [])
    .filter(p => p && p.id)
    .map(p => ({
      id: p.id,
      title: String(notion.titleOf(p) || '未命名页面').slice(0, 160),
      url: String(p.url || ('https://www.notion.so/' + String(p.id).replace(/-/g, ''))),
    }));
  return { ok: true, pages };
}

async function status(ctx = {}, { meetingId = '', includeParents = false } = {}) {
  const disconnected = ctx.env?.NOTION_DISCONNECTED === '1';
  const authSt = disconnected ? { source: 'none', authorized: false, message: '' } : await notionAuth.status(ctx);
  let oauthSt = { configured: false, available: [] };
  try {
    oauthSt = await oauthLink.status({ env: ctx.env || {}, dataDir: ctx.dataDir, fetchImpl: ctx.fetchImpl });
  } catch {}
  const state = ctx.dataDir ? readState(ctx.dataDir) : { version: 1, parentId: '', parentTitle: '', outputs: {} };
  const prefix = meetingId ? `${meetingId}:` : '';
  const syncedOutputs = {};
  for (const [k, v] of Object.entries(state.outputs || {})) {
    if (!meetingId || k === meetingId || k.startsWith(prefix)) {
      syncedOutputs[k] = { pageId: v.pageId, url: v.url, title: v.title, syncedAt: v.syncedAt };
    }
  }
  let candidateParents = [];
  if (authSt.authorized && includeParents) {
    const found = await listAuthorizedPages(ctx);
    if (found.ok) candidateParents = found.pages;
  }
  return {
    oauthConfigured: Boolean(oauthSt.configured && Array.isArray(oauthSt.available) && oauthSt.available.includes('notion')),
    authorized: Boolean(authSt.authorized),
    source: authSt.source || 'none',
    message: authSt.message || '',
    parentId: state.parentId || '',
    parentTitle: state.parentTitle || '',
    syncedOutputs,
    candidateParents,
  };
}

async function setParent(ctx = {}, { parentId = '', parentTitle = '' } = {}) {
  if (!ctx.dataDir) throw Error('缺少数据目录');
  const cleanId = String(parentId || '').trim();
  if (!UUID_RE.test(cleanId)) throw Error('Notion 父页面 ID 无效');
  const cleanTitle = String(parentTitle || '').trim().slice(0, 160);
  return enqueue(ctx.dataDir, () => {
    const state = readState(ctx.dataDir);
    state.parentId = cleanId;
    state.parentTitle = cleanTitle;
    saveState(ctx.dataDir, state);
    return { ok: true, parentId: state.parentId, parentTitle: state.parentTitle };
  });
}

async function appendBatches(ctx, blockParentId, batches) {
  for (const batch of batches) {
    if (!batch.length) continue;
    const r = await notion.api(ctx, 'PATCH', 'blocks/' + encodeURIComponent(blockParentId) + '/children', { children: batch });
    if (!r.ok) throw Error(r.error || '写入 Notion 内容块失败');
  }
}

async function pushOutput(ctx = {}, payload = {}) {
  if (!ctx.dataDir) throw Error('缺少数据目录');
  if (ctx.env?.NOTION_DISCONNECTED === '1') throw Error('尚未授权 Notion，请先在授权页完成标准 Notion OAuth 连接');
  const resolved = await notionAuth.resolve(ctx);
  if (!resolved?.token) throw Error('尚未授权 Notion，请先在授权页完成标准 Notion OAuth 连接');

  const key = String(payload.key || '').trim();
  if (!KEY_RE.test(key)) throw Error('产出标识无效');
  const title = String(payload.title || '').trim().slice(0, 200);
  if (!title) throw Error('缺少产出标题');

  const contentSpec = {
    title,
    conclusion: String(payload.conclusion || ''),
    sections: Array.isArray(payload.sections) ? payload.sections : [],
    rows: Array.isArray(payload.rows) ? payload.rows : [],
    sources: Array.isArray(payload.sources) ? payload.sources : [],
    markdown: String(payload.markdown || ''),
  };
  const digest = crypto.createHash('sha256').update(JSON.stringify(contentSpec)).digest('hex');

  return enqueue(ctx.dataDir, async () => {
    const state = readState(ctx.dataDir);
    const existing = state.outputs[key];
    const nowIso = new Date().toISOString();

    if (existing && existing.digest === digest) {
      return {
        ok: true,
        unchanged: true,
        pageId: existing.pageId,
        url: existing.url,
        title: existing.title,
        syncedAt: existing.syncedAt,
        parentId: state.parentId,
        parentTitle: state.parentTitle,
      };
    }

    if (existing && existing.pageId) {
      if (existing.title !== title) {
        const tr = await notion.api(ctx, 'PATCH', 'pages/' + encodeURIComponent(existing.pageId), {
          properties: { title: { title: chunkRichText(title) } },
        });
        if (!tr.ok) throw Error(tr.error || '更新 Notion 页面标题失败');
      }
      const stamp = nowIso.slice(0, 16).replace('T', ' ');
      const blocks = [
        textBlock('heading_3', `Citeside 增量更新 · ${stamp}`),
        ...blocksFromOutput({ key, ...contentSpec }),
      ];
      await appendBatches(ctx, existing.pageId, batchBlocks(blocks, 100));
      state.outputs[key] = { ...existing, title, digest, syncedAt: nowIso };
      saveState(ctx.dataDir, state);
      return {
        ok: true,
        updated: true,
        pageId: existing.pageId,
        url: existing.url,
        title,
        syncedAt: nowIso,
        parentId: state.parentId,
        parentTitle: state.parentTitle,
      };
    }

    let parentId = '';
    let parentTitle = state.parentTitle || '';
    if (payload.parentId) {
      const explicit = String(payload.parentId).trim();
      if (!UUID_RE.test(explicit)) throw Error('Notion 父页面 ID 无效');
      parentId = explicit;
      if (payload.parentTitle) parentTitle = String(payload.parentTitle).trim().slice(0, 160);
    } else if (state.parentId && UUID_RE.test(state.parentId)) {
      parentId = state.parentId;
    } else if (ctx.env?.NOTION_DOCUMENT_PARENT) {
      parentId = parseParentInput(ctx.env.NOTION_DOCUMENT_PARENT);
    }

    if (!parentId) {
      const found = await listAuthorizedPages(ctx);
      if (!found.ok) return { ok: false, error: found.error };
      const chosen = found.pages.find(p => PREFERRED_PARENTS.includes(p.title)) || found.pages[0];
      if (!chosen) return { ok: false, error: '未找到已授权的 Notion 父页面，请在 Notion 授权页勾选至少一个页面' };
      parentId = chosen.id;
      parentTitle = chosen.title;
      state.parentId = parentId;
      state.parentTitle = parentTitle;
    }

    const blocks = blocksFromOutput({ key, ...contentSpec });
    const batches = batchBlocks(blocks, 100);
    const created = await notion.api(ctx, 'POST', 'pages', {
      parent: { page_id: parentId },
      properties: { title: { title: chunkRichText(title) } },
      children: batches[0] || [],
    });
    if (!created.ok || !created.json?.id) throw Error(created.error || '创建 Notion 页面失败');

    const pageId = created.json.id;
    const url = String(created.json.url || ('https://www.notion.so/' + String(pageId).replace(/-/g, '')));
    if (batches.length > 1) await appendBatches(ctx, pageId, batches.slice(1));

    state.outputs[key] = { pageId, url, title, digest, syncedAt: nowIso };
    saveState(ctx.dataDir, state);
    return {
      ok: true,
      created: true,
      pageId,
      url,
      title,
      syncedAt: nowIso,
      parentId,
      parentTitle,
    };
  });
}

module.exports = { blocksFromOutput, status, setParent, pushOutput };
