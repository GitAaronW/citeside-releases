'use strict';
// TENANT-SECURITY：第三方密钥从 settings.json 明文移进 macOS 钥匙串。
// 这一版只复制、不搬走（见 hydrate 上方说明）；settings.json 记「哪些键已复制并回读校验过」的清单。
// 启用条件：macOS，且启动器设了 THT_SECRET_STORE=keychain（兼容 7603cd8 写过 SECRET_STORE=keychain 的文件）。
// 写钥匙串失败（锁着、被拒、值里有引号换行）就不进清单，status() 里写清哪一项、为什么。
// RELAY_TOKEN 是本机回环口令（页面链接、MCP 桥都直接读文件），不搬。
const fs = require('fs'), path = require('path'), crypto = require('crypto'), { spawnSync } = require('child_process');

const NOT_SECRET = new Set(['RELAY_TOKEN']);
const isSecretKey = k => /(_API_KEY|_TOKEN|_SECRET|_ACCESS_KEY|_APP_KEY)$/.test(k) && !NOT_SECRET.has(k);
const cache = new Map();          // service\0key → 值（本进程内）
const known = new Set();          // 本进程见过的密钥值，给日志脱敏用
let lastStatus = { mode: 'file', keys: [], errors: [] };

const bin = env => env.THT_SECURITY_BIN || '/usr/bin/security';
const service = dataDir => 'Citeside ' + crypto.createHash('sha1').update(path.resolve(dataDir)).digest('hex').slice(0, 8);
function enabled(raw = {}, env = process.env) {
  if (env.THT_SECRET_STORE === 'file') return false;
  if (process.platform !== 'darwin' && !env.THT_SECURITY_BIN) return false;
  return env.THT_SECRET_STORE === 'keychain' || raw.SECRET_STORE === 'keychain';
}
const remember = v => { if (typeof v === 'string' && v.trim().length >= 8) known.add(v.trim()); };

function kcRead(svc, key, env) {
  const id = svc + '\0' + key;
  if (cache.has(id)) return { ok: true, value: cache.get(id) };
  const r = spawnSync(bin(env), ['find-generic-password', '-s', svc, '-a', key, '-w'], { encoding: 'utf8', timeout: 3000 });
  if (r.status !== 0) return { ok: false, reason: r.error ? r.error.code || '无法调用钥匙串' : '钥匙串里没有这一项或拒绝读取' };
  const value = String(r.stdout || '').replace(/\n$/, '');
  cache.set(id, value); return { ok: true, value };
}
// 值走 stdin（security -i），不出现在进程参数里。
function kcWrite(svc, key, value, env) {
  if (/["\\\r\n]/.test(value)) return { ok: false, reason: '值里有引号、反斜杠或换行，钥匙串命令行无法安全写入' };
  const r = spawnSync(bin(env), ['-i'], { input: `add-generic-password -U -s "${svc}" -a "${key}" -w "${value}"\n`, encoding: 'utf8', timeout: 5000 });
  if (r.error) return { ok: false, reason: r.error.code || '无法调用钥匙串' };
  cache.delete(svc + '\0' + key);
  const back = kcRead(svc, key, env);
  if (!back.ok || back.value !== value) { cache.delete(svc + '\0' + key); return { ok: false, reason: '写入后读回不一致' }; }
  return { ok: true };
}
function kcDelete(svc, key, env) {
  cache.delete(svc + '\0' + key);
  spawnSync(bin(env), ['delete-generic-password', '-s', svc, '-a', key], { encoding: 'utf8', timeout: 5000 });
}

// 10-26 版是「复制，不搬走」（总控 10-23 定）：
//   - 写：密钥复制进钥匙串，回读一致才把键名记进 SECRET_KEYS_IN_KEYCHAIN；settings.json 里的原值不清空，也不写 SECRET_STORE 标记。
//     旧版程序只读 settings.json，照样拿得到密钥，可以随时回退。
//   - 读：清单里的键先从钥匙串读（非交互、3 秒超时、失败 60 秒内不再试）；读不到就用 settings.json 的值，转写 / 模型 / Slack 不停。
//     两边都有值又不一致时以 settings.json 为准（多半是旧版程序或手改写进去的新值），下次保存时再同步进钥匙串。
//   清空 settings.json 里的明文留到 Aaron 确认钥匙串可用之后的下一版。
const failedAt = new Map();   // service\0key → 上次读失败的时间
function kcReadSoft(svc, key, env) {
  const id = svc + '\0' + key, t = failedAt.get(id);
  if (t && Date.now() - t < 60e3) return { ok: false, reason: '钥匙串刚刚读失败，暂用 settings.json' };
  const r = kcRead(svc, key, env);
  if (r.ok) failedAt.delete(id); else failedAt.set(id, Date.now());
  return r;
}

// 文件内容 → 带真实密钥的配置。
function hydrate(raw, dataDir, env = process.env) {
  const out = { ...raw };
  for (const [k, v] of Object.entries(out)) if (isSecretKey(k)) remember(v);
  if (!enabled(raw, env)) { lastStatus = { mode: 'file', keys: [], errors: [], fromKeychain: [], fromFile: [] }; return out; }
  const svc = service(dataDir), errors = [], fromKeychain = [], fromFile = [];
  const keys = Array.isArray(raw.SECRET_KEYS_IN_KEYCHAIN) ? raw.SECRET_KEYS_IN_KEYCHAIN : [];
  for (const k of keys) {
    const fileValue = typeof out[k] === 'string' ? out[k] : '';
    const r = kcReadSoft(svc, k, env);
    if (r.ok && r.value && (!fileValue || fileValue === r.value)) { out[k] = r.value; remember(r.value); fromKeychain.push(k); continue; }
    if (fileValue) { fromFile.push(k); if (!r.ok) errors.push({ key: k, reason: r.reason + '（已改用 settings.json）' }); continue; }
    out[k] = ''; errors.push({ key: k, reason: r.ok ? '钥匙串里是空值' : r.reason });
  }
  lastStatus = { mode: 'keychain-copy', keys: keys.slice(), errors, fromKeychain, fromFile };
  return out;
}

// 带真实密钥的配置 → 写进文件的内容：密钥照原样留在文件里，另复制一份进钥匙串。
function persist(full, dataDir, env = process.env, previous = {}) {
  if (!enabled({ ...previous, ...full }, env)) return full;
  const svc = service(dataDir), out = { ...full }, errors = [];
  const before = new Set(Array.isArray(previous.SECRET_KEYS_IN_KEYCHAIN) ? previous.SECRET_KEYS_IN_KEYCHAIN : []);
  const now = new Set();
  for (const [k, v] of Object.entries(full)) {
    if (!isSecretKey(k) || typeof v !== 'string') continue;
    if (!v) {
      // 文件里原来有值、这次被清空 = 用户删掉了这把钥匙：钥匙串里的副本一起删。原来就是空（7603cd8 搬走过的旧文件）则保留副本。
      if (before.has(k) && !previous[k]) now.add(k); else if (before.has(k)) kcDelete(svc, k, env);
      continue;
    }
    remember(v);
    const cur = cache.get(svc + '\0' + k);
    const w = cur === v ? { ok: true } : kcWrite(svc, k, v, env);
    if (w.ok) now.add(k); else errors.push({ key: k, reason: w.reason });
  }
  delete out.SECRET_STORE;
  if (now.size) out.SECRET_KEYS_IN_KEYCHAIN = [...now].sort(); else delete out.SECRET_KEYS_IN_KEYCHAIN;
  lastStatus = { mode: 'keychain-copy', keys: [...now].sort(), errors, fromKeychain: [], fromFile: [] };
  return out;
}

// 还没复制进钥匙串的密钥（启动时据此决定要不要补一次复制）。
function pendingCopy(raw = {}) {
  const done = new Set(Array.isArray(raw.SECRET_KEYS_IN_KEYCHAIN) ? raw.SECRET_KEYS_IN_KEYCHAIN : []);
  return plaintextKeys(raw).filter(k => !done.has(k));
}

// 给不走 config.js 的小工具（tht-slack、网页搜索等）用：读文件并补回钥匙串里的密钥。
function readSettings(dataDir, env = process.env) {
  const raw = JSON.parse(fs.readFileSync(path.join(dataDir, 'settings.json'), 'utf8'));
  return hydrate(raw, dataDir, env);
}

// 文件里还剩几项明文密钥（设置页 / 自检用，只给键名不给值）。
function plaintextKeys(raw = {}) {
  return Object.entries(raw).filter(([k, v]) => isSecretKey(k) && typeof v === 'string' && v).map(([k]) => k).sort();
}
// 明确要删的密钥：钥匙串删掉，返回要写回文件的内容（清单里去掉这几项）。
function forget(raw, keys, dataDir, env = process.env) {
  const svc = service(dataDir), drop = new Set(keys);
  for (const k of drop) kcDelete(svc, k, env);
  const out = { ...raw };
  for (const k of drop) if (isSecretKey(k)) out[k] = '';
  if (Array.isArray(out.SECRET_KEYS_IN_KEYCHAIN)) out.SECRET_KEYS_IN_KEYCHAIN = out.SECRET_KEYS_IN_KEYCHAIN.filter(k => !drop.has(k));
  return out;
}
// 整块凭据（OAuth 令牌组）：开了钥匙串就存钥匙串（JSON 先转 base64，避开引号），否则写 fallbackFile（0600）。
// 两处只存一处：写钥匙串成功就删掉 fallbackFile，免得明文留底。
function putBlob(dataDir, name, obj, { useKeychain, fallbackFile, requireKeychain = false }, env = process.env) {
  const text = JSON.stringify(obj);
  if (useKeychain) {
    const w = kcWrite(service(dataDir), name, Buffer.from(text).toString('base64'), env);
    if (w.ok) { try { fs.rmSync(fallbackFile, { force: true }); } catch (e) {} return { ok: true, where: 'keychain' }; }
  }
  if (requireKeychain) return { ok: false, where: 'unavailable' };
  fs.mkdirSync(path.dirname(fallbackFile), { recursive: true, mode: 0o700 });
  require('./durable-json').writeText(fallbackFile, text);
  return { ok: true, where: 'file' };
}
function getBlob(dataDir, name, { useKeychain, fallbackFile }, env = process.env) {
  try { return JSON.parse(fs.readFileSync(fallbackFile, 'utf8')); } catch (e) {}
  if (!useKeychain) return null;
  const r = kcRead(service(dataDir), name, env);
  if (!r.ok) return null;
  try { return JSON.parse(Buffer.from(r.value, 'base64').toString('utf8')); } catch (e) { return null; }
}
function dropBlob(dataDir, name, { fallbackFile }, env = process.env) {
  kcDelete(service(dataDir), name, env);
  try { fs.rmSync(fallbackFile, { force: true }); } catch (e) {}
}
const status = () => ({ ...lastStatus, errors: lastStatus.errors.map(e => ({ ...e })) });
const knownSecrets = () => [...known];

module.exports = { isSecretKey, enabled, hydrate, persist, forget, readSettings, plaintextKeys, pendingCopy, status, knownSecrets, service, putBlob, getBlob, dropBlob, _cache: cache };
