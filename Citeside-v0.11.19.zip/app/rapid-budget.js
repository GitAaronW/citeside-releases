'use strict';
// B20: quality is judged by the model; this pass only removes repeated content.
const STOP = new Set('the a an and or but of to in on for with at by from as is are was were be been being this that these those it its they them their we our you your he she his her i me my not no yes so if then than too very can could should would will may might must do does did have has had just also still yet about into over more most less such any some all each other there here what which who whom when where why how only own same both few out up down off again further once one two let lets ask asks asked question questions point points need needs needed whether yet unanswered answered someone nobody anyone meeting team'.split(' '));
const words = t => new Set((String(t || '').toLowerCase().match(/[a-z][a-z0-9'-]{2,}/g) || []).map(w => w.replace(/'s$|s$/, '')).filter(w => w.length > 2 && !STOP.has(w)));
function sameEnglish(a, b) {
  const x = words(a), y = words(b); if (x.size < 3 || y.size < 3) return false;
  let both = 0; for (const w of x) if (y.has(w)) both++;
  return both >= 3 && (both / (x.size + y.size - both) >= 0.4 || both / Math.min(x.size, y.size) >= 0.6);
}
// Keep all distinct points, including multiple useful points on the same topic.
function pick(candidates, { shown = [], nowSec = 0 } = {}) {
  const seen = (shown || []).filter(c => c && c.lane === 'fast' && !c.stale && Number.isFinite(c.at) && c.at >= 0 && c.at <= nowSec + 1);
  const fresh = [];
  for (const c of candidates || []) {
    if (!c || seen.some(r => sameEnglish(c.point, r.point))) continue;
    fresh.push(c); seen.push(c);
  }
  return fresh;
}
module.exports = { pick, sameEnglish };
