'use strict';
// DELETE-EXPORT（2026-10-23）：用户导出、删除范围、断开连接、注销本机数据。全部只动这台 Mac，不加任何上云链路。
//   导出：一场会的纪要 + 逐字稿 → Markdown 文件（或原始 JSON），浏览器直接下载。
//   删除范围：删一场会之前先列清楚本机会删哪些、哪些只隐藏、哪些在供应商那边删不到。
//   断开连接：清掉 settings.json 里该服务的凭据（读取方每次现读 settings，清了就不再读）；飞书登录归命令行工具，不代为注销。
//   注销：清空本机数据目录（凭据一并清空、不再从安装包预置里补回），要求输入确认词；做完要重启citeside。
// 保留期限（回收 30 天）由 Aaron 在数据策略里定，这里不改。
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const sha16 = id => crypto.createHash('sha256').update(String(id)).digest('hex').slice(0, 16);

// ——— 导出 ———
function safeName(s) { return String(s || '会议').replace(/[\\/:*?"<>|\n\r\t]+/g, ' ').trim().slice(0, 80) || '会议'; }
function exportMeeting(session, note, share, format) {
  const base = safeName((share.fileNameOf ? share.fileNameOf(session) : '').replace(/\.md$/, '') || session.topicTitle || session.title || session.id);
  if (format === 'json') {
    const body = JSON.stringify({ v: 1, exportedAt: new Date().toISOString(), note: note || '', session }, null, 1);
    return { filename: base + '.json', type: 'application/json; charset=utf-8', body };
  }
  return { filename: base + '.md', type: 'text/markdown; charset=utf-8', body: share.buildMarkdown(session, note) };
}
const disposition = name => "attachment; filename=\"export\"; filename*=UTF-8''" + encodeURIComponent(name);

// ——— 删除范围：本机删掉的 / 只隐藏的 / 供应商那边的 ———
const VENDOR = [
  { where: 'Notion', what: '会后推过去的纪要页（Citeside · 会议纪要 下的子页，以及更早纪要父页里的子页）', how: '在 Notion 里手动删；Citeside本机队列会一起删掉，不再推' },
  { where: '飞书', what: '归档文档、我来做建的任务、分享发出的私聊', how: '在飞书里手动删' },
  { where: 'Slack', what: '分享发出的消息和文件', how: '在 Slack 里手动删' },
  { where: '语音转写 / 模型供应商', what: '会中送过去转写或分析的音频与文字（设置页里配了哪几家就是哪几家）', how: '按各家保留政策处理，Citeside无法远程删除，也不承诺已彻底清除' },
  { where: '本机镜像', what: '记忆投影目录里的会议索引镜像、夜间决策板备份', how: '索引行会同步删；备份文件按各自管线的保留期' }
];
const HIDDEN = [
  '工作台 / 项目里引用这场会的条目（只隐藏，不改原记录）',
  '母文档里指向这场会的链接（只隐藏）',
  '分享记录、发送回执、会议看板任务（不含会议原文）'
];
function scope(items) {
  const label = it => it.kind === 'file' ? path.basename(path.dirname(it.from)) + '/' + path.basename(it.from) : it.kind;
  return {
    local: items.filter(it => !it.missing).map(it => ({ item: label(it), size: it.size || 0 })),
    hiddenOnly: HIDDEN,
    vendor: VENDOR,
    retention: '删除先进回收，30 天内可恢复，30 天后本机彻底删除'
  };
}

// ——— 断开连接 ———
// 只清 settings.json 里的凭据；off 的那几项是本机开关，清凭据之外顺带关掉写出。
const SERVICES = {
  slack: { name: 'Slack', clear: ['SLACK_BOT_TOKEN', 'SLACK_USER_TOKEN', 'SLACK_TEAM_NAME', 'SLACK_SELF_ID', 'SLACK_SELF_DM'] },
  notion: { name: 'Notion', clear: ['NOTION_TOKEN', 'NOTION_MINUTES_PARENT', 'NOTION_DOCUMENT_PARENT'], set: { NOTION_MINUTES: 'off', MY_TASKS: 'off', NOTION_DISCONNECTED: '1' }, note: 'claude.ai 上的 Notion 连接器归 claude.ai 管，要彻底撤销请在 claude.ai 设置里断开' },
  deepgram: { name: 'Deepgram', clear: ['DEEPGRAM_API_KEY'] },
  // 模型接口的密钥名由适配层给，这里不认厂商
  'model-api': { name: '模型接口', get clear() { return require('./llm').API_KEYS; } },
  volc: { name: '火山语音', clear: ['VOLC_APP_KEY', 'VOLC_ACCESS_KEY'] },
  jev: { name: 'Jev', clear: ['JEV_API_KEY'], set: { JEV_GATE: 'off' } },
  'free-ai': { name: '免费模型', clear: ['FREE_AI_TOKEN', 'FREE_AI_URL'] },
  // 飞书登录归命令行工具管，命令行由工具层给
  lark: { name: '飞书', get manual() { return require('./tools/lark').LOGOUT_COMMAND; }, note: '飞书登录由命令行工具管，其他工具也在用，Citeside不代为注销；需要时在终端运行下面这条命令' }
};
function connections(cfg) {
  return Object.entries(SERVICES).map(([id, s]) => ({ id, name: s.name, connected: s.manual ? null : (s.clear || []).some(k => String(cfg[k] || '').trim()) || Object.entries(s.set || {}).some(([k, off]) => String(cfg[k] || '').toLowerCase() !== off), manual: s.manual || '', note: s.note || '' }));
}
function disconnect(settings, id) {
  const s = SERVICES[id];
  if (!s) throw Object.assign(new Error('不认识的服务'), { status: 400 });
  if (s.manual) return { ok: false, service: id, manual: s.manual, note: s.note };
  const cur = JSON.parse(fs.readFileSync(settings.file, 'utf8'));
  const cleared = (s.clear || []).filter(k => String(cur[k] || '').trim());
  for (const k of s.clear || []) cur[k] = '';
  Object.assign(cur, s.set || {});
  settings.save(cur);
  return { ok: true, service: id, cleared, note: s.note || '' };
}

async function disconnectFull(settings, id) {
  if(id!=='notion')return disconnect(settings,id);
  const env=settings.load(),dataDir=settings.dataDir;
  const link=require('./tools/oauth-link');
  const view=require('./product-account').publicView(dataDir);
  const warnings=[];
  for(const binding of view.bindings.filter(b=>b.provider==='notion')){
    const result=await link.disconnect(binding.key,{env,dataDir});
    if(result.revokeError)warnings.push(result.revokeError);
  }
  const result=disconnect(settings,id);
  return {...result,warnings};
}

// ——— 注销本机数据 ———
const ERASE_WORD = '注销本机数据';
function guardDir(dataDir) {
  const d = path.resolve(String(dataDir || ''));
  if (d === path.parse(d).root || d === path.resolve(require('os').homedir())) throw Object.assign(new Error('数据目录不安全，拒绝注销'), { status: 400 });
  let j = null; try { j = JSON.parse(fs.readFileSync(path.join(d, 'settings.json'), 'utf8')); } catch (e) {}
  if (!j || !j.RELAY_TOKEN) throw Object.assign(new Error('这不是Citeside的数据目录，拒绝注销'), { status: 400 });
  return { dir: d, cfg: j };
}
function sizeOf(p) {
  let n = 0;
  try { const st = fs.lstatSync(p); if (!st.isDirectory()) return st.size; for (const c of fs.readdirSync(p)) n += sizeOf(path.join(p, c)); } catch (e) {}
  return n;
}
function erasePlan(dataDir) {
  const { dir } = guardDir(dataDir);
  const entries = fs.readdirSync(dir).filter(n => n !== 'settings.json').map(n => ({ name: n, bytes: sizeOf(path.join(dir, n)) }));
  return { dataDir: dir, confirmWord: ERASE_WORD, entries, keeps: ['settings.json 里的本机访问口令（凭据全部清空）'], vendor: VENDOR, requiresRestart: true };
}
function erase(dataDir, { confirm, settings } = {}) {
  if (confirm !== ERASE_WORD) throw Object.assign(new Error('确认词不对，没有删除任何东西'), { status: 400 });
  const { dir, cfg } = guardDir(dataDir);
  const removed = [], failed = [];
  for (const n of fs.readdirSync(dir)) {
    if (n === 'settings.json') continue;
    try { fs.rmSync(path.join(dir, n), { recursive: true, force: true }); removed.push(n); } catch (e) { failed.push({ name: n, error: String(e.message || e).slice(0, 200) }); }
  }
  // 凭据全清；PRESET_OPTOUT 让下次启动不再从安装包 preset.json 里把凭据补回来。
  const base = settings && settings.defaults ? { ...settings.defaults } : {};   // 默认值里凭据和目录都是空串
  const next = { ...base, RELAY_TOKEN: cfg.RELAY_TOKEN, PRESET_VERSION: cfg.PRESET_VERSION || '', PRESET_OPTOUT: '1', ERASED_AT: new Date().toISOString() };
  const file = path.join(dir, 'settings.json');
  require('./durable-json').write(file, next, { space: 2 });
  return { ok: !failed.length, removed, failed, vendor: VENDOR, requiresRestart: true };
}

module.exports = { exportMeeting, disposition, scope, VENDOR, SERVICES, connections, disconnect, disconnectFull, ERASE_WORD, erasePlan, erase, sha16 };
