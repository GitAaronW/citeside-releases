'use strict';
// 麦克风 + 系统声混成一路送火山时，外放的远端声会被麦克风再录一遍：
// 同一句话紧接着以另一个说话人身份再出一次（有时只剩后半句、多一两个字）。
// 认回声的条件（三条同时满足）：同一识别流；开始时刻紧贴上一句结束（≤1.5s）；
// 文本与上一句几乎一样，或是上一句的尾巴。真人重复别人的话通常换说法、隔得更久，不会落进这个窗。
const WINDOW_MS = 1500;
const MIN_CHARS = 3;      // 「嗯」「对」「好的」这类短应答允许重复
const SIMILAR = 0.85;     // 公共子序列占较短一句的比例
// 两句的差异里出现否定词或数字，说明是在纠正而不是回声（「可以上线」→「不可以上线」）
const MEANINGFUL = /[不没别非未无勿否\d零一二三四五六七八九十百千万亿两]/u;

function norm(text) { return [...String(text || '').replace(/[\s\p{P}\p{S}]/gu, '').toLowerCase()]; }

// 最长公共子序列对齐；返回公共长度和两句各自没对上的字（按位置，换序的数字也算差异）
function align(a, b) {
  const dp = Array.from({ length: a.length + 1 }, () => new Array(b.length + 1).fill(0));
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++)
      dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
  let i = a.length, j = b.length, extra = '';
  while (i > 0 && j > 0) {
    if (a[i - 1] === b[j - 1]) { i--; j--; }
    else if (dp[i - 1][j] >= dp[i][j - 1]) extra += a[--i];
    else extra += b[--j];
  }
  while (i > 0) extra += a[--i];
  while (j > 0) extra += b[--j];
  return { common: dp[a.length][b.length], extra };
}

function isEchoText(prev, cur) {
  if (cur.length < MIN_CHARS) return false;
  const p = prev.join(''), c = cur.join('');
  if (p === c || p.endsWith(c)) return true;   // 只剩后半句：没有新增内容
  const shorter = Math.min(prev.length, cur.length), longer = Math.max(prev.length, cur.length);
  if (shorter < 4 || longer > shorter * 1.5 + 2) return false;
  const { common, extra } = align(prev, cur);
  return common / shorter >= SIMILAR && !MEANINGFUL.test(extra);
}

function createEchoFilter() {
  const last = new Map();   // 每个识别流只和紧邻的上一句保留句比
  return {
    // 判为回声时返回对应的原句，否则 null。record 为真时，即使像回声也把本句记成下一句的比较对象（正文已经决定留下）。
    check({ streamId = '', text = '', start, end, record = false }) {
      if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
      const n = norm(text), prev = last.get(streamId);
      const echo = !!(prev && start >= prev.start && start - prev.end <= WINDOW_MS && isEchoText(prev.n, n));
      if (echo && !record) return prev;
      last.set(streamId, { n, start, end, text });
      return echo ? prev : null;
    },
  };
}

module.exports = { createEchoFilter, isEchoText, norm, WINDOW_MS };
