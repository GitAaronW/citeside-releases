'use strict';
// 方法论实验开关（exp/method-hats-20261024，只给回放对比用，不进发布）：
//   THT_METHODS=hats          六顶思考帽找缺
//   THT_METHODS=refclass      参考类预测 + ICD 203 置信度用语
//   THT_METHODS=hats,refclass 两个一起
//   THT_METHODS=brief         只开卡片篇幅硬上限（正文一句 ≤30 字、动作一句 ≤20 字）
//   THT_METHODS=source        外部卡必须带可查的出处，没有就不出（method-source.js；独立开关，不连带 brief）
// brief 在任一方法开关打开时自动打开（Aaron 10-25 定的卡片格式：方法标签 + 一句话正文 + 一句话动作），也可单独开。
function flags() {
  const s = String(process.env.THT_METHODS || '').toLowerCase();
  const hats = /\bhats\b/.test(s), refclass = /\brefclass\b/.test(s), source = /\bsource\b/.test(s);
  return { hats, refclass, source, brief: hats || refclass || /\bbrief\b/.test(s) };
}
module.exports = { flags };
