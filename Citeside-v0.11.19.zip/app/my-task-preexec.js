'use strict';
// My Task Pre-Execution ("我的任务提前试跑 + 一进两出", V2):
// - Attribution routing: others' todos produce 0 live interruptions and go silently
//   to post-meeting minutes; only my / ambiguous tasks enter pre-execution.
// - Reversible 3-state machine: pending_confirm <-> running (AbortController cancel)
//   -> ready <-> ignored (anytime restore).
// - Exit A (handoff): always available across all 3 states; supports non-MCP
//   full-Prompt copy (0 Citeside quota) and MCP direct dispatch.
// - Exit B (revise): genuine in-place draft rewrite (never lazy append) or
//   unified in-place Q&A thread.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const journal = require('./session-journal');

const PREFS_FILE = 'my-task-preexec-prefs.json';
const VALID_STATUSES = ['pending_confirm', 'running', 'ready', 'ignored'];
const VALID_CATEGORIES = ['pure_draft', 'ambiguous_heavy'];
const controllers = new Map();

const squeeze = s => String(s || '').replace(/\s+/g, ' ').trim();

function sanitizeHumanText(s, maxLen = 2000) {
  return String(s || '')
    .replace(/\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?\b/g, '')
    .replace(/\bt=\d+s\b/gi, '')
    .replace(/\bHTTP\s*\d{3}\b/gi, '')
    .replace(/\bS\d+\b/g, '参会人')
    .replace(/\s+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, maxLen);
}

function prefsPath(dataDir) {
  return dataDir ? path.join(dataDir, 'state', PREFS_FILE) : '';
}

function getPrefs(dataDir) {
  const file = prefsPath(dataDir);
  const defaults = { autoRunPureDraft: true, mcpConnected: false };
  if (!file) return defaults;
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    return {
      autoRunPureDraft: typeof raw?.autoRunPureDraft === 'boolean' ? raw.autoRunPureDraft : true,
      mcpConnected: typeof raw?.mcpConnected === 'boolean' ? raw.mcpConnected : false
    };
  } catch {
    return defaults;
  }
}

function setPrefs(dataDir, patch = {}) {
  const next = {
    ...getPrefs(dataDir),
    ...(typeof patch.autoRunPureDraft === 'boolean' ? { autoRunPureDraft: patch.autoRunPureDraft } : {}),
    ...(typeof patch.mcpConnected === 'boolean' ? { mcpConnected: patch.mcpConnected } : {})
  };
  const file = prefsPath(dataDir);
  if (file) journal.write(file, next);
  return next;
}

function ensureStore(session) {
  if (!session || typeof session !== 'object') throw Error('session_required');
  if (!session.myTaskPreexec || typeof session.myTaskPreexec !== 'object') {
    session.myTaskPreexec = { items: [] };
  }
  if (!Array.isArray(session.myTaskPreexec.items)) session.myTaskPreexec.items = [];
  if (!Array.isArray(session.silentOtherTodos)) session.silentOtherTodos = [];
  return session.myTaskPreexec;
}

function ctrlKey(session, taskId) {
  return `${session?.id || 'local'}:${taskId}`;
}

function abortControllerFor(session, taskId) {
  const key = ctrlKey(session, taskId);
  const ac = controllers.get(key);
  if (ac) {
    try { ac.abort(); } catch {}
    controllers.delete(key);
  }
}

function classifyOwner(input = {}) {
  if (['me', 'other', 'ambiguous'].includes(input.owner)) return input.owner;
  if (input.isMe === true) return 'me';
  const text = squeeze(input.quote || input.text || input.title || '');
  if (/^(?:我|本人)(?:散会后|会后|明天|周五|这周|下周|来|负责|发|写|整理|起草|准备|给)/.test(text) || /交给我|我来写|我来起草|我发给|我整理/.test(text)) {
    return 'me';
  }
  if (/谁来|看看谁|待定|一起评估|顺便把/.test(text)) return 'ambiguous';
  if (input.speaker && !input.isMe && /我(?:散会后|会后|明天|来|负责|发|写|整理)/.test(text)) {
    return 'other';
  }
  return 'ambiguous';
}

function classifyCategory(input = {}) {
  if (VALID_CATEGORIES.includes(input.category)) return input.category;
  const text = squeeze(input.title || input.quote || input.text || '');
  const heavy = /评估框架|报价阶梯|法务|SLA|架构方案|路线图|跨团队|谁来牵头/.test(text);
  if (heavy || classifyOwner(input) === 'ambiguous') return 'ambiguous_heavy';
  return 'pure_draft';
}

function defaultParagraphs(session, task) {
  const meetingName = sanitizeHumanText(session?.title || '本次会议', 80);
  const title = sanitizeHumanText(task.title, 100);
  const quote = sanitizeHumanText(task.quote || '', 240);
  const constraints = Array.isArray(task.memoryConstraints) && task.memoryConstraints.length
    ? task.memoryConstraints.map(c => `- ${sanitizeHumanText(c, 160)}`).join('\n')
    : '- 仅基于本场会议已确认的事实表述，未确认事项单独标注待复核。';
  return [
    `${title}（初稿）`,
    `基于「${meetingName}」沟通要点整理，供直接复用或按需微调。`,
    quote ? `一、会中明确诉求\n${quote}` : `一、核心要点\n围绕「${title}」整理可执行初稿内容。`,
    `二、关键事实与边界约束\n${constraints}`,
    '三、下一步确认\n如需补充细节、调整语气或限定时间节点，可直接发送修改意见原地更新正文。'
  ];
}

function ingest(session, candidate = {}, opts = {}) {
  const store = ensureStore(session);
  const owner = classifyOwner(candidate);
  const title = sanitizeHumanText(candidate.title || candidate.text || '', 120);
  if (!title) throw Error('task_title_required');
  const quote = sanitizeHumanText(candidate.quote || candidate.text || '', 300);

  // Attribution routing: others' todos never interrupt or enter pre-execution.
  if (owner === 'other') {
    const rec = {
      id: 'other-' + crypto.randomBytes(6).toString('hex'),
      owner: 'other',
      assignee: sanitizeHumanText(candidate.speaker || candidate.assignee || '参会人', 40),
      title,
      quote,
      recordedAt: (opts.now || Date.now)()
    };
    session.silentOtherTodos.push(rec);
    return { routed: 'silent_other', item: rec };
  }

  const category = classifyCategory({ ...candidate, owner, title, quote });
  const id = squeeze(candidate.id) || ('task-' + crypto.randomBytes(6).toString('hex'));
  const existing = store.items.find(x => x.id === id);
  if (existing) return { routed: 'existing', item: existing };

  const confirmHeadline = sanitizeHumanText(
    candidate.confirmHeadline || (category === 'ambiguous_heavy' ? `是否由你牵头起草「${title.slice(0, 24)}」？` : `后台起草「${title.slice(0, 26)}」？`),
    44
  );
  const item = {
    id,
    owner,
    category,
    title,
    confirmHeadline,
    quote,
    memoryConstraints: Array.isArray(candidate.memoryConstraints)
      ? candidate.memoryConstraints.map(x => sanitizeHumanText(x, 180)).filter(Boolean).slice(0, 6)
      : [],
    status: 'pending_confirm',
    prevStatus: 'pending_confirm',
    paragraphs: Array.isArray(candidate.paragraphs) ? candidate.paragraphs.map(p => sanitizeHumanText(p, 1200)).filter(Boolean) : [],
    draft: '',
    updatedIndices: [],
    thread: [],
    createdAt: (opts.now || Date.now)(),
    updatedAt: (opts.now || Date.now)()
  };
  if (item.paragraphs.length) item.draft = item.paragraphs.join('\n\n');
  store.items.push(item);

  const prefs = getPrefs(opts.dataDir);
  if (owner === 'me' && category === 'pure_draft' && prefs.autoRunPureDraft && opts.autoStart !== false) {
    void startRun(session, item.id, opts);
  }
  return { routed: 'preexec', item };
}

async function generateDraftParagraphs(session, item, { ask, env, signal, delayMs = 0 } = {}) {
  if (delayMs > 0) {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(resolve, delayMs);
      timer.unref?.();
      if (signal) {
        if (signal.aborted) { clearTimeout(timer); reject(Error('aborted')); return; }
        signal.addEventListener('abort', () => { clearTimeout(timer); reject(Error('aborted')); }, { once: true });
      }
    });
  }
  if (signal?.aborted) throw Error('aborted');

  if (typeof ask === 'function') {
    const sys = '你是会议干活助手。直接输出可直接发给对方的中文初稿正文，分段清晰，不要寒暄铺垫，不露任何内部ID或时间戳。返回 JSON {"paragraphs":["段落1","段落2",...]}。';
    const user = JSON.stringify({
      meetingTitle: sanitizeHumanText(session?.title || '', 120),
      taskTitle: item.title,
      quote: item.quote,
      constraints: item.memoryConstraints
    });
    const raw = await ask(sys, user, { purpose: 'my-task-preexec-draft', signal, json: true, env });
    if (signal?.aborted) throw Error('aborted');
    if (typeof raw === 'string' && raw.trim()) {
      try {
        const parsed = JSON.parse(raw.trim().replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, ''));
        if (Array.isArray(parsed?.paragraphs) && parsed.paragraphs.length) {
          const clean = parsed.paragraphs.map(p => sanitizeHumanText(p, 1600)).filter(Boolean);
          if (clean.length) return clean;
        }
      } catch {
        const split = sanitizeHumanText(raw, 4000).split(/\n{2,}/).filter(Boolean);
        if (split.length) return split;
      }
    }
  }
  return defaultParagraphs(session, item);
}

async function startRun(session, taskId, opts = {}) {
  const store = ensureStore(session);
  const item = store.items.find(x => x.id === taskId);
  if (!item) throw Error('task_not_found');
  if (item.status === 'ready') return item;
  if (item.status === 'running') return item;

  abortControllerFor(session, taskId);
  const ac = new AbortController();
  const key = ctrlKey(session, taskId);
  controllers.set(key, ac);

  item.status = 'running';
  item.prevStatus = 'running';
  item.updatedAt = (opts.now || Date.now)();
  opts.onUpdate?.(item);

  try {
    const paragraphs = await generateDraftParagraphs(session, item, {
      ask: opts.ask,
      env: opts.env,
      signal: ac.signal,
      delayMs: Number(opts.delayMs) || 0
    });
    if (ac.signal.aborted || item.status !== 'running') return item;
    item.paragraphs = paragraphs;
    item.draft = paragraphs.join('\n\n');
    item.status = 'ready';
    item.prevStatus = 'ready';
    item.updatedIndices = [];
    item.updatedAt = (opts.now || Date.now)();
    opts.onUpdate?.(item);
    return item;
  } catch (e) {
    if (ac.signal.aborted || String(e?.message) === 'aborted') {
      return item;
    }
    if (item.status === 'running') {
      item.status = 'pending_confirm';
      item.prevStatus = 'pending_confirm';
      item.updatedAt = (opts.now || Date.now)();
      opts.onUpdate?.(item);
    }
    throw e;
  } finally {
    if (controllers.get(key) === ac) controllers.delete(key);
  }
}

function cancel(session, taskId, opts = {}) {
  const store = ensureStore(session);
  const item = store.items.find(x => x.id === taskId);
  if (!item) throw Error('task_not_found');
  abortControllerFor(session, taskId);
  if (item.status === 'running') {
    item.status = 'pending_confirm';
    item.prevStatus = 'pending_confirm';
    item.updatedAt = (opts.now || Date.now)();
    opts.onUpdate?.(item);
  }
  return item;
}

function ignore(session, taskId, opts = {}) {
  const store = ensureStore(session);
  const item = store.items.find(x => x.id === taskId);
  if (!item) throw Error('task_not_found');
  abortControllerFor(session, taskId);
  if (item.status !== 'ignored') {
    item.prevStatus = item.status === 'ready' ? 'ready' : 'pending_confirm';
    item.status = 'ignored';
    item.updatedAt = (opts.now || Date.now)();
    opts.onUpdate?.(item);
  }
  return item;
}

function restore(session, taskId, opts = {}) {
  const store = ensureStore(session);
  const item = store.items.find(x => x.id === taskId);
  if (!item) throw Error('task_not_found');
  if (item.status === 'ignored') {
    item.status = item.prevStatus === 'ready' && item.paragraphs.length ? 'ready' : 'pending_confirm';
    item.updatedAt = (opts.now || Date.now)();
    opts.onUpdate?.(item);
  }
  return item;
}

function isQuestionText(text) {
  const s = squeeze(text);
  return /[？?]$|^(?:为什么|怎么|要不要|是否|能不能|有没有|哪|什么|请问)/.test(s)
    || /(?:风险|建议|怎么看|合不合适|有没有遗漏)/.test(s);
}

function deterministicRewrite(paragraphs, instruction) {
  const paras = (paragraphs.length ? paragraphs : ['初稿正文']).slice();
  const changed = [];
  if (/正式|礼貌|商务|敬语/.test(instruction)) {
    paras[0] = paras[0].replace(/（初稿）$/, '') + '（正式版）';
    changed.push(0);
    if (paras.length > 1) {
      paras[1] = '您好！感谢今日沟通，现将会议确认的核心要点整理如下，敬请审阅指正。';
      changed.push(1);
    }
    const last = paras.length - 1;
    paras[last] = '如贵方需进一步核对细节或补充材料，我方将第一时间配合。顺颂商祺。';
    if (!changed.includes(last)) changed.push(last);
    return { paragraphs: paras, updatedIndices: changed, reply: '已将正文整体改写为更正式的商务语气。' };
  }
  if (/精简|简短|压缩|三点|3点|要点/.test(instruction)) {
    const header = paras[0];
    const compact = [
      header,
      '核心要点精简如下：\n1. 核心结论与交付范围已按会中对齐明确。\n2. 关键事实与边界约束严格遵循已确认口径。\n3. 如需补充条款或确认时间节点，可直接回复推进。'
    ];
    return { paragraphs: compact, updatedIndices: [1], reply: '已将正文原地精简为 3 条核心要点。' };
  }
  if (/时间|截止|周五|17:00|五点|下班前|几点/.test(instruction)) {
    const last = paras.length - 1;
    const cleanTime = instruction.replace(/^[请帮我把给再加]+/, '').replace(/[。！!]+$/, '');
    paras[last] = `时间节点确认：将在 ${cleanTime} 前同步最终版本，如需补充请随时回复。`;
    changed.push(last);
    return { paragraphs: paras, updatedIndices: changed, reply: `已将时间节点直接融入正文第 ${last + 1} 段。` };
  }
  const targetIdx = paras.length >= 2 ? paras.length - 1 : 0;
  const cleanReq = instruction.replace(/^[请帮我把给再]+/, '').replace(/[。！!]+$/, '');
  paras[targetIdx] = paras[targetIdx].replace(/。?$/, '。') + ` ${cleanReq}。`;
  changed.push(targetIdx);
  return { paragraphs: paras, updatedIndices: changed, reply: `已按你的修改意见原地更新正文第 ${targetIdx + 1} 段。` };
}

async function revise(session, taskId, instruction, opts = {}) {
  const store = ensureStore(session);
  const item = store.items.find(x => x.id === taskId);
  if (!item) throw Error('task_not_found');
  if (item.status !== 'ready') throw Error('task_not_ready');
  const text = sanitizeHumanText(instruction, 600);
  if (!text) throw Error('instruction_required');

  const now = (opts.now || Date.now)();
  item.thread.push({ role: 'user', text, at: now });

  if (isQuestionText(text)) {
    let reply = '已结合本场会议内容核对：当前初稿已覆盖已确认要点，未证实事项均已留白。如需调整措辞，直接发修改指令即可原地改写正文。';
    if (typeof opts.ask === 'function') {
      const sys = '你是会议任务助手。基于给定初稿与会议背景简洁回答用户追问，不露内部ID或时间戳，≤120字。';
      const raw = await opts.ask(sys, JSON.stringify({ title: item.title, draft: item.draft, question: text }), { purpose: 'my-task-preexec-qa', env: opts.env });
      if (typeof raw === 'string' && raw.trim()) reply = sanitizeHumanText(raw, 400);
    }
    item.thread.push({ role: 'ai', text: reply, at: (opts.now || Date.now)() });
    item.updatedAt = (opts.now || Date.now)();
    opts.onUpdate?.(item);
    return { kind: 'answer', reply, updatedIndices: [], item };
  }

  let nextParas = null;
  let updatedIndices = [];
  let reply = '';

  if (typeof opts.ask === 'function') {
    const sys = '你是会议初稿编辑。根据用户修改意见，直接原地改写给定段落数组（绝不在末尾拼敷衍备注），返回严格 JSON {"paragraphs":["..."],"updatedIndices":[0],"reply":"一句简短改写说明"}。';
    const raw = await opts.ask(sys, JSON.stringify({ title: item.title, paragraphs: item.paragraphs, instruction: text }), { purpose: 'my-task-preexec-revise', json: true, env: opts.env });
    if (typeof raw === 'string' && raw.trim()) {
      try {
        const parsed = JSON.parse(raw.trim().replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, ''));
        if (Array.isArray(parsed?.paragraphs) && parsed.paragraphs.length) {
          nextParas = parsed.paragraphs.map(p => sanitizeHumanText(p, 1600)).filter(Boolean);
          updatedIndices = Array.isArray(parsed.updatedIndices) ? parsed.updatedIndices.filter(n => Number.isInteger(n) && n >= 0 && n < nextParas.length) : [0];
          reply = sanitizeHumanText(parsed.reply || '已按你的要求原地改写正文。', 200);
        }
      } catch {}
    }
  }

  if (!nextParas || !nextParas.length) {
    const out = deterministicRewrite(item.paragraphs, text);
    nextParas = out.paragraphs;
    updatedIndices = out.updatedIndices;
    reply = out.reply;
  }

  item.paragraphs = nextParas;
  item.draft = nextParas.join('\n\n');
  item.updatedIndices = updatedIndices;
  item.thread.push({ role: 'ai', text: reply, at: (opts.now || Date.now)() });
  item.updatedAt = (opts.now || Date.now)();
  opts.onUpdate?.(item);
  return { kind: 'rewrite', reply, updatedIndices, item };
}

function buildHandoffPrompt(session, item, { checks = {}, extra = '' } = {}) {
  const include = {
    context: checks.context !== false,
    quote: checks.quote !== false,
    memory: checks.memory !== false,
    draft: checks.draft === true && item.status === 'ready'
  };
  const blocks = [];
  blocks.push(`# 任务目标\n请帮我完成：${sanitizeHumanText(item.title, 160)}`);
  if (include.context) {
    const meetingTitle = sanitizeHumanText(session?.title || '本次会议', 120);
    const goal = sanitizeHumanText(session?.meetingScenario?.goal || '', 200);
    blocks.push(`# 会议背景\n会议主题：${meetingTitle}${goal ? `\n本场目标：${goal}` : ''}`);
  }
  if (include.quote && item.quote) {
    blocks.push(`# 相关原话摘录\n${sanitizeHumanText(item.quote, 320)}`);
  }
  if (include.memory && item.memoryConstraints?.length) {
    blocks.push(`# 必须遵守的事实与边界约束\n${item.memoryConstraints.map(x => `- ${sanitizeHumanText(x, 180)}`).join('\n')}`);
  }
  if (include.draft && item.draft) {
    blocks.push(`# 当前轻初稿（可在此基础上完善）\n${sanitizeHumanText(item.draft, 3500)}`);
  }
  const cleanExtra = sanitizeHumanText(extra, 400);
  if (cleanExtra) {
    blocks.push(`# 补充要求\n${cleanExtra}`);
  }
  return blocks.join('\n\n');
}

async function handoff(session, taskId, options = {}, opts = {}) {
  const store = ensureStore(session);
  const item = store.items.find(x => x.id === taskId);
  if (!item) throw Error('task_not_found');
  if (item.status === 'ignored') throw Error('task_ignored');

  const mode = options.mode === 'mcp' ? 'mcp' : 'copy';
  const prompt = buildHandoffPrompt(session, item, {
    checks: options.checks || {},
    extra: options.extra || ''
  });

  if (mode === 'mcp') {
    let delivered = true;
    if (typeof opts.dispatchMcp === 'function') {
      const res = await opts.dispatchMcp({ taskId: item.id, title: item.title, prompt });
      delivered = res?.ok !== false;
    }
    return {
      ok: delivered,
      mode: 'mcp',
      quotaConsumed: false,
      prompt,
      status: item.status
    };
  }

  return {
    ok: true,
    mode: 'copy',
    quotaConsumed: false,
    prompt,
    status: item.status
  };
}

function toClientItem(item) {
  return {
    id: item.id,
    owner: item.owner,
    category: item.category,
    title: item.title,
    confirmHeadline: item.confirmHeadline,
    quote: item.quote,
    memoryConstraints: item.memoryConstraints.slice(),
    status: item.status,
    paragraphs: item.paragraphs.slice(),
    draft: item.draft,
    updatedIndices: item.updatedIndices.slice(),
    thread: item.thread.map(m => ({ role: m.role, text: m.text }))
  };
}

function snapshot(session, { dataDir } = {}) {
  const store = ensureStore(session);
  const prefs = getPrefs(dataDir);
  const items = store.items.filter(x => x.status !== 'ignored').map(toClientItem);
  const ignored = store.items.filter(x => x.status === 'ignored').map(toClientItem);
  return {
    prefs,
    activeCount: items.length,
    runningCount: items.filter(x => x.status === 'running').length,
    readyCount: items.filter(x => x.status === 'ready').length,
    ignoredCount: ignored.length,
    silentOtherCount: (session.silentOtherTodos || []).length,
    items,
    ignored
  };
}

module.exports = {
  PREFS_FILE,
  VALID_STATUSES,
  VALID_CATEGORIES,
  getPrefs,
  setPrefs,
  classifyOwner,
  classifyCategory,
  ingest,
  startRun,
  cancel,
  ignore,
  restore,
  revise,
  buildHandoffPrompt,
  handoff,
  snapshot,
  sanitizeHumanText
};
