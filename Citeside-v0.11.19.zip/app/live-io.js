'use strict';
// Large snapshots are cloned once at submission, then serialized/fsynced off the
// event loop. One worker preserves write order, including the final complete flag.
const { Worker, isMainThread, parentPort, workerData } = require('node:worker_threads');
const fs = require('node:fs');
const path = require('node:path');
if (!isMainThread && workerData?.memory) {
  try { const { dataDir, query, projectId } = workerData.memory; const ops = require('./memory-ops'); const cards = ops.retrieve(dataDir, query, { projectId }); parentPort.postMessage({ cards, block: ops.toPromptBlock(cards) }); }
  catch (e) { parentPort.postMessage({ error: e.message }); }
} else if (!isMainThread) {
  parentPort.on('message', ({ id, file, data, op }) => {
    try {
      if(op==='read'){parentPort.postMessage({id,value:JSON.parse(fs.readFileSync(file,'utf8'))});return;}
      fs.mkdirSync(path.dirname(file), { recursive: true });
      if (op === 'raw') require('./durable-json').writeText(file, data);
      else require('./durable-json').write(file, data);
      parentPort.postMessage({ id });
    } catch (e) { parentPort.postMessage({ id, error: e.message }); }
  });
} else {
  let worker, seq = 0;
  const pending = new Map();
  function write(file, data, op = 'write') {
    if (!worker) {
      const w = worker = new Worker(__filename);
      w.on('message', ({ id, error, value }) => {
        const p = pending.get(id); if (!p) return;
        pending.delete(id); error ? p.reject(new Error(error)) : p.resolve(value);
        if (!pending.size) w.unref();
      });
      const fail = error => { if (worker !== w) return; worker = null; for (const p of pending.values()) p.reject(error); pending.clear(); };
      w.on('error', fail);
      w.on('exit', code => fail(new Error('live journal worker exited: ' + code)));
    }
    worker.ref();
    return new Promise((resolve, reject) => {
      const id = ++seq; pending.set(id, { resolve, reject });
      try { worker.postMessage({ id, file, data, op }); }
      catch (e) { pending.delete(id); if (!pending.size) worker.unref(); reject(e); }
    });
  }
  const queues = new Map(), checked = new Map();
  function append(file, text, max = 10 * 1024 * 1024) {
    const next = (queues.get(file) || Promise.resolve()).catch(() => {}).then(async () => {
      await fs.promises.mkdir(path.dirname(file), { recursive: true });
      if (Date.now() - (checked.get(file) || 0) > 60000) {
        checked.set(file, Date.now());
        const stat = await fs.promises.stat(file).catch(e => { if (e.code !== 'ENOENT') throw e; });
        if (stat?.size > max) await fs.promises.rename(file, file + '.1');
      }
      await fs.promises.appendFile(file, text, { mode: 0o600 });
    });
    queues.set(file, next);
    const clean = () => { if (queues.get(file) === next) queues.delete(file); };
    next.then(clean, clean); return next;
  }
  // Serialize partial writes and drain before fsync/close. Bound buffered audio
  // so a failed/slow disk cannot consume unlimited memory during a meeting.
  function audio(fd, onError = () => {}, maxBytes = 16 * 1024 * 1024) {
    let tail = Promise.resolve(), bytes = 0, closed = false, failure;
    const call = (fn, ...args) => new Promise((resolve, reject) => fn(...args, (e, n) => e ? reject(e) : resolve(n)));
    const report = e => { failure = e; onError(e); };
    return {
      write(buffer) {
        if (closed || failure) return false;
        if (bytes + buffer.length > maxBytes) { report(new Error('audio disk queue full')); return false; }
        const copy = Buffer.from(buffer); bytes += copy.length;
        tail = tail.then(async () => {
          let offset = 0;
          while (offset < copy.length) {
            const n = await call(fs.write, fd, copy, offset, copy.length - offset, null);
            if (!n) throw new Error('audio write made no progress');
            offset += n;
          }
        }).catch(report).finally(() => { bytes -= copy.length; });
        return true;
      },
      async flush() { await tail; if (failure) throw failure; await call(fs.fsync, fd); },
      async close() {
        if (closed) return; closed = true;
        try { await tail; await call(fs.fsync, fd); }
        finally { await call(fs.close, fd); }
        if (failure) throw failure;
      }
    };
  }
  function retrieve(dataDir, query, projectId) {
    return new Promise((resolve, reject) => {
      const w = new Worker(__filename, { workerData: { memory: { dataDir, query, projectId } } });
      const timer = setTimeout(() => { void w.terminate(); reject(new Error('live memory timeout')); }, 15000);
      w.once('message', result => { clearTimeout(timer); void w.terminate(); result.error ? reject(new Error(result.error)) : resolve(result); });
      w.once('error', e => { clearTimeout(timer); reject(e); });
      w.once('exit', code => { clearTimeout(timer); reject(new Error('live memory exited: ' + code)); });
    });
  }
  module.exports = { write, read: file => write(file, undefined, 'read'), append, audio, retrieve };
}
