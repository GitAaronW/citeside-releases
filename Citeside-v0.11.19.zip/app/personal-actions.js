'use strict';
const {normalizeActionDue}=require('./research-quality');
// Personal work requires a task-bound original quote, never just a model owner label.
const clean = x => String(x || '').trim();
const same = (a,b) => clean(a).toLowerCase() === clean(b).toLowerCase();
const escape = x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function selfNames(session = {}, env = {}) {
  const owner = session.self || session.owner || {};
  return [...new Set([...(Array.isArray(session.selfNames) ? session.selfNames : []),
    typeof owner === 'string' ? owner : owner.displayName || owner.name,
    ...(Array.isArray(owner.aliases) ? owner.aliases : []),
    ...String(env.MEETING_PUSH_SELF_NAMES || '').split(/[,，;；\n]/)].map(clean)
    .filter(n => n && !/^(我|你|本人|me|self)$/i.test(n)))];
}
const TASK_WRAP = new Set('please kindly put together follow up on with for to the a an and or of in at by before after until end day eod cob asap today tomorrow tonight this next week monday tuesday wednesday thursday friday saturday sunday morning afternoon evening noon brief quick short concise summary note notes doc document report table list checklist email message update draft write send over share prepare compile create review check verify test run summarize'.split(' '));
function matchRows(action, rows) {
  const rawEv = clean(action.evidence || (typeof action.said === 'string' ? action.said : '') || action.quote);
  const normEv = rawEv.replace(/\s+/g, ' ');
  if (!normEv) return [];
  const ref = action.sourceRef || action.source_ref;
  const refOk = r => !ref || String(r.segId || r.id) === String(ref);
  const exactWithRef = rows.filter(r => clean(r.text).replace(/\s+/g, ' ') === normEv && refOk(r));
  if (exactWithRef.length) return exactWithRef;
  const exactAny = rows.filter(r => clean(r.text).replace(/\s+/g, ' ') === normEv);
  if (exactAny.length === 1) return exactAny;
  const coreEv = normEv.replace(/[.!?。！？…]+$/g, '').trim();
  if (coreEv.length < 12) return [];
  const subWithRef = rows.filter(r => clean(r.text).replace(/\s+/g, ' ').includes(coreEv) && refOk(r));
  if (subWithRef.length === 1) return subWithRef;
  const subAny = rows.filter(r => clean(r.text).replace(/\s+/g, ' ').includes(coreEv));
  if (subAny.length === 1) return subAny;
  if (ref) {
    const byRef = rows.filter(r => String(r.segId || r.id) === String(ref));
    if (byRef.length === 1) {
      const a = coreEv.replace(/[\s\p{P}]/gu, '').toLowerCase();
      const b = clean(byRef[0].text).replace(/[\s\p{P}]/gu, '').toLowerCase();
      const grams = [...new Set(Array.from({ length: Math.max(0, a.length - 1) }, (_, i) => a.slice(i, i + 2)))];
      if (grams.length >= 6 && grams.filter(g => b.includes(g)).length / grams.length >= 0.7) return byRef;
    }
  }
  return [];
}
function taskGrounded(task, full) {
  const object = task.replace(/^(?:please\s+)?(?:put together|follow up(?:\s+on|\s+with)?|draft|write|send(?:\s+over)?|prepare|compile|create|share|review|check|verify|run|summarize|update)\s+(?:a\s+|an\s+|the\s+)?/i, '').replace(/^(?:整理|查看|编写|起草|撰写|写|发送|发出|汇总|研究|查找|准备|确认|参加|亲自|拍板|负责|请)+/, '').replace(/[\s\p{P}]/gu,'').toLowerCase();
  const quote = full.replace(/[\s\p{P}]/gu,'').toLowerCase();
  const pairs = [...new Set(Array.from({length:Math.max(0,object.length-1)},(_,i)=>object.slice(i,i+2)))];
  if ((pairs.length && pairs.filter(p=>quote.includes(p)).length / pairs.length >= 0.5) || /(?:这个|这件事).{0,8}我来|这个你.{0,12}给我一版/.test(full)) return true;
  // Summarized/bilingual task titles (e.g. "Review PR #402 memory leak fix before EOD" vs bilingual quote)
  // may rephrase time/context wrappers while keeping >=2 concrete technical/domain tokens from the quote.
  const lowFull = full.toLowerCase();
  const stripped = task.replace(/(?:今天|明天|后天|下周|本周|周一|周二|周三|周四|周五|下班前|会后|尽快|帮忙|麻烦|一下|一份|一版|完成|提交|整理|查看|编写|起草|撰写|发送|发出|汇总|准备|确认|的|了|把|将|并|及|与|和)/g, ' ');
  const tokens = [];
  for (const m of stripped.matchAll(/[A-Za-z0-9]{2,}|[\p{Script=Han}]{2,}/gu)) {
    const w = m[0].toLowerCase();
    if (/^[\p{Script=Han}]+$/u.test(w)) {
      for (let i = 0; i + 2 <= w.length; i++) tokens.push(w.slice(i, i + 2));
    } else if (!TASK_WRAP.has(w)) {
      tokens.push(w);
    }
  }
  const uniq = [...new Set(tokens)];
  if (uniq.length < 2) return false;
  const hits = uniq.filter(w => lowFull.includes(w) || (w.length >= 4 && w.endsWith('s') && lowFull.includes(w.slice(0, -1))));
  return hits.length >= 2 && (hits.length >= 3 || hits.some(w => /\d/.test(w)) || hits.length / uniq.length >= 0.3);
}
function personal(action, rows, names) {
  const evidence = clean(action.evidence || (typeof action.said === 'string' ? action.said : '') || action.quote);
  const hasSaid = action.said === true || (action.said !== false && Boolean(evidence));
  if (!names.length || !hasSaid || action.unverified) return null;
  const task = clean(action.do || action.text || action.what);
  const background = action.background === undefined ? clean(action.context || action.why || action.due || task) : clean(action.background);
  if (!evidence || !background || task.length < 5 || /^(这个|那个|这件事|跟一下|看一下(?:这个|那个)?|处理一下)[。！]?$/u.test(task)) return null;
  // Model must bind to a unique utterance; identical quotes from different speakers are ambiguous.
  const matches = matchRows(action, rows);
  if (matches.length !== 1) return null;
  const row = matches[0], full = clean(row.text);
  // A valid assignment quote for task A must not authorize a model-invented task B.
  if (!taskGrounded(task, full)) return null;
  const targets = namedTargets(full, names);
  // 能不能 is polite when the utterance already names someone. Bare negotiation stays blocked.
  // could/can/would/please are requests, not uncertainty. Secondary "don't send/merge externally" guardrails do not cancel an explicit request.
  const hasPositiveAssign = /\b(?:could\s+you|can\s+you|would\s+you|please\s+(?!do\s+not\b|don['’]t\b|note\b)[a-z]+)\b|(?:麻烦你|帮我|请你|请帮|你来)/i.test(full);
  const trimmedGuardrail = hasPositiveAssign ? full
    .replace(/[,，;；.—–\-]\s*(?:just\s+|only\s+|but\s+|and\s+)*(?:do\s+not|don['’]t)\s+(?:send|post|publish|share|email|mail|push|merge|deploy|submit|broadcast|release)\b[^.!?。！？]*/gi, '')
    .replace(/[，,;；。]\s*(?:但是|但|不过|只是|先|切记|注意|千万|暂时)*\s*不要\s*(?:直接|先|立即|马上|对外|自动|急着|随便)?\s*(?:发|外发|群发|发送|发出|合并|合入|推|提交|上线|发布|merge|push|send)[^。！？.!?]*/gi, '')
    : full;
  if (/(?:如果|假如|假设|要不|可以吗|好吗|据说|他说|她说|不用|不需要|取消|已完成|已发)/.test(trimmedGuardrail)) return null;
  if (/(?:^|[，,。；;\s])(?:我|个人)?建议(?:你|由|让|先|下周|大家|我们)/.test(trimmedGuardrail)) return null;
  if (/不要/.test(trimmedGuardrail)) return null;
  if (/已经\s*(?:发|发出|发送|完成|做完|弄完|搞定|结束|取消|写好|整理好|审完)/.test(trimmedGuardrail)) return null;
  if (/(?:^|[.!?;]\s*)if\s+we\b/i.test(trimmedGuardrail) || /\b(?:suppose|hypothetically|he said|she said|rumor has it|do not|don['’]t|no need to|cancel(?:led|ed)?|already (?:sent|done|completed))\b/i.test(trimmedGuardrail)) return null;
  if (/能不能/.test(full) && !targets.length) return null;
  if (!unspecified(action.owner) && !names.some(n => same(n, action.owner))) return null;
  const ownerMatches = names.some(n => same(n, action.owner));
  const speaker = clean(row.speaker || row.name);
  const genericSpeaker = !speaker || /^(?:me|self|myself|我|本人|你|他们|她们|线上|在场|them|unknown)$/i.test(speaker) || /^(?:s|spk_?)?\d+$/i.test(speaker) || /^speaker\s*\d+$/i.test(speaker) || /^说话人\s*\d+$/i.test(speaker);
  const track = row.ownerAttribution || {};
  const reliableTrack = !row.echoMark && track.candidate === true && ['native_dual_track', 'split_track', 'google_meet_self'].includes(track.source) && Number(track.confidence) >= 0.85;
  const namedSpeaker = !row.echoMark && !genericSpeaker && row.speakerUnverified !== true && names.some(n => same(n, speaker));
  const promise = (reliableTrack || namedSpeaker) && (/(?:^|这个|这件事|[，。；：,;:\s])我(?:来|会|负责|回头|稍后|明天|今天)/.test(full) || /\b(?:I['’]ll|I will(?!\s+not)|let me|I can(?!'t|['’]t|\s+not)|I['’]m going to|I am going to)\s+(?:put together|follow up|draft|write|send|prepare|compile|own|handle|take|share|work on|review|check|verify|run|test|update|fix|summarize)\b/i.test(full));
  // Conflicting/mixed assignees always remain in the full list.
  if (targets.some(n => !names.some(self => same(self,n)))) return null;
  const named = targets.some(n => names.some(self => same(self,n)));
  const addressed = row.addressedToSource === 'voiceprint' &&
    names.some(n => same(n,row.addressedTo)) && /你/.test(full);
  if (!(promise || named || (addressed && ownerMatches))) return null;
  return { evidence, sourceRef: String(row.segId || row.id || ''), background,
    owner: names.find(n => same(n, action.owner)) || names[0], kind: promise ? 'promise' : named ? 'assignment' : 'addressed' };
}
// Only explicit vocatives/assignment verbs count; model owner labels never prove self ownership.
const NOT_PERSON = new Set('i you we they he she it this that who what monday tuesday wednesday thursday friday saturday sunday january february march april may june july august september october november december q1 q2 q3 q4 the a an and or for to from with of on in at by as is be do did done please could can would hey hi hello let thanks thank then also just but so now next first still already maybe perhaps however okay ok yes no not before after today tomorrow someone people team folks everyone anybody somebody anyone api soc hipaa vpc sla eod dr mr mrs ms prof note subject re fw fwd'.split(' '));
function englishPeople(raw) {
  const text = clean(raw).replace(/^@+/, '').replace(/^(?:hey|hi|hello)\s+/i, '');
  if (!text) return [];
  const names = [];
  for (const chunk of text.split(/\s+(?:and|&)\s+/i)) {
    const bits = chunk.trim().split(/\s+/).filter(Boolean);
    if (!bits.length || bits.length > 2) continue;
    const tokens = [];
    let ok = true;
    for (const bit of bits) {
      const token = bit.replace(/['’]s$/i, '').replace(/[.,!?;:，。！？；：]+$/g, '');
      if (!/^[A-Z][A-Za-z.'-]{1,25}$/.test(token)) { ok = false; break; }
      if (NOT_PERSON.has(token.toLowerCase()) || /^[A-Z0-9]{2,}$/.test(token) || /^Q[1-4]$/i.test(token)) { ok = false; break; }
      tokens.push(token);
    }
    if (ok && tokens.length) names.push(tokens.join(' '));
  }
  return names;
}
const CJK_BLOCK = new Set('帮我 帮忙 麻烦 拜托 请你 确认 整理 跟进 负责 查看 产品 经理 产品经理 今天 明天 后天 这边 同学 接口 方案 大家 我们 你们 他们 这个 那个 一下 需求 文档 交互 说明 拉齐 版本 同事 团队 用户 本人 自己 什么 怎么 可以 需要 已经 不用 不要 如果 假如 假设 现在 稍后 会后 会后前 下班 设计 设计师 前端 后端 运营 测试 工程师 负责人 事情 这件 一个 一版 一份 补一 看一下 看看 对齐 同步 输出 更新 工作 项目 功能 性能 问题 时间 会议 草稿 邮件 发出 伙伴 英文 过目 千万 直接 你来 你去 我来 我会'.split(/\s+/));
const CJK_AFTER = /^(?:[，,。；;：:\s]|帮我|请帮我|请你|麻烦你|麻烦|拜托|今天|明天|后天|今早|今晚|会后|稍后|现在|下班|来|去|负责|跟进|确认|拉齐|整理|看一下|看看|看|把|给|这|那|的|一下|请|补|发|could\b|can\b|would\b|please\b)/i;
function cjkNameAt(text, index) {
  const rest = text.slice(index);
  const han = rest.match(/^[\p{Script=Han}]{2,4}/u);
  if (!han) return '';
  for (let n = han[0].length; n >= 2; n--) {
    const name = han[0].slice(0, n);
    if (CJK_BLOCK.has(name) || /^(?:你|我|他|她|咱)/.test(name) || /今天|明天|后天|下班|会后|稍后|现在|帮我|请你|请|产品|经理|工程师|负责人|设计师|同学|这边|接口|方案|需求|文档|运营|前端|后端|草稿|邮件|确认|整理|跟进|拉齐|查看|麻烦|拜托|一下/.test(name)) continue;
    const after = rest.slice(n);
    if (after && /^[\p{Script=Han}]/u.test(after) && !CJK_AFTER.test(after)) continue;
    return name;
  }
  return '';
}
function knownVocatives(text, knownNames) {
  const out = [];
  const ordered = [...(Array.isArray(knownNames) ? knownNames : [])].map(clean).filter(n => n && n.length >= 2 && !/^(?:我|你|本人|me|self)$/i.test(n)).sort((a, b) => b.length - a.length);
  let guard = text;
  for (const name of ordered) {
    const han = /^[\p{Script=Han}]+$/u.test(name);
    const boundary = han ? `(?<![\\p{Script=Han}])${escape(name)}(?![\\p{Script=Han}])` : `(?<![A-Za-z])${escape(name)}(?![A-Za-z])`;
    const flags = han ? 'gu' : 'giu';
    if (!new RegExp(boundary, flags).test(guard)) continue;
    const ctx = new RegExp(`(?:麻烦|拜托|交给|请|由|@)\\s*${boundary}|${boundary}\\s*[，,：:]?\\s*(?:帮我|请帮我|麻烦|拜托|请你|你来|你去|你负责|请确认|请跟进|请|could\\s+you|can\\s+you|would\\s+you|please\\b)|${boundary}\\s*(?:帮我|请帮我|请你|麻烦你|你来|你去|负责)`, flags);
    if (ctx.test(text)) out.push(name);
    guard = guard.replace(new RegExp(boundary, flags), ' ');
  }
  return out;
}
function cjkVocatives(text) {
  const out = [];
  const add = name => { const n = clean(name); if (n && !CJK_BLOCK.has(n) && !/^(?:你|我|他|她|咱)/.test(n) && !/产品|经理|工程师|负责人|设计师|同学|这边|今天|明天|会后|草稿|邮件|方案|接口|确认|整理|跟进|拉齐|一下|查看/.test(n)) out.push(n); };
  for (const m of text.matchAll(/(?:麻烦|拜托|交给|请|由)\s*/gu)) add(cjkNameAt(text, m.index + m[0].length));
  for (const m of text.matchAll(/(?:^|\s)@/g)) add(cjkNameAt(text, m.index + m[0].length));
  for (const m of text.matchAll(/(?:^|[，,。；;：:\s])([\p{Script=Han}]{2,4})\s*[，,]\s*(?:帮我|请帮我|麻烦|拜托|请你|你来|你去|你负责|请确认|请跟进|could\s+you|can\s+you|would\s+you|please\b)/giu)) add(m[1]);
  for (const m of text.matchAll(/(?:^|[，,。；;：:\s]|麻烦|拜托|交给|请|由)([\p{Script=Han}]{2,3})(?:帮我|请帮我|请你|麻烦你)/gu)) add(m[1]);
  for (const m of text.matchAll(/(?:交给|由)\s*([\p{Script=Han}]{2,4})\s*(?:来)?(?:跟进|负责)/gu)) add(m[1]);
  return out;
}
function namedTargets(text, knownNames = []) {
  const out=[];
  const src=clean(text);
  const addRaw=name=>{const n=clean(name);if(n)out.push(n);};
  const addEnglish=raw=>{for(const name of englishPeople(raw))out.push(name);};
  for(const m of src.matchAll(/(?:^|[，,。；;])\s*([^，,。；;]{1,40}?)[，,\s]*(?:这个)?你(?:来|去|负责|跟|周|今天|明天|回头|稍后|先|把|给|整理|查看)/g)) addRaw(m[1]);
  for(const m of src.matchAll(/(?:交给|由|请)\s*([^，,。；;\s]{1,20}?)(?=[，,\s]|来|负责)/g)) addRaw(m[1]);
  for(const m of src.matchAll(/(?:^|[，,。；;])\s*([^，,。；;]{1,40}?)\s*(?:负责|来负责)/g)) {
    const name=m[1].trim();
    // A clause starting with a pronoun is task wording, not another assignee.
    if (!/^(?:你|我|他|她|这个|这件事)/.test(name)) addRaw(name);
  }
  for (const m of src.matchAll(/(?:^|[\n.!?;,，；。！？\u2014\u2013])\s*(?:(?:[Hh]ey|[Hh]i|[Hh]ello)\s+)?@?([A-Z][A-Za-z.'-]{1,25}(?:\s+(?:and|&)\s+[A-Z][A-Za-z.'-]{1,25})?)\s*[,:\-\u2013\u2014]\s*(?:[Cc]ould\s+you|[Cc]an\s+you|[Ww]ould\s+you|[Pp]lease)\b/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/(?:^|[\n.!?;,，；。！？\u2014\u2013])\s*@?([A-Z][A-Za-z.'-]{1,25}(?:\s+[A-Z][A-Za-z.'-]{1,25})?)\s*[:\-\u2013\u2014]\s*(?:[Pp]lease\s+)?(?:draft|write|send|prepare|compile|put\s+together|review|check|verify|run|benchmark|share|summarize|update|follow\s+up)\b/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/(?:^|[\s\n.!?;。！？])@([A-Z][A-Za-z.'-]{1,25}(?:\s+[A-Z][A-Za-z.'-]{1,25})?)\s+(?:[Cc]ould\s+you|[Cc]an\s+you|[Ww]ould\s+you|[Pp]lease)\b/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/\b(?:[Aa]ssign(?:ed)?\s+to|[Hh]and(?:ed)?\s+over\s+to|[Oo]ver\s+to|[Ll]eave\s+(?:this\s+|it\s+)?to|[Aa]sk)\s+([A-Z][A-Za-z.'-]*(?:\s+[A-Z][A-Za-z.'-]*)?)/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/\b(?:[Cc]ould|[Cc]an|[Ww]ould)\s+you\s+[^?!.;,]{3,80},\s*([A-Z][A-Za-z.'-]{1,25})\s*[?.!]?/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/\b([A-Z][A-Za-z.'-]{1,25}(?:\s+[A-Z][A-Za-z.'-]{1,25})?)\s+(?:will|is\s+going\s+to|to)\s+(?:draft|write|send|prepare|compile|put\s+together|own|handle|follow\s+up|take\s+care\s+of|share|review|check|verify|run|summarize|update)\b/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/(?:^|[\s，,。；;:\-\u2013\u2014])([A-Z][A-Za-z.'-]{1,25}(?:\s+[A-Z][A-Za-z.'-]{1,25})?)\s*[，,:\-\u2013\u2014]?\s*(?:今天|明天|稍后|会后|现在)?[^，,。；;]{0,24}?(?:帮我|帮忙|麻烦你|请你|请帮|能不能)/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/(?:^|[\s，,。；;])([A-Z][A-Za-z.'-]{1,25})\s*(?:请帮我|帮我|麻烦你)/g)) addEnglish(m[1]);
  for (const m of src.matchAll(/(?:麻烦|拜托)\s*([A-Z][A-Za-z.'-]{1,25}(?:\s+[A-Z][A-Za-z.'-]{1,25})?)/g)) addEnglish(m[1]);
  for (const name of knownVocatives(src, knownNames)) addRaw(name);
  for (const name of cjkVocatives(src)) addRaw(name);
  const prelim = [...new Set(out.map(clean).filter(n => n && !/^(?:麻烦|拜托|帮我|帮忙|能不能|请你|麻烦你)$/.test(n) && !CJK_BLOCK.has(n) && !/确认一下|整理一下|跟进一下|看一下/.test(n)))];
  return prelim.filter(n => !/^[\p{Script=Han}]+$/u.test(n) || !prelim.some(other => other !== n && other.includes(n) && /^[\p{Script=Han}]+$/u.test(other)));
}
const unspecified = n => !clean(n) || /^(?:我|你|本人|自己|self|me|myself|未指定|待定负责人|待定|未知|unknown|unassigned|none|null|待认领|未分配|全员|大家|所有人|S\d+|spk_?\d+|speaker\s*\d+|说话人\s*\d+)$/i.test(clean(n));
function roleKeywordList(names, opts) {
  const out = [], seen = new Set();
  for (const raw of [...(opts && Array.isArray(opts.roleKeywords) ? opts.roleKeywords : []), ...(names && Array.isArray(names.roleKeywords) ? names.roleKeywords : [])]) {
    const kw = clean(raw);
    if (kw.length < 2 || kw.length > 40) continue;
    const key = kw.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key); out.push(kw);
    if (out.length >= 16) break;
  }
  return out;
}
function roleContextBlocked(text) {
  if (/(?:如果|假如|假设|要不|据说|他说|她说|不用|不需要|取消|已完成|已发)/.test(text)) return true;
  if (/(?:^|[.!?;]\s*)if\b/i.test(text)) return true;
  if (/\b(?:suppose|hypothetically|he said|she said|rumor has it|do not|don['’]t|no need to|already (?:sent|done|completed))\b/i.test(text)) return true;
  if (/不要/.test(text) || /已经\s*(?:发|发出|发送|完成|做完|弄完|搞定)/.test(text)) return true;
  return false;
}
function clockBefore(text, index) {
  return /\d\s*$/.test(text.slice(Math.max(0, index - 4), index));
}
function shortCapsAssigns(text, kw) {
  const re = new RegExp(`(?<![A-Za-z])${escape(kw)}(?![A-Za-z])`, 'gi');
  for (const m of text.matchAll(re)) {
    if (clockBefore(text, m.index)) continue;
    const pre = text.slice(0, m.index), post = text.slice(m.index + m[0].length);
    if (/(?:^|\s)@$/.test(pre) || /\bthe\s+$/i.test(pre) || /^\s*[,，:]/.test(post) || /^\s*这边/.test(post) || /^\s*(?:please|could|can|would)\b/i.test(post) || /(?:could|can|would|please)\s+(?:the\s+)?$/i.test(pre)) return true;
  }
  return false;
}
function shortHanAssigns(text, kw) {
  const k = escape(kw);
  return new RegExp(`${k}(?:同学|负责人|这边|工程师)|(?:请|麻烦|拜托|交给)\\s*${k}(?!需)|由\\s*${k}\\s*(?:来)?(?:跟进|负责|确认|拉齐)`, 'u').test(text);
}
function phraseAssigns(text, kw) {
  const k = escape(kw);
  const left = /[A-Za-z]/.test(kw) ? `(?<![A-Za-z])${k}(?![A-Za-z])` : k;
  return new RegExp(`(?:麻烦|拜托|请|交给|由)\\s*${left}|(?:could|can|would)\\s+(?:the\\s+)?${left}|(?:please|ask)\\s+(?:the\\s+)?${left}|@${left}|${left}\\s*[，,:：]\\s*(?:please\\b|could\\b|can\\b|would\\b|请|帮)|${left}\\s*(?:这边\\s*)?(?:会后|今天|明天|稍后|现在)?\\s*(?:请|帮我|来|去|负责|跟进|拉齐|确认|整理|补|看一下|看看|同步|对齐|输出|更新)|${left}\\s+(?:please|could|can|would|will|should)\\b|${left}\\s+(?:follow(?:\\s+up)?|confirm|draft|send|prepare|review|check|own|handle|update|write|pull|sync)\\b`, /[A-Za-z]/.test(kw) ? 'i' : 'u').test(text);
}
function roleAssigned(text, keywords) {
  const src = clean(text);
  if (!src || roleContextBlocked(src)) return false;
  for (const kw of keywords) {
    if (/^pm$/i.test(kw) || (/^[A-Z]{2,3}$/.test(kw) && kw.length <= 3)) { if (shortCapsAssigns(src, kw)) return true; continue; }
    if (/^[\p{Script=Han}]{2}$/u.test(kw)) { if (shortHanAssigns(src, kw)) return true; continue; }
    if (phraseAssigns(src, kw)) return true;
  }
  return false;
}
function classify(action, rows = [], names = [], opts = {}) {
  const list = Array.isArray(names) ? names : [];
  const attribution=personal(action,rows,list);
  const matches=matchRows(action, rows);
  const targets=matches.length===1 ? namedTargets(matches[0].text, list) : [];
  const others=targets.filter(n=>!list.some(self=>same(self,n)));
  const owner=clean(action.owner);
  if(others.length || (!unspecified(owner) && !list.some(n=>same(n,owner))))
    return {group:'all',owner:others.join(' / ')||owner,reason:'other-owner'};
  if(action.attributionReview?.decision==='dismiss') return {group:'all',owner:attribution?.owner||'未指定',reason:'dismissed'};
  if(action.attributionReview?.decision==='claim' && list.length)
    return {group:'mine',owner:list[0],attribution:{owner:list[0],kind:'claimed',evidence:action.evidence,background:action.background},reason:'user-claimed'};
  if(attribution) return {group:'mine',owner:attribution.owner,attribution,reason:attribution.kind};
  const keywords = roleKeywordList(list, opts);
  const task = clean(action.do || action.text || action.what);
  if (matches.length === 1 && keywords.length && taskGrounded(task, clean(matches[0].text)) && roleAssigned(matches[0].text, keywords))
    return {group:'possible', owner:'', reason:'role-keyword-match'};
  // A missing owner alone is no signal that this work might belong to the user.
  const weakText = [action.owner, action.evidence, action.background, action.hint, action.do, action.text].map(clean).join(' ');
  const weak = list.some(n => new RegExp('(^|[^a-z0-9_])' + escape(clean(n)) + '(?=$|[^a-z0-9_])','iu').test(weakText));
  return {group:weak ? 'possible':'all',owner:unspecified(owner) ? (!weak && (owner === '待定负责人' || owner === '未指定') ? '未指定' : '') : owner,reason:weak ? 'ownership-unclear':'no-self-signal'};
}
// Stored attribution is an evidence snapshot, not a model's group/mine flag.
function confirmed(action, names = []) {
  if (action.attributionReview?.decision === 'dismiss') return false;
  if (action.attributionReview?.decision === 'claim') return classify(action,[],names).group === 'mine';
  const a=action.attribution;
  if (!a || (!names.some(n=>same(n,a.owner)) && a.kind !== 'claimed')) return false;
  if (a.kind === 'claimed') return action.attributionReview?.decision === 'claim';
  return !!personal({...action,do:a.evidence,evidence:a.evidence,background:a.background,said:true,sourceRef:''},
    [{text:a.evidence,speaker:a.kind==='promise'?a.owner:'',...(a.kind==='addressed'?{addressedTo:a.owner,addressedToSource:'voiceprint'}:{})}],names);
}
function storedGroups(actions, names, meetingStart) {
  actions=actions.map(a=>{const due=normalizeActionDue(a.due,meetingStart);return due===a.due?a:{...a,due};});
  const allActions=actions.map(a=>confirmed(a,names)?{...a,group:'mine'}:{...a,...classify(a,[],names),owner:a.owner});
  return {myActions:allActions.filter(a=>a.group==='mine'),possibleActions:allActions.filter(a=>a.group==='possible'),allActions};
}
function isRoleOpts(value) {
  return !!value && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date) && (Object.prototype.hasOwnProperty.call(value, 'roleKeywords') || Object.prototype.hasOwnProperty.call(value, 'meetingStart'));
}
function groupActions(actions = [], rows = [], names = [], fourth, fifth) {
  let meetingStart = fourth, opts = fifth || {};
  if (isRoleOpts(fourth)) { opts = fourth; meetingStart = fourth.meetingStart; }
  else if (isRoleOpts(fifth)) opts = fifth;
  actions=(Array.isArray(actions)?actions:[]).map(a=>{const due=normalizeActionDue(a.due,meetingStart);return due===a.due?a:{...a,due};});
  const allActions=actions.map(a=>{const c=classify(a,rows,names,opts);return {...a,...c,attribution:c.attribution||null};});
  return {myActions:allActions.filter(a=>a.group==='mine'),possibleActions:allActions.filter(a=>a.group==='possible'),allActions};
}
module.exports = { selfNames, personal, classify, groupActions, unspecified, confirmed, storedGroups, namedTargets };

