'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
// durable-json 的 tmp 名带 UUID：同一份 enhanced.json 可能被 Node 和 Python 同时写，同名临时文件会互相截断（审查 D3）
function write(file,data){fs.mkdirSync(path.dirname(file),{recursive:true});require('./durable-json').write(file,data);}
// A completed temp file is linked into place without replacing a competing writer.
function writeIfAbsent(file,data){
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const tmp=file+'.tmp.exclusive-'+process.pid+'-'+crypto.randomBytes(12).toString('hex');
  const fd=fs.openSync(tmp,'wx',0o600);
  try{
    try{fs.writeFileSync(fd,JSON.stringify(data));fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
    try{fs.linkSync(tmp,file);return true;}catch(e){if(e.code==='EEXIST')return false;throw e;}
  }finally{try{fs.unlinkSync(tmp);}catch(e){if(e.code!=='ENOENT')throw e;}}
}
function read(file){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return null;}}
module.exports={write,writeIfAbsent,read};
