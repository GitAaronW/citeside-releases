'use strict';
// Local, optional registry. Registration is not evidence that ASR has matched a voice.
// Never infer identity from diarization order, participants, or a preceding sentence.
const fs = require('fs');
const { isSelfEdition } = require('./edition');
const own = (o, k) => Object.prototype.hasOwnProperty.call(o || {}, k);
const idOf = value => typeof value === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value.trim()) ? value.trim().toLowerCase() : '';
function aliases(row) {
  const ids = ['SpeakID', 'SpeakId'].filter(k => own(row, k)).map(k => idOf(row[k]));
  return ids.length && ids.every(Boolean) && new Set(ids).size === 1 ? ids[0] : '';
}
// A receipt is a recorded subject declaration, not proof verified with a provider.
function validConsent(receipt, personId) {
  return !!receipt && receipt.subjectId === personId && receipt.scope === 'voiceprint-identification'
    && receipt.confirmedBySubject === true && !receipt.revokedAt
    && typeof receipt.grantedAt === 'string' && Number.isFinite(Date.parse(receipt.grantedAt))
    && Date.parse(receipt.grantedAt) <= Date.now()
    && typeof receipt.evidenceRef === 'string' && receipt.evidenceRef.trim().length > 0
    && receipt.evidenceRef.length <= 1000 && !/[\x00-\x1f\x7f]/.test(receipt.evidenceRef);
}
function registry(rows, consents = {}) {
  if (!isSelfEdition()) return new Map();
  const result = new Map(), rejected = new Set();
  if (!Array.isArray(rows)) return result;
  for (const row of rows) {
    if (!row || typeof row !== 'object') continue;
    const id = aliases(row), name = typeof row.name === 'string' ? row.name.trim() : '';
    if (!id) {
      for (const key of ['SpeakID', 'SpeakId']) {
        const conflict = idOf(row[key]);
        if (conflict) { rejected.add(conflict); result.delete(conflict); }
      }
      continue;
    }
    if (!validConsent(consents[id], id) || !name || name.length > 80 || /[\x00-\x1f\x7f]/.test(name) || (own(row, 'Status') && row.Status !== 1) || result.has(id)) {
      rejected.add(id); result.delete(id); continue;
    }
    if (!rejected.has(id)) result.set(id, name);
  }
  return result;
}
function load(file, consents) {
  if (!isSelfEdition()) return new Map();
  try { return registry(JSON.parse(fs.readFileSync(file, 'utf8')), consents); } catch { return new Map(); } }
// Group matching needs one GroupID shared by every row; anything mixed means no group.
function groupOf(rows) {
  if (!isSelfEdition()) return '';
  if (!Array.isArray(rows) || !rows.length) return '';
  const ids = new Set(rows.map(row => idOf(row?.GroupID ?? row?.GroupId ?? '')));
  return ids.size === 1 && !ids.has('') ? [...ids][0] : '';
}
// Adds group matching to a streaming request; with no group the request is left untouched.
function requestGroup(req, group) {
  if (!isSelfEdition()) {
    delete req.ssd_mode; delete req.ssd_version; delete req.voiceprints;
    return req;
  }
  if (!group) { delete req.ssd_mode; delete req.voiceprints; return req; }
  if (group) { req.ssd_mode = 2; req.voiceprints = [{ id: '', group_id: group }]; }
  return req;
}
function loadGroup(file, consents) {
  if (!isSelfEdition()) return '';
  try { const rows = JSON.parse(fs.readFileSync(file, 'utf8')), allowed = registry(rows, consents);
    return Array.isArray(rows) && rows.every(row => allowed.has(aliases(row))) ? groupOf(rows) : '';
  } catch { return ''; } }
// Measured 2026-10-23 on Aaron's labelled clips: 0.42 is the lowest floor with no wrong person.
const MIN_SIMILARITY = 0.42;
function groupMatch(utterance, registered) {
  // In group mode the provider writes the matched name into speaker_id. The
  // similarity list on other sentences can repeat the previous sentence's
  // scores, so only a named sentence whose own score clears the floor counts.
  const label = utterance?.additions?.speaker_id;
  if (typeof label !== 'string' || /^\d+$/.test(label.trim()) || !registered?.size) return null;
  const name = label.trim(), matches = utterance?.attributes?.voiceprint_matches;
  if (!Array.isArray(matches)) return null;
  let best = null;
  for (const m of matches) {
    const id = idOf(m?.id);
    if (!id || registered.get(id) !== name || typeof m.similarity !== 'number' || m.similarity < MIN_SIMILARITY) continue;
    if (!best || m.similarity > best.similarity) best = { id, similarity: m.similarity };
  }
  if (!best) return null;
  // One person may own several voiceprints (online and in-room mic); keep one key per person.
  const id = [...registered].find(([, n]) => n === name)[0];
  return { id, name, source: 'provider-group-match', matchedId: best.id, similarity: Math.round(best.similarity * 1000) / 1000 };
}
function resolve(utterance, registered) {
  if (!isSelfEdition()) return null;
  // These are explicit identity fields only. speaker_id=1 is a local diarization
  // label, not the first registered person. No stream-wide propagation is safe.
  const values = [];
  for (const row of [utterance, utterance?.additions]) {
    if (!row || typeof row !== 'object') continue;
    for (const key of ['SpeakID', 'SpeakId']) if (own(row, key)) values.push(idOf(row[key]));
  }
  if (!values.length) return groupMatch(utterance, registered);
  if (values.some(v => !v) || new Set(values).size !== 1) return null;
  const id = values[0], name = registered?.get(id);
  return name ? { id, name, source: 'provider-reported' } : null;
}
function apply(session, utterance, row) {
  if (!isSelfEdition()) return false;
  const identity = resolve(utterance, session.voiceprintRegistry);
  if (!identity) return false;
  row.speakerIdentity = identity;
  // A human label on the original speaker always wins. The stable identity key
  // otherwise keeps numeric speaker labels from transferring names on reconnect.
  if (own(session.names, row.speaker)) return false;
  row.diarizationSpeaker = row.speaker;
  row.speaker = 'vp-' + identity.id;
  if (own(session.names, row.speaker)) return false;
  session.names = { ...session.names, [row.speaker]: identity.name };
  return true;
}
// Public streams may carry a provider name even without a local registry.
function speakerLabel(value) {
  if (value === undefined || value === null) return '';
  const label = String(value);
  return isSelfEdition() || /^\d+$/.test(label.trim()) ? label : '';
}
module.exports = { speakerLabel, validConsent, registry, load, groupOf, loadGroup, requestGroup, resolve, apply, MIN_SIMILARITY };
