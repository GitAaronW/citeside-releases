'use strict';

// Context 来源的 HTTP 薄层：注册表仍由 context-sources.js 管，这里只负责鉴权后的
// CRUD、可读的本机状态，以及将文件系统异常压成不带路径的稳定错误。
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const registry = require('./context-sources');

const clean = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
const apiPath = pathname => String(pathname || '').replace(/^\/asr-relay/, '') === '/context-sources';
const json = (res, status, body) => {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
};
const absolute = value => path.resolve(clean(value, 4000).replace(/^~(?=\/)/, os.homedir()));

function statusOf(source, dataDir) {
  if(['google-drive','mcp','notion'].includes(source.type)) {
    const cached=dataDir&&require('./context-source-cache').read(dataDir,source);
    return {state:cached?.state||'disconnected',available:cached?.state==='ready',kind:source.type,...(source.type==='mcp'?{error:cached?.error||'',coverage:cached?.coverage||null}:{}),modifiedAt:cached?.fetchedAt||'',version:cached?.version||''};
  }
  try {
    const stat = fs.statSync(absolute(source.path));
    const actual = stat.isDirectory() ? 'directory' : stat.isFile() ? 'file' : 'other';
    return {
      state: actual === (source.type === 'obsidian' ? 'directory' : source.type) ? 'ready' : 'type-mismatch',
      available: actual === (source.type === 'obsidian' ? 'directory' : source.type),
      kind: actual,
      modifiedAt: stat.mtime.toISOString(),
      version: `${Math.trunc(stat.mtimeMs)}-${stat.size}`,
    };
  } catch (error) {
    return { state: error && error.code === 'ENOENT' ? 'missing' : 'unreadable', available: false, kind: source.type, modifiedAt: '', version: '' };
  }
}

function publicRegistry(dataDir) {
  const current = registry.load(dataDir);
  if (current.error) throw new Error('registry-unavailable');
  return { version: current.version, sources: current.sources.map(source => ({ ...source, status: statusOf(source, dataDir) })) };
}

function generatedId(source) {
  const stem = clean(source.title || path.basename(clean(source.path, 4000)) || 'source', 48)
    .toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'source';
  return `${stem.slice(0, 48)}-${crypto.randomBytes(3).toString('hex')}`;
}

async function route(req, res, url, { authed, dataDir, log = () => {}, googleDrive, googleRead = require('./google-materials').readDriveDocument, mcpRead = require('./mcp-context-source').readMcpSource, signal }) {
  if (!apiPath(url && url.pathname)) return false;
  if (!authed) { json(res, 401, { ok: false, error: '请连接 Mac' }); return true; }
  if (req.method === 'GET') {
    try { json(res, 200, { ok: true, ...publicRegistry(dataDir) }); }
    catch (error) { log(`context sources read failed: ${error && error.message}`); json(res, 500, { ok: false, error: '本机来源暂时读不了' }); }
    return true;
  }
  if (req.method !== 'POST') { json(res, 405, { ok: false, error: '不支持这个操作' }); return true; }

  let raw = '';
  try {
    for await (const chunk of req) {
      raw += chunk;
      if (Buffer.byteLength(raw) > 32 * 1024) throw new Error('too-large');
    }
  } catch (error) { json(res, 413, { ok: false, error: '请求过长' }); return true; }
  let body;
  try { body = JSON.parse(raw || '{}'); }
  catch (error) { json(res, 400, { ok: false, error: '格式不对' }); return true; }

  const controller = new AbortController();
  const abort = () => controller.abort();
  const closed = () => { if (!res.writableEnded) abort(); };
  req.once?.('aborted', abort); res.once?.('close', closed); signal?.addEventListener('abort', abort, { once: true });
  if (signal?.aborted) abort();
  const readGoogle = source => googleDrive && source.id.startsWith('gdrive-') ? googleDrive.readMaterial(require('./google-materials').parseDriveSource(source.path).id) : googleRead(dataDir,source.path);
  const readMcp = async source => {
    try { return await mcpRead(dataDir, source, { signal: controller.signal }); }
    catch { return { state: controller.signal.aborted ? 'cancelled' : 'failed', available: false, text: '', error: 'MCP 完整读取失败，请检查连接和权限后重试' }; }
  };
  try {
    const action = clean(body.action, 20);
    if (action === 'upsert') {
      const source = { ...(body.source || {}) };
      if (!source.id) source.id = generatedId(source);
      const normalized = registry.normalize(source);
      if(!normalized) throw Error('缺少合法 type 或 path');
      if(normalized.type==='notion') throw Error('Notion 来源请在 Connectors 中明确选择');
      if(normalized.type==='google-drive') {
        const result=await readGoogle(normalized);
        require('./context-source-cache').save(dataDir,normalized,result);
      }
      if(normalized.type==='mcp' && normalized.enabled) require('./context-source-cache').save(dataDir,normalized,await readMcp(normalized));
      registry.upsert(dataDir, normalized);
    } else if (action === 'refresh') {
      const source=registry.load(dataDir).sources.find(x=>x.id===clean(body.id,80));
      if(!source || !['google-drive','mcp','notion'].includes(source.type)) { json(res,404,{ok:false,error:'没找到可刷新的来源'}); return true; }
      if(source.type==='notion') { await require('./notion-connector').refresh(dataDir); json(res,200,{ok:true,...publicRegistry(dataDir)}); return true; }
      let result;
      try { result=source.type==='mcp'?await readMcp(source):await readGoogle(source); }
      catch {
        // A failed refresh invalidates the previous snapshot, never the source registration.
        require('./context-source-cache').save(dataDir,source,{state:'failed',available:false,text:''});
        json(res,502,{ok:false,error:'Drive 刷新失败；已停止使用旧快照，请检查权限和连接后重试'}); return true;
      }
      require('./context-source-cache').save(dataDir,source,result);
    } else if (action === 'toggle') {
      const current = registry.load(dataDir);
      if (current.error) throw new Error('registry-unavailable');
      const found = current.sources.find(item => item.id === clean(body.id, 80));
      if (!found) { json(res, 404, { ok: false, error: '没找到这个来源' }); return true; }
      registry.upsert(dataDir, { ...found, enabled: body.enabled !== false });
    } else if (action === 'delete') {
      const old=registry.load(dataDir).sources.find(x=>x.id===clean(body.id,80));
      if(old?.type==='notion') { require('./notion-connector').removeSelected(dataDir,require('./notion-connector').pageId(old.path)); json(res,200,{ok:true,...publicRegistry(dataDir)}); return true; }
      if(['google-drive','mcp','notion'].includes(old?.type))require('./context-source-cache').remove(dataDir,old);
      if (!registry.remove(dataDir, clean(body.id, 80))) { json(res, 404, { ok: false, error: '没找到这个来源' }); return true; }
    } else { json(res, 400, { ok: false, error: '操作不对' }); return true; }
    json(res, 200, { ok: true, ...publicRegistry(dataDir) });
  } catch (error) {
    log(`context sources write failed: ${error && error.message}`);
    const invalid = /\bid\b|\btype\b|\bpath\b|缺少合法/.test(String(error && error.message));
    json(res, invalid ? 400 : 500, { ok: false, error: invalid ? '请检查来源名称、类型和路径' : '本机来源暂时保存不了' });
  } finally {
    req.removeListener?.('aborted', abort); res.removeListener?.('close', closed); signal?.removeEventListener('abort', abort);
  }
  return true;
}

module.exports = { route, publicRegistry, statusOf };
