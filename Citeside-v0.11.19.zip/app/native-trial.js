'use strict';
// 首次引导「试听」：和正式会议同一条 原生采集 → 转写 → 提示 管线，但不留任何会议痕迹。
// 不进会议库 / 最近记录 / Notion / 任务 / 日历：finalize 前清空转写、去掉录音路径，
// finalize 只负责关转写和计时器、把场次移出内存；之后删掉 pending、journal、pcm 和截图。
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const PREFIX='trial-';
const isTrialId=id=>typeof id==='string'&&/^trial-[0-9a-f-]{36}$/.test(id);
// 返回 true=删除成功；文件原本不存在也算成功。失败返回 Error，调用方决定是否记日志/重试。
const rm=file=>{try{fs.rmSync(file,{recursive:true,force:true});return true;}catch(e){return e;}};
const sentence=text=>{const s=String(text||'').trim();const m=s.match(/^(.{1,80}?[。！？!?；;]|.{1,80}?\.(?=\s|$))\s*(.*)$/s);return m?{title:m[1].trim(),body:m[2].trim()}:{title:s.slice(0,80),body:s.slice(80).trim()};};

function files(dataDir,id){
  return [path.join(dataDir,'state','live-sessions',id+'.json'),path.join(dataDir,'audio',id+'.pcm'),path.join(dataDir,'pending','sess-'+id+'.json'),path.join(dataDir,'state','native-frames',id)];
}
// A crash is not a capture-stop receipt. Keep original paths in place because
// an old helper may still hold/write them; never archive or transcribe them here.
// A private receipt inventories recoverable files without copying their content.
function sweep(dataDir,log=()=>{}){
  let n=0;const groups=new Map();
  const safeDir=dir=>{try{return fs.lstatSync(dir).isDirectory()&&!fs.lstatSync(dir).isSymbolicLink();}catch{return false;}};
  if(!safeDir(dataDir))return 0;
  const state=path.join(dataDir,'state');
  if(fs.existsSync(state)&&!safeDir(state))return 0;
  for(const [relative,re] of [['state/live-sessions',/^(trial-[0-9a-f-]{36})\.json(?:\.tmp\.\d+)?$/],['audio',/^(trial-[0-9a-f-]{36})\.pcm$/],['pending',/^sess-(trial-[0-9a-f-]{36})\.json(?:\.tmp\.\d+)?$/],['state/native-frames',/^(trial-[0-9a-f-]{36})$/]]){
    const dir=path.join(dataDir,relative);if(!safeDir(dir))continue;
    let names=[];try{names=fs.readdirSync(dir);}catch(e){log('试听恢复目录读取失败 '+String(e?.message||e));continue;}
    for(const name of names){
      const match=name.match(re);if(!match||!isTrialId(match[1]))continue;
      const file=path.join(dir,name);
      try{
        const stat=fs.lstatSync(file);if(stat.isSymbolicLink()||!(stat.isFile()||stat.isDirectory()))continue;
        fs.chmodSync(file,stat.isDirectory()?0o700:0o600);
        const entries=groups.get(match[1])||[];entries.push(path.relative(dataDir,file));groups.set(match[1],entries);n++;
      }catch(e){log('试听恢复保护失败 '+name+' '+String(e?.message||e));}
    }
  }
  if(!groups.size)return n;
  const recovery=path.join(state,'trial-recovery');
  try{
    fs.mkdirSync(state,{recursive:true,mode:0o700});
    if(fs.existsSync(recovery)&&!safeDir(recovery))throw Error('unsafe_recovery_directory');
    fs.mkdirSync(recovery,{mode:0o700});
  }catch(e){if(e?.code!=='EEXIST'){log('试听恢复回执未写入，原件保留 '+String(e?.message||e));return n;}}
  try{fs.chmodSync(recovery,0o700);}catch(e){log('试听恢复回执目录保护失败，原件保留 '+String(e?.message||e));return n;}
  for(const [id,recoveryFiles] of groups){
    let fd;
    try{
      fd=fs.openSync(path.join(recovery,id+'.json'),'wx',0o600);
      fs.writeFileSync(fd,JSON.stringify({sessionId:id,captureStopped:false,preservedAt:Date.now(),recoveryFiles}));fs.fsyncSync(fd);
    }catch(e){if(e?.code!=='EEXIST')log('试听恢复回执未写入，原件保留 '+id+' '+String(e?.message||e));}
    finally{if(fd!==undefined)try{fs.closeSync(fd);}catch{}}
  }
  return n;
}
function lines(session){
  const rows=(session?.transcript||[]).map(r=>String(r?.text||'').trim()).filter(Boolean).slice(-8);
  const partial=String(session?.lastPartialText||'').trim();
  if(partial&&(session.lastRecognitionTs||0)>(session.lastFinalTs||0)&&rows.at(-1)!==partial)rows.push(partial);
  return rows.map(x=>x.slice(0,400));
}
// 卡片只来自真实洞察结果；没有就返回 null，前端不补一张假的。
function card(session,cardState,uiLang='zh'){
  const item=[cardState?.suggestion,...(cardState?.insights||[])].find(x=>x?.text&&String(x.text).trim());
  if(!item)return null;
  const {title,body}=sentence(item.text);
  const rows=session?.transcript||[];const ids=item.sourceIds||[];
  const index=rows.findIndex(r=>ids.includes(r.id||r.segId));
  const source=index<0?'':uiLang==='en'?`Based on: your sentence ${index+1}`:`依据：你刚才说的第 ${index+1} 句`;
  return {title,...(body?{body}:{}),...(source?{source}:{})};
}

function create({dataDir,log=()=>{},maxMs=45000,stopGraceMs=8000,now=Date.now}={}){
  const swept=dataDir?sweep(dataDir,log):0;if(swept)log('试听未确认残留已保护 '+swept+' 项，未删除或自动转写');
  let last=null;          // 最近一次试听的快照：结束后 state 仍能读到转写和卡片
  let startedAt=0,heardAt=0;
  const api={
    isTrialId,
    intent(j={},uiLanguage=''){
      const uiLang=(j.uiLang||uiLanguage)==='en'?'en':'zh';const lang=j.lang==='en'||(!j.lang&&uiLang==='en')?'en':'zh';
      last=null;startedAt=now();heardAt=0;
      return {sessionId:PREFIX+crypto.randomUUID(),trial:true,title:uiLang==='en'?'Trial':'试听',lang,uiLang};
    },
    // 正式 start() 里拿到 trial intent 后调用：给场次打标，并设硬上限，前端走掉也会自己收尾。
    attach(session,stop){
      session.trial=true;
      const timer=setTimeout(()=>{if(!session.finalized){log('试听到达上限，自动结束 '+session.id);stop();}},maxMs);timer.unref?.();
      session.trialTimer=timer;
    },
    // A timeout is not a stop receipt. Keep the recorder/session and every recovery
    // file intact until the helper actually posts /native/end after stopping.
    graceStop(session,onTimeout=()=>{}){
      clearTimeout(session.trialStopTimer);
      const timer=setTimeout(()=>{
        session.trialStopTimer=null;
        if(session.trialDiscarded||session.trialStopConfirmed)return;
        session.trialEndError='capture_stop_unconfirmed';session.trialStopRequested=0;
        log('试听停止未确认，录音和待恢复队列保留 '+session.id);
        try{onTimeout();}catch(e){log('试听停止状态通知失败 '+String(e?.message||e));}
      },stopGraceMs);timer.unref?.();session.trialStopTimer=timer;
    },
    snapshot({live,pending,startupError='',startupErrorSessionId=''}){
      if(live&&live.session.trial&&!live.session.finalized){
        const s=live.session,out=lines(s);
        const level=live.audioLevelAt&&now()-live.audioLevelAt<1200?Math.max(0,Math.min(1,Number(live.audioLevel)||0)):0;
        if(level>0.05&&!heardAt)heardAt=now();
        // 「在重试」= 小窗还在接入，或已经听到声音但转写超过 3 s 没有任何回应（转写连接自身会重连）。
        const retrying=!out.length&&(!live.captureReady||!!heardAt&&now()-heardAt>3000);
        return {level,lines:out,card:card(s,live.feed.cardState,s.uiLang),retrying,done:false,error:live.error||(s.trialEndError==='capture_stop_unconfirmed'?'录音端尚未确认停止，录音已保留，请重试':s.trialEndError?'试听收尾失败，请重试':'')};
      }
      if(pending?.trial)return {level:0,lines:[],card:null,retrying:now()-startedAt>3000,done:false,error:''};
      if(last)return last;
      if(startupErrorSessionId&&isTrialId(startupErrorSessionId))return {level:0,lines:[],card:null,retrying:false,done:true,error:startupError||'试听未能开始'};
      return {level:0,lines:[],card:null,retrying:false,done:true,error:''};
    },
    // F-02：可重入、失败可见可重试。
    // 第一次进来就把要删的路径记在 s.trialCleanup 上，删成功一项才划掉一项；finalize 抛错时文件一个不删（恢复线索留着），
    // 抛 trial_finalize_failed 给 /native/end 回 409；计时器、音频 fd、ASR 连接不管成败都在 finally 里放掉。
    // 同时只跑一份：并发的第二次调用拿到同一个 promise。
    async discard(live){
      const s=live.session;
      if(s.trialDiscarded)return last||{level:0,lines:[],card:null,retrying:false,done:true,error:''};
      if(s.trialDiscarding)return s.trialDiscarding;
      const run=(async()=>{
        clearTimeout(s.trialTimer);clearTimeout(s.trialStopTimer);
        if(!s.trialCleanup){
          last={level:0,lines:lines(s),card:card(s,live.feed.cardState,s.uiLang),retrying:false,done:true,error:live.error||''};
          const id=s.id,targets=dataDir&&isTrialId(id)?files(dataDir,id):[];
          if(s.journalPath)targets.push(s.journalPath);if(s.audioPath)targets.push(s.audioPath);
          // finalize 只在有转写时写进 hub、有转写或录音时入归档队列；两样都拿走，它就只做收尾。
          Object.defineProperty(s,'transcript',{configurable:true,get:()=>[],set:()=>{}});
          s.audioPath='';
          s.trialCleanup={targets:[...new Set(targets)]};
        }
        try{
          if(!s.finalized){
            try{await s.finalize('试听结束');}
            catch(e){
              s.trialEndError=String(e?.message||e);last={...last,error:'试听收尾失败，请重试'};
              log('试听收尾失败（文件保留，可重试）'+s.id+' '+s.trialEndError);
              throw Error('trial_finalize_failed: '+s.trialEndError);
            }
          }
        }finally{
          try{clearInterval(s.journalTimer);}catch{}
          try{await s.closeAudio?.();}catch(e){log('试听音频句柄关闭失败 '+String(e?.message||e||'audio_close_failed'));}
          try{if(s.volcWs&&s.volcWs.readyState!==3)s.volcWs.close();}catch{}
        }
        // F-02：finalize 里 mac/dg drain 超时或失败的回执（finalize-drain.js），试听照常收尾，只留日志
        if(s.drainReceipts?.length)log('试听转写收尾未确认 '+s.id+' '+s.drainReceipts.map(r=>r.name+':'+r.reason).join(','));
        if(s.pendingPath&&!s.trialCleanup.targets.includes(s.pendingPath))s.trialCleanup.targets.push(s.pendingPath);
        const left=[];
        for(const f of s.trialCleanup.targets){const r=rm(f);if(r!==true){left.push(f);log('试听文件清理失败 '+f+' '+r.message);}}
        s.trialCleanup.targets=left;
        if(left.length){s.trialEndError='cleanup';last={...last,error:'试听文件没删干净，请重试'};throw Error('trial_cleanup_failed: '+left.length+' 项');}
        s.trialEndError='';s.trialDiscarded=true;
        if(last?.error==='试听收尾失败，请重试'||last?.error==='试听文件没删干净，请重试')last={...last,error:''};
        return last;
      })();
      s.trialDiscarding=run;
      try{return await run;}finally{s.trialDiscarding=null;}
    },
    forget(){last=null;},
  };
  return api;
}
module.exports={create,sweep,lines,card,isTrialId};
