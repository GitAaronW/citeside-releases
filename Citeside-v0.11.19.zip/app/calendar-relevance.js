'use strict';
const FIRST=3*60e3, INTERVAL=10*60e3;
const generic=/会议|周会|项目|汇报|讨论|今天|我们|这个|那个|然后|大家|开始|同步|进度|meeting|weekly|project|update/gi;
function words(text){
 const clean=String(text||'').toLowerCase().replace(/https?:\/\/\S+/g,' ').replace(generic,' '), out=new Set(clean.match(/[a-z][a-z0-9_-]{2,}/g)||[]);
 for(const run of clean.match(/[\u4e00-\u9fff]+/g)||[])for(let i=0;i<run.length-1;i++)out.add(run.slice(i,i+2));
 return out;
}
function overlap(a,b){return [...a].filter(w=>b.has(w)).length;}
function evaluate(calendar,transcript){
 const rows=(transcript||[]).filter(r=>String(r.text||'').trim()).slice(0,16), text=rows.map(r=>r.text).join('\n');
 const reference=[calendar.title,calendar.event?.title,calendar.description,calendar.event?.description,...(calendar.agenda||[]),...(calendar.briefLines||[]).map(r=>r.text)].join('\n');
 const expected=words(reference), actual=words(text);
 if(rows.length<3||text.length<120||expected.size<3||actual.size<12)return 'unknown';
 return overlap(expected,actual)===0?'mismatch':'related';
}
function check(session,now=Date.now()){
 const c=session.calendar;if(!c||c.chosen==='none'||!(c.eventId||c.event?.eventId)||session.finalized||session.end)return false;
 const state=c.relevance||(c.relevance={});if(state.ignored||now-Number(session.startTs||session.start)<FIRST||state.checkedAt&&now-state.checkedAt<INTERVAL)return false;
 state.checkedAt=now;state.status=evaluate(c,session.transcript);return true;
}
function alternatives(c,start){const lo=Date.parse(c.start||c.event?.start)||Number(start), hi=Date.parse(c.end||c.event?.end)||lo+60*60e3;return (c.dayEvents||[]).filter(e=>e.eventId!==(c.eventId||c.event?.eventId)&&Date.parse(e.start)<hi&&(Date.parse(e.end)||Date.parse(e.start)+60*60e3)>lo);}
function inferredTitle(rows){const text=(rows||[]).map(r=>r.text||'').join(' ');const named=text.match(/(?:今天(?:是|开的是|召开的是)?|现在(?:开始|召开)?|本次)\s*([^，。！？\n]{3,35}(?:周会|例会|评审会|讨论会))/);return named?named[1]:((rows||[]).find(r=>String(r.text||'').length>=12)?.text||'').slice(0,40);}
// Update only calendar-derived titles and automatic board modules; preserve human edits.
function applyBinding(session,previous,hub){
 const c=session.calendar, ev=c.eventId?{...(c.event||{}),eventId:c.eventId,calendarId:c.calendarId,title:c.title,start:c.start,end:c.end,description:c.description||''}:null;
 if(!session.title||session.title===previous?.title||session.title===previous?.event?.title)session.title=ev?.title||inferredTitle(session.transcript);
 const source=hub?.data?.sources?.find(s=>s.key==='session:'+session.id);if(!source)return;
 source.calendarEvent=ev;
 if(!source.title||source.title===previous?.title||source.title===previous?.event?.title)source.title=session.title;
 const changed=(previous?.eventId||previous?.event?.eventId||'')!==(ev?.eventId||'');
 if(!changed){hub.save();return;}
 if(source.board?.modules)source.board.modules=source.board.modules.filter(m=>!['premeeting-materials','premeeting-candidates'].includes(m.id)||m.edited!==false);
 if(ev){const module=require('./premeeting-brief').preparationModule(hub.data,source,ev);if(module&&source.board&&!source.board.modules.some(m=>m.id===module.id))source.board.modules.push(module);}
 source.revision=(source.revision||0)+1;hub.save();
}
module.exports={evaluate,check,alternatives,inferredTitle,applyBinding};
