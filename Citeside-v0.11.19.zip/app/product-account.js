'use strict';
// ACCOUNT-WORK 第 1 步：本机产品账号（不上云）。
// account.json 存一个稳定的产品 user_id 和绑定表：Google / 飞书 / Notion / AI 供应商的外部账号各自对应到这个 user_id。
// 规矩：
//   - 只有登录回调验证过归属的外部账号才能绑（proof.verifiedBy 必填），同邮箱不算证明，不按邮箱自动合并；
//   - 同一个外部账号已绑在本机时，要重新证明才能换绑；
//   - 每个绑定有自己的目录 accounts/<user_id>/<provider>-<hash>/，令牌和缓存放这里，解绑 = 调撤销 + 删这个目录；
//   - 现有单账号数据（会议、设置、owner-profile.json）原样不动，不迁移。
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const PROVIDERS = new Set(['google', 'lark', 'notion', 'slack', 'ai']);
const fileOf = dataDir => path.join(dataDir, 'account.json');
const bindingKey = (provider, externalId) => provider + '-' + crypto.createHash('sha256').update(provider + '\0' + externalId).digest('hex').slice(0, 16);

function writeAtomic(file, data) {
  require('./durable-json').write(file, data, { space: 2 });
}

function load(dataDir, now = Date.now()) {
  const file = fileOf(dataDir);
  try {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (j && typeof j.userId === 'string' && /^u_[a-f0-9]{32}$/.test(j.userId)) return { userId: j.userId, createdAt: j.createdAt || 0, bindings: Array.isArray(j.bindings) ? j.bindings : [] };
    throw Error('本机账号文件损坏：' + file);
  } catch (e) {
    if (e.code !== 'ENOENT') throw e;
  }
  const account = { userId: 'u_' + crypto.randomBytes(16).toString('hex'), createdAt: now, bindings: [] };
  fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  writeAtomic(file, account);
  return account;
}

function bindingDir(dataDir, account, b) { return path.join(dataDir, 'accounts', account.userId, b.key); }

// proof：登录回调给出的归属证明，例如 { verifiedBy: 'oauth', subject: '<外部平台的用户 ID>' }。
function bind(dataDir, { provider, externalId, label = '', proof } = {}, now = Date.now()) {
  if (!PROVIDERS.has(provider)) throw Error('不支持的账号类型：' + String(provider).slice(0, 40));
  externalId = String(externalId || '').trim();
  if (!externalId) throw Error('缺少外部账号 ID');
  if (!proof || !proof.verifiedBy || String(proof.subject || '') !== externalId) throw Error('没有通过登录验证这个账号属于你，不能绑定（同邮箱不算证明）');
  const account = load(dataDir, now), key = bindingKey(provider, externalId);
  const existing = account.bindings.find(b => b.key === key);
  const binding = { key, provider, externalId, label: String(label).slice(0, 120), verifiedBy: String(proof.verifiedBy).slice(0, 40), boundAt: existing ? existing.boundAt : now, verifiedAt: now };
  account.bindings = account.bindings.filter(b => b.key !== key).concat(binding);
  fs.mkdirSync(bindingDir(dataDir, account, binding), { recursive: true, mode: 0o700 });
  writeAtomic(fileOf(dataDir), account);
  return { account, binding, dir: bindingDir(dataDir, account, binding) };
}

// revoke(binding) 由各平台的登录模块提供（撤销令牌）；撤销失败也删本机目录和绑定，并把失败原因返回给界面。
async function unbind(dataDir, key, { revoke } = {}) {
  const account = load(dataDir), binding = account.bindings.find(b => b.key === key);
  if (!binding) return { ok: false, error: '没有这个绑定' };
  let revokeError = '';
  if (revoke) { try { await revoke(binding); } catch (e) { revokeError = String(e && e.message || e).slice(0, 200); } }
  fs.rmSync(bindingDir(dataDir, account, binding), { recursive: true, force: true });
  account.bindings = account.bindings.filter(b => b.key !== key);
  writeAtomic(fileOf(dataDir), account);
  return { ok: true, revoked: !!revoke && !revokeError, revokeError };
}

// 给设置页：不含令牌，外部 ID 只露末 4 位。
function publicView(dataDir) {
  const a = load(dataDir);
  return { userId: a.userId, bindings: a.bindings.map(b => ({ key: b.key, provider: b.provider, label: b.label, externalIdTail: b.externalId.slice(-4), verifiedBy: b.verifiedBy, boundAt: b.boundAt })) };
}

module.exports = { PROVIDERS, load, bind, unbind, publicView, bindingKey };
