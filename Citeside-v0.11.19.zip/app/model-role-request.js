'use strict';
// Business purposes select a role, never a vendor or model. Execution remains llm.ask.
const { ROLES } = require('./model-routing');
function roleOf({ role, stage = '', kind = 'post' } = {}) {
  if (role !== undefined) return role; // llm validates explicit names; do not silently repair them.
  if (/^(proactive-gate|jev-gate)(-|$)/.test(stage)) return 'input-detect';
  if (['live-expert-editor', 'publication', 'jev-publication', 'live-card-rewrite', 'native-live-brief'].includes(stage)) return 'discovery-edit';
  if (/^(live-research|research-report|research-card)/.test(stage)) return 'research';
  if (['live-expert', 'verify', 'premeeting-industry'].includes(stage) || kind === 'verify') return 'lookup';
  if (/^(act-for-me|assigned-draft|project-deliverable|actions\.|local-agent\.|meeting-board|mother-document)/.test(stage) || ['live-draft', 'todo-say'].includes(stage)) return 'draft';
  if (['chat', 'conversation', 'meeting-candidate-comment'].includes(stage)) return 'chat';
  if (['meeting-calibration', 'one-pager', 'replay', 'post-meeting-decisions', 'memory-diff', 'synthesis'].includes(stage)) return 'summary';
  return ['quick', 'live', 'triage', 'think'].includes(kind) ? 'understand' : 'summary';
}
function optionsFor(env, options = {}) {
  env = require('./meeting-work-state').environment(options.workState, env);
  if (!env.LLM_ROUTING && !env.LLM_ROUTING_ERROR && !options.routingSnapshot) return options;
  return { ...options, role: options.routingSnapshot?.role || roleOf(options) };
}
function ask(env, options = {}) {
  const background = options.workState ? undefined : require('./my-ai-brief').background(options.dataDir);
  return require('./llm').ask(env, optionsFor(env, { ...options, ...(background ? { background } : {}) }));
}
module.exports = { roleOf, optionsFor, ask, ROLES };
