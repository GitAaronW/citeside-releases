'use strict';
const fs=require('node:fs'),path=require('node:path'),{execFileSync}=require('node:child_process');
function readCommit(root=path.resolve(__dirname,'..')){
 // 决策 6：tht-commit 戳记指向「构建时 HEAD」。检出目录（有 .git）里 Git 是唯一真源，
 // 生成的 app/build-identity.json 只是无 .git 构建/安装副本（已装 App、冻结源码）的回退来源，那里行为不变。
 // Never inherit the Git identity of a containing directory for an unpacked build.
 // Also scrub GIT_DIR/GIT_WORK_TREE so an inherited env cannot point rev-parse at another repo.
 if(fs.existsSync(path.join(root,'.git'))){
  // 决策 6：检出目录里 Git 是唯一真源。rev-parse 失败时宁可返回 null（install-guard 的
  // guard/stamp/verifyStamp 会 fail-closed 拒绝安装），也绝不回退到可能过期的
  // build-identity.json——那会声称构建于某 commit 而实际不是，退回本修复要消灭的静默旧戳记。
  try{
   const env={...process.env};delete env.GIT_DIR;delete env.GIT_WORK_TREE; // 显式删除，不依赖 Node 对 undefined env 值的处理
   const sha=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8',stdio:['ignore','pipe','ignore'],env}).trim();
   return /^[a-f0-9]{40}$/.test(sha)?sha:null; // 校验输出格式，异常 stdout 不当戳记
  }catch{return null;}
 }
 try{const sha=JSON.parse(fs.readFileSync(path.join(root,'app/build-identity.json'),'utf8')).commit;if(/^[a-f0-9]{40}$/.test(sha))return sha;}catch{}
 return null;
}
module.exports={readCommit,commit:readCommit()};
