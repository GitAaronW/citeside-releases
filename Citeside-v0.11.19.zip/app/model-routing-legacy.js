'use strict';
// Turn an existing LLM_CHAIN / LLM_PROVIDER environment into a role-routing document.
// Chain order and the model actually selected come from llm.chainForStage and llm.pickModel.
// This module does not invent a second provider matrix or a role-to-stage map.
const { createHash } = require('node:crypto');
const routing = require('./model-routing');
const llm = require('./llm');
const { isSecretKey } = require('./secret-store');

const BOUNDARY = 'legacy-existing';
// Compiler ceiling. Legacy timeouts are per attempt; this does not add a shorter task cutoff.
const DEADLINE_MS = 1800000;
const REQUEST_FIELDS = new Set(['kind', 'stage', 'noFallback', 'images']);

function plain(x) { return !!x && typeof x === 'object' && !Array.isArray(x); }
function fail(errorCode) { return { ok: false, config: null, credentials: null, errorCode }; }
function idFor(prefix, key) { return prefix + createHash('sha256').update(key).digest('hex').slice(0, 12); }

function validateRequests(requests) {
  if (!plain(requests)) return 'legacy_requests_invalid';
  const names = Object.keys(requests);
  if (names.length !== routing.ROLES.length || routing.ROLES.some(role => !Object.hasOwn(requests, role))) return 'legacy_requests_invalid';
  for (const role of routing.ROLES) {
    const request = requests[role];
    if (!plain(request) || Object.keys(request).some(key => !REQUEST_FIELDS.has(key))) return 'legacy_request_invalid';
    if (typeof request.kind !== 'string' || !request.kind || typeof request.stage !== 'string') return 'legacy_request_invalid';
    if (request.noFallback !== undefined && typeof request.noFallback !== 'boolean') return 'legacy_request_invalid';
    if (request.images !== undefined && !Array.isArray(request.images)) return 'legacy_request_invalid';
  }
  return '';
}

function connectionFor(provider, refFor) {
  if (provider.type === 'openai') {
    const ref = refFor(provider.key);
    if (!ref) return { errorCode: 'legacy_credential_unreadable' };
    if (!Number.isSafeInteger(provider.maxInput) || provider.maxInput < 1 || provider.maxInput > 10000000) return { errorCode: 'legacy_input_limit_unexpressible' };
    return {
      key: JSON.stringify(['openai', provider.baseUrl, ref]),
      connection: { protocol: 'openai', endpoint: provider.baseUrl, credentialRef: ref, region: BOUNDARY, dataScope: BOUNDARY },
      maxInput: provider.maxInput,
    };
  }
  if (provider.type !== 'cli') return { errorCode: 'legacy_provider_unexpressible' };
  if (provider.kind === 'custom') {
    const spec = provider.custom;
    if (!spec || typeof spec.bin !== 'string' || !spec.bin || !Array.isArray(spec.args) || spec.args.some(item => typeof item !== 'string')) return { errorCode: 'legacy_custom_unexpressible' };
    if ((spec.stdin !== 'prompt' && spec.stdin !== 'none') || typeof spec.promptArg !== 'string' || typeof spec.outputJson !== 'string') return { errorCode: 'legacy_custom_unexpressible' };
    return {
      key: JSON.stringify(['cli', 'custom', spec.bin, spec.args, spec.stdin, spec.promptArg, spec.outputJson]),
      connection: { protocol: 'cli', kind: 'custom', bin: spec.bin, args: spec.args.slice(), stdin: spec.stdin, promptArg: spec.promptArg, outputJson: spec.outputJson, region: BOUNDARY, dataScope: BOUNDARY },
    };
  }
  if (!['codex', 'claude'].includes(provider.kind)) return { errorCode: 'legacy_provider_unexpressible' };
  return {
    key: JSON.stringify(['cli', provider.kind]),
    connection: { protocol: 'cli', kind: provider.kind, region: BOUNDARY, dataScope: BOUNDARY },
  };
}

function migrateLegacy(env, input = {}) {
  if (!plain(env)) return fail('legacy_env_invalid');
  const requestError = validateRequests(input.requests);
  if (requestError) return fail(requestError);
  if (env.CLOUD_AI === 'off') return fail('legacy_cloud_ai_off');
  let base;
  try { base = llm.chainOf(env); } catch { return fail('legacy_migrate_failed'); }
  if (!Array.isArray(base) || !base.length) return fail(Array.isArray(env.LLM_CHAIN) && env.LLM_CHAIN.length ? 'legacy_chain_empty' : 'legacy_unconfigured');

  const credentials = {};
  const secrets = [];
  const secretToRef = new Map();
  let secretCount = 0;
  let credentialError = '';
  // Persistent documents refer to the existing hydrated secret store, never a
  // detached return-value map that disappears on restart. No secret is written.
  const persistent = input.persistentCredentials === true;
  function refFor(secret) {
    if (typeof secret !== 'string' || !secret) return '';
    const known = secretToRef.get(secret);
    if (known) return known;
    if (persistent) {
      const refs = Object.keys(env).filter(key => /^[A-Z][A-Z0-9_]*$/.test(key) && isSecretKey(key) && env[key] === secret);
      if (refs.length !== 1) {
        credentialError = refs.length ? 'legacy_credential_ref_ambiguous' : 'legacy_credential_ref_unavailable';
        return '';
      }
      secretToRef.set(secret, refs[0]);
      secrets.push(secret);
      return refs[0];
    }
    secretCount += 1;
    const ref = 'legacy-' + secretCount;
    secretToRef.set(secret, ref);
    credentials[ref] = secret;
    secrets.push(secret);
    return ref;
  }

  const preserveStages = input.preserveStagePolicy === true;
  const stageEnv = Object.fromEntries(['CLOUD_AI', 'ACTIVE_INTELLIGENCE_MODE', 'LLM_QUICK_ROUTE', 'LLM_PROVIDER', 'LLM_MODEL_QUICK', 'LLM_MODEL_POST'].map(key => [key, String(env[key] || '')]));
  const connections = {};
  const profiles = {};
  const connectionIds = new Map();
  const profileIds = new Map();
  const roles = {};

  for (const role of routing.ROLES) {
    const request = input.requests[role];
    const query = { kind: request.kind, stage: request.stage, noFallback: request.noFallback === true, images: request.images || [] };
    let chain;
    try { chain = llm.chainForStage(env, query); } catch { return fail('legacy_migrate_failed'); }
    if (!Array.isArray(chain) || !chain.length) return fail('legacy_role_chain_empty');
    const selected = preserveStages ? [...base, llm.chainForStage(env, {kind:'quick',stage:'proactive-gate'}).at(-1)] : request.noFallback === true ? chain.slice(0, 1) : chain;
    const ids = [];
    for (const provider of selected) {
      const models = Object.fromEntries(Object.entries(provider.models || {}).filter(([kind]) => routing.MODEL_KINDS.includes(kind)));
      if (Object.values(models).some(model => typeof model !== 'string' || (model !== '' && !model.trim()))) return fail('legacy_model_unexpressible');
      const modelId = llm.pickModel(provider, request.kind);
      if (typeof modelId !== 'string') return fail('legacy_model_unexpressible');
      if (provider.type === 'cli' ? (modelId !== '' && !modelId.trim()) : !modelId.trim()) return fail('legacy_model_unexpressible');
      if (typeof provider.label !== 'string' || !provider.label) return fail('legacy_provider_unexpressible');
      const built = connectionFor(provider, refFor);
      if (built.errorCode) return fail(credentialError || built.errorCode);
      let connectionId = connectionIds.get(built.key);
      if (!connectionId) {
        connectionId = idFor('c', built.key);
        connectionIds.set(built.key, connectionId);
        connections[connectionId] = built.connection;
      }
      const capabilities = {
        json: provider.type === 'openai' || (provider.type === 'cli' && provider.kind === 'codex'),
        tools: provider.type === 'cli' && provider.kind === 'claude',
        vision: provider.vision === true,
      };
      const profile = { connection: connectionId, modelId, models, label: provider.label, capabilities };
      if (provider.type === 'openai') profile.maxInput = built.maxInput;
      const profileKey = JSON.stringify([connectionId, modelId, models, capabilities, profile.maxInput || null, provider.label]);
      let profileId = profileIds.get(profileKey);
      if (!profileId) {
        profileId = idFor('p', profileKey);
        profileIds.set(profileKey, profileId);
        profiles[profileId] = profile;
      }
      if (ids.includes(profileId)) {
        profileId = idFor('p', profileKey + '\n#' + ids.length);
        profiles[profileId] = { ...profile, capabilities: { ...capabilities } };
      }
      ids.push(profileId);
    }
    if (new Set(ids).size !== ids.length) return fail('legacy_chain_duplicate');
    const gateProfile = preserveStages ? ids.pop() : null;
    roles[role] = { primary: ids[0], fallback: ids.slice(1), deadlineMs: DEADLINE_MS, allowedRegions: [BOUNDARY], allowedDataScopes: [BOUNDARY] };
    if (preserveStages) roles[role].legacyStage = { version: 1, environment: {...stageEnv}, explicitChain: Array.isArray(env.LLM_CHAIN) && env.LLM_CHAIN.length > 0, proactiveProfile: gateProfile };
  }

  const config = { schemaVersion: 1, connections, profiles, roles };
  let serialized;
  try { serialized = JSON.stringify(config); } catch { return fail('legacy_config_unserializable'); }
  if (/"keyFrom"\s*:/.test(serialized) || /"(?:key|token|password)"\s*:/.test(serialized)) return fail('legacy_credential_in_config');
  for (const secret of secrets) if (secret && serialized.includes(secret)) return fail('legacy_credential_in_config');
  try { routing.compile(config); } catch (error) { return fail(error.code || 'routing_config_invalid'); }
  return { ok: true, config, credentials, errorCode: null };
}

module.exports = { migrateLegacy };
