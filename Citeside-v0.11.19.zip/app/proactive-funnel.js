'use strict';
// Local sanitized funnel ledger. Tokens only: no transcript, quotes, URLs, titles, or secrets.
const fs = require('fs');
const path = require('path');
const MAX_EVENTS = 500;
const TOKEN = /^[A-Za-z0-9_-]{1,64}$/;
const OUTCOMES = new Set(['ok', 'drop', 'error']);

function token(value) {
  if (typeof value !== 'string' || !TOKEN.test(value)) return undefined;
  return value;
}
function numeric(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return undefined;
  return value;
}
function safeSessionId(sessionId) {
  const cleaned = String(sessionId || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 80);
  return cleaned || 'session';
}
function summarize(events) {
  const list = Array.isArray(events) ? events : [];
  const dropsByReason = {};
  let wakes = 0, understandOk = 0, candidates = 0, checkOk = 0, writeOk = 0, published = 0, pending = 0;
  for (const event of list) {
    if (!event || typeof event !== 'object') continue;
    if (event.stage === 'wake') wakes += 1;
    if (event.stage === 'understand' && event.outcome === 'ok') understandOk += 1;
    if (event.reason === 'candidate') candidates += 1;
    if (event.stage === 'check' && event.outcome === 'ok') checkOk += 1;
    if (event.stage === 'write' && event.outcome === 'ok') writeOk += 1;
    if (event.stage === 'publish' && event.outcome === 'ok') published += 1;
    if (event.stage === 'pending' && event.outcome === 'ok') pending += 1;
    if (event.outcome === 'drop' || event.outcome === 'error') {
      const reason = typeof event.reason === 'string' && event.reason ? event.reason : 'unspecified';
      dropsByReason[reason] = (dropsByReason[reason] || 0) + 1;
    }
  }
  return { totalEvents: list.length, wakes, understandOk, candidates, checkOk, writeOk, published, pending, dropsByReason };
}
function create({ dataDir, sessionId, now = Date.now, persist = true } = {}) {
  const recorded = [];
  function stamp() {
    try {
      const value = numeric(Number(now()));
      return value === undefined ? 0 : value;
    } catch { return 0; }
  }
  function store(event) {
    if (!(persist && dataDir && sessionId)) return;
    try {
      const dir = path.join(String(dataDir), 'state', 'proactive-funnel');
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      try { fs.chmodSync(dir, 0o700); } catch { /* best-effort */ }
      const file = path.join(dir, safeSessionId(sessionId) + '.jsonl');
      if (path.dirname(file) !== dir) return;
      fs.appendFileSync(file, JSON.stringify(event) + '\n', { mode: 0o600 });
      try { fs.chmodSync(file, 0o600); } catch { /* best-effort */ }
    } catch { /* diagnostics must never break a live card */ }
  }
  function record(input) {
    try {
      const src = input && typeof input === 'object' ? input : {};
      const event = { at: stamp() };
      const wakeId = token(src.wakeId);
      const stage = token(src.stage);
      const kind = token(src.kind);
      const outcome = token(src.outcome);
      const reason = token(src.reason);
      const ms = numeric(src.ms);
      if (wakeId) event.wakeId = wakeId;
      if (stage) event.stage = stage;
      if (kind) event.kind = kind;
      if (outcome && OUTCOMES.has(outcome)) event.outcome = outcome;
      if (reason) event.reason = reason;
      if (ms !== undefined) event.ms = ms;
      recorded.push(event);
      if (recorded.length > MAX_EVENTS) recorded.splice(0, recorded.length - MAX_EVENTS);
      store(event);
      return event;
    } catch { return null; }
  }
  return {
    record,
    events() { return recorded.map(event => ({ ...event })); },
    summarize() { return summarize(recorded); }
  };
}
module.exports = { create, summarize };
