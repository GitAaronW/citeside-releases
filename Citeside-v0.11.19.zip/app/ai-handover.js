'use strict';

// A scoped, local snapshot. Possession of its random id grants access only to
// the selected text, never to the meeting store or the relay settings.
const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const TTL = 24 * 60 * 60 * 1000;

function error(statusCode, message, status) {
  return Object.assign(new Error(message), { statusCode, ...(status ? { status } : {}) });
}
function filename(dataDir, id) {
  if (typeof id !== 'string' || !UUID.test(id)) throw error(400, '交接 ID 无效');
  return path.join(dataDir, 'state', 'ai-handovers', id + '.json');
}
function persist(dataDir, snapshot) {
  const file = filename(dataDir, snapshot.id);
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  require('./durable-json').write(file, snapshot);
}
function load(dataDir, id) {
  let snapshot;
  try { snapshot = JSON.parse(fs.readFileSync(filename(dataDir, id), 'utf8')); }
  catch (e) {
    if (e.statusCode) throw e;
    if (e.code === 'ENOENT') throw error(404, '找不到这次交接');
    throw error(500, '无法读取交接快照');
  }
  if (snapshot.id !== id || !Array.isArray(snapshot.items)) throw error(500, '交接快照无效');
  return snapshot;
}
function active(snapshot) {
  if (snapshot.status === 'revoked') throw error(410, '这次交接已撤销', 'revoked');
  if (!Number.isFinite(Date.parse(snapshot.expiresAt)) || Date.parse(snapshot.expiresAt) <= Date.now()) {
    throw error(410, '这次交接已过期', 'expired');
  }
  return snapshot;
}
function metadata(snapshot) {
  const { id, title, intent, createdAt, expiresAt, status, receivedAt, revokedAt } = snapshot;
  return { id, title, intent, createdAt, expiresAt, status, itemCount: snapshot.items.length,
    ...(receivedAt ? { receivedAt } : {}), ...(revokedAt ? { revokedAt } : {}) };
}
function plain(value, name, max) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) throw error(400, name + '无效或过长');
  return value;
}
function create(dataDir, input) {
  if (!input || typeof input !== 'object' || !Array.isArray(input.items) || !input.items.length || input.items.length > 20) {
    throw error(400, '请选择 1–20 项内容');
  }
  const title = plain(input.title, '标题', 300);
  const intent = plain(input.intent, '交接目的', 4000);
  const ids = new Set();
  let total = 0;
  const items = input.items.map(item => {
    if (!item || typeof item !== 'object') throw error(400, '选中内容无效');
    const selected = { id: plain(item.id, '内容 ID', 300), title: plain(item.title, '内容标题', 300), text: plain(item.text, '内容正文', 100000) };
    if (ids.has(selected.id)) throw error(400, '选中内容重复');
    ids.add(selected.id);
    total += selected.text.length;
    return selected;
  });
  if (total > 200000) throw error(400, '选中内容总计不能超过 200000 字符');
  const now = Date.now();
  const snapshot = { id: randomUUID(), title, intent, items, createdAt: new Date(now).toISOString(),
    expiresAt: new Date(now + TTL).toISOString(), status: 'pending' };
  persist(dataDir, snapshot);
  return metadata(snapshot);
}
function get(dataDir, id) { return metadata(active(load(dataDir, id))); }
function read(dataDir, id) {
  const snapshot = active(load(dataDir, id));
  if (!snapshot.receivedAt) {
    snapshot.receivedAt = new Date().toISOString();
    snapshot.status = 'received';
    persist(dataDir, snapshot);
  }
  return { ...metadata(snapshot), items: snapshot.items };
}
function revoke(dataDir, id) {
  const snapshot = load(dataDir, id);
  if (snapshot.status !== 'revoked') {
    snapshot.status = 'revoked';
    snapshot.revokedAt = new Date().toISOString();
    persist(dataDir, snapshot);
  }
  return metadata(snapshot);
}
module.exports = { create, get, read, revoke };
