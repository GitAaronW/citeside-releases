'use strict';
// Claude 命令行 PreToolUse 钩子：会中外部核实的每次 WebSearch / WebFetch 发出前过去敏闸，模型自己加的词也拦得住。
// 退出码 2 = 拒绝这次调用，stderr 回给模型。读不懂的输入一律拒绝。
const fs=require('fs'),isearch=require('./insight-search');
function decide(raw,dataDir='',options={}){
 let tool='',value='';try{const j=JSON.parse(raw);tool=j.tool_name||'';value=String(j.tool_input?.query||j.tool_input?.url||'');}catch{return false;}
 if(!value)return false;
 const safe=isearch.isSafeQuery(value,isearch.loadSensitiveNames(options));
 if(dataDir)try{isearch.appendAudit(dataDir,{at:new Date().toISOString(),stage:'live-expert',tool,query:value,allowed:safe,...(!safe?{reason:'unsafe_query'}:{})});}catch{}
 return safe;
}
function settings(dataDir=''){return JSON.stringify({hooks:{PreToolUse:[{matcher:'WebSearch|WebFetch',hooks:[{type:'command',command:[process.execPath,__filename,dataDir].map(x=>JSON.stringify(x)).join(' ')}]}]}});}
module.exports={decide,settings};
if(require.main===module){const ok=decide(fs.readFileSync(0,'utf8'),process.argv[2]||'');if(!ok){process.stderr.write('这次检索被拒绝：含内部敏感词，或中文超过 12 字。只用简短的技术名词和公开产品名。\n');process.exit(2);}}
