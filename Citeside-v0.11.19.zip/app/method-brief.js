'use strict';
// 卡片篇幅硬上限（Aaron 10-25 投票页评论：「做起来很困难…让人一句话读完」）。
// 一张卡 = [方法标签]正文一句 + 「动作：」一句（外部卡末尾再一行「来源：」，见 method-source.js）。正文 ≤ BODY_MAX 字、动作 ≤ ACTION_MAX 字，标签和来源行不计。
// 三道工序，都不用省略号、不在词中间切（10-25 总控回读：c1 的动作被截成「…加关键技术假…」）：
//   ① 提示词要模型写短（BODY_ASK / ACTION_ASK 留余量）；
//   ② 超限的卡让模型重写一次（rewrite，异步；一次调用带上全部超限卡；仍超限、丢了动作、数字和原文不一样、
//      带省略号 / 换行 / 「动作：」前缀的都不采用）；
//   ③ 兜底退回到上限内最近一个完整分句（clip：最后一个句末或句中标点处停）。上限内一个标点都没有就没有分句可退，
//      这张卡整张不出（brief 把它去掉并记一行日志）。上限是硬的：出去的卡永远在上限内，宁可少一张卡也不切半个词。
const BODY_MAX = 30, ACTION_MAX = 20;          // 硬上限
const BODY_ASK = 26, ACTION_ASK = 16;          // 给模型的目标：留 4 字余量，模型数字通常偏多 1–4 字
const TAGS = /^(?:「[^」\n]{1,40}」)+/;
const ACTION_LINE = /\n\s*(?:动作|Action)\s*[:：]\s*/i;
const ACTION_PREFIX = /^\s*(?:动作|Action)\s*[:：]/i;
const SOURCE_LINE = /\n\s*来源\s*[:：]\s*/;
const ELLIPSIS = /…|\.{3}/;
const CLAUSE_END = /[。！？!?]/, CLAUSE_MID = /[，、；;：:,]/;
const NUM = /\d+(?:[.．]\d+)?/g;
const chars = s => Array.from(String(s || ''));
const DROP = Symbol('method-brief drop');

// 拆成 { tags, body, action, source }；没有动作行时 action 为 ''，没有「来源：」行时 source 为 ''。
// 来源行先剥出来再找动作行，所以它在动作行前后都行，且不进正文 / 动作的字数。
function split(text) {
  const t = String(text || '');
  const m = t.match(TAGS), tags = m ? m[0] : '';
  let rest = t.slice(tags.length), source = '';
  const si = rest.search(SOURCE_LINE);
  if (si >= 0) {
    const tail = rest.slice(si).replace(SOURCE_LINE, ''), nl = tail.indexOf('\n');
    source = (nl < 0 ? tail : tail.slice(0, nl)).trim();
    rest = rest.slice(0, si) + (nl < 0 ? '' : tail.slice(nl));
  }
  const a = rest.search(ACTION_LINE);
  if (a < 0) return { tags, body: rest.trim(), action: '', source };
  const after = rest.slice(a).replace(ACTION_LINE, '');
  return { tags, body: rest.slice(0, a).trim(), action: after.trim(), source };
}
const join = (tags, body, action, source) => tags + body + (action ? '\n动作：' + action : '') + (source ? '\n来源：' + source : '');
// 退回到 max 字以内最近的完整分句：上限内最后一个标点处停——句末标点保留，句中标点去掉。
// 上限内没有标点就没有分句可退：返回 null（不硬截、不加「…」、不超限放行），调用方把这张卡去掉。
function clip(s, max) {
  const cs = chars(String(s || '').trim());
  if (cs.length <= max) return cs.join('');
  const head = cs.slice(0, max);
  for (let i = head.length - 1; i > 0; i--) {
    if (CLAUSE_END.test(head[i])) return head.slice(0, i + 1).join('');
    if (CLAUSE_MID.test(head[i])) return head.slice(0, i).join('');
  }
  return null;
}
// 正文或动作退不进上限 → null（整张卡不出）；否则返回的文字一定在上限内。
function briefText(text) {
  if (typeof text !== 'string') return text;
  const { tags, body, action, source } = split(text);
  const b = clip(body, BODY_MAX), a = clip(action, ACTION_MAX);
  if (b === null || a === null) return null;
  return join(tags, b, a, source);
}
function cardsOf(parsed) { return [parsed.suggestion, ...(Array.isArray(parsed.insights) ? parsed.insights : [])]; }
function mapCards(parsed, fn) {
  return { ...parsed, suggestion: fn(parsed.suggestion, 0), insights: (Array.isArray(parsed.insights) ? parsed.insights : []).map((c, j) => fn(c, j + 1)) };
}
// 兜底（同步）：每张卡退回到完整分句；退不进上限的卡整张去掉（suggestion 置 null、insight 从列表里删）并记一行日志。
function brief(parsed, log) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return parsed;
  const out = mapCards(parsed, c => {
    if (!c || typeof c.text !== 'string') return c;
    const text = briefText(c.text);
    if (text === null) { if (typeof log === 'function') log('method-brief overflow dropped ' + c.text.replace(/\n/g, ' / ')); return DROP; }
    return { ...c, text };
  });
  return { ...out, suggestion: out.suggestion === DROP ? null : out.suggestion, insights: out.insights.filter(c => c !== DROP) };
}
// 测试 / 评审用：这段卡片文字是否已在上限内（标签和来源行不计）。
function within(text) { const { body, action } = split(text); return chars(body).length <= BODY_MAX && chars(action).length <= ACTION_MAX; }

// 重写后的数字必须和原文一模一样（多重集相等：不新增、不删、不改、不重复；guard 的数字闸在重写之前跑过）。
function numbersKept(after, before) {
  const count = s => { const m = new Map(); for (const n of String(s).match(NUM) || []) m.set(n, (m.get(n) || 0) + 1); return m; };
  const a = count(after), b = count(before);
  return a.size === b.size && [...a].every(([n, k]) => b.get(n) === k);
}
const rewritePrompt = `你是会议卡片的编辑。下面每张卡的正文或动作超过了字数上限，请逐张重写：正文一句不超过 bodyMax 字，动作一句不超过 actionMax 字（人名、编号、英文缩写都按字数算）。保留原意和原有的人名、编号、数字；不加原文没有的内容和数字；每句写完整，不用省略号；不写标签，不写「动作：」前缀。只回 JSON：{"cards":[{"k":0,"body":"…","action":"…"}]}，k 照抄输入。`;
// 超限的卡让模型重写一次。ask(system, user) 回 JSON 字符串；调用失败、格式不对、仍超限、原来有动作行却丢了、数字和原文不一样、
// 带省略号 / 换行 / 「动作：」前缀 → 那张卡不采用，交给 brief() 兜底。模型照抄了标签就去掉（标签由系统加）；来源行不送去重写，原样接回。
async function rewrite(parsed, ask, log) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || typeof ask !== 'function') return parsed;
  const slots = [];
  cardsOf(parsed).forEach((c, i) => { if (c && typeof c.text === 'string' && !within(c.text)) slots.push({ i, ...split(c.text) }); });
  if (!slots.length) return parsed;
  let out;
  try {
    const raw = await ask(rewritePrompt, JSON.stringify({ bodyMax: BODY_ASK, actionMax: ACTION_ASK, cards: slots.map((s, k) => ({ k, body: s.body, action: s.action })) }));
    out = JSON.parse(String(raw).replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, ''));
  } catch (e) { if (typeof log === 'function') log('method-brief rewrite failed ' + (e && e.message || e)); return parsed; }
  const list = Array.isArray(out) ? out : (Array.isArray(out?.cards) ? out.cards : []);
  const fixed = new Map();
  for (const r of list) {
    const s = slots[Number(r?.k)]; if (!s || fixed.has(s.i)) continue;
    const body = String(r.body || '').trim().replace(TAGS, '').trim(), action = String(r.action || '').trim();
    if (!body || chars(body).length > BODY_MAX || chars(action).length > ACTION_MAX) continue;
    if (s.action && !action) continue;
    if (/[\r\n]/.test(body + action) || ELLIPSIS.test(body + action) || ACTION_PREFIX.test(body) || ACTION_PREFIX.test(action)) continue;
    if (!numbersKept(body + '\n' + action, s.body + '\n' + s.action)) continue;
    fixed.set(s.i, join(s.tags, body, action, s.source));
  }
  if (typeof log === 'function') log('method-brief rewrite ' + fixed.size + '/' + slots.length);
  if (!fixed.size) return parsed;
  return mapCards(parsed, (c, i) => fixed.has(i) ? { ...c, text: fixed.get(i) } : c);
}
const prompt = `
卡片篇幅（硬规则）：每张卡的 text 只有两句。第一句是正文，不超过 ${BODY_ASK} 个字，一句话说清会上缺的角度或外部的看法；然后换行写「动作：」加一句，不超过 ${ACTION_ASK} 个字，说清谁做什么。人名、编号、英文缩写都按字数算，宁可少说一层也不要超：正文超过 ${BODY_MAX} 字或动作超过 ${ACTION_MAX} 字的卡会被退回重写，仍超就只保留到最后一个完整分句；没有分句可退就整张卡不出。不写铺垫、不复述会上原话、不解释为什么。
`;
module.exports = { BODY_MAX, ACTION_MAX, BODY_ASK, ACTION_ASK, TAGS, split, clip, briefText, brief, rewrite, within, numbersKept, rewritePrompt, prompt };
