'use strict';
// SUPPORT-FEEDBACK：「复制诊断信息」。只放版本、系统、配置开关和最近的错误摘要；
// 不放 Key、会议内容、逐字稿、人名路径。错误行按关键词筛，再逐行脱敏截断，用户复制前能先看到全文。
const fs=require('fs'),os=require('os'),path=require('path');
const SECRET=/KEY|TOKEN|SECRET|PASSWORD/i;   // settings 里名字带这些的字段一律当密钥
const CJK_ERR_G=/失败|异常|出错|报错|超时/g;
const ERR=/失败|异常|出错|报错|超时|error|fail|exception|timeout|ECONN|ENOTFOUND|EACCES|http [45]\d\d|status[ =:]+[45]\d\d/i;
function scrub(line,env={}){
 let s=String(line);
 for(const [k,v] of Object.entries(env))if(SECRET.test(k)&&v&&String(v).length>=6)s=s.split(String(v)).join('***');
 return s.replace(/sk-[\w-]{6,}/g,'sk-***').replace(/Bearer\s+\S+/gi,'Bearer ***')
  .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g,'<email>').replace(/\/Users\/[^/\s]+/g,'/Users/<me>')
  .replace(/(https?:\/\/[^\s?#]+)[?#]\S*/g,'$1?…').replace(/[A-Za-z0-9_-]{24,}/g,'***')
  .replace(/[「“][^」”]{0,400}[」”]/g,'「…」')   // 中文引号里多半是会议原文或模型输出，整段去掉
  .replace(/"([^"]{0,400})"/g,(m,x)=>/[^\x00-\x7f]|\s/.test(x)||x.length>40?'"…"':m)   // 英文引号只去掉像正文的，留住 JSON 字段名
  .replace(/[\u3400-\u9fff\uf900-\ufaff][\u3400-\u9fff\uf900-\ufaff\u3000-\u303f\uff00-\uffef]*/g,x=>'…'+(x.match(CJK_ERR_G)||[]).join('/'))   // 没加引号的中文一律去掉，只留其中的错误词本身（「生成纪要失败」→「…失败」）：人名 + 错误词也不漏
  .slice(0,180);
}
function tail(file,n=600){try{const st=fs.statSync(file),fd=fs.openSync(file,'r'),len=Math.min(st.size,256*1024),buf=Buffer.alloc(len);fs.readSync(fd,buf,0,len,st.size-len);fs.closeSync(fd);return buf.toString('utf8').split('\n').slice(-n);}catch{return [];}}
function recentErrors(dataDir,env,max=20){
 const out=[];
 for(const name of ['events.log','launcher.log']){for(const l of tail(path.join(dataDir,name)))if(l.trim()&&ERR.test(l))out.push(name.replace('.log','')+' '+scrub(l,env));}
 return out.slice(-max);
}
// 用哪家、发到哪，一律问统一入口 llm.chainOf，这里不认厂商
function aiLabel(env){try{const p=require('./llm').chainOf(env)[0];if(!p)return '';let h='';try{h=p.baseUrl?new URL(p.baseUrl).host:'';}catch{}return p.label+(h?'（'+h+'）':'')+(p.model?' · '+p.model:'');}catch{return '';}}
function build({dataDir,env,version,macAsrAvailable,consent}){
 const yes=v=>v?'已填':'未填';
 const lines=[
  'Citeside诊断信息（不含 Key 和会议内容）',
  '生成时间 '+new Date().toISOString(),
  '版本 '+version+' · macOS '+os.release()+' '+os.arch()+' · Node '+process.versions.node,
  '转写 '+(env.ASR_PROVIDER||'未选')+' · 本机转写可用 '+(macAsrAvailable?'是':'否')+' · 火山 Key '+yes(env.VOLC_APP_KEY&&env.VOLC_ACCESS_KEY)+' · Deepgram Key '+yes(env.DEEPGRAM_API_KEY),
  'AI '+(env.CLOUD_AI==='off'?'只在本机（不调用）':(aiLabel(env)||'未配置'))+(env.LLM_PROVIDER_AUTO==='1'?'（自动选的）':'')+' · 逐句筛选 '+(env.JEV_GATE==='on'?'开':'关'),
  '接收方记录 '+(consent?(consent.recorded?(consent.acceptedAt+(consent.changed?' · 下一场开场时更新':'')):'尚无（第一场开场时记录）'):'未知'),
  '',
  '最近的错误（已脱敏，最多 20 条）：'
 ];
 const errs=recentErrors(dataDir,env);
 return lines.concat(errs.length?errs:['（没有）']).join('\n');
}
module.exports={build,scrub,recentErrors};
