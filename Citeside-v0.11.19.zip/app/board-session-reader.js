'use strict';
// One reader per request: historical directories are indexed once, while live
// sessions and enhanced content are still read at the moment they are needed.
// An ended meeting keeps the enhanced copy. Current judgments that exist only
// on the later history snapshot are copied onto it; live capture still wins.
function currentJudgments(session){
 return (session?.factchecks||[]).filter(item=>item&&item.channel==='judgment'&&item.id&&!item.stale&&!item.supersededBy);
}
module.exports=function({live,pipeline,exportState,decorate}){
 let jobs,history;
 // Opt-in view decoration receives its own top-level copy; default live reads
 // keep their identity for editing/capture. Decoration never rewrites a session.
 const view=(session,id)=>{if(!session||typeof decorate!=='function')return session;const copy={...session};return decorate(copy,String(id))||copy;};
 const copies=new Map();
 const historical=id=>{id=String(id);if(!copies.has(id))copies.set(id,structuredClone(historyOf().get(id)));return copies.get(id);};
 const historyOf=()=>{if(!history)history=new Map(exportState().sessions.map(s=>[String(s.id),s]));return history;};
 return id=>{
  const current=live.get(id);if(current)return view(current,id);
  if(!jobs)jobs=new Map(pipeline.list().map(j=>[String(j.sessionId),j]));
  const enhanced=pipeline.result(id,jobs.get(String(id))||null);
  if(!enhanced)return view(historical(id),id);
  const historySession=historyOf().get(String(id));
  if(!require('./session-continuation').sameGeneration(enhanced,historySession))return view(historical(id),id);
  const saved=historyOf().get(String(id));
  const seen=new Set((enhanced.factchecks||[]).map(item=>item&&item.id).filter(Boolean));
  const missing=currentJudgments(saved).filter(item=>!seen.has(item.id)).map(item=>structuredClone(item));
  if(!missing.length)return view(enhanced,id);
  const existing=enhanced.factchecks||[];
  const factchecks=currentJudgments(enhanced).length?[...missing,...existing]:[...existing,...missing];
  return view({...enhanced,factchecks},id);
 };
};
