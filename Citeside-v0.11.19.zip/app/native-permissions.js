'use strict';
// TRIAL-ONBOARDING：首页引导开权限（麦克风、屏幕与系统录音）。
// 权限归属录音小助手 CitesideCapture.app 自己（TCC 按 app 记），服务端查不到，
// 所以由常驻的小助手在空闲心跳里上报，首页读这里；点「去开通」时排一条请求给小助手，
// 小助手弹系统授权框，仅当明确需要直跳设置（openSettings）时才打开系统设置对应页；
// 小助手尚未运行且未明确要求打开设置时先拉起小助手由其发起系统授权，避免先弹出空列表的系统设置。
const KINDS={microphone:'Privacy_Microphone',screen:'Privacy_ScreenCapture'};
const STALE_MS=15000;
const REFRESH_COOLDOWN_MS=5000;
const RECYCLE_COOLDOWN_MS=10000;

function create({now=()=>Date.now(),open=url=>require('child_process').execFile('/usr/bin/open',[url],()=>{}),ensureHelper=null,recycleHelper=null}={}){
 let report=null,reportedAt=0,pending='',verifyOnly=false,pendingOpenSettings=false;
 let lastScreenRequest=-Infinity,lastScreenRefresh=-Infinity,lastScreenOpenSettings=-Infinity,lastRecycle=-Infinity;
 const settingsUrl=kind=>'x-apple.systempreferences:com.apple.preference.security?'+KINDS[kind];
 function status(){
  const fresh=!!report&&now()-reportedAt<STALE_MS;
  return {known:fresh,microphone:fresh?report.microphone:'unknown',screen:fresh?report.screen:'unknown',
   missing:fresh?Object.keys(KINDS).filter(k=>report[k]!=='authorized'):[]};
 }
 function fromHelper(j){
  const norm=v=>['authorized','denied','restricted','notDetermined'].includes(v)?v:'unknown';
  report={microphone:norm(j.microphone),screen:j.screen===true?'authorized':j.screen===false?'denied':norm(j.screen)};
  reportedAt=now();
  const request=pending,verify=verifyOnly,openSettings=pendingOpenSettings;
  pending='';verifyOnly=false;pendingOpenSettings=false;
  if(j.afterVerify===true&&report.screen!=='authorized'&&typeof recycleHelper==='function'&&now()-lastRecycle>=RECYCLE_COOLDOWN_MS){
   lastRecycle=now();
   Promise.resolve().then(()=>recycleHelper()).catch(()=>{});
  }
  return {ok:true,request,...(verify?{verifyOnly:true}:{}),...(openSettings?{openSettings:true}:{})};
 }
 function request(kind,verify=false,{openSettings=false}={}){
  if(!KINDS[kind])throw Object.assign(Error('invalid_permission'),{status:400});
  if(verify&&kind!=='screen')throw Object.assign(Error('invalid_permission'),{status:400});
  const s=status();
  if(s.known){
   if(kind==='screen'){
    // A settings return or explicit "Open System Settings" CTA has its own
    // cooldown so returning from or opening Settings isn't blocked by initial ask.
    const lastAttempt=verify?lastScreenRefresh:(openSettings?lastScreenOpenSettings:lastScreenRequest);
    if(now()-lastAttempt<REFRESH_COOLDOWN_MS)return {ok:true,via:'helper',pending:true};
    if(verify)lastScreenRefresh=now();
    else if(openSettings)lastScreenOpenSettings=now();
    else lastScreenRequest=now();
   }
   pending=kind;verifyOnly=verify;pendingOpenSettings=!!openSettings&&!verify;
   return {ok:true,via:'helper'};
  }
  // A read-only refresh must never open settings or be reported as a grant.
  if(verify)return {ok:false,via:'unavailable'};
  if(!openSettings&&typeof ensureHelper==='function'){
   if(kind==='screen'){
    if(now()-lastScreenRequest<REFRESH_COOLDOWN_MS&&pending===kind)return {ok:true,via:'helper',pending:true};
    lastScreenRequest=now();
   }
   pending=kind;verifyOnly=false;pendingOpenSettings=false;
   Promise.resolve().then(()=>ensureHelper()).catch(()=>{});
   return {ok:true,via:'helper',launching:true};
  }
  open(settingsUrl(kind));return {ok:true,via:'settings'};
 }
 async function route(req,res,u,isLocal){
  const p=u.pathname;if(p!=='/native/permissions'&&p!=='/native/permissions/request'&&p!=='/native/permissions/refresh')return false;
  const send=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(j));return true;};
  if(!isLocal)return send(403,{ok:false,error:'local_only'});
  if(p==='/native/permissions'&&req.method==='GET')return send(200,status());
  if(req.method!=='POST')return send(405,{ok:false,error:'method'});
  if(!String(req.headers['content-type']||'').includes('application/json'))return send(415,{ok:false,error:'json_required'});
  let body='';for await(const c of req){body+=c;if(body.length>4096)return send(413,{ok:false,error:'too_large'});}
  let j;try{j=JSON.parse(body||'{}');}catch{return send(400,{ok:false,error:'bad_json'});}
  try{return send(200,p==='/native/permissions'?fromHelper(j):p==='/native/permissions/refresh'?request(j.kind,true):request(j.kind,false,{openSettings:j.openSettings===true}));}
  catch(e){return send(e.status||500,{ok:false,error:e.message});}
 }
 return {route,status,fromHelper,request,settingsUrl};
}
module.exports={create,STALE_MS,REFRESH_COOLDOWN_MS,RECYCLE_COOLDOWN_MS};