'use strict';
// Only verbatim excerpts validated by meeting-frame enter the document. The
// private frame (purpose/need/avoid) remains outside the user's working text.
const crypto=require('crypto');
const safeLink=value=>{try{const url=new URL(value);return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password&&!/[\\\x00-\x20]/.test(value);}catch{return false;}};
function modules(session={}){
 if(session.trial)return [];
 const state=session.nativeInsights?.understanding,groups=new Map();
 for(const item of state?.excerpts||[]){
  const quote=String(item?.quote||'').trim(),url=String(item?.url||'').trim(),title=String(item?.title||'').trim();
  if(!quote||quote.length>240||!title||!/^https?:\/\//.test(url)||!safeLink(url))continue;
  const doc=state.documents?.find(d=>d.url===url&&d.title===title);if(!doc)continue;
  const key=String(doc.id||url),group=groups.get(key)||{title,url,quotes:[],sourceRefs:['document:'+key]};
  if(!group.quotes.includes(quote))group.quotes.push(quote);groups.set(key,group);
 }
 return [...groups.entries()].map(([key,g])=>({id:'meeting-frame-material-'+crypto.createHash('sha256').update(key).digest('hex').slice(0,24),kind:'note',title:g.title,body:g.quotes.join('\n\n')+'\n\n['+g.title.replace(/[\[\]\\]/g,'\\$&')+']('+g.url+')',sourceRefs:g.sourceRefs,documentSection:'notes',documentMeetingType:require('./meeting-document-layout').meetingType(session)}));
}
function sync(store,source,session){
 if(!source?.motherDocumentId||!session?.id)return {updated:0,conflicts:[]};
 const incoming=modules(session);if(!incoming.length)return {updated:0,conflicts:[]};
 const record=store.read(source.motherDocumentId).record;if(record.fork)return {updated:0,conflicts:[]};
 const result={updated:0,conflicts:[]};
 for(const module of incoming){const imported=store.importModule(source.motherDocumentId,module,session.id);if(imported?.conflict)result.conflicts.push(module.id);else if(imported?.revision)result.updated++;}
 return result;
}
module.exports={modules,sync};
