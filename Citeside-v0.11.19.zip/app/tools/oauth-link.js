'use strict';
// LARK-MULTITENANT / DOCS-LARK-OAUTH / DOCS-NOTION-OAUTH：本机这一半的官方授权。
// 流程：设置页点「连接飞书」→ /oauth/start/feishu 生成 state + PKCE，跳到飞书官方授权页 →
//       飞书带授权码回到本机 /oauth/callback/feishu → 本机把授权码交给令牌换取服务（services/oauth-exchange，
//       只有它握 client_secret）→ 拿到令牌后本机直连飞书核实「这是谁」→ 绑进本机产品账号（product-account），
//       令牌按绑定存（开钥匙串就进钥匙串，否则绑定目录下 token.json 0600）。
// 之后读日历 / 文档都由本机拿令牌直连平台接口，不再经过换取服务。
// 换取服务地址：设置项 OAUTH_EXCHANGE_URL（或环境变量 THT_OAUTH_EXCHANGE_URL）；没配就整条路显示「未配置」，旧的 lark-cli / NOTION_TOKEN 照常可用。
const crypto = require('crypto'), path = require('path');
const account = require('../product-account'), secrets = require('../secret-store');

// 飞书权限名按开放平台公开文档填写，未在真实商店应用上逐项核对（待核实）；可用设置项 FEISHU_OAUTH_SCOPES 覆盖。
const SCOPES = {
  base: 'offline_access calendar:calendar:readonly calendar:calendar.event:read',
  docs: 'docx:document:readonly wiki:wiki:readonly drive:drive:readonly search:docs:read',
};
const ACCOUNT_PROVIDER = { feishu: 'lark', lark: 'lark', notion: 'notion' };
const PENDING_MS = 10 * 60e3;
const pending = new Map();         // state → { provider, verifier, redirectUri, scopes, at }
let providerCache = { url: '', at: 0, list: null };

// 设置项优先；环境变量 THT_OAUTH_EXCHANGE_URL 给启动器 / 开发用（调用方传进来的 env 是设置对象，不含进程环境变量）。
const exchangeUrl = env => String(env.OAUTH_EXCHANGE_URL || env.THT_OAUTH_EXCHANGE_URL || process.env.THT_OAUTH_EXCHANGE_URL || '').replace(/\/+$/, '');
const b64url = buf => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

async function jsonFetch(f, url, opts = {}) {
  const r = await f(url, { ...opts, signal: AbortSignal.timeout(opts.timeout || 15000) });
  let j = null; try { j = await r.json(); } catch (e) {}
  return { status: r.status, ok: r.ok, json: j };
}

// 换取服务上配了哪几家（client_id、授权页地址是公开信息，从服务拿，安装包里不写死）。
async function providers(env, { fetchImpl = globalThis.fetch, now = Date.now() } = {}) {
  const base = exchangeUrl(env);
  if (!base) return { ok: false, error: '未配置令牌换取服务（OAUTH_EXCHANGE_URL）', providers: {} };
  if (providerCache.url === base && providerCache.list && now - providerCache.at < 10 * 60e3) return { ok: true, providers: providerCache.list };
  try {
    const r = await jsonFetch(fetchImpl, base + '/v1/providers');
    if (!r.ok || !r.json || !r.json.ok) return { ok: false, error: '令牌换取服务没有响应（' + r.status + '）', providers: {} };
    providerCache = { url: base, at: now, list: r.json.providers || {} };
    return { ok: true, providers: providerCache.list };
  } catch (e) { return { ok: false, error: '连不上令牌换取服务', providers: {} }; }
}

function sweep(now) { for (const [k, v] of pending) if (now - v.at > PENDING_MS) pending.delete(k); }

// 生成跳转到官方授权页的地址。want='docs' 时在基础权限上增量申请文档权限（飞书）。
async function start(provider, { env, port, want = 'base', fetchImpl, now = Date.now() } = {}) {
  if (!ACCOUNT_PROVIDER[provider]) return { ok: false, error: '不支持的平台' };
  const list = await providers(env, { fetchImpl, now });
  if (!list.ok) return list;
  const p = list.providers[provider];
  if (!p) return { ok: false, error: '令牌换取服务还没有配置这家平台' };
  sweep(now);
  const state = b64url(crypto.randomBytes(24)), redirectUri = `http://127.0.0.1:${port}/oauth/callback/${provider}`;
  const q = new URLSearchParams({ client_id: p.clientId, redirect_uri: redirectUri, state, response_type: 'code' });
  let verifier = '', scopes = '';
  if (provider === 'notion') q.set('owner', 'user');
  else {
    scopes = String(env.FEISHU_OAUTH_SCOPES || SCOPES.base) + (want === 'docs' ? ' ' + SCOPES.docs : '');
    q.set('scope', scopes);
  }
  if (p.pkce) {
    verifier = b64url(crypto.randomBytes(48));
    q.set('code_challenge', b64url(crypto.createHash('sha256').update(verifier).digest()));
    q.set('code_challenge_method', 'S256');
  }
  pending.set(state, { provider, verifier, redirectUri, scopes, at: now });
  return { ok: true, url: p.authorizeUrl + '?' + q.toString(), state };
}

const blobOpts = (dataDir, env, dir) => ({ useKeychain: secrets.enabled(safeSettings(dataDir), env), fallbackFile: path.join(dir, 'token.json') });
function safeSettings(dataDir) { try { return JSON.parse(require('fs').readFileSync(path.join(dataDir, 'settings.json'), 'utf8')); } catch (e) { return {}; } }
const blobName = key => 'OAUTH_' + key;
function dirOf(dataDir, key) { const a = account.load(dataDir); return path.join(dataDir, 'accounts', a.userId, key); }

// 拿令牌后直连平台核实身份：飞书 user_info；Notion 用换取回包里的授权人 + 工作区，再用 users/me 对一遍。
async function identify(provider, token, apiBase, f) {
  if (provider === 'notion') {
    if (!token.workspaceId || !token.ownerUserId) return { ok: false, error: 'Notion 没有返回授权人和工作区' };
    const r = await require('./notion').whoAmI(token.accessToken, f);
    if (!r.ok) return { ok: false, error: '用新令牌读不到 Notion 身份（' + r.status + '）' };
    if (r.ownerUserId && r.ownerUserId !== token.ownerUserId) return { ok: false, error: 'Notion 授权人和令牌不一致' };
    return { ok: true, externalId: token.workspaceId + ':' + token.ownerUserId, label: (token.workspaceName || 'Notion') + (token.ownerName ? ' · ' + token.ownerName : '') };
  }
  const r = await jsonFetch(f, apiBase + '/open-apis/authen/v1/user_info', { headers: { Authorization: 'Bearer ' + token.accessToken } });
  const d = r.json && r.json.code === 0 && r.json.data;
  if (!d || !d.open_id) return { ok: false, error: '用新令牌读不到飞书身份（' + (r.json && r.json.code || r.status) + '）' };
  return { ok: true, externalId: provider + ':' + (d.tenant_key || '-') + ':' + d.open_id, label: (provider === 'feishu' ? '飞书' : 'Lark') + ' · ' + String(d.name || d.en_name || '').slice(0, 60), tenantKey: d.tenant_key || '' };
}

// 授权页回到本机后调用。state 一次性、10 分钟内有效、必须是本机发起的那一家。
async function callback(provider, { code, state, error }, { env, dataDir, fetchImpl = globalThis.fetch, now = Date.now() } = {}) {
  const pend = pending.get(String(state || ''));
  if (!pend || pend.provider !== provider || now - pend.at > PENDING_MS) return { ok: false, error: '授权链接已过期或不是从本机发起的，请回到设置页重新点「连接」' };
  pending.delete(String(state));
  if (error) return { ok: false, error: error === 'access_denied' ? '你在授权页取消了授权' : '授权页返回错误：' + String(error).slice(0, 60) };
  if (!code) return { ok: false, error: '授权页没有带回授权码' };
  const base = exchangeUrl(env), list = await providers(env, { fetchImpl, now });
  const p = list.ok && list.providers[provider];
  if (!p) return { ok: false, error: list.error || '令牌换取服务还没有配置这家平台' };
  let r;
  try {
    r = await jsonFetch(fetchImpl, base + '/v1/token', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, grant: 'authorization_code', code, redirectUri: pend.redirectUri, codeVerifier: pend.verifier || undefined }) });
  } catch (e) { return { ok: false, error: '连不上令牌换取服务' }; }
  if (!r.ok || !r.json || !r.json.ok) return { ok: false, error: (r.json && r.json.error) || '换取令牌失败（' + r.status + '）' };
  const token = r.json.token;
  const who = await identify(provider, token, p.apiBase, fetchImpl).catch(() => ({ ok: false, error: '核实身份时连不上平台' }));
  if (!who.ok) return who;
  const bound = account.bind(dataDir, { provider: ACCOUNT_PROVIDER[provider], externalId: who.externalId, label: who.label, proof: { verifiedBy: 'oauth:' + provider, subject: who.externalId } }, now);
  const record = {
    platform: provider, apiBase: p.apiBase, accessToken: token.accessToken, refreshToken: token.refreshToken,
    expiresAt: token.expiresIn ? now + token.expiresIn * 1000 : 0, refreshExpiresAt: token.refreshExpiresIn ? now + token.refreshExpiresIn * 1000 : 0,
    scope: token.scope || pend.scopes, savedAt: now,
  };
  const stored = secrets.putBlob(dataDir, blobName(bound.binding.key), record, blobOpts(dataDir, env, bound.dir), env);
  return { ok: true, key: bound.binding.key, label: who.label, stored: stored.where, scope: record.scope };
}

// 给读日历 / 读文档的地方用：拿这家平台第一个绑定的有效令牌，快过期就先刷新。没有绑定返回 null（调用方退回 lark-cli / NOTION_TOKEN）。
async function accessToken(platform, { env, dataDir, fetchImpl = globalThis.fetch, now = Date.now() } = {}) {
  let a; try { a = account.load(dataDir, now); } catch (e) { return null; }
  for (const b of a.bindings.filter(x => x.provider === ACCOUNT_PROVIDER[platform])) {
    const dir = path.join(dataDir, 'accounts', a.userId, b.key), opts = blobOpts(dataDir, env, dir);
    const rec = secrets.getBlob(dataDir, blobName(b.key), opts, env);
    if (!rec || rec.platform !== platform || !rec.accessToken) continue;
    if (!rec.expiresAt || rec.expiresAt - 60e3 > now) return { token: rec.accessToken, apiBase: rec.apiBase, scope: rec.scope, key: b.key };
    if (!rec.refreshToken || (rec.refreshExpiresAt && rec.refreshExpiresAt < now)) return { expired: true, key: b.key, error: '授权已过期，请到设置页重新连接' };
    const base = exchangeUrl(env);
    if (!base) return { expired: true, key: b.key, error: '授权已过期，且没有配置令牌换取服务' };
    let r;
    try { r = await jsonFetch(fetchImpl, base + '/v1/token', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ provider: platform, grant: 'refresh_token', refreshToken: rec.refreshToken }) }); }
    catch (e) { return { expired: true, key: b.key, error: '刷新授权时连不上令牌换取服务' }; }
    if (!r.ok || !r.json || !r.json.ok) return { expired: true, key: b.key, error: (r.json && r.json.error) || '刷新授权失败' };
    const t = r.json.token;
    const next = { ...rec, accessToken: t.accessToken, refreshToken: t.refreshToken || rec.refreshToken,
      expiresAt: t.expiresIn ? now + t.expiresIn * 1000 : 0, refreshExpiresAt: t.refreshExpiresIn ? now + t.refreshExpiresIn * 1000 : rec.refreshExpiresAt, savedAt: now };
    secrets.putBlob(dataDir, blobName(b.key), next, opts, env);
    return { token: next.accessToken, apiBase: next.apiBase, scope: next.scope, key: b.key };
  }
  return null;
}

// 断开：Notion 调官方撤销；飞书 / Lark 没有给第三方的撤销用户令牌接口（待核实），只删本机，并告诉用户去哪里彻底收回。
async function disconnect(key, { env, dataDir, fetchImpl = globalThis.fetch } = {}) {
  const dir = dirOf(dataDir, key), opts = blobOpts(dataDir, env, dir);
  const rec = secrets.getBlob(dataDir, blobName(key), opts, env);
  const result = await account.unbind(dataDir, key, { revoke: async () => {
    if (!rec) return;
    if (rec.platform !== 'notion') throw Error('飞书没有提供撤销接口：本机令牌已删除；要彻底收回，请在飞书「设置 → 隐私 → 授权管理」移除Citeside');
    const base = exchangeUrl(env);
    if (!base) throw Error('没有配置令牌换取服务，无法通知 Notion 撤销；本机令牌已删除');
    const r = await jsonFetch(fetchImpl, base + '/v1/revoke', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ provider: 'notion', token: rec.accessToken }) });
    if (!r.ok || !r.json || !r.json.ok) throw Error((r.json && r.json.error) || 'Notion 撤销失败');
  } });
  secrets.dropBlob(dataDir, blobName(key), opts, env);
  return result;
}

// 同步判断有没有绑定（工具登记表的 available 是同步的）。没有 account.json 时不新建。
function hasBinding(platform, dataDir) {
  if (!dataDir || !require('fs').existsSync(path.join(dataDir, 'account.json'))) return false;
  try { return account.load(dataDir).bindings.some(b => b.provider === ACCOUNT_PROVIDER[platform]); } catch (e) { return false; }
}

// 绑定了的外部身份（Notion = workspaceId:ownerUserId）。manual-forwards 用它核对「这页是不是 Aaron 本人改的」。没绑定返回 ''。
function boundExternalId(platform, dataDir) {
  if (!hasBinding(platform, dataDir)) return '';
  try { const b = account.load(dataDir).bindings.find(x => x.provider === ACCOUNT_PROVIDER[platform]); return String((b && b.externalId) || ''); } catch (e) { return ''; }
}

async function status({ env, dataDir, fetchImpl } = {}) {
  const list = await providers(env, { fetchImpl });
  let view = { userId: '', bindings: [] }; try { view = account.publicView(dataDir); } catch (e) {}
  return { configured: list.ok, error: list.ok ? '' : list.error, available: Object.keys(list.providers || {}), bindings: view.bindings.filter(b => b.provider === 'lark' || b.provider === 'notion') };
}

module.exports = { start, callback, accessToken, disconnect, status, hasBinding, boundExternalId, providers, SCOPES, _pending: pending, _reset: () => { pending.clear(); providerCache = { url: '', at: 0, list: null }; } };
