'use strict';
// 飞书工具。读类两条（搜文档、取文档），写类两条（建日历、建任务）。
// 写类只有界面点「发出 / 派发」那条路能执行（登记表里的 confirmedByUser 门禁），模型和 MCP 永远拿不到。
//
// 真实命令形状（2026-09-22 用 --as user 只读实测）：
//   lark-cli docs +search --query <词> --as user --page-size 15 --format json
//     → { ok, data:{ has_more, page_token, total, results:[{ entity_type, title_highlighted, summary_highlighted,
//          result_meta:{ token, url, doc_types, owner_name, edit_user_name, create_time_iso, update_time_iso, last_open_time_iso } }] } }
//     标题和摘要里命中的词被 <h></h> 包着，要剥掉再给人看。
//   lark-cli docs +fetch --doc <token|url> --as user --doc-format markdown --format json [--scope outline|keyword --keyword <词>]
//     → { ok, data:{ document:{ content, document_id, revision_id } } }
const { runCli, larkAvailable: cliAvailable, resolveIds, clip } = require('./lark-cli');
const larkApi = require('./lark-api'), oauth = require('./oauth-link');
// DOCS-LARK-OAUTH：读文档的两条工具在有官方授权时直连开放平台，没有授权才走本机 lark-cli。日历和会议关联那几条仍只走 lark-cli。
const docsAvailable = (env, ctx) => (ctx && oauth.hasBinding('feishu', ctx.dataDir)) ? { ok: true } : cliAvailable();
const larkAvailable = cliAvailable;
const authHint = r => r.needsScope ? r.error + '。到设置页点「连接飞书 · 文档权限」补授权' : r.error;
// 官方接口只给纯文本：outline 取开头一段，keyword 本机按词挑段落（前 1 后 2 行），和 lark-cli 的取法对齐。
function scoped(text, scope, keyword) {
  if (scope === 'keyword') {
    let re; try { re = new RegExp(keyword, 'i'); } catch (e) { re = new RegExp(keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); }
    const lines = text.split('\n'), keep = new Set();
    lines.forEach((l, i) => { if (re.test(l)) for (let k = i - 1; k <= i + 2; k++) if (k >= 0 && k < lines.length) keep.add(k); });
    return [...keep].sort((a, b) => a - b).map(i => lines[i]).join('\n');
  }
  return scope === 'outline' ? text.slice(0, 4000) : text;
}

const unTag = s => String(s || '').replace(/<\/?h>/g, '');
const dig = (o, ...ks) => { for (const k of ks) { const v = k.split('.').reduce((x, p) => (x == null ? x : x[p]), o); if (typeof v === 'string' && v) return v; } return ''; };

// 工具登记：由 index.js 单向装配时调 registerAll(reg) 把登记口注入进来（主题 2 阶段 1 环消除，
// 本文件不再 require('./index')）。下面 reg.register 的定义与调用风格逐字保留，只是 reg 变成参数。
function registerAll(reg) {
  // Exact platform IDs only; titles and document contents cannot establish these links.
  for (const spec of [
    {name:'lark.calendar.meeting',key:'eventId',flag:'--event-ids',cmd:['calendar','+meeting'],path:'meetings',id:'event_id',pattern:/^[A-Za-z0-9_-]{12,100}$/},
    {name:'lark.meetings.detail',key:'meetingId',flag:'--meeting-ids',cmd:['vc','+detail'],path:'meetings',id:'meeting_id',pattern:/^\d{10,30}$/},
    {name:'lark.notes.detail',key:'noteId',flag:'--note-id',cmd:['note','+detail'],path:'note',id:'note_id',pattern:/^\d{10,30}$/},
  ]) reg.register({
    name:spec.name,title:'读取关联会议资料',description:'以平台原始标识读取关联，始终沿用已登录用户身份。',level:'read',source:'lark',
    input:{type:'object',required:[spec.key],properties:{[spec.key]:{type:'string',minLength:10,maxLength:100},...(spec.key==='eventId'?{calendarId:{type:'string',maxLength:200}}:{})}},
    available:()=>larkAvailable(),
    async run(args,ctx){
      if(!spec.pattern.test(args[spec.key]))return {ok:false,error:'Invalid platform identifier'};
      const argv=[...spec.cmd,spec.flag,args[spec.key],'--as','user','--format','json'];
      // The platform mapping API accepts only the logged-in user's primary calendar.
      // Organizer calendar IDs from agenda events remain provenance, not API scope.
      if(spec.key==='eventId')argv.push('--calendar-id','primary');
      const r=await runCli(argv,{execImpl:ctx.execImpl,log:ctx.log,timeout:30000});
      if(!r.ok)return {ok:false,error:r.error};
      if(r.json.identity!=='user')return {ok:false,error:'Source identity is not verified'};
      const value=r.json.data?.[spec.path],rows=Array.isArray(value)?value:value?[value]:[];
      const matches=rows.filter(x=>x?.[spec.id]===args[spec.key]);
      if(matches.length!==1)return {ok:false,error:'Platform association is missing or ambiguous'};
      const x=matches[0],data={identity:'user',[spec.id]:x[spec.id]};
      for(const k of ['meeting_id','note_id','meeting_no','topic','start_time','end_time','minute_token','note_display_type','note_doc_token','verbatim_doc_token'])
        if(typeof x[k]==='string')data[k]=x[k].slice(0,400);
      if(Array.isArray(x.shared_doc_tokens))data.shared_doc_tokens=x.shared_doc_tokens.filter(t=>typeof t==='string'&&/^[A-Za-z0-9]{8,64}$/.test(t)).slice(0,20);
      return {ok:true,data};
    },
  });

  reg.register({
    name: 'lark.docs.search', title: '搜飞书文档', level: 'read', source: 'lark',
    description: '按关键词搜飞书云文档和知识库（Search v2）。返回标题、摘要、文档 token 和链接；要正文再用 lark.docs.fetch。',
    input: { type: 'object', required: ['query'], properties: {
      query: { type: 'string', minLength: 1, maxLength: 200 },
      limit: { type: 'integer', minimum: 1, maximum: 20, default: 8 },
    } },
    available: docsAvailable,
    async run(args, ctx) {
      const viaApi = await larkApi.searchDocs(args.query, ctx, { pageSize: Math.min(20, args.limit || 8) });
      // 官方授权读不到（缺权限 / 过期）且本机有 lark-cli 时退回 lark-cli，不让已有用法变差。
      if (viaApi && !viaApi.ok && !cliAvailable().ok) return { ok: false, error: authHint(viaApi) };
      const r = viaApi && viaApi.ok ? { ok: true, json: viaApi } : await runCli(['docs', '+search', '--query', args.query, '--as', 'user',
        '--page-size', String(Math.min(20, args.limit || 8)), '--format', 'json'],
        { execImpl: ctx.execImpl, log: ctx.log, timeout: 30000 });
      if (!r.ok) return { ok: false, error: r.error };
      const results = ((r.json || {}).data || {}).results || [];
      return { ok: true, items: results.slice(0, args.limit).map(x => {
        const m = x.result_meta || {};
        return {
          title: clip(unTag(x.title_highlighted), 200),
          text: clip(unTag(x.summary_highlighted), 400),
          docType: x.entity_type || '', token: m.token || '', url: m.url || '',
          owner: m.owner_name || '', lastEditedBy: m.edit_user_name || '',
          ref: m.token ? 'lark:' + m.token : 'lark:' + clip(unTag(x.title_highlighted), 40),
          source: 'lark:docs', at: m.update_time_iso || m.create_time_iso || '',
        };
      }) };
    },
  });

  reg.register({
    name: 'lark.docs.fetch', title: '取飞书文档正文', level: 'read', source: 'lark',
    description: '按文档 token 或链接取正文（Markdown）。scope=outline 只取目录，scope=keyword 配 keyword 只取命中的那几段——整份很长时先用这两种。',
    input: { type: 'object', required: ['doc'], properties: {
      doc: { type: 'string', minLength: 6, maxLength: 400, description: '文档 token 或飞书链接' },
      scope: { type: 'string', enum: ['full', 'outline', 'keyword'], default: 'outline' },
      keyword: { type: 'string', maxLength: 120, description: 'scope=keyword 时要找的词，支持 a|b 这种或关系' },
    } },
    available: docsAvailable,
    async run(args, ctx) {
      const doc = String(args.doc).trim();
      if (!/^https?:\/\//.test(doc) && !/^[A-Za-z0-9]{8,64}$/.test(doc)) return { ok: false, error: 'doc 要是飞书链接或文档 token' };
      if (/^https?:\/\//.test(doc)) {
        let host = ''; try { host = new URL(doc).hostname; } catch (e) {}
        if (!/(^|\.)(larksuite\.com|feishu\.cn|doubao\.com)$/.test(host)) return { ok: false, error: '这不是飞书文档链接' };
      }
      const a = ['docs', '+fetch', '--doc', doc, '--as', 'user', '--doc-format', 'markdown', '--format', 'json'];
      if (args.scope === 'outline') a.push('--scope', 'outline');
      if (args.scope === 'keyword') {
        if (!args.keyword) return { ok: false, error: 'scope=keyword 要同时给 keyword' };
        a.push('--scope', 'keyword', '--keyword', args.keyword, '--context-before', '1', '--context-after', '2');
      }
      if (args.scope === 'keyword' && !args.keyword) return { ok: false, error: 'scope=keyword 要同时给 keyword' };
      const viaApi = await larkApi.fetchDoc(doc, ctx);
      if (viaApi && !viaApi.ok && !cliAvailable().ok) return { ok: false, error: authHint(viaApi) };
      const r = viaApi && viaApi.ok ? { ok: true, json: viaApi } : await runCli(a, { execImpl: ctx.execImpl, log: ctx.log, timeout: 60000 });
      if (!r.ok) return { ok: false, error: r.error };
      const d = ((r.json || {}).data || {}).document || {};
      const content = viaApi && viaApi.ok ? scoped(String(d.content || ''), args.scope || 'outline', args.keyword || '') : String(d.content || '');
      if (!content) return { ok: false, error: '这份文档没读到正文（可能没权限，或这一段是空的）' };
      return { ok: true, data: {
        text: content, docId: d.document_id || '', revision: d.revision_id || 0, scope: args.scope || 'outline',
        ref: 'lark:' + (d.document_id || doc), source: 'lark:docs', at: String(d.revision_id || ''),
        url: /^https?:\/\//.test(doc) ? doc : '',
      } };
    },
  });

  // ===== 写类：只有界面点击那条路能走到 =====
  reg.register({
    name: 'lark.calendar.create', title: '建飞书日历', level: 'write', source: 'lark',
    description: '按草稿建一场飞书日历。只有你在界面上点「发出会议邀请」才会执行。',
    input: { type: 'object', required: ['title', 'start', 'end'], properties: {
      title: { type: 'string', minLength: 1, maxLength: 120 },
      start: { type: 'string', minLength: 10, maxLength: 40, description: '本机时区的 ISO 串' },
      end: { type: 'string', minLength: 10, maxLength: 40 },
      note: { type: 'string', maxLength: 400, default: '' },
      agenda: { type: 'array', maxItems: 10, default: [], items: { type: 'string', maxLength: 200 } },
      attendees: { type: 'array', maxItems: 20, default: [], items: { type: 'string', maxLength: 40 } },
    } },
    available: () => larkAvailable(),
    async run(args, ctx) {
      const opts = { execImpl: ctx.execImpl, log: ctx.log };
      const got = args.attendees.length ? await resolveIds(args.attendees, opts) : { ok: true, ids: [], missing: [] };
      const ids = got.ids || [], missing = got.missing || [];
      const desc = [args.note, args.agenda.length ? '议程：\n' + args.agenda.map((x, i) => (i + 1) + '. ' + x).join('\n') : '',
        missing.length ? '（还没解析到飞书账号的人：' + missing.join('、') + '）' : ''].filter(Boolean).join('\n\n');
      const a = ['calendar', '+create', '--as', 'user', '--summary', args.title, '--start', args.start, '--end', args.end, '--format', 'json'];
      if (desc) a.push('--description', desc);
      if (ids.length) a.push('--attendee-ids', ids.join(','));
      const r = await runCli(a, opts);
      if (!r.ok) return { ok: false, error: r.error, uncertain: !!r.uncertain };
      return { ok: true, data: {
        url: dig(r.json, 'data.event.app_link', 'data.event.url', 'data.app_link', 'data.url'),
        id: dig(r.json, 'data.event.event_id', 'data.event_id'), missing,
        ref: 'lark:calendar:' + (dig(r.json, 'data.event.event_id', 'data.event_id') || ''), source: 'lark:calendar', at: args.start,
      } };
    },
  });

  reg.register({
    name: 'lark.task.create', title: '建飞书任务', level: 'write', source: 'lark',
    description: '按草稿建一条飞书任务并派给人。只有你在界面上点「派发」才会执行。',
    input: { type: 'object', properties: {
      description: { type: 'string', maxLength: 2000, default: '' },
      assignee: { type: 'string', maxLength: 60, default: '' },
      assigneeId: { type: 'string', maxLength: 80, default: '' },
      due: { type: 'string', maxLength: 10, default: '', description: 'YYYY-MM-DD' },
      links: { type: 'array', maxItems: 6, default: [], items: { type: 'string', maxLength: 400 } },
    } },
    available: () => larkAvailable(),
    async run(args, ctx) {
      const opts = { execImpl: ctx.execImpl, log: ctx.log };
      const summary = args.description.split('\n')[0].slice(0, 120) || args.assignee;
      if (!summary) return { ok: false, error: '草稿是空的' };
      const a = ['task', '+create', '--as', 'user', '--summary', summary, '--format', 'json'];
      const body = [args.description, args.links.length ? '相关链接：\n' + args.links.join('\n') : ''].filter(Boolean).join('\n\n');
      if (body) a.push('--description', body);
      if (/^\d{4}-\d{2}-\d{2}$/.test(args.due)) a.push('--due', args.due);   // lark-cli 1.0.96 的 date: 前缀会解析失败（09-22 真派发报错），裸 YYYY-MM-DD 建成全天截止
      let assigneeId = /^(?:ou_|cli_)[A-Za-z0-9]{1,64}$/.test(args.assigneeId) ? args.assigneeId : '';
      let miss = '';
      if (!assigneeId && args.assignee) { const got = await resolveIds([args.assignee], opts); assigneeId = (got.ids || [])[0] || ''; }
      // 解析不到账号就不硬派：任务照建，把人名写进说明，并在卡片上说清「没派到人」，不让它悄悄丢。
      if (assigneeId) a.push('--assignee', assigneeId);
      else if (args.assignee) {
        miss = args.assignee;
        const add = '（没解析到 ' + miss + ' 的飞书账号，这条先挂在我名下）', i = a.indexOf('--description');
        if (i >= 0) a[i + 1] += '\n\n' + add; else a.push('--description', add);
      }
      const r = await runCli(a, opts);
      if (!r.ok) return { ok: false, error: r.error, uncertain: !!r.uncertain };
      const id = dig(r.json, 'data.task.guid', 'data.task.task_id', 'data.guid');
      return { ok: true, data: {
        url: dig(r.json, 'data.task.url', 'data.url'), id,
        note: miss ? '没解析到 ' + miss + ' 的飞书账号，任务建了但没派到人' : '',
        ref: 'lark:task:' + id, source: 'lark:task', at: args.due || '',
      } };
    },
  });

  reg.register({
    name: 'lark.task.get', title: '看飞书任务是否完成', level: 'read', source: 'lark',
    description: '读一条飞书任务（按 guid）是否已完成，用来把飞书侧的完成同步回「Aaron 待办」。',
    input: { type: 'object', required: ['id'], properties: { id: { type: 'string', maxLength: 80 } } },
    available: () => larkAvailable(),
    async run(args, ctx) {
      if (!/^[A-Za-z0-9_-]{1,80}$/.test(args.id)) return { ok: false, error: '任务 id 不对' };
      const r = await runCli(['task', 'tasks', 'get', '--as', 'user', '--task-guid', args.id, '--format', 'json'], { execImpl: ctx.execImpl, log: ctx.log });
      if (!r.ok) return { ok: false, error: r.error };
      const t = (r.json && r.json.data && r.json.data.task) || {}, at = String(t.completed_at || '0');
      return { ok: true, data: { id: args.id, completed: at !== '0' && at !== '', completedAt: at !== '0' ? at : '', ref: 'lark:task:' + args.id, source: 'lark:task' } };
    },
  });

  reg.register({
    name: 'lark.message.send', title: '发飞书私信', level: 'write', source: 'lark',
    description: '给一位飞书联系人发送确认过的消息。只有界面明确确认后才会执行。',
    input: { type: 'object', required: ['recipient', 'text'], properties: {
      recipient: { type: 'string', minLength: 1, maxLength: 80, description: '姓名或 open_id' },
      text: { type: 'string', minLength: 1, maxLength: 4000 },
    } },
    available: () => larkAvailable(),
    async run(args, ctx) {
      const opts = { execImpl: ctx.execImpl, log: ctx.log };
      let openId = /^ou_[A-Za-z0-9]{1,64}$/.test(args.recipient) ? args.recipient : '';
      if (!openId) { const got = await resolveIds([args.recipient], opts); openId = (got.ids || [])[0] || ''; }
      if (!openId) return { ok: false, error: '没找到 ' + args.recipient + ' 的飞书账号' };
      const r = await _cli.messageSend({ openId, markdown: args.text }, opts);
      if (!r.ok) return r;
      return { ok: true, data: { id: r.messageId || '', ref: 'lark:message:' + (r.messageId || ''), source: 'lark:im', at: new Date().toISOString() } };
    },
  });
}

// 洞察卡动作（app/insight-actions.js，批 3）直接调的三个只读 / 写类底层函数：找人、文档链接回读、建任务。
// 命令行都在 ./lark-cli 里拼，这里只是工具层对外的口；写类（建任务）由调用方先过 send-gate 的确认与幂等。
const _cli = require('./lark-cli');
module.exports = { registerAll, LOGOUT_COMMAND: _cli.LOGOUT_COMMAND, resolveIds, docInspect: _cli.docInspect, taskCreate: _cli.taskCreate, messageSend: _cli.messageSend, docCreate: _cli.docCreate, docAppend: _cli.docAppend, docValidateAppend: _cli.docValidateAppend, docFetchMarkdown: _cli.docFetchMarkdown, larkAvailable, selfOpenId: _cli.selfOpenId };
