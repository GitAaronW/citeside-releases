'use strict';
// Notion 读类工具。按官方 API 实现：POST /v1/search、GET /v1/blocks/{id}/children，都要 Notion-Version 头。
// Native MCP serves registered reads; configured OAuth/token writes keep precedence.
// With no configured credentials, the existing local connector may relay document sync.
// ⚠️ 2026-09-22 交付时只用假服务端测过，没连过真的 Notion（本机设置里没有 NOTION_TOKEN）。

const API = 'https://api.notion.com/v1/';
const VERSION = '2022-06-28';
const clip = (s, n) => String(s == null ? '' : s).slice(0, n);
const link = require('./oauth-link');
const bridge = require('../notion-mcp-bridge');
const useMcp = ctx => !ctx.notionMcpNative && !ctx.fetchImpl && !tokenOf(ctx.env) && !link.hasBinding('notion', ctx.dataDir) && bridge.connected(ctx);
const tokenOf = env => String((env || {}).NOTION_TOKEN || '').trim();
const connection = require('../notion-connection');
const relayFor = connection.relayFor;

// Notion 的文字都摊在 rich_text 数组里，标题还分 title / Name 两种属性名，统一在这里抽。
function plain(rich) { return (Array.isArray(rich) ? rich : []).map(x => String(x?.plain_text ?? x?.text?.content ?? '')).join(''); }
function titleOf(page) {
  const props = (page && page.properties) || {};
  for (const v of Object.values(props)) if (v && v.type === 'title') return plain(v.title);
  if (page && page.title) return plain(page.title);
  return '';
}
function blockText(b) {
  const t = b && b.type;
  const body = t && b[t];
  if (!body) return '';
  if (Array.isArray(body.rich_text)) return plain(body.rich_text);
  if (Array.isArray(body.caption)) return plain(body.caption);
  if (typeof body.title === 'string') return body.title;
  return '';
}
// Only fixed local messages may cross the provider boundary; remote bodies may contain secrets.
function httpError(status) {
  const reasons={400:'请求参数无效，请检查页面和操作内容',401:'凭据无效或已过期，请在设置页重新连接 Notion',403:'无权访问，请将页面共享给已配置的 Notion 集成',404:'页面不存在或不可访问，请检查链接与共享权限',409:'内容发生冲突，请重新读取后重试',429:'请求过于频繁，请稍后重试'};
  const reason=reasons[status]||(status>=500?'服务暂时不可用，请稍后重试':null);
  return 'Notion '+(reason||'请求失败')+(Number.isInteger(status)?'（HTTP '+status+'）':'');
}
async function api(ctx, method, endpoint, body) {
  if(ctx.notionMcpNative&&method==='GET')return bridge.request(ctx,endpoint);
  const relay=tokenOf(ctx.env)||link.hasBinding('notion',ctx.dataDir)?null:relayFor(ctx);
  if(relay && await relay.available()){
    const result=await relay.request(method,endpoint,body);
    // Never replay a write whose result is uncertain through another transport.
    if(result.ok || result.uncertain || result.blocked)return result;
  }
  if (relay) {
    const cli = bridge.cliStatus(ctx);
    if (cli.cliError && !cli.cliEffectiveKey) return { ok: false, blocked: true, error: cli.cliError };
  }
  // DOCS-NOTION-OAUTH：有官方授权（用户在 Notion 授权页勾选过页面）就用它，没有才用设置里的 NOTION_TOKEN。
  const oauth = ctx.dataDir ? await link.accessToken('notion', ctx) : null;
  if (oauth && oauth.expired && !tokenOf(ctx.env)) return { ok: false, error: oauth.error };
  // NOTION-REUSE-AUTH：没有自己的授权时沿用本机 Claude / Codex 已有的 Notion 授权，设置里不用填 token。
  const token = oauth && oauth.token || tokenOf(ctx.env) || bridge.reusedBearer(ctx.notionHome||ctx.env?.HOME||require('os').homedir()).token;
  if (!token) return { ok: false, error: '没有连接 Notion：到设置页点「连接 Notion」' };
  const f = ctx.fetchImpl || globalThis.fetch;
  if (typeof f !== 'function') return { ok: false, error: '这个 Node 没有 fetch' };
  try {
    const r = await f((ctx.notionBase || API) + endpoint, {
      method, headers: { Authorization: 'Bearer ' + token, 'Notion-Version': VERSION, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000),
    });
    let j;
    try { j = await r.json(); } catch (e) { if(r.ok)throw e; }
    if (!r.ok || j && j.object === 'error') return { ok: false, status: r.status, uncertain: method !== 'GET' && r.status >= 500, error: httpError(r.status) };
    return { ok: true, json: j };
  } catch (e) { return { ok: false, uncertain: method !== 'GET', error: 'Notion 暂时无法连接，请稍后重试' }; }
}
// Iterative depth-first traversal preserves document order without an arbitrary depth cutoff.
// Limits count blocks, never characters. Any unread descendants/pages are explicit.
async function children(ctx, id, limit = 5000, continuation = null) {
  const budget = Math.max(1, Math.min(10000, Number(limit) || 5000));
  if (continuation && (continuation.rootId !== id || !Array.isArray(continuation.frames) || !continuation.frames.length || continuation.frames.length > 10000 || continuation.frames.some(f => !f || typeof f.id !== 'string' || !f.id || f.id.length > 80 || !Number.isInteger(f.index) || f.index < 0 || f.index > 100 || !Number.isInteger(f.pageSize) || f.pageSize < 1 || f.pageSize > 100 || typeof f.cursor !== 'string' || f.cursor.length > 1000))) return { ok: false, error: 'Notion 续读状态无效' };
  const stack = continuation ? continuation.frames.map(f => ({ ...f, rows: null })) : [{ id, cursor: '', rows: null, index: 0 }], lines = [], snapshots = [];
  const visited = new Set(continuation?.visited || [id.replace(/-/g, '')]);
  let blocks = 0, reason = '';
  while (stack.length) {
    const frame = stack[stack.length - 1];
    if (!frame.rows) {
      if (blocks >= budget) { reason = 'block_limit'; break; }
      frame.pageSize = frame.pageSize || Math.min(100, budget - blocks);
      const database = frame.kind === 'database';
      const endpoint = database ? 'databases/' + encodeURIComponent(frame.id) + '/query' : 'blocks/' + encodeURIComponent(frame.id) + '/children?page_size=' + frame.pageSize + (frame.cursor ? '&start_cursor=' + encodeURIComponent(frame.cursor) : '');
      const r = await api(ctx, database ? 'POST' : 'GET', endpoint, database ? { page_size: frame.pageSize, ...(frame.cursor ? { start_cursor: frame.cursor } : {}) } : undefined); if (!r.ok) return r;
      const j = r.json || {};
      frame.rows = Array.isArray(j.results) ? j.results : []; frame.index = frame.index || 0;
      frame.hasMore = !!j.has_more; frame.next = String(j.next_cursor || '');
      if (frame.hasMore && (!frame.next || frame.next === frame.cursor)) { reason = 'invalid_cursor'; break; }
    }
    if (frame.index >= frame.rows.length) {
      if (frame.hasMore) { frame.cursor = frame.next; frame.rows = null; frame.index = 0; frame.pageSize = null; }
      else stack.pop();
      continue;
    }
    if (blocks >= budget) { reason = 'block_limit'; break; }
    const block = frame.rows[frame.index++]; blocks++;
    const text = block.object === 'page' ? titleOf(block) : blockText(block); if (text) lines.push(text);
    if (block.id) snapshots.push({ id: block.id, type: block.type, text, hasChildren: !!block.has_children, version: block.last_edited_time || '', parentId: frame.id, richText: block[block.type]?.rich_text || null, color: block[block.type]?.color || 'default' });
    let childId = '', kind = '';
    if (block.type === 'child_database') { childId = block.id; kind = 'database'; }
    else if (block.has_children || block.type === 'child_page' || block.object === 'page') childId = block.id;
    else if (block.type === 'link_to_page') childId = block.link_to_page?.page_id || block.link_to_page?.database_id || '';
    // Cross-meeting output links written by the cloud adapter are read exactly once.
    else if (/^https:\/\/(?:www\.)?notion\.(?:so|site|com)\/[a-f0-9-]{32,36}$/i.test(text)) childId = text.split('/').at(-1);
    if (block.link_to_page?.database_id) kind = 'database';
    if (childId && !visited.has(childId.replace(/-/g, ''))) {
      if (!childId || stack.some(f => f.id === childId)) { reason = 'invalid_child'; break; }
      visited.add(childId.replace(/-/g, ''));
      stack.push({ id: childId, kind, cursor: '', rows: null, index: 0 });
    } else if (block.has_children && !block.id) { reason = 'invalid_child'; break; }

  }
  const truncated = !!reason;
  return { ok: true, lines, snapshots, blocks, truncated, ...(reason === 'block_limit' ? { continuation: { rootId: id, visited: [...visited], frames: stack.map(f => ({ id: f.id, kind: f.kind || '', cursor: f.cursor, index: f.index, pageSize: f.pageSize || Math.min(100, budget) })) } } : {}), coverage: { kind: continuation ? 'continuation_segment' : 'document_text', complete: !truncated, readBlocks: blocks, blockLimit: budget, ...(reason ? { reason } : {}) } };
}
// 云端资料库也走这一层，避免它另写一套 Notion URL、鉴权和超时规则。
// 返回每页的正文快照；单页失败只计错，不拦住其余已授权页面。
async function crawlPages(ctx, { pageLimit = 500, blockLimit = 5000, maxBlocks = 100000 } = {}) {
  let cursor = '', seen = 0, errors = 0, hasMore = false;
  const items = [];
  do {
    const request = { page_size: Math.min(100, pageLimit - seen), filter: { property: 'object', value: 'page' }, sort: { direction: 'descending', timestamp: 'last_edited_time' } };
    if (cursor) request.start_cursor = cursor;
    const found = await api(ctx, 'POST', 'search', request);
    if (!found.ok) return { ok: false, error: found.error, items, pages: seen, errors: errors + 1 };
    const rows = ((found.json || {}).results) || [];
    for (const page of rows) {
      if (seen >= pageLimit) break;
      seen++;
      let body = await children(ctx, page.id, blockLimit);
      let totalBlocks = body.blocks || 0;
      while (body.ok && body.continuation && totalBlocks < maxBlocks) {
        const next = await children(ctx, page.id, Math.min(blockLimit, maxBlocks - totalBlocks), body.continuation);
        if (!next.ok) { body = next; break; }
        totalBlocks += next.blocks; body = { ...next, lines: body.lines.concat(next.lines), blocks: totalBlocks, coverage: { ...next.coverage, kind: 'document_text', readBlocks: totalBlocks } };
      }
      if (!body.ok) { errors++; continue; }
      items.push({ id: page.id || '', title: clip(titleOf(page) || '（无标题）', 200), url: page.url || '', at: page.last_edited_time || page.created_time || '', text: body.lines.join('\n'), truncated: body.truncated, coverage: body.coverage, continuation: body.continuation || null });
    }
    hasMore = !!(found.json || {}).has_more;
    cursor = hasMore && seen < pageLimit ? String((found.json || {}).next_cursor || '') : '';
  } while (cursor && seen < pageLimit);
  return { ok: true, items, pages: seen, errors, truncated: hasMore || items.some(p => p.truncated) };
}
// Read one authorized page from its beginning; never append a stale saved prefix.
async function readCompletePage(ctx,id,{blockLimit=5000,maxBlocks=100000}={}){
 const before=await api(ctx,'GET','pages/'+encodeURIComponent(id));
 if(!before.ok)return before;
 const version=before.json?.last_edited_time;
 if(!version)return {ok:false,error:'Notion 未提供可核对的正文版本'};
 let state=null,lines=[],snapshots=[],count=0;
 do{
  const part=await children(ctx,id,Math.min(blockLimit,maxBlocks-count),state);
  if(!part.ok)return part;
  lines.push(...part.lines);snapshots.push(...(part.snapshots||[]));count+=part.blocks;state=part.continuation||null;
  if(part.truncated&&!state)return {ok:false,error:'Notion 正文分页不完整'};
  if(state&&count>=maxBlocks)return {ok:false,error:'Notion 正文尚未读完，保留原有内容'};
 }while(state);
 const after=await api(ctx,'GET','pages/'+encodeURIComponent(id));
 if(!after.ok)return after;
 if(after.json?.last_edited_time!==version)return {ok:false,error:'Notion 资料在读取期间已修改，请重试'};
 return {ok:true,text:lines.join('\n'),snapshots,version,coverage:{kind:'document_text',complete:true,readBlocks:count},url:before.json.url||''};
}
const unavailable = (env, ctx = {}) => connection.state({ ...ctx, env }).connected
  ? { ok: true } : { ok: false, reason: '未接：设置页点「连接 Notion」授权' };

// 工具登记：由 index.js 单向装配时调 registerAll(reg) 注入登记口（主题 2 阶段 1 环消除）。
// reg.register 调用逐字不动，只是 reg 从 require('./index') 改为参数。
function registerAll(reg) {
  reg.register({
    name: 'notion.search', title: '搜 Notion', level: 'read', source: 'notion',
    description: '搜这份 Notion 授权能看到的页面和数据库，返回标题、id 和链接。要正文用 notion.fetch。',
    input: { type: 'object', required: ['query'], properties: {
      query: { type: 'string', minLength: 1, maxLength: 200 },
      limit: { type: 'integer', minimum: 1, maximum: 20, default: 8 },
    } },
    available: unavailable,
    async run(args, ctx) {
      if(useMcp(ctx))return bridge.call(ctx,'search',args);
      const r = await api(ctx, 'POST', 'search', { query: args.query, page_size: Math.min(20, args.limit || 8) });
      if (!r.ok) return r;
      const results = ((r.json || {}).results) || [];
      return { ok: true, items: results.slice(0, args.limit).map(p => ({
        title: clip(titleOf(p) || '（无标题）', 200), text: clip(titleOf(p), 200),
        objectType: p.object || '', id: p.id || '', url: p.url || '',
        ref: 'notion:' + (p.id || ''), source: 'notion:search', at: p.last_edited_time || p.created_time || '',
        editedBy: (p.last_edited_by && p.last_edited_by.id) || '', createdBy: (p.created_by && p.created_by.id) || '',   // 谁改的：manual-forwards 只算 Aaron 本人改的页
      })) };
    },
  });

  reg.register({
    name: 'notion.recent', title: '看 Notion 最近编辑', level: 'read', source: 'notion',
    description: '按最后编辑时间倒序列这份授权能看到的页面，用来找正在编辑的文档。',
    input: { type: 'object', properties: { limit: { type: 'integer', minimum: 1, maximum: 50, default: 20 } } },
    available: unavailable,
    async run(args, ctx) {
      if (useMcp(ctx)) return { ok: false, error: '此 MCP 连接不支持按最近编辑列页面' };
      const r = await api(ctx, 'POST', 'search', { page_size: args.limit || 20, filter: { property: 'object', value: 'page' }, sort: { direction: 'descending', timestamp: 'last_edited_time' } });
      if (!r.ok) return r;
      return { ok: true, items: (((r.json || {}).results) || []).map(p => ({
        title: clip(titleOf(p) || '（无标题）', 200), objectType: p.object || '', id: p.id || '', url: p.url || '',
        ref: 'notion:' + (p.id || ''), source: 'notion:recent', at: p.last_edited_time || p.created_time || '',
        editedBy: (p.last_edited_by && p.last_edited_by.id) || '',
      })) };
    },
  });

  reg.register({
    name: 'notion.user', title: '查 Notion 用户名', level: 'read', source: 'notion',
    description: '按用户 id 取显示名，用来判断页面是谁在改。',
    input: { type: 'object', required: ['id'], properties: { id: { type: 'string', minLength: 8, maxLength: 80 } } },
    available: unavailable,
    async run(args, ctx) {
      const id = String(args.id).trim();
      if (!/^[0-9a-fA-F-]{8,80}$/.test(id)) return { ok: false, error: 'id 不像 Notion 的用户 id' };
      if (useMcp(ctx)) return { ok: false, unsupported: true, error: '此 MCP 连接不支持查用户' };
      const r = await api(ctx, 'GET', 'users/' + encodeURIComponent(id));
      if (!r.ok) return r;
      return { ok: true, data: { name: clip((r.json || {}).name, 120) } };
    },
  });

  reg.register({
    name: 'notion.fetch', title: '取 Notion 页面内容', level: 'read', source: 'notion',
    description: '按页面 id 取真实标题和递归块正文（纯文字）。id 从 notion.search 的结果里拿。',
    input: { type: 'object', required: ['id'], properties: {
      id: { type: 'string', minLength: 8, maxLength: 80, description: '页面或块 id' },
      limit: { type: 'integer', minimum: 1, maximum: 10000, default: 5000 },
      continuation: { type: 'string', maxLength: 2000000, description: '上次返回的 continuation JSON；续读只返回后续正文，请与此前正文合并' },
    } },
    available: unavailable,
    async run(args, ctx) {
      const id = String(args.id).trim();
      if (!/^[0-9a-fA-F-]{8,80}$/.test(id)) return { ok: false, error: 'id 不像 Notion 的页面 id' };
      if(useMcp(ctx))return bridge.call(ctx,'fetch',args);
      let continuation = null; try { if(args.continuation) continuation=JSON.parse(args.continuation); } catch { return { ok:false,error:'Notion 续读状态无效' }; }
      const [page, body] = await Promise.all([api(ctx, 'GET', 'pages/' + encodeURIComponent(id)), children(ctx, id, Math.min(10000, args.limit || 5000), continuation)]);
      if (!body.ok) return body;
      if (!body.lines.length && !body.continuation && !continuation) return { ok: false, error: '这一页没读到文字内容（可能是数据库页，或授权没分享到这一页）' };
      return { ok: true, data: { title: page.ok ? clip(titleOf(page.json) || '（无标题）', 200) : '（标题读不到）', text: body.lines.join('\n'), blocks: body.blocks, truncated: body.truncated, coverage: body.coverage, continuation: body.continuation || null, continued: !!continuation,
        url: page.ok ? page.json.url || '' : '', ref: 'notion:' + id, source: 'notion:blocks', at: page.ok ? page.json.last_edited_time || '' : '' } };
    },
  });
}

// DOCS-NOTION-OAUTH：拿刚换到的令牌问 Notion「我是谁」，核对授权人（oauth-link 绑定账号前调用）。
async function whoAmI(token, fetchImpl = globalThis.fetch) {
  const r = await fetchImpl(API + 'users/me', { headers: { Authorization: 'Bearer ' + token, 'Notion-Version': VERSION }, signal: AbortSignal.timeout(15000) });
  let j = null; try { j = await r.json(); } catch (e) {}
  return { ok: r.ok && !!j, status: r.status, ownerUserId: j && j.bot && j.bot.owner && j.bot.owner.user && j.bot.owner.user.id || '' };
}

async function available(ctx = {}){return connection.state(ctx).connected || !!(await relayFor(ctx)?.available());}

const connected = ctx => connection.state(ctx).connected;
module.exports = { registerAll, relayFor, available, connected, plain, titleOf, blockText, children, crawlPages, readCompletePage, api, whoAmI };
