'use strict';
// 有官方授权（oauth-link）时，本机拿用户令牌直连飞书 / Lark 开放平台；没有授权就返回 null，调用方照旧走 lark-cli。
// 回包整理成和 lark-cli 一样的形状，下游（日历匹配、文档读取）不用分两套。
// 接口路径按开放平台公开文档：calendar/v4 主日历 + instance_view、suite 文档搜索、docx raw_content、wiki get_node。未在商店应用上实测（待核实）。
const link = require('./oauth-link');

// 飞书「权限不足」类错误码 → 一句话 + 要不要引导去增量授权。
const SCOPE_CODES = new Set([99991679, 99991672, 99991668, 1770032, 1069902, 131006]);
function failure(j, status) {
  const code = j && j.code;
  if (status === 401 || code === 99991677 || code === 99991663) return { ok: false, error: '飞书授权已失效，请到设置页重新连接', needsAuth: true };
  if (SCOPE_CODES.has(code) || status === 403) return { ok: false, error: '飞书授权里缺少这项权限，或这篇文档没有分享给你', needsScope: true };
  return { ok: false, error: '飞书没有接受这次请求（' + String(code || status).slice(0, 20) + '）' };
}

async function call(auth, f, method, pathname, { query, body } = {}) {
  const url = auth.apiBase + pathname + (query ? '?' + new URLSearchParams(query) : '');
  const r = await f(url, { method, headers: { Authorization: 'Bearer ' + auth.token, 'Content-Type': 'application/json; charset=utf-8' }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000) });
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok || !j || j.code !== 0) return failure(j, r.status);
  return { ok: true, data: j.data || {} };
}

async function auth(ctx) {
  for (const platform of ['feishu', 'lark']) {
    const a = await link.accessToken(platform, ctx);
    if (a) return a;
  }
  return null;
}

const iso = t => { const n = Number(t && t.timestamp); if (n) return new Date(n * 1000).toISOString(); return (t && t.date) ? t.date + 'T00:00:00' : ''; };

// 等价于 lark-cli calendar +agenda：返回 {ok, data:[event]}，event 字段与 lark-cli 一致（start_time.datetime 等）。
async function agenda({ start, end }, ctx) {
  const a = await auth(ctx);
  if (!a) return null;
  if (a.expired) return { ok: false, error: { message: a.error,code:/连不上|刷新授权失败/.test(a.error||'')?'timeout':'token_expired' } };
  const f = ctx.fetchImpl || globalThis.fetch;
  try {
    const primary = await call(a, f, 'POST', '/open-apis/calendar/v4/calendars/primary');
    if (!primary.ok) return { ok: false, error: { message: primary.error,code:primary.needsAuth||primary.needsScope?'token_expired':'transient' } };
    const cal = primary.data.calendars && primary.data.calendars[0] && primary.data.calendars[0].calendar;
    if (!cal || !cal.calendar_id) return { ok: false, error: { message: '飞书没有返回主日历' } };
    const r = await call(a, f, 'GET', '/open-apis/calendar/v4/calendars/' + encodeURIComponent(cal.calendar_id) + '/events/instance_view',
      { query: { start_time: String(Math.floor(start.getTime() / 1000)), end_time: String(Math.floor(end.getTime() / 1000)), user_id_type: 'open_id' } });
    if (!r.ok) return { ok: false, error: { message: r.error,code:r.needsAuth||r.needsScope?'token_expired':'transient' } };
    const items = (r.data.items || []).filter(ev => ev && ev.status !== 'cancelled').map(ev => ({
      event_id: ev.event_id, summary: ev.summary || '', description: ev.description || '',
      start_time: { datetime: iso(ev.start_time) }, end_time: { datetime: iso(ev.end_time) },
      organizer_calendar_id: ev.organizer_calendar_id || '', vchat: { meeting_url: (ev.vchat && ev.vchat.meeting_url) || '' },
      location: { name: (ev.location && ev.location.name) || '' }, self_rsvp_status: ev.self_rsvp_status || ev.rsvp_status || '',
    }));
    return { ok: true, data: items, via: 'oauth' };
  } catch (e) { return { ok: false, error: { message: '连不上飞书开放平台' } }; }
}

// 等价于 lark-cli docs +search 的结果形状：{ok, data:{results:[{title_highlighted, result_meta:{token,url,doc_types}}]}}
async function searchDocs(query, ctx, { pageSize = 15 } = {}) {
  const a = await auth(ctx);
  if (!a) return null;
  if (a.expired) return { ok: false, error: a.error, needsAuth: true };
  const f = ctx.fetchImpl || globalThis.fetch;
  try {
    const r = await call(a, f, 'POST', '/open-apis/suite/docs-api/search/object', { body: { search_key: String(query).slice(0, 200), count: Math.min(50, pageSize), offset: 0 } });
    if (!r.ok) return r;
    const results = (r.data.docs_entities || []).map(d => ({ entity_type: 'doc', title_highlighted: d.title || '', summary_highlighted: '',
      result_meta: { token: d.docs_token, url: '', doc_types: String(d.docs_type || '').toUpperCase(), owner_name: '' } }));
    return { ok: true, data: { results, has_more: !!r.data.has_more }, via: 'oauth' };
  } catch (e) { return { ok: false, error: '连不上飞书开放平台' }; }
}

// 读一篇文档的纯文本。wiki 节点先换成真实文档 token。返回 {ok, data:{document:{content, document_id}}}，与 lark-cli docs +fetch 同形。
async function fetchDoc(tokenOrUrl, ctx) {
  const a = await auth(ctx);
  if (!a) return null;
  if (a.expired) return { ok: false, error: a.error, needsAuth: true };
  const f = ctx.fetchImpl || globalThis.fetch;
  const s = String(tokenOrUrl || ''), m = s.match(/\/(wiki|docx|docs)\/([A-Za-z0-9]{10,})/);
  let kind = m ? m[1] : 'docx', token = m ? m[2] : s.trim();
  if (!/^[A-Za-z0-9]{10,}$/.test(token)) return { ok: false, error: '不是有效的飞书文档链接' };
  try {
    if (kind === 'wiki') {
      const n = await call(a, f, 'GET', '/open-apis/wiki/v2/spaces/get_node', { query: { token } });
      if (!n.ok) return n;
      const node = n.data.node || {};
      if (node.obj_type !== 'docx') return { ok: false, error: '这个知识库节点不是文档（' + String(node.obj_type || '未知').slice(0, 20) + '），暂不支持' };
      token = node.obj_token;
    } else if (kind === 'docs') return { ok: false, error: '旧版文档暂不支持官方授权读取' };
    const r = await call(a, f, 'GET', '/open-apis/docx/v1/documents/' + encodeURIComponent(token) + '/raw_content');
    if (!r.ok) return r;
    return { ok: true, data: { document: { content: String(r.data.content || ''), document_id: token } }, via: 'oauth' };
  } catch (e) { return { ok: false, error: '连不上飞书开放平台' }; }
}

module.exports = { agenda, searchDocs, fetchDoc, failure };
