'use strict';
const { binPath: resolveLarkCli } = require('./lark-cli');
// 日历读取与重新授权共用的命令边界；runner/open 均可注入，不泄露授权凭据。
const {execFile}=require('child_process');
function parse(text){
 const s=String(text||'').trim();try{return JSON.parse(s);}catch{}
 for(const line of s.split('\n')){try{const j=JSON.parse(line);if(j&&typeof j==='object')return j;}catch{}}
 const i=s.indexOf('{');try{return i>=0?JSON.parse(s.slice(i)):null;}catch{return null;}
}
function run(args,timeout=12000,runner=execFile){
 return new Promise(resolve=>{const done=(error,stdout,stderr)=>{
  const out=parse(stdout),err=parse(stderr);
  resolve({error,json:err?.ok===false?err:out||err});
 };try{runner(resolveLarkCli(),args,{timeout,maxBuffer:4e6,env:{...process.env,LARKSUITE_CLI_NO_UPDATE_NOTIFIER:'1',LARKSUITE_CLI_NO_SKILLS_NOTIFIER:'1'}},done);}catch(e){done(e);}});
}
function failure(result){
 const out=require('../calendar-failure').classify(result.error?.code==='ENOENT'?result.error:result.json?.error||result.error||result.json||{});
 const error=out.reason==='missing_tool'?(result.error?.code==='ENOENT'?'没找到飞书命令行工具':'飞书命令行工具不可用，请安装并配置'):out.reason==='reauth'?'飞书授权已过期':'日历暂时读不到，稍后自动重试';
 return {...out,error,action:out.reason==='reauth'?'reauthorize':null};
}

function create({runner=execFile,open=url=>new Promise((resolve,reject)=>execFile('open',[url],e=>e?reject(e):resolve())),refresh=async()=>{}}={}){
 let state={status:'idle'},pending=null;
 return {
  status:()=>({...state}),
  async start(){
   if(pending)return {ok:true,...state};
   // 在首次异步调用前加锁，重复点击不能发起第二次授权。
   state={status:'starting'};
   pending=(async()=>{
    const r=await run(['auth','login','--domain','all','--no-wait','--json'],30000,runner);
    const d=r.json?.data||r.json||{};
    if(r.error||r.json?.ok===false)throw Error(failure(r).error);
    const url=d.verification_url||d.verification_uri_complete;
    if(!url||!d.device_code||new URL(url).protocol!=='https:')throw Error('暂时无法重新授权，请稍后重试');
    await open(url);
    state={status:'pending'};
    // 此命令负责后台轮询并保存登录态；HTTP 请求不会等它完成。
    void run(['auth','login','--device-code',d.device_code,'--json'],300000,runner).then(async done=>{
     if(done.error||done.json?.ok!==true)throw Error('授权未完成，请重新授权');
     await refresh();state={status:'complete'};
    }).catch(()=>{state={status:'failed',error:'授权未完成，请重新授权'};}).finally(()=>{pending=null;});
    return {ok:true,...state};
   })().catch(e=>{state={status:'failed',error:e.message==='没找到飞书命令行工具'?e.message:'暂时无法重新授权，请稍后重试'};pending=null;return {ok:false,...state};});
   return pending;
  }
 };
}
module.exports={parse,run,failure,create};
