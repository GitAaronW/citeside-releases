'use strict';
// 六顶思考帽找缺（Edward de Bono）。后台按句子措辞统计全场六顶帽子各占多少，占比最低的那顶就是本轮出卡方向；
// 卡片只露一个小标签，写法 = 方法名（括号白话）；帽色带信息所以保留子名，如「六顶思考帽·黑帽（风险视角）」（Aaron 10-25 投票页评论：「这样是最完整的」；通则「方法名后面不再加同义的子名」），统计本身不给用户看。词表是启发式，只用来定方向，不替模型判断内容。
// 与 thinking-methods.json 里「模型自己挑一顶帽子标在判断上」不同：这里是后台先数、再把缺口交给模型。
const HATS = {
  white: { label: '六顶思考帽·白帽（事实视角）', re: /\d|数据|数字|实测|测试结果|统计|目前|现状|报告|结果显示|比例|占比|指标|平均|样本/ },
  red: { label: '六顶思考帽·红帽（感受视角）', re: /觉得|感觉|担心|害怕|喜欢|不喜欢|直觉|个人(?:觉得|认为)|不爽|舒服|难受|有点怕|希望|兴奋|放心|不放心|纠结/ },
  black: { label: '六顶思考帽·黑帽（风险视角）', re: /风险|隐患|问题是|做不到|不行|失败|延期|来不及|万一|瓶颈|成本太高|撑不住|崩|漏|翻车|卡住|不够|缺口|合规|安全/ },
  yellow: { label: '六顶思考帽·黄帽（价值视角）', re: /好处|价值|收益|优势|机会|亮点|卖点|值得|能带来|更好|提升|受益|赚|省/ },
  green: { label: '六顶思考帽·绿帽（新点子视角）', re: /不如|要不|试试|换个思路|有没有可能|新的|点子|idea|另一种|换一种|脑洞|创新/i },
  blue: { label: '六顶思考帽·蓝帽（流程视角）', re: /下一步|排期|负责|谁来|流程|节点|议程|时间点|截止|todo|安排|同步|对齐|评审|确认一下|总结一下/i },
};
const ORDER = Object.keys(HATS);
const LABELS = Object.fromEntries(ORDER.map(k => [k, HATS[k].label]));

// 一句话可以戴多顶帽子；没命中任何词表的句子不计（闲聊、衔接句）。
function hatsOf(rows) {
  const counts = Object.fromEntries(ORDER.map(k => [k, 0]));
  let rowsSeen = 0;
  for (const r of rows || []) {
    const text = String(r?.text || '');
    if (!text.trim()) continue;
    rowsSeen++;
    for (const k of ORDER) if (HATS[k].re.test(text)) counts[k]++;
  }
  const total = ORDER.reduce((n, k) => n + counts[k], 0);
  const share = Object.fromEntries(ORDER.map(k => [k, total ? Math.round(100 * counts[k] / total) : 0]));
  return { counts, share, total, rows: rowsSeen };
}
// 至少 minRows 句才定方向；缺的那顶 = 占比最低（并列取先出现的：白 红 黑 黄 绿 蓝）。
function missing(stat, minRows = 20) {
  if (!stat || stat.rows < minRows || !stat.total) return null;
  const hat = ORDER.reduce((best, k) => stat.share[k] < stat.share[best] ? k : best, ORDER[0]);
  return { hat, label: LABELS[hat] };
}
const prompt = `
六顶思考帽找缺（实验）：hats 是后台按措辞统计的全场六顶帽子占比（white 事实 / red 感受 / black 风险 / yellow 价值 / green 新点子 / blue 流程），hats.missing 是占比最低的那顶。
- 出 gap 卡时优先沿 hats.missing 的视角补会上没人提的角度；内容仍必须落在本场议题上、有依据，并过 So what：答不出「对当前决定有什么影响」就不出。
- 每张卡加 lens 字段，取 white|red|black|yellow|green|blue 之一，表示这张卡站在哪顶帽子。不改 text，不在 text 里写帽子名。
- 不为凑帽子出卡：缺的那顶在这场会上没有实质可补就不出。
`;
// 卡片只露一个小标签：text 前加「六顶思考帽·黑帽（风险视角）」。在 guard 之后做，去重和数字闸看到的仍是原文。
// 模型有时自己把帽子写进 text（「六顶思考帽 · 黑帽（风险）」这类变体）：开头标签串里的六顶思考帽标签一律换成规范写法，
// lens 字段缺失时从帽色字推断；帽色都没有就把那个标签去掉。幂等：规范标签再过一遍不变。
const HAT_CHAR = { 白: 'white', 红: 'red', 黑: 'black', 黄: 'yellow', 绿: 'green', 蓝: 'blue' };
const MODEL_TAG = /^((?:「(?!六顶思考帽)[^」\n]*」)*)「六顶思考帽([^」\n]*)」/;   // 前面的标签串里不能再含六顶思考帽标签，否则两个模型标签只换掉后一个
function tagLens(parsed) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return parsed;
  const tag = c => {
    if (!c || typeof c.text !== 'string') return c;
    let lens = String(c.lens || '').toLowerCase(), text = c.text, pre = '';
    for (let m = text.match(MODEL_TAG); m; m = text.match(MODEL_TAG)) {
      const hat = (m[2].match(/([白红黑黄绿蓝])帽/) || [])[1];
      if (!LABELS[lens] && hat) lens = HAT_CHAR[hat];
      pre += m[1]; text = text.slice(m[0].length);
    }
    const label = LABELS[lens];
    const out = pre + (label ? `「${label}」` : '') + text;
    return out === c.text ? c : { ...c, text: out };
  };
  return { ...parsed, suggestion: tag(parsed.suggestion), insights: (Array.isArray(parsed.insights) ? parsed.insights : []).map(tag) };
}
const LENS_TAG = /^「六顶思考帽·([^」]+)」/;
module.exports = { HATS, ORDER, LABELS, LENS_TAG, HAT_CHAR, hatsOf, missing, tagLens, prompt };
