'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto');
// Publish only a complete, flushed receipt. Never turn a persistence failure into success.
function writeText(file, text, opts = {}) {
  const dir = path.dirname(file), tmp = file + '.' + crypto.randomUUID() + '.tmp';
  const mode = opts.mode === undefined ? 0o600 : opts.mode;
  let fd, published = false;
  try {
    fd = fs.openSync(tmp, 'wx', mode);
    fs.writeFileSync(fd, text);
    fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined;
    fs.renameSync(tmp, file);
    published = true;
    const d = fs.openSync(dir, 'r');
    try { fs.fsyncSync(d); }
    catch (e) {
      // The file bytes are already fsynced and the rename has landed. Windows refuses fsync on a directory handle (EPERM).
      if (!e || (e.code !== 'EPERM' && e.code !== 'EINVAL' && e.code !== 'ENOTSUP')) throw e;
    } finally { fs.closeSync(d); }
  } catch (e) {
    // Callers must not roll back memory after the new bytes became visible.
    if (published && e && typeof e === 'object') e.published = true;
    throw e;
  } finally {
    if (fd !== undefined) fs.closeSync(fd);
    fs.rmSync(tmp, { force: true });
  }
}
// opts.space / opts.newline keep legacy on-disk formats (JSON.stringify(v, null, n) ± '\n') byte-identical.
function write(file, value, opts = {}) {
  let text = JSON.stringify(value, null, opts.space);
  if (opts.newline) text += '\n';
  writeText(file, text, opts);
}
module.exports = { write, writeText };
