'use strict';

function failure(code) { const error = new Error(code); error.code = code; return error; }

// Dormant policy for EphemeralTurnRunner plus the caller's existing independent
// fallback. No provider selection, model changes, process spawning or retries.
async function boundedTurnFallback(runner, fallback, text, { signal, timeoutMs, primaryTimeoutMs } = {}) {
  if (!runner || typeof runner.run !== 'function' || typeof fallback !== 'function') throw new TypeError('explicit adapters required');
  if (![timeoutMs, primaryTimeoutMs].every(value => Number.isSafeInteger(value) && value > 0)) throw failure('invalid_timeout');
  if (signal?.aborted) throw failure('cancelled');
  const deadline = Date.now() + timeoutMs;
  let primaryError;
  try {
    const result = await runner.run(text, { signal, timeoutMs: Math.min(primaryTimeoutMs, timeoutMs) });
    return { ...result, transport: 'persistent', degraded: false };
  } catch (error) { primaryError = error; }
  if (signal?.aborted || primaryError?.code === 'cancelled' || primaryError?.code === 'runner_closed') throw failure('cancelled');
  // Backpressure is admission control, not a reason to spawn more work.
  if (primaryError?.code === 'transport_busy' || primaryError?.code === 'invalid_request') throw primaryError;
  const remaining = deadline - Date.now();
  if (remaining <= 0) throw failure('timeout');
  const controller = new AbortController();
  const knownReasons = new Set(['timeout', 'transport_closed', 'transport_spawn_failed', 'transport_write_failed', 'transport_read_failed',
    'invalid_frame', 'frame_too_large', 'rpc_failed', 'invalid_thread', 'invalid_turn', 'empty', 'output_too_large', 'turn_failed']);
  const fallbackReason = knownReasons.has(primaryError?.code) ? primaryError.code : 'primary_failed';
  return new Promise((resolve, reject) => {
    let settled = false;
    const settle = (error, result) => {
      if (settled) return;
      settled = true; clearTimeout(timer); signal?.removeEventListener('abort', abort);
      error ? reject(error) : resolve(result);
    };
    const stop = code => { controller.abort(failure(code)); settle(failure(code)); };
    const abort = () => stop('cancelled');
    const timer = setTimeout(() => stop('timeout'), remaining);
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) return abort();
    // Promise boundary also captures synchronous adapter failures. Late answers
    // are ignored even if an adapter does not honor the cancellation signal.
    Promise.resolve().then(() => {
      if (settled) throw failure('cancelled');
      return fallback(text, { signal: controller.signal, timeoutMs: Math.max(1, deadline - Date.now()) });
    }).then(result => {
      if (!result || typeof result.text !== 'string' || !result.text.trim()) return settle(failure('empty'));
      settle(null, { ...result, transport: 'fallback', degraded: true, fallbackReason });
    }, error => settle(error));
  });
}

module.exports = { boundedTurnFallback };
