'use strict';
// 火山偶尔把同一段话判给两个说话人，各出一条 final：时间首尾相接、文字相同或一条包含另一条。
// 只比同一识别流里紧挨着的两条。同一句话隔很久又出现是真的（游戏语音、复述），不能按文本全局去重。
// 8 字及以上、后句被前句包含或以前句开头：仍删除或只留新增（f97528a）。
// 4–7 字，以及后一句以前一句结尾：只标记，不改正文。
const MAX_GAP_MS = 1500, MIN_CHARS = 4, DROP_MIN_CHARS = 8;
const norm = s => String(s || '').replace(/[\s\p{P}\p{S}]/gu, '').toLowerCase();
const timed = t => t && Number.isFinite(t.start) && Number.isFinite(t.end);
// prev、next 都是转写行。返回 null（照常发布）、{action:'drop'}、{action:'trim',text} 或 {action:'mark',rule}。
function classify(prev, next) {
 const a = prev?.sourceTiming, b = next?.sourceTiming;
 if (!timed(a) || !timed(b) || !a.streamId || a.streamId !== b.streamId) return null;
 if (Math.abs(b.start - a.end) > MAX_GAP_MS) return null;
 if (String(prev.speaker ?? '') === String(next.speaker ?? '')) return null;
 const p = norm(prev.text), n = norm(next.text);
 const short = Math.min(p.length, n.length);
 if (short < MIN_CHARS) return null;
 if (p.includes(n)) return short >= DROP_MIN_CHARS ? {action: 'drop'} : {action: 'mark', rule: 'short'};
 if (n.startsWith(p)) {
  if (short < DROP_MIN_CHARS) return {action: 'mark', rule: 'short'};
  // 在原文上走到第 p.length 个有效字符，保留后面的标点和大小写。
  let seen = 0, i = 0;
  for (const ch of String(next.text)) { if (seen === p.length) break; i += ch.length; if (norm(ch)) seen++; }
  const text = String(next.text).slice(i).replace(/^[\s\p{P}\p{S}]+/u, '');
  return norm(text) ? {action: 'trim', text} : {action: 'drop'};
 }
 if (n.endsWith(p)) return {action: 'mark', rule: 'suffix'};
 return null;
}
// drop 的原文挂在上一句，trim 的原文挂在本句。mark 只留标记，正文不动。
function apply(prev,row){
  const r=classify(prev,row);if(!r)return null;
  if(r.action==='mark'){row.providerRepeatMark={rule:r.rule,text:row.text};return 'mark';}
  const t=row.sourceTiming,kept={text:row.text,speaker:row.speaker,start:t.start,end:t.end};
  if(r.action==='drop')(prev.providerRepeat||=[]).push(kept);
  else{(row.providerRepeat||=[]).push(kept);row.text=r.text;}
  return r.action;
}

module.exports={classify,apply,norm,MAX_GAP_MS,MIN_CHARS,DROP_MIN_CHARS};
