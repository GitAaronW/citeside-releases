'use strict';
// L3 Source Domain Health Memory: tracks which public domains reliably serve
// readable page text vs. returning 403/Cloudflare/TLS errors, and ranks
// search results so high-authority, non-anti-bot sources are fetched first.
const fs = require('fs');
const path = require('path');

const FILE_NAME = 'source-domain-health.json';
const MAX_DOMAINS = 300;
const WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

const GOLD_DOMAINS = new Set([
  'en.wikipedia.org', 'zh.wikipedia.org', 'wikipedia.org',
  'sec.gov', 'www.sec.gov', 'efts.sec.gov',
  'github.com', 'api.github.com', 'docs.github.com',
  'arxiv.org', 'developer.mozilla.org', 'datatracker.ietf.org',
  'nodejs.org', 'kubernetes.io', 'docs.python.org', 'react.dev',
  'reuters.com', 'apnews.com', 'gov.cn', 'stats.gov.cn', 'chinatax.gov.cn',
  'news.ycombinator.com', 'openai.com', 'anthropic.com', 'ai.google.dev'
]);

const memCache = new Map();

function hostOf(url) {
  try {
    return new URL(String(url || '')).hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return '';
  }
}

function isGoldHost(host) {
  if (!host) return false;
  if (GOLD_DOMAINS.has(host)) return true;
  for (const g of GOLD_DOMAINS) {
    if (host.endsWith('.' + g)) return true;
  }
  return false;
}

function stateFile(dataDir) {
  if (!dataDir) return '';
  return path.join(dataDir, 'state', FILE_NAME);
}

function load(dataDir, now = Date.now()) {
  const file = stateFile(dataDir);
  if (!file) return {};
  const cached = memCache.get(file);
  if (cached && now - cached.at < 30000) return cached.data;
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    const data = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    memCache.set(file, { at: now, data });
    return data;
  } catch {
    const data = {};
    memCache.set(file, { at: now, data });
    return data;
  }
}

function save(dataDir, data, now = Date.now()) {
  const file = stateFile(dataDir);
  if (!file) return;
  try {
    const entries = Object.entries(data)
      .filter(([, v]) => v && now - (Number(v.updatedAt) || 0) <= WINDOW_MS)
      .sort((a, b) => (Number(b[1].updatedAt) || 0) - (Number(a[1].updatedAt) || 0))
      .slice(0, MAX_DOMAINS);
    const pruned = Object.fromEntries(entries);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = file + '.tmp.' + process.pid;
    fs.writeFileSync(tmp, JSON.stringify(pruned, null, 2));
    fs.renameSync(tmp, file);
    memCache.set(file, { at: now, data: pruned });
  } catch {}
}

function record(dataDir, url, outcome, now = Date.now()) {
  const host = hostOf(url);
  if (!host || !dataDir) return;
  const data = load(dataDir, now);
  const cur = data[host] && typeof data[host] === 'object'
    ? { ok: Number(data[host].ok) || 0, fail: Number(data[host].fail) || 0, streakFail: Number(data[host].streakFail) || 0, lastError: String(data[host].lastError || '') }
    : { ok: 0, fail: 0, streakFail: 0, lastError: '' };
  if (outcome === 'ok') {
    cur.ok += 1;
    cur.streakFail = 0;
    cur.lastError = '';
  } else {
    cur.fail += 1;
    cur.streakFail += 1;
    cur.lastError = String(outcome || 'fail').slice(0, 40);
  }
  cur.updatedAt = now;
  data[host] = cur;
  save(dataDir, data, now);
}

function scoreRow(row, healthMap, now = Date.now()) {
  const host = hostOf(row?.url);
  let score = 0;
  if (isGoldHost(host)) score += 30;
  const stats = host ? healthMap[host] : null;
  if (stats && now - (Number(stats.updatedAt) || 0) <= WINDOW_MS) {
    const ok = Number(stats.ok) || 0;
    const fail = Number(stats.fail) || 0;
    const streakFail = Number(stats.streakFail) || 0;
    if (streakFail >= 2 && ok === 0) score -= 80;
    else if (streakFail >= 3) score -= 60;
    else if (ok > 0 && ok >= fail) score += Math.min(25, ok * 5);
    else if (fail > ok) score -= Math.min(40, (fail - ok) * 10);
  }
  return score;
}

function rankUrls(dataDir, rows, now = Date.now()) {
  if (!Array.isArray(rows) || rows.length <= 1) return Array.isArray(rows) ? rows : [];
  const healthMap = load(dataDir, now);
  return rows
    .map((row, idx) => ({ row, idx, score: scoreRow(row, healthMap, now) }))
    .sort((a, b) => b.score - a.score || a.idx - b.idx)
    .map(x => x.row);
}

function clearCache() { memCache.clear(); }

module.exports = { FILE_NAME, GOLD_DOMAINS, hostOf, isGoldHost, record, rankUrls, load, clearCache };
