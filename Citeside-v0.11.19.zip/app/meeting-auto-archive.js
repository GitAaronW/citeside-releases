'use strict';

// Filing uses only sources explicitly authorized for this meeting. It never
// reads a URL, widens scope, guesses from titles, or edits document content.
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function resolve(data, source, session) {
  const project = source.projectManual && data.projects.find(p => p.id === source.projectId);
  const projectId = project?.id || '';
  const nodes = data.knowledgeNodes || [];
  const valid = ids => [...new Set((Array.isArray(ids) ? ids : []).filter(id =>
    nodes.some(n => n.id === id && (n.projectId || '') === projectId)
  ))].sort();
  const selected = new Set((Array.isArray(session.contextSourceIds) ? session.contextSourceIds : []).slice(0, 100));
  const refs = projectId ? data.sources.filter(s =>
    s.id !== source.id && selected.has(s.id) && s.projectId === projectId && !s.projectAuto && !s.archived
  ) : [];
  const mappings = refs.map(s => valid(s.topicIds)).filter(ids => ids.length);
  const sets = [...new Set(mappings.map(ids => JSON.stringify(ids)))];
  // Legacy explicit assignments, including an empty selection, also win.
  const manual = source.topicManual === true || source.topicIds !== undefined && source.topicAuto !== true;
  const semantic = sets.length === 0 && projectId ? require('./meeting-topic-classifier').accepted(data, source, session) : null;
  const topicIds = manual ? valid(source.topicIds) : sets.length === 1 ? JSON.parse(sets[0]) : semantic ? valid(semantic.topicIds) : [];
  const relatedManual = source.relatedManual === true || source.relatedIds !== undefined && source.relatedAuto !== true;
  const relatedIds = relatedManual ? source.relatedIds || [] : refs.map(s => s.id).sort();
  const reason = !projectId ? 'no-confirmed-project' : manual ? 'manual' :
    sets.length > 1 ? 'conflicting-source-topics' : semantic ? 'classified-meeting-evidence' : topicIds.length ? 'authorized-source-topics' : 'no-source-topic-mapping';
  const ended = !!(session.end || session.finalized);
  return {
    projectId, topicIds, relatedIds, relatedManual, manual,
    receipt: {
      method: semantic && !manual ? 'meeting-topic-classification' : 'authorized-source-mapping',
      classificationEvidence: semantic && !manual ? semantic.evidence : [],
      state: topicIds.length ? (ended ? 'archived' : 'linked') : 'unassigned',
      reason, projectId, topicIds, sourceIds: refs.map(s => s.id).sort(),
      relatedLinks: refs.filter(s => relatedIds.includes(s.id) && s.url).map(s => ({ sourceId: s.id, url: s.url })),
      ended
    }
  };
}

function apply(hub, source, session) {
  const result = resolve(hub.data, source, session);
  const patch = { autoArchive: result.receipt };
  if (!result.manual) {
    patch.topicIds = result.topicIds;
    patch.topicAuto = true;
  }
  if (!result.relatedManual) {
    patch.relatedIds = result.relatedIds;
    patch.relatedAuto = true;
  }
  // Filing is separate from link discovery. Never move an existing document
  // to another project or queue an external write for local metadata changes.
  if (source.motherDocumentId && result.receipt.ended) {
    try {
      const store = require('./mother-documents').get(hub.root);
      const record = store.read(source.motherDocumentId).record;
      if (record.projectId !== result.projectId) {
        patch.autoArchive = { ...patch.autoArchive, documentState: 'project-mismatch' };
      } else {
        store.fileMeeting(source.motherDocumentId, source.sessionId, result.receipt);
        patch.autoArchive = { ...patch.autoArchive, documentState: 'filed' };
      }
    } catch {
      patch.autoArchive = { ...patch.autoArchive, documentState: 'retry-required' };
    }
  }
  let changed = false;
  for (const [key, value] of Object.entries(patch)) {
    if (!equal(source[key], value)) {
      source[key] = value;
      changed = true;
    }
  }
  if (changed) {
    source.revision++;
    hub.dirty = (hub.dirty || 0) + 1;
  }
  return source;
}

module.exports = { resolve, apply };
