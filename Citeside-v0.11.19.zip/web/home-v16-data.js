'use strict';
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.CitesideHomeV16=factory();})(typeof window==='undefined'?globalThis:window,function(){
 function millis(value){if(typeof value==='number')return Number.isFinite(value)?value:0;if(typeof value!=='string'||!value.trim())return 0;const n=/^\d+$/.test(value)?Number(value):Date.parse(value);return Number.isFinite(n)?n:0;}
 function dayKey(value){const n=millis(value);if(!n)return '';const d=new Date(n),pad=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
 function weekBounds(now=Date.now()){const start=new Date(now);start.setHours(0,0,0,0);start.setDate(start.getDate()-((start.getDay()+6)%7));const end=new Date(start);end.setDate(end.getDate()+7);return {start:start.getTime(),end:end.getTime()};}
 function calendar(events,{now=Date.now(),expanded=false}={}){
  const bounds=weekBounds(now),seen=new Set(),all=[];
  for(const event of events||[]){const start=millis(event.start);if(start<now||start>=bounds.end||start<bounds.start)continue;const key=String(event.calendarId||'')+'|'+String(event.eventId||start+'|'+event.title);if(seen.has(key))continue;seen.add(key);all.push({...event,startMs:start,endMs:millis(event.end)});}
  all.sort((a,b)=>a.startMs-b.startMs||String(a.eventId||'').localeCompare(String(b.eventId||'')));
  const visible=all.length>10&&!expanded?all.slice(0,10):all,groups=[];
  for(const event of visible){const key=dayKey(event.startMs);let group=groups.at(-1);if(group?.key!==key){group={key,total:all.filter(e=>dayKey(e.startMs)===key).length,events:[]};groups.push(group);}group.events.push(event);}
  return {...bounds,total:all.length,hidden:all.length-visible.length,groups};
 }
 function history(meetings){const stamp=m=>millis(m.start)||-Infinity;return (meetings||[]).filter(m=>m?.id).slice().sort((a,b)=>stamp(b)-stamp(a)||String(a.id).localeCompare(String(b.id)));}
 function parseLocalDate(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))return null;const [y,m,d]=value.split('-').map(Number),at=new Date(y,m-1,d);return dayKey(+at)===value?at:null;}
 function dateBounds(filter={kind:'all'},now=Date.now()){
  if(filter.kind==='all')return null;const at=new Date(now),today=new Date(at.getFullYear(),at.getMonth(),at.getDate()),next=d=>new Date(d.getFullYear(),d.getMonth(),d.getDate()+1);
  if(filter.kind==='today')return {start:+today,end:+next(today)};
  if(filter.kind==='week')return weekBounds(now);
  if(filter.kind==='month')return {start:+new Date(at.getFullYear(),at.getMonth(),1),end:+new Date(at.getFullYear(),at.getMonth()+1,1)};
  const start=parseLocalDate(filter.from),last=parseLocalDate(filter.to);
  if(filter.kind!=='custom'||!start||!last||start>last)throw Error('invalid_date_range');
  return {start:+start,end:+next(last)};
 }
 function timeline(meetings,{query='',filter={kind:'all'},now=Date.now()}={}){const bounds=dateBounds(filter,now),search=String(query).trim().toLocaleLowerCase();return history(meetings,{now}).filter(m=>{const start=millis(m.start);return (!search||[m.title,m.autoTitle,m.text].filter(Boolean).join(' ').toLocaleLowerCase().includes(search))&&(!bounds||!!start&&start>=bounds.start&&start<bounds.end);});}
 return {millis,dayKey,weekBounds,calendar,history,parseLocalDate,dateBounds,timeline};
});
