/* 定价与权益静态元信息（与官网 site/pricing/index.html 对齐）。实际结账价格、币种与月度额度一律以服务端 /account/payments/catalog 及 /v1/me 返回为准。 */
window.THT_PLANS = Object.freeze([
  Object.freeze({ id: 'free', sku: 'trial', name: 'Free Trial', price: 0, hours: 15, research: 30, credits: 0 }),
  Object.freeze({ id: 'plus', sku: 'plus', name: 'Plus', price: 19.9, hours: 20, research: 30, credits: 15000 }),
  Object.freeze({ id: 'pro', sku: 'pro', name: 'Pro', price: 39.9, hours: 50, research: 80, credits: 25000 }),
  Object.freeze({ id: 'max', sku: 'max', name: 'Max', price: 99.9, hours: null, research: null, credits: 60000 })
]);
